


const Tech = () => {
  
  return (
    <div className="flex justify-center  mt-[100px] mb-[300px]">
        <div className="flex  flex-col gap-4 w-[30%] justify-center items-center ">
      <h4 className="text-gray-400 font-">Teach</h4>
      <h4>I want to teach</h4>
<select className=" w-full pt-3 pb-3 pr-5 pl-4 border-[#E0E0E0] border-2 rounded-2xl " >
<option value="Spanish">Spanish</option>
<option value="English">English</option>
<option value="French">French</option>
<option value="Italian">Italian</option>
<option value="Japanese">Japanese</option>
<option value="Chinese">Chinese</option>

</select>


      {/* </div> */}
      
    </div>
    </div>
  )
}

export default Tech
