import RoutesDeclare from "./component/Routes/RoutesDeclare"


function App() {
 

  return (
    <>
  <RoutesDeclare/>
    </>
  )
}

export default App
