<?php
require_once($_SERVER['CONTEXT_DOCUMENT_ROOT'].'/customer-order-tool/officeapp/db/db.inc');

$query = "SELECT configuration_key,configuration_value  FROM `configuration`";
  $variable_result =  mysqli_query($zendb, $query); 
  $variable_array_value = '';
  if(!empty($variable_result)){
	   while($variable_array = mysqli_fetch_array($variable_result)){
			$variable_array_value =  $variable_array['configuration_value'];
			$variable_array_key =  $variable_array['configuration_key'];
			//define('MODULE_SHIPPING_INSTALLED','fedexwebservices.php;upsxml.php;usps.php;storepickup.php');
			if($variable_array_key == "MODULE_SHIPPING_INSTALLED"){
				define('MODULE_SHIPPING_INSTALLED','fedexwebservices.php;upsxml.php;usps.php;storepickup.php');
			}else{
				define($variable_array_key,$variable_array_value);
			}

			
	   }
  }



define('MODULE_SHIPPING_FEDEX_WEB_SERVICES_TEXT_TITLE', 'FedEx');
define('MODULE_SHIPPING_FEDEX_QUOTE_SORT', 'Price');
define('MODULE_SHIPPING_USPS_REGULATIONS', 'False');
define('MODULE_SHIPPING_FEDEX_WEB_SERVICES_TEXT_DESCRIPTION', '<h2>FedEx Web Services</h2><p>You will need to have registered an account with FedEx and proper approval from FedEx identity to use this module. Please see the README.TXT file for other requirements.</p>');
define('MODULE_SHIPPING_FEDEX_WEB_SERVICES_TEXT_DESCRIPTION_SOAP', '<h2>FedEx Web Services</h2><p><span style="color:#dd0000;">Warning: SOAP Extension is not enabled. FedEx Web Services Shipping Module will not work until SOAP is enabled. Ensure that PHP is compiled with SOAP. Speak to your hosting company if unsure.</span></p> <p>You will need to have registered an account with FedEx and proper approval from FedEx identity to use this module. Please see the README.TXT file for other requirements.</p>');


/* Ups */

define('MODULE_SHIPPING_UPSXML_RATES_TEXT_TITLE', 'United Parcel Service');
	define('MODULE_SHIPPING_UPSXML_RATES_TEXT_DESCRIPTION', 'United Parcel Service');
	define('MODULE_SHIPPING_UPSXML_RATES_TEXT_UNKNOWN_ERROR', 'An unknown error occured with the ups shipping calculations.');
	define('MODULE_SHIPPING_UPSXML_RATES_TEXT_IF_YOU_PREFER', 'If you prefer to use ups as your shipping method, please contact');
	define('MODULE_SHIPPING_UPSXML_RATES_TEXT_COMM_ERROR', 'A communication error occured while attempting to contact the UPS gateway');
	define('MODULE_SHIPPING_UPSXML_RATES_TEXT_COMM_UNKNOWN_ERROR', 'An unknown error occured while attempting to contact the UPS gateway');
	define('MODULE_SHIPPING_UPSXML_RATES_TEXT_COMM_VERSION_ERROR', 'This module supports only xpci version 1.0001 of the UPS Rates Interface. Please contact the webmaster for additional assistance.');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_US_ORIGIN_01', 'UPS Next Day Air');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_US_ORIGIN_02', 'UPS 2nd Day Air');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_US_ORIGIN_03', 'UPS Ground');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_US_ORIGIN_07', 'UPS Worldwide Express');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_US_ORIGIN_08', 'UPS Worldwide Expedited');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_US_ORIGIN_11', 'UPS Standard');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_US_ORIGIN_12', 'UPS 3 Day Select');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_US_ORIGIN_13', 'UPS Next Day Air Saver');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_US_ORIGIN_14', 'UPS Next Day Air Early A.M.');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_US_ORIGIN_54', 'UPS Worldwide Express Plus');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_US_ORIGIN_59', 'UPS 2nd Day Air A.M.');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_US_ORIGIN_65', 'UPS Express Saver');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_CANADA_ORIGIN_01', 'UPS Express');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_CANADA_ORIGIN_02', 'UPS Expedited');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_CANADA_ORIGIN_07', 'UPS Worldwide Express');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_CANADA_ORIGIN_08', 'UPS Worldwide Expedited');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_CANADA_ORIGIN_11', 'UPS Standard');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_CANADA_ORIGIN_12', 'UPS 3 Day Select');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_CANADA_ORIGIN_13', 'UPS Express Saver');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_CANADA_ORIGIN_14', 'UPS Express Early A.M.');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_CANADA_ORIGIN_54', 'UPS Worldwide Express Plus');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_EU_ORIGIN_07', 'UPS Express');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_EU_ORIGIN_08', 'UPS Expedited');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_EU_ORIGIN_11', 'UPS Standard');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_EU_ORIGIN_54', 'UPS Worldwide Express Plus');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_EU_ORIGIN_65', 'UPS Express NA1');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_EU_ORIGIN_69', 'UPS Express Saver');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_EU_ORIGIN_64', 'UPS Express Saver');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_PR_ORIGIN_01', 'UPS Next Day Air');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_PR_ORIGIN_02', 'UPS 2nd Day Air');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_PR_ORIGIN_03', 'UPS Ground');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_PR_ORIGIN_07', 'UPS Worldwide Express');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_PR_ORIGIN_08', 'UPS Worldwide Expedited');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_PR_ORIGIN_14', 'UPS Next Day Air&reg; Early A.M.');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_PR_ORIGIN_54', 'UPS Worldwide Express Plus');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_MEXICO_ORIGIN_07', 'UPS Worldwide Express');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_MEXICO_ORIGIN_08', 'UPS Worldwide Expedited');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_MEXICO_ORIGIN_54', 'UPS Worldwide Express Plus');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_OTHER_ORIGIN_07', 'UPS Worldwide Express');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_OTHER_ORIGIN_08', 'UPS Worldwide Expedited');
	define('MODULE_SHIPPING_UPSXML_SERVICE_CODE_OTHER_ORIGIN_54', 'UPS Worldwide Express Plus');
	define('MODULE_SHIPPING_UPSXML_RATES_TEST_MODE', 'Prod');
	
	
	/*Usps*/
	
define('MODULE_SHIPPING_USPS_TEXT_TITLE', 'United States Postal Service');
define('MODULE_SHIPPING_USPS_TEXT_SHORT_TITLE', 'USPS');
define('MODULE_SHIPPING_USPS_TEXT_DESCRIPTION', 'United States Postal Service<br /><br />You will need to have registered an account with USPS at https://secure.shippingapis.com/registration/ to use this module<br /><br />USPS expects you to use pounds as weight measure for your products.');

define('MODULE_SHIPPING_USPS_TEXT_TEST_MODE_NOTICE', '<br /><span class="alert">Your account is in TEST MODE. Do not expect to see usable rate quotes until your USPS account is moved to the production server (1-800-344-7779) and you have set the module to production mode in Zen Cart admin.</span>');
define('MODULE_SHIPPING_USPS_TEXT_SERVER_ERROR', 'An error occurred in obtaining USPS shipping quotes.<br />If you prefer to use USPS as your shipping method, please try refreshing this page, or contact the store owner.');
define('MODULE_SHIPPING_USPS_TEXT_ERROR', 'We are unable to find a USPS shipping quote suitable for your mailing address and the shipping methods we typically use.<br />If you prefer to use USPS as your shipping method, please contact us for assistance.<br />(Please check that your Zip Code is entered correctly.)');

define('MODULE_SHIPPING_USPS_TEXT_DAY', 'day');
define('MODULE_SHIPPING_USPS_TEXT_DAYS', 'days');
define('MODULE_SHIPPING_USPS_TEXT_WEEKS', 'weeks');
define('HTTP_SERVER', 'https://dev1.specialtywraps.com');
define('HTTPS_SERVER', 'https://dev1.specialtywraps.com');
define('DIR_WS_CATALOG', '/');
define('DIR_FS_SQL_CACHE', '/');
define('DIR_WS_HTTPS_CATALOG', '/');
define('PROJECT_VERSION_MAJOR', '');
define('PROJECT_VERSION_MINOR', '');
define('IS_ADMIN_FLAG', 'True');



define('MODULE_SHIPPING_STOREPICKUP_TEXT_TITLE', 'Store Pickup');
define('MODULE_SHIPPING_STOREPICKUP_TEXT_DESCRIPTION', 'Customer In Store Pick-up');
// payment method is GV/Discount
  define('PAYMENT_METHOD_GV', 'Gift Certificate/Coupon');
  define('PAYMENT_MODULE_GV', 'GV/DC');
  define('DIR_FS_CATALOG', $rootPath);
  define('DIR_FS_EMAIL_TEMPLATES', DIR_FS_CATALOG . 'email/');
define('MODULE_SHIPPING_STOREPICKUP_TEXT_WAY', 'Walk In');
define('MODULE_SHIPPING_STOREPICKUP_MULTIPLE_WAYS', "");
define('DATE_FORMAT_SHORT', '%m/%d/%Y');  // this is used for strftime()
  define('DATE_FORMAT_LONG', '%A %d %B, %Y'); // this is used for strftime()
  define('DATE_FORMAT', 'm/d/Y'); // this is used for date()
  define('DATE_TIME_FORMAT', DATE_FORMAT_SHORT . ' %H:%M:%S');


define('NAVBAR_TITLE', 'My Account');
define('HEADING_TITLE', 'My Account Information');

define('OVERVIEW_TITLE', 'Overview');
define('OVERVIEW_SHOW_ALL_ORDERS', '(show all orders)');
define('OVERVIEW_PREVIOUS_ORDERS', 'Previous Orders');
define('TABLE_HEADING_DATE', 'Date');
define('TABLE_HEADING_ORDER_NUMBER', 'No.');
define('TABLE_HEADING_SHIPPED_TO', 'Ship To');
define('TABLE_HEADING_STATUS', 'Status');
define('TABLE_HEADING_VIEW', 'View');

define('MY_ACCOUNT_TITLE', 'My Account');
define('MY_ACCOUNT_INFORMATION', 'View or change my account information.');
define('MY_ACCOUNT_ADDRESS_BOOK', 'View or change entries in my address book.');
define('MY_ACCOUNT_PASSWORD', 'Change my account password.');
define('MY_ACCOUNT_CARD_UPDATE','Update Credit Card on Authorize.net');

define('MY_ORDERS_TITLE', 'My Orders');
define('MY_ORDERS_VIEW', 'View the orders I have made.');

define('EMAIL_NOTIFICATIONS_TITLE', 'Email Notifications');
define('EMAIL_NOTIFICATIONS_NEWSLETTERS', 'Subscribe or unsubscribe from newsletters.');
define('EMAIL_NOTIFICATIONS_PRODUCTS', 'View or change my product notification list.');
define('DISCOUNT_CODE_TEXT', 'Price Refrects Quantity Discount of');
define('SALE_TEXT', 'Sale Price!');
?>
