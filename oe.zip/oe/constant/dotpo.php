<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2003 The zen-cart developers                           |
// |                                                                      |   
// | http://www.zen-cart.com/index.php                                    |   
// |                                                                      |   
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
// $Id: cod.php 1969 2005-09-13 06:57:21Z drbyte $
//

  define('MODULE_PAYMENT_DOTPO_TEXT_TITLE', '<i class="fa fa-money" aria-hidden="true"></i> PO ');
  define('MODULE_PAYMENT_DOTPO_TEXT_DESCRIPTION', 'PO');
  define('MODULE_PAYMENT_DOTPO_NUMER_TEXT', 'PO Number');
  define('MODULE_PAYMENT_DOTPO_TERM_CONDITION_TEXT', 'Check the box to indicate that you have read and agree to the terms presented in the Standard Terms and Conditions of Sale agreement (click through for full agreement).');
  define('MODULE_PAYMENT_DOTPO_PO_NUMBER_TEXT_JS_CC_SC', '* Please add PO Number.\n');
  define('MODULE_PAYMENT_DOTPO_PO_TERM_TEXT_JS_CC_SC', '* You must agree to the Standard Terms and Conditions.\n');
?>
