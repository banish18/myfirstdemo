<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2004 Josh Dechant                                      |
// |                                                                      |
// | Portions Copyright (c) 2004 The zen-cart developers                  |
// |                                                                      |
// | http://www.zen-cart.com/index.php                                    |
// |                                                                      |
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
//  $Id: ot_order_discount.php,v 1.000 2004-08-22 dreamscape Exp $
//

  define('MODULE_ORDER_DISCOUNT_TITLE', 'Global Order Discount');
  define('MODULE_ORDER_DISCOUNT_DESCRIPTION', 'Order specific discount percentage or flat rate - Specify discount rate based on the order total.');
  define('SHIPPING_NOT_INCLUDED', ' [Shipping not included]');
  define('TAX_NOT_INCLUDED', ' [Tax not included]');

  define('MODULE_ORDER_DISCOUNT_PERCENTAGE_TEXT_EXTENSION', ' (%s%%)'); // %s is the percent discount as a number; %% displays a % sign
  define('MODULE_ORDER_DISCOUNT_FORMATED_TITLE', '<strong>Order Discount%s:</strong>'); // %s is the placement of the MODULE_ORDER_DISCOUNT_PERCENTAGE_TEXT_EXTENSION
  define('MODULE_ORDER_DISCOUNT_FORMATED_TEXT', '<strong>-%s</strong>'); // %s is the discount amount formated for the currency
?>
