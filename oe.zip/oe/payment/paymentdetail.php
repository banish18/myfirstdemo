<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include(getcwd().'/function.php');
if(isset($_POST['action']) && $_POST['action'] == "delete_card"){
	$cid = $_POST['cpid'];
	$pid = $_POST['paymentid'];
	$processCIM = new processCIM;
	$processCIM->deletePayment($cid,$pid);
	echo "Card Deleted Successfully";
}
?>
<html>
<head>
<title>Payment Records</title>

<style type="text/css">
#payment .caption h4, .caption h5 {  margin-bottom: 6px;}
#add_payment{min-height:1000px}
#edit_payment{min-height:900px}
</style>
</head>
<body>
	<div class="container1">
		<div class="row">
			<div class="col-md-12">
				<div class="card-header d-flex justify-content-between align-items-center">
				<span>
					<i class="fa fa-table"></i>
					<a href="/direct-payment">Go Back</a> 
				</span>
				</div>
				<div class="card-body">
					<div class="cards">
						<?php 
				
				$html = '';
				if(isset($_POST['cid'])){
					
					$html .='<div class="card-body" >
					<div class="cards">';
						$processCIM = new processCIM;
					    $processCIM->getPayments($_POST['cid']);
					$html .='</div>
				</div>';
				
				}
				echo $html;
				
				?>
				</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
