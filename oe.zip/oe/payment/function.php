<?php 
include('payment.php');
require_once($_SERVER['CONTEXT_DOCUMENT_ROOT'].'/customer-order-tool/officeapp/db/db.inc');
class processCIM{
	function createcutomerProfile($email){
		$cim = new authorizenet_cim;
		return $cim->createCustomerProfileRequest($email);
	}
	function getPayments($cid){
		global $zendb;
		$cim = new authorizenet_cim;
		$token = "";
		$html = '';
		$cim->getProfilePageRequest2($cid);
		
		if ($cim->isSuccessful())
		{
			$token = $cim->getProfilePageRequestToken();
			$cim->getCustomerProfileRequest();
			$response = str_replace('xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd"','',substr($cim->response,strpos($cim->response,"<getCustomerProfileResponse")));
			$response_obj = simplexml_load_string('<?xml version="1.0" encoding="utf-8"?>'.$response) or die("Error: Cannot create object");
			$html .='<div class="panel panel-info tab-pane center-block" id="payment_record">
				<div class="panel-body">
				<div class="row row-equal-height">';	
				$i = 0;			
				foreach ($response_obj->profile->paymentProfiles as $item) {
					$i++;
					
					mysqli_query($zendb,"update customers set customers_customerPaymentProfileId = '".(string)$item->customerPaymentProfileId."' where customers_customerProfileId =".$cid);
					$customer_payment_methods[] = (string)$item->customerPaymentProfileId;	
					$cim->setParameter('customerPaymentProfileId', $item->customerPaymentProfileId);					
					$cim->getCustomerPaymentProfileRequest();		
					$html .='<div class="col-sm-6 col-md-4 col-lg-3 embed-responsive-item">
						<div class="thumbnail">
							<div class="float-left w-100 caption p-3 bg-light border mb-4"><p>';
								if($item->customerPaymentProfileId !=""){
														$html .='<input type="radio"  checked="checked" value="'.$item->customerPaymentProfileId.'" name="customer_paymentProfileId">';	
								}else{
											$html .='<input type="radio" onclick="SetPaymentProfiler('.$item->customerPaymentProfileId.','. $customers_customerProfileId.');" value="'.$item->customerPaymentProfileId.'" name="customer_paymentProfileId">'; 													
								}
								if(isset($item->payment->creditCard)){
									$vlv = "<span>Card &nbsp;&nbsp;:</span>  &nbsp;".$item->payment->creditCard->cardNumber;
								}else{
									$vlv =  "<span>Account:</span>  &nbsp;".$item->payment->bankAccount->accountNumber.", ".$item->payment->bankAccount->bankName;
								}
								$html .='<label>'.$vlv.'</label></p>';
								if(isset($item->payment->creditCard)){
								$html .='<div class="clearfix"></div>
								<p >'."<span>Expiration &nbsp;&nbsp;:</span> &nbsp;".$cim->expirationDate.'</p >';
								}							
								 isset($item->payment->creditCard) ? $vlv1 = $item->billTo->firstName." ". $item->billTo->lastName : $vlv1 = $item->payment->bankAccount->nameOnAccount ;
								 $html .='<p ><span>Name :&nbsp;</span>'.$vlv1.'</p >
								<p ><span>Address : </span>'.$item->billTo->address.' </p >
								<p ><span>City : </span> '.$item->billTo->city .'</p >
								<p align="right"><button class="btn btn-primary editPay btn-sm float-left" data-toggle="modal" data-target="#myModal" role="button" value="'.$item->customerPaymentProfileId.'" > <i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit Details</button>
								<button type="button" class="btn btn-secondary holiday-bow-button btn-sm float-right" onclick="DeletePaymentProfiler('.$item->customerPaymentProfileId.','.$cid.')"> <i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
								</p>
							</div>
						</div>
						</div>';
					}
						$html .='</div>
													</div>';
													
						if($i == 0){
							$html .= '<h3 class="m-3">No Records.</h3>';	
						}							
						$html .='</div>';
						$html .='<div id="addPayDiv"><button type="button" id="addPaymentButton" data-toggle="modal" data-target="#myModal" class="btn btn-success btn-sm holiday-bow-button"> <i class="fa fa-plus" aria-hidden="true"></i>ADD NEW CREDIT CARD</button></div><br>
						<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						  <div class="modal-dialog">
							<div class="modal-content">
							  <div class="modal-body">
									<iframe id="add_payment" class="embed-responsive-item " name="add_payment" width="100%"  frameborder="0" scrolling="no" ></iframe>
									
									<iframe id="edit_payment" class="embed-responsive-item panel" name="edit_payment" width="100%"  frameborder="0" scrolling="no" style="display:none;"></iframe>		       	
							  </div>
							</div>
						  </div>
						</div>';
						$html .='</div>';
						
						$html .='<form id="send_token" action="" method="post" target="load_profile" >
							<input type="hidden" name="token" value="'.$token.'" />
							<input type="hidden" name="paymentProfileId" value="" />
							<input type="hidden" name="shippingAddressId" value="" />
						</form>';
					}else{
						if($cim->resultCode == "Error" && $cim->cim_code){
							$html .= '<h5 class="m-3">There is no customer profile record are found.Need to update new customer profile id.</h5><br />
							<input type="button" onclick="newCustomerProfile('.$cid.')" id="new_customer_id" value="Update Profile" />
							';
						}else{
							$html .= '<h3 class="m-3">No customer profile found.</h3><br />';
						}		
					}
		echo $html;
	}	
	function deletePayment($cid,$pid){
		$cim = new authorizenet_cim;
		$cim->deleteCustomerPaymentProfileRequest($cid,$pid);
	}
}
?>
