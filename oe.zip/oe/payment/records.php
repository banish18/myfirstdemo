<?php 
include('payment/function.php');
if(isset($_POST['action']) && $_POST['action'] == "delete_card"){
	$cid = $_POST['cpid'];
	$pid = $_POST['paymentid'];
	$processCIM = new processCIM;
	$processCIM->deletePayment($cid,$pid);
	echo "Card Deleted Successfully";
}
?>
<html>
<head>
<title>Payment Records</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="payment/contentx/bootstrap.min.css">

<!-- jQuery library -->
<script src="payment/contentx/jquery.min.js"></script>

<!-- Popper JS -->
<script src="payment/contentx/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="payment/contentx/bootstrap.min.js"></script> 

<link href="payment/contentx/paymentShipping.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="payment/contentx/popup.js"></script>
<!-- Live url (https://js.authorize.net/v1/Accept.js) -->
<script src="https://jstest.authorize.net/v1/Accept.js"></script>
<script type="text/javascript">
	<!-- Live url (https://accept.authorize.net/customer/) -->
	var baseUrl = "https://test.authorize.net/customer/";
	var onLoad = true;
	tab = null;
	function returnLoaded() {
		console.log("Return Page Called ! ");
		$('.close').trigger('click');
		showTab(tab);
	}
	window.CommunicationHandler = {};
	function parseQueryString(str) {
		var vars = [];
		var arr = str.split('&');
		var pair;
		for (var i = 0; i < arr.length; i++) {
			pair = arr[i].split('=');
			vars[pair[0]] = unescape(pair[1]);
		}
		return vars;
	}
	CommunicationHandler.onReceiveCommunication = function (argument) {
		params = parseQueryString(argument.qstr)
		parentFrame = argument.parent.split('/')[4];
		console.log(params);
		console.log(parentFrame);
		console.log(params['height']);
		$frame = null;
		switch(parentFrame){
			case "addPayment" 	: $frame = $("#add_payment");break;
			case "editPayment" 	: $frame = $("#edit_payment");break;
		}
		switch(params['action']){
			case "resizeWindow" 	: if( parentFrame== "manage" && parseInt(params['height'])<1150) params['height']=1150;
										$frame.outerHeight(parseInt(params['height']));
										break;
			case "successfulSave" 	: $('#myModal').modal('hide'); location.reload(false); break;
			case "cancel" 			: 	switch(parentFrame){
										case "addPayment"   : $("#send_token").attr({"action":baseUrl+"addPayment","target":"add_payment"}).submit(); $("#add_payment").hide();  $('#myModal').modal('toggle');  break; 										
										case "editPayment"  :  $('#myModal').modal('toggle'); $("#payment").show(); $("#addPayDiv").show(); break;  
										}
						 				break;
		}
	}

	function showTab(target){
		onLoad = true;
		var currTime = sessionStorage.getItem("lastTokenTime");
		if (currTime === null || (Date.now()-currTime)/60000 > 15){
			location.reload(true);
			onLoad = true;
		}
		if (onLoad) {
			setTimeout(function(){ 
				$("#send_token").attr({"action":baseUrl+"addPayment","target":"add_payment"}).submit();
			} ,100);
			onLoad = false;
		}

		
		switch(target){
			case "#home" 		: $("#home").show();$("#acceptJSPayDiv").show();break;
			case "#payment" 	: $("#payment").show(); $("#addPayDiv").show(); break;
		}
	}

	$(function(){

		$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
			tab = $(e.target).attr("href") // activated tab
			sessionStorage.setItem("tab",tab);
			showTab(tab);
		});
		onLoad = true;
		sessionStorage.setItem("lastTokenTime",Date.now());
		tab = sessionStorage.getItem("tab");
		if (tab === null) {
			$("[href='#home']").parent().addClass("active");
			tab = "#home";
		}
		else{
			$("[href='"+tab+"']").parent().addClass("active");
		}
		console.log("Tab : "+tab);
		showTab(tab);
		$("#addPaymentButton").click(function() {
			$("#myModalLabel").text("Add Details");
			$("#edit_payment").hide();
			$("#add_payment").show();
			$(window).scrollTop($('#add_payment').offset().top-50);
		});
		
		$(".editPay").click(function(e) {
			$ppid = $(this).attr("value");
			$("#send_token [name=paymentProfileId]").attr("value",$ppid);
			$("#add_payment").hide();
			$("#edit_payment").show();
			$("#send_token").attr({"action":baseUrl+"editPayment","target":"edit_payment"}).submit();
			$("#send_token [name=paymentProfileId]").attr("value","");
			$("#myModalLabel").text("Edit Details")
			$(window).scrollTop($("#edit_payment").offset().top-30);
		});
	});

	function DeletePaymentProfiler(paymentid,cpid)
	{   
		if(confirm("Are you sure you want to delete this?")){
			$.ajax({
			  type: 'POST',
			  url: "records.php",
			  data: {action:'delete_card',paymentid:paymentid,cpid:cpid},
			  dataType: "text",
			  success: function(resultData) {
				   location.reload();	
			  }
			});
		}
		else{
			return false;
		}
	}
</script>
<style type="text/css">
#payment .caption h4, .caption h5 {  margin-bottom: 6px;}
#add_payment{min-height:1000px}
#edit_payment{min-height:900px}
</style>
</head>
<body>
	<div class="container1">
		<div class="row">
			<div class="col-md-12">
				<div class="card-header d-flex justify-content-between align-items-center">
				<span>
					<i class="fa fa-table"></i>
					<a href="/direct-payment">Go Back</a> 
				</span>
				</div>
				<div class="card-body">
					<div class="cards">
						<?php 
						$processCIM = new processCIM;
						if(isset($_GET['cid'])){
							$processCIM->getPayments($_GET['cid']);
						}
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>

