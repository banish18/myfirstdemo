<?php 
include('function.php');
if(isset($_POST['action']) && $_POST['action'] == "add_new_cutomer"){
	$email 		= $_POST['email'];
	$processCIM = new processCIM;
	$data 		= $processCIM->createcutomerProfile($email);
	echo $data;
	exit;
}
?>
<html>
<head>
<title>Payments</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="/direct-payment/contentx/bootstrap.min.css">

<!-- jQuery library -->
<script src="/direct-payment/contentx/jquery.min.js"></script>

<!-- Popper JS -->
<script src="/direct-payment/contentx/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="/direct-payment/contentx/bootstrap.min.js"></script>

</head>
<body>
	<div class="container">
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
			<div class="card-header d-flex justify-content-between align-items-center">
			<span>
				<i class="fa fa-table"></i>
				<h5>Customer Profile</h5> 
            </span>
            <div style="display: flex;align-items: center;position: absolute;right: 20px;">
				<a href="javascript:void(0)" class="btn btn-info" data-toggle="modal" data-target="#add_user_modal">
					Add New Customer Profile
				</a>
			</div>
            </div>
			<div class="card-body">
				<div class="table-responsive">
					<form method="post" id="payment-form">
						<input type="text" name="customer_profile" id="customer_profile" class="form-control col-md-6" placeholder="Please enter customer profile id" required/>
						<hr />
						<input type="button" name="submit" class="btn btn-info" id="get-payments" value="Get Payment Profile"/>
					</form>
				</div>
			</div>
			<!-- Add User Modal -->
				<div class="modal fade" id="add_user_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
				  <div class="modal-dialog modal-dialog-centered" role="document">
					<div class="modal-content">
						<ul class="errors"></ul>
					  <div class="modal-header">					  
						<h5 class="modal-title" id="exampleModalLongTitle">Add New Customers</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
					  </div>
					  <div class="modal-body">
						<form method="POST" id="add_user_form">
						  <div class="form-group">
							<label for="user_email" class="col-form-label">Email</label>
							<input type="text" class="form-control" id="email" name="email">
						  </div>		  
						</form>
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary" id="add_cutomer_profile">Save</button>
					  </div>
					</div>
				  </div>
				</div>
		</div>
		<div class="col-md-2"></div>
	</div>
	</div>
</body>
<script>
$(function(){
	$("#get-payments").click(function(){
		var customerProfile = $("#customer_profile").val();	
		if(customerProfile != "" ){
			window.location.href = "/direct-payment/records.php?cid="+customerProfile;
		}else{
			alert("Please Enter Customer profile id");	
		}
		
	});
	$("#add_cutomer_profile").click(function(){
		var email = $("#email").val();
		$.ajax({
		  type: 'POST',
		  url: "/direct-payment/index.php",
		  data: {action:'add_new_cutomer',email:email},
		  dataType: "text",
		  success: function(resultData) {
			   alert(resultData);	
			   location.reload();
		  }
		});
	});
});
</script>
</html>
