<?php
class SampleCodeConstants
{
	//merchant credentials
	const MERCHANT_LOGIN_ID = "5KP3u95bQpv";
	const MERCHANT_TRANSACTION_KEY = "346HZ32z3fP4hTG2";
}
?>

