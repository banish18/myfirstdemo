<?php 
include('payment.php');
class processCIM{
	function createcutomerProfile($email){
		die('sdkjfhgsk');
		$cim = new authorizenet_cim;
		//$cim->createCustomerProfileRequest($email);
		//return $cim->customerProfileId;
	}
	function getPayments($cid){
		$cim = new authorizenet_cim;
		//$cid = "1922271500";
		$token = "";
		$html = '';
		$cim->getProfilePageRequest2($cid);
		if ($cim->isSuccessful())
		{
			$token = $cim->getProfilePageRequestToken();
			$cim->getCustomerProfileRequest();
			$response = str_replace('xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd"','',substr($cim->response,strpos($cim->response,"<getCustomerProfileResponse")));
			$response_obj = simplexml_load_string('<?xml version="1.0" encoding="utf-8"?>'.$response) or die("Error: Cannot create object");
			//echo "<pre>";print_r();
				
			$html .='<div class="panel panel-info tab-pane center-block" id="payment">
				<div class="panel-heading">
					<h2 class="leftBoxHeading">Saved Payment Methods</h2>
				</div>
				<div class="panel-body">
				<div class="row row-equal-height">';	
				$i = 0;			
				foreach ($response_obj->profile->paymentProfiles as $item) {
					$i++;
					$customer_payment_methods[] = (string)$item->customerPaymentProfileId;				
					$cim->setParameter('customerPaymentProfileId', $item->customerPaymentProfileId);					
					$cim->getCustomerPaymentProfileRequest();		
					$html .='<div class="col-sm-6 col-md-4 col-lg-3 embed-responsive-item">
						<div class="thumbnail">
							<div class="float-left w-100 caption p-3 bg-light border mb-4">';
								if($item->customerPaymentProfileId !=""){
														$html .='<input type="radio"  checked="checked" value="'.$item->customerPaymentProfileId.'" name="customer_paymentProfileId">';	
								}else{
											$html .='<input type="radio" onclick="SetPaymentProfiler('.$item->customerPaymentProfileId.','. $customers_customerProfileId.');" value="'.$item->customerPaymentProfileId.'" name="customer_paymentProfileId">'; 													
								}
								if(isset($item->payment->creditCard)){
									$vlv = "Card &nbsp;&nbsp;: &nbsp;".$item->payment->creditCard->cardNumber;
								}else{
									$vlv =  "Account : &nbsp;".$item->payment->bankAccount->accountNumber.", ".$item->payment->bankAccount->bankName;
								}
								$html .='<label>'.$vlv.'</label>';
								if(isset($item->payment->creditCard)){
								$html .='<div class="clearfix"></div>
								<p >'."Expiration &nbsp;&nbsp;: &nbsp;".$cim->expirationDate.'</p >';
								}							
								 isset($item->payment->creditCard) ? $vlv1 = $item->billTo->firstName." ". $item->billTo->lastName : $vlv1 = $item->payment->bankAccount->nameOnAccount ;
								 $html .='<p >Name :&nbsp;'.$vlv1.'</p >
								<p >Address : '.$item->billTo->address.' </p >
								<p >City : '.$item->billTo->city .'</p >
								<p align="right"><button class="btn btn-primary editPay btn-xs float-left" data-toggle="modal" data-target="#myModal" role="button" value="'.$item->customerPaymentProfileId.'" >Edit Details</button>
								<button type="button" class="btn btn-danger holiday-bow-button btn-xs float-right" onclick="DeletePaymentProfiler('.$item->customerPaymentProfileId.','.$cid.')">Delete</button>
								</p>
							</div>
						</div>
						</div>';
					}
						$html .='</div>
													</div>';
													
						if($i == 0){
							$html .= '<h3 class="m-3">No Records.</h3>';	
						}							
						$html .='</div>
						</div>';
						$html .='<div id="addPayDiv"><button type="button" id="addPaymentButton" data-toggle="modal" data-target="#myModal" class="btn btn-success holiday-bow-button">ADD NEW CREDIT CARD</button></div><br>
						<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
						  <div class="modal-dialog">
							<div class="modal-content">
							  <div class="modal-body">
									<iframe id="add_payment" class="embed-responsive-item " name="add_payment" width="100%"  frameborder="0" scrolling="no" ></iframe>
									
									<iframe id="edit_payment" class="embed-responsive-item panel" name="edit_payment" width="100%"  frameborder="0" scrolling="no" ></iframe>		       	
							  </div>
							</div>
						  </div>
						</div>
						<form id="send_token" action="" method="post" target="load_profile" >
							<input type="hidden" name="token" value="'.$token.'" />
							<input type="hidden" name="paymentProfileId" value="" />
							<input type="hidden" name="shippingAddressId" value="" />
						</form>';
					}else{
						$html .= 'No Records For this customer.';	
					}
		echo $html;
	}	
	function deletePayment($cid,$pid){
		$cim = new authorizenet_cim;
		$cim->deleteCustomerPaymentProfileRequest($cid,$pid);
	}
}
?>
