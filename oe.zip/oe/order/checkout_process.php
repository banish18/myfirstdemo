<?php 
/*ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);*/
$rootPath = $_SERVER['CONTEXT_DOCUMENT_ROOT'].'/customer-order-tool/officeapp/oe/';
require($rootPath.'constant/shipping.php');
require($rootPath.'includes/classes/payment.php');
$payment_modules = new payment('authorizenet_cim');


// load the selected shipping module
require($rootPath.'includes/classes/shipping.php');

if(isset($_SESSION['shipping'])){
	$shipping_modules = new shipping($_SESSION['shipping']);
	$order 		  	= new order;
	$order->info['ordertotal'] = [];
	$warehouses 	= $order->info['warehouse_id'];
	$multiTitleData = $_POST["multiOrderdatatitle"];
	$splitVals = [];
	foreach($order->info['ot_classes'] as $key => $value){
		foreach($value as $kk => $vv){
			$splitVals[$kk][] = $vv;
		}
	}
	$oTtotals = [];
	foreach($splitVals as $key => $value){
		$splitValsd = [];
		foreach($value as $kk => $vv){
			foreach($vv as $kkd => $vvv){
				$splitValsd[] = $vvv;
			}
		}
		$oTtotals[$key] = $splitValsd;
	}
	foreach ($oTtotals as $key => $row)
	{	
		$orderBy = array();
		foreach($row as $kk => $datas){
			$orderBy[$kk] = $datas['order_by'];
		}
		array_multisort($orderBy, SORT_ASC, $row);
		$oTtotals[$key] = $row;
	}
	$order->info['ordertotal'] = $oTtotals;
	foreach($warehouses as $key => $value){
		$shipCost = '0';
		$shitanVal = '0';
		$subtotal = [];
		foreach($order->info['ordertotal'][$value] as $ky => $val){
			if($val['code'] == "ot_subtotal"){
				$subtotal[$key] = $val['value'];
			}
		}
		foreach($order->info['ordertotal'][$value] as $ky => $val){
			if($val['code'] == "ot_shipping"){
				$shipCost = $val['value'];
				if($val['title'] == "Tantative Shipping:"){
					$shipCost  = number_format((float)$subtotal[$key]*15/100, 2, '.', '');
					$val['value'] = $shipCost;
					$val['text'] = "$".$shipCost;
				}
			}
			if($val['code'] == "ot_total"){
				$val['value'] += $shipCost;
				$val['text'] = '$'.number_format((float)$val['value'], 2, '.', '');
				$order->info['total'][$value] = $val['value'];
			}
			$order->info['ordertotal'][$value][$ky] = $val;
		}
	}
	foreach($order->info['ordertotal'] as $keym => $value){
		$outputArray = [];
		//Let's make a cycle going for every array inside $content
		foreach ($value as $innerArray) {
		  //Does this $innerArray['name'] (filter_ammount) exist in $outputArray in an array 
		  //consisting in key => value where the key is 'name' and equals 
		  //what we look for that is(filter_ammount)?
		  $key = array_search($innerArray['code'], array_column($outputArray , 'code'));
		  //If not, let's place this array in the $output array
		  if ($key === false) {
			  array_push($outputArray, $innerArray);
		  } else { 
			  //If exists, then $key is the $key of the $outputArray and let's add to its value 
			  //our current value, that is in our $innerArray, concatenated with a comma
			  $outputArray[$key]['value'] += number_format((float)$innerArray['value'], 2, '.', '');
			  $outputArray[$key]['text']  = '$'.number_format((float)$outputArray[$key]['value'], 2, '.', '');
		  }
		  $order->info['ordertotal'][$keym] = $outputArray;
		}
	}
	
	
	
	/*echo "<pre>";print_r($order->info['ordertotal']);
	die;*/

	$paymentRes = $payment_modules->before_process();
	if($paymentRes['status'] == "5"){
		$res = array('status' => '5',"order" => $paymentRes['msg']);
	}else{
		$orderIds 	  = $order->create(2);
		$order->saveorderDetails($orderIds);
		foreach($orderIds as $key => $order_id){
			$order->create_add_products($key,$order_id,false);
		}
		
		
		$payment_modules->after_process($orderIds);
		$order->saveOrdertotal($orderIds);
		$order->send_order_email($orderIds);
		$orderHtml 	  = $order->getOrder($orderIds);
		$order->clearCart();
		$res = array('status' => '1',"order" => $orderHtml);
		unset($_SESSION['shipping']);
		unset($_SESSION['drop_ship_flag_fedex']);
		unset($_SESSION['subtotal']);
		unset($_SESSION['total']);
		unset($_SESSION['payment']);
		unset($_SESSION['custom_ship_code']);
		unset($_SESSION['cart']);
	}
}else{
	$res = array('status' => '0');
}
echo json_encode($res);
?>
