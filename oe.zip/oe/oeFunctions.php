<?php
date_default_timezone_set('America/New_York');//or change to whatever timezone you want

include '../db/dbzen.inc';
include 'oeAPI.php';

//$_GET['do']='getCustomer';
//$_GET['do']='lookUpCustomer';
//$_GET['search']='Erik';
//$_GET['customer']='10';
//$_GET['order']='102053';

$shipment = array('mark_up' => '10', 'oID' => '108997', 'res_ups' => '0', 'res_fedex' => '0', 'ds_fee' => '0', 'gfp' => '0', 'shipping_code' => '03', 'order_date' => date('Y-m-d'),
	'ship_name' 	=> 'Louis Markulin', 
	'ship_company' 	=> 'Restorative Support', 
	'ship_street1' 	=> '565 E Main St', 
	'ship_street2' 	=> 'Suite 210', 
	'ship_city' 	=> 'Canfield', 
	'ship_state' 	=> 'OH', 
	'ship_zip' 		=> '44406', 
	'ship_country' 	=> 'US',
	'bill_street1' 	=> 'PO BOX 625', 
	'bill_city' 	=> 'Canfield', 
	'bill_state' 	=> 'OH', 
	'bill_zip' 		=> '44406', 
	'bill_country' 	=> 'US'
);
$packages[] = array( 'weight' => '2', 'commodity' => '125', 'length' => '15', 'width'	=> '7', 'height' => '3' );
$packages[] = array( 'weight' => '3', 'commodity' => '125', 'length' => '24', 'width'	=> '22', 'height' => '7' );

$selected_customer = (new customer)
		->setZenId($zendb);


if (isset($_GET['customer'])) $selected_customer->setCustomerId($_GET['customer']);
if (isset($_GET['order'])) $selected_customer->setCustomerId($_GET['order']);
/*$new_shipment = (new shipping)
		->setShipment($shipment)
		->setPackages($packages);*/

//echo '<pre>';
switch($_GET['do']){
	case 'lookUpCustomer':
		echo json_encode($selected_customer->lookUpCustomer($_GET['term']));
		break;
	case 'lookUpProduct':
		echo json_encode($selected_customer->lookUpProduct($_GET['term']));
		break;
	case 'lookUpProductdesc':
		echo json_encode($selected_customer->lookUpProductdesc($_GET['term']));
		break;	
	case 'lookUpCustomerByAddress':
		echo json_encode($selected_customer->lookUpCustomerByAddress($_GET['term']));
		break;
	case 'lookUpState':
		echo json_encode($selected_customer->lookUpState($_GET['term'],$_GET['cont']));
		break;	
	case 'getCustomer':
		echo json_encode($selected_customer->getCustomer());
		break;
	case 'getAddresses':
		echo json_encode($selected_customer->getAddresses());
		break;
	case 'getOrders':
		echo json_encode($selected_customer->getOrders());
		break;
	case 'getOrderTotals':
		echo json_encode($selected_customer->getOrderTotals());
		break;
	case 'getOrderProducts':
		echo json_encode($selected_customer->getOrderProducts());
		break;
	case 'getOrderStatusHistories':
		echo json_encode($selected_customer->getOrderStatusHistories());
		break;
	case 'getUpsRates':
		echo json_encode($new_shipment->getUpsRates());
		break;
	case 'getUpsGfRates':
		echo json_encode($new_shipment->getUpsGfRates());
		break;
	case 'getFedexRates':
		echo json_encode($new_shipment->getFedexRates());
		break;
	case 'getUspsRates':
		echo json_encode($new_shipment->getUspsRates());
		break;
	case 'getAllRates':
		$new_shipment->getUpsRates();
		$new_shipment->getUpsGfRates();
		$new_shipment->getFedexRates();
		echo json_encode($new_shipment->getUspsRates());
		break;
	case 'changePassword':
		echo $selected_customer->changePassword($_GET['data']);
		break;
}
//echo '</pre>';

?>
