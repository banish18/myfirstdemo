<?php
require_once( '../db/db.inc' );
require_once('payment/function.php');
//session_start();
//echo "<pre>";
//print_r($_SESSION);
//echo "</pre>";

$sql = "SELECT DISTINCT group_id, group_name FROM group_pricing";
$group_pricing=mysqli_query($zendb, $sql);
$selected_option = "";
if (!$group_pricing) die($sql . '<br>COULD NOT GET DISCOUNT GROUPS:' . mysqli_error($zendb));
else {
	$group_pricing_options = '<option value="0">NONE</option>';
	while($row = mysqli_fetch_array($group_pricing)) {
		$group_pricing_options .= '<option value="' . $row['group_id'] . '">' . $row['group_name'] . '</option>';
	}
}

$get_country = "SELECT  * FROM countries";
$get_result = mysqli_query($zendb, $get_country);
if (!$get_result) die($get_country . '<br>COULD NOT GET DISCOUNT GROUPS:' . mysqli_error($zendb));
else {
	$country_option = '<option value="">Please Choose Your Country</option>';
	while ($country = mysqli_fetch_array($get_result)) {
		if($country['countries_id'] == 223){ $selected_option = "selected=selected"; } else { $selected_option = ""; }
		
		$country_option .= '<option value="' . $country['countries_id'] . '"'. $selected_option.'>' . $country['countries_name'] . '</option>';
	}
}
$terms_options = '<option value="0">Due in Advance</option>
<option value="1">Special</option>
<option value="2">Due Upon Receipt</option>
<option value="3">N15</option>
<option value="4">N30</option>
<option value="5">1%10N30</option>
<option value="6">N45</option>
<option value="7">N60</option>
<option value="8">N90</option>
<option value="9">12/1</option>';

$spClass = 'd-none';

if(isset($_POST['action']) && $_POST['action'] == "add_new_cutomer"){
	$email 		= $_POST['email'];
	$processCIM = new processCIM;
	$data 		= $processCIM->createcutomerProfile($email);
	echo $data;
	exit;
}
?>

   

<html lang="en">
   <head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
		<!-- Raleway Font Family -->
		
		<!-- Font Awesome v4.7.0 -->
		<link href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"> 
		<!-- custom style file -->
		<link rel="stylesheet" type="text/css" href="assets/css/style.css" />
		<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
		<link href="payment/contentx/paymentShipping.css" rel="stylesheet" type="text/css" />
		<title>Holiday Manufacturing Inc, Holiday Bows</title>
  
   </head>
    <!--<div class="loader-overlay" style="visibility:hidden"><div class="lds-default"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div></div>-->
    
   <body>
	<div class="wrapper">
      <div class="top-bar">
        <div class="container">
          <div class="row mb-0">
		  <div class="col-md-4 justify-content-start p-0">
			<div class="row ml-6 mt-2">
				<div class="col-md-7 justify-content-end ml-4 p-0 mt-2">
					<h5>Customer Id : <b id="customer_id_head"></b></h5>
				</div>
				<div class="col-md-4 justify-content-end p-0 head_button">
					<a href="JavaScript:void(0);" class="btn btn-primary p-2 m-1" id="save_customer">
                      <i class="fa fa-check"></i>
                      Save
                    </a>
                    <a href="JavaScript:void(0);" class="btn btn-primary" id="update_customer" style="display:none">
                      <i class="fa fa-check"></i>
						Update
                    </a>
				</div>
			</div>
		  </div>
            <div class="col-md-8 justify-content-end d-flex p-0">
              <div class="form-row">
                <div class="col-md-6">
                  <label for="lookup" class="small mb-1">Lookup Customer</label>
                  <input type="text" class="form-control form-control-sm input-style" id="customer_search_name" placeholder="Enter Name, Company, Phone or Email" />
                </div>
                <div class="col-md-6">
                  <label for="byAddress" class="small mb-1">By Address</label>
                  <input type="text" class="form-control form-control-sm input-style" id="customer_search_address" placeholder="Enter Street, Town or Zip" />
                </div>
              </div>
            </div>
          </div>
        </div><!-- container closed -->
      </div>
	   <button style="display:none;" type="button" class="btn suggestion-btn-info btn-lg" data-toggle="modal" data-target="#suggestionmodel">Open Modal</button>
	   <button style="display:none;" type="button" class="btn error-btn-info btn-lg" data-toggle="modal" data-target="#errorM">Open Modal</button>
	   <!--Message Modal -->
		<div class="modal fade" id="suggestionmodel"  tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="vertical-alignment-helper">
				<div class="modal-dialog ">
			<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<h4 class="modal-title">We could not verify the address provided. Please select an address from the list below.</h4>
							<button type="button" class="close" data-dismiss="modal">&times;</button>
						</div>
						<div class="modal-body">       
						</div>
						<div class="modal-footer">
							<button type="button"  class="btn suggestion-confirm btn-primary" id="suggestion-confirm">Confirm</button>
							<button type="button" data-dismiss="modal" class="btn suggestion-cancel btn-danger" id="suggestion-cancel">Cancel</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		
		<!-- Modal -->
		<div class="modal fade" id="errorM"  tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="vertical-alignment-helper">
				<div class="modal-dialog ">
					<!-- Modal content-->
					<div class="modal-content" >
						<div class="modal-header">
							
							<h4 class="modal-title float-left">Address validation error :</h4>
							<button type="button" class="close float-right" data-dismiss="modal">&times;</button>
						</div>
			
						<div class="modal-body">We could not verify the address provided. Please enter correct address.</div>	
						<div class="modal-footer"><button type="button" data-dismiss="modal" class="btn suggestion-cancel btn-primary" id="suggestion-cancel">Cancel</button></div>
					</div>    
				</div>
			</div>
		</div>
		
		<!-- Reset password modal -->
		
		<div class="modal fade" id="resetmodal" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<form  id="form-reset">
					<div class="modal-header">
						<h5>Reset Password</h5>
					</div>
					<div class="modal-body">
						
						
							<div class="form-group">
								<label for="Password">Password</label>
								<input type="password" class="form-control input-style" id="password" name="new_password">
							</div>
							<div class="form-group">
								<label for="pwd">Confirm Password:</label>
								<input type="password" class="form-control input-style" id="confirmpassword" name="confirm_password">
							</div>
							<input type="hidden" id="resetcustomers_id" name="customers_id" value="">
							
						
						
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-primary" id="save_password">Submit</button>
						<button type="button" class="btn btn-danger" data-dismiss="modal" id="cancel_reset">Close</button>
					</div>
					</form>
				</div>
			</div>
		</div>
		
		<div class="wrapper">
			<!-- container closed -->
			</div>
			<div class="customer-wrap">
			<div class="navbar-wrap">
				<div class="container d-flex justify-content-between align-items-center p-0">
				<ul class="nav nav-pills" role="tablist">
					<li class="nav-item">
						<a class="nav-link active" id="customer-tab" data-toggle="pill" href="#customer" role="tab" aria-controls="Customer" aria-selected="true">Customer ID<div id="customer_id_text"></div></a>
					</li>
					<li class="nav-item">
						<a class="nav-link disabled" id="address-tab" data-toggle="pill" href="#address" role="tab" aria-controls="address" aria-selected="false">Addresses</a>
					</li>
					<li class="nav-item">
						<a class="nav-link disabled" id="payment-tab" data-toggle="pill" href="#payment" role="tab" aria-controls="payment" aria-selected="false">Payment</a>
					</li>
					
					<li class="nav-item">
						<a class="nav-link" id="cart-tab" data-toggle="pill" href="#cart" role="tab" aria-controls="cart" aria-selected="false">Cart</a>
					</li>
					<li class="nav-item ">
						<a class="nav-link disabled" id="newOrder-tab" data-toggle="pill" href="#newOrder" role="tab" aria-controls="newOrder" aria-selected="false">Order</a>
					</li>
					<!--li class="nav-item">
						<a class="nav-link disabled" id="Order-tab" data-toggle="pill" href="#Order" role="tab" aria-controls="Order" aria-selected="false">Order</a>
					</li-->
					<li class="nav-item">
						<a class="nav-link" id="orderHistory-tab" data-toggle="pill" href="#orderHistory" role="tab" aria-controls="orderHistory" aria-selected="false">Order History</a>
					</li>
				</ul>
				<div class="right-btns">
					<a href="JavaScript:void(0);"  class="btn btn-primary" id="reset_form">
					<i class="fa fa-refresh mr-2"></i>
					Clear Form
					</a>
					<a href="JavaScript:void(0);" class="btn btn-primary" id="insert_cusform">
					<i class="fa fa-plus mr-2"></i>
					Insert
					</a>
				</div>
				</div>
			</div>
      
        <div class="tab-content" id="pills-tabContent">
			<div class="lbs-wrap" style="display:none">
				<div class="lds-roller">
					<div></div>
					<div></div>
					<div></div>
					<div></div>
					<div></div>
					<div></div>
					<div></div>
					<div></div>
				</div>
			</div>
           <div class="tab-pane fade show active" id="customer" role="tabpanel" aria-labelledby="customer-tab">
            <div class="container">
              <div class="card-block">
                 <h5 class="form-title">Personal Info</h5>
                  <form action="" post="method" id="customer_detail">
                    <div class="row">
                      <div class="col">
                        <div class="form-group">
                           <label>First Name 
                              <sup><i class="fa fa-asterisk small text-danger"></i></sup>
                            </label>
                           <input type="text" class="issame form-control input-style" id="customers_firstname" name="customers_firstname" value="" maxlength="32" tabindex=1 />
                           <span class="error" style="display:none">Please Enter First Name</span>
                        </div>
                        <div class="form-group">
                           <label>Telephone Number
                              <sup><i class="fa fa-asterisk small text-danger"></i></sup>
                           </label>
                           <input type="tel" class="issame form-control input-style customers_telephone" id="customers_telephone" name="customers_telephone" value="" maxlength="15" tabindex=3/>
                           <span class="error" style="display:none">Please Enter Phone Number</span>
                        </div>
                        <div class="form-group">
                          <label>E-Mail Address
                              <sup><i class="fa fa-asterisk small text-danger"></i></sup>
                          </label>
                          <input type="email" class="issame form-control input-style" id="customers_email_address" name="customers_email_address" value="" maxlength="32" tabindex=5/>
                           <span class="error" style="display:none">Please Enter Email Address</span>
                        </div>
                      </div>
                      <div class="col">
                        <div class="form-group">
                           <label>Last Name
                              <sup><i class="fa fa-asterisk small text-danger"></i></sup>
                           </label>
                           <input type="text" class="issame form-control input-style" name="customers_lastname" id="customers_lastname" value="" maxlength="32" tabindex=2/>
                           <span class="error" style="display:none">Please Enter Last Name</span>
                        </div>
                        <div class="form-group">
                           <label>Fax Number</label>
                           <input type="tel" class="issame form-control input-style" id="customers_fax" name="customers_fax" value="" maxlength="15" tabindex=4 />
                        </div>
                      </div>
                    </div>
                    
                    <h5 class="form-title">Options</h5>
                    <div class="row">
                      <div class="col">
					   <div class="form-group">
                           <label for="customers_terms">Terms</label>
                           <select id="customers_terms" onchange="showSpecialterms(this)" class="issame form-control input-style custom-select" name="customers_terms" tabindex=7>
                              <?php echo $terms_options; ?>
                           </select>
                        </div>
                        <div class="form-group d-none sp_terms">
                          <label>Special Terms</label>
                          <input type="text" class="issame form-control input-style" name="customers_terms_special" value="" id="customers_terms_special" tabindex=6/>
                        </div>
						
                       
                        <div class="form-group">
                          <label>Shipping Notes</label>
                          <input type="text" class="issame form-control input-style" id="customers_special_shipping_notes" name="customers_special_shipping_notes" value="" tabindex=10 />
                        </div>
                        <div class="form-group">
                           <label for="inputState">Discount Group</label>
                           <select id="discount_grp" class="issame form-control input-style custom-select" name="customers_group_pricing"tabindex=11 id="customers_group_pricing">
                             <?php echo $group_pricing_options; ?>
                           </select>
                        </div>
                      </div>
                      <div class="col">
                        <div class="form-group">
                          <label>Resale Tax Id</label>
                          <input type="text" class="issame form-control input-style" name="customers_resale_tax_id" value="" id="customers_resale_tax_id" maxlength="9" tabindex=9/>
                        </div>
						 <div class="form-group rTaxdate">
                          <label>Resale Tax Id Date</label> 
                          <input type="text" id="customers_resale_tax_id_date" class="issame form-control input-style" name="customers_resale_tax_id_date" value="" tabindex=8 />
                        </div>
                       <div class="form-group">
                          <label>Order Notes</label> 
                          <input type="text" class="issame form-control input-style" name="customers_special_order_notes" value="" id="customers_special_order_notes" tabindex=11 />
                        </div>
                      </div>
                    </div>
                     <h5 class="form-title">Customer Other Information</h5>
                    <div class="row mb-3">
                      <div class="col">
                        <div class="custom-control custom-checkbox mr-sm-2">
                          <input type="checkbox" class="issame custom-control-input" name="customers_invoice_email"  id="invoice" value="1">
                          <label class="custom-control-label" for="invoice">E-Mail Invoice</label>
                        </div>
                        <div class="custom-control custom-checkbox mr-sm-2">
                          <input type="checkbox" class="issame custom-control-input" id="mail-invoice" name="customers_invoice_mail" value="1">
                          <label class="custom-control-label" for="mail-invoice">Mail Invoice</label>
                        </div>
                        <div class="custom-control custom-checkbox mr-sm-2">
                          <input type="checkbox" class="issame custom-control-input" id="fax-invoice" name="customers_invoice_fax" value="1">
                          <label class="custom-control-label" for="fax-invoice">Fax Invoice</label>
                        </div>
                        <div class="custom-control custom-checkbox mr-sm-2" id="blind_ship">
                          <input type="checkbox" class="issame custom-control-input" value="1" id="blind-ship" name="customers_blind_ship_enabled">
                          <label class="custom-control-label" for="blind-ship">Blind Ship</label>
                        </div>
                        <div class="custom-control custom-checkbox mr-sm-2" id="blind_by_default"  style="display:none">
                          <input type="checkbox" class="issame custom-control-input" id="by-default" name="customers_blind_ship_default" value="1">
                          <label class="custom-control-label" for="by-default">... by Default</label>
                        </div>
                      </div>
                      <div class="col">
                        <div class="custom-control custom-checkbox mr-sm-2">
                          <input type="checkbox" class="issame custom-control-input" id="wholesale" name="customer_wholesale" value="1">
                          <label class="custom-control-label" for="wholesale">Wholesale Customer</label>
                        </div>
                        <div class="custom-control custom-checkbox mr-sm-2">
                          <input type="checkbox" class="issame custom-control-input" id="store-pickup" value="1" name="customers_store_pickup_enabled">
                          <label class="custom-control-label" for="store-pickup">Store Pickup</label>
                        </div>
                        <div class="custom-control custom-checkbox mr-sm-2">
                          <input type="checkbox" class="issame custom-control-input" value="1" id="custom_ship_date" name="customers_custom_ship_date_enabled" >
                          <label class="custom-control-label" for="custom_ship_date">Custom Ship Date</label>
                        </div>
                        <div class="custom-control custom-checkbox mr-sm-2">
                          <input type="checkbox" class="issame custom-control-input" value="1" id="ship-collect" name="customers_ship_collect" onclick ="Check_ship_collect()">
                          <label class="custom-control-label" for="ship-collect">Can Ship Collect</label>
                        </div>
                      </div>
                    </div>
                    <div class="bg-gray p-3" id="fedex_account" style="display:none">
					   <div class="row form-group">
						   <div class="col">
							  <label>UPS Account  <sup><i class="fa fa-asterisk small text-danger"></i></sup></label>
							    <input type="text" class="issame form-control" name="customers_ups_acct" id="customers_ups_acct" value=""/>
							     <span class="error" style="display:none">Please Enter UPS/Fedex Account</span>
						   </div>
						   <div class="col">
							  <label>Fedex Account  <sup><i class="fa fa-asterisk small text-danger"></i></sup></label> 
							   <input type="text" class="issame form-control" name="customers_fedex_acct" value="" id="customers_fedex_acct" />
							    <span class="error" style="display:none">Please Enter Fedex Account</span>
						   </div>
					   </div>
                   </div>
                    <div class="row">
                       <div class="col-md-6">
                          <div class="form-group">
                            <label>LTL Capabilities</label>
                            <div id="ltl_capable">
								<input type="radio" name="customers_ltl_capable" id="ltl_0" class="issame" value="0"checked><label for="ltl_0" class="ltl">None</label>
								<input type="radio" name="customers_ltl_capable" class="issame" id="ltl_1" value="1"><label for="ltl_1" class="ltl">Commercial w/dock</label>
								<input type="radio" name="customers_ltl_capable" class="issame" id="ltl_2" value="2"><label for="ltl_2" class="ltl">Commercial NO dock</label>
							</div>
                          </div>
                       </div>
                    </div>
                     <input type="hidden" id="update_customerID" value="" name="customer_id">
                    <a href="JavaScript:void(0);" data-target="#resetmodal" data-toggle="modal" class="btn btn-primary disabled" id="reset_password">
                      <i class="fa fa-refresh"></i>
                      Reset Password
                    </a>
              </div>
              </form>
            </div><!-- container closed -->
           </div>
            <div class="tab-pane fade" id="address" role="tabpanel" aria-labelledby="address-tab">
              <div class="container">
                <div class="card-block">
				  <div class="d-between mb-3">
					<h5 class="form-title mb-0">Address Details</h5>
					<a href="javascript:void(0);" class="btn btn-primary btn-sm w-12" id="add_address">
						<i class="fa fa-plus"></i>
						Add Address
					</a>
					</div>
					
                  <form method="POST" id="address_data">
					
				<div class="address_detail"></div>
				 <div class="address_form" style="display:none">
                  <div class="form-group row">
                    <label for="name" class="col-lg-2 col-form-label">Name
                    <sup><i class="fa fa-asterisk small text-danger"></i></sup>
                    </label>
                    <div class="col-lg-5">
                      <input type="text" class="form-control input-style" id="first_name" name="firstname" size="33" maxlength="32"/>
					  <span class="error" style="display:none">Please Enter First Name</span>
                    </div>
                    <div class="col-lg-5">
                      <input type="text" class="form-control input-style" id="last_name" name="lastname" size="33" maxlength="32"/>
					  <span class="error" style="display:none">Please Enter Last Name</span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="company" class="col-lg-2 col-form-label">Company</label>
                    <div class="col-lg-10">
                      <input type="text" class="form-control input-style" id="Company" name="company" size="41" maxlength="64" />
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="address" class="col-lg-2 col-form-label">Address
                    <sup><i class="fa fa-asterisk small text-danger"></i></sup></label>
                    <div class="col-lg-10">
                      <input type="text" class="form-control input-style" id="customeraddress" name="street_address" size="41" maxlength="64" />
						<span class="error" style="display:none">Please Enter Address</span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="address2" class="col-lg-2 col-form-label">Address Line 2</label>
                    <div class="col-lg-10">
                      <input type="text" class="form-control input-style" id="address2" name="suburb" size="33" maxlength="32" />
                    </div>
                  </div>
                
				  <div class="form-group row">
                    <label for="country" class="col-lg-2 col-form-label">Country 
                    <sup><i class="fa fa-asterisk small text-danger"></i></sup></label>
                    <div class="col-lg-10">
                      <select id="country" class="form-control input-style custom-select" name="zone_country_id">
                       <?php echo $country_option; ?>
                      </select>
                      <span class="error" style="display:none">Please Select country</span>
                       <input type="hidden" name="ups_validated" value="0" id="ups_validated">
					   <input type="hidden" name="fedex_validated" value="0" id="fedex_validated">
					   <input type="hidden" name="ups_residential" value="0" id="ups_residential">
					   <input type="hidden" name="fedex_residential" value="0" id="fedex_residential">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="state" class="col-lg-2 col-form-label">State/Province 
                    <sup><i class="fa fa-asterisk small text-danger"></i></sup></label>
                    <div class="col-lg-10">
                      <input type="text" class="form-control input-style cstate" id="state" name="state" value="" size="33" maxlength="32" />
						<span class="error" style="display:none">Please Enter State/Province</span>
                    </div>
                  </div>
				    <div class="form-group row">
                    <label for="city" class="col-lg-2 col-form-label">City 
                    <sup><i class="fa fa-asterisk small text-danger"></i></sup></label>
                    <div class="col-lg-10">
                      <input type="text" class="form-control input-style" id="city" name="city" size="33" maxlength="32"/>
						<span class="error" style="display:none">Please Enter City</span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="zipcode" class="col-lg-2 col-form-label">Post/Zip Code 
                    <sup><i class="fa fa-asterisk small text-danger"></i></sup></label>
                    <div class="col-lg-10">
                      <input type="text" class="form-control input-style" id="zipcode" maxlength="10" name="zipcode" />
                      <span class="error" style="display:none">Please Enter Zipcode</span>
                    </div>
                  </div>
                  
                  <div class="custom-control custom-checkbox mr-sm-2 mb-3">
                    <input type="checkbox" class="custom-control-input" id="primary-address" name="primary" value="on">
                    <label class="custom-control-label" for="primary-address">Set as Primary Address</label>
                  </div>
                  <a href="JavaScript:void(0);" class="btn btn-primary save_address" id="save_customer_detail">
                    <i class="fa fa-check"></i>
                    Save
                  </a>
                  <a href="JavaScript:void(0);" class="btn btn-primary save_address" id="back_btn">
                    <i class="fa fa-arrow-left"></i>
                    Back
                  </a>
                </div>
                <input type="hidden" id="customer_id" value="" name="customer_id">
                <input type="hidden" id="contry_id_per" value="223" name="contry_id_per">
                </div>
                </form>
                
                <!-- update address form -->
                
                 <form method="POST" id="update_address" style="display:none">
					
				 <div class="updateaddress_form">
                  <div class="form-group row">
                    <label for="name" class="col-lg-2 col-form-label">Name
                    <sup><i class="fa fa-asterisk small text-danger"></i></sup>
                    </label>
                    <div class="col-lg-5">
                      <input type="text" class="form-control input-style" id="update_first_name" name="firstname" size="33" maxlength="32"/>
					  <span class="error" style="display:none">Please Enter First Name</span>
                    </div>
                    <div class="col-lg-5">
                      <input type="text" class="form-control input-style" id="update_last_name" name="lastname" size="33" maxlength="32"/>
					  <span class="error" style="display:none">Please Enter Last Name</span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="company" class="col-lg-2 col-form-label">Company</label>
                    <div class="col-lg-10">
                      <input type="text" class="form-control input-style" id="update_Company" name="company" size="41" maxlength="64" />
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="address" class="col-lg-2 col-form-label">Address
                    <sup><i class="fa fa-asterisk small text-danger"></i></sup></label>
                    <div class="col-lg-10">
                      <input type="text" class="form-control input-style" id="update_customeraddress" name="street_address" size="41" maxlength="64" />
						<span class="error" style="display:none">Please Enter Address</span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="address2" class="col-lg-2 col-form-label">Address Line 2</label>
                    <div class="col-lg-10">
                      <input type="text" class="form-control input-style" id="update_address2" name="suburb" size="33" maxlength="32" />
                    </div>
                  </div>
               
				     <div class="form-group row">
                    <label for="country" class="col-lg-2 col-form-label">Country 
                    <sup><i class="fa fa-asterisk small text-danger"></i></sup></label>
                    <div class="col-lg-10">
                      <select id="update_country" class="form-control input-style custom-select" name="zone_country_id">
                       <?php echo $country_option; ?>
                      </select>
                      <span class="error" style="display:none">Please Select country</span>
                       <input type="hidden" name="ups_validated" value="0" id="update_ups_validated">
					   <input type="hidden" name="fedex_validated" value="0" id="update_fedex_validated">
					   <input type="hidden" name="ups_residential" value="0" id="update_ups_residential">
					   <input type="hidden" name="fedex_residential" value="0" id="update_fedex_residential">
					   <input type="hidden" name="address_book_id" value="0" id="address_book_id">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="state" class="col-lg-2 col-form-label">State/Province 
                    <sup><i class="fa fa-asterisk small text-danger"></i></sup></label>
                    <div class="col-lg-10">
                      <input type="text" class="form-control input-style" id="update_state" name="state" value="" size="33" maxlength="32" />
						<span class="error" style="display:none">Please Enter State/Province</span>
                    </div>
                  </div>
				     <div class="form-group row">
                    <label for="city" class="col-lg-2 col-form-label">City 
                    <sup><i class="fa fa-asterisk small text-danger"></i></sup></label>
                    <div class="col-lg-10">
                      <input type="text" class="form-control input-style" id="update_city" name="city" size="33" maxlength="32"/>
						<span class="error" style="display:none">Please Enter City</span>
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="zipcode" class="col-lg-2 col-form-label">Post/Zip Code 
                    <sup><i class="fa fa-asterisk small text-danger"></i></sup></label>
                    <div class="col-lg-10">
                      <input type="text" class="form-control input-style" id="update_zipcode" maxlength="10" name="zipcode" />
                      <span class="error" style="display:none">Please Enter Zipcode</span>
                    </div>
                  </div>
               
                  <div class="custom-control custom-checkbox mr-sm-2 mb-3">
                    <input type="checkbox" class="custom-control-input" id="update_primary-address" name="primary" value="on">
                    <label class="custom-control-label" for="update_primary-address">Set as Primary Address</label>
                  </div>
                  <a href="JavaScript:void(0);" class="btn btn-primary update_address" id="Update_address_detail">
                    <i class="fa fa-check"></i>
                    Update
                  </a>
                   <a href="JavaScript:void(0);" class="btn btn-primary save_address" id="updateback_btn">
                    <i class="fa fa-arrow-left"></i>
                    Back
                  </a>
                </div>
                <input type="hidden" id="update_customer_id" value="" name="customer_id">
                </div>
                </form>
                
              </div>
              <div class="tab-pane fade" id="payment" role="tabpanel" aria-labelledby="Payment-tab">
				<div class="container">
					<div class="form-group row mt-3">
						<div class="d-between mb-3">
							<h5 class="form-title mb-0">Payment Details</h5>
						</div>
					</div>
					<div class="row">
						<div class="col-md-2"></div>
						<div class="col-md-8" style="display:none">
							<div class="card-header d-flex justify-content-between align-items-center">
								<span>
									<i class="fa fa-table"></i>
									<h5>Customer Profile</h5> 
								</span>
							</div>
							<div style="display: flex;align-items: center;position: absolute;right: 20px;">
								<a href="javascript:void(0)" class="btn btn-info" data-toggle="modal" data-target="#add_user_modal">
									Add New Customer Profile
								</a>
							</div>
						</div>
					</div>
					
					<!-- Add User Modal -->
					<div class="modal fade" id="add_user_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
						<div class="modal-dialog modal-dialog-centered" role="document">
							<div class="modal-content">
								<ul class="errors"></ul>
								<div class="modal-header">					  
									<h5 class="modal-title" id="exampleModalLongTitle">Add New Customers</h5>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
									</button>
								</div>
								<div class="modal-body">
									<form method="POST" id="add_user_form">
									<div class="form-group">
										<label for="user_email" class="col-form-label">Email</label>
										<input type="text" class="form-control" id="email" name="email">
									</div>		  
									</form>
								</div>
								<div class="modal-footer">
									<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
									<button type="button" class="btn btn-primary" id="add_cutomer_profile">Save</button>
								</div>
							</div>
						</div>
					</div>
					
					<div class="col-md-2"></div>
					<!--<div style="margin-left: 10%; display:none" class="loader"></div>-->
				<div class="getdata"></div>
					<input type="hidden" id="customer_profile_id" value="">
				</div>
			</div>
			 <div class="tab-pane fade mt-3" id="cart" role="tabpanel" aria-labelledby="cart-tab">
             <div class="container">
				 <div style="margin-left: 10%; display:none" class=""><img src="https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif"></div>
				  <div id="cart-table"></div>
			 </div>
           </div>
           <div class="tab-pane fade mt-3" id="newOrder" role="tabpanel" aria-labelledby="newOrder-tab">
             <div class="containerj">
				<div id="newOrder_cartable">
					Order Detail
				</div>
             </div>
           </div>
           <div class="tab-pane fade" id="Order" role="tabpanel" aria-labelledby="Order-tab">
             <div class="container">
				<div class="col-md-12 bg-light p-3 border w-100 d-table br-radi">
					<div class="row row-equal-height">
						<!--div class="col-md-12">
							<div class="step-title b-title">Shipping Method:</div>
							<div id="checkoutShippingContentChoose" class=" font-weight-normal mb-3">
								Please select the preferred shipping method to use on this order.
							</div>
						</div>
						<div class="col-lg-12 shipping_method d-md-flex">
							<div class="col-md-4">
								<input id="ship_collect_check_back" type="checkbox" name="ship_collect_check_back" value="1">	<span class="pt-2">Ship on Your Account ?</span>
							</div>
							<div class="col-md-4"><span class="ship_collect_info"><input style="position:absolute;margin: 0px !important;visibility:hidden !important;max-height: 0px !important;min-height: 0px !important;" type="checkbox" id="fedexwebservices_ship_collect_check" name="fedexwebservices_ship_collect_check" value="1">  <input type="text" placeholder="FedEx account number" name="fedexwebservices_ship_collect" id="fedexwebservices_ship_collect" value="12345"> </span>
						</div>
						<div class="col-md-4"><span class="ship_collect_info"><input style="position:absolute;margin: 0px !important;visibility:hidden !important;max-height: 0px !important;min-height: 0px !important;" type="checkbox" id="upsxml_ship_collect_check" name="upsxml_ship_collect_check" value="1">  <input type="text" placeholder="UPS account number" name="upsxml_ship_collect" id="upsxml_ship_collect" value=""> </span>
						</div-->
						
						<div class="col-lg-12 orderData">
						
						</div>
					</div>
				</div>
			</div>
			
             </div>
			 <div class="tab-pane fade" id="orderHistory" role="tabpanel" aria-labelledby="orderHistory-tab">
             <div class="container order_data">


             </div>
           </div>
           </div>
            </div>
        </div>
        
<!-- Modal Discount -->
<div id="discountModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Apply Discount</h4>
      </div>
      <div class="modal-body">
		<div class="row">
			<div class="col-md-12">
			<select class="form-control" id="discount_type">
				<option value="0">Select Discount</option>
				<option value="Order Discount">Order Discount</option>
				<option value="Group Discount">Group Discount</option>
			</select>
			</div>
			<div class="col-md-12">
				<input type="text" id="discount_amount" class="form-control border" placeholder="Discount Amount"/>
				<input type="text" id="discount_percent" placeholder="Discount Percentage" class="form-control border"/>
				<input type="hidden" id="split_ware"/>
				<input type="button" class="btn btn-success mt-2" id="add_discount" value="Add Discount" onclick="addDiscount()"/>
			</div>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- Modal Tax -->
<div id="taxModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Apply Tax</h4>
      </div>
      <div class="modal-body">
		<div class="row">
			<div class="col-md-12">
				<input type="text" id="tax_amount" class="form-control border" placeholder="Tax Amount"/>
				<input type="text" id="tax_percent" placeholder="Tax Percentage" class="form-control border"/>
				<input type="hidden" id="split_tax_ware"/>
				<input type="button" class="btn btn-success mt-2" id="add_tax" value="Add Tax" onclick="addTax()"/>
			</div>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- Coupon Tax -->
<div id="couponModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Apply Coupon</h4>
      </div>
      <div class="modal-body">
		<div class="row">
			<div class="col-md-12">
				<input type="text" id="coupon_code" class="form-control border" placeholder="Coupon Code"/>
				<input type="hidden" id="split_ware_coupon"/>
				<input type="button" class="btn btn-success mt-2" id="add_coupon" value="Apply Coupon" onclick="addCoupon()"/>
			</div>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- Product Status Modal -->
<div id="statusModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Status</h4>
      </div>
      <div class="modal-body">
		<div class="row">
			<div class="col-md-12 pproductStat">
				
			</div>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- Shipping Modal -->
<div id="shppingModal" class="modal fade" >
  <div class="modal-dialog modal-ship">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Shipping</h4>
      </div>
      <div class="modal-body">
		<div class="row">
			<div class="col-md-12 ordershipping"></div>
		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


      </div><!-- Customer wrap closed -->
   </div><!-- wrapper closed -->
   
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script src="assets/js/sweetalert.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="assets/js/jquery.caret.js"></script>
<script src="assets/js/jquery.mobilePhoneNumber.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js" defer ></script>
<link href = "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel = "stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" rel="stylesheet"/>
<link href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet"/>
<script src="payment/contentx/popper.min.js"></script>
<script src="https://jstest.authorize.net/v1/Accept.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>

  
</body>
   </html>
