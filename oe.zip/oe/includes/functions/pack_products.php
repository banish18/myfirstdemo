<?php
//BEGIN FUNCTIONS
// Determines container size to be used based on volume provided. If too large, it splits volume in 2, 3, 4.. until it 
// finds a container size that fits the volume. Returns container $key.
// Return total number of items
function item_count($items_left_to_pack, $item) {
	$count=0;
	foreach ($items_left_to_pack as $item_array) {
		if ($item_array[0]==$item) $count++;
	}
	return $count;
}

// Return total volume of items
function total_item_volume($items_with_vol_key) { 
	$volume=0;
	foreach ($items_with_vol_key as $item) {
		$volume += $item['vol'];
	}
	return $volume;
}

// Try to select box by fitting volume into single box starting with smallest box. If not increment boxes and try again.
function select_container($total_item_vol, $boxes=1) { 
	global $container;
	foreach (array_keys($container) as $key) {
//		echo "$boxes : $total_item_vol : $key : {$container[$key]['vol']}<BR>";
		if ($container[$key]['vol'] > $total_item_vol) 
			return array($key, $boxes);
	}
	$boxes++; //Increment boxes
	$total_item_vol=$total_item_vol/$boxes*($boxes-1); // Divide volume by new boxes
	return select_container($total_item_vol, $boxes); //Check to see if this volume fits into a box	
}

// Start with a volume. If something is packed in that volume, the volume converts to 4 volumes: 1 filled, 3 empty
// Loop trying to fit largest items into smallest volumes
// Input selected $container, Pack with $to_pack until filled. Test all items
// Return $packed and remaining $to_pack
function pack_ribbon($container, $to_pack) {
	$rect=array(); //Rectangular prism array
	$packed = array(); // Items that been placed in container
	list($LL, $WW, $HH) = LWH($container, false);
	
	$rect[] = array('length'=>$LL, 'width'=>$WW, 'height'=>$HH, 'vol' => $LL * $WW * $HH , 'x' => 0, 'y' => 0, 'z' => 0); //First rectangular prism is the box
	$packed['VOL'] = $rect[0]['vol']; // Box volume
	//$packed['weight'] = $container['weight']; // Box weight
	$packed['weight'] = ''; // Box weight
	$packed['vol']=0; //Packed volume
//	echo '===============================<br>';
	foreach ($to_pack as $key =>$item) {
		foreach ($rect as $key1 =>$rect_space) {
			list($LL, $WW, $HH, $XX, $YY, $ZZ) = LWH($rect_space);
			list($l, $w, $h) = LWH($item);
			if ($LL >= $l && $WW >= $w && $HH >= $h) { //Fits
				$packed[]= array_merge($item, array('x' => $XX, 'y' => $YY, 'z' => $ZZ, 'rotated' => 0)); // Pack it
				unset ($to_pack[$key]);
				unset ($rect[$key1]);
				if (($l * $WW * ($HH-$h)) <> 0 ) //Must have all three dimensions to set a rectangular prism
					$rect[] = array('length'=>$l, 'width'=>$WW, 'height'=>$HH-$h, 'vol' => $l * $WW * ($HH-$h), 'x' => $XX, 'y' => $YY, 'z' => $ZZ+$h);
				if (($l * ($WW-$w) * $h) <> 0 )
					$rect[] = array('length'=>$l, 'width'=>$WW-$w, 'height'=>$h, 'vol' => $l * ($WW-$w) * $h, 'x' => $XX, 'y' => $YY+$w, 'z' => $ZZ);
				if ((($LL-$l) * $WW * $HH) <> 0 )
					$rect[] = array('length'=>$LL-$l, 'width'=>$WW, 'height'=>$HH, 'vol' => ($LL-$l) * $WW * $HH, 'x' => $XX+$l, 'y' => $YY, 'z' => $ZZ);
				//Try saving other rectangles form Y, Z slicing. Then merge
				$packed['vol']+=$l*$w*$h;
				$packed['weight']+=$item['weight'];
				$fail=0; //Success
				break; // Dont test any more. Exit loop and try next item in remaining rectangular prisms
			}
			else if ($LL >= $w && $WW >= $l && $HH >= $h) { // Fits rotated 90 degrees l is w and w is l
				$packed[]= array_merge($item, array('x' => $XX, 'y' => $YY, 'z' => $ZZ, 'rotated' => 1)); // Pack it
				unset ($to_pack[$key]);
				unset ($rect[$key1]);
				if (($w * $WW * ($HH-$h)) <> 0 )
					$rect[] = array('length'=>$w, 'width'=>$WW, 'height'=>$HH-$h, 'vol' => $w * $WW * ($HH-$h), 'x' => $XX, 'y' => $YY, 'z' => $ZZ+$h);
				if (($w * ($WW-$l) * $h) <> 0 )
					$rect[] = array('length'=>$w, 'width'=>$WW-$l, 'height'=>$h, 'vol' => $w * ($WW-$l) * $h, 'x' => $XX, 'y' => $YY+$l, 'z' => $ZZ);
				if ((($LL-$w) * $WW * $HH) <> 0 )
					$rect[] = array('length'=>$LL-$w, 'width'=>$WW, 'height'=>$HH, 'vol' => ($LL-$w) * $WW * $HH, 'x' => $XX+$w, 'y' => $YY, 'z' => $ZZ);
				$packed['vol']+=$l*$w*$h;
				$packed['weight']+=$item['weight'];
				$fail=0;
				break;
			} 
		}
		$rect = sortArrayByField( $rect, 'vol' , false); // Sort by smallest volume rectangular prism
	}
	/*echo "<pre>";print_r($to_pack);*/
	return array($packed, $to_pack);
}

function pop_whitetray($trays) {
	global $whitetray, $whitetray_count;
	$whitetray_count-=$trays;
	$whitetray[$trays]['value']--;
	$sku=$whitetray[$trays][$whitetray[$trays]['value']]['sku'];
	$weight=$whitetray[$trays][$whitetray[$trays]['value']]['weight']*$trays;
	unset($whitetray[$trays][$whitetray[$trays]['value']]);
	return array($sku, $weight);
}
function pop_browntray($trays) {
	global $browntray, $browntray_count;
	$browntray_count-=$trays;
	$browntray[$trays]['value']--;
	$sku=$browntray[$trays][$browntray[$trays]['value']]['sku'];
	$weight=$browntray[$trays][$browntray[$trays]['value']]['weight']*$trays;
	unset($browntray[$trays][$browntray[$trays]['value']]);
	return array($sku, $weight);
}
function push_whitetray($trays, $sku, $weight) {
	global $whitetray, $whitetray_count;
	$whitetray[$trays][$whitetray[$trays]['value']] = array ('sku' => $sku,'weight' => $weight);
	$whitetray[$trays]['value']++;
	$whitetray_count+=$trays;
}
function push_browntray($trays, $sku, $weight) {
	global $browntray, $browntray_count;
	$browntray[$trays][$browntray[$trays]['value']] = array ('sku' => $sku,'weight' => $weight);
	$browntray[$trays]['value']++;
	$browntray_count+=$trays;
}
function LWH($data,$outer = true) {
	if ($outer) {
		if (isset($data['x']))
			return array($data['length'], $data['width'], $data['height'], $data['x'], $data['y'], $data['z']);
		else
			return array($data['length'], $data['width'], $data['height']);
	}
	else {
			return array($data['innerL'], $data['innerW'], $data['innerH']);
	}
}
function pack_it($box_id, $length, $width, $height, $weight, $contents) {
	global $packed, $box_num;
	$packed[]= array (
		'box_num' => $box_num++,
		'box_id' => $box_id,
		'length' => $length,
		'width' => $width,
		'height' => $height,
		'weight' => $weight,
		'contents' => $contents);	
}

function sortArrayByField ( $original, $field, $descending = false ) {
	if (count($original) <=1) return $original;
//	echo '<pre>';
//	if (count($original) <=1) var_dump($original);
//	echo '</pre>';
	$sortArr = array();
	foreach ( $original as $key => $value ) {
		$sortArr[ $key ] = $value[ $field ];
	}
 	if ( $descending ) {
		arsort( $sortArr );
	}
	else {
		asort( $sortArr );
	}
	$resultArr = array();
	foreach ( $sortArr as $key => $value ) {
		$resultArr[ $key ] = $original[ $key ];
	}
	return $resultArr;
}

function csv_to_array($filename='', $delimiter=',') {
	if(!file_exists($filename) || !is_readable($filename))
		return FALSE;
	$header = NULL;
	$data = array();
	if (($handle = fopen($filename, 'r')) !== FALSE) {
		while (($row = fgetcsv($handle, 1000, $delimiter)) !== FALSE) {
			if(!$header) $header = $row;
			else $data[] = array_combine($header, $row);
		}
		fclose($handle);
	}
	return $data;
}

function packProducts($pack_this) {
	
	ini_set( "display_errors", 0);
	
	$start = microtime(true); //******
	global $packed, $box_num, $whitetray, $whitetray_count, $browntray, $browntray_count, $container, $ejs_debug;
	$packed='';
	
	$whitetray['1']['value'] = $whitetray['2']['value'] = $whitetray['3']['value'] = $whitetray['4']['value'] = $whitetray['5']['value'] = 0;
	$browntray['1']['value'] = $browntray['2']['value'] = $browntray['3']['value'] = 0;
	$SR100sm = $SR100lg = array();
	$whitetray_count=$browntray_count=0;
//	echo '<pre>';
global $zendb;
	//Load boxes from DB
	$query = "SELECT b.sku, b.innerL, b.innerW, b.innerH, b.weightMax, b.outerL, b.outerW, b.outerH,b.numOnPallet, p.products_weight as weight, b.active
		FROM boxes b
		LEFT JOIN products p on p.products_model=b.sku";
		$query_result = mysqli_query($zendb, $query);
		while ($result = mysqli_fetch_array($query_result)) {
			$boxes[$result['sku']]= array( 'length' => $result['outerL'], 'width' => $result['outerW'], 'height' => $result['outerH'], 'weight' => $result['weight'], 'innerL' => $result['innerL'], 'innerW' => $result['innerW'], 'innerH' => $result['innerH'], 'weightMax' => $result['weightMax']);
			if ($result['active']==1)
			{
				$container[$result['sku']] = array( 'length' => $result['outerL'], 'width' => $result['outerW'], 'height' => $result['outerH'], 'weight' => $result['weight'], 'innerL' => $result['innerL'], 'innerW' => $result['innerW'], 'innerH' => $result['innerH'], 'weightMax' => $result['weightMax'], 'vol' => $result['outerL'] * $result['outerW'] * $result['outerH']);
			}
		}
	//Start packing based on pack_type: 1:Already packed for shipping, 2:Use box pack algorithm, 3:Use special bow pack algorithm
	$box_num=0;
	foreach ($pack_this as $key =>$product) {
		$sku = $product['sku'] . ':' . $product['sku_old'];
		if ($product['pack_type']==1) { //Prepacked for shipping
			
			for ($i = 0; $i < $product['quantity']; $i++) { //explode quantities and pack in array
				pack_it('0000-000', $product['pack_length'], $product['pack_width'], $product['pack_height'], $product['weight'], array ('quantity' => 1, 'sku' => $sku));
			}			
			unset($pack_this[$key]); //Packed, remove from packing task
		}
		else if ($product['pack_type']==2) { // Pack in generic box pack algorithm based on sizes
			for ($i = 0; $i < $product['quantity']; $i++) { //explode quantities and pack in array
//				$packer->addItem(new TestItem($sku, $product['pack_width'], $product['pack_length'], $product['pack_height'], $product['weight']));
//				$items_1P->insert(new TestItem($sku, $product['pack_width'], $product['pack_length'], $product['pack_height'], $product['weight']));
				$items_to_pack[]= array($sku, 'length' => $product['pack_length'], 'width' => $product['pack_width'], 'height' => $product['pack_height'], 'weight' => $product['weight'], 'vol' => $product['pack_length'] * $product['pack_width'] * $product['pack_height']);

			}
			unset($pack_this[$key]); //Moved to generic box packing task, remove from packing task
		}
		else if ($product['pack_length']==24 && $product['pack_width']==22 && $product['pack_height']==4 && $product['pack_type']==3) { //White tray
			if ($product['quantity'] >= 6) {
				$items_in_boxes = floor($product['quantity']/6);
				if ($items_in_boxes*6<>$product['quantity']) {
					push_whitetray($product['quantity']-($items_in_boxes*6), $sku, $product['weight']); // Save onto brown tray stack
				}
				for ($i = 0; $i < $items_in_boxes; $i++) { //explode quantities and pack in array
					$pack_in='1000-010';
					pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $product['weight']*6 + $boxes[$pack_in]['weight'], array ('quantity' => 6, 'sku' => $sku));
				}
			}
			else {
				push_whitetray($product['quantity'], $sku, $product['weight']); // Save onto brown tray stack
			}
			unset($pack_this[$key]); //Remove from packing task
		}
		else if ($product['pack_length']==24 && $product['pack_width']==22 && $product['pack_height']==6 && $product['pack_type']==3) { //Brown tray
			if ($product['quantity'] >= 4) {
				$items_in_boxes = floor($product['quantity']/4);
				if ($items_in_boxes*4<>$product['quantity']) {
					push_browntray($product['quantity']-($items_in_boxes*4), $sku, $product['weight']); // Save onto brown tray stack
				}
				for ($i = 0; $i < $items_in_boxes; $i++) { //explode quantities and pack in array
					$pack_in='1000-010';
					pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $product['weight']*4 + $boxes[$pack_in]['weight'], array ('quantity' => 4, 'sku' => $sku));
				}
			}
			else {
				push_browntray($product['quantity'], $sku, $product['weight']); // Save onto brown tray stack
			}
			unset($pack_this[$key]); //Remove from packing task
		}
		else if ($product['pack_length']==14 && $product['pack_width']==14 && $product['pack_height']==9 && $product['pack_type']==3) { //Small car bows
			if ($product['quantity'] >= 2) {
				$items_in_boxes = floor($product['quantity']/2);
				if ($items_in_boxes*2<>$product['quantity'])
					$SR100sm[] = array (
						'sku' => $sku,
						'length' => $product['pack_length'],
						'width' => $product['pack_width'],
						'height' => $product['pack_height'],
						'weight' => $product['weight'],
						'quantity' => $pack_this[$key]['quantity']-$items_in_boxes*2);	
				for ($i = 0; $i < $items_in_boxes; $i++) { //explode quantities and pack in array
					$pack_in='1000-001';
					pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $product['weight']*2 + $boxes[$pack_in]['weight'], array ('quantity' => 2, 'sku' => $sku));
				}
			}
			else {
				$SR100sm[] = array (
					'sku' => $sku,
					'length' => $product['pack_length'],
					'width' => $product['pack_width'],
					'height' => $product['pack_height'],
					'weight' => $product['weight'],
					'quantity' => $pack_this[$key]['quantity']);	
			}
			unset($pack_this[$key]); //Remove from packing task
		}
		else if ($product['pack_length']==16 && $product['pack_width']==16 && $product['pack_height']==10 && $product['pack_type']==3) { //Large car bows
			if ($product['quantity'] >= 2) {
				$items_in_boxes = floor($product['quantity']/2);
				if ($items_in_boxes*2<>$product['quantity'])
					$SR100lg[] = array (
						'sku' => $sku,
						'length' => $product['pack_length'],
						'width' => $product['pack_width'],
						'height' => $product['pack_height'],
						'weight' => $product['weight'],
						'quantity' => $pack_this[$key]['quantity']-$items_in_boxes*2);	
				for ($i = 0; $i < $items_in_boxes; $i++) { //explode quantities and pack in array
					$pack_in='1000-001';
					pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $product['weight']*2 + $boxes[$pack_in]['weight'], array ('quantity' => 2, 'sku' => $sku));
				}
			}
			else {
				$SR100lg[] = array (
					'sku' => $sku,
					'length' => $product['pack_length'],
					'width' => $product['pack_width'],
					'height' => $product['pack_height'],
					'weight' => $product['weight'],
					'quantity' => $pack_this[$key]['quantity']);	
			}
			unset($pack_this[$key]); //Remove from packing task
		}
		else { //Moved to generic box packing task, remove from packing task
			/*for ($i = 0; $i < $product['quantity']; $i++) { //explode quantities and pack in array
				$packer->addItem(new TestItem($sku , $product['pack_length'], $product['pack_width'], $product['pack_height'], $product['weight']));
				$items->insert(new TestItem($sku , $product['pack_length'], $product['pack_width'], $product['pack_height'], $product['weight']));
			}*/
			unset($pack_this[$key]); 
		}
	}
	
	//Pack car bows
	if (count($SR100sm) == 1) {
		$pack_in='1000-002';
		pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $SR100sm[0]['weight'] + $boxes[$pack_in]['weight'], array ('quantity' => 1, 'sku' => $sku));
	}
	else {
		unset($content);
		$weight=$i=0;
		foreach ($SR100sm as $SR100sm_item) {
			$content[] =  array ('quantity' => 1, 'sku' => $SR100sm_item['sku']);
			$weight+=$SR100sm_item['weight'];
			if ($i==0) $i++;
			else {
				$pack_in='1000-001';
				pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
				unset($content);
				$weight=$i=0;
			}
		}
		if (isset($content)) {
			$pack_in='1000-002';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
	}
	if (count($SR100lg) == 1) {
		$pack_in='1000-569';
		pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $SR100lg[0]['weight'] + $boxes[$pack_in]['weight'], array ('quantity' => 1, 'sku' => $sku));
	}
	else {
		unset($content);
		$weight=$i=0;
		foreach ($SR100lg as $SR100lg_item) {
			$content[] =  array ('quantity' => 1, 'sku' => $SR100lg_item['sku']);
			$weight+=$SR100lg_item['weight'];
			if ($i==0) $i++;
			else {
				$pack_in='1000-004';
				pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
				unset($content);
				$weight=$i=0;
			}
		}
		if (isset($content)) {
			$pack_in='1000-569';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
	}
	if (count($items_to_pack)<>0 && $items_to_pack<>'') {
		$items_to_pack = sortArrayByField ( $items_to_pack, 'vol', true ); // Sort items by volume, descending order
		$total_item_vol = total_item_volume($items_to_pack);
		// Will *ALL* ribbon fit in 1-tray. If so, add a white tray of ribbon, else pack separately.
		// Check to see if it fits in 50% to 100% of single white tray volume. Otherwise pack in smaller/larger box
		$fit_in_white_tray=false;
		if (($container['1000-005']['vol'] > $total_item_vol) && ($container['1000-005']['vol']*.50 < $total_item_vol)) { // Volume says it might
			list($packed_container, $items_left_to_pack)=pack_ribbon($container['1000-005'], $items_to_pack); //Try it
			if (count($items_left_to_pack)==0 ) { // Fits in the white tray 
				$items_to_pack_str=implode(', ', array_map(function ($entry) {return $entry['0'];}, array_slice($packed_container, 3)));
				push_whitetray(1, $items_to_pack_str, $packed_container['weight']); // Save 1 trays
				$fit_in_white_tray=true;
			}
		}
		if (!$fit_in_white_tray) { //Didn't fit. Pack in other boxes
			$items_left_to_pack = $items_to_pack;  // Reset items left
			$error_factor = 0.0; // Use this error factor when checking item volume against box volume
			$min_vol_used = 0.8; //Try next largest box if utilization is less than rate
			$container = sortArrayByField ( $container, 'vol', false); // Sort boxes by volume, ascending order for selecting box
			$container_keys = array_keys($container); // Get container keys so we can move up box sizes incrementally if necessary
			list($selected_container, $no_of_boxes) = select_container($total_item_vol*(1+$error_factor)); //Find box that fits
			$box_pass=1;
			
			/*echo "<pre>";print_r($items_left_to_pack);
			
			echo count($items_left_to_pack);*/
			
			/*die;*/
			
			while (count($items_left_to_pack)<>0) { if($box_pass>1000)break; //Now pack it until nothing is left
				$keys = array_keys($items_left_to_pack);// Get keys of items 
				$first_item_before_packing = $items_left_to_pack[$keys[0]][0]; //This is the 1st item
				$first_item_before_packing_qty = item_count($items_left_to_pack, $first_item_before_packing); // Qty of 1st item
				list($packed_container, $items_left_to_pack)=pack_ribbon($container[$selected_container], $items_left_to_pack); // Pack the selected container
				$keys = array_keys($items_left_to_pack); // Get keys of items after packing
				$first_item_after_packing = $items_left_to_pack[$keys[0]][0]; //This is the first item after packing
				$first_item_after_packing_qty = item_count($items_left_to_pack, $first_item_after_packing); // Qty of 1st item after packing
				if (($first_item_before_packing==$first_item_after_packing && $first_item_before_packing_qty==$first_item_after_packing_qty) || ($packed_container['vol']/$packed_container['VOL'] < $min_vol_used  && $box_pass<3)) { 
				
				// 1st item did not pack or box not utili. 
//					echo $selected_container . '-' . $first_item_before_packing_qty . ':' . $first_item_after_packing_qty . '<br>';
					$selected_container = $container_keys[array_search($selected_container, $container_keys)+1]; // Select next sized box
					$items_left_to_pack = $items_to_pack; //Reset items left
					$box_pass++;
					
				}
				else {  //What ever fit in that box will now be packed
				
					list($LL, $WW, $HH) = LWH($container[$selected_container], false);
					$i=0;
					unset($content); // Clear content variable so we can append into packed container
					while (isset($packed_container[$i])) {
						$content[] = array ('quantity' => 1, 'sku' => $packed_container[$i][0]);
						$i++;
					}
					$content = sortArrayByField ( $content, 'sku'); // Sort items by sku
					$old_content= array ('quantity' => 0, 'sku' => '', 'key' => '');
					foreach ($content as $key =>$current_content) { // Implode SKUs
						if ($current_content['sku'] == $old_content['sku'] ) {
							$content[$key]['quantity']+=$content[$old_content['key']]['quantity'];
							unset($content[$old_content['key']]);
						}
						$old_content= array ('quantity' => $current_content['quantity'], 'sku' => $current_content['sku'], 'key' => $key);
					}
					pack_it($selected_container, $LL, $WW, $HH, $packed_container['weight'], $content);
					$items_to_pack = $items_left_to_pack;
					//Reselect box based on remaining items
					$total_item_vol = total_item_volume($items_left_to_pack);
					list($selected_container, $no_of_boxes) = select_container($total_item_vol*(1+$error_factor)); //Find box that fits
					$box_pass=1;
//					echo 'PACKED: Box Volume:' . number_format($packed_container['VOL'],0) . ', Volume Used:' . number_format($packed_container['vol'],0) . ', Remainder (' . number_format(($packed_container['VOL']-$packed_container['vol'])/$packed_container['VOL']*100,0) . '%): ' . number_format($packed_container['VOL']-$packed_container['vol'],0) . ", Weight: {$packed_container['weight']} lbs <br>";
				}
			}
		}
	}
    
	//Pack white trays into 6-packs. Match compatible amounts, 5/1, 4/2, etc.
	while ($whitetray_count>=6) {
		unset($content);
		$weight=0;
		if ($whitetray[5]['value']>=1 && $whitetray[1]['value']>=1 ) {
			list($sku, $weight) = pop_whitetray(5);
			$content[] =  array ('quantity' => 5, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
		}
		else if ($whitetray[4]['value']>=1 && $whitetray[2]['value']>=1 ) {
			list($sku, $weight) = pop_whitetray(4);
			$content[] =  array ('quantity' => 4, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			$weight+=$weight1;
		}
		else if ($whitetray[4]['value']>=1 && $whitetray[1]['value']>=2 ) {
			list($sku, $weight) = pop_whitetray(4);
			$content[] =  array ('quantity' => 4, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
			list($sku, $weight1) = pop_whitetray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
		}
		else if ($whitetray[3]['value']>=2 ) {
			list($sku, $weight) = pop_whitetray(3);
			$content[] =  array ('quantity' => 3, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(3);
			$content[] =  array ('quantity' => 3, 'sku' => $sku);
			$weight+=$weight1;
		}
		else if ($whitetray[3]['value']>=1 && $whitetray[2]['value']>=1 && $whitetray[1]['value']>=1 ) {
			list($sku, $weight) = pop_whitetray(3);
			$content[] =  array ('quantity' => 3, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			$weight+=$weight1;
			list($sku, $weight1) = pop_whitetray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
		}
		else if ($whitetray[3]['value']>=1 && $whitetray[1]['value']>=3 ) {
			list($sku, $weight) = pop_whitetray(3);
			$content[] =  array ('quantity' => 3, 'sku' => $sku);
			for ($i = 0; $i < 3; $i++) {
				list($sku, $weight1) = pop_whitetray(1);
				$content[] =  array ('quantity' => 1, 'sku' => $sku);
				$weight+=$weight1;
			}
		}
		else if ($whitetray[2]['value']>=3 ) {
			for ($i = 0; $i < 3; $i++) {
				list($sku, $weight1) = pop_whitetray(2);
				$content[] =  array ('quantity' => 2, 'sku' => $sku);
				$weight+=$weight1;
			}
		}
		else if ($whitetray[2]['value']>=2 && $whitetray[1]['value']>=2 ) {
			for ($i = 0; $i < 2; $i++) {
				list($sku, $weight1) = pop_whitetray(2);
				$content[] =  array ('quantity' => 2, 'sku' => $sku);
				$weight+=$weight1;
			}
			for ($i = 0; $i < 2; $i++) {
				list($sku, $weight1) = pop_whitetray(1);
				$content[] =  array ('quantity' => 1, 'sku' => $sku);
				$weight+=$weight1;
			}
		}
		else if ($whitetray[2]['value']>=1 && $whitetray[1]['value']>=4 ) {
			list($sku, $weight) = pop_whitetray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			for ($i = 0; $i < 4; $i++) {
				list($sku, $weight1) = pop_whitetray(1);
				$content[] =  array ('quantity' => 1, 'sku' => $sku);
				$weight+=$weight1;
			}
		}
		else if ($whitetray[1]['value']>=6 ) {
			for ($i = 0; $i < 6; $i++) {
				list($sku, $weight1) = pop_whitetray(1);
				$content[] =  array ('quantity' => 1, 'sku' => $sku);
				$weight+=$weight1;
			}
		}
		else if ($whitetray[5]['value']>=1 && $whitetray[2]['value']>=1 ) { //Split 2 trays into 2 x 1 trays
			list($sku, $weight) = pop_whitetray(5);
			$content[] =  array ('quantity' => 5, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(2);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1/2;
			push_whitetray(1, $sku, $weight1/2); // Save 1 tray
		}
		else if ($whitetray[5]['value']>=1 && $whitetray[3]['value']>=1 ) { //Split 3 trays into 2 tray and 1 tray
			list($sku, $weight) = pop_whitetray(5);
			$content[] =  array ('quantity' => 5, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(3);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1/3;
			push_whitetray(2, $sku, $weight1/3); // Save 2 trays
		}
		else if ($whitetray[5]['value']>=1 && $whitetray[4]['value']>=1 ) { //Split 4 trays into 3 tray and 1 tray
			list($sku, $weight) = pop_whitetray(5);
			$content[] =  array ('quantity' => 5, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(4);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1/4;
			push_whitetray(3, $sku, $weight1/4); // Save 3 trays
		}
		else if ($whitetray[5]['value']>=2) { //Split a 5 trays into 4 tray and 1 tray
			list($sku, $weight) = pop_whitetray(5);
			$content[] =  array ('quantity' => 5, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(5);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1/5;
			push_whitetray(4, $sku, $weight1/5); // Save 4 trays
		}
		else if ($whitetray[4]['value']>=1 && $whitetray[3]['value']>=1 ) { //Split 3 trays into 2 tray and 1 tray
			list($sku, $weight) = pop_whitetray(4);
			$content[] =  array ('quantity' => 4, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(3);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			$weight+=$weight1/3*2;
			push_whitetray(1, $sku, $weight1/3); // Save 1 trays
		}
		else if ($whitetray[4]['value']>=2) { //Split a 4 tray into 2 x 2 tray
			list($sku, $weight) = pop_whitetray(4);
			$content[] =  array ('quantity' => 4, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(4);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			$weight+=$weight1/2;
			push_whitetray(2, $sku, $weight1/4); // Save 2 trays
		}
		else if ($whitetray[3]['value']>=1 && $whitetray[2]['value']>=2 ) { //Split 2 trays into 2 x 1 tray
			list($sku, $weight) = pop_whitetray(3);
			$content[] =  array ('quantity' => 3, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			$weight+=$weight1/2;
			list($sku, $weight1) = pop_whitetray(2);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1/2;
			push_whitetray(1, $sku, $weight1/2); // Save 1 tray
		}
		$pack_in='1000-010';
		pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
	}
	while ($browntray_count>=4) {
		unset($content);
		$weight=0;
		if ($browntray[3]['value']>=1 && $browntray[1]['value']>=1 ) {
			list($sku, $weight) = pop_browntray(3);
			$content[] =  array ('quantity' => 3, 'sku' => $sku);
			list($sku, $weight1) = pop_browntray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
		}
		else if ($browntray[2]['value']>=2 ) {
			list($sku, $weight) = pop_browntray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			list($sku, $weight1) = pop_browntray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			$weight+=$weight1;
		}
		else if ($browntray[2]['value']>=1 && $browntray[1]['value']>=2 ) {
			list($sku, $weight) = pop_browntray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			list($sku, $weight1) = pop_browntray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
			list($sku, $weight1) = pop_browntray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
		}
		else if ($browntray[1]['value']>=4) {
			for ($i = 1; $i <= 4; $i++) {
				list($sku, $weight1) = pop_browntray(1);
				$content[] =  array ('quantity' => 1, 'sku' => $sku);
				$weight+=$weight1;
			}
		}
		else if ($browntray[3]['value']>=1 && $browntray[2]['value']>=1 ) { //Split 2 trays into 2 x 1 tray
			list($sku, $weight) = pop_browntray(3);
			$content[] =  array ('quantity' => 3, 'sku' => $sku);
			list($sku, $weight1) = pop_browntray(2);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1/2;
			push_browntray(1, $sku, $weight1/2); // Save single tray
		}
		else if ($browntray[3]['value']>=2) { //Split a 3 trays into 2 trays and 1 tray
			list($sku, $weight) = pop_browntray(3);
			$content[] =  array ('quantity' => 3, 'sku' => $sku);
			list($sku, $weight1) = pop_browntray(3);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1/3;
			push_browntray(2, $sku, $weight1/3); // Save 2 trays
		}
		$pack_in='1000-010';
		pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
	}
	
	//Pack white trays into 6-packs. white and brown trays <6 white <4 brown into 6-pack
	unset($content);
	$weight=0;
	if ($whitetray_count>=3 && $browntray_count>=2) { //Pack in 6-pack mixed white and brown trays
		$whitetray_count-=3;
		$browntray_count-=2;
		for ($i = 1; $i <= 3; $i++) {
			$whitetray[$i]['value']--;
			$content[] =  array ('quantity' => $i, 'sku' => $whitetray[$i][$whitetray[$i]['value']]['sku']);
			$weight+=$whitetray[$i][$whitetray[$i]['value']]['weight'];
			unset($whitetray[$i][$whitetray[$i]['value']]);
		}
		for ($i = 1; $i <= 2; $i++) {
			$browntray[$i]['value']--;
			$content[] =  array ('quantity' => $i, 'sku' => $browntray[$i][$browntray[$i]['value']]['sku']);
			$weight+=$browntray[$i][$browntray[$i]['value']]['weight'];
			unset($browntray[$i][$browntray[$i]['value']]);
		}
		$pack_in='1000-010';
		pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
	}

	//Pack less than 6-pack quantities of white and/or brown trays
	unset($content);
	$weight=0;
	if ($whitetray_count==5) { //pack in 3-pack & 2-pack
		if ($whitetray[5]['value']==1) { //Break into 3 & 2
			list($sku, $weight) = pop_whitetray(5);
			$weight=$weight/5*3;
			$content[] =  array ('quantity' => 3, 'sku' => $sku);
			$pack_in='1000-009';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			$pack_in='1000-008';
			unset($content);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			$weight=$weight/3*2;
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
		if ($whitetray[4]['value']==1) { //Break into 2 & 2
			list($sku, $weight) = pop_whitetray(4);
			$weight=$weight/2;
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			$pack_in='1000-008';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			list($sku, $weight1) = pop_whitetray(1);
			$weight+=$weight1;
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$pack_in='1000-009';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
		else if ($whitetray[3]['value']==1 && $whitetray[2]['value']==1) { 
			list($sku, $weight) = pop_whitetray(3);
			$content[] =  array ('quantity' => 3, 'sku' => $sku);
			$pack_in='1000-009';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			unset($content);
			list($sku, $weight) = pop_whitetray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			$pack_in='1000-009';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			unset($content);
		}
		else if ($whitetray[3]['value']==1 && $whitetray[1]['value']==2) { 
			list($sku, $weight) = pop_whitetray(3);
			$content[] =  array ('quantity' => 3, 'sku' => $sku);
			$pack_in='1000-009';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			unset($content);
			list($sku, $weight) = pop_whitetray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
			$pack_in='1000-008';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
		else if ($whitetray[2]['value']==2) {
			list($sku, $weight) = pop_whitetray(2);
			$weight=$weight;
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			$pack_in='1000-008';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			list($sku, $weight) = pop_whitetray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
			$pack_in='1000-009';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
		else if ($whitetray[2]['value']==1) {
			list($sku, $weight) = pop_whitetray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
			$pack_in='1000-009';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			unset($content);
			$weight=0;
			for ($i = 1; $i <= 2; $i++) {
				list($sku, $weight1) = pop_whitetray(1);
				$content[] =  array ('quantity' => 1, 'sku' => $sku);
				$weight+=$weight1;
			}
			$pack_in='1000-008';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
		else { //5 single trays are left to pack into 3-pack and 2-pack
			for ($i = 1; $i <= 3; $i++) {
				list($sku, $weight1) = pop_whitetray(1);
				$content[] =  array ('quantity' => 1, 'sku' => $sku);
				$weight+=$weight1;
			}
			$pack_in='1000-009';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			unset($content);
			$weight=0;
			for ($i = 1; $i <= 2; $i++) {
				list($sku, $weight1) = pop_whitetray(1);
				$content[] =  array ('quantity' => 1, 'sku' => $sku);
				$weight+=$weight1;
			}
			$pack_in='1000-008';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
	}
	else if ($whitetray_count==4) { //pack in 2 x 2-pack
		$pack_in='1000-008';
		if ($whitetray[4]['value']==1) { //Break into 2 & 2
			list($sku, $weight) = pop_whitetray(4);
			$weight=$weight/2;
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
		else if ($whitetray[3]['value']==1) { 
			list($sku, $weight) = pop_whitetray(3);
			$weight=$weight/3*2;
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			unset($content);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight=$weight/2;
			list($sku, $weight1) = pop_whitetray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
		else if ($whitetray[2]['value']==2) { 
			list($sku, $weight) = pop_whitetray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			unset($content);
			list($sku, $weight) = pop_whitetray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
		else if ($whitetray[2]['value']==1) { 
			list($sku, $weight) = pop_whitetray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			unset($content);
			list($sku, $weight) = pop_whitetray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
		else { //4 single trays are left to pack into 2 x 2-packs
			for ($j = 0; $j < 2; $j++) {
				unset($content);
				for ($i = 1; $i <= 2; $i++) {
					list($sku, $weight1) = pop_whitetray(1);
					$content[] =  array ('quantity' => 1, 'sku' => $sku);
					$weight+=$weight1;
				}
				pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
				$weight=0;
			}
		}
	}
	else if ($whitetray_count==3) { //pack in 3-pack
		if ($whitetray[3]['value']==1) {
			list($sku, $weight) = pop_whitetray(3);
			$content[] =  array ('quantity' => 3, 'sku' => $sku);
		}
		else if ($whitetray[2]['value']==1 && $whitetray[1]['value']==1) {
			list($sku, $weight) = pop_whitetray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			list($sku, $weight1) = pop_whitetray(1);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight+=$weight1;
		}
		else { 
			for ($i = 1; $i <= 3; $i++) {
				list($sku, $weight1) = pop_whitetray(1);
				$content[] =  array ('quantity' => 1, 'sku' => $sku);
				$weight+=$weight1;
			}
		}
		$pack_in='1000-009';
		pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
	}
	else if ($whitetray_count==2) { //pack in 2-pack
		$pack_in='1000-008';
		if ($whitetray[2]['value']==1) {
			list($sku, $weight) = pop_whitetray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
		}
		else { 
			for ($i = 1; $i <= 2; $i++) {
				list($sku, $weight1) = pop_whitetray(1);
				$content[] =  array ('quantity' => 1, 'sku' => $sku);
				$weight+=$weight1;
			}
		}
		pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
	}
	else if ($whitetray_count==1) { //pack in 1-pack
		$pack_in='1000-005';
		list($sku, $weight) = pop_whitetray(1);
		$content[] =  array ('quantity' => 1, 'sku' => $sku);
		pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
	}
	if ($browntray_count==3) { //pack in 3-pack & 1 pack deep
		$browntray_count-=3;
		if ($browntray[3]['value']==1) {
			list($sku, $weight) = pop_browntray(3);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			$weight=$weight/3*2;
			$pack_in='1000-009';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
			unset($content);
			$content[] =  array ('quantity' => 1, 'sku' => $sku);
			$weight=$weight/2;
			$pack_in='1000-006';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
		if ($browntray[2]['value']==1) {
			list($sku, $weight) = pop_browntray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
			$weight=$weight;
			$pack_in='1000-009';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
		else {
			for ($i = 1; $i <= 2; $i++) {
				list($sku, $weight1) = pop_browntray(1);
				$content[] =  array ('quantity' => 1, 'sku' => $sku);
				$weight+=$weight1;
			}
			$pack_in='1000-009';
			pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
		}
		unset($content);
		list($sku, $weight) = pop_browntray(1);
		$content[] =  array ('quantity' => 1, 'sku' => $sku);
		$pack_in='1000-006';
		pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
	} 
	else if ($browntray_count==2) { //pack in 3-pack 
		$pack_in='1000-009';
		if ($browntray[2]['value']==1) {
			list($sku, $weight) = pop_browntray(2);
			$content[] =  array ('quantity' => 2, 'sku' => $sku);
		}
		else { 
			for ($i = 1; $i <= 2; $i++) {
				list($sku, $weight1) = pop_browntray(1);
				$content[] =  array ('quantity' => 1, 'sku' => $sku);
				$weight+=$weight1;
			}
		}
		pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
	}
	else if ($browntray_count==1) { //pack in 1 pack deep
		$pack_in='1000-006';
		list($sku, $weight) = pop_browntray(1);
		$content[] =  array ('quantity' => 1, 'sku' => $sku);
		pack_it($pack_in, $boxes[$pack_in]['length'], $boxes[$pack_in]['width'], $boxes[$pack_in]['height'], $weight + $boxes[$pack_in]['weight'], $content);
	}

//print_r($packed);

//echo count($packed);

$time_elapsed_secs = microtime(true) - $start; //***************
//echo ($quotes['module'] . " Execution time: " . $time_elapsed_secs . "<br>" . PHP_EOL); //***************
return $packed;
}
  ?>
