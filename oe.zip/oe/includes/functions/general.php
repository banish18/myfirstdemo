<?php
require_once($rootPath.'includes/classes/shopping_cart.php');
////
// Wrapper function for round()
  function zen_round($number, $precision) {
/// fix rounding error on GVs etc.
    $number = round($number, $precision);

    return $number;
  }
   function zen_get_shipping_enabled($shipping_module) {
    global $PHP_SELF, $cart, $order;
	$shoppingcart = new shoppingCart;
    $check_cart_free = $shoppingcart->in_cart_check('product_is_always_free_shipping','1');
    $check_cart_cnt = $shoppingcart->count_contents();
    $check_cart_weight = $shoppingcart->show_weight();
    

    switch(true) {
      // Free Shipping when 0 weight - enable freeshipper - ORDER_WEIGHT_ZERO_STATUS must be on
      case (ORDER_WEIGHT_ZERO_STATUS == '1' and ($check_cart_weight == 0 and $shipping_module == 'freeshipper')):
        return true;
        break;
      // Free Shipping when 0 weight - disable everyone - ORDER_WEIGHT_ZERO_STATUS must be on
      case (ORDER_WEIGHT_ZERO_STATUS == '1' and ($check_cart_weight == 0 and $shipping_module != 'freeshipper')):
        return false;
        break;
      case (($shoppingcart->free_shipping_items() == $check_cart_cnt) and $shipping_module == 'freeshipper'):
        return true;
        break;
      case (($shoppingcart->free_shipping_items() == $check_cart_cnt) and $shipping_module != 'freeshipper'):
        return false;
        break;
      // Always free shipping only true - enable freeshipper
      case (($check_cart_free == $check_cart_cnt) and $shipping_module == 'freeshipper'):
        return true;
        break;
      // Always free shipping only true - disable everyone
      case (($check_cart_free == $check_cart_cnt) and $shipping_module != 'freeshipper'):
        return false;
        break;
      // Always free shipping only is false - disable freeshipper
      case (($check_cart_free != $check_cart_cnt) and $shipping_module == 'freeshipper'):
        return false;
        break;
      default:
        return true;
        break;
    }
  }
  
?>
