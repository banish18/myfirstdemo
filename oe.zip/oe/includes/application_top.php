<?php

set_magic_quotes_runtime(0);
if (@ini_get('magic_quotes_sybase') != 0) @ini_set('magic_quotes_sybase', 0);

if (file_exists('includes/configure.php')) {
  include('includes/configure.php');
}

require(DIR_WS_CLASSES."class.base.php");

// set the type of request (secure or not)
$request_type = (strtolower($_SERVER['HTTPS']) == 'on' || $_SERVER['HTTPS'] == '1' || strstr(strtoupper($_SERVER['HTTP_X_FORWARDED_BY']),'SSL') || strstr(strtoupper($_SERVER['HTTP_X_FORWARDED_HOST']),'SSL'))  ? 'SSL' : 'NONSSL';

// set php_self in the local scope
if (!isset($PHP_SELF)) $PHP_SELF = $_SERVER['PHP_SELF'];

// include the list of project database tables
require(DIR_FS_CATALOG . DIR_WS_INCLUDES . 'database_tables.php');

// include the cache class
require(DIR_FS_CATALOG . DIR_WS_CLASSES . 'cache.php');
$zc_cache = new cache;

// Load db classes
// Load queryFactory db classes
require(DIR_FS_CATALOG . DIR_WS_CLASSES . 'db/' .DB_TYPE . '/query_factory.php');
$db = new queryFactory();
$db->connect(DB_SERVER, DB_SERVER_USERNAME, DB_SERVER_PASSWORD, DB_DATABASE);

$zc_cache->sql_cache_flush_cache();

// set application wide parameters

$configuration = $db->Execute('select configuration_key as cfgKey, configuration_value as cfgValue from ' . TABLE_CONFIGURATION);
while (!$configuration->EOF) {
	define($configuration->fields['cfgKey'], $configuration->fields['cfgValue']);
	$configuration->MoveNext();
}

// include the database functions
 require(DIR_WS_FUNCTIONS . 'database.php');

// define our general functions used application-wide
 require(DIR_WS_FUNCTIONS . 'general.php');
 require(DIR_WS_FUNCTIONS . 'functions_prices.php');
 //require(DIR_WS_FUNCTIONS . 'html_output.php');
 require(DIR_WS_FUNCTIONS . 'functions_customers.php'); // partial copy of catalog functions customers for now
 require(DIR_WS_FUNCTIONS . 'functions_email.php');
 require(DIR_WS_FUNCTIONS . 'password_funcs.php');

require(DIR_FS_CATALOG . DIR_WS_CLASSES . 'class.phpmailer.php');
require(DIR_FS_CATALOG . DIR_WS_CLASSES . 'class.smtp.php');
?>