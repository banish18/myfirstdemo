<?php
/**
 * zcAjaxPayment
 *
 * @package templateSystem
 * @copyright Copyright 2003-2014 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: Ian Wilson  New in v1.5.4 $
 */
require_once(getcwd().'/includes/library/addressvalidation/fedex_fnc.php');
require_once(getcwd().'/includes/classes/class.base.php');
require_once('../db/db.inc');
require_once(getcwd().'/getCountrycode.php');


class zcAddressValidation extends base
{
	
	
	public function getcountriesCode($country_id) {
		global $zendb;
		$countries = [];
		//echo $zendb;
	    $sql = "SELECT  * FROM countries where countries_id='".$country_id."'";
		$result = mysqli_query($zendb, $sql);
		while ($country = mysqli_fetch_array($result)) { 
			$countries = array (
				'countries_name'	=>	$country['countries_name'],
				'countries_iso_code_2' 	=>	$country['countries_iso_code_2'],
				'countries_iso_code_3' 	=>	$country['countries_iso_code_3']
			);
		}
		return $countries;
	}
	
	public function getzoneCode($country_id , $state_name) {
		global $zendb;
		$sql = "select zone_code from zones where zone_country_id = '".$country_id."' and zone_name like '%".$state_name."%'";
		$result = mysqli_query($zendb, $sql);
		$zone_data = mysqli_fetch_array($result);
		if(!empty($zone_data))
		{
			$zone_code = $zone_data['zone_code'];
		}
		else
		{
			$zone_code = $state_name;
		}
		
		
		return $zone_code;
	}

	public function ValidateAddress()
	{	
		global $db;
		$data = array();		
		$country_id = $_REQUEST['country'];
		$state_name = $_REQUEST['state'];
		//Configuration
		$access = "EBE9010D119A9E48";
		$userid = "holidaybows";
		$passwd = "Fountain59";
		$wsdl = getcwd().'/includes/library/addressvalidation/XAV.wsdl';
		$operation = "ProcessXAV";
		$endpointurl = 'https://onlinetools.ups.com/webservices/XAV';
		$outputFileName = "XOLTResult.xml";
		
		$countries_array = $this->getcountriesCode($country_id);
		
		
		
		$_REQUEST['country'] =  $countries_array['countries_iso_code_2'];
		
		$state_zone_code = $this->getzoneCode($country_id,$state_name);
		$_REQUEST['state'] = $state_zone_code;
		
			
	   $response = FedEx_Address_Validation($_REQUEST);
	  	 
	   if (isset($response['Error'])) {
			$data['Score'] = 0;
		}
		else
		{
			$data['Score'] = $response['Score'];
			$data['ResidentialStatus'] = $response['ResidentialStatus'];
			if($data['Score']!=100)
			{
				//$data['Changes']=$response['ResidentialStatus'];
				$street_address = $_REQUEST['street_address1'];
				$street_address .= trim($_REQUEST["street_address2"])!=""? " ".$_REQUEST["street_address2"]:"";
			    $user_entered_adddress_value = $street_address.", ".$_REQUEST['city'].", ".$_REQUEST['state'].", ".$_REQUEST['postcode'];
			    $user_entered_adddress_text = "<div class='addres-text'>".$street_address." (Original)<br>".$_REQUEST['city'].", <span=class='origanal-address'></span>".$_REQUEST['state'].", ".$_REQUEST['postcode']."</div>";
				$data["suggestion"] = "<input type='radio' name='suggest_address' class='suggested_address user_entered_adddress' value='".$user_entered_adddress_value."'> ".$user_entered_adddress_text;
				$fedex_suggestion_value  = $response['Address']['StreetLines'].", ".$response['Address']['City'].", ".$response['Address']['StateOrProvinceCode'].", ".$response['Address']['PostalCode'];
				$fedex_suggestion_text  =  "<div class='addres-text'>".$response['Address']['StreetLines'].",<br>".$response['Address']['City'].", ".$response['Address']['StateOrProvinceCode'].", ".$response['Address']['PostalCode']."</div>";
				$data["suggestion"] .=  "<input type='radio' name='suggest_address' class='suggested_address fedex_suggestion' value='".$fedex_suggestion_value."'> ".$fedex_suggestion_text;				
			}			
		}
		try
		  {

			$mode = array
			(
				 'soap_version' => 'SOAP_1_1',  // use soap 1.1 client
				 'trace' => 1
			);

			// initialize soap client
			$client = new SoapClient($wsdl , $mode);

			//set endpoint url
			$client->__setLocation($endpointurl);


			//create soap header
			$usernameToken['Username'] = $userid;
			$usernameToken['Password'] = $passwd;
			$serviceAccessLicense['AccessLicenseNumber'] = $access;
			$upss['UsernameToken'] = $usernameToken;
			$upss['ServiceAccessToken'] = $serviceAccessLicense;

			$header = new SoapHeader('http://www.ups.com/XMLSchema/XOLTWS/UPSS/v1.0','UPSSecurity',$upss);
			$client->__setSoapHeaders($header);


			//get response
			$resp = $client->__soapCall($operation ,array($this->processXAV()));

			if($_REQUEST['country']=="US"||$_REQUEST['country']=="PR")
			{
				if(isset($resp->Candidate)){
					if(count($resp->Candidate)>0)
					{
						$data['UPSScore'] = 1;
					}
				}
				else
				{
					$data['UPSScore'] = 0;
				}						
		    }
			

		  }
		  catch(Exception $ex)
		  {
			//print_r ($ex);
		  }
		return $data;
	}
	 function processXAV()
	 {
		  //create soap request
		  $option['RequestOption'] = '1';
		  $request['Request'] = $option;

		  $companyname = "";
		  $addressline1 = $_REQUEST["street_address1"];
		  $addressline2 = $_REQUEST["street_address2"];
		  $region = $_REQUEST["city"].",".$_REQUEST["state"].",".$_REQUEST["postcode"];
		  $city = $_REQUEST["city"];
		  $zicode = explode("-",$_REQUEST["postcode"]);
		  $state = $_REQUEST["state"];
		  $country = $_REQUEST["country"];
		  $request['RegionalRequestIndicator'] = '1';
		  $addrkeyfrmt['ConsigneeName'] = $companyname;
		  $addrkeyfrmt['AddressLine'] = array('"'.$addressline1.'"','"'.$addressline2.'"');
		  $addrkeyfrmt['Region'] = $region;
		  $addrkeyfrmt['PoliticalDivision2'] = $city;
		  $addrkeyfrmt['PoliticalDivision1'] = $state;
		  $addrkeyfrmt['PostcodePrimaryLow'] = @$zicode[0];
		  $addrkeyfrmt['PostcodeExtendedLow'] =  @$zicode[1];
		  $addrkeyfrmt['Urbanization'] = '';
		  $addrkeyfrmt['CountryCode'] = $country;
		  $request['AddressKeyFormat'] = $addrkeyfrmt;	 
		  return $request;
	 }
	 
	 function ship(){
		 
		global $db;
		$data = array();		
		$address_book_id = $_REQUEST['id'];
		$shipto=$_REQUEST['shipto'];	 
		
		$blind_ship_to = "blind_ship_to ='".$shipto."'";
			
		$sql = "update ". TABLE_ADDRESS_DETAILS." set ".$blind_ship_to." where address_book_id='".$address_book_id."'";
		
		$res = $db->Execute($sql);
		
		if($res->resource==1){
			$data[]='update success';			
		}
		else { $data[]='update error'; }
		return $data;
		 
	}
	
}

?>
