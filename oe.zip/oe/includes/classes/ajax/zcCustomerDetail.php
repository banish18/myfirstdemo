<?php
/**
 * zcCustomerDetail
 *
 * @package templateSystem
 * @copyright Copyright 2003-2014 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: Ian Wilson  New in v1.5.4 $
 */
require_once('../db/db.inc');
require_once('payment/function.php');


class zcCustomerDetail
{
	/*
	 * return random password
	*/
	public function password_generate($chars) 
	{
		$data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
		return substr(str_shuffle($data), 0, $chars);
	}
	
	/*
	 * Save new customer detail
	*/
	
	public function savecustomer() {
		global $zendb;
		
		parse_str($_POST['form_data'], $customerarray);
		
		
		$randomPassword = $this->password_generate(7);
        
		$customer_name = isset($customerarray['customers_firstname']) ? $customerarray['customers_firstname'] : "";
		$customers_telephone = isset($customerarray['customers_telephone']) ? $customerarray['customers_telephone'] : "";
		$customers_email_address = isset($customerarray['customers_email_address']) ? $customerarray['customers_email_address'] : "";
		$customers_lastname = isset($customerarray['customers_lastname']) ? $customerarray['customers_lastname'] : "";
		$customers_fax = isset($customerarray['customers_fax']) ? $customerarray['customers_fax'] : "";
		$customers_group_pricing = isset($customerarray['customers_group_pricing']) ? $customerarray['customers_group_pricing'] : 0;
		$customers_terms_special = isset($customerarray['customers_terms_special']) ? $customerarray['customers_terms_special'] : "";
		$customers_resale_tax_id_date = isset($customerarray['customers_resale_tax_id_date']) ? $customerarray['customers_resale_tax_id_date'] : null;
		$customers_special_shipping_notes = isset($customerarray['customers_special_shipping_notes']) ? $customerarray['customers_special_shipping_notes'] : "";
		$customers_terms = isset($customerarray['customers_terms']) ? $customerarray['customers_terms'] : "";
		$customers_resale_tax_id = isset($customerarray['customers_resale_tax_id']) ? $customerarray['customers_resale_tax_id'] : "";
		$customers_special_order_notes = isset($customerarray['customers_special_order_notes']) ? $customerarray['customers_special_order_notes'] : "";
		$customers_invoice_email = isset($customerarray['customers_invoice_email']) ? $customerarray['customers_invoice_email'] : 0;
		$customers_invoice_mail = isset($customerarray['customers_invoice_mail']) ? $customerarray['customers_invoice_mail'] : 0;
		$customers_invoice_fax = isset($customerarray['customers_invoice_fax']) ? $customerarray['customers_invoice_fax'] : 0;
		$customers_blind_ship_enabled = isset($customerarray['customers_blind_ship_enabled']) ? $customerarray['customers_blind_ship_enabled'] : 0;
		$customers_blind_ship_default = isset($customerarray['customers_blind_ship_default']) ? $customerarray['customers_blind_ship_default'] : 0;
		$customer_wholesale = isset($customerarray['customer_wholesale']) ? $customerarray['customer_wholesale'] : 0;
		$customers_store_pickup_enabled = isset($customerarray['customers_store_pickup_enabled']) ? $customerarray['customers_store_pickup_enabled'] : 0;
		$customers_custom_ship_date_enabled = isset($customerarray['customers_custom_ship_date_enabled']) ? $customerarray['customers_custom_ship_date_enabled'] : 0;
		$customers_ship_collect = isset($customerarray['customers_ship_collect']) ? $customerarray['customers_ship_collect'] : 0;
		$customers_ups_acct = isset($customerarray['customers_ups_acct']) ? $customerarray['customers_ups_acct'] : "";
		$customers_fedex_acct = isset($customerarray['customers_fedex_acct']) ? $customerarray['customers_fedex_acct'] : "";
		$customers_ltl_capable = isset($customerarray['customers_ltl_capable']) ? $customerarray['customers_ltl_capable'] : 0;
		$msg = 0;
		
		
		
		
		
		$check_customer_exist = "SELECT * FROM customers WHERE customers_email_address = '" . $customers_email_address ."'";
		
		$cus_result = mysqli_query($zendb, $check_customer_exist);
		$count_val = mysqli_num_rows ( $cus_result );
		if($count_val == 0)
		{
			$processCIM = new processCIM;
		    $customerPId = $processCIM->createcutomerProfile($customers_email_address);
		
			$sql = "INSERT INTO customers(customers_firstname, customers_lastname, customers_email_address, customers_telephone, customers_fax,customers_password,customers_group_pricing,customers_customerProfileId )VALUES( '". $customer_name . "', '" .$customers_lastname . "', '" .$customers_email_address . "', '" .$customers_telephone . "', '" .$customers_fax . "',MD5('".$randomPassword."'),'".$customers_group_pricing."','".$customerPId."')";
			
			$result = mysqli_query($zendb, $sql);
			$customer_id = mysqli_insert_id($zendb);
		    $_SESSION["customer_id"] = $customer_id;
			$customer_detail_sql = "INSERT INTO customers_details
				(customers_id, customers_store_pickup_enabled, customers_custom_ship_date_enabled, customers_terms, customers_terms_special, customers_blind_ship_enabled, customers_blind_ship_default, customers_ship_collect, customers_ups_acct, customers_fedex_acct, customers_ltl_capable, customers_special_shipping_notes, customers_special_order_notes, customers_invoice_mail, customers_invoice_fax, customers_invoice_email, customers_resale_tax_id, customers_resale_tax_id_date, customer_wholesale )	
				VALUES( '". $customer_id . "', '" .
					$customers_store_pickup_enabled . "', '" .
					$customers_custom_ship_date_enabled . "', '" .
					$customers_terms . "', '" .
					$customers_terms_special . "', '" .
					$customers_blind_ship_enabled . "', '" .
					$customers_blind_ship_default . "', '" .
					$customers_ship_collect . "', '" .
					$customers_ups_acct . "', '" .
					$customers_fedex_acct . "', '" .
					$customers_ltl_capable . "', '" .
					$customers_special_shipping_notes . "', '" .
					$customers_special_order_notes . "', '" .
					$customers_invoice_mail . "', '" .
					$customers_invoice_fax . "', '" .
					$customers_invoice_email . "', '" .
					$customers_resale_tax_id . "', '" .
					$customers_resale_tax_id_date . "', '" .
					$customer_wholesale . "')";
					
			$cus_detail_result = mysqli_query($zendb, $customer_detail_sql);
			$msg .= 1;
		}
		else
		{
			$msg .= 0;
		}
		
		return $msg;
	}
	
	/* Add new customer proile */
	function createCustomerproile(){
		global $zendb;
		$_SESSION['customerProfileId'] = $_REQUEST['cid'];
		$sql = "select customers_id,customers_email_address from customers where customers_customerProfileId=".$_REQUEST['cid'];
		$result = mysqli_query($zendb, $sql); //query the database for entries containing the term
		$msg = 0;
		if(mysqli_num_rows($result) > 0){
			$result_data = mysqli_fetch_array($result);
			$customer_id = $result_data["customers_id"];
			$customers_email_address = $result_data["customers_email_address"];
			if($customers_email_address != ""){
				$processCIM = new processCIM;
				$customerPId = $processCIM->createcutomerProfile($customers_email_address);
				if($customerPId != "0"){
					$update_default_address = "UPDATE customers SET
						customers_customerProfileId = '" . $customerPId . "'
						WHERE customers_id='".  $customer_id . "'";
					mysqli_query($zendb, $update_default_address);
					$msg = 1;
				}
			}	
		}
		
		return $msg;
	}
	
	
	/*
	 * Update customer detail
	*/
	
	public function updateCustomer() {
		global $zendb;
		
		parse_str($_POST['form_data'], $customerarray);
		
		
		$customer_id = isset($customerarray['customer_id']) ? $customerarray['customer_id'] : "";
		$customer_name = isset($customerarray['customers_firstname']) ? $customerarray['customers_firstname'] : "";
		$customers_telephone = isset($customerarray['customers_telephone']) ? $customerarray['customers_telephone'] : "";
		$customers_email_address = isset($customerarray['customers_email_address']) ? $customerarray['customers_email_address'] : "";
		$customers_lastname = isset($customerarray['customers_lastname']) ? $customerarray['customers_lastname'] : "";
		$customers_fax = isset($customerarray['customers_fax']) ? $customerarray['customers_fax'] : "";
		$customers_group_pricing = isset($customerarray['customers_group_pricing']) ? $customerarray['customers_group_pricing'] : 0;
		$customers_terms_special = isset($customerarray['customers_terms_special']) ? $customerarray['customers_terms_special'] : "";
		$customers_resale_tax_id_date = isset($customerarray['customers_resale_tax_id_date']) ? $customerarray['customers_resale_tax_id_date'] : null;
		$customers_special_shipping_notes = isset($customerarray['customers_special_shipping_notes']) ? $customerarray['customers_special_shipping_notes'] : "";
		$customers_terms = isset($customerarray['customers_terms']) ? $customerarray['customers_terms'] : "";
		$customers_resale_tax_id = isset($customerarray['customers_resale_tax_id']) ? $customerarray['customers_resale_tax_id'] : "";
		$customers_special_order_notes = isset($customerarray['customers_special_order_notes']) ? $customerarray['customers_special_order_notes'] : "";
		$customers_invoice_email = isset($customerarray['customers_invoice_email']) ? $customerarray['customers_invoice_email'] : 0;
		$customers_invoice_mail = isset($customerarray['customers_invoice_mail']) ? $customerarray['customers_invoice_mail'] : 0;
		$customers_invoice_fax = isset($customerarray['customers_invoice_fax']) ? $customerarray['customers_invoice_fax'] : 0;
		$customers_blind_ship_enabled = isset($customerarray['customers_blind_ship_enabled']) ? $customerarray['customers_blind_ship_enabled'] : 0;
		$customers_blind_ship_default = isset($customerarray['customers_blind_ship_default']) ? $customerarray['customers_blind_ship_default'] : 0;
		$customer_wholesale = isset($customerarray['customer_wholesale']) ? $customerarray['customer_wholesale'] : 0;
		$customers_store_pickup_enabled = isset($customerarray['customers_store_pickup_enabled']) ? $customerarray['customers_store_pickup_enabled'] : 0;
		$customers_custom_ship_date_enabled = isset($customerarray['customers_custom_ship_date_enabled']) ? $customerarray['customers_custom_ship_date_enabled'] : 0;
		$customers_ship_collect = isset($customerarray['customers_ship_collect']) ? $customerarray['customers_ship_collect'] : 0;
		$customers_ups_acct = isset($customerarray['customers_ups_acct']) ? $customerarray['customers_ups_acct'] : "";
		$customers_fedex_acct = isset($customerarray['customers_fedex_acct']) ? $customerarray['customers_fedex_acct'] : "";
		$customers_ltl_capable = isset($customerarray['customers_ltl_capable']) ? $customerarray['customers_ltl_capable'] : 0;
		$msg = 0;
		
		
		$sql = "UPDATE customers SET
				customers_firstname = '" . $customer_name . "',
				customers_lastname = '" . $customers_lastname . "',
				customers_email_address = '" . $customers_email_address . "',
				customers_group_pricing = '" . $customers_group_pricing . "',
				customers_telephone = '" . $customers_telephone . "',
				customers_fax = '" . $customers_fax . "'
				WHERE customers_id='".  $customer_id . "'";
		$result = mysqli_query($zendb, $sql);
		
		$sql_customerDetail = "UPDATE customers_details SET
								customers_store_pickup_enabled = '" . $customers_store_pickup_enabled . "',
								customers_custom_ship_date_enabled = '" . $customers_custom_ship_date_enabled . "',
								customers_terms = '" . $customers_terms . "',
								customers_terms_special = '" . $customers_terms_special . "',
								customers_blind_ship_enabled = '" . $customers_blind_ship_enabled . "',
								customers_blind_ship_default = '" . $customers_blind_ship_default . "',
								customers_ship_collect = '" . $customers_ship_collect . "',
								customers_ups_acct = '" . $customers_ups_acct . "',
								customers_fedex_acct = '" . $customers_fedex_acct . "',
								customers_ltl_capable = '" . $customers_ltl_capable . "',
								customers_special_shipping_notes = '" . $customers_special_shipping_notes . "',
								customers_special_order_notes = '" . $customers_special_order_notes . "',
								customers_invoice_mail = '" . $customers_invoice_mail . "',
								customers_invoice_fax = '" . $customers_invoice_fax . "',
								customers_invoice_email = '" . $customers_invoice_email . "',
								customers_resale_tax_id = '" . $customers_resale_tax_id . "',
								customers_resale_tax_id_date = '" . $customers_resale_tax_id_date . "',
								customer_wholesale = '" . $customer_wholesale . "'
								WHERE customers_id='".  $customer_id . "'";
								$result = mysqli_query($zendb, $sql_customerDetail);
						$msg = 1;
			return $msg;
	}
	
	
	/*
	 * return customer address 
	 */
	
	public function getaddress()
	{
		
		global $zendb;
		$customer_id = $_POST["customer"];
		$_SESSION['customer_id'] = $customer_id;
		
		$get_customer_detail = "SELECT customers_default_address_id,customers_firstname ,customers_lastname,customers_email_address,customers_telephone FROM customers WHERE customers_id='".$customer_id."'";
		
		$customer_detailresult = mysqli_query($zendb, $get_customer_detail);
		$customer = mysqli_fetch_array($customer_detailresult);
		
		
		$sql = "SELECT  ab.address_book_id,ab.entry_zone_id, entry_company, entry_firstname, entry_lastname, entry_street_address, entry_suburb, entry_postcode, entry_city, entry_state, entry_country_id, 	zone_code, blind_shipping, ups_validated, fedex_validated, ups_residential, fedex_residential, blind_ship_to, dropship_fee, dropship_fee_threshhold
		FROM address_book ab
		LEFT JOIN address_details ad ON ab.address_book_id = ad.address_book_id
		LEFT JOIN zones z on ab.entry_zone_id=z.zone_id
		WHERE ab.customers_id = '" . $customer_id . "'";
		$result1 = mysqli_query($zendb, $sql);
		$data = mysqli_num_rows ( $result1 );
		$address_html = "";
		if($data > 0)
		{
			$address_html .= '<script>$("#table_id").DataTable();</script>';
			$address_html .= '<table id="table_id" class="display">
				<thead><tr><th>#</th><th>ID</th><th>Company</th><th>First Name</th><th>Last Name</th><th>Street Address 1</th><th>Street Address 2</th><th>City</th><th>State</th><th>Postcode</th><th>Action</th></tr></thead><tbody>';
			
				while ($address = mysqli_fetch_array($result1)) {
					
					$zoneNme = $this->adget_zone_name($address['entry_country_id'], $address['entry_zone_id'], $address['entry_state']);
					$defaultAdd = '';
					if($customer['customers_default_address_id'] == $address['address_book_id']){
						$defaultAdd = "Primary Address";
					}
					$address_html .= '<tr><td><b>'.$defaultAdd.'</b></td><td>'.$address['address_book_id'].'</td><td>'.$address['entry_company'].'</td><td>'.$address['entry_firstname'].'</td><td>'.$address['entry_lastname'].'</td><td>'.$address['entry_street_address'].'</td><td>'.$address['entry_suburb'].'</td><td>'.$address['entry_city'].'</td><td>'.$zoneNme.'</td><td>'.$address['entry_postcode'].'</td><td><a title="Edit" class="edit_address mr-3" href="JavaScript:void(0);" data-id="'.$address['address_book_id'].'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a><a title="Delete" class="delete_address" href="JavaScript:void(0);" data-id="'.$address['address_book_id'].'"><i class="fa fa-trash" aria-hidden="true"></i></a></td></tr>';
				}
				
			
			$address_html .= '</tbody></table>';
			
			
		}
		else
		{
			$address_html .= '<p>No Result Found !!';
		}
		return $address_html;
	}
	
	/*
	 * Return the zone (State/Province) name
	 * TABLES: zones
	 */
	  function adget_zone_name($country_id, $zone_id, $default_zone) {
		global $zendb;
		$zone_query = "select zone_name
					   from zones
					   where zone_country_id = '" . (int)$country_id . "'
					   and zone_id = '" . (int)$zone_id . "'";

		$zone = mysqli_query($zendb,$zone_query);

		if (mysqli_num_rows($zone) > 0) {
			$zoneR = mysqli_fetch_array($zone);
		  return $zoneR['zone_name'];
		} else {
		  return $default_zone;
		}
	  }
	
	
	/*
	 * save cutomer new address
	 */
	
	public function saveaddress() {
		global $zendb;
		
		parse_str($_POST['form_data'], $addressarray);
		
		$msg="";
		$firstname = isset($addressarray['firstname']) ? $addressarray['firstname'] : "";
		$lastname = isset($addressarray['lastname']) ? $addressarray['lastname'] : "";
		$company = isset($addressarray['company']) ? $addressarray['company'] : "";
		$street_address = isset($addressarray['street_address']) ? $addressarray['street_address'] : "";
		$suburb = isset($addressarray['suburb']) ? $addressarray['suburb'] : "";
		$city = isset($addressarray['city']) ? $addressarray['city'] : "";
		$state = isset($addressarray['state']) ? $addressarray['state'] : "";
		$zipcode = isset($addressarray['zipcode']) ? $addressarray['zipcode'] : "";
		$zone_country_id = isset($addressarray['zone_country_id']) ? $addressarray['zone_country_id'] : "";
		$customer_id = isset($addressarray['customer_id']) ? $addressarray['customer_id'] : "";
		$ups_validated = isset($addressarray['ups_validated']) ? $addressarray['ups_validated'] : 0;
		$fedex_validated = isset($addressarray['fedex_validated']) ? $addressarray['fedex_validated'] : 0;
		$ups_residential = isset($addressarray['ups_residential']) ? $addressarray['ups_residential'] : 0;
		$fedex_residential = isset($addressarray['fedex_residential']) ? $addressarray['fedex_residential'] : 0;
		$primary = isset($addressarray['primary']) ? $addressarray['primary'] : "";
		$zones = $this->getZonesCodeId($zone_country_id , $state);
		$dropship_fee = 0.00;
		$dropship_fee_threshhold = 0.00;
		
		if($_REQUEST['suggested'] == "suggested_address")
		{
			$state = $this->getZonename($zone_country_id,$state);
			$zones = $this->getZonesCodeId($zone_country_id , $state);
		}
		
		
		$sql = "INSERT INTO address_book
			(customers_id, entry_company, entry_firstname, entry_lastname, entry_street_address, entry_suburb, entry_postcode, entry_city, entry_state, entry_country_id,entry_zone_id)	
			VALUES( '". $customer_id . "', '" .
				$company . "', '" .
				$firstname . "', '" .
				$lastname . "', '" .
				$street_address . "', '" .
				$suburb . "', '" .
				$zipcode . "', '" .
				$city . "', '" .
				$state . "', '" .
				$zone_country_id . "', '" .
				$zones . "')";
		$result = mysqli_query($zendb, $sql);
		
		$address_book_id = mysqli_insert_id($zendb);
		
		$address_detailsql = "INSERT INTO address_details
			(  address_book_id, ups_validated, fedex_validated, ups_residential, fedex_residential, dropship_fee, dropship_fee_threshhold )	
			VALUES('". $address_book_id . "', '" . $ups_validated . "', '" . $fedex_validated . "', '" . $ups_residential . "', '" . $fedex_residential . "','" . $dropship_fee . "', '" . $dropship_fee_threshhold . "')";
		$address_detail_result = mysqli_query($zendb, $address_detailsql);
		
		
		
		if($primary == "on")
		{
			$update_default_address = "UPDATE customers SET
				customers_default_address_id = '" . $address_book_id . "'
				WHERE customers_id='".  $customer_id . "'";
			mysqli_query($zendb, $update_default_address);
		}else{
			$slectDefaddress = "select customers_default_address_id from customers WHERE customers_id='".  $customer_id . "'";
			$res = mysqli_query($zendb,$slectDefaddress);
			$customers_default_address_id = "";
			if(mysqli_num_rows($res) > 0){
				$rows = mysqli_fetch_array($res);
				$customers_default_address_id = $rows["customers_default_address_id"];
				if($customers_default_address_id == "0"){
					$update_default_address = "UPDATE customers SET
					customers_default_address_id = '" . $address_book_id . "'
					WHERE customers_id='".  $customer_id . "'";
					mysqli_query($zendb, $update_default_address);
				}
			}
		}
		
		$msg .= "Address added successfully !!";
		return $msg;
	}
	
	/*
	 *  Update address data 
	 */
	
	public function updateAddress() {
		global $zendb;
		
		parse_str($_POST['form_data'], $addressarray);
		
		$msg="";
		$customer_id = isset($addressarray['customer_id']) ? $addressarray['customer_id'] : "";
		$firstname = isset($addressarray['firstname']) ? $addressarray['firstname'] : "";
		$lastname = isset($addressarray['lastname']) ? $addressarray['lastname'] : "";
		$company = isset($addressarray['company']) ? $addressarray['company'] : "";
		$street_address = isset($addressarray['street_address']) ? $addressarray['street_address'] : "";
		$suburb = isset($addressarray['suburb']) ? $addressarray['suburb'] : "";
		$city = isset($addressarray['city']) ? $addressarray['city'] : "";
		$state = isset($addressarray['state']) ? $addressarray['state'] : "";
		$zipcode = isset($addressarray['zipcode']) ? $addressarray['zipcode'] : "";
		$zone_country_id = isset($addressarray['zone_country_id']) ? $addressarray['zone_country_id'] : "";
		$address_book_id = isset($addressarray['address_book_id']) ? $addressarray['address_book_id'] : "";
		$ups_validated = isset($addressarray['ups_validated']) ? $addressarray['ups_validated'] : 0;
		$fedex_validated = isset($addressarray['fedex_validated']) ? $addressarray['fedex_validated'] : 0;
		$ups_residential = isset($addressarray['ups_residential']) ? $addressarray['ups_residential'] : 0;
		$fedex_residential = isset($addressarray['fedex_residential']) ? $addressarray['fedex_residential'] : 0;
		$primary = isset($addressarray['primary']) ? $addressarray['primary'] : "";
		$zones = $this->getZonesCodeId($zone_country_id , $state);
		$dropship_fee = 0.00;
		$dropship_fee_threshhold = 0.00;
		
		
		if($_REQUEST['suggested'] == "suggested_address")
		{
			$state = $this->getZonename($zone_country_id,$state);
			$zones = $this->getZonesCodeId($zone_country_id , $state);
		}
		
		$sql = "UPDATE  address_book SET
					entry_company = '" . $company . "',
					entry_firstname = '" . $firstname . "',
					entry_lastname = '" . $lastname . "',
					entry_street_address = '" . $street_address . "',
					entry_suburb = '" . $suburb . "',
					entry_postcode = '" . $zipcode . "',
					entry_city = '" . $city . "',
					entry_state = '" . $state . "',
					entry_country_id = '" . $zone_country_id . "',
					entry_zone_id  = '" . $zones . "'
				WHERE address_book_id='".  $address_book_id . "'";
				
		$result = mysqli_query($zendb, $sql);
		
		$sql = "UPDATE address_details SET
					ups_validated = '" . $ups_validated . "',
					fedex_validated = '" . $fedex_validated . "',
					ups_residential = '" . $ups_residential . "',
					fedex_residential = '" . $fedex_residential . "',
					dropship_fee = '" . $dropship_fee . "',
					dropship_fee_threshhold = '" . $dropship_fee_threshhold . "'
				WHERE address_book_id='".  $address_book_id . "'";
		
		if($primary == "on")
		{
			$update_default_address = "UPDATE customers SET
				customers_default_address_id = '" . $address_book_id . "'
				WHERE customers_id='".  $customer_id . "'";
			mysqli_query($zendb, $update_default_address);
		}
		else
		{
			$slectDefaddress = "select customers_default_address_id from customers WHERE customers_id='".  $customer_id . "'";
			$res = mysqli_query($zendb,$slectDefaddress);
			$customers_default_address_id = "";
			if(mysqli_num_rows($res) > 0){
				$rows = mysqli_fetch_array($res);
				$customers_default_address_id = $rows["customers_default_address_id"];
				if($customers_default_address_id == "0"){
					$update_default_address = "UPDATE customers SET
					customers_default_address_id = '" . $address_book_id . "'
					WHERE customers_id='".  $customer_id . "'";
					mysqli_query($zendb, $update_default_address);
				}
			}
		}
		
		$msg .= "Address update successfully !!";
		
		return $msg;
	}
	
	/*
	 * return state code
	*/
	
	public function getZonesCodeId($countryid , $state) {
		global $zendb;
		$sql = "SELECT zone_id FROM zones where zone_country_id = '".$countryid."' and zone_name ='".$state."'";
		$result = mysqli_query($zendb, $sql);
		$data = mysqli_fetch_array($result);
		$zone_id = 0;
		if(!empty($data))
		{
			$zone_id = $data['zone_id'];
		}
		return $zone_id;
	}
	
	/*
	 * return state name
	*/
	
	public function getZonename($countryid ,$zone_code)
	{
		global $zendb;
		$sql = "SELECT zone_name FROM zones where zone_country_id = '".$countryid."' and zone_code ='".$zone_code."'";
		$result = mysqli_query($zendb, $sql);
		$data = mysqli_fetch_array($result);
		$zone_name = "";
		if(!empty($data))
		{
			$zone_name = $data['zone_name'];
		}
		return $zone_name;
	}
	
	/* 
	 * delete address function 
	*/
	
	public function deleteAddress() {
		global $zendb;
		$msg = "";
		$address_book_id = $_REQUEST['address_book_id'];
		$customer_id = $_SESSION['customer_id'];
		$slectDefaddress = "select customers_default_address_id from customers WHERE customers_id='".  $customer_id . "'";
		$res = mysqli_query($zendb,$slectDefaddress);
		$customers_default_address_id = "";
		if(mysqli_num_rows($res) > 0){
			$rows = mysqli_fetch_array($res);
			$customers_default_address_id = $rows["customers_default_address_id"];
			if($customers_default_address_id == $address_book_id){
				$msg = "This is your primary address you cannot delete this !";
			}else{
				$sql = "DELETE FROM address_book WHERE address_book_id='".  $address_book_id . "'";
				$result = mysqli_query($zendb, $sql);
				$msg = "Address delete successfully !";
			}
		}
		return $msg;
	}
	
	/*
	 *  Address detail function 
	*/
	
	public function addressDetail() {
		global $zendb;
		$address_book_id = $_REQUEST['address_book_id'];
		$sql = "SELECT a.entry_company,a.entry_firstname,a.entry_lastname,a.entry_street_address,a.entry_suburb,a.entry_postcode,a.entry_city,a.entry_state,a.entry_country_id,a.address_book_id ,c.customers_default_address_id FROM address_book as a LEFT JOIN customers as c on a.customers_id = c.customers_id WHERE address_book_id='".  $address_book_id . "'";
		$result = mysqli_query($zendb, $sql);
		while ($address = mysqli_fetch_array($result)) { 
			$addresses = array (
				'company' 			=>	$address['entry_company'],
				'firstname'			=>	$address['entry_firstname'],
				'lastname' 			=>	$address['entry_lastname'],
				'street1' 			=>	$address['entry_street_address'],
				'street2' 			=>	$address['entry_suburb'],
				'postcode'			=>	$address['entry_postcode'],
				'city'	 			=>	$address['entry_city'],
				'state' 			=>	$address['entry_state'],
				'country_id' 		=>	$address['entry_country_id'],
				'address_book_id' 	=>	$address['address_book_id'],
				'customers_default_address_id' 	=>	$address['customers_default_address_id']
			);
		}
		return $addresses;
	}
	
	/*
	 * Password Reset 
	*/
	
	public function passwordReset() {
		global $zendb;
		parse_str($_POST['form_data'], $passwordarray);
		$msg = "";
		$customer_id = $passwordarray['customers_id'];
		$new_password = $passwordarray['new_password'];
		$updatedPassword = password_hash($new_password, PASSWORD_DEFAULT);
		$sql = "UPDATE customers SET customers_password = '".$updatedPassword."' WHERE customers_id ='".  $customer_id . "'";
		$result = mysqli_query($zendb, $sql);
		$msg = "Password update successfully !!";
		return $msg;
	}
	
	/*
	 * Get Customer data using session
	 */
	 
	 public function sessionCustomerData() {
		global $zendb;
		$term = $_POST['emailId'];
		$term = trim(strip_tags($term));
		$search_results = [];
		$search = '(entry_company LIKE "%' . $term . '%") ';
		$search .= 'OR (entry_firstname LIKE "%' . $term . '%")';
		$search .= 'OR (entry_lastname LIKE "%' . $term . '%")';
		$search .= 'OR (customers_firstname LIKE "%' . $term . '%")';
		$search .= 'OR (customers_lastname LIKE "%' . $term . '%")';
		$search .= 'OR (customers_email_address LIKE "%' . $term . '%")';
		$search .= 'OR (customers_telephone LIKE "%' . $term . '%")';
		
		$sql = "SELECT DISTINCT CONCAT(customers_firstname,' ',customers_lastname) as name, customers_firstname ,customers_lastname ,customers_email_address,customers_fax,customers_default_address_id, customers_customerProfileId,customers_telephone, customers_terms,customers_blind_ship_default,customers_terms_special,customers_ship_collect,customers_resale_tax_id_date,customers_resale_tax_id,customers_special_order_notes,customers_special_shipping_notes,customers_ups_acct,customers_fedex_acct,customers_ltl_capable,customers_invoice_email,customer_wholesale,customers_invoice_mail,customers_invoice_fax,customers_store_pickup_enabled,customers_custom_ship_date_enabled,customers_blind_ship_enabled,customers_ltl_capable,customers_group_pricing,customers_terms,c.customers_id 
			FROM customers c
			LEFT JOIN address_book ab ON ab.customers_id=c.customers_id LEFT JOIN customers_details cd ON cd.customers_id=c.customers_id 
			WHERE " . $search . "";
		$result = mysqli_query($zendb, $sql); //query the database for entries containing the term
		$result_data = mysqli_fetch_array($result);
	    $customers_default_address_id = $result_data['customers_default_address_id'];
		$cus_id = $result_data['customers_id'];
		$get_countryzone = "SELECT entry_country_id, entry_zone_id FROM address_book WHERE customers_id = '".$cus_id."' AND address_book_id = '".$customers_default_address_id."'";
		$countryzone_result = mysqli_query($zendb, $get_countryzone);
		$countzone = mysqli_num_rows($countryzone_result);
		$countzoneresult = mysqli_fetch_array($countryzone_result);
		$_SESSION['customer_country_id'] = $countzoneresult['entry_country_id'];
		$_SESSION['customer_zone_id'] = $countzoneresult['entry_zone_id'];
		$_SESSION['customer_id'] = $cus_id;
		//$_SESSION['customer_country_id'] = $countzoneresult['entry_country_id'];
		//$_SESSION['customer_zone_id'] = 0;
		
		/*if($result_data['customers_customerProfileId'] == ""){
			$processCIM = new processCIM;
			$customerPId = $processCIM->createcutomerProfile($customers_email_address);
			$result_data['customers_customerProfileId'] = $customerPId;
		}*/
		
		
		$search_results = array (
					'id'	=> $result_data['customers_id'],
					'name'	=> $result_data['name'],
					'customers_email_address'	=> $result_data['customers_email_address'],
					'customers_firstname'	=> $result_data['customers_firstname'],
					'customers_lastname'	=> $result_data['customers_lastname'],
					'customers_terms'	=> $result_data['customers_terms'],
					'customers_group_pricing'	=> $result_data['customers_group_pricing'],
					'customers_ltl_capable'	=> $result_data['customers_ltl_capable'],
					'customers_blind_ship_enabled'	=> $result_data['customers_blind_ship_enabled'],
					'customers_custom_ship_date_enabled'	=> $result_data['customers_custom_ship_date_enabled'],
					'customers_store_pickup_enabled'	=> $result_data['customers_store_pickup_enabled'],
					'customer_wholesale'	=> $result_data['customer_wholesale'],
					'customers_fedex_acct'	=> $result_data['customers_fedex_acct'],
					'customers_blind_ship_default'	=> $result_data['customers_blind_ship_default'],
					'customers_ltl_capable'	=> $result_data['customers_ltl_capable'],
					'customers_ups_acct'	=> $result_data['customers_ups_acct'],
					'customers_invoice_mail'	=> $result_data['customers_invoice_mail'],
					'customers_invoice_fax'	=> $result_data['customers_invoice_fax'],
					'customers_ship_collect'	=> $result_data['customers_ship_collect'],
					'customers_invoice_email'	=> $result_data['customers_invoice_email'],
					'customers_special_shipping_notes'	=> $result_data['customers_special_shipping_notes'],
					'customers_special_order_notes'	=> $result_data['customers_special_order_notes'],
					'customers_resale_tax_id'	=> $result_data['customers_resale_tax_id'],
					'customers_resale_tax_id_date'	=> $result_data['customers_resale_tax_id_date'],
					'customers_terms_special'	=> $result_data['customers_terms_special'],
					'customers_terms'	=> $result_data['customers_terms'],
					'customers_fax'	=> $result_data['customers_fax'],
					'customers_customerProfileId'	=> $result_data['customers_customerProfileId'],
					'customers_telephone'		=> $result_data['customers_telephone']
				);
				
				
	   return $search_results;
	}
	
	public function customerAuthId() {
		global $zendb;
		$customer_id = $_REQUEST['customer_id'];
		$customer_email = $_REQUEST['customer_email'];
		$processCIM = new processCIM;
		$customerPId = $processCIM->createcutomerProfile($customer_email);
		if($customerPId != 0)
		{
			$sql = "UPDATE customers SET customers_customerProfileId = '" . $customerPId . "' WHERE customers_id='".  $customer_id . "'";
			$result = mysqli_query($zendb, $sql);
		}
		return $customerPId;
	}
	
	/* cart search product */
	
	public function getcartProduct() 
	{
		global $zendb;
		
		$products_model = $_POST['products_model'];
		$customer_id = $_POST['customer_id'];
		$product_html = "";
		$get_product_detail = "SELECT products.products_id, products.products_quantity, products.products_model, products.products_price, products.products_qty_box_status, products_details.pack_desc, products_details.availability_status FROM products LEFT JOIN products_details ON products.products_id = products_details.products_id WHERE products.products_model = '".$products_model."'";
		
		$result = mysqli_query($zendb, $get_product_detail);
		$product = mysqli_fetch_array($result);
		
		$productDetailQry = "SELECT discount_code from products_details where products_id ='" . $product['products_id'] . "'";
		$productDetail = mysqli_query($zendb, $productDetailQry);
		$productDetailresult = mysqli_fetch_array($productDetail);
		$discount_code = $productDetailresult['discount_code'];
		
		if($discount_code != 0){
		$discountData = $this->calculate_discountIDsP($discount_code,$product['products_quantity'],$product['products_price']);
		//echo "<pre>";
		//print_r($discountData);
		//echo "</pre>";
		if($discountData['min_qty'] != 1){
			$QtyText = '<b class="p_qty_tag"><span class="qnty-spn">Qty 1</span> <span class="prioce_dfs">:</span> </b>';
			$listing_content .= $one_time .' '.$QtyText.'<b class="pprice">'. ((zen_has_product_attributes_values((int)$_GET['products_id']) and $flag_show_product_info_starting_at == 1) ? TEXT_BASE_PRICE : '') . zen_get_products_display_price($product_info->fields['products_id']).'</span></b>';   
		}
	}else{
		$listing_content .= $one_time .' '.'<b class="pprice">'. ((zen_has_product_attributes_values((int)$_GET['products_id']) and $flag_show_product_info_starting_at == 1) ? TEXT_BASE_PRICE : '') . zen_get_products_display_price($product_info->fields['products_id']).'</span></b>';  
	}
		
	//	$product_html .= '<script>$("#productable_id").DataTable();</script>';
	//		$product_html .= '<table id="productable_id" class="display">
	//			<thead><tr><th>Product Name</th><th>Availability</th><th>SKU</th><th>Price</th><th>Qty</th><th></th></tr></thead><tbody>';
	//		
	//			
	//				
	//				$product_html .= '<tr><td>'.$product['pack_desc'].'</td><td>';
	//				
	//				if(($product['availability_status'] == 1 || $product['availability_status']==2 || $product['availability_status']==3) && ($product['products_quantity']>5))
	//				{
	//					$product_html .= '<span class="pro_available in_stock"><span class="fa fa-check"></span> In stock</span>';
	//				}else if(($product['availability_status']==1) && ($product['products_quantity']>0) &&($product['products_quantity']<=5)){
	//					$product_html .= '<span class="pro_available in_stock"><span class="fa fa-check"></span> In stock</span>';
	//				}
	//				else if(($product['availability_status']==1) && ($product['products_quantity']<=0) )
	//				{	
	//					$product_html .= '<span class="pro_available limited_availability"><span class="fa fa-exclamation"></span> On Backorder</span>';
	//				}
	//				else if(($product['availability_status']==2) && ($product['products_quantity']>0) &&($product['products_quantity']<=5)){
	//					$product_html .= '<span class="pro_available limited_availability"><span class="fa fa-exclamation"></span> Limited Availability</span>';
	//				}
	//				else if($product['availability_status']==2 && $product['products_quantity']<=0 )
	//				{
	//					$product_html .= '<span class="pro_available limited_availability"><span class="fa fa-exclamation"></span> Limited Availability</span><br> <span class="pro_available made-to-order2"><span class="fa fa-clock-o"></span> Made to Order <a href="#" data-toggle="tooltip" data-placement="top" title="Order may be delayed" class="fa fa-info-circle" aria-hidden="true"></a> </span>';
	//				}
	//				$product_html .= '</td><td>'.$product['products_model'].'</td><td>'.$address['entry_lastname'].'</td><td>'.$address['entry_street_address'].'</td><td>'.$address['entry_suburb'].'</td><td>'.$address['entry_city'].'</td><td>'.$address['entry_state'].'</td><td>'.$address['entry_postcode'].'</td><td><a title="Edit" class="edit_address mr-3" href="JavaScript:void(0);" data-id="'.$address['address_book_id'].'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a><a title="Delete" class="delete_address" href="JavaScript:void(0);" data-id="'.$address['address_book_id'].'"><i class="fa fa-trash" aria-hidden="true"></i></a></td></tr>';
	//			
	//			
	//		
	//		$product_html .= '</tbody></table>';
		
	}
	
	public function calculate_discountIDsP($id,$qty,$price){
		global $zendb;
		$productDiscountQry = "SELECT * from products_discounts where id ='" . $id . "' order by discount_qty ASC";
		$productDiscount  = mysqli_query($zendb, $productDiscountQry);
		$productDiscountresult  = mysqli_fetch_array($productDiscount);
		$items = array();
		$productDiscountresult["max_qty"] = $this->getmaxQty($id);
		$productDiscountresult["min_qty"] = $this->getminQty($id);
		$productDiscountresult["max_dis"] = $this->getMaxDisct($id,$price);
		$productDiscountresult["min_dis"] = $this->getMinDisct($id,$price);
		
		return $productDiscountresult;  
	}
	
	public function getmaxQty($id){
		global $zendb;
		$productDiscountQry = "SELECT discount_qty from products_discounts where id ='" . $id . "' order by discount_qty DESC limit 1";
		$productDiscount = mysqli_query($zendb, $productDiscountQry);
		$productDiscountresult = mysqli_fetch_array($productDiscount);
		$items = $productDiscountresult["discount_qty"]; 
		
		return $items;  
	}
	
	public function getminQty($id){
		global $zendb;
		$productDiscountQry = "SELECT discount_qty from products_discounts where id ='" . $id . "' order by discount_qty ASC limit 1";
		$productDiscount = mysqli_query($zendb, $productDiscountQry);
		$productDiscountresult = mysqli_fetch_array($productDiscount);
		$items = $productDiscountresult["discount_qty"]; 
		
		return $items;  
	}
	
	
	
	public function getMaxDisct($id,$price){
		global $zendb;
		$productDiscountQry = "SELECT * from products_discounts where id ='" . $id . "' order by discount_qty DESC limit 1";
		$productDiscount   = mysqli_query($zendb, $productDiscountQry);
		$productDiscountresult = mysqli_fetch_array($productDiscount);
		$discountPct        = $productDiscountresult['discount_pct']; 
		$step               = $productDiscountresult['round_to_nearest']; 
		$totalDiscount      = round($price*($discountPct/100),2);
		$multiplicand       = round(( $totalDiscount / $step ),2);
		$rest               = fmod($totalDiscount,$step);
		if( $rest > $step/2 ) $multiplicand++; // round up if needed
		$roundedvalue       = round(( $step*$multiplicand),2);
		$totalDiscount      = $price-$roundedvalue;
		$TDis = $totalDiscount;
		return $TDis;  
	}
	
	public function getMinDisct($id,$price){
		global $zendb;
		$productDiscountQry = "SELECT * from products_discounts where id ='" . $id . "' order by discount_qty ASC limit 1";
		$productDiscount    = mysqli_query($zendb, $productDiscountQry);
		$productDiscountresult = mysqli_fetch_array($productDiscount);
		$discountPct        = $productDiscountresult['discount_pct']; 
		$step               = $productDiscountresult['round_to_nearest']; 
		$totalDiscount      = round($price*($discountPct/100),2);
		$multiplicand       = round(( $totalDiscount / $step ),2);
		$rest               = fmod($totalDiscount,$step);
		if( $rest > $step/2 ) $multiplicand++; // round up if needed
		$roundedvalue       = round(($step*$multiplicand),2);
		$totalDiscount      = $price-$roundedvalue;
		$TDis = $totalDiscount;
		return $TDis;  
	}
	public function updateDefaultaddrId() {
		global $zendb;
		$addsId 			= $_REQUEST["addressId"];
		$_SESSION['sendto'] = $addsId;
	}
	/* Update billing address */
	public function updateDefaultbillingAddressId() {
		global $zendb;
		$addsId = $_REQUEST["addressId"];
		$_SESSION['billto'] = $addsId;
		/*$addsId = $_REQUEST["addressId"];
		$customer_id = $_REQUEST["customerId"];
		$update_default_address = "UPDATE customers SET customers_default_address_id = '" . $addsId . "' WHERE customers_id='".  $customer_id . "'";
		mysqli_query($zendb, $update_default_address);*/
	}
	public function store_shippingSession()
	{
		$shipping_title = $_REQUEST['shipping_title'];
		$shipping_id= $_REQUEST['shipping_id'];
		$shipping_cost = $_REQUEST['shipping_cost'];
		$splitTaxclass 	   = $_REQUEST['splitTaxclass'];
		$splitTaxBasis 	   = $_REQUEST['splitTaxBasis'];
		if($splitTaxclass == 'no'){
			$splitTaxclass = 0;
		}
		if($splitTaxBasis == 'no'){
			$splitTaxBasis = 0;
		}
		if($_REQUEST['splitCost'] == "0.00"){
			$spcostArr = [];
		}else{
			$splitCost 	   = explode('&',rtrim($_REQUEST['splitCost'], '&'));
			$spcostArr = [];
			foreach($splitCost as $spCost){
				$spCostExp = explode('_',$spCost);
				$spVal = $spCostExp[1];
				if($spCostExp[1] == "no"){
					$spVal = '0.00';
				}
				$spcostArr[$spCostExp[0]] = $spVal;
			}
		}
		$_SESSION['shipping'] = array('id' => $shipping_id,'title' => $shipping_title,'cost' => $shipping_cost,'requested_ship_date' => 'special_shipping_instructions','par_cost' => $spcostArr,'tax_class' => $splitTaxclass,'tax_basis' => $splitTaxBasis);
		
		//echo "<pre>";print_r($_SESSION['shipping']);
	
	}
	
	public function taxCalculate(){
		$order = new order;
		$tax = $_REQUEST['taxVal'];
		$taxRes = $order->tax_calculation($tax);
		return $taxRes;
	}

	/*
	 * Get Order customer data using customer id
	 */
	 
	 public function orderCustomerData() {
		global $zendb,$rootPath;
		$orders_query = "SELECT o.orders_id, o.date_purchased, o.delivery_name,
                        o.delivery_country, o.billing_name, o.billing_country,
                        o.reorder, o.shipping_method,
                        ot.text as order_total,s.orders_status_name, d.tracking_number from orders o
LEFT JOIN orders_total ot on o.orders_id = ot.orders_id
LEFT JOIN orders_details d on d.orders_id = o.orders_id
LEFT JOIN orders_status s on o.orders_status = s.orders_status_id
where o.customers_id = ".$_REQUEST['customer_id']."
AND   s.language_id = '1'
AND ot.class = 'ot_total' ORDER BY orders_id DESC";
		$_records = mysqli_query($zendb,$orders_query);		
		$num_rec_per_page=8;
	    $page=$_REQUEST['page'];
		$start_from = ($page-1) * $num_rec_per_page;
		$total_records = mysqli_num_rows($_records);
		$total_pages = ceil($total_records / $num_rec_per_page);		
		$limit = "limit $start_from, $num_rec_per_page";	
		
		
		

$orders_query = "SELECT o.orders_id, o.date_purchased, o.delivery_name,
                        o.delivery_country, o.billing_name, o.billing_country,
                        o.reorder, o.shipping_method,
                        ot.text as order_total,s.orders_status_name, d.tracking_number from orders o
						LEFT JOIN orders_total ot on o.orders_id = ot.orders_id
						LEFT JOIN orders_details d on d.orders_id = o.orders_id
						LEFT JOIN orders_status s on o.orders_status = s.orders_status_id
						where o.customers_id = ".$_REQUEST['customer_id']."
						AND   s.language_id = '1'
						AND ot.class = 'ot_total' ORDER BY orders_id DESC ".$limit;
						
						
		$ordersres = mysqli_query($zendb,$orders_query);

		$ordersArray = array();
		while ($orders = mysqli_fetch_array($ordersres)) {
		  if (!empty($orders['delivery_name'])) {
			$order_name = $orders['delivery_name'];
			$order_country = $orders['delivery_country'];
		  } else {
			$order_name = $orders['billing_name'];
			$order_country = $orders['billing_country'];
		  }

		  $ordersArray[] = array('orders_id'=>$orders['orders_id'],
		  'date_purchased'=>$orders['date_purchased'],
		  'order_name'=>$order_name,
		  'order_country'=>$order_country,
		  'orders_status_name'=>$orders['orders_status_name'],
		  'shipping_method'=>$orders['shipping_method'],
		  'tracking_number'=>$orders['tracking_number'],
		  'reorder'=>$orders['reorder'],
		  'order_total'=>$orders['order_total']
		  );
		}
		include_once($rootPath.'constant/shipping.php');
		include_once($rootPath.'constant/language/english.php');

 $orderHtml = '';
$orderHtml .= '<div class="table-responsive customer-orders">
<h5 class="form-title mb-3 mt-3">Order Records</h5>
<table class="table table-sm table-middle text-center customer-orders">
    <thead>
    <tr class="tableHeading">
		<th scope="col">'.TABLE_HEADING_DATE.'</th>
		<th scope="col">'.TABLE_HEADING_ORDER_NUMBER.'</th>
		<th scope="col">'.TABLE_HEADING_SHIPPED_TO.'</th>
		<th scope="col">Tracking</th>
		<th scope="col">'. TABLE_HEADING_STATUS.'</th>
		<th scope="col">'.TABLE_HEADING_TOTAL.'</th>
		<th scope="col">'.TABLE_HEADING_VIEW.'</th>
	</tr>
 </thead>
 <tbody class="customer_orders">';
$inc = 0;
$cid = $_SESSION['customer_id'];
  foreach($ordersArray as $orders) {
	  	$tno=$orders['tracking_number'];
				$tracking_link='';
					 
				if (preg_match('/FedEx/',$orders['shipping_method'])){
					if($tno!=''){
						$imglink='<img src="'.DIR_WS_IMAGES.'/fedex.jpg">';
						$tracking_link='<a target="_blank" href="https://www.fedex.com/apps/fedextrack/?tracknumbers='.$tno.'">'.$imglink.$tno.'</a>';
					}
				}
				else if (preg_match('/United States Postal Service/',$orders['shipping_method'])){
					if($tno!=''){
						$imglink='<img src="'.DIR_WS_IMAGES.'/usps.jpg">'; 
						$tracking_link='<a target="_blank" href="https://tools.usps.com/go/TrackConfirmAction?tLabels='.$tno.'">'.$imglink.$tno.'</a>';
					}
				}
				else if (preg_match('/United Parcel Service/',$orders['shipping_method'])){
					if($tno!=''){
						$imglink='<img src="'.DIR_WS_IMAGES.'/ups.jpg">';
						$tracking_link='<a target="_blank" href="https://wwwapps.ups.com/WebTracking/track?track=yes&trackNums='.$tno.'">'.$imglink.$tno.'</a>';
					}
				}	
				else if (preg_match('/Store Pickup/',$orders['shipping_method'])){
					if($tno!=''){
						$tracking_link='PICKED UP '.$tno;
					}
				}
				
				$datePurchased = date('m/d/Y',strtotime($orders['date_purchased']));
				$orderId = $orders['orders_id'];
				$order_name = $orders['order_name'];
				$order_country = $orders['order_country'];
				$orders_status_name = $orders['orders_status_name'];
				$order_total = $orders['order_total'];
				
		//// End Braj ////////		
  $orderHtml .= '<tr>
    <td width="100px" align="center">'.$datePurchased.'</td>
    <td width="100px" align="center">#'. $orderId.'</td>
    <td align="center"><address>'.$order_name . '--' .$order_country.'</address></td>   
    <td width="200px" align="center">'.$tracking_link.'</td>
    <td width="200px" align="center">'.$orders_status_name.'</td>
    <td width="100px" align="center">'.$order_total.'</td>
    <td width="75px"><a class="btn btn-info" href="javascript:void(0)" onclick="getsingleOrder('.$orderId.','.$cid.')"> View</a></td>
  </tr>';
$inc++;
  }
  if($inc == 0){
	  $orderHtml .= "<tr><td colspan='7'><p>No Orders Available</p></td></tr>";
	  }

		$_page_start = 1;
		$_page_end = $total_pages;		
		$next_page = $page;
		$next_page++;
  
$orderHtml .='</tbody>
</table>
<div class="paging">';

if($page<$_page_end)
{
  $orderHtml .='<button type="button" class="show_more-orders float-right btn btn-success mb-3" onclick=\'getordercustomerData('.$cid.','.$next_page.')\'>Show More Orders</button>';
}

$orderHtml .='</div>
</div>';
return array('html' => $orderHtml);

	}
	
	function orderData(){
		global $zendb;
		$order_id 	 = $_REQUEST['order_id'];
		$customer_id = $_REQUEST['customer_id'];
		$html = '';
		
		   $orderQry 			= "select * from orders where orders_id =".$order_id;
		   $orderRes  			= mysqli_query($zendb, $orderQry);
		   if($orderRes){
				$ordeRow				= mysqli_fetch_array($orderRes);
				/*
				 * 
				 * Order Products Query
				 * 
				 * 
				 * */
				$orderproductQry 			= "select * from orders_products where orders_id =".$order_id;
				$orderproductRes  			= mysqli_query($zendb, $orderproductQry);
				$productsHtml 	= '';
				$orderDate 		= date('m/d/Y',strtotime($ordeRow['date_purchased']));
				$orderDate2 	= date('m/d/Y',strtotime($ordeRow['date_purchased']));
				$orderTotal 	= $ordeRow['order_total'];
				
				/* 
				 * 
				 * Delivery address
				 * 
				 *  */
				$delivery_name = $ordeRow['delivery_name'];
				$delivery_company = $ordeRow['delivery_company'];
				$delivery_street_address = $ordeRow['delivery_street_address'];
				$delivery_suburb = $ordeRow['delivery_suburb'];
				$delivery_city = $ordeRow['delivery_city'];
				$delivery_state = $ordeRow['delivery_state'];
				$delivery_postcode = $ordeRow['delivery_postcode'];
				$delivery_country = $ordeRow['delivery_country'];
				
				
				/* 
				 * 
				 * Billing address 
				 * 
				 * */
				$billing_name = $ordeRow['billing_name'];
				$billing_company = $ordeRow['billing_company'];
				$billing_street_address = $ordeRow['billing_street_address'];
				$billing_suburb = $ordeRow['billing_suburb'];
				$billing_city = $ordeRow['billing_city'];
				$billing_postcode = $ordeRow['billing_postcode'];
				$billing_state = $ordeRow['billing_state'];
				$billing_country = $ordeRow['billing_country'];
				
				/* 
				 * 
				 * Shipping
				 * 
				 *  */
				$shipping_method = $ordeRow['shipping_method'];
				
				/* 
				 * 
				 * Payment 
				 * 
				 * */
				$payment_method = $ordeRow['payment_method'];
				
				/*
				 * 
				 * Order Status history
				 *
				 */
				 
				$orderstatusQry 			= "select a.comments as comments,b.orders_status_name as status_name from orders_status_history as a LEFT JOIN orders_status as b on a.orders_status_id = b.orders_status_id where a.orders_id =".$order_id;
				$orderstatusRes  			= mysqli_query($zendb, $orderstatusQry);
				$orderstatusRow = mysqli_fetch_array($orderstatusRes);
			   
				$orderStatus    = $orderstatusRow['status_name'];
				$orderComments    = $orderstatusRow['comments'];
				while($row = mysqli_fetch_array($orderproductRes)){
					$pModel = $row['products_model'];
					$products_quantity = $row['products_quantity'];
					$products_name = $row['products_name'];
					$products_price = $row['final_price'];
					$pModel = $row['products_model'];
					$productsHtml .= '<tr>
						<td>'.$pModel.'</td>
						<td class="accountQuantityDisplay">'.$products_quantity.'&nbsp;ea.</td>
						<td class="accountProductDisplay">'.$products_name.'</td>
						<td class="accountTotalDisplay">$'.number_format((float)$products_price*$products_quantity, 2, '.', '').'</td>
					  </tr>';
				}
				
				$orderTotalQry 			= "select * from orders_total where orders_id =".$order_id;
				$orderTotalRes  			= mysqli_query($zendb, $orderTotalQry);
				
				while($orderTotalRows = mysqli_fetch_array($orderTotalRes)){
					$allTotals[] = $orderTotalRows;
				}
				if($this->chekcOrder($allTotals)){
					foreach($allTotals as $key => $value){
						if($value["class"] == "ot_tax"){
							$txArr = $allTotals[$key];
							$txKy = $key;
							unset($allTotals[$key]);
						}
						if($value["title"] == "Sub-Total:"){
							$subtArr = $allTotals[$key];
							$subKy = $key;
							unset($allTotals[$key]);
						}
					}
					$allTotals[$subKy] = $txArr;
					$allTotals[$txKy] = $subtArr;
					ksort($allTotals);
				}
				$html .= '<div class="wrapper">
		  <div class="customer-wrap">
			<div class="containerm">
			  <div class="centerColumn">
			  <div class="mt-2"><a href="javascript:void(0)" onclick="getordercustomerData('.$customer_id.')">Return Back</a></div>
				<div class="d-between top-head">
				  <h4 class="mb-0">Order Information&nbsp;-&nbsp;Order #'.$order_id.'</h4>
				  <h4 class="mb-0"> Order Date: '.$orderDate.'</h4>
				</div>
				<div class="table-responsive mb-3">
				  <table class="table table-sm mb-0 order-table table-middle">
					<thead class="thead-dark">
					  <tr>
						<th>Part No</th>
						<th>Qty.</th>
						<th>Products</th>
						<th>Total</th>
					  </tr>
					</thead>
					<tbody>
					 '.$productsHtml.'
					</tbody>
				  </table>
				</div>
				<div class="orderTotals d-flex justify-content-end"><div class="w-100">';
						if($orderTotalRes){				
							 foreach($allTotals as $orderTotals) {
								 $html .='<div class="d-between"><b>'.$orderTotals['title'].'</b>
								 <span>'.$orderTotals['text'].'</span></div>
								';
							 }
						}
				$html .='</div></div>
				<div class="table-responsive mb-4">
				  <table class="table table-sm table-middle">
					<tbody>
					  <tr class="thead-dark">
						<th>Date</th>
						<th>Order Status</th>
						<th>Comments</th>
					  </tr>
					  <tr>
						<td>'.$orderDate2.'</td>
						<td>'.$orderStatus.'</td>
						<td>'.$orderComments.'</td> 
					  </tr>
					</tbody>
				  </table>
				</div>
				
				<h2 class="orderHistoryStatus">Status History &amp; Comments</h2>
				<div class="auto-hight"></div>
				<div class="row">
				  <div class="col-md-6 ">
					<div class="my-account-links">
					  <div class="card-box">
						<h2>Delivery Address</h2>
						<address>';
						if($delivery_company != ""){
							$html .=''.$delivery_company.'<br>';
						}
						if($delivery_name != ""){
							$html .=''.$delivery_name.' <br>';
						}
						if($delivery_street_address != ""){
							$html .=''.$delivery_street_address.' <br>';
						}
						$html .= ''.$delivery_city.', '.$delivery_state.'    '.$delivery_postcode.'<br> '.$delivery_country.'</address>
					  </div>
					  <div class="card-box">                  
						<h2>Shipping Method</h2>
						<div>'.$shipping_method.'</div>
					  </div>
					</div>
				  </div>
				  <div class="col-md-6 my-account-links">
					<div class="card-box">
					  <h2>Billing Address</h2>
					  <address>';
					    if($billing_company != ""){
							$html .=''.$billing_company.'<br>';
						}
						if($billing_name != ""){
							$html .=''.$billing_name.' <br>';
						}
						if($billing_street_address != ""){
							$html .=''.$billing_street_address.' <br>';
						}
					  
						$html .= ''.$billing_city.', '.$billing_state.'    '.$billing_postcode.'
						<br> '.$billing_country.'
					  </address>
					</div>
					<div class="card-box">
					  <h2>Payment Method</h2>
					  <div>'.$payment_method.'</div>
					</div>
				  </div>
				</div>
			  </div>
			</div>
		  </div><!-- Customer wrap closed -->
		</div><!-- wrapper closed -->';
		   }

		return array('html' => $html);
	}
	
	
	function chekcOrder($allTotals){
		foreach($allTotals as $key => $value){
			if($value["class"] == "ot_tax"){
				$txArr = $allTotals[$key];
				$txKy = $key;
				$totId = $value["orders_total_id"];
				unset($allTotals[$key]);
			}
			if($value["title"] == "Sub-Total:"){
				$sotId = $value["orders_total_id"];
				$subtArr = $allTotals[$key];
				$subKy = $key;
				unset($allTotals[$key]);
			}
		}
	    if((isset($totId) && isset($sotId)) && $totId < $sotId){
			return true;
		}else{
			return false;
		}	
	}
	
	 function moveKeyBefore($arr, $find, $move) {
		if (!isset($arr[$find], $arr[$move])) {
				return $arr;
			}

			$elem = [$move=>$arr[$move]];  // cache the element to be moved
			$start = array_splice($arr, 0, array_search($find, array_keys($arr)));
			unset($start[$move]);  // only important if $move is in $start
			return $start + $elem + $arr;
	  }
}

?>
