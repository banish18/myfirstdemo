<?php


/**
 * zcProductDetail
 *
 * @package templateSystem
 * @copyright Copyright 2003-2014 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: Ian Wilson  New in v1.5.4 $
 */
require_once('../db/db.inc');
require_once('payment/function.php');
require_once('document_general_info.php');
require('includes/classes/shipping.php');
require('payment/authorizenet_cim.php');
class zcProductDetail
{
	public function cartTable() {
		global $zendb,$rootPath;
		$store = "Holiday Manufacturing Inc";
		$cart_html = "";
		$customer_id = $_REQUEST["customerId"];
		$get_customerholiday_cart = "SELECT products_id,customers_basket_quantity,store_type FROM customers_basket where customers_id ='".$customer_id."' AND store_type='Holiday Manufacturing Inc' order by customers_basket_id";
		
		
		
		$get_customerspacial_cart = "SELECT products_id,customers_basket_quantity,store_type FROM customers_basket where customers_id ='".$customer_id."' AND store_type='Specialitywrap' order by customers_basket_id";
		
		$holidayresult = mysqli_query($zendb, $get_customerholiday_cart);
		$holidaycountresult = mysqli_num_rows($holidayresult);
		
		
		if($holidaycountresult > 0)
		{
			$status = [];
			$subtotal1 = 0; 
		     $cart_html .= '<h5 class="text-primary ml-3">Store Name: Holiday Manufacturing Inc</h5>';
			 $shoppingCart = new shoppingCart();
			 while ($cartproduct = mysqli_fetch_array($holidayresult)) {
				  $pid  = $cartproduct['products_id'];
				  $qtty = $cartproduct['customers_basket_quantity'];
				  $status[$pid] = $shoppingCart->update_quantity($pid,$qtty);
			 }
			  $alStat = [];
			  $stutsHtml = '';
			  foreach($status as $key => $value){
				  $stat = explode("_",$value);
				  $productSku = $this->get_product_sku($key);
				  $alStat[$key] = $stat[1];
				  if($stat[0] == "3"){
					  $stutsHtml .= '<span>'.$productSku.' - Quantity ordered exceeds current inventory. Order may be delayed due to backorder.</span><br />';
				  }elseif($stat[0] == "2"){
					  $stutsHtml .= '<span>'.$productSku.' - Quantity ordered exceeds current inventory. Order adjusted to reflect availability.</span><br />';
				  }
			  }
			if($stutsHtml != ""){
				$cart_html .= '<div class="p-2 m-2 text-center perrmsg">'.$stutsHtml.'</div>';
			}
			$cart_html .= '<script>$("#carttable").DataTable();</script>';
			$cart_html .= '<table id="carttable" class="table table-striped">
				<thead><tr><th>SKU</th><th>Qty</th><th>Old SKU</th><th>Price</th><th>Total</th</tr></thead><tbody>';
			$t_price   = "0";
			$holidayresult = mysqli_query($zendb, $get_customerholiday_cart);
			while ($cartproduct = mysqli_fetch_array($holidayresult)) {
				$totalCart = "0";
				$productId = $cartproduct['products_id'];
				$qty = $cartproduct['customers_basket_quantity'];
				$productDetail = $this->getproduct($productId);
				$sku_old = $productDetail["sku_old"];
				$price = round($productDetail["products_price"], 2);
				
				/* New code start */
				$ppe = $price;
				 /* $ppe = zen_round(zen_add_tax($ppe, zen_get_tax_rate($products[$i]['tax_class_id'])), $currencies->get_decimal_places($_SESSION['currency']));*/
					/* get and calculate discount products particularly */
					  /* Get Product discount code */
				$productTypelabels = $this->getproductTypes($ppe,$productId,$qty);	  
				$res = 	$this->productPrice($ppe,$productId,$qty);
				$prSKU = $productDetail["products_model"];; 
				$t_price = $t_price+str_replace('$','',$res["total_price"]);
				$cart_html .= '<tr><td>'.$prSKU.' <span class="not_txt">'.($productTypelabels?$productTypelabels:'').'</span></td><td>'.$qty.'</td><td>'.$sku_old.'</td><td>'.$res["product_price"].'</td><td>'.$res["total_price"].'</td></tr>';
				
				
			}
			$cart_html .= '</tbody></table>';
			$cart_html .=  "<div class='text-right text-primary mt-3 font-weight-bold'>Total: $".number_format($t_price, 2, '.', '').'</div>';
			$cart_html .= '<div class="text-right"><a href="JavaScript:void(0);" data-store="Holiday Manufacturing Inc" data-cusID = "'.$customer_id.'" class="cart-submit btn btn-primary" >Continue checkout</a></div>';
			
		}
		$spacialresult = mysqli_query($zendb, $get_customerspacial_cart);
		$spacialcountresult = mysqli_num_rows($spacialresult);
		$scart_html = '';
		if($spacialcountresult > 0)
		{
			$subtotal1 = 0; 
			$status = [];
			$scart_html .= '<h5 class="text-primary ml-3">Store Name: Specialitywrap</h5>';
			 $shoppingCart = new shoppingCart();
			 while ($cartproduct = mysqli_fetch_array($spacialresult)) {
				  $pid  = $cartproduct['products_id'];
				  $qtty = $cartproduct['customers_basket_quantity'];
				  $status[$pid] = $shoppingCart->update_quantity($pid,$qtty);
			 }
			  $alStat = [];
			  $stutsHtml = '';
			  foreach($status as $key => $value){
				  $stat = explode("_",$value);
				  $productSku = $this->get_product_sku($key);
				  $alStat[$key] = $stat[1];
				  if($stat[0] == "3"){
					  $stutsHtml .= '<span>'.$productSku.' - Quantity ordered exceeds current inventory. Order may be delayed due to backorder.</span><br />';
				  }elseif($stat[0] == "2"){
					  $stutsHtml .= '<span>'.$productSku.' - Quantity ordered exceeds current inventory. Order adjusted to reflect availability.</span><br />';
				  }
			  }
			 if($stutsHtml != ""){
				$scart_html .= '<div class="p-2 m-2 text-center perrmsg">'.$stutsHtml.'</div>';
			 }
			$scart_html .= '<script>$("#spacialitycarttable").DataTable();</script>';
			$scart_html .= '<table id="spacialitycarttable" class="table table-striped">
				<thead><tr><th>SKU</th><th>Qty</th><th>Old SKU</th><th>Price</th><th>Total</th</tr></thead><tbody>';
			$t_price   = "0";
			$spacialresults = mysqli_query($zendb, $get_customerspacial_cart);
			while ($cartproduct = mysqli_fetch_array($spacialresults)) {
				$totalCart = "0";
				$productId = $cartproduct['products_id'];
				$qty = $cartproduct['customers_basket_quantity'];
				$productDetail = $this->getproduct($productId);
				
				/* Label text */
				
				$sku_old = $productDetail["sku_old"];
				$price = round($productDetail["products_price"], 2);
				
				/* New code start */
				$ppe = $price;
				$productTypelabels = $this->getproductTypes($ppe,$productId,$qty);
				 /* $ppe = zen_round(zen_add_tax($ppe, zen_get_tax_rate($products[$i]['tax_class_id'])), $currencies->get_decimal_places($_SESSION['currency']));*/
					/* get and calculate discount products particularly */
					  /* Get Product discount code */
				$res = 	$this->productPrice($ppe,$productId,$qty);
				$prSKU = $productDetail["products_model"];
				$t_price = $t_price+str_replace('$','',$res["total_price"]);
				$scart_html .= '<tr><td>'.$prSKU.' <span class="not_txt">'.($productTypelabels?$productTypelabels:'').'</span></td><td>'.$qty.'</td><td>'.$sku_old.'</td><td>'.$res["product_price"].'</td><td>'.$res["total_price"].'</td></tr>';
			}
			$scart_html .= '</tbody></table>';
			$scart_html .=  "<div class='text-right text-primary mt-3 font-weight-bold'>Total: $".number_format($t_price, 2, '.', '').'</div>';
			$scart_html .= '<div class="text-right"><a href="JavaScript:void(0);" data-store="Specialitywrap" data-cusID = "'.$customer_id.'" class="cart-submit btn btn-primary" >Continue checkout</a></div>';
			
		}
		if(($spacialcountresult == 0))
		{
			$scart_html .= 'Cart is empty !!';
			$scart_html .= '<div class="text-right"><a href="JavaScript:void(0);" data-store="Specialitywrap" data-cusID = "'.$customer_id.'" class="cart-submit btn btn-primary" >Checkout</a></div>';
			$showsDv = '';
		}else{
			$showsDv = 'show';
		}
		if($holidaycountresult == 0){
			$cart_html .= 'Cart is empty !!';
			$cart_html .= '<div class="text-right"> <a href="JavaScript:void(0);" data-store="Holiday Manufacturing Inc" data-cusID = "'.$customer_id.'" class="cart-submit btn btn-primary" >Checkout</a></div>';
			$showhDv = '';
		}else{
			$showhDv = 'show';
		}
		$html = '<!--Accordion wrapper-->
					<div class="accordion md-accordion" id="accordionEx" role="tablist" aria-multiselectable="true">

					  <!-- Accordion card -->
					  <div class="card">

						<!-- Card header -->
						<div class="card-header" role="tab" id="headingOne1">
						  <a data-toggle="collapse" data-parent="#accordionEx" href="#collapseOne1" aria-expanded="true"
							aria-controls="collapseOne1">
							<h5 class="mb-0">
							  <b>Countinue Checkout with Specialitywrap</b> <i class="fa fa-angle-down rotate-icon float-right shipIcon"></i>
							</h5>
						  </a>
						</div>

						<!-- Card body -->
						<div id="collapseOne1" class="collapse '.$showsDv.'" role="tabpanel" aria-labelledby="headingOne1"
						  data-parent="#accordionEx">
						  <div class="card-body">
							'.$scart_html.'
						  </div>
						</div>

					  </div>
					  <!-- Accordion card -->

					  <!-- Accordion card -->
					  <div class="card">

						<!-- Card header -->
						<div class="card-header" role="tab" id="headingTwo2">
						  <a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapseTwo2"
							aria-expanded="false" aria-controls="collapseTwo2">
							<h5 class="mb-0">
							  <b>Countinue Checkout with Holidaybows </b><i class="fa fa-angle-down rotate-icon float-right"></i>
							</h5>
						  </a>
						</div>

						<!-- Card body -->
						<div id="collapseTwo2" class="collapse '.$showhDv.'" role="tabpanel" aria-labelledby="headingTwo2"
						  data-parent="#accordionEx">
						  <div class="card-body">
							'.$cart_html.'
						  </div>
						</div>';
		
		return $html;
	} 
	
	public function getproductTypes($ppe,$productId,$qty){
		global $zendb;
		$pro_normal_price = zen_get_products_base_price($productId);
	   $pro_special_price = zen_get_products_special_price($productId, true);
	   $pro_sale_price = zen_get_products_special_price($productId, false);  
		$productDetailQry = "SELECT discount_code
				  from products_details
				  where products_id ='" . $productId . "'";
		$productDetail = mysqli_query($zendb,$productDetailQry);
		$productDetail = mysqli_fetch_array($productDetail);
		$discount_code = $productDetail['discount_code'];
		$discountCodeData = $this->calculate_discountCodeID($discount_code);
		$label = '';
		if($pro_special_price !="")
		{
		  $label = SALE_TEXT;
		}
		elseif($pro_sale_price != "")
		{
		  $label = SALE_TEXT;
		}
		else
		{
		  $ppt = $ppe * $qty;
		  if($discount_code != 0){
			$totalAmt = $ppe*$qty;
			$discount = $this->calculate_discount($discount_code,$ppe,$qty,$totalAmt); 
			
			if(count($discount) > 0){
				$label = DISCOUNT_CODE_TEXT.' '.$discount['discount_pct'].'%';
			}else{
				if(($qty >= $discountCodeData['minProductQuantity'])&&($qty < $discountCodeData['maxProductQuantity'])){
					$label = DISCOUNT_CODE_TEXT .' '.$discountCodeData['minProductQuantityPercentage'].'%';	 
				}
				if($qty >= $discountCodeData['maxProductQuantity']){
					$label = DISCOUNT_CODE_TEXT .' '.$discountCodeData['maxProductQuantityPercentage'].'%';	
				}
			}
		  }
		}
		
		return $label;
					
	}
	
	public function getproduct($pid)
	{
		 global $zendb;
		 
		 $products_query = "select p.products_id, p.master_categories_id, p.products_status, pd.products_name, pd.products_description, p.products_model, p.products_image, p.products_price, p.products_weight, p.products_tax_class_id,p.products_quantity_order_min, p.products_quantity_order_units, p.products_quantity_order_max,p.product_is_free, p.products_priced_by_attribute,p.products_discount_type, p.products_discount_type_from, p.products_virtual, p.product_is_always_free_shipping, pdet.pack_length, pdet.pack_width, pdet. pack_height, pdet.pack_type, pdet.sku_old,pdet.warehouse_id,pdet.discount_code from products  p,products_description pd, products_details pdet where p.products_id = '" .$pid . "' and pd.products_id = p.products_id and pdet.products_id = p.products_id";
		 $result = mysqli_query($zendb, $products_query);
		 $productArray = mysqli_fetch_array($result);
		 return $productArray;
		 
	}
	
	public function get_product()
	{
		 $pid = $_REQUEST["product_id"];
		 $result = $this->getproduct($pid);
		 $productPrice = $this->productPrice($result['products_price'],$result['products_id'],'1');
		 
		 $result['products_price'] = $productPrice['product_price'];
		 $result['total_price'] 	= $productPrice['total_price'];
		 return json_encode($result);
		 
	}
	
	public function store_cart()
	{
		/*ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);*/
		global $zendb,$rootPath;
		/*require($rootPath.'includes/classes/order.php');
		$order =  new order;
		echo "<pre>";print_r($order->info['ordertotal']);
		die;*/
		$cart_html = "";
		$cart_totl = 0.00;
		$store_name = $_REQUEST["store_type"];
		$customerId = $_REQUEST["customerId"];
		$_SESSION['store_type'] = $store_name;
		$shoppingCart = new shoppingCart();
		
		$get_customer_cart = "SELECT products_id,customers_basket_quantity,store_type FROM customers_basket where customers_id ='".$customerId."' AND store_type='".$store_name."'";
		
		$get_customer_default_addr = "SELECT customers_customerProfileId,customers_customerPaymentProfileId,customers_customerShippingAddressId,customers_default_address_id FROM `customers` where customers_id = '".$customerId."'";
		$addr_result = mysqli_query($zendb, $get_customer_default_addr);

		$defaultaddr_array = mysqli_fetch_array($addr_result);
		$default_addrId = $defaultaddr_array['customers_default_address_id'];
		$default_baddrId  = $defaultaddr_array['customers_default_address_id'];;
		$customers_customerProfileId = $defaultaddr_array['customers_customerProfileId'];
		$customers_customerPaymentProfileId = $defaultaddr_array['customers_customerPaymentProfileId'];
		$customers_customerShippingAddressId = $defaultaddr_array['customers_customerShippingAddressId'];
		$result = mysqli_query($zendb, $get_customer_cart);
		$countresult = mysqli_num_rows($result);
		
		/* get customer terms */
		$get_customer_default = "SELECT customers_terms FROM `customers_details` where customers_id = '".$customerId."'";
		$cust_result = mysqli_query($zendb, $get_customer_default);
		$custdetar_array = mysqli_fetch_array($cust_result);
		
		/*pending */
		if(isset($_SESSION['sendto']) && isset($_SESSION['billto'])) {
			if($_SESSION['sendto'] == ""){
				$_SESSION['sendto'] = $default_addrId;
			}else{
				$default_addrId = $_SESSION['sendto'];
			}
			if($_SESSION['billto'] == ""){
				$_SESSION['billto'] = $default_addrId;
			}else{
				$default_baddrId = $_SESSION['billto'];
			}
		}else{
			$_SESSION['sendto'] = $default_addrId;
			$_SESSION['billto'] = $default_addrId;
		}
		/*echo $_SESSION['sendto'];
		echo $_SESSION['billto'];*/
		$_SESSION['customers_ip_address'] = $_SERVER['REMOTE_ADDR'];
		$_SESSION['cart'] = $shoppingCart->calculate();
		/*pending */
		
		$getCartTotl = "select total from cart_total where cid = '".$customerId."'";
		$cartotl_result = mysqli_query($zendb, $getCartTotl);
		$cartotl_rowfetch = mysqli_fetch_array($cartotl_result);
		if(!empty($cartotl_rowfetch))
		{
			$cart_totl = $cartotl_rowfetch['total'];
		}
		
		$_SESSION['cart_total'] = $cart_totl;
		
		
		$cart_html .= '<h5 class="text-primary m-l3">Store Name: <b id="store_name">'.$store_name.'</b></h5>';
		$cart_html .= '<script>$("#newordertable").DataTable();</script>';
		
		$cart_html .= '<div class="col-lg-12 shipping_method d-md-flex mb-4"><div class="col-lg-12 bg-gary"><div class="row"><div class="col-lg-12"><div class="row border"><div class="col-lg-3 bg-gray m-2 p-2"><div class="step-title b-title"><b>Ship to Address:</b></div>';
		
			$get_addr_detail = "SELECT  ab.address_book_id, entry_company, entry_firstname, entry_lastname, entry_street_address, entry_suburb, entry_postcode, entry_city, entry_state, entry_country_id, 	zone_code, blind_shipping, ups_validated, fedex_validated, ups_residential, fedex_residential, blind_ship_to, dropship_fee, dropship_fee_threshhold FROM address_book ab LEFT JOIN address_details ad ON ab.address_book_id = ad.address_book_id
			LEFT JOIN zones z on ab.entry_zone_id=z.zone_id WHERE ab.customers_id = '". $customerId ."'";
			
			
			$addrdetail_result = mysqli_query($zendb, $get_addr_detail);
			$cart_html .= '<div class="address">';
			$cart_html .= '<select name="shippingaddress" id="shippingaddress" class="custom-select custom-select-sm">';
			$preDdata = "";
			while ($addrdetail_array = mysqli_fetch_array($addrdetail_result)) {
				$dataVl = $addrdetail_array['entry_street_address']."<br>".$addrdetail_array['entry_city']." ".$addrdetail_array['zone_code']." ".$addrdetail_array['entry_postcode'];
				
				$cart_html .=  '<option data-id="'.$dataVl.'" value="'.$addrdetail_array['address_book_id'].'"'; 
				if($addrdetail_array['address_book_id'] == $default_addrId)
				{
					$cart_html .= 'selected = selected';
					$preDdata = $dataVl;
				}
				$cart_html .= '>';
				$cart_html .= $addrdetail_array['entry_firstname']." ". $addrdetail_array['entry_lastname'];
				$cart_html .= '</option>';
			}
			$cart_html .= '</select>
			<div class="mt-2" id="shipAdd">
				'.$preDdata.'
			</div>';
			$cart_html .= '<div class="ship_methodl">';
			$cart_html .= $this->getShipping($countresult);
			
		/*row div close */
		$cart_html .= '</div></div></div>
		
		<div class="col-lg-3 bg-gray m-2 p-2"><div class="step-title b-title"><b>Bill to Address:</b></div>
		<select name="billingaddress" id="billingaddress" class="custom-select custom-select-sm">';
			$get_addr_detail = "SELECT  ab.address_book_id, entry_company, entry_firstname, entry_lastname, entry_street_address, entry_suburb, entry_postcode, entry_city, entry_state, entry_country_id, 	zone_code, blind_shipping, ups_validated, fedex_validated, ups_residential, fedex_residential, blind_ship_to, dropship_fee, dropship_fee_threshhold FROM address_book ab LEFT JOIN address_details ad ON ab.address_book_id = ad.address_book_id
			LEFT JOIN zones z on ab.entry_zone_id=z.zone_id WHERE ab.customers_id = '". $customerId ."'";
			$addrdetail_result = mysqli_query($zendb, $get_addr_detail);
			while ($baddrdetail_array = mysqli_fetch_array($addrdetail_result)) {
				$dataVl = $baddrdetail_array['entry_street_address']."<br>".$baddrdetail_array['entry_city']." ".$baddrdetail_array['zone_code']." ".$baddrdetail_array['entry_postcode'];
				
				$cart_html .=  '<option data-id="'.$dataVl.'" value="'.$baddrdetail_array['address_book_id'].'"'; 
				if($baddrdetail_array['address_book_id'] == $default_baddrId)
				{
					$cart_html .= 'selected = selected';
					$prebilData = $dataVl;
				}
				$cart_html .= '>';
				$cart_html .= $baddrdetail_array['entry_firstname']." ". $baddrdetail_array['entry_lastname'];
				$cart_html .= '</option>';
			}
			$cart_html .= '</select><div class="mt-2" id="billAdd">
				'.$prebilData.'
			</div>
			
			
		</div>
		<div class="col-lg-5 bg-gray m-2 p-2">
			<div class="row">
				<div class="col-lg-8">
				<div class="step-title b-title"><b>Payment Method</b></div>';
		$payment = new authorizenet_cim_new;
		$selection = $payment->selection();	
		$cart_html .= "<div class='card_details_fields'><input type='radio' checked name='paymentmethod' id='credit_card' />";
		for ($j=0, $n2=sizeof($selection['fields']); $j<$n2; $j++) {
			$cart_html .= $selection['fields'][$j]['field'];
			$cart_html .= '<div class="clearBoth"></div>';

		}
		$cart_html .= '
		<div class="row">
			<div class="col-lg-6 cod_pay"><input type="radio" name="paymentmethod" id="cash_on_delivery" /> Cash On Delivery</div>';
			if($custdetar_array['customers_terms'] != "0"){
				$cart_html .= '<div class="col-lg-6 po_pay mb-2"><input type="radio" name="paymentmethod" id="po_check" /> PO : <input type="text" id="po_number" /> </div>';
			}
		$cart_html .= '</div>
		</div>
				</div>
				<div class="col-lg-4">
				<a href="JavaScript:void(0);" data-store="'.$store_name.'" data-cusID = "'.$customerId.'" onclick="generateOrder('.$customers_customerProfileId.','.$customers_customerPaymentProfileId.','.$customers_customerShippingAddressId.')" class="neworder-submit btn btn-primary mt-5" >Confirm order</a>
				<div class="updatecrtData"><button onclick="updateCart()" id="apply_cart" class="btn btn-info mt-3">Update Record</button></div>
				</div>
			</div>
		</div>
			</div>
		</div></div>';
		$cart_html .= '<div class="row mainProddiv"><div class="col-lg-12 wareboxes mt-3">';
		$subtotal = 0; 
		$cart_html .='<div class="row mb-2 mt-2">
			<input type="hidden" id="product_id" />
				<div class="col-md-2 text-right">
				<label>LOOKUP ITEM</label>
				</div>
				<div class="col-md-2">
					<input type="text" id="sku_search" placeholder="Search by SKU"/>
				</div>
				<div class="col-md-2">
					<input type="text" id="description" placeholder="Search by Description"/>
				</div>
				<div class="col-md-2">
					<input type="text" id="qty" placeholder="Enter Qty"/>
				</div>
				<div class="col-md-2">
					<input type="text" id="price" placeholder="Price" readonly/>
				</div>
				<div class="col-md-2">
					<input type="button" onclick="add_to_carts()" id="add_to_cart" class="btn btn-info" value="Add to cart" />
				</div>
			</div>';
		require_once($rootPath.'includes/classes/order.php');	
		$order =  new order;
		$cart_html .='<div class="cart_table_contect">';
		$cart_html .=$this->getProducts($order);
		
		$cart_html .= '</div>';

		
		$cart_html .= '</div>';
		$cart_html .= '<div class="instruction_box w-100 mt-3"></div>';
		$cart_html .= '<div class="bg-gary mt-2 mb-2 w-100"></div>';
		$cart_html .= '<div class="col-lg-2"><div class="text-right mt-3"></div></div>
		</div></div>';
		return $cart_html;
	}
	function calculate_discountCodeID($id){
		global $zendb;
		$productDiscountQry = "SELECT * from products_discounts  where id ='" . $id . "'";
		$productDiscount      = mysqli_query($zendb,$productDiscountQry);
		if(mysqli_num_rows($productDiscount) > 0){
			while ($row = mysqli_fetch_array($productDiscount)) {
				$data[$row['discount_qty']]['percentage']=$row['discount_pct'];
			}
		}else{
			$data        = [];
		}
		ksort($data);
		if(!empty($data)){
			$firsArrElmnt = implode('',current($data)); 
			$firstArrElmntKey = key($data);
			$lastArrElmnt = implode('',end($data)); 
			$lastArrElmntKey = key($data);
			$data['minProductQuantity']=$firstArrElmntKey;
			$data['minProductQuantityPercentage']=$firsArrElmnt;
			$data['maxProductQuantity']=$lastArrElmntKey;
			$data['maxProductQuantityPercentage']=$lastArrElmnt;	
		}
		return $data;  
	}
	  function calculate_discountIDs($id,$value,$qty,$totalAmt){
	  global $zendb;
		$productDiscountQry = "SELECT *
			from products_discounts
			where id ='" . $id . "' and discount_qty = '".$qty."'";
		$productDiscount      = mysqli_query($zendb,$productDiscountQry);
		if(mysqli_num_rows($productDiscount) > 0){
		  $productDiscount = mysqli_fetch_array($productDiscount);
		  $discountPct        = $productDiscount['discount_pct']; 
		  $step               = $productDiscount['round_to_nearest']; 
		  $totalDiscount      = $value*(1-$discountPct/100);
		  $multiplicand       = floor( $totalDiscount / $step );
		  if($step >= 1){
			 // echo $step;
			  $rest               = $totalDiscount % $step;
			  if( $rest > $step/2 ) $multiplicand++; // round up if needed
		  }
		  $roundedvalue       = $step*$multiplicand;
		  $totalDiscount      = $value-$roundedvalue;
		}else{
		  $totalDiscount = 'No quantity discount';
		}
	  return $totalDiscount;  
	}
	 function calculate_discount($id,$value,$qty,$totalAmt){
	  global $zendb;
		$productDiscountQry = "SELECT *
			from products_discounts
			where id ='" . $id . "' and discount_qty = '".$qty."'";
			
		$productDiscount      = mysqli_query($zendb,$productDiscountQry);
		if(mysqli_num_rows($productDiscount) > 0){
		  $productDiscount = mysqli_fetch_array($productDiscount);
		}else{
		  $productDiscount = [];
		}
	  return $productDiscount;  
	}
	function productPrice($ppe,$productId,$qty){
		global $zendb;
		   $pro_normal_price = zen_get_products_base_price($productId);
				   $pro_special_price = zen_get_products_special_price($productId, true);
				   $pro_sale_price = zen_get_products_special_price($productId, false);  
					$productDetailQry = "SELECT discount_code
							  from products_details
							  where products_id ='" . $productId . "'";
					$productDetail = mysqli_query($zendb,$productDetailQry);
					$productDetail = mysqli_fetch_array($productDetail);
					$discount_code = $productDetail['discount_code'];
					$discountCodeData = $this->calculate_discountCodeID($discount_code);
					if($pro_special_price !="")
					{
					  $ppe = 	round($pro_special_price,2);
					  $ppt = round($pro_special_price,2)*$qty;
					}
					elseif($pro_sale_price != "")
					{
					  $ppe = 	round($pro_sale_price,2);
					  $ppt = round($pro_sale_price,2)*$qty;
					}
					else
					{
					  $ppt = $ppe * $qty;
					  if($discount_code != 0){
						$totalAmt = $ppe*$qty;
						$discount = $this->calculate_discountIDs($discount_code,$ppe,$qty,$totalAmt); 
						if(($qty >= $discountCodeData['minProductQuantity'])&&($qty < $discountCodeData['maxProductQuantity'])){
							$totalAmt     = $ppe*$qty;
							$discount     = round((($totalAmt*$discountCodeData['minProductQuantityPercentage'])/100), 2);
							$qtYdiscount     = round((($ppe*$discountCodeData['minProductQuantityPercentage'])/100), 2);
							//$ppt          =  $totalAmt - $discount;
							$ppe          = $ppe - $qtYdiscount;	
							$ppt          =  $ppe * $qty;		 
						}
						if($qty >= $discountCodeData['maxProductQuantity']){
							$totalAmt     = $ppe*$qty;
							$discount     = round((($totalAmt*$discountCodeData['maxProductQuantityPercentage'])/100), 2);
							$qtYdiscount     = round((($ppe*$discountCodeData['maxProductQuantityPercentage'])/100), 2);
							//$ppt          =  $totalAmt - $discount;
							$ppe          = $ppe - $qtYdiscount;			
							$ppt          =  $ppe * $qty;		
						}
						if($qty < $discountCodeData['minProductQuantity']){
							$totalAmt     = $ppe*$qty;
							$discount     = 0;
							$qtYdiscount     = 0;
							$ppe          = $ppe - $qtYdiscount;			
							$ppt          =  $ppe * $qty;		
						}
					  }
					}    
				   $totalCart     = number_format($ppt, 2, '.', '');
				   
				   $result = array("product_price" => '$'.number_format($ppe, 2, '.', ''),"total_price" => '$'.$totalCart);
				/* New code end */
			return $result;	
	}
	
	
	/* apply Coupon */
	function applyCoupon(){
		global $rootPath;
		require($rootPath.'includes/classes/order.php');
		$order 		 = new order;
		$coupon_code = $_REQUEST['coupon_code'];
		$html = $order->applyCoupon($coupon_code);
		return json_encode($html);
	}
	/* remove Coupon */
	function removeCoupon(){
		global $rootPath;
		require($rootPath.'includes/classes/order.php');
		$order 		 = new order;
		$coupon_amt = $_REQUEST['coupon_amt'];
		$html = $order->removeCoupon($coupon_amt);
		return $html;
	}
	
	function checkProd(){
		$products_id = $_REQUEST['pid'];
		$shoppingCart = new shoppingCart();
		$res = $shoppingCart->checkPrductcart($products_id);
		return json_encode(array('status' => $res));
	}
	
	/* Add to Cart */
	function add_to_cart() {
		global $zendb, $messageStack;
		$products_id = $_REQUEST['pid'];
		$qty = $_REQUEST['qty'];
		$store_name = $_REQUEST['store_name'];
		$action = $_REQUEST['isaction'];
		$shoppingCart = new shoppingCart();
		$res = $shoppingCart->add_cart($products_id,$qty,$store_name,$action);
		$alStat = [];
	  $stutsHtml = '';
	  foreach($res as $key => $value){
		  $stat = explode("_",$value);
		  $productSku = $this->get_product_sku($key);
		  $alStat[$key] = $stat[1];
		  if($stat[0] == "3"){
			  $stutsHtml = '<span>'.$productSku.' - Quantity ordered exceeds current inventory. Order may be delayed due to backorder.</span><br /><br />';
		  }elseif($stat[0] == "2"){
			  $stutsHtml = '<span>'.$productSku.' - Quantity ordered exceeds current inventory. Order adjusted to reflect availability.</span><br /><br />';
		  }elseif($stat[0] == "5"){
			   $stutsHtml = '<span>'.$productSku.' - Product is out of stock.</span><br /><br />';
		  }
	  }
		$ship = '0';
		$html = $this->update_cart_table($ship);
		return json_encode(array('status' => $stutsHtml,'html' => $html));
  }
  
  /* Remove Cart */
  function removeCart(){
	  $products_id = $_REQUEST['pid'];
	  $shoppingCart = new shoppingCart();
	  $shoppingCart->remove($products_id);
	  $ship = '0';
	  $res = $this->update_cart_table($ship);
	  return json_encode($res);
  }
  
   /* Update Cart */
  function updateCart(){
	  if(isset($_REQUEST['pdata'])){
		  $products_id = $_REQUEST['pdata'];
		  $shoppingCart = new shoppingCart();
		  $status = [];
		  foreach($products_id as $pr){
			  $pArr = explode("_",$pr);
			  $status[$pArr[0]] = $shoppingCart->update_quantity($pArr[0],$pArr[1]);
		  }
		  $alStat = [];
		  $stutsHtml = '';
		  foreach($status as $key => $value){
			  $stat = explode("_",$value);
			  $productSku = $this->get_product_sku($key);
			  
			  $alStat[$key] = $stat[1];
			  if($stat[0] == "3"){
				  $stutsHtml .= '<span>'.$productSku.' - Quantity ordered exceeds current inventory. Order may be delayed due to backorder.</span><br /><br />';
			  }elseif($stat[0] == "2"){
				  $stutsHtml .= '<span>'.$productSku.' - Quantity ordered exceeds current inventory. Order adjusted to reflect availability.</span><br /><br />';
			  }elseif($stat[0] == "5"){
				   $stutsHtml = '<span>'.$productSku.' - Product is out of stock.</span><br /><br />';
			  }
		  }
		  $ship = '1';
		  $html = $this->update_cart_table($ship);
		  $res = json_encode(array('status' => $alStat,'html' => $html,'stutsHtml' => $stutsHtml));
	  }else{
		  $ship = '1';
		  $html = $this->update_cart_table($ship);
		  $res = json_encode(array('status' => '','html' => $html,'stutsHtml' => ''));
	  }
	  return $res;
  }
  
   function get_product_name($product_id, $language = '') {
    global $zendb;

    //if (empty($language)) $language = $_SESSION['languages_id'];

    $product_query = "select products_name
                      from products_description
                      where products_id = '" . (int)$product_id . "'
                      ";

    $product = mysqli_query($zendb,$product_query);
    $productres = mysqli_fetch_array($product);

    return $productres['products_name'];
  }
  
   function get_product_sku($product_id, $language = '') {
    global $zendb;

    //if (empty($language)) $language = $_SESSION['languages_id'];

    $product_query = "select products_model
                      from products
                      where products_id = '" . (int)$product_id . "'
                      ";

    $product = mysqli_query($zendb,$product_query);
    $productres = mysqli_fetch_array($product);

    return $productres['products_model'];
  }
  
  public function update_cart_table($ship)
	{
		global $zendb,$rootPath;
		require($rootPath.'includes/classes/order.php');
		$order = new order;
		$cart_html = "";
		$cart_totl = 0.00;
		$store_name = $_SESSION['store_type'];
		$customerId = $_SESSION["customer_id"];
		$_SESSION['store_type'] = $store_name;
		$shoppingCart = new shoppingCart();
		
		$get_customer_cart = "SELECT products_id,customers_basket_quantity,store_type FROM customers_basket where customers_id ='".$customerId."' AND store_type='".$store_name."'";
	
		$result = mysqli_query($zendb, $get_customer_cart);
		$countresult = mysqli_num_rows($result);
		
		//echo $countresult;
		/*pending */
		$_SESSION['cart'] = $shoppingCart->calculate();
		/*pending */
		
		$getCartTotl = "select total from cart_total where cid = '".$customerId."'";
		$cartotl_result = mysqli_query($zendb, $getCartTotl);
		$cartotl_rowfetch = mysqli_fetch_array($cartotl_result);
		if(!empty($cartotl_rowfetch))
		{
			$cart_totl = $cartotl_rowfetch['total'];
		}
		
		$_SESSION['cart_total'] = $cart_totl;
		$cart_html = '';
		if($countresult > 0)
		{
			$subtotal = 0; 
			$order = new order;
			$cart_html = $this->getProducts($order);
		}
		
		//echo "<pre>";print_r($countresult);
		
		/* Shipping Rates */
		if($ship == "1"){
			$ship_html = $this->getShipping($countresult);
		}else{
			$ship_html = '';
		}
		return array("cart" => $cart_html,'shipping' => $ship_html);
	}
	function getShipping($countresult){
		global $zendb;
		$cart_html = '';
		$cart_html .= '<div class="ship_data" style="display:none;">';
		$shpiArrHtml = '';
		
		if($countresult > 0)
		{
			//echo $countresult.'helhldo';
			$shipping_modules = new shipping;
			$quotes = $shipping_modules->quote();
			//echo "<pre>";print_r($quotes);
			$order = new order;
			if(!empty($quotes) && !isset($quotes['error'])){
				if($_SESSION['drop_ship_flag_fedex'] != 0 && $_SESSION['drop_ship_flag_ups'] != 0){
						foreach($quotes as $subKey => $subArray){
							if($quotes[$subKey]['id'] == 'usps'){
								unset($quotes[$subKey]);
							}
							if($quotes[$subKey]['module'] == 'Store Pickup'){
								   unset($quotes[$subKey]);
							}
						}
				}
				$mulTicheck = '0';
				$wareArr = [];
				foreach($order->info['warehouse_id'] as $mult){
						if($mult > 1){
							$wareArr[] = 'multi';
						}
				}
				if(in_array('multi',$wareArr)){
					$mulTicheck = 1;	
				}
				if($mulTicheck == 1){
					foreach($quotes as $subKey => $subArray){
						if($quotes[$subKey]['id'] == 'usps'){
							unset($quotes[$subKey]);
						}
						if($quotes[$subKey]['module'] == 'Store Pickup'){
							   unset($quotes[$subKey]);
						}
					}
				}
				//echo "<pre>";print_r($order->info['warehouse_id']);
				$_SESSION['dropship_cost'] = 0;
				$_SESSION['drop_ship_flag_ups'] = 0;
				$customer_id = $_SESSION['customer_id'];
				  $sql = "select * from customers_details where customers_id='".$customer_id."'";
				  $account_infores = mysqli_query($zendb,$sql);	
				  $account_info = mysqli_fetch_array($account_infores);	
				  
				 $strPick =  $account_info['customers_store_pickup_enabled'];
				 if($strPick == '0'){
					foreach($quotes as $subKey => $subArray){
						if($quotes[$subKey]['module'] == 'Store Pickup'){
							   unset($quotes[$subKey]);
						}
					}
				 }
				
				  $i = 0;
				 $cart_html .= '<div class="row mb-2 mt-2">'; 
				 $preSelected = [];
				 $$preSelectedStr = [];
				foreach ($quotes as $key=>$value) {
					if(!empty($value) &&(isset($value['methods']) && !empty($value['methods']))){
					if($value["module"] == "United States Postal Service"){
						$title = "USPS";
					}else{
						$title = $value["module"];
					}
					$lwtVal  = [];
					foreach($value['methods'] as $services)
					{
						if($services['id'] != "storepickup0"){
							$lwtVaL[] = array(round($services['cost'],2),$title.' '.$services['title']);
						}else{
							if($services['id'] == "storepickup0"){
								$preSelectedStr = array(round($services['cost'],2),$title.' '.$services['title']);
							}
						}
					}
					$preSelected = min($lwtVaL);
					
					/* ship collect start */
					
					if($i == 0){
								
						$cart_html .= 		'<div class="col-md-4">';
									if($account_info['customers_ship_collect']==1 && ($_SESSION['drop_ship_flag_fedex'] == 0 && $_SESSION['drop_ship_flag_ups'] == 0))
								{
									if($mulTicheck == 0 && $preSelectedStr[0] != "0"){
									
						$cart_html .= 	'<input id="ship_collect_check_back" class="ship_collect_check_back"  type="checkbox" onclick="setshipCOllect(this)" name="ship_collect_check_back" value="1">
							<span class="pt-2">Ship on Your Account?</span>';
							 } } 
					$cart_html .= 	'</div>';	
					}
					if($value['module'] == "United Parcel Service"){
								$mDnae = "UPS";
							}else{
								$mDnae = $value['module'];
							}
					if($account_info['customers_ship_collect']==1 && ($_SESSION['drop_ship_flag_fedex'] == 0 && $_SESSION['drop_ship_flag_ups'] == 0))
					{
						if($mulTicheck == 0){
							if($value["id"]=="fedexwebservices"||$value["id"]=="upsxml"){ 		
								$ship_acct_value = $value["id"]=="upsxml"?$account_info['customers_ups_acct']:$account_info['customers_fedex_acct'];
				
								  
				$cart_html .= '<div class="col-md-4"><span class="ship_collect_info"><input style="position:absolute;margin: 0px !important;visibility:hidden !important;max-height: 0px !important;min-height: 0px !important;" id="'.$value["id"].'_ship_collect_check"  type="checkbox" name="'. $value["id"].'_ship_collect_check" value="1">  <input type="text" placeholder="'.$mDnae.' account number" name="'. $value["id"].'_ship_collect" id="'.$value["id"].'_ship_collect" value="'.$ship_acct_value.'"> </span></div>';
							
							}
						}
					}
					$i++;
					
					/* ship collect end */
				}
				}
				$cart_html .= '</div>';
				if(empty($preSelected)){
					$preSelected = $preSelectedStr;
				}
				
			if(!empty($preSelected)){
			$cart_html .= '<div class="dropdown dropdown-custom d-inline-block"><p class="dropdown-toggle d-block bg-transparent rounded-0 mb-0" data-toggle="dropdown"><span class="titlePst">'.(!empty($preSelected)?$preSelected[1]:"").'</span><span class="cstTil">$'.(!empty($preSelected)?$preSelected[0]:"").'</span><span><i class="fa fa-caret-down"></i></span></p><div class="dropdown-menu p-0 mt-0 shipValmeth">';
			
				if($mulTicheck == 1){
					foreach($quotes as $subKey => $subArray){
						if($quotes[$subKey]['id'] == 'usps'){
							unset($quotes[$subKey]);
						}
						if($quotes[$subKey]['module'] == 'Store Pickup'){
							   unset($quotes[$subKey]);
						}
					}
				}
				foreach ($quotes as $key=>$value) {
				if(!empty($value) &&(isset($value['methods']) && !empty($value['methods']))){	
					if($value["module"] == "United States Postal Service"){
						$title = "USPS";
					}else{
						$title = $value["module"];
					}
					if(isset($value['tax_class']) && $value['tax_class'] > 0){
						$tax_class = $value['tax_class'];
					}else{
						$tax_class = 'no';
					}
					if(isset($value['tax_basis']) && $value['tax_basis'] != ''){
						$tax_basis = $value['tax_basis'];
					}else{
						$tax_basis = 'no';
					}
					if($value['module'] == "United Parcel Service"){
						$mDnae = "UPS";
						$clss = "";
					}elseif($value['module'] == "United States Postal Service"){
						$mDnae = $value['module'];
						$clss = "usps_pick";
					}elseif($value['module'] == "Store Pickup"){
						$mDnae = $value['module'];
						$clss = "store_pickup";
					}else{
						$mDnae = $value['module'];
						$clss = '';
					}
					foreach($value['methods'] as $services)
					{
						$srId = str_replace(' ', '', $services['id']);
						$spltshipCost = '';
						$spltshipshipCost = '';
						foreach($services['par_cost'] as $shkey => $shvalue){
							$spltshipCost .= $shkey.'_'.round($shvalue,2).'&';
							$spltshipshipCost .= $shkey.'_no&';
						}
						$shpCost = $services['cost'];
						$shipId = str_replace(' ', '', $services['id']);
						if($services['title'] == "Standard Overnight" || $services['title'] == "First Overnight" || $services['title'] == "Priority Overnight"){
							$titleVl = $title." ".$services['title'];
						}else{
							if($value["module"] == "United States Postal Service"){
								$titleVl = $title." ".$services['title'];
							}else{
								$titleVl = $services['title'];
							}
							
						}
						//$titleVl = $title." ".$services['title'];
						//echo "<pre>";print_r($preSelected);
						$shipCost =  '$'.number_format((float)$services['cost'], 2, '.', '');
						if($preSelected[0] == round($services['cost'],2)){
							$preselc = "preSelct";
						}else{
							$preselc = "";
						}
						$cart_html .= '<p onclick="setShipping(this)" class="dropdown-item m-0 p-0 shipval '.$clss.' '.$preselc.'" data-shipid = "'.$shipId.'"><span class="seletitlePst">'.$titleVl.'</span><span class="selecstTil price_'.$mDnae.'" data-txcls = "'.$tax_class.'" data-taxbasis = "'.$tax_basis.'" data-cost ="'.$shipCost.'" data-spltcost ="'.$spltshipCost.'">'.$shipCost.'</span><span style="display:none;" data-txcls = "'.$tax_class.'" data-taxbasis = "no" data-cost ="$0.00" data-splstcost ="'.$spltshipshipCost.'" class="important selecsstTil selecstTil forward nprice_'.$mDnae.'">$0.00</span></p>';
					}
				}
				}
				$shpiArrHtml .='</div></div>';
				}
			}
			
			if(empty($preSelected) || $preSelected[1] == "Store Pickup Pick-up at 4 Tripp Street"){
				
				$shpiArrHtml .= '<p>Unfortunately we are unable to calculate the cost of shipping at this time. Please continue checking out. Someone will contact you to provide a freight quote prior to processing of your order. We are sorry for this inconvenience.</p>';
					$shpiArrHtml .= '<input type="button" onclick="settanShipping()" class="tanlnk btn btn-success mt-3 w-100" value="Click to apply Tantaive Shipping">';
			}
			//echo $shpiArrHtml;
			$cart_html .= $shpiArrHtml;	
		}else{
			$cart_html .= "<p>Seems like you didn't add any products.Please Add products to get shiping rates.</p>";
		}
		$cart_html .= '</div>';
		return $cart_html;
	}
	
	function getProducts($order){
		$cart_html = '';
		if(isset($order->products) && !empty($order->products)){
			$i = 0;
			$t_price= '0';
			if(count($order->products) == 1){
				$clMD = '12';
			}else{
				$clMD = '6';
			}
			$allProducts = [];
			$allOrdertotal = [];
			foreach($order->products as $key => $products){
				foreach($products as $prdt){
					$allProducts[] = $prdt;
				}
				if($order->info['ordertotal']){
					$allvalues = "0";
					foreach($order->info['ordertotal'][$key] as $ordertotal){
						$value  = $ordertotal["value"];
						$title 	= $ordertotal["title"];
						$code 	= $ordertotal["code"];
						$text 	= $ordertotal["text"];
						$allOrdertotal[] = $ordertotal;
					}
				}
			}
			$orderBy = array();
			foreach ($allOrdertotal as $key => $row)
			{
				$orderBy[$key] = $row['order_by'];
			}
			array_multisort($orderBy, SORT_ASC, $allOrdertotal);
			/*echo "<pre>";print_r($allOrdertotal);
			die;*/
			$outputArray = [];
			//Let's make a cycle going for every array inside $content
			foreach ($allOrdertotal as $innerArray) {
			  //Does this $innerArray['name'] (filter_ammount) exist in $outputArray in an array 
			  //consisting in key => value where the key is 'name' and equals 
			  //what we look for that is(filter_ammount)?
			  $key = array_search($innerArray['code'], array_column($outputArray , 'code'));
			  //If not, let's place this array in the $output array
			  if ($key === false) {
				  array_push($outputArray, $innerArray);
			  } else { 
				  //If exists, then $key is the $key of the $outputArray and let's add to its value 
				  //our current value, that is in our $innerArray, concatenated with a comma
				  $outputArray[$key]['value'] += $innerArray['value'];
			  }
			}
			$cart_html .= '
				<input type="hidden" class="all_warehouse" value="'.$key.'" />
				<table id="newordertabled" class="table table-striped">	<thead><tr><th>Remove</th><th>Warehouse</th><th>SKU</th><th>Description</th><th>Qty</th><th align="right">Price</th><th align="right">Total</th></tr></thead><tbody>';
			$t_price = '0';
			$subtotal = '';
			//echo "<pre>";print_r($allProducts);
			foreach($allProducts as $cartproduct){
				$productId = $cartproduct['id'];
				$warehouse = $cartproduct['warehouse_id'];
				$description = ($cartproduct['name']!="")?$cartproduct['name']:"";
				
				// strip tags to avoid breaking any html
				$string = strip_tags($description);
				if (strlen($string) > 50) {

					// truncate string
					$stringCut = substr($string, 0, 50);
					$endPoint = strrpos($stringCut, ' ');

					//if the string doesn't contain any space then it will cut without word basis.
					$string = $endPoint? substr($stringCut, 0, $endPoint) : substr($stringCut, 0);
					$string .= '...';
				}
				$qty = $cartproduct['qty'];
				$productDetail = $cartproduct['final_price'];
				$price = round($productDetail, 2);
				$products_model = $cartproduct["model"];
				$res = 	$this->productPrice($price,$productId,$qty);
				$totalprice = str_replace("$","",$res["total_price"]);
				$totalprice = number_format((float)$totalprice, 2, '.', '');
				$price 		= str_replace("$","",$res["product_price"]);
				$price = number_format((float)$price, 2, '.', '');
				$cart_html .= '<tr><td class="text-center"><a href="javascript:void(0)" onclick="removeCart('.$productId.')"><i class="fa fa-trash"></i></a></td><td>'.$warehouse.'</td><td>'.$products_model.'</td><td>'.$string.'</td><td><input type="text" onclick="changeqty()" class="pt_'.$productId.' pqty text-center" style="width:28%;" id="qty" value="'.$qty.'" data-cost="'.$productId.'" /></td><td align="right">$'.$price.'</td><td align="right">$'.$totalprice.'</td></tr>';
			}
			$cart_html .= '</tbody></table>';
			if($outputArray){
				$mthtmld = '';
				
				if(isset($_SESSION["coupon_code"]) && $_SESSION['coupon_code']!= ""){
					$csl = 'none';
					$rmcsl = 'block!important';
				}else{
					$csl = 'block';
					$rmcsl = 'none';
				}
				$cpHtml = '<a onclick="applyCoupon(1)" id="apply_coupon" class="btn btn-info pt-1 pb-1 m-1" href="javascript:void(0)" data-toggle="modal" data-target="#couponModal">Apply Coupon</a>';
				foreach($outputArray as $ordertotal){
					$remcpnCode = '';
					$title = $ordertotal["title"];
					$value = number_format((float)$ordertotal["value"], 2, '.', '');
					$text = $ordertotal["text"];
					$code = $ordertotal["code"];
					$nVal = "$".$value;
					if($code == "ot_coupon" || $code == "ot_discount" || $code == "ot_group_pricing"){
						$nVal = "-$".$value;
					}
					
					if($code == "ot_coupon"){
						$mthtmld .='<input type="hidden" id="splitCmat" value="'.$value.'" />';
						$remcpnCode = '<a onclick="removeCoupon(0)" href="javascript:void(0)" id="apply_coupon" style="color:red" style="display:'.$rmcsl.'" class="" data-toggle="modal">X</a>';
					}
					$mthtmld .=  "<div class='".$code." text-right text-primary mt-2 font-weight-bold'><span class ='alltitle_".$key."' >".$title."</span> <span class='allvalues_".$key." sub_".$code."'>".$nVal."</span> ".$remcpnCode."</div>";
					if($title == "Subtotal :" && $code != "ot_coupon"){
						$mthtmld .= '<div class="couponData  text-right text-primary mt-2 font-weight-bold" style="display:'.$csl.'">'.$cpHtml.'</div>';
					}
				}
				
				$cart_html .= '<div class="row"><div class="col-lg-6"><div class="row"><div class="col-lg-6"><b>Special Shipping Instructions:</b><textarea class="form-control border" id="shipping_instruction"></textarea></div><div class="col-lg-6"><b>Special Production Instructions:</b><textarea class="form-control border" id="production_instruction"></textarea></div></div></div><div class="col-md-6">'.$mthtmld.'</div>
				
				</div><div class="row"><div class="col-lg-2"></div>';
		$cart_html.= '<div class="col-lg-8"><div class="updatecrtData"><label>You will need to update quantity and shipping rates before proceed to checkout.</label></div>';
			}
		}
		return $cart_html;
	}
	public function resetsessionCustomerData(){
		$_SESSION["sendto"] = "";
		$_SESSION["billto"] = "";
	}
}

?>
