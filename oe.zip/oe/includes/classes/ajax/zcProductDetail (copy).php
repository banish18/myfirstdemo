<?php
/**
 * zcProductDetail
 *
 * @package templateSystem
 * @copyright Copyright 2003-2014 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: Ian Wilson  New in v1.5.4 $
 */
ini_set('display_errors', 1);
require_once('../db/db.inc');
require_once('payment/function.php');
require_once('document_general_info.php');


class zcProductDetail
{
	/* cart search product */
	
	public function add_to_cart() {
		echo "s";
		
	}
	
	public function getcartProduct() 
	{
		global $zendb;
		
		$show_onetime_charges_description = 'false';
		$products_model = $_POST['products_model'];
		$customer_id = $_POST['customer_id'];
		$product_html = "";
		$get_product_detail = "SELECT products.products_id, products.products_quantity, products.products_model, products.products_price, products.products_qty_box_status, products_details.pack_desc, products_details.availability_status FROM products LEFT JOIN products_details ON products.products_id = products_details.products_id WHERE products.products_model = '".$products_model."'";
		
		$result = mysqli_query($zendb, $get_product_detail);
		$product = mysqli_fetch_array($result);
		
		$sql = "select distinct popt.products_options_id, popt.products_options_name, popt.products_options_sort_order,
                              popt.products_options_type, popt.products_options_length, popt.products_options_comment,
                              popt.products_options_size,
                              popt.products_options_images_per_row,
                              popt.products_options_images_style,
                              popt.products_options_rows
              from  products_options popt, products_attributes patrib
              where           patrib.products_id='" . $product['products_id'] . "'
              and             patrib.options_id = popt.products_options_id";
             
		$prooptionresult = mysqli_query($zendb, $sql);
		$prooptionarray = mysqli_fetch_array($prooptionresult);
		if(!empty($prooptionarray))
		{
			$optionsql = "select    pov.products_options_values_id,
                        pov.products_options_values_name,
                        pa.* products_attributes
              from pa, products_options_values pov
              where     pa.products_id = '" . $product['products_id'] . "'
              and       pa.options_id = '" . $products_options_names['products_options_id'] . "'
              and       pa.options_values_id = pov.products_options_values_id";

          $optionsqlresult = mysqli_query($zendb, $optionsql);
		  $optionsqlarray = mysqli_fetch_array($optionsqlresult);
		  if(!empty($optionsqlarray))
		  {
			  if ($optionsqlarray['attributes_price_onetime'] != 0 or $optionsqlarray['attributes_price_factor_onetime'] != 0) {
                      $show_onetime_charges_description = 'true';
              } 
		  }

		}
		
		if ($show_onetime_charges_description == 'true') {
		$one_time = '<span >' . TEXT_ONETIME_CHARGE_SYMBOL . TEXT_ONETIME_CHARGE_DESCRIPTION . '</span><br />';
		} else {
			$one_time = '';
		} 
		$flag_show_product_info_starting_at = $this->zen_get_show_product_switch($product['products_id'], 'starting_at');
		$productDetailQry = "SELECT discount_code from products_details where products_id ='" . $product['products_id'] . "'";
		$productDetail = mysqli_query($zendb, $productDetailQry);
		$productDetailresult = mysqli_fetch_array($productDetail);
		$discount_code = $productDetailresult['discount_code'];
		$QtyText = '';
		if($discount_code != 0){
		$discountData = $this->calculate_discountIDsP($discount_code,$product['products_quantity'],$product['products_price']);
		if($discountData['min_qty'] != 1){
			$QtyText = '<b class="p_qty_tag"><span class="qnty-spn">Qty 1</span> <span class="prioce_dfs">:</span> </b>';
			$product_html .= $one_time .' '.$QtyText.'<b class="pprice">'. (($this->zen_has_product_attributes_values(($product['products_id']) and $flag_show_product_info_starting_at == 1) ? TEXT_BASE_PRICE : '') . zen_get_products_display_price($$product['products_price']).'</span></b>';   
		}
	}else{
		$product_html .= $one_time .' '.'<b class="pprice">'. ((zen_has_product_attributes_values(($product['products_id']) and $flag_show_product_info_starting_at == 1) ? TEXT_BASE_PRICE : '') . zen_get_products_display_price($product['products_price']).'</span></b>';  
	}
		
	//	$product_html .= '<script>$("#productable_id").DataTable();</script>';
	//		$product_html .= '<table id="productable_id" class="display">
	//			<thead><tr><th>Product Name</th><th>Availability</th><th>SKU</th><th>Price</th><th>Qty</th><th></th></tr></thead><tbody>';
	//		
	//			
	//				
	//				$product_html .= '<tr><td>'.$product['pack_desc'].'</td><td>';
	//				
	//				if(($product['availability_status'] == 1 || $product['availability_status']==2 || $product['availability_status']==3) && ($product['products_quantity']>5))
	//				{
	//					$product_html .= '<span class="pro_available in_stock"><span class="fa fa-check"></span> In stock</span>';
	//				}else if(($product['availability_status']==1) && ($product['products_quantity']>0) &&($product['products_quantity']<=5)){
	//					$product_html .= '<span class="pro_available in_stock"><span class="fa fa-check"></span> In stock</span>';
	//				}
	//				else if(($product['availability_status']==1) && ($product['products_quantity']<=0) )
	//				{	
	//					$product_html .= '<span class="pro_available limited_availability"><span class="fa fa-exclamation"></span> On Backorder</span>';
	//				}
	//				else if(($product['availability_status']==2) && ($product['products_quantity']>0) &&($product['products_quantity']<=5)){
	//					$product_html .= '<span class="pro_available limited_availability"><span class="fa fa-exclamation"></span> Limited Availability</span>';
	//				}
	//				else if($product['availability_status']==2 && $product['products_quantity']<=0 )
	//				{
	//					$product_html .= '<span class="pro_available limited_availability"><span class="fa fa-exclamation"></span> Limited Availability</span><br> <span class="pro_available made-to-order2"><span class="fa fa-clock-o"></span> Made to Order <a href="#" data-toggle="tooltip" data-placement="top" title="Order may be delayed" class="fa fa-info-circle" aria-hidden="true"></a> </span>';
	//				}
	//				$product_html .= '</td><td>'.$product['products_model'].'</td><td>'.$address['entry_lastname'].'</td><td>'.$address['entry_street_address'].'</td><td>'.$address['entry_suburb'].'</td><td>'.$address['entry_city'].'</td><td>'.$address['entry_state'].'</td><td>'.$address['entry_postcode'].'</td><td><a title="Edit" class="edit_address mr-3" href="JavaScript:void(0);" data-id="'.$address['address_book_id'].'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a><a title="Delete" class="delete_address" href="JavaScript:void(0);" data-id="'.$address['address_book_id'].'"><i class="fa fa-trash" aria-hidden="true"></i></a></td></tr>';
	//			
	//			
	//		
	//		$product_html .= '</tbody></table>';
		
	}
	
	public function zen_not_null($value) {
    if (is_array($value)) {
      if (sizeof($value) > 0) {
        return true;
      } else {
        return false;
      }
    } elseif( is_a( $value, 'queryFactoryResult' ) ) {
      if (sizeof($value->result) > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      if (($value != '') && (strtolower($value) != 'null') && (strlen(trim($value)) > 0)) {
        return true;
      } else {
        return false;
      }
    }
  }
	
	//get specials price or sale price
  public function zen_get_products_special_price($product_id, $specials_price_only=false) {
    global $zendb;
    $sql = "select products_price, products_model, products_priced_by_attribute from products where products_id = '" .$product_id . "'"
   $result = mysqli_query($zendb, $sql);
   $product = mysqli_fetch_array($result);
   $product_numrow =  mysqli_num_rows ($result);
    if ($product_numrow > 0) {
//  	  $product_price = $product->fields['products_price'];
      $product_price = $this->zen_get_products_base_price($product_id);
    } else {
      return false;
    }

    $specials_sql = "select specials_new_products_price from specials where products_id = '" . $product_id . "' and status='1'";
   $specialsresult = mysqli_query($zendb, $specials_sql);
   $specials = mysqli_fetch_array($specialsresult);
   $specials_numrow = mysqli_num_rows ($specialsresult);
    if ($specials_numrow > 0) {
//      if ($product->fields['products_priced_by_attribute'] == 1) {
        $special_price = $specials['specials_new_products_price'];
    } else {
      $special_price = false;
    }

    if(substr($product['products_model'], 0, 4) == 'GIFT') {    //Never apply a salededuction to Ian Wilson's Giftvouchers
      if ($this->zen_not_null($special_price)) {
        return $special_price;
      } else {
        return false;
      }
    }

// return special price only
    if ($specials_price_only==true) {
      if ($this->zen_not_null($special_price)) {
        return $special_price;
      } else {
        return false;
      }
    } else {
// get sale price
// changed to use master_categories_id
	  /***** Start Custom Code For SalesMaker to run for every category************/	
	   $product_categories_sql = "select categories_id from products_to_categories where products_id = '" . $product_id . "'";
	    $categoriessresult = mysqli_query($zendb, $product_categories_sql);
		$product_to_categories = mysqli_fetch_array($categoriessresult);
		 $categories_numrow = mysqli_num_rows ($product_to_categories);
       $category_ids = array();
      if ($categories_numrow >= 1) {
        while (!$product_to_categories->EOF) {          
          $category_ids[] = $product_to_categories->fields['categories_id'];
          $product_to_categories->MoveNext();
		}
      }
      $new_sale = $db->Execute("select sale_categories_all,sale_deduction_value from " . TABLE_SALEMAKER_SALES . " where sale_status = '1' and (sale_date_start <= now() or sale_date_start = '0001-01-01') and (sale_date_end >= now() or sale_date_end = '0001-01-01') and (sale_pricerange_from <= '" . $product_price . "' or sale_pricerange_from = '0') and (sale_pricerange_to >= '" . $product_price . "' or sale_pricerange_to = '0') order by sale_deduction_value DESC");
      $sale_catgories = array();
      if ($new_sale->RecordCount() >= 1) {
        while (!$new_sale->EOF) {          
          $sale_catgories[$new_sale->fields['sale_deduction_value']] = explode(',',$new_sale->fields['sale_categories_all']);
          $new_sale->MoveNext();
		}
      }      
      foreach($sale_catgories as $_sales_categories)
      {
		 $sale_catgories =  array_intersect($category_ids,$_sales_categories);
		 if(count($sale_catgories))break;		
	  }      
	  if(count($sale_catgories)>0)
	  {
		  foreach($sale_catgories as $sale_category){$category = $sale_category;break;}		  
	  }
	  else
	  {		  
			$product_to_categories = $db->Execute("select master_categories_id from " . TABLE_PRODUCTS . " where products_id = '" . $product_id . "'");
			$category = $product_to_categories->fields['master_categories_id'];
	  }   
      /***** End Custom Code For SalesMaker to run for every category************/	
      $sale = $db->Execute("select sale_specials_condition, sale_deduction_value, sale_deduction_type from " . TABLE_SALEMAKER_SALES . " where sale_categories_all like '%," . $category . ",%' and sale_status = '1' and (sale_date_start <= now() or sale_date_start = '0001-01-01') and (sale_date_end >= now() or sale_date_end = '0001-01-01') and (sale_pricerange_from <= '" . $product_price . "' or sale_pricerange_from = '0') and (sale_pricerange_to >= '" . $product_price . "' or sale_pricerange_to = '0')");
      if ($sale->RecordCount() < 1) {
         return $special_price;
      }

      if (!$special_price) {
        $tmp_special_price = $product_price;
      } else {
        $tmp_special_price = $special_price;
      }
      switch ($sale->fields['sale_deduction_type']) {
        case 0:
          $sale_product_price = $product_price - $sale->fields['sale_deduction_value'];
          $sale_special_price = $tmp_special_price - $sale->fields['sale_deduction_value'];
          break;
        case 1:
          $sale_product_price = $product_price - (($product_price * $sale->fields['sale_deduction_value']) / 100);
          $sale_special_price = $tmp_special_price - (($tmp_special_price * $sale->fields['sale_deduction_value']) / 100);
          break;
        case 2:
          $sale_product_price = $sale->fields['sale_deduction_value'];
          $sale_special_price = $sale->fields['sale_deduction_value'];
          break;
        default:
          return $special_price;
      }

      if ($sale_product_price < 0) {
        $sale_product_price = 0;
      }

      if ($sale_special_price < 0) {
        $sale_special_price = 0;
      }

      if (!$special_price) {
        return number_format($sale_product_price, 4, '.', '');
      } else {
        switch($sale->fields['sale_specials_condition']){
          case 0:
            return number_format($sale_product_price, 4, '.', '');
            break;
          case 1:
            return number_format($special_price, 4, '.', '');
            break;
          case 2:
            return number_format($sale_special_price, 4, '.', '');
            break;
          default:
            return number_format($special_price, 4, '.', '');
        }
      }
    }
  }
	
	
	////
// computes products_price + option groups lowest attributes price of each group when on
  public function zen_get_products_base_price($products_id) {
    global $zendb;
		$sql = "select products_price, products_priced_by_attribute from products where products_id = '" . $products_id . "'";
		$result = mysqli_query($zendb, $sql);
		$product_check = mysqli_fetch_array($result);
     

// is there a products_price to add to attributes
      $products_price = $product_check['products_price'];

      // do not select display only attributes and attributes_price_base_included is true
      $product_att_query = "select options_id, price_prefix, options_values_price, attributes_display_only, attributes_price_base_included, round(concat(price_prefix, options_values_price), 5) as value from products_attributes where products_id = '" .$products_id . "' and attributes_display_only != '1' and attributes_price_base_included='1'";
      
      $product_attresult = mysqli_query($zendb, $product_att_query);
	  $product_att_numrow =  mysqli_num_rows ( $product_att_query_array );

      $the_options_id= 'x';
      $the_base_price= 0;
// add attributes price to price
      if ($product_check['products_priced_by_attribute'] == '1' and $product_att_numrow >= 1) {
		  while ($product_att_data = mysqli_fetch_array($product_attresult)) {
			if ( $the_options_id != $product_att_data['options_id']) {
				$the_options_id = $product_att_data['options_id'];
				$the_base_price += (($product_att_data['price_prefix'] == '-') ? -1 : 1) * $product_att_data['options_values_price'];
			}
         }

        $the_base_price = $products_price + $the_base_price;
      } else {
        $the_base_price = $products_price;
      }
      return $the_base_price;
  }
	////
// Display Price Retail
// Specials and Tax Included
  public function zen_get_products_display_price($products_id) {
    global $zendb;


    $free_tag = "";
    $call_tag = "";

	$sql = "select products_tax_class_id, products_price, products_priced_by_attribute, product_is_free, product_is_call, products_type from products where products_id = '" . $products_id . "'" . " limit 1";
	$result = mysqli_query($zendb, $sql);
	$product_check = mysqli_fetch_array($result);
		
    if ($product_check['products_type'] == 3) {
      return '';
    }

    $show_display_price = '';
    $display_normal_price = $this->zen_get_products_base_price($products_id);
    $display_special_price = $this->zen_get_products_special_price($products_id, true);
    $display_sale_price = zen_get_products_special_price($products_id, false);

    $show_sale_discount = '';
    if (SHOW_SALE_DISCOUNT_STATUS == '1' and ($display_special_price != 0 or $display_sale_price != 0)) {
      if ($display_sale_price) {
        if (SHOW_SALE_DISCOUNT == 1) {
          if ($display_normal_price != 0) {
            $show_discount_amount = number_format(100 - (($display_sale_price / $display_normal_price) * 100),SHOW_SALE_DISCOUNT_DECIMALS);
          } else {
            $show_discount_amount = '';
          }
          $show_sale_discount = '<span class="productPriceDiscount">' . '<br />' . PRODUCT_PRICE_DISCOUNT_PREFIX . $show_discount_amount . PRODUCT_PRICE_DISCOUNT_PERCENTAGE . '</span>';

        } else {
          $show_sale_discount = '<span class="productPriceDiscount">' . '<br />' . PRODUCT_PRICE_DISCOUNT_PREFIX . $currencies->display_price(($display_normal_price - $display_sale_price), zen_get_tax_rate($product_check->fields['products_tax_class_id'])) . PRODUCT_PRICE_DISCOUNT_AMOUNT . '</span>';
        }
      } else {
        if (SHOW_SALE_DISCOUNT == 1) {
          $show_sale_discount = '<span class="productPriceDiscount">' . '<br />' . PRODUCT_PRICE_DISCOUNT_PREFIX . number_format(100 - (($display_special_price / $display_normal_price) * 100),SHOW_SALE_DISCOUNT_DECIMALS) . PRODUCT_PRICE_DISCOUNT_PERCENTAGE . '</span>';
        } else {
          $show_sale_discount = '<span class="productPriceDiscount">' . '<br />' . PRODUCT_PRICE_DISCOUNT_PREFIX . $currencies->display_price(($display_normal_price - $display_special_price), zen_get_tax_rate($product_check->fields['products_tax_class_id'])) . PRODUCT_PRICE_DISCOUNT_AMOUNT . '</span>';
        }
      }
    }

    if ($display_special_price) {
      $show_normal_price = '<span class="normalprice">' . $currencies->display_price($display_normal_price, zen_get_tax_rate($product_check->fields['products_tax_class_id'])) . ' </span>';
      if ($display_sale_price && $display_sale_price != $display_special_price) {
        $show_special_price = '&nbsp;' . '<span class="productSpecialPriceSale">' . $currencies->display_price($display_special_price, zen_get_tax_rate($product_check->fields['products_tax_class_id'])) . '</span>';
        if ($product_check->fields['product_is_free'] == '1') {
          $show_sale_price = '<br />' . '<span class="productSalePrice">' . PRODUCT_PRICE_SALE . '<s>' . $currencies->display_price($display_sale_price, zen_get_tax_rate($product_check->fields['products_tax_class_id'])) . '</s>' . '</span>';
        } else {
          $show_sale_price = '<br />' . '<span class="productSalePrice">' . PRODUCT_PRICE_SALE . $currencies->display_price($display_sale_price, zen_get_tax_rate($product_check->fields['products_tax_class_id'])) . '</span>';
        }
      } else {
        if ($product_check->fields['product_is_free'] == '1') {
          $show_special_price = '&nbsp;' . '<span class="productSpecialPrice">' . '<s>' . $currencies->display_price($display_special_price, zen_get_tax_rate($product_check->fields['products_tax_class_id'])) . '</s>' . '</span>';
        } else {
          $show_special_price = '&nbsp;' . '<span class="productSpecialPrice">' . $currencies->display_price($display_special_price, zen_get_tax_rate($product_check->fields['products_tax_class_id'])) . '</span>';
        }
        $show_sale_price = '';
      }
    } else {
      if ($display_sale_price) {
        $show_normal_price = '<span class="normalprice">' . $currencies->display_price($display_normal_price, zen_get_tax_rate($product_check->fields['products_tax_class_id'])) . ' </span>';
        $show_special_price = '';
        $show_sale_price = '<br />' . '<span class="productSalePrice">' . PRODUCT_PRICE_SALE . $currencies->display_price($display_sale_price, zen_get_tax_rate($product_check->fields['products_tax_class_id'])) . '</span>';
      } else {
        if ($product_check->fields['product_is_free'] == '1') {
          $show_normal_price = '<s>' . $currencies->display_price($display_normal_price, zen_get_tax_rate($product_check->fields['products_tax_class_id'])) . '</s>';
        } else {
          $show_normal_price = $currencies->display_price($display_normal_price, zen_get_tax_rate($product_check->fields['products_tax_class_id']));
        }
        $show_special_price = '';
        $show_sale_price = '';
      }
    }

    if ($display_normal_price == 0) {
      // don't show the $0.00
      $final_display_price = $show_special_price . $show_sale_price . $show_sale_discount;
    } else {
      $final_display_price = $show_normal_price . $show_special_price . $show_sale_price . $show_sale_discount;
    }

    // If Free, Show it
    if ($product_check->fields['product_is_free'] == '1') {
      if (OTHER_IMAGE_PRICE_IS_FREE_ON=='0') {
        $free_tag = '<br />' . PRODUCTS_PRICE_IS_FREE_TEXT;
      } else {
        $free_tag = '<br />' . zen_image(DIR_WS_TEMPLATE_IMAGES . OTHER_IMAGE_PRICE_IS_FREE, PRODUCTS_PRICE_IS_FREE_TEXT);
      }
    }

    // If Call for Price, Show it
    if ($product_check->fields['product_is_call']) {
      if (PRODUCTS_PRICE_IS_CALL_IMAGE_ON=='0') {
        $call_tag = '<br />' . PRODUCTS_PRICE_IS_CALL_FOR_PRICE_TEXT;
      } else {
        $call_tag = '<br />' . zen_image(DIR_WS_TEMPLATE_IMAGES . OTHER_IMAGE_CALL_FOR_PRICE, PRODUCTS_PRICE_IS_CALL_FOR_PRICE_TEXT);
      }
    }

    return $final_display_price . $free_tag . $call_tag;
  }

	
	
 /*
 * Look up SHOW_XXX_INFO switch for product ID and product type
 */
    public function zen_get_show_product_switch($lookup, $field, $suffix= 'SHOW_', $prefix= '_INFO', $field_prefix= '_', $field_suffix='') {
      global $zendb;

      $sql = "select products_type from products where products_id='" . $lookup . "'";
      $sql_result = mysqli_query($zendb, $sql);
	  $type_lookup = mysqli_fetch_array($sql_result);
      
      $protypesql = "select type_handler from product_types where type_id = '" . $type_lookup['products_type'] . "'";
      $protypesql_result = mysqli_query($zendb, $protypesql);
	  $show_key = mysqli_fetch_array($protypesql_result);


      $zv_key = strtoupper($suffix . $show_key['type_handler'] . $prefix . $field_prefix . $field . $field_suffix);

      $confsql = "select configuration_key, configuration_value from product_type_layout where configuration_key='" . $zv_key . "'";
      $confsql_result = mysqli_query($zendb, $confsql);
      $confsql_result_array = mysqli_fetch_array($protypesql_result);
	  $zv_key_value = mysqli_num_rows ( $confsql_result );
      if ($zv_key_value > 0) {
        return $confsql_result_array['configuration_value'];
      } else {
        $sql = "select configuration_key, configuration_value from configuration where configuration_key='" . $zv_key . "'";
		$confsql_result = mysqli_query($zendb, $sql);
		$zv_key_value = mysqli_num_rows ( $confsql_result );
        if ($zv_key_value > 0) {
          return $zv_key_value['configuration_value'];
        } else {
          return false;
        }
      }
    }
	
	/*
 *  Check if product has attributes values
 */
  public function zen_has_product_attributes_values($products_id) {
    global $zendb;
    $attributes_query = "select sum(options_values_price) as total
                         from products_attributes
                         where products_id = '" . $products_id . "'";
                         
    $attributes_result = mysqli_query($zendb, $attributes_query);
    $attributes = mysqli_fetch_array($attributes_result);

    if ($attributes['total'] != 0) {
      return true;
    } else {
      return false;
    }
  }
	
	public function calculate_discountIDsP($id,$qty,$price){
		global $zendb;
		$productDiscountQry = "SELECT * from products_discounts where id ='" . $id . "' order by discount_qty ASC";
		$productDiscount  = mysqli_query($zendb, $productDiscountQry);
		$productDiscountresult  = mysqli_fetch_array($productDiscount);
		$items = array();
		$productDiscountresult["max_qty"] = $this->getmaxQty($id);
		$productDiscountresult["min_qty"] = $this->getminQty($id);
		$productDiscountresult["max_dis"] = $this->getMaxDisct($id,$price);
		$productDiscountresult["min_dis"] = $this->getMinDisct($id,$price);
		
		return $productDiscountresult;  
	}
	
	public function getmaxQty($id){
		global $zendb;
		$productDiscountQry = "SELECT discount_qty from products_discounts where id ='" . $id . "' order by discount_qty DESC limit 1";
		$productDiscount = mysqli_query($zendb, $productDiscountQry);
		$productDiscountresult = mysqli_fetch_array($productDiscount);
		$items = $productDiscountresult["discount_qty"]; 
		
		return $items;  
	}
	
	public function getminQty($id){
		global $zendb;
		$productDiscountQry = "SELECT discount_qty from products_discounts where id ='" . $id . "' order by discount_qty ASC limit 1";
		$productDiscount = mysqli_query($zendb, $productDiscountQry);
		$productDiscountresult = mysqli_fetch_array($productDiscount);
		$items = $productDiscountresult["discount_qty"]; 
		
		return $items;  
	}
	
	
	
	public function getMaxDisct($id,$price){
		global $zendb;
		$productDiscountQry = "SELECT * from products_discounts where id ='" . $id . "' order by discount_qty DESC limit 1";
		$productDiscount   = mysqli_query($zendb, $productDiscountQry);
		$productDiscountresult = mysqli_fetch_array($productDiscount);
		$discountPct        = $productDiscountresult['discount_pct']; 
		$step               = $productDiscountresult['round_to_nearest']; 
		$totalDiscount      = round($price*($discountPct/100),2);
		$multiplicand       = round(( $totalDiscount / $step ),2);
		$rest               = fmod($totalDiscount,$step);
		if( $rest > $step/2 ) $multiplicand++; // round up if needed
		$roundedvalue       = round(( $step*$multiplicand),2);
		$totalDiscount      = $price-$roundedvalue;
		$TDis = $totalDiscount;
		return $TDis;  
	}
	
	public function getMinDisct($id,$price){
		global $zendb;
		$productDiscountQry = "SELECT * from products_discounts where id ='" . $id . "' order by discount_qty ASC limit 1";
		$productDiscount    = mysqli_query($zendb, $productDiscountQry);
		$productDiscountresult = mysqli_fetch_array($productDiscount);
		$discountPct        = $productDiscountresult['discount_pct']; 
		$step               = $productDiscountresult['round_to_nearest']; 
		$totalDiscount      = round($price*($discountPct/100),2);
		$multiplicand       = round(( $totalDiscount / $step ),2);
		$rest               = fmod($totalDiscount,$step);
		if( $rest > $step/2 ) $multiplicand++; // round up if needed
		$roundedvalue       = round(($step*$multiplicand),2);
		$totalDiscount      = $price-$roundedvalue;
		$TDis = $totalDiscount;
		return $TDis;  
	}
}

?>
