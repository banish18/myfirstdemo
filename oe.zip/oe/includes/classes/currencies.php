<?php
require_once($_SERVER['CONTEXT_DOCUMENT_ROOT'].'/customer-order-tool/officeapp/db/db.inc');
class currencies {
  var $currencies;

  // class constructor
  function currencies() {
	global $zendb;
   $this->currencies = array();
   $currencies_query = "select code, title, symbol_left, symbol_right, decimal_point,
                                thousands_point, decimal_places, value
                        from currencies";
  
   $currencies = mysqli_query($zendb, $currencies_query);
  
	while ($currency = mysqli_fetch_array($currencies)) {
	$this->currencies[$currency['code']] = array('title' => $currency['title'],
		'symbol_left' => $currency['symbol_left'],
		'symbol_right' => $currency['symbol_right'],
		'decimal_point' => $currency['decimal_point'],
		'thousands_point' => $currency['thousands_point'],
		'decimal_places' => $currency['decimal_places']);
		}
			
   return $this->currencies;
  }

  // class methods
  function format($number, $calculate_currency_value = true, $currency_type = '', $currency_value = '') {

    if (empty($currency_type)) $currency_type = $_SESSION['currency'];

    if ($calculate_currency_value == true) {
      $rate = (zen_not_null($currency_value)) ? $currency_value : $this->currencies[$currency_type]['value'];
      $format_string = $this->currencies[$currency_type]['symbol_left'] . number_format(zen_round($number * $rate, $this->currencies[$currency_type]['decimal_places']), $this->currencies[$currency_type]['decimal_places'], $this->currencies[$currency_type]['decimal_point'], $this->currencies[$currency_type]['thousands_point']) . $this->currencies[$currency_type]['symbol_right'];
    } else {
      $format_string = $this->currencies[$currency_type]['symbol_left'] . number_format(zen_round($number, $this->currencies[$currency_type]['decimal_places']), $this->currencies[$currency_type]['decimal_places'], $this->currencies[$currency_type]['decimal_point'], $this->currencies[$currency_type]['thousands_point']) . $this->currencies[$currency_type]['symbol_right'];
    }

    if ((DOWN_FOR_MAINTENANCE=='true' and DOWN_FOR_MAINTENANCE_PRICES_OFF=='true') and (!strstr(EXCLUDE_ADMIN_IP_FOR_MAINTENANCE, $_SERVER['REMOTE_ADDR']))) {
      $format_string= '';
    }

    return $format_string;
  }

  function value($number, $calculate_currency_value = true, $currency_type = '', $currency_value = '') {

    if (empty($currency_type)) $currency_type = $_SESSION['currency'];

    if ($calculate_currency_value == true) {
      if ($currency_type == DEFAULT_CURRENCY) {
        $rate = (zen_not_null($currency_value)) ? $currency_value : 1/$this->currencies[$_SESSION['currency']]['value'];
      } else {
        $rate = (zen_not_null($currency_value)) ? $currency_value : $this->currencies[$currency_type]['value'];
      }
      $currency_value = zen_round($number * $rate, $this->currencies[$currency_type]['decimal_places']);
    } else {
      $currency_value = zen_round($number, $this->currencies[$currency_type]['decimal_places']);
    }

    return $currency_value;
  }

  function is_set($code) {
    if (isset($this->currencies[$code]) && zen_not_null($this->currencies[$code])) {
      return true;
    } else {
      return false;
    }
  }

  function get_value($code) {
    return $this->currencies[$code]['value'];
  }

  function get_decimal_places($code) {
    return $this->currencies[$code]['decimal_places'];
  }

  function display_price($products_price, $products_tax, $quantity = 1) {
    return $this->format(zen_add_tax($products_price, $products_tax) * $quantity);
  }
}
?>
