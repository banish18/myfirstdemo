<?php
$rootPath = $_SERVER['CONTEXT_DOCUMENT_ROOT'].'/customer-order-tool/officeapp/oe/';
require_once($rootPath.'constant/shipping.php');

/**
 * File contains the order-processing class ("order")
 *
 * @package classes
 * @copyright Copyright 2003-2012 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: Ian Wilson  Fri Jun 1 14:21:21 2012 +0000 Modified in v1.5.1 $
 */
/**
 * order class
 *
 * Handles all order-processing functions
 *
 * @package classes
 */
require_once($rootPath.'includes/classes/currencies.php');
require_once($rootPath.'includes/database_tables.php');
require_once($rootPath.'includes/functions/pack_products.php');
require_once($rootPath.'includes/modules/order_total/ot_tax.php');
require_once($rootPath.'includes/modules/order_total/ot_order_discount.php');
require_once($rootPath.'includes/modules/order_total/ot_group_pricing.php');
require_once($rootPath.'includes/modules/order_total/ot_label_desc.php');
require_once($rootPath.'includes/modules/order_total/ot_coupon.php');
require_once($rootPath.'includes/modules/order_total/ot_subtotal.php');
require_once($rootPath.'includes/modules/order_total/ot_total.php');
require_once($rootPath.'includes/modules/order_total/ot_shipping.php');

class order{
  var $info, $totals, $products, $customer, $delivery, $content_type, $email_low_stock, $products_ordered_attributes,
  $products_ordered, $products_ordered_email, $attachArray;

  function order($order_id = '') {
	global $zendb;
    $this->info = array();
    $this->totals = array();
    $this->products = array();
    $this->customer = array();
    $this->delivery = array();
    $this->cart();
  }
  
  function cart() {
	  
    global $zendb, $currencies,$order_total;
	
    //$decimals = $currencies->get_decimal_places($_SESSION['currency']);

    //$this->content_type = $_SESSION['cart']->get_content_type();

    $customer_address_query = "select c.customers_firstname, c.customers_lastname, c.customers_telephone,
                                    c.customers_email_address, ab.entry_company, ab.entry_street_address,
                                    ab.entry_suburb, ab.entry_postcode, ab.entry_city, ab.entry_zone_id,
                                    z.zone_name, co.countries_id, co.countries_name,
                                    co.countries_iso_code_2, co.countries_iso_code_3,
                                    co.address_format_id, ab.entry_state
                                   from (" . TABLE_CUSTOMERS . " c, " . TABLE_ADDRESS_BOOK . " ab )
                                   left join " . TABLE_ZONES . " z on (ab.entry_zone_id = z.zone_id)
                                   left join " . TABLE_COUNTRIES . " co on (ab.entry_country_id = co.countries_id)
                                   where c.customers_id = '" . (int)$_SESSION['customer_id'] . "'
                                   and ab.customers_id = '" . (int)$_SESSION['customer_id'] . "'
                                   and c.customers_default_address_id = ab.address_book_id";

    $customer_addressRes  	= mysqli_query($zendb, $customer_address_query);
    $customer_address		= mysqli_fetch_array($customer_addressRes);
    $shipping_address_query = "select ab.entry_firstname, ab.entry_lastname, ab.entry_company,
                                    ab.entry_street_address, ab.entry_suburb, ab.entry_postcode,
                                    ab.entry_city, ab.entry_zone_id, z.zone_name, ab.entry_country_id,
                                    c.countries_id, c.countries_name, c.countries_iso_code_2,
                                    c.countries_iso_code_3, c.address_format_id, ab.entry_state
                                   from " . TABLE_ADDRESS_BOOK . " ab
                                   left join " . TABLE_ZONES . " z on (ab.entry_zone_id = z.zone_id)
                                   left join " . TABLE_COUNTRIES . " c on (ab.entry_country_id = c.countries_id)
                                   where ab.customers_id = '" . (int)$_SESSION['customer_id'] . "'
                                   and ab.address_book_id = '" . (int)$_SESSION['sendto']. "'";

    $shipping_addressRes  	= mysqli_query($zendb, $shipping_address_query);
    $shipping_address		= mysqli_fetch_array($shipping_addressRes);

    $billing_address_query = "select ab.entry_firstname, ab.entry_lastname, ab.entry_company,
                                   ab.entry_street_address, ab.entry_suburb, ab.entry_postcode,
                                   ab.entry_city, ab.entry_zone_id, z.zone_name, ab.entry_country_id,
                                   c.countries_id, c.countries_name, c.countries_iso_code_2,
                                   c.countries_iso_code_3, c.address_format_id, ab.entry_state
                                  from " . TABLE_ADDRESS_BOOK . " ab
                                  left join " . TABLE_ZONES . " z on (ab.entry_zone_id = z.zone_id)
                                  left join " . TABLE_COUNTRIES . " c on (ab.entry_country_id = c.countries_id)
                                  where ab.customers_id = '" . (int)$_SESSION['customer_id'] . "'
                                  and ab.address_book_id = '" . (int)$_SESSION['billto'] . "'";

 
    $billing_addressRes  	= mysqli_query($zendb, $billing_address_query);
    $billing_address		= mysqli_fetch_array($billing_addressRes);
    
    
    

    // set default tax calculation for not-logged-in visitors
    $taxCountryId = $taxZoneId = -1;

    $tax_address_query = '';
    switch (STORE_PRODUCT_TAX_BASIS) {
      case 'Shipping':
      $tax_address_query = "select ab.entry_country_id, ab.entry_zone_id
                              from " . TABLE_ADDRESS_BOOK . " ab
                              left join " . TABLE_ZONES . " z on (ab.entry_zone_id = z.zone_id)
                              where ab.customers_id = '" . (int)$_SESSION['customer_id'] . "'
                              and ab.address_book_id = '" . (int)($this->content_type == 'virtual' ? $_SESSION['billto'] : $_SESSION['sendto']) . "'";
      break;
      case 'Billing':
      $tax_address_query = "select ab.entry_country_id, ab.entry_zone_id
                              from " . TABLE_ADDRESS_BOOK . " ab
                              left join " . TABLE_ZONES . " z on (ab.entry_zone_id = z.zone_id)
                              where ab.customers_id = '" . (int)$_SESSION['customer_id'] . "'
                              and ab.address_book_id = '" . (int)$_SESSION['billto'] . "'";
      break;
      case 'Store':
      if ($billing_address->fields['entry_zone_id'] == STORE_ZONE) {

        $tax_address_query = "select ab.entry_country_id, ab.entry_zone_id
                                from " . TABLE_ADDRESS_BOOK . " ab
                                left join " . TABLE_ZONES . " z on (ab.entry_zone_id = z.zone_id)
                                where ab.customers_id = '" . (int)$_SESSION['customer_id'] . "'
                                and ab.address_book_id = '" . (int)$_SESSION['billto'] . "'";
      } else {
        $tax_address_query = "select ab.entry_country_id, ab.entry_zone_id
                                from " . TABLE_ADDRESS_BOOK . " ab
                                left join " . TABLE_ZONES . " z on (ab.entry_zone_id = z.zone_id)
                                where ab.customers_id = '" . (int)$_SESSION['customer_id'] . "'
                                and ab.address_book_id = '" . (int)($this->content_type == 'virtual' ? $_SESSION['billto'] : $_SESSION['sendto']) . "'";
      }
    }
    if ($tax_address_query != '') {
	  $tax_addressRes  	= mysqli_query($zendb, $tax_address_query);
	  $tax_address		= mysqli_fetch_array($tax_addressRes);
      if (count($tax_address) > 0) {
        $taxCountryId = $tax_address['entry_country_id'];
        $taxZoneId = $tax_address['entry_zone_id'];
      }
    }
   
    
    $class =& $_SESSION['payment'];
    $_SESSION['currency'] = "USD";
    $_SESSION['payML'] = $_SESSION['payment'];
	$shipCOst = '0';
	if(isset($_SESSION['shipping'])){
		$shipCOst 	 = $_SESSION['shipping']['cost'];
	}
	$shipping_method = '';
	$shipping_id = '';
	if(isset($_SESSION['shipping'])){
		$shipping_method = (is_array($_SESSION['shipping']) ? $_SESSION['shipping']['title'] : $_SESSION['shipping']);
		$shipping_id = $_SESSION['shipping']['id'];
	}
	
   
	$shipCOstArr = [];
    $this->info = array('order_status' => DEFAULT_ORDERS_STATUS_ID,
                        'currency' => $_SESSION['currency'],
                        'currency_value' => '1.000000',
                        'payment_method' => (isset($_SESSION['pay_title'])?$_SESSION['pay_title']:''),
                        'payment_module_code' => (isset($_SESSION['pay_code'])?$_SESSION['pay_code']:''),
                        'coupon_code' => '',
                        'shipping_method' => $shipping_method,
                        'shipping_module_code' => $shipping_id,
                        'shipping_cost' => $shipCOst,
                        'par_cost' => $shipCOstArr,
                        'subtotal' => 0,
                        'shipping_tax' => 0,
                        'tax' => 0,
                        'total' => 0,
                        'tax_groups' => array(),
                        'comments' => (isset($_SESSION['comments']) ? $_SESSION['comments'] : ''),
                         'shipping_comments' => (isset($_SESSION['special_shipping_instructions']) ? $_SESSION['special_shipping_instructions'] : ''),
                        'ip_address' => $_SESSION['customers_ip_address'] . ' - ' . $_SERVER['REMOTE_ADDR']
                        );                   
    $this->customer = array('firstname' => $customer_address['customers_firstname'],
                            'lastname' => $customer_address['customers_lastname'],
                            'company' => $customer_address['entry_company'],
                            'street_address' => $customer_address['entry_street_address'],
                            'suburb' => $customer_address['entry_suburb'],
                            'city' => $customer_address['entry_city'],
                            'postcode' => $customer_address['entry_postcode'],
                            'state' => ((!empty($customer_address['entry_state'])) ? $customer_address['entry_state'] : $customer_address['zone_name']),
                            'zone_id' => $customer_address['entry_zone_id'],
                            'country' => array('id' => $customer_address['countries_id'], 'title' => $customer_address['countries_name'], 'iso_code_2' => $customer_address['countries_iso_code_2'], 'iso_code_3' => $customer_address['countries_iso_code_3']),
                            'format_id' => (int)$customer_address['address_format_id'],
                            'telephone' => $customer_address['customers_telephone'],
                            'email_address' => $customer_address['customers_email_address']);
                            
    $this->delivery = array('firstname' => $shipping_address['entry_firstname'],
                            'lastname' => $shipping_address['entry_lastname'],
                            'company' => $shipping_address['entry_company'],
                            'street_address' => $shipping_address['entry_street_address'],
                            'suburb' => $shipping_address['entry_suburb'],
                            'city' => $shipping_address['entry_city'],
                            'postcode' => $shipping_address['entry_postcode'],
                            'state' => ((!empty($shipping_address['entry_state'])) ? $shipping_address['entry_state'] : $shipping_address['zone_name']),
                            'zone_id' => $shipping_address['entry_zone_id'],
                            'country' => array('id' => $shipping_address['countries_id'], 'title' => $shipping_address['countries_name'], 'iso_code_2' => $shipping_address['countries_iso_code_2'], 'iso_code_3' => $shipping_address['countries_iso_code_3']),
                            'country_id' => $shipping_address['entry_country_id'],
                            'format_id' => (int)$shipping_address['address_format_id']);

    $this->billing = array('firstname' => $billing_address['entry_firstname'],
                           'lastname' => $billing_address['entry_lastname'],
                           'company' => $billing_address['entry_company'],
                           'street_address' => $billing_address['entry_street_address'],
                           'suburb' => $billing_address['entry_suburb'],
                           'city' => $billing_address['entry_city'],
                           'postcode' => $billing_address['entry_postcode'],
                           'state' => ((!empty($billing_address['entry_state'])) ? $billing_address['entry_state'] : $billing_address['zone_name']),
                           'zone_id' => $billing_address['entry_zone_id'],
                           'country' => array('id' => $billing_address['countries_id'], 'title' => $billing_address['countries_name'], 'iso_code_2' => $billing_address['countries_iso_code_2'], 'iso_code_3' => $billing_address['countries_iso_code_3']),
                           'country_id' => $billing_address['entry_country_id'],
                           'format_id' => (int)$billing_address['address_format_id']);
    $shoppingCartclass = new shoppingCart;                       
    $productsSess = $shoppingCartclass->get_all_products($_SESSION['cart']['contents']);
	 $productsArr = [];
    if($productsSess){
      for ($i=0, $n=sizeof($productsSess); $i<$n; $i++) {
        $pRar = $productsSess[$i]['warehouse_id'];
        $productsArr[$pRar][] = $productsSess[$i];
      }
    }
    $f = 0;
    $shipamt = "";
    $totalshipamt = "";
    $this->info['warehouse_id'] = []; 
	$_SESSION['product_detailed_info_var'] = [];
	$this->products = [];
	$this->info['subtotal'] = [];
	$this->info['taxrates'] = [];
    foreach ($productsArr as $kyy => $products) {
		  $shipamt = '';
		  $index = 0;
		  $tsubtotal = "";
		  $taxtotal = "0";
		  $ttax = [];
		  $crt = "0";
		  $this->info['warehouse_id'][] = $kyy;
		  for ($i=0, $n=sizeof($products); $i<$n; $i++) {
			if (($i/2) == floor($i/2)) {
			  $rowClass="rowEven";
			} else {
			  $rowClass="rowOdd";
			}
			/*if(count($productsArr) > 1){
				$pTaxlxassID = $this->checkTaxclsid($productsArr);
			}else{
				$pTaxlxassID = $products[$i]['tax_class_id'];
			}*/
			$pTaxlxassID = $this->checkTaxclsid($productsArr);
			$taxRates = zen_get_multiple_tax_rates($pTaxlxassID, $taxCountryId, $taxZoneId);
			
			$tax_rate = zen_get_tax_rate($pTaxlxassID, $taxCountryId, $taxZoneId);
			$pprice = $this->productPrice($products[$i]['price'],$products[$i]['id'],$products[$i]['quantity']);
			if($tax_rate != "0"){
				$taxtotal += $pprice['product_price']*$products[$i]['quantity'];
				$ttax[] = array('tax_rate' => $tax_rate,'tax_groups' => $taxRates,'value' => $taxtotal);
			}
			
			//echo "<pre>";print_r($ttax);
			
			
			 $_SESSION['product_detailed_info_var'][$products[$i]['id']]['total_price_val']=$products[$i]['price']*$products[$i]['quantity']; 
			 $_SESSION['product_detailed_info_var'][$products[$i]['id']]['warehouse_id']=$products[$i]['warehouse_id'];
			 
			$_SESSION['product_detailedDp'][$products[$i]['id']]['warehouse_id']=$products[$i]['warehouse_id'];
			$_SESSION['product_detailedDp'][$products[$i]['id']]['cost']=$products[$i]['pdcost'];
			$_SESSION['product_detailedDp'][$products[$i]['id']]['qty']=$products[$i]['quantity'];
			$crt = $crt+$products[$i]['price']*$products[$i]['quantity'];
			$this->products[$kyy][] = array('qty' => $products[$i]['quantity'],
											'name' => $products[$i]['name'],
											'warehouse_id' => $products[$i]['warehouse_id'],
											'model' => $products[$i]['model'],
											'tax' => $tax_rate,
											'tax_groups'=>$taxRates,
											'tax_description' => '',
											'price' => $products[$i]['price'],
											'final_price' => $products[$i]['price'],
											'onetime_charges' =>'',
											'weight' => $products[$i]['weight'],
											'products_priced_by_attribute' => $products[$i]['products_priced_by_attribute'],
											'product_is_free' => $products[$i]['product_is_free'],
											'products_discount_type' => $products[$i]['products_discount_type'],
											'products_discount_type_from' => $products[$i]['products_discount_type_from'],
											'id' => $products[$i]['id'],
											'products_description' => $products[$i]['description'],
											'rowClass' => $rowClass);
			$index++;		
			
		}
		$this->info['subtotal'][$kyy] = $crt;
		$this->info['taxrates'][$kyy] = end($ttax);
	}
	$this->info['ordertotal'] = [];
	/*  */
	$this->orderSubtotal($this->products);
	/*  */
	$cart_total = $_SESSION['cart_total'];
	$this->info['total'] = [];
	/* Label Description value */
	$descriptionData = $this->label_description($this->info['warehouse_id'],$this->info);
	if(!empty($descriptionData)){
		$this->info['ordertotal'][] = $descriptionData;
	}
	/* Global Discount */
	$discountData = $this->discount_calculation($this->info);
	if(!empty($discountData)){
		$this->info['ordertotal'][] = $discountData;
		if(isset($_SESSION['d_total_amt']))
		$this->info['d_total_amt']  = $_SESSION['d_total_amt'];
	}else{
		$this->info['d_total_amt'] = [];
	}

	/* Group Discount */
	$groupdiscountData = $this->group_discount_calculation($this->info);
	if(!empty($groupdiscountData)){
		$this->info['ordertotal'][] = $groupdiscountData;
		if(isset($_SESSION['gd_total_amt']))
		$this->info['gd_total_amt']  = $_SESSION['gd_total_amt'];
	}else{
		$this->info['gd_total_amt'] = [];
	}
	
	
    
	/* ot sub total */
	$ot_sub_total = $this->ot_subtotal($this->info['ordertotal']);
	$this->info['split_subtotal'] = $ot_sub_total;
	
	if(isset($_SESSION["coupon_code"]) && $_SESSION["coupon_code"] != ""){
		$coupontotal 		= new ot_coupon;
		$coupontotalData  = $coupontotal->process($this->info['split_subtotal'],$_SESSION["coupon_code"]);
		$this->applyCoupon($_SESSION["coupon_code"]);
		$this->info['ordertotal'][] = $coupontotalData;
	}
	$ot_sub_total = $this->ot_subtotal($this->info['ordertotal']);
	if(!empty($ot_sub_total)){
		$this->info['ordertotal'][] = $ot_sub_total;
	}
	
	if(isset($_SESSION["coupon_amount"]) && !empty($_SESSION["coupon_amount"])){
		$this->info['coupon_amount'] = $_SESSION["coupon_amount"];
	}else{
		$this->info['coupon_amount'] = [];
	}
	/* ot tax total */
	$taxData = $this->tax_calculation($this->info);
	if(!empty($taxData)){
		$this->info['ordertotal'][] = $taxData;
	}
	/* ot total */
	$ot_total = $this->ot_total($ot_sub_total,$taxData);
	if(!empty($ot_total)){
		$this->info['ordertotal'][] = $ot_total;
	}
	$this->info['ot_classes'] = $this->info['ordertotal'];
	/*shipping*/
	$ot_shipping = $this->ot_shipping($this);
	//echo "<pre>";print_r($this->info['taxrates']);
	if(!empty($ot_shipping)){
		$this->info['ot_classes'][] = $ot_shipping;
	}
	
	/*echo "<pre>";print_r($_SESSION['shipping']);
	echo "<pre>";print_r($this->info['ot_classes']);
	die;*/
	
	$splitVals = [];
	foreach($this->info['ordertotal'] as $key => $value){
		foreach($value as $kk => $vv){
			$splitVals[$kk][] = $vv;
		}
	}
	$oTtotals = [];
	foreach($splitVals as $key => $value){
		$splitValsd = [];
		foreach($value as $kk => $vv){
			foreach($vv as $kkd => $vvv){
				$splitValsd[] = $vvv;
			}
		}
		$oTtotals[$key] = $splitValsd;
	}
	$this->info['shippingcomments'] = "";
	
	$this->info['ordertotal'] = $oTtotals;
    $this->info['order_split_tax'] = '';
  }
  
  /* check tax */
  function checkTaxclsid($productsArr){
	$txClsid = [];
	foreach ($productsArr as $key => $products) {
		for ($i=0, $n=sizeof($products); $i<$n; $i++) {
			if($products[$i]['tax_class_id'] != '0'){
				$txClsid[] = $products[$i]['tax_class_id'];
			}
		}
		if(count($txClsid) > 0){
			$txsId = $txClsid[0];
		}else{
			$txsId = '0';
		}
	}
	return $txsId;
  }
 
  /* Subtotal */
  function ot_subtotal($oTtotals) {
	 $subtotal 		= new ot_subtotal;
	  $subtotalData  = $subtotal->process($oTtotals);
	  return $subtotalData;
  }
  /* Total */
  function ot_total($ot_sub_total,$taxData) {
	 $total 	 = new ot_total;
	 $totalData  = $total->process($ot_sub_total,$taxData);
	 return $totalData;
  }
  /* Label Description */
  function label_description($warehouseIds,$orderValues){
	  $label_desc 		= new ot_label_desc;
	  $descriptionData  = $label_desc->process($warehouseIds,$orderValues);
	  return $descriptionData;
  }
  
   /* Shipping */
  function ot_shipping($order) {
	 $shipping 	 = new ot_shipping;
	 $shippingData  = $shipping->process($order);
	 return $shippingData;
  }
  
  
  
  /* Function tax calculation */
  
  function tax_calculation($taxValues){
	  $ot_tax 	= new ot_tax;
	  $taxPrice = $ot_tax->process($taxValues);
	  return $taxPrice;
  }
  
  /* Function discount calculation */
  
  function discount_calculation($orderValues){
	  $ot_order_discount 	= new ot_order_discount;
	  $discountPrice = $ot_order_discount->process($orderValues);
	  return $discountPrice;
  }
  
  /* Group Discount */
  function group_discount_calculation($orderValues){
	  $ot_group_pricing 	= new ot_group_pricing;
	  $gdiscountPrice = $ot_group_pricing->process($orderValues);
	  return $gdiscountPrice;
  }
  
  
  /* Order subtotal variable */
  
  function orderSubtotal($order_products){
	  global $zendb;
	  $this->info['sales_items_total'] = [];
	  $this->info['other_items_total'] = [];
	  $this->info['quantity_discount_items'] = [];
      foreach($order_products as $key => $_products)      
      {		   
	    $salesItemTotal    = "0";
	    $ItemsubTotal 	   = "0";
	    $oterItemTotal     = "0";
		foreach($_products as $_product){
		   $pro_normal_price = zen_get_products_base_price($_product['id']);
		   $pro_special_price = zen_get_products_special_price($_product['id'], true);
		   $pro_sale_price = zen_get_products_special_price($_product['id'], false);
		   if($pro_special_price !="")
		   {
			   $salesItemTotal += $pro_special_price*$_product['qty'];
		   }
		   elseif($pro_sale_price != "")
		   {
			   $salesItemTotal += $pro_sale_price*$_product['qty'];
		   }
		   else
		   {
			  /* get and calculate discount products particularly */
			  /* Get Product discount code */
			  $productDetailQry = "SELECT discount_code
					  from " . TABLE_PRODUCTS_DETAILS . "
					  where products_id ='" . $_product['id'] . "'";
			  $productDetailqry = mysqli_query($zendb,$productDetailQry);
			  $productDetail = mysqli_fetch_array($productDetailqry);
			  $discount_code = $productDetail['discount_code'];
			  $discountCodeData = $this->calculate_discountCodeID($discount_code);
			  if($discount_code == "0"){
				  $oterItemTotal +=  $pro_normal_price*$_product['qty'];
			  }else{
				$ppe =  $_product['price'];
				$ppt = $ppe * $_product['qty'];
				$totalAmt = $ppe*$_product['qty'];
				$discount = $this->calculate_discountIDs($discount_code,$ppe,$_product['qty'],$totalAmt); 
				$qty = $_product['qty'];
						
				if(($qty >= $discountCodeData['minProductQuantity'])&&($qty < $discountCodeData['maxProductQuantity'])){
					$totalAmt     = $ppe*$qty;
					$discount     = round((($totalAmt*$discountCodeData['minProductQuantityPercentage'])/100), 2);
					$qtYdiscount     = round((($ppe*$discountCodeData['minProductQuantityPercentage'])/100), 2);
					//$ppt          =  $totalAmt - $discount;
					$ppe          = $ppe - $qtYdiscount;	
					$ppt          =  $ppe * $qty;		 
				}
				if($qty >= $discountCodeData['maxProductQuantity']){
					$totalAmt     = $ppe*$qty;
					$discount     = round((($totalAmt*$discountCodeData['maxProductQuantityPercentage'])/100), 2);
					$qtYdiscount     = round((($ppe*$discountCodeData['maxProductQuantityPercentage'])/100), 2);
					//$ppt          =  $totalAmt - $discount;
					$ppe          = $ppe - $qtYdiscount;			
					$ppt          =  $ppe * $qty;		
				}
				if($qty < $discountCodeData['minProductQuantity']){
					$totalAmt     = $ppe*$qty;
					$discount     = 0;
					$qtYdiscount     = 0;
					$ppe          = $ppe - $qtYdiscount;			
					$ppt          =  $ppe * $qty;		
				}
				$ItemsubTotal += $ppt;
			  }
		   }
		}
		if($salesItemTotal != "0"){
			$this->info['sales_items_total'][$key] = round($salesItemTotal,2);
		}
		if($oterItemTotal != "0"){
			$this->info['other_items_total'][$key] 	= round($oterItemTotal,2);
		}
		if($ItemsubTotal != "0"){
			$this->info['quantity_discount_items'][$key]  = round($ItemsubTotal,2);
		}
	  }	        
  }
   /******************************** Function to add order record into the database ************************************/
  function create($zf_mode = 2) {
    global $zendb,$currencies,$order,$order_totals;
    $customers_id 					= $_SESSION['customer_id'];
    $customers_name 				= $this->customer['firstname'] . ' ' . $this->customer['lastname'];
    $customers_company 				= $this->customer['company'];
    $customers_street_address 		= $this->customer['street_address'];
    $customers_suburb 				= $this->customer['suburb'];
    $customers_city 				= $this->customer['city'];
    $customers_postcode 			= $this->customer['postcode'];
    $customers_state 				= $this->customer['state'];
    $customers_country 				= $this->customer['country']['title'];
    $customers_telephone 			= $this->customer['telephone'];
    $customers_email_address 		= $this->customer['email_address'];
    $customers_address_format_id 	= $this->customer['format_id'];
    $delivery_name 					= $this->delivery['firstname'] . ' ' . $this->delivery['lastname'];
    $delivery_company 				= $this->delivery['company'];
    $delivery_street_address 		= $this->delivery['street_address'];
    $delivery_suburb 				= $this->delivery['suburb'];
    $delivery_city 					= $this->delivery['city'];
    $delivery_postcode 				= $this->delivery['postcode'];
    $delivery_state 				= $this->delivery['state'];
    $delivery_country 				= $this->delivery['country']['title'];
    $delivery_address_format_id 	= $this->delivery['format_id'];
    $billing_name 					= $this->billing['firstname'] . ' ' . $this->billing['lastname'];
    $billing_company 				= $this->billing['company'];
    $billing_street_address 		= $this->billing['street_address'];
    $billing_suburb 				= $this->billing['suburb'];
    $billing_city 					= $this->billing['city'];
    $billing_postcode 				= $this->billing['postcode'];
    $billing_state 					= $this->billing['state'];
    $billing_country 				= $this->billing['country']['title'];
    $billing_address_format_id 		= $this->billing['format_id'];
    $payment_method 				= ($this->info['payment_module_code'] == "dotpo"?"PO":$this->info['payment_module_code']);
    $payment_module_code 			= $this->info['payment_module_code'];
    $shipping_method 				= $this->info['shipping_method'];
    $shipping_module_code 			= $this->info['shipping_module_code'];
    $coupon_code 					= $this->info['coupon_code'];
    $cc_type 						= '';//$this->info['cc_type'];
    $cc_owner 						= '';//$this->info['cc_owner'];
    $cc_number 						= '';//$this->info['cc_number'];
    $cc_expires	 					= '';//$this->info['cc_expires'];
    $date_purchased 				= 'now()';
    $orders_status 					= $this->info['order_status'];
   
    $order_tax 						= '';
    $shipping_comments 				= $this->info['shipping_comments'];
    $currency 						= $this->info['currency'];
    $currency_value 				= $this->info['currency_value'];
    $ip_address 					=$_SESSION['customers_ip_address'] . ' - ' . $_SERVER['REMOTE_ADDR'];
    $orderDate                      = date('Y-m-d h:i:s');
	foreach($this->info['total'] as $key => $value){
		$order_total 					= $this->info['total'][$key];
		$sql_data_array = "insert into orders set 
				customers_id 					= '".$customers_id."',
				customers_name 				= '".$customers_name."',
				customers_company 			= '".$customers_company."',
				customers_street_address		= '".$customers_street_address."',
				customers_suburb 				= '".$customers_suburb."',
				customers_city 				= '".$customers_city."',
				customers_postcode 			= '".$customers_postcode."',
				customers_state 				= '".$customers_state."',
				customers_country 			= '".$customers_country."',
				customers_telephone	 		= '".$customers_telephone."',
				customers_email_address 		= '".$customers_email_address."',
				customers_address_format_id 	= '".$customers_address_format_id."',
				delivery_name				= '".$delivery_name."',
				delivery_company 				= '".$delivery_company."',
				delivery_street_address 		= '".$delivery_street_address."',
				delivery_suburb 				= '".$delivery_suburb."',
				delivery_city 				= '".$delivery_city."',
				delivery_postcode 			= '".$delivery_postcode."',
				delivery_state 				= '".$delivery_state."',
				delivery_country 				= '".$delivery_country."',
				delivery_address_format_id 	= '".$delivery_address_format_id."',
				billing_name 					= '".$billing_name."',
				billing_company 				= '".$billing_company."',
				billing_street_address 		= '".$billing_street_address."',
				billing_suburb 				= '".$billing_suburb."',
				billing_city 					= '".$billing_city."',
				billing_postcode 				= '".$billing_postcode."',
				billing_state 				= '".$billing_state."',
				billing_country 				= '".$billing_country."',
				billing_address_format_id 	= '".$billing_address_format_id."',
				payment_method 				= '".$payment_method."',
				payment_module_code 			= '".$payment_module_code."',
				shipping_method 				= '".$shipping_method."',
				shipping_module_code 			= '".$shipping_module_code."',
				coupon_code 					= '".$coupon_code."',
				cc_type 						= '".$cc_type."',
				cc_owner 						= '".$cc_owner."',
				cc_number	 					= '".$cc_number."',
				cc_expires 					= '".$cc_expires."',
				date_purchased 				= '".$orderDate."',
				orders_status 				= '".$orders_status."',
				order_total					= '".$order_total."',
				order_tax 					= '".$order_tax."',
				shipping_comments 			= '".$shipping_comments."',
				currency 						= '".$currency."',
				currency_value 				= '".$currency_value."',
				ip_address 					= '".$ip_address."'";			
		
		if (mysqli_query($zendb,$sql_data_array)) 
		{ 
			$res = array('status' => '1');
		} 
		else
		{ 
			$res = array('status' => '0',"message" => "ERROR: Could not able to execute $sql. "
				.mysqli_error($link));
		} 
		$orderIds[$key] =	mysqli_insert_id($zendb);
	}				
	return $orderIds;
  }
  
  
  /*
   * 
   * Entry in order detail table
   * 
   */
   
   function saveorderDetails($orderIds){
	   global $zendb;
	   foreach($orderIds as $key => $order_id){
		/******************* Get Order products ids *************************/
		/******************* Get Order products ids *************************/
		$products_query = "select products_id,warehouse_id from " . TABLE_ORDERS_PRODUCTS . "
									  where orders_id = '" . $order_id . "'"; 
		$pro 								= mysqli_query($zendb,$products_query);
		$proRes                             = mysqli_fetch_array($pro);
		$requested_ship_date 				= '';		
		$special_shipping_instructions 		= '';
		if(isset($_POST["shipping_instruction"])){
			$special_shipping_instructions	= $_POST["shipping_instruction"];	
		}else{
			$special_shipping_instructions	= '';	
		}
		if(isset($_POST["production_instruction"])){
			$special_production_instructions	= $_POST["production_instruction"];	
		}else{
			$special_production_instructions	= '';	
		}
		
		$ship_collect 						= '';	
		$order_notes_public 				= '';	
		$sql = "insert into orders_details (orders_id,requested_ship_date,special_shipping_instructions,special_production_instructions,order_notes_public,collect_acct)
						values('".$order_id."','".$requested_ship_date."','".$special_shipping_instructions."','".$special_production_instructions."','".$order_notes_public."','".$ship_collect."')";
		mysqli_query($zendb,$sql);	
		/*$shoppingCartclass = new shoppingCart;                       
		$productsSess = $shoppingCartclass->get_all_products($_SESSION['cart']['contents']);  			
		foreach ($productsSess as $value) {
			$ware = $value['warehouse_id'];
			$ConvertedArray[$ware][] = $value;
		}
		$i = 0; 
		foreach ($ConvertedArray as $key => $value) {
		  $boxesToShips = packProducts($value,1);
		  $newboxesToShips = [];
		  foreach ($boxesToShips as $kkey => $vvalue) {
			 $vvalue['warehouse_id'] = $key;
			 $newboxesToShips[$kkey] = $vvalue;
		  }
		  $aboxesToShips[] = $newboxesToShips;
		  $i++;
		}*/
		if(isset($_SESSION["boxesToShipss"]) && !empty($_SESSION["boxesToShipss"])){
			$aboxesToShips = $_SESSION["boxesToShipss"];
			$boxesToShip = serialize($aboxesToShips);
			/*******************  update warehouse_id into TABLE_ORDERS_DETAILS table ************************/
			mysqli_query($zendb,"update orders_details set warehouse_id = '" . $proRes['warehouse_id'] . "', packaging_details = '".$boxesToShip."' where orders_id = '" . $order_id . "'");
		}
	   }
   }
   
   /* 
    * 
    * Function to save order total table values
    * 
    */
	
	function saveOrdertotal($orderIds){
		global $zendb;
		foreach($orderIds as $key => $value){
			foreach($this->info['ordertotal'][$key] as $order_total){
				$title 	= $order_total['title'];
				$text 	= $order_total['text'];
				$ovalue = number_format((float)$order_total['value'], 2, '.', '');
				$class 	= $order_total['code'];
				if($title != ""){
					$sql 	= "insert into ".TABLE_ORDERS_TOTAL." set orders_id = '".$value."',title = '".$title."',text = '".$text."',value = '".$ovalue."',class = '".$class."'";
					mysqli_query($zendb,$sql);
				}
			}
		}
	}
   
    /* 
    * 
    * Function to save ordered product
    * 
    */
	function create_add_products($key,$zf_insert_id, $zf_mode = false) {
		global $zendb, $currencies, $order_total_modules, $order_totals;
		// initialized for the email confirmation
		$this->products_ordered = '';
		$this->products_ordered_html = '';
		/*$this->subtotal = 0;
		$this->total_tax = 0;*/

		// lowstock email report
		$this->email_low_stock='';
		$this->total_weight = '';
		$this->total_tax = 0;
		$this->total_cost = 0;
		
		
		for ($i=0, $n=sizeof($this->products[$key]); $i<$n; $i++) {
		  $custom_insertable_text = '';
		  // Stock Update - Joao Correia
		  if (STOCK_LIMITED == 'true') {
			if (DOWNLOAD_ENABLED == 'true') {
			  $stock_query_raw = "select p.products_quantity, pad.products_attributes_filename, p.product_is_always_free_shipping
								  from " . TABLE_PRODUCTS . " p
								  left join " . TABLE_PRODUCTS_ATTRIBUTES . " pa
								   on p.products_id=pa.products_id
								  left join " . TABLE_PRODUCTS_ATTRIBUTES_DOWNLOAD . " pad
								   on pa.products_attributes_id=pad.products_attributes_id
								  WHERE p.products_id = '" . $this->products[$key][$i]['id'] . "'";

			  // Will work with only one option for downloadable products
			  // otherwise, we have to build the query dynamically with a loop
			  $products_attributes = $this->products[$key][$i]['attributes'];
			  if (is_array($products_attributes)) {
				$stock_query_raw .= " AND pa.options_id = '" . $products_attributes[0]['option_id'] . "' AND pa.options_values_id = '" . $products_attributes[0]['value_id'] . "'";
			  }
			  $stock_values = mysqli_query($zendb,$stock_query_raw);
			} else {
			  $stock_values = mysqli_query($zendb,"select * from " . TABLE_PRODUCTS . " where products_id = '" . $this->products[$key][$i]['id']."'");
			}

			//$this->notify('NOTIFY_ORDER_PROCESSING_STOCK_DECREMENT_BEGIN');

			if (mysqli_num_rows($stock_values) > 0) {
			  $stock_values = mysqli_fetch_array($stock_values);
			  // do not decrement quantities if products_attributes_filename exists
			  if ((DOWNLOAD_ENABLED != 'true') || $stock_values['product_is_always_free_shipping'] == 2 || (!$stock_values['products_attributes_filename']) ) {
				$stock_left = $stock_values['products_quantity'] - $this->products[$key][$i]['qty'];
				$this->products[$key]['stock_reduce'] = $this->products[$key][$i]['qty'];
			  } else {
				$stock_left = $stock_values['products_quantity'];
			  }
			  mysqli_query($zendb,"update " . TABLE_PRODUCTS . " set products_quantity = '" . $stock_left . "' where products_id = '" . $this->products[$key][$i]['id'] . "'");
			  //        if ( ($stock_left < 1) && (STOCK_ALLOW_CHECKOUT == 'false') ) {
			  if ($stock_left <= 0) {
				// only set status to off when not displaying sold out
				if (SHOW_PRODUCTS_SOLD_OUT == '0') {
				  mysqli_query("update " . TABLE_PRODUCTS . " set products_status = 0 where products_id = '" . $this->products[$key][$i]['id'] . "'");
				}
			  }

			  // for low stock email
			  if ( $stock_left <= STOCK_REORDER_LEVEL ) {
				// WebMakers.com Added: add to low stock email
				$this->email_low_stock .=  'ID# ' . $this->products[$key][$i]['id'] . "\t\t" . $this->products[$key][$i]['model'] . "\t\t" . $this->products[$key][$i]['name'] . "\t\t" . ' Qty Left: ' . $stock_left . "\n";
			  }
			}
		  }

		  // Update products_ordered (for bestsellers list)
		  mysqli_query($zendb,"update " . TABLE_PRODUCTS . " set products_ordered = products_ordered + " . sprintf('%f', $this->products[$key][$i]['qty']) . " where products_id = '" . $this->products[$key][$i]['id'] . "'");

		  //$this->notify('NOTIFY_ORDER_PROCESSING_STOCK_DECREMENT_END');

		  $products_query = "select warehouse_id from " . TABLE_PRODUCTS_DETAILS . "
									  where products_id = '" . $this->products[$key][$i]['id'] . "'"; 
			$pro = mysqli_query($zendb,$products_query);
			if (mysqli_num_rows($pro) > 0) {
			   $pro = mysqli_fetch_array($pro);
			   $warehouse_ids = $pro['warehouse_id'];
			}else{
			  $warehouse_ids = 0;
			}   
/* get and calculate discount products particularly */
			/* Get Product discount code */
			$pro_normal_price = zen_get_products_base_price($this->products[$key][$i]['id']);
			$pro_special_price = zen_get_products_special_price($this->products[$key][$i]['id'], true);
			$pro_sale_price = zen_get_products_special_price($this->products[$key][$i]['id'], false);  
			$productDetailQry = "SELECT discount_code
					  from " . TABLE_PRODUCTS_DETAILS . "
					  where products_id ='" . $this->products[$key][$i]['id'] . "'";
			$productDetail = mysqli_query($zendb,$productDetailQry);
			$productDetail = mysqli_fetch_array($productDetail);
			$discount_code = $productDetail['discount_code'];
			if($pro_special_price !="")
			{
			  $discount = 0;
			}
			elseif($pro_sale_price != "")
			{
			  $discount = 0;
			}
			else
			{
			  $discount = 0;
			  if($discount_code != 0){
				$totalAmt   = $this->products[$key][$i]['price']*$this->products[$key][$i]['qty'];
				$discount   = $this->calculate_discountIDs($discount_code,$totalAmt,$this->products[$key][$i]['qty'],$totalAmt); 
				if($discount != "No quantity discount"){
				  $price      = $this->products[$key][$i]['price']-$discount;
				  $finalPrice = $this->products[$key][$i]['final_price']-$discount;
				}else{
				 if($this->products[$key][$i]['qty'] > 1){
					$totalAmt   = $this->products[$key][$i]['price']*$this->products[$key][$i]['qty'];
					$discount     = round((($totalAmt*10)/10)*(20/100), 2);
				  }
				}
			  }
			} 
			$discount     = round($discount/$this->products[$key][$i]['qty'],2);      
			$dt = $this->productPrice($this->products[$key][$i]['price'],$this->products[$key][$i]['id'],$this->products[$key][$i]['qty']);
			$price        = number_format((float)$dt['product_price'], 2, '.', '');   
			$finalPrice   = number_format((float)$dt['product_price'], 2, '.', '');
		    $sql_data_array = "insert into ".TABLE_ORDERS_PRODUCTS." set orders_id = ".$zf_insert_id.",products_id = '".$this->products[$key][$i]['id']."',
								  warehouse_id =  ".$warehouse_ids.",
								  products_model = '".$this->products[$key][$i]['model']."',
								  products_name = '".mysqli_real_escape_string($zendb,$this->products[$key][$i]['name'])."',
								  products_price = '".$price."',
								  final_price = '".$finalPrice."',
								  onetime_charges = '".$this->products[$key][$i]['onetime_charges']."',
								  products_tax = '".$this->products[$key][$i]['tax']."',
								  products_quantity = '".$this->products[$key][$i]['qty']."',
								  products_priced_by_attribute = '".$this->products[$key][$i]['products_priced_by_attribute']."',
								  product_is_free = '".$this->products[$key][$i]['product_is_free']."',
								  products_discount_type = '".$this->products[$key][$i]['products_discount_type']."',
								  products_discount_type_from = '".$this->products[$key][$i]['products_discount_type_from']."',
								  products_prid = '".$this->products[$key][$i]['id']."'";
		  mysqli_query($zendb, $sql_data_array);
		  $order_products_id = mysqli_insert_id($zendb);

		  //------ bof: insert customer-chosen options to order--------
		  $attributes_exist = '0';
		  $this->products_ordered_attributes = '';
		  $this->total_weight = '';
		  $total_products_price = '';
		  if (isset($this->products[$key][$i]['attributes'])) {
			$attributes_exist = '1';
			for ($j=0, $n2=sizeof($this->products[$key][$i]['attributes']); $j<$n2; $j++) {
			  if (DOWNLOAD_ENABLED == 'true') {
				$attributes_query = "select popt.products_options_name, poval.products_options_values_name,
									 pa.options_values_price, pa.price_prefix,
									 pa.product_attribute_is_free, pa.products_attributes_weight, pa.products_attributes_weight_prefix,
									 pa.attributes_discounted, pa.attributes_price_base_included, pa.attributes_price_onetime,
									 pa.attributes_price_factor, pa.attributes_price_factor_offset,
									 pa.attributes_price_factor_onetime, pa.attributes_price_factor_onetime_offset,
									 pa.attributes_qty_prices, pa.attributes_qty_prices_onetime,
									 pa.attributes_price_words, pa.attributes_price_words_free,
									 pa.attributes_price_letters, pa.attributes_price_letters_free,
									 pad.products_attributes_maxdays, pad.products_attributes_maxcount, pad.products_attributes_filename
									 from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_OPTIONS_VALUES . " poval, " .
				TABLE_PRODUCTS_ATTRIBUTES . " pa
									  left join " . TABLE_PRODUCTS_ATTRIBUTES_DOWNLOAD . " pad
									  on pa.products_attributes_id=pad.products_attributes_id
									 where pa.products_id = '" . zen_db_input($this->products[$key][$i]['id']) . "'
									  and pa.options_id = '" . $this->products[$key][$i]['attributes'][$j]['option_id'] . "'
									  and pa.options_id = popt.products_options_id
									  and pa.options_values_id = '" . $this->products[$key][$i]['attributes'][$j]['value_id'] . "'
									  and pa.options_values_id = poval.products_options_values_id
									  and popt.language_id = '" . $_SESSION['languages_id'] . "'
									  and poval.language_id = '" . $_SESSION['languages_id'] . "'";

				$attributes_values = mysqli_query($zendb,$attributes_query);
			  } else {
				$attributes_values = mysqli_query($zendb,"select popt.products_options_name, poval.products_options_values_name,
									 pa.options_values_price, pa.price_prefix,
									 pa.product_attribute_is_free, pa.products_attributes_weight, pa.products_attributes_weight_prefix,
									 pa.attributes_discounted, pa.attributes_price_base_included, pa.attributes_price_onetime,
									 pa.attributes_price_factor, pa.attributes_price_factor_offset,
									 pa.attributes_price_factor_onetime, pa.attributes_price_factor_onetime_offset,
									 pa.attributes_qty_prices, pa.attributes_qty_prices_onetime,
									 pa.attributes_price_words, pa.attributes_price_words_free,
									 pa.attributes_price_letters, pa.attributes_price_letters_free
									 from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_OPTIONS_VALUES . " poval, " . TABLE_PRODUCTS_ATTRIBUTES . " pa
									 where pa.products_id = '" . $this->products[$key][$i]['id'] . "' and pa.options_id = '" . (int)$this->products[$key][$i]['attributes'][$j]['option_id'] . "' and pa.options_id = popt.products_options_id and pa.options_values_id = '" . (int)$this->products[$key][$i]['attributes'][$j]['value_id'] . "' and pa.options_values_id = poval.products_options_values_id and popt.language_id = '" . $_SESSION['languages_id'] . "' and poval.language_id = '" . $_SESSION['languages_id'] . "'");
			  }
			  $attributes_values = mysqli_fetch_array($attributes_values);
			  //clr 030714 update insert query.  changing to use values form $order->products for products_options_values.
			  $sql_data_array = "insert into ".TABLE_ORDERS_PRODUCTS_ATTRIBUTES." orders_id = '".$zf_insert_id."',
									  orders_products_id = '".$order_products_id."',
									  products_options = '".$attributes_values['products_options_name']."',
									  products_options_values = '".$this->products[$key][$i]['attributes'][$j]['value']."',
									  options_values_price = '".$attributes_values['options_values_price']."',
									  price_prefix = '".$attributes_values['price_prefix']."',
									  product_attribute_is_free = '".$attributes_values['product_attribute_is_free']."',
									  products_attributes_weight = '".$attributes_values['products_attributes_weight']."',
									  products_attributes_weight_prefix = '".$attributes_values['products_attributes_weight_prefix']."',
									  attributes_discounted = '".$attributes_values['attributes_discounted']."',
									  attributes_price_base_included = '".$attributes_values['attributes_price_base_included']."',
									  attributes_price_onetime = '".$attributes_values['attributes_price_onetime']."',
									  attributes_price_factor = '".$attributes_values['attributes_price_factor']."',
									  attributes_price_factor_offset = '".$attributes_values['attributes_price_factor_offset']."',
									  attributes_price_factor_onetime = '".$attributes_values['attributes_price_factor_onetime']."',
									attributes_price_factor_onetime_offset = '".$attributes_values['attributes_price_factor_onetime_offset']."',
									  attributes_qty_prices = '".$attributes_values['attributes_qty_prices']."',
									  attributes_qty_prices_onetime = '".$attributes_values['attributes_qty_prices_onetime']."',
									  attributes_price_words = '".$attributes_values['attributes_price_words']."',
									  attributes_price_words_free = '".$attributes_values['attributes_price_words_free']."',
									  attributes_price_letters = '".$attributes_values['attributes_price_letters']."',
									  attributes_price_letters_free = '".$attributes_values['attributes_price_letters_free']."',
									  products_options_id = '".(int)$this->products[$key][$i]['attributes'][$j]['option_id']."',
									  products_options_values_id ='".(int)$this->products[$key][$i]['attributes'][$j]['value_id']."',
									  products_prid = '".$this->products[$key][$i]['id']."'";


			  mysqli_query($zendb,$sql_data_array);

			 /* $this->notify('NOTIFY_ORDER_DURING_CREATE_ADDED_ATTRIBUTE_LINE_ITEM', $sql_data_array);*/

			  if ((DOWNLOAD_ENABLED == 'true') && isset($attributes_values['products_attributes_filename']) && !empty($attributes_values['products_attributes_filename'])) {
				$sql_data_array = "insert into ".TABLE_ORDERS_PRODUCTS_DOWNLOAD." set orders_id = '".$zf_insert_id."',
										orders_products_id = '".$order_products_id."',
										orders_products_filename = '".$attributes_values->fields['products_attributes_filename']."',
										download_maxdays = '".$attributes_values->fields['products_attributes_maxdays']."',
										download_count = '".$attributes_values->fields['products_attributes_maxcount']."',
										products_prid = '".$this->products[$key][$i]['id']."'"
										;

				zen_db_perform($zendb, $sql_data_array);

				$this->notify('NOTIFY_ORDER_DURING_CREATE_ADDED_ATTRIBUTE_DOWNLOAD_LINE_ITEM', $sql_data_array);
			  }
			  $this->products_ordered_attributes .= "\n\t" . $attributes_values->fields['products_options_name'] . ' ' . zen_decode_specialchars($this->products[$key][$i]['attributes'][$j]['value']);
			}
		  }
		  //------eof: insert customer-chosen options ----
		//$this->notify('NOTIFY_ORDER_PROCESSING_ATTRIBUTES_EXIST', $attributes_exist);

		//$this->notify('NOTIFY_ORDER_DURING_CREATE_ADD_PRODUCTS', $custom_insertable_text);

	/* START: ADD MY CUSTOM DETAILS
	 * 1. calculate/prepare custom information to be added to this product entry in order-confirmation, perhaps as a function call to custom code to build a serial number etc:
	 *   Possible parameters to pass to custom functions at this point:
	 *     Product ID ordered (for this line item): $this->products[$i]['id']
	 *     Quantity ordered (of this line-item): $this->products[$i]['qty']
	 *     Order number: $zf_insert_id
	 *     Attribute Option Name ID: (int)$this->products[$i]['attributes'][$j]['option_id']
	 *     Attribute Option Value ID: (int)$this->products[$i]['attributes'][$j]['value_id']
	 *     Attribute Filename: $attributes_values->fields['products_attributes_filename']
	 *
	 * 2. Add that data to the $this->products_ordered_attributes variable, using this sort of format:
	 *      $this->products_ordered_attributes .=  {INSERT CUSTOM INFORMATION HERE};
	 */

		$this->products_ordered_attributes .= $custom_insertable_text;

	/* END: ADD MY CUSTOM DETAILS */

		  // update totals counters
		  $this->total_weight += ($this->products[$key][$i]['qty'] * $this->products[$key][$i]['weight']);
		  $this->total_tax += zen_calculate_tax($this->products[$key][$i]['price'] * $this->products[$key][$i]['qty'], $this->products[$key][$i]['tax']);
		  $this->total_cost += $total_products_price;

		  //$this->notify('NOTIFY_ORDER_PROCESSING_ONE_TIME_CHARGES_BEGIN');
		  /*Code to show products total identical*/
		  $this->products[$key][$i]['final_price']= round($this->products[$key][$i]['final_price'],2);
		  /*End of the code*/
		  // build output for email notification
		  $this->products_ordered .=  $this->products[$key][$i]['qty'] . ' x ' . $this->products[$key][$i]['name'] . ($this->products[$key][$i]['model'] != '' ? ' (' . $this->products[$key][$i]['model'] . ') ' : '') . ' = ' .
		  $this->products[$key][$i]['final_price']*$this->products[$key][$i]['qty'] +$this->products[$key][$i]['tax'].
		  ($this->products[$key][$i]['onetime_charges'] !=0 ? "\n" . TEXT_ONETIME_CHARGES_EMAIL . $this->products[$key][$i]['onetime_charges']+$this->products[$key][$i]['tax'] : '') .
		  $this->products_ordered_attributes . "\n";
		  $this->products_ordered_html .=
		  '<tr>' . "\n" .
		  '<td class="product-details" align="right" valign="top" width="30">' . $this->products[$key][$i]['qty'] . '&nbsp;x</td>' . "\n" .
		  '<td class="product-details" valign="top">' . nl2br($this->products[$key][$i]['name']) . ($this->products[$key][$i]['model'] != '' ? ' (' . nl2br($this->products[$key][$i]['model']) . ') ' : '') . "\n" .
		  '<nobr>' .
		  '<small><em> '. nl2br($this->products_ordered_attributes) .'</em></small>' .
		  '</nobr>' . 
		  '</td>' . "\n" . 
		  '<td class="product-details-num" valign="top" align="right">' .
		  $this->products[$key][$i]['final_price']*$this->products[$key][$i]['qty']+$this->products[$key][$i]['tax'].
		  ($this->products[$key][$i]['onetime_charges'] !=0 ?
		  '</td></tr>' . "\n" . '<tr><td class="product-details">' . nl2br(TEXT_ONETIME_CHARGES_EMAIL) . '</td>' . "\n" .
		  '<td>' . $currencies->display_price($this->products[$key][$i]['onetime_charges'], $this->products[$key][$i]['tax'], 1) : '') .
		  '</td></tr>' . "\n";
    }
	$this->products_ordered_htmls = [];
    foreach ($this->products as $key => $value) {
      foreach ($value as $kkey => $vvalue) {
			/*Code to show products total identical*/
			if($vvalue['id'] != ""){
				$dt = $this->productPrice($vvalue['price'],$vvalue['id'],$vvalue['qty']);
				/*End of the code*/
			   $this->products_ordered_htmls[$key][] =
				'<tr>' . "\n" .
				'<td class="product-details" align="right" valign="top" width="30">' . $vvalue['qty'] . '&nbsp;x</td>' . "\n" .
				'<td class="product-details" valign="top">' . nl2br($vvalue['name']) . ($vvalue['model'] != '' ? ' (' . nl2br($vvalue['model']) . ') ' : '') . "\n" .
				'<nobr>' .
				'<small><em> '. nl2br($this->products_ordered_attributes) .'</em></small>' .
				'</nobr>' . 
				'</td>' . "\n" . 
				'<td class="product-details-num" valign="top" align="right">$' .
				number_format((float)$dt['product_price']*$vvalue['qty'], 2, '.', '') .
				($vvalue['onetime_charges'] !=0 ?
				'</td></tr>' . "\n" . '<tr><td class="product-details">' . nl2br(TEXT_ONETIME_CHARGES_EMAIL) . '</td>' . "\n" .
				'<td>' . $currencies->display_price($vvalue['onetime_charges'], $vvalue['tax'], 1) : '') .
				'</td></tr>' . "\n";
			}
      }
	  //echo "<pre>";print_r($this->products_ordered_htmls);
    }
	//echo "<pre>";print_r($this->products_ordered_htmls);

    //$order_total_modules->apply_credit();//ICW ADDED FOR CREDIT CLASS SYSTEM
    //$this->notify('NOTIFY_ORDER_AFTER_ORDER_CREATE_ADD_PRODUCTS');
  }
  /* function create_add_products($zf_insert_ids) {
    global $zendb, $currencies, $order_total_modules, $order_totals;
	foreach($zf_insert_ids as $kk => $zf_insert_id){
		for ($i=0, $n=sizeof($this->products[$kk]); $i<$n; $i++) {
			 $products_id 					= $this->products[$kk][$i]['id'];
			 $warehouse_id 					= $this->products[$kk][$i]['warehouse_id'];
			 $products_model 				= $this->products[$kk][$i]['model'];
			 $products_name 				= $this->products[$kk][$i]['name'];
			 $products_price 				= $this->products[$kk][$i]['price'];
			 $final_price 					= $this->products[$kk][$i]['final_price'];
			 $onetime_charges 				= $this->products[$kk][$i]['onetime_charges'];
			 $products_tax 					= $this->products[$kk][$i]['tax'];
			 $products_quantity 			= $this->products[$kk][$i]['qty'];
			 $products_priced_by_attribute  = $this->products[$kk][$i]['products_priced_by_attribute'];
			 $product_is_free 				= $this->products[$kk][$i]['product_is_free'];
			 $products_discount_type 		= $this->products[$kk][$i]['products_discount_type'];
			 $products_discount_type_from 	= $this->products[$kk][$i]['products_discount_type_from'];
			 $products_prid 				= $this->products[$kk][$i]['id'];
			
			 $sql_data_array = "insert into ".TABLE_ORDERS_PRODUCTS." set 
									  orders_id 					= '".$zf_insert_id."',
									  products_id 					= '".$products_id."',
									  warehouse_id 					= '".$warehouse_id."',
									  products_model 				= '".$products_model."',
									  products_name 				= '".$products_name."',
									  products_price 				= '".$products_price."',
									  final_price 					= '".$final_price."',
									  onetime_charges 				= '".$onetime_charges."',
									  products_tax 					= '".$products_tax."',
									  products_quantity 			= '".$products_quantity."',
									  products_priced_by_attribute 	= '".$products_priced_by_attribute."',
									  product_is_free 				= '".$product_is_free."',
									  products_discount_type 		= '".$products_discount_type."',
									  products_discount_type_from 	= '".$products_discount_type_from."',
									  products_prid 				= '".$products_prid."'";
				if (mysqli_query($zendb,$sql_data_array)) 
				{ 
					$res = array('status' => '1');
				} 
				else
				{ 
					$res = array('status' => '0',"message" => "ERROR: Could not able to execute $sql. "
						.mysqli_error($link));
				} 
		  }
	}
  }*/
  
  
  /*
   * 
   * Rendor html
   *
   */
   
   function getOrder($orderIds){
	   global $zendb;
	   $html = '';
	   $r = '0';
	   foreach($orderIds as $key => $order_id){
		   $orderQry 			= "select * from orders where orders_id =".$order_id;
		   $orderRes  			= mysqli_query($zendb, $orderQry);
		   if($orderRes){
				$ordeRow				= mysqli_fetch_array($orderRes);
				/*
				 * 
				 * Order Products Query
				 * 
				 * 
				 * */
				$orderproductQry 			= "select * from ".TABLE_ORDERS_PRODUCTS." where orders_id =".$order_id;
				$orderproductRes  			= mysqli_query($zendb, $orderproductQry);
				$productsHtml 	= '';
				$orderDate 		= date('m/d/Y',strtotime($ordeRow['date_purchased']));
				$orderDate2 	= date('m/d/Y',strtotime($ordeRow['date_purchased']));
				$orderTotal 	= $ordeRow['order_total'];
				$shippingCost 	= $_SESSION['shipping']['cost'];
				$subtotal 		= $this->info['subtotal'][$key];
				
				/* 
				 * 
				 * Delivery address
				 * 
				 *  */
				$delivery_name = $ordeRow['delivery_name'];
				$delivery_company = $ordeRow['delivery_company'];
				$delivery_street_address = $ordeRow['delivery_street_address'];
				$delivery_suburb = $ordeRow['delivery_suburb'];
				$delivery_city = $ordeRow['delivery_city'];
				$delivery_state = $ordeRow['delivery_state'];
				$delivery_postcode = $ordeRow['delivery_postcode'];
				$delivery_country = $ordeRow['delivery_country'];
				
				
				/* 
				 * 
				 * Billing address 
				 * 
				 * */
				$billing_name = $ordeRow['billing_name'];
				$billing_company = $ordeRow['billing_company'];
				$billing_street_address = $ordeRow['billing_street_address'];
				$billing_suburb = $ordeRow['billing_suburb'];
				$billing_city = $ordeRow['billing_city'];
				$billing_postcode = $ordeRow['billing_postcode'];
				$billing_state = $ordeRow['billing_state'];
				$billing_country = $ordeRow['billing_country'];
				
				/* 
				 * 
				 * Shipping
				 * 
				 *  */
				$shipping_method = $ordeRow['shipping_method'];
				
				/* 
				 * 
				 * Payment 
				 * 
				 * */
				$payment_method = $ordeRow['payment_method'];
				
				/*
				 * 
				 * Order Status history
				 *
				 */
				 
				$orderstatusQry 			= "select a.comments as comments,b.orders_status_name as status_name from orders_status_history as a LEFT JOIN orders_status as b on a.orders_status_id = b.orders_status_id where a.orders_id =".$order_id;
				$orderstatusRes  			= mysqli_query($zendb, $orderstatusQry);
				$orderstatusRow = mysqli_fetch_array($orderstatusRes);
			   
				$orderStatus    = $orderstatusRow['status_name'];
				$orderComments    = $orderstatusRow['comments'];
				while($row = mysqli_fetch_array($orderproductRes)){
					$pModel = $row['products_model'];
					$products_quantity = $row['products_quantity'];
					$products_name = $row['products_name'];
					$products_price = $row['products_price'];
					$pModel = $row['products_model'];
					$productsHtml .= '<tr>
						<td>'.$pModel.'</td>
						<td class="accountQuantityDisplay">'.$products_quantity.'&nbsp;ea.</td>
						<td class="accountProductDisplay">'.$products_name.'</td>
						<td class="accountTotalDisplay">$'.number_format((float)$products_price*$products_quantity, 2, '.', '').'</td>
					  </tr>';
				}
				
				$orderTotalQry 			= "select * from orders_total where orders_id =".$order_id;
				$orderTotalRes  			= mysqli_query($zendb, $orderTotalQry);
				$rdCls =  '';
                if($r > 0){
					$rdCls = 'mt-4';
				}
				$html .= '<div class="wrapper '.$rdCls.'">
		  <div class="customer-wrap">
			<div class="container">
			  <div class="centerColumn border p-4">
				<div class="d-between top-head">
				  <h4 class="mb-0">Order Information&nbsp;-&nbsp;Order #'.$order_id.'</h4>
				  <h4 class="mb-0"> Order Date: '.$orderDate.'</h4>
				</div>
				<div class="table-responsive mb-3">
				  <table class="table table-sm mb-0 order-table table-middle">
					<thead class="thead-dark">
					  <tr>
						<th>Part No</th>
						<th>Qty.</th>
						<th>Products</th>
						<th>Total</th>
					  </tr>
					</thead>
					<tbody>
					 '.$productsHtml.'
					</tbody>
				  </table>
				</div>
				<div class="orderTotals d-flex justify-content-end"><div class="w-100">';
						if($orderTotalRes){				
							 while($orderTotals = mysqli_fetch_array($orderTotalRes)) {
								 $html .='<div class="d-between"><b>'.$orderTotals['title'].'</b>
								 <span>'.$orderTotals['text'].'</span></div>
								';
							 }
						}
				$html .='</div></div>
				<div class="table-responsive mb-4">
				  <table class="table table-sm table-middle">
					<tbody>
					  <tr class="thead-dark">
						<th>Date</th>
						<th>Order Status</th>
						<th>Comments</th>
					  </tr>
					  <tr>
						<td>'.$orderDate2.'</td>
						<td>'.$orderStatus.'</td>
						<td>'.$orderComments.'</td> 
					  </tr>
					</tbody>
				  </table>
				</div>
				
				<h2 class="orderHistoryStatus">Status History &amp; Comments</h2>
				<div class="auto-hight"></div>
				<div class="row">
				  <div class="col-md-6 ">
					<div class="my-account-links">
					  <div class="card-box">
						<h2>Delivery Address</h2>
						<address>';
						if($delivery_company != ""){
							$html .=''.$delivery_company.'<br>';
						}
						if($delivery_name != ""){
							$html .=''.$delivery_name.' <br>';
						}
						if($delivery_street_address != ""){
							$html .=''.$delivery_street_address.' <br>';
						}
						$html .= ''.$delivery_city.', '.$delivery_state.'    '.$delivery_postcode.'<br> '.$delivery_country.'</address>
					  </div>
					  <div class="card-box">                  
						<h2>Shipping Method</h2>
						<div>'.$shipping_method.'</div>
					  </div>
					</div>
				  </div>
				  <div class="col-md-6 my-account-links">
					<div class="card-box">
					  <h2>Billing Address</h2>
					  <address>';
					    if($billing_company != ""){
							$html .=''.$billing_company.'<br>';
						}
						if($billing_name != ""){
							$html .=''.$billing_name.' <br>';
						}
						if($billing_street_address != ""){
							$html .=''.$billing_street_address.' <br>';
						}
					  
						$html .= ''.$billing_city.', '.$billing_state.'    '.$billing_postcode.'
						<br> '.$billing_country.'
					  </address>
					</div>
					<div class="card-box">
					  <h2>Payment Method</h2>
					  <div>'.$payment_method.'</div>
					</div>
				  </div>
				</div>
			  </div>
			</div>
		  </div><!-- Customer wrap closed -->
		</div><!-- wrapper closed -->';
		   }
		   $r++;
	   }
	   return $html;
   }
   
   /*
    * 
    * Clear cart
    * 
    */
    
    function clearCart(){
		global $zendb;
		$customer_id = $_SESSION['customer_id'];
		$store_type = $_SESSION['store_type'];
		mysqli_query($zendb,'delete from customers_basket where customers_id ='.$customer_id.' and store_type = "'.$store_type.'"');
		mysqli_query($zendb,'delete from cart_total where cid ='.$customer_id);
	}
	/*
	* Get Order $this
	*/
	function applyCoupon($coupon_code){
		$coupontotal 		= new ot_coupon;
		$coupontotalData  = $coupontotal->process($this->info['split_subtotal'],$coupon_code);
		$res = ['status' => '0'];
		if(!empty($coupontotalData)){
			$this->info["coupon_amount"] = $coupontotalData;
			$_SESSION["coupon_amount"] = $coupontotalData;
			$_SESSION["coupon_code"] = $coupon_code;
			$taxData = $this->tax_calculation($this->info);
			if(!empty($taxData)){
				$texDa = $taxData;
			}else{
				$texDa = [];
			}
			$html = "";
			$values = "0";
			$TaxValues = "0";
			$cCmount = "0";
			foreach($coupontotalData as $key => $cData){
				$cCmount += $cData[0]["value"];
				if(!empty($texDa)){
					$taxData = $texDa[$key][0]["value"];
				}else{
					$taxData = '0';
				}
				$TaxValues += $taxData;
			}
			$title =  'Discount Coupon : '. strtoupper((!empty($coupon_code) ? $coupon_code:"")) . ' :';
			$cCmount = number_format((float)$cCmount, 2, '.', '');
			$html = '<div class="ot_coupon text-right text-primary mt-2 font-weight-bold"><span class="alltitle">'.$title.'</span> <span class="allvalues sub_ot_coupon">-$'.$cCmount.'</span> <a href="javascript:void(0)" onclick="removeCoupon('.$cCmount.')" style="color:red" id="apply_coupon" class="" data-toggle="modal">X</a>
				<input type="hidden" id="splitCmat" value="'.$cCmount.'" /> 
				</div>';	
			$rmCphtml = '<a href="javascript:void(0)" onclick="removeCoupon('.$cCmount.')" style="color:red" id="apply_coupon" class="" data-toggle="modal">X</a>';
				$wId[] 		  = $key;
				$values 	  = $cCmount;
			
			$taxDatas = number_format((float)$TaxValues, 2, '.', '');
			$TaxValues = $taxDatas;
			$res = array('status' => '1','html' => $html,'warehouses' => $wId,'values' => $values,'taxvalues' => $TaxValues,'rmchtml' => $rmCphtml);
			}
			return $res;
	}
	/* Remove Coupon */
	
	/*
	* Get Order $this
	*/
	function removeCoupon($coupon_amount){
		$this->info["coupon_amount"] = [];
		$_SESSION["coupon_amount"] = [];
		$_SESSION["coupon_code"] 	 = "";
		$taxData = $this->tax_calculation($this->info);
		if(!empty($taxData)){
			$texDa = $taxData;
		}else{
			$texDa = [];
		}
		$wId = [];
		$TaxValues = "";
		if(!empty($texDa)){
			foreach($texDa as $key => $cData){
				$wId[] 		  = $key;
				$taxData = $cData[0]["value"];
				$TaxValues+= $taxData;
			}
		}
		$res = array('warehouses' => $wId,'taxvalues' => $TaxValues);
		return json_encode($res);
	}
	
	/**/
	function calculate_discountCodeID($id){
		global $zendb;
		$productDiscountQry = "SELECT * from ".TABLE_PRODUCTS_DISCOUNTS."     where id ='" . $id . "'";
		$productDiscount      = mysqli_query($zendb,$productDiscountQry);
		if(mysqli_num_rows($productDiscount) > 0){
			while ($row = mysqli_fetch_array($productDiscount)) {
				$data[$row['discount_qty']]['percentage']=$row['discount_pct'];
			}
		}else{
			$data        = [];
		}
		if(!empty($data))
		{
			ksort($data);
			$firsArrElmnt = implode('',current($data)); 
			$firstArrElmntKey = key($data);
			$lastArrElmnt = implode('',end($data)); 
			$lastArrElmntKey = key($data);
			$data['minProductQuantity']=$firstArrElmntKey;
			$data['minProductQuantityPercentage']=$firsArrElmnt;
			$data['maxProductQuantity']=$lastArrElmntKey;
			$data['maxProductQuantityPercentage']=$lastArrElmnt;
		}
		
		return $data;  
	}
   function calculate_discountIDs($id,$value,$qty,$totalAmt){
	  global $zendb;
		$productDiscountQry = "SELECT *
			from products_discounts
			where id ='" . $id . "' and discount_qty = '".$qty."'";
		$productDiscount      = mysqli_query($zendb,$productDiscountQry);
		if(mysqli_num_rows($productDiscount) > 0){
		  $productDiscount = mysqli_fetch_array($productDiscount);
		  $discountPct        = $productDiscount['discount_pct']; 
		  $step               = $productDiscount['round_to_nearest']; 
		  $totalDiscount      = $value*(1-$discountPct/100);
		  $multiplicand       = floor( $totalDiscount / $step );
		  if($step >= 1){
			 // echo $step;
			  $rest               = $totalDiscount % $step;
			  if( $rest > $step/2 ) $multiplicand++; // round up if needed
		  }
		  $roundedvalue       = $step*$multiplicand;
		  $totalDiscount      = $value-$roundedvalue;
		}else{
		  $totalDiscount = 'No quantity discount';
		}
	  return $totalDiscount;  
	}
	
	function productPrice($ppe,$productId,$qty){
		global $zendb;
		   $pro_normal_price = zen_get_products_base_price($productId);
				   $pro_special_price = zen_get_products_special_price($productId, true);
				   $pro_sale_price = zen_get_products_special_price($productId, false);  
					$productDetailQry = "SELECT discount_code
							  from products_details
							  where products_id ='" . $productId . "'";
					$productDetail = mysqli_query($zendb,$productDetailQry);
					$productDetail = mysqli_fetch_array($productDetail);
					$discount_code = $productDetail['discount_code'];
					$discountCodeData = $this->calculate_discountCodeID($discount_code);
					if($pro_special_price !="")
					{
					  $ppt = round($pro_special_price,2)*$qty;
					  $ppe = round($pro_special_price,2);
					}
					elseif($pro_sale_price != "")
					{
					  $ppt = round($pro_sale_price,2)*$qty;
					  $ppe = round($pro_sale_price,2);
					}
					else
					{
					  $ppt = $ppe * $qty;
					  if($discount_code != 0){
						$totalAmt = $ppe*$qty;
						$discount = $this->calculate_discountIDs($discount_code,$ppe,$qty,$totalAmt); 
						if(($qty >= $discountCodeData['minProductQuantity'])&&($qty < $discountCodeData['maxProductQuantity'])){
							$totalAmt     = $ppe*$qty;
							$discount     = round((($totalAmt*$discountCodeData['minProductQuantityPercentage'])/100), 2);
							$qtYdiscount     = round((($ppe*$discountCodeData['minProductQuantityPercentage'])/100), 2);
							//$ppt          =  $totalAmt - $discount;
							$ppe          = $ppe - $qtYdiscount;	
							$ppt          =  $ppe * $qty;		 
						}
						if($qty >= $discountCodeData['maxProductQuantity']){
							$totalAmt     = $ppe*$qty;
							$discount     = round((($totalAmt*$discountCodeData['maxProductQuantityPercentage'])/100), 2);
							$qtYdiscount     = round((($ppe*$discountCodeData['maxProductQuantityPercentage'])/100), 2);
							//$ppt          =  $totalAmt - $discount;
							$ppe          = $ppe - $qtYdiscount;			
							$ppt          =  $ppe * $qty;		
						}
						if($qty < $discountCodeData['minProductQuantity']){
							$totalAmt     = $ppe*$qty;
							$discount     = 0;
							$qtYdiscount     = 0;
							$ppe          = $ppe - $qtYdiscount;			
							$ppt          =  $ppe * $qty;		
						}
					  }
					}    
				   $totalCart     = $ppt;
				   $result = array("product_price" => $ppe,"total_price" => $totalCart);
				/* New code end */
			return $result;	
	}
	
	
	function send_order_email($orderIds) {
		global $currencies, $order_totals,$rootPath;
		require_once($rootPath.'constant/checkout_process.php');
		require_once($rootPath.'constant/email_extras.php');
		require_once($rootPath.'includes/functions/functions_customers.php');
		require_once($rootPath.'includes/functions/functions_email.php');
		if ($this->email_low_stock != '' and SEND_LOWSTOCK_EMAIL=='1') {
		  // send an email
		  $email_low_stock = SEND_EXTRA_LOW_STOCK_EMAIL_TITLE . "\n\n" . $this->email_low_stock;
		  zen_mail('', SEND_EXTRA_LOW_STOCK_EMAILS_TO, EMAIL_TEXT_SUBJECT_LOWSTOCK, $email_low_stock, STORE_OWNER, EMAIL_FROM, array('EMAIL_MESSAGE_HTML' => nl2br($email_low_stock)),'low_stock');
		}

		// lets start with the email confirmation
		// make an array to store the html version
		
		foreach($orderIds as $key => $zf_insert_id){
		$html_msg=array();
		$_SESSION['COWOA'] = "true";
	// COWOA:If COWOA and Send Order Status is True     \\\
	
	$StreName = $_SESSION['store_type'];

		if ($_SESSION['COWOA'] && (COWOA_ORDER_STATUS == 'true'))  {
			$htmlInvoiceURL=EMAIL_TEXT_INVOICE_URL_CLICK;;
			$htmlInvoiceValue=zen_href_link(FILENAME_ORDER_STATUS, 'order_id=' . $zf_insert_id, 'SSL', false);
			$email_order = EMAIL_TEXT_HEADER . EMAIL_TEXT_FROM . $StreName . "\n\n" .
			$this->customer['firstname'] . ' ' . $this->customer['lastname'] . "\n\n" .
			EMAIL_THANKS_FOR_SHOPPING . "\n" . EMAIL_DETAILS_FOLLOW . "\n" .
			EMAIL_SEPARATOR . "\n" .
			EMAIL_TEXT_ORDER_NUMBER . ' ' . $zf_insert_id . "\n" .
			EMAIL_TEXT_DATE_ORDERED . ' ' . strftime(DATE_FORMAT_LONG) . "\n" .
			EMAIL_TEXT_INVOICE_URL . ' ' . zen_href_link(FILENAME_ORDER_STATUS, 'order_id=' . $zf_insert_id, 'SSL', false) . "\n\n";
			$html_msg['EMAIL_TEXT_HEADER']     = EMAIL_TEXT_HEADER;
			$html_msg['EMAIL_TEXT_FROM']       = EMAIL_TEXT_FROM;
			$html_msg['INTRO_STORE_NAME']      = $StreName;
			$html_msg['EMAIL_THANKS_FOR_SHOPPING'] = EMAIL_THANKS_FOR_SHOPPING;
			$html_msg['EMAIL_DETAILS_FOLLOW']  = EMAIL_DETAILS_FOLLOW;
			$html_msg['INTRO_ORDER_NUM_TITLE'] = EMAIL_TEXT_ORDER_NUMBER;
			$html_msg['INTRO_ORDER_NUMBER']    = $zf_insert_id;
			$html_msg['INTRO_DATE_TITLE']      = EMAIL_TEXT_DATE_ORDERED;
			$html_msg['INTRO_DATE_ORDERED']    = strftime(DATE_FORMAT_LONG);
			$html_msg['INTRO_URL_TEXT']        = EMAIL_TEXT_INVOICE_URL_CLICK;
			$html_msg['INTRO_URL_VALUE']       = zen_href_link(FILENAME_ORDER_STATUS, 'order_id=' . $zf_insert_id, 'SSL', false);
		}
		
	// COWOA:If COWOA but Send Order Status is False
		if ($_SESSION['COWOA'] && (COWOA_ORDER_STATUS == 'false')){
		$htmlInvoiceURL='';
		$htmlInvoiceValue='';
		$email_order = EMAIL_TEXT_HEADER . EMAIL_TEXT_FROM . $StreName . "\n\n" .
		$this->customer['firstname'] . ' ' . $this->customer['lastname'] . "\n\n" .
		EMAIL_THANKS_FOR_SHOPPING . "\n" . EMAIL_DETAILS_FOLLOW . "\n" .
		EMAIL_SEPARATOR . "\n" .
		EMAIL_TEXT_ORDER_NUMBER . ' ' . $zf_insert_id . "\n" .
		EMAIL_TEXT_DATE_ORDERED . ' ' . strftime(DATE_FORMAT_LONG) . "\n\n";
		$html_msg['EMAIL_TEXT_HEADER']     = EMAIL_TEXT_HEADER;
		$html_msg['EMAIL_TEXT_FROM']       = EMAIL_TEXT_FROM;
		$html_msg['INTRO_STORE_NAME']      = $StreName;
		$html_msg['EMAIL_THANKS_FOR_SHOPPING'] = EMAIL_THANKS_FOR_SHOPPING;
		$html_msg['EMAIL_DETAILS_FOLLOW']  = EMAIL_DETAILS_FOLLOW;
		$html_msg['INTRO_ORDER_NUM_TITLE'] = EMAIL_TEXT_ORDER_NUMBER;
		$html_msg['INTRO_ORDER_NUMBER']    = $zf_insert_id;
		$html_msg['INTRO_DATE_TITLE']      = EMAIL_TEXT_DATE_ORDERED;
		$html_msg['INTRO_DATE_ORDERED']    = strftime(DATE_FORMAT_LONG);
		$html_msg['INTRO_URL_TEXT']        = '';
		$html_msg['INTRO_URL_VALUE']       = '';
		}
		// NO COWOA, so lets set up the Text and HTML E-mail Information for the Order History Info
	 if (!$_SESSION['COWOA']){  
		  $invoiceInfo=EMAIL_TEXT_INVOICE_URL . ' ' . zen_href_link(FILENAME_ACCOUNT_HISTORY_INFO, 'order_id=' . $zf_insert_id, 'SSL', false) . "\n\n";
		  $htmlInvoiceURL=EMAIL_TEXT_INVOICE_URL_CLICK;;
		  $htmlInvoiceValue=zen_href_link(FILENAME_ACCOUNT_HISTORY_INFO, 'order_id=' . $zf_insert_id, 'SSL', false);
	   
		$email_order = EMAIL_TEXT_HEADER . EMAIL_TEXT_FROM . $StreName . "\n\n" .
		$this->customer['firstname'] . ' ' . $this->customer['lastname'] . "\n\n" .
		EMAIL_THANKS_FOR_SHOPPING . "\n" . EMAIL_DETAILS_FOLLOW . "\n" .
		EMAIL_SEPARATOR . "\n" .
		EMAIL_TEXT_ORDER_NUMBER . ' ' . $zf_insert_id . "\n" .
		EMAIL_TEXT_DATE_ORDERED . ' ' . strftime(DATE_FORMAT_LONG) . "\n" .
		EMAIL_TEXT_INVOICE_URL . ' ' . zen_href_link(FILENAME_ACCOUNT_HISTORY_INFO, 'order_id=' . $zf_insert_id, 'SSL', false) . "\n\n";
		$html_msg['EMAIL_TEXT_HEADER']     = EMAIL_TEXT_HEADER;
		$html_msg['EMAIL_TEXT_FROM']       = EMAIL_TEXT_FROM;
		$html_msg['INTRO_STORE_NAME']      = $StreName;
		$html_msg['EMAIL_THANKS_FOR_SHOPPING'] = EMAIL_THANKS_FOR_SHOPPING;
		$html_msg['EMAIL_DETAILS_FOLLOW']  = EMAIL_DETAILS_FOLLOW;
		$html_msg['INTRO_ORDER_NUM_TITLE'] = EMAIL_TEXT_ORDER_NUMBER;
		$html_msg['INTRO_ORDER_NUMBER']    = $zf_insert_id;
		$html_msg['INTRO_DATE_TITLE']      = EMAIL_TEXT_DATE_ORDERED;
		$html_msg['INTRO_DATE_ORDERED']    = strftime(DATE_FORMAT_LONG);
		$html_msg['INTRO_URL_TEXT']        = EMAIL_TEXT_INVOICE_URL_CLICK;
		$html_msg['INTRO_URL_VALUE']       = zen_href_link(FILENAME_ACCOUNT_HISTORY_INFO, 'order_id=' . $zf_insert_id, 'SSL', false);
	  }
		//comments area
		if ($this->info['comments']) {
		  $email_order .= zen_db_output($this->info['comments']) . "\n\n";
		  $html_msg['ORDER_COMMENTS'] = nl2br(zen_db_output($this->info['comments']));
		} else {
		  $html_msg['ORDER_COMMENTS'] = '';
		}
		if($_SESSION['store_type'] == "Holiday Manufacturing Inc"){
			$html_msg['BRAND_IMAGE'] = 'Holiday';
		}else{
			$html_msg['BRAND_IMAGE'] = $_SESSION['store_type'];
        }

		//products area
		$email_order .= EMAIL_TEXT_PRODUCTS . "\n" .
		EMAIL_SEPARATOR . "\n" .
		$this->products_ordered .
		EMAIL_SEPARATOR . "\n";
		$html_msg['PRODUCTS_TITLE'] = EMAIL_TEXT_PRODUCTS;
		$product_detail = '<table class="product-details" border="0" width="100%" cellspacing="0" cellpadding="2">'; 
		  foreach ($this->products_ordered_htmls[$key] as  $allvalue) {
			  $product_detail .= $allvalue;
		  }
		  $product_detail .= '</table>';
		  $html_msg['PRODUCTS_DETAIL'] =$product_detail;

		//order totals area
		$html_ot = '<tr><td class="order-totals-text" align="right" width="100%">' . '&nbsp;' . '</td> ' . "\n" . '<td class="order-totals-num" align="right" nowrap="nowrap">' . '---------' .'</td> </tr>' . "\n";
		foreach($this->info['ordertotal'][$key] as $order_total){
				$title 	= $order_total['title'];
				$text 	= $order_total['text'];
				$ovalue = $order_total['value'];
				$class 	= $order_total['code'];
		  $email_order .= strip_tags($title) . ' ' . strip_tags($text) . "\n";
		  $html_ot .= '<tr><td class="order-totals-text" align="right" width="100%">' . $title . '</td> ' . "\n" . '<td class="order-totals-num" align="right" nowrap="nowrap">' .($text) .'</td> </tr>' . "\n";
		}
		$html_msg['ORDER_TOTALS'] = '<table border="0" width="100%" cellspacing="0" cellpadding="2"> ' . $html_ot . ' </table>';

		//addresses area: Delivery
		$html_msg['HEADING_ADDRESS_INFORMATION']= HEADING_ADDRESS_INFORMATION;
		$html_msg['ADDRESS_DELIVERY_TITLE']     = EMAIL_TEXT_DELIVERY_ADDRESS;
		$html_msg['ADDRESS_DELIVERY_DETAIL']    = ($this->content_type != 'virtual') ? zen_address_label($_SESSION['customer_id'], $_SESSION['sendto'], true, '', "<br />") : 'n/a';
		$html_msg['SHIPPING_METHOD_TITLE']      = HEADING_SHIPPING_METHOD;
		$html_msg['SHIPPING_METHOD_DETAIL']     = (!empty($this->info['shipping_method'])) ? $this->info['shipping_method'] : 'n/a';
		
		if ($this->info['shippingcomments']) {
		  $email_order .= $this->info['shippingcomments']. "\n\n";
		  $html_msg['SHIPPING_ORDER_COMMENTS'] = nl2br($this->info['shippingcomments']);
		} else {
		  $html_msg['SHIPPING_ORDER_COMMENTS'] = '';
		}
		

		if ($this->content_type != 'virtual') {
		  $email_order .= "\n" . EMAIL_TEXT_DELIVERY_ADDRESS . "\n" .
		  EMAIL_SEPARATOR . "\n" .
		  zen_address_label($_SESSION['customer_id'], $_SESSION['sendto'], 0, '', "\n") . "\n";
		}

		//addresses area: For COWOA - Billing info sent if the Cart has a dollar value otherwise, do not show the billing address
		if ($_SESSION['cart']['total'] != 0) {
		$email_order .= "\n" . EMAIL_TEXT_BILLING_ADDRESS . "\n" .
		EMAIL_SEPARATOR . "\n" .
		zen_address_label($_SESSION['customer_id'], $_SESSION['billto'], 0, '', "\n") . "\n\n";
		$html_msg['ADDRESS_BILLING_TITLE']   = EMAIL_TEXT_BILLING_ADDRESS;
		$html_msg['ADDRESS_BILLING_DETAIL']  = zen_address_label($_SESSION['customer_id'], $_SESSION['billto'], true, '', "<br />");
		} else{
		$html_msg['ADDRESS_BILLING_TITLE']   = '';
		$html_msg['ADDRESS_BILLING_DETAIL']  = ' <br />';    
		}
		//echo "<pre>";print_r($_SESSION);
		if ($_SESSION['payment']){
		  $cc_num_display = (isset($this->info['cc_number']) && $this->info['cc_number'] != '') ? /*substr($this->info['cc_number'], 0, 4) . */ str_repeat('X', (strlen($this->info['cc_number']) - 8)) . substr($this->info['cc_number'], -4) . "\n\n" : '';
		  $email_order .= EMAIL_TEXT_PAYMENT_METHOD . "\n" .
		  EMAIL_SEPARATOR . "\n";
		  $payment_class = $_SESSION['payment'];
		  $email_order .= $GLOBALS[$payment_class]->title . "\n\n";
		  $email_order .= (isset($this->info['cc_type']) && $this->info['cc_type'] != '') ? $this->info['cc_type'] . ' ' . $cc_num_display . "\n\n" : '';
		  $email_order .= '';
		 // $email_order .= ($GLOBALS[$payment_class]->email_footer) ? $GLOBALS[$payment_class]->email_footer . "\n\n" : '';
		} else {
		  $email_order .= EMAIL_TEXT_PAYMENT_METHOD . "\n" .
		  EMAIL_SEPARATOR . "\n";
		  $email_order .= PAYMENT_METHOD_GV . "\n\n";
		}
		$html_msg['PAYMENT_METHOD_TITLE']  = EMAIL_TEXT_PAYMENT_METHOD;
		$html_msg['PAYMENT_METHOD_DETAIL'] = (is_object($GLOBALS[$_SESSION['payment']]) ? $GLOBALS[$payment_class]->title : PAYMENT_METHOD_GV );
		$html_msg['PAYMENT_METHOD_FOOTER'] = (isset($this->info['cc_type']) && $this->info['cc_type'] != '' ? $this->info['cc_type'] . ' ' . $cc_num_display . "\n\n" : '');
		
	
		// include disclaimer
		if (defined('EMAIL_DISCLAIMER') && EMAIL_DISCLAIMER != '') $email_order .= "\n-----\n" . sprintf(EMAIL_DISCLAIMER, STORE_OWNER_EMAIL_ADDRESS) . "\n\n";
		// include copyright
		if (defined('EMAIL_FOOTER_COPYRIGHT')) $email_order .= "\n-----\n" . EMAIL_FOOTER_COPYRIGHT . "\n\n";

		while (strstr($email_order, '&nbsp;')) $email_order = str_replace('&nbsp;', ' ', $email_order);

		$html_msg['EMAIL_FIRST_NAME'] = $this->customer['firstname'];
		$html_msg['EMAIL_LAST_NAME'] = $this->customer['lastname'];
		//  $html_msg['EMAIL_TEXT_HEADER'] = EMAIL_TEXT_HEADER;
		$html_msg['EXTRA_INFO'] = '';
		zen_mail($this->customer['firstname'] . ' ' . $this->customer['lastname'], $this->customer['email_address'], EMAIL_TEXT_SUBJECT . EMAIL_ORDER_NUMBER_SUBJECT . $zf_insert_id, $email_order, $StreName, EMAIL_FROM, $html_msg, 'checkout', $this->attachArray);
	
		// send additional emails
		if (SEND_EXTRA_ORDER_EMAILS_TO != '') {
		  $extra_info=email_collect_extra_info('','', $this->customer['firstname'] . ' ' . $this->customer['lastname'], $this->customer['email_address'], $this->customer['telephone']);
		  $html_msg['EXTRA_INFO'] = $extra_info['HTML'];

		  // include authcode and transaction id in admin-copy of email
		  if (isset($GLOBALS[$_SESSION['payment']]->auth_code) || isset($GLOBALS[$_SESSION['payment']]->transaction_id)) {
			$pmt_details = ($GLOBALS[$_SESSION['payment']]->auth_code != '' ? 'AuthCode: ' . $GLOBALS[$_SESSION['payment']]->auth_code . '  ' : '') . ($GLOBALS[$_SESSION['payment']]->transaction_id != '' ?  'TransID: ' . $GLOBALS[$_SESSION['payment']]->transaction_id : '') . "\n\n";
			$email_order = $pmt_details . $email_order;
			$html_msg['EMAIL_TEXT_HEADER'] = nl2br($pmt_details) . $html_msg['EMAIL_TEXT_HEADER'];
		  }
		  zen_mail('', SEND_EXTRA_ORDER_EMAILS_TO, SEND_EXTRA_NEW_ORDERS_EMAILS_TO_SUBJECT . ' ' . EMAIL_TEXT_SUBJECT . EMAIL_ORDER_NUMBER_SUBJECT . $zf_insert_id,
		  $email_order . $extra_info['TEXT'], $StreName, EMAIL_FROM, $html_msg, 'checkout_extra', $this->attachArray);
		}
	}
		/*$this->notify('NOTIFY_ORDER_AFTER_SEND_ORDER_EMAIL', array($zf_insert_id, $email_order, $extra_info, $html_msg));*/
  }

}

