<?php
ob_start();
/**
 * shipping class
 *
 * @package classes
 * @copyright Copyright 2003-2012 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: Ian Wilson  Wed Jul 24 17:24:08 2013 +0100 Modified in v1.5.2 $
 */

require_once($rootPath.'constant/shipping.php');
require_once($rootPath.'constant/authorizenet_cim.php');
require_once($rootPath.'includes/classes/shopping_cart.php');
require_once($rootPath.'includes/functions/pack_products.php');
require_once($rootPath.'includes/functions/general.php');
require_once($_SERVER['CONTEXT_DOCUMENT_ROOT'].'/customer-order-tool/officeapp/db/db.inc');



class shipping {
  var $modules;
  var $GLOBALS;
 // class constructor
  function shipping($module = '') {
    global $PHP_SELF, $messageStack,$rootPath;
	$this->modules = explode(';', MODULE_SHIPPING_INSTALLED);
	$include_modules = array();
      
		reset($this->modules);
        while (list(, $value) = each($this->modules)) {
          $class = substr($value, 0, strrpos($value, '.'));
          $include_modules[] = array('class' => $class, 'file' => $value);
        }
		for ($i=0, $n=sizeof($include_modules); $i<$n; $i++) {
			include_once($rootPath.'shipping/' . $include_modules[$i]['file']);
			$GLOBALS[$include_modules[$i]['class']] = new $include_modules[$i]['class'];
		}
    }
    
  function calculate_boxes_weight_and_tare() {
    global $zendb;
	global $shipping_weight, $shipping_quoted, $shipping_num_boxes;
	$ttlweight = new shoppingCart;
	$total_weight = $ttlweight->show_weight();
	$shipping_box_query = "SELECT configuration_value  FROM `configuration` WHERE `configuration_key` = 'shipping_box_weight'";
	$shippingbox_result = mysqli_query($zendb, $shipping_box_query);
	$shippingbox_array = mysqli_fetch_array($shippingbox_result);
	$shipping_box_weight = $shippingbox_array['configuration_value'];
	$shipping_padding_query = "SELECT configuration_value  FROM `configuration` WHERE `configuration_key` = 'SHIPPING_BOX_PADDING'";
	$shipping_padding_result = mysqli_query($zendb, $shipping_padding_query);
	$shipping_padding_array = mysqli_fetch_array($shipping_padding_result);
	$shipping_boxpadding = $shipping_padding_array['configuration_value'];
	$shipping_maxweight_query = "SELECT configuration_value  FROM `configuration` WHERE `configuration_key` = 'SHIPPING_MAX_WEIGHT'";
	$shipping_maxweight_result = mysqli_query($zendb, $shipping_maxweight_query);
	$shipping_maxweight_array = mysqli_fetch_array($shipping_maxweight_result);
	$shipping_maxweight = $shipping_maxweight_array['configuration_value'];
	
	if (is_array($this->modules)) {
		$shipping_quoted = '';
		$shipping_num_boxes = 1;
		$shipping_weight = $total_weight;
	
		$za_tare_array = $za_tare_array = explode(":" , $shipping_box_weight);
		$zc_tare_percent= $za_tare_array[0];
		$zc_tare_weight= $za_tare_array[1];
	
		$za_large_array = $za_tare_array = explode(":" , $shipping_boxpadding);
		$zc_large_percent= $za_large_array[0];
		$zc_large_weight= $za_large_array[1];
	
		// SHIPPING_BOX_WEIGHT = tare
		// SHIPPING_BOX_PADDING = Large Box % increase
		// SHIPPING_MAX_WEIGHT = Largest package
	
		switch (true) {
		// large box add padding
		case($shipping_maxweight <= $shipping_weight):
			$shipping_weight = $shipping_weight + ($shipping_weight*($zc_large_percent/100)) + $zc_large_weight;
			break;
		default:
		// add tare weight < large
			$shipping_weight = $shipping_weight + ($shipping_weight*($zc_tare_percent/100)) + $zc_tare_weight;
			break;
		}
		$shipping_weight;
	
		if ($shipping_weight > $shipping_maxweight) { // Split into many boxes
			$zc_boxes = zen_round(($shipping_weight/$shipping_maxweight), 2);
			$shipping_num_boxes = ceil($zc_boxes);
			$shipping_weight = $shipping_weight/$shipping_num_boxes;
		}
	}
	return $shipping_weight;
	
 }
  
	function quote($method = '', $module = '', $calc_boxes_weight_tare = true) {
		$quotes_array = array();
		$shoppingCarts = new shoppingCart;
$product_array = $shoppingCarts->get_products();
$boxesToShip = [];
if(!empty($product_array)){
	foreach ($product_array as $value) {
		$ware = $value['warehouse_id'];
		$ConvertedArray[$ware][] = $value;
	}
	$i = 0; 
	foreach ($ConvertedArray as $key => $value) {
	  $boxesToShips = packProducts($value,1);
	  $boxesToShips = [];
		$newboxesToShips = [];
		if($boxesToShips){
			foreach ($boxesToShips as $kkey => $vvalue) {
				$vvalue['warehouse_id'] = $key;
				$newboxesToShips[$kkey] = $vvalue;
			}
		}
	  $boxesToShips = $newboxesToShips;
	  $boxesToShip[$key] = $boxesToShips;
	  $boxesToShipss[$key] = $boxesToShips;
	  $i++;
	}
}
$_SESSION["boxesToShipss"] = $boxesToShipss;
		$this->calculate_boxes_weight_and_tare();
		
		if (is_array($this->modules)) {
			$include_quotes = array();
		
			reset($this->modules);
			while (list(, $value) = each($this->modules)) {
			$class = substr($value, 0, strrpos($value, '.'));
			$include_quotes[] = $class;
			}
		
			$size = sizeof($include_quotes);
			for ($i=0; $i<$size; $i++) {
				$start = microtime(true); //******
				/*echo $GLOBALS[$include_quotes[$i]]->enabled;*/
				if ($GLOBALS[$include_quotes[$i]]->enabled) {
					$quotes = $GLOBALS[$include_quotes[$i]]->quote($method);
				}
				//$quotes = $GLOBALS[$include_quotes[$i]]->quote($method);
				//$quotes = $class_obj->quote($method);
				if (is_array($quotes)) $quotes_array[] = $quotes;
					$time_elapsed_secs = microtime(true) - $start; //***************
				}
				//die;
				
			return $quotes_array;
		
	}
}

 
 
}
