<?php
/**
 * ot_total order-total module
 *
 * @package orderTotal
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: ot_subtotal.php 6101 2007-04-01 10:30:22Z wilt $
 */
 require($rootPath. 'constant/order_total/ot_subtotal.php');
  class ot_subtotal {
    var $title, $output;

    function ot_subtotal() {
      $this->code = 'ot_subtotal';
      $this->title = MODULE_ORDER_TOTAL_SUBTOTAL_TITLE;
      $this->description = MODULE_ORDER_TOTAL_SUBTOTAL_DESCRIPTION;
      $this->sort_order = MODULE_ORDER_TOTAL_SUBTOTAL_SORT_ORDER;

      $this->output = array();
    }

    function process($ordertotal) {
		global $currencies;
		$splitVals = [];
		foreach($ordertotal as $key => $value){
			foreach($value as $kk => $vv){
				$splitVals[$kk][] = $vv;
			}
		}
		$oTtotals = [];
		foreach($splitVals as $key => $value){
			$splitValsd = [];
			foreach($value as $kk => $vv){
				foreach($vv as $kkd => $vvv){
					$splitValsd[] = $vvv;
				}
			}
			$oTtotals[$key] = $splitValsd;
		}
		foreach($oTtotals as $key => $values){
			$subTotal = "0";
			foreach($values as $value){
				if($value["code"] == "ot_closeouts" || $value["code"] == "ot_other" || $value["code"] == "ot_quantity"){
					$subTotal += $value["value"];
				}else{
					$subTotal -= $value["value"];
				}
			}
			$subTotal = number_format((float)$subTotal, 2, '.', '');
			$this->output[$key][] = array('code' => 'ot_subtotal','title' => 'Subtotal :',
										  'text' => "$".$subTotal,
										  'value' => $subTotal,
									  'order_by' => '4');	
		}
		return $this->output;
    }

    function keys() {
      return array('MODULE_ORDER_TOTAL_SUBTOTAL_STATUS', 'MODULE_ORDER_TOTAL_SUBTOTAL_SORT_ORDER');
    }
  }
?>
