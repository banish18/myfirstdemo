<?php
/**
 * ot_shipping order-total module
 *
 * @package orderTotal
 * @copyright Copyright 2003-2013 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: Ian Wilson  Mon Oct 28 17:54:33 2013 +0000 Modified in v1.5.2 $
 */
 require($rootPath. 'constant/order_total/ot_shipping.php');
  class ot_shipping {
    var $title, $output;

    function ot_shipping() {
      global $order, $currencies,$pdo;
      $this->code = 'ot_shipping';
      $this->title = MODULE_ORDER_TOTAL_SHIPPING_TITLE;
      $this->description = MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION;
      $this->sort_order = MODULE_ORDER_TOTAL_SHIPPING_SORT_ORDER;
    }

    function process($order) {
		global $currencies;
		if(isset($_SESSION['shipping'])){
			$this->shippingTax($order,$_SESSION['shipping']['tax_class'],$_SESSION['shipping']['tax_basis']);
			$par_cost = $_SESSION['shipping']['par_cost'];
			$this->title = $_SESSION['shipping']['title'];
			if($_SESSION['shipping']['id'] == "tan_ship"){
				foreach($order->info['warehouse_id'] as $key => $value){
					 $this->output[$value][] = array('code' => $this->code,'title' => $this->title . ':',
								  'text' => '$0.00',
								  'value' => '0.00',
								  'order_by' => '6');
				}
			}else{
				if(!empty($par_cost)){
					foreach($par_cost as $key => $value){
						$value = number_format((float)$value, 2, '.', '');
						$ship_cost_txt = "$".$value;
						$ship_cost = $value;
						$this->output[$key][] = array('code' => $this->code,'title' => $this->title . ':',
									  'text' => $ship_cost_txt,
									  'value' => $ship_cost,
									  'order_by' => '6');
					}
				}
			}
		}
		return $this->output;
    }
	
	function shippingTax($order,$shipClass,$taxBasis){
		unset($_SESSION['shipping_tax_description']);
      $this->output = array();
      if (MODULE_ORDER_TOTAL_SHIPPING_FREE_SHIPPING == 'true') {
        switch (MODULE_ORDER_TOTAL_SHIPPING_DESTINATION) {
          case 'national':
            if ($order->delivery['country_id'] == STORE_COUNTRY) $pass = true; break;
          case 'international':
            if ($order->delivery['country_id'] != STORE_COUNTRY) $pass = true; break;
          case 'both':
            $pass = true; break;
          default:
            $pass = false; break;
        }

        if ( ($pass == true) && ( ($order->info['total'] - $order->info['shipping_cost']) >= MODULE_ORDER_TOTAL_SHIPPING_FREE_SHIPPING_OVER) ) {
          $order->info['shipping_method'] = $this->title;
          $order->info['total'] -= $order->info['shipping_cost'];
        }
      }
      $module = (isset($_SESSION['shipping']) && isset($_SESSION['shipping']['id'])) ? substr($_SESSION['shipping']['id'], 0, strpos($_SESSION['shipping']['id'], '_')) : '';
      if (is_object(($order)) && !empty($order->info['shipping_method'])) {
        if ($shipClass > 0) {
          if (isset($taxBasis) && $taxBasis !=0) {
			 $shipping_tax_basis = $taxBasis;
          } else {
             $shipping_tax_basis = STORE_SHIPPING_TAX_BASIS;
          }
          if ($shipping_tax_basis == 'Billing') {
            $shipping_tax = zen_get_tax_rate($shipClass, $order->billing['country']['id'], $order->billing['zone_id']);
            $shipping_tax_description = zen_get_tax_description($shipClass, $order->billing['country']['id'], $order->billing['zone_id']);
          } elseif ($shipping_tax_basis == 'Shipping') {
            $shipping_tax = zen_get_tax_rate($shipClass, $order->delivery['country']['id'], $order->delivery['zone_id']);
            $shipping_tax_description = zen_get_tax_description($shipClass, $order->delivery['country']['id'], $order->delivery['zone_id']);
          } else {
            if (STORE_ZONE == $order->billing['zone_id']) {
              $shipping_tax = zen_get_tax_rate($shipClass, $order->billing['country']['id'], $order->billing['zone_id']);
              $shipping_tax_description = zen_get_tax_description($shipClass, $order->billing['country']['id'], $order->billing['zone_id']);
            } elseif (STORE_ZONE == $order->delivery['zone_id']) {
              $shipping_tax = zen_get_tax_rate($shipClass, $order->delivery['country']['id'], $order->delivery['zone_id']);
              $shipping_tax_description = zen_get_tax_description($shipClass, $order->delivery['country']['id'], $order->delivery['zone_id']);
            } else {
              $shipping_tax = 0;
            }
          }
          $shipping_tax_amount = zen_calculate_tax($order->info['shipping_cost'], $shipping_tax);
          $order->info['shipping_tax'] += $shipping_tax_amount;
          $order->info['tax'] += $shipping_tax_amount;
          $order->info['tax_groups']["$shipping_tax_description"] += zen_calculate_tax($order->info['shipping_cost'], $shipping_tax);
          $order->info['total'] += zen_calculate_tax($order->info['shipping_cost'], $shipping_tax);
          $_SESSION['shipping_tax_description'] =  $shipping_tax_description;
          $_SESSION['shipping_tax_amount'] =  $shipping_tax_amount;
          if (DISPLAY_PRICE_WITH_TAX == 'true') $order->info['shipping_cost'] += zen_calculate_tax($order->info['shipping_cost'], $shipping_tax);
        }

        if ($_SESSION['shipping']['id'] == 'free_free') {
          $order->info['shipping_method'] = FREE_SHIPPING_TITLE;
          $order->info['shipping_cost'] = 0;
        }

      }
	}
  }
