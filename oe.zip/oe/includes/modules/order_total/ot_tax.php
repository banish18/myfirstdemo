<?php
/**
 * ot_tax order-total module
 */
 require($rootPath. 'constant/order_total/ot_tax.php');
 require_once($rootPath.'includes/classes/currencies.php');
class ot_tax {
	var $title, $output;
	function ot_tax() {
		$this->code  = 'ot_tax';
		$this->title = MODULE_ORDER_TOTAL_TAX_TITLE;
		$this->description = MODULE_ORDER_TOTAL_TAX_DESCRIPTION;
		$this->sort_order = MODULE_ORDER_TOTAL_TAX_SORT_ORDER;
		$this->output = array();
	}

	function process($orderValues) {
		global $zendb;
		$customer_id = $_SESSION['customer_id'];
		$sql = "select * from customers_details where customers_id='".$customer_id."' ";
		$account_info = mysqli_query( $zendb,$sql); 
		$account_info = mysqli_fetch_array($account_info);
		foreach($orderValues['taxrates'] as $key => $value){
			if(!empty($value) && trim($account_info['customers_resale_tax_id']) == ""){
				/* Subtract Discount value form total */
			if(isset($orderValues['d_total_amt'][$key])){
				$discountValues = $orderValues['d_total_amt'][$key];
			}else{
				$discountValues = "0";
			}
			if(isset($orderValues['gd_total_amt'][$key])){
				$gdiscountValues = $orderValues['gd_total_amt'][$key];
			}else{
				$gdiscountValues = "0";
			}
			if(!empty($orderValues['coupon_amount']) && isset($orderValues['coupon_amount'][$key])){
				$couponAmount = $orderValues['coupon_amount'][$key];
				$cAmount 	  = $couponAmount[0]["value"];
			}else{
				$cAmount = "0";
			}
			/*echo $value["value"].' coupon amt '.$cAmount;
			echo "<br />";*/
			
			
			$odValue = $value["value"]-$discountValues-$gdiscountValues-$cAmount;
			
			
			$taxRate = round(zen_calculate_tax($odValue,$value["tax_rate"]),2);
			$taxRate = number_format((float)$taxRate, 2, '.', '');
			$text 		 = '$'.$taxRate;
			if($value["tax_rate"] == "0"){
				$this->title = "Sales Tax";
			}else{
				$til 		 = array_keys($value["tax_groups"]);
				$this->title = $til[0];
			}
			
			$this->output[$key][] = array(
		                  'code' => $this->code,
						  'title' => $this->title . ':' ,
						  'text' => $text,
						  'value' => $taxRate,
						  'order_by' => '5');
		}
			}
		
		return $this->output;		  
	}
	// Calculates Tax rounding the result
	function zen_calculate_tax($price, $tax) {
		return $price * $tax / 100;
	}
	////
// Return the tax rates for each defined tax for the given class and zone
// @returns array(description => tax_rate)
  
}
?>
