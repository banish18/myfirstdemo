<?php
/**
 * ot_total order-total module
 *
 * @package orderTotal
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: ot_subtotal.php 6101 2007-04-01 10:30:22Z wilt $
 */
 //require($rootPath. 'constant/order_total/ot_total.php');
  class ot_total {
    var $title, $output;

    function ot_total() {
      $this->code = 'ot_total';
      $this->title = MODULE_ORDER_TOTAL_SUBTOTAL_TITLE;
      $this->description = MODULE_ORDER_TOTAL_SUBTOTAL_DESCRIPTION;
      $this->sort_order = MODULE_ORDER_TOTAL_SUBTOTAL_SORT_ORDER;

      $this->output = array();
    }

    function process($ot_sub_total,$taxData) {
		global $currencies;
		foreach($ot_sub_total as $key => $value){
			$tax = '0';
			$Total = $value[0]["value"];
			if(isset($taxData[$key])){
				$tax   = $taxData[$key];
				$Total = $value[0]["value"]+$tax[0]["value"];
			}
			$Total = number_format((float)$Total, 2, '.', '');
			$this->output[$key][] = array('code' => 'ot_total','title' => 'Total :',
									  'text' => "$".$Total,
									  'value' => $Total,
									  'order_by' => '7');
		}
		return $this->output;
    }

    function keys() {
      return array('MODULE_ORDER_TOTAL_SUBTOTAL_STATUS', 'MODULE_ORDER_TOTAL_SUBTOTAL_SORT_ORDER');
    }
  }
?>
