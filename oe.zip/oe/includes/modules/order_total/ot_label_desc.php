<?php
/**
 * ot_total order-total module
 *
 * @package orderTotal
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: ot_subtotal.php 6101 2007-04-01 10:30:22Z wilt $
 */
  class ot_label_desc {
    var $title, $output;

    function ot_subtotal() {
      $this->code = 'ot_label_desc';
      $this->title = MODULE_ORDER_TOTAL_SUBTOTAL_TITLE;
      $this->description = MODULE_ORDER_TOTAL_SUBTOTAL_DESCRIPTION;
      $this->sort_order = MODULE_ORDER_TOTAL_SUBTOTAL_SORT_ORDER;

      $this->output = array();
    }

    function process($warehouseIds,$orderData) {
		global $currencies;
		foreach($warehouseIds as $key => $wid){
			if(!empty($orderData['sales_items_total']) && isset($orderData['sales_items_total'][$wid]) && $orderData['sales_items_total'][$wid] > 0)
			{
			  $orderData['sales_items_total'][$wid] = number_format((float)$orderData['sales_items_total'][$wid], 2, '.', '');
			  $this->output[$wid][] = array('code' => 'ot_closeouts','title' => 'Closeouts :',
									  'text' => "$".$orderData['sales_items_total'][$wid],
									  'value' => $orderData['sales_items_total'][$wid],
									  'order_by' => '1');
			}
			if(!empty($orderData['other_items_total'] && isset($orderData['other_items_total'][$wid])) && $orderData['other_items_total'][$wid] > 0)
			{
			  $orderData['other_items_total'][$wid] = number_format((float)$orderData['other_items_total'][$wid], 2, '.', '');
			  $this->output[$wid][] = array('code' => 'ot_quantity','title' => 'Items Subtotal :',
									  'text' => "$".$orderData['other_items_total'][$wid],
									  'value' => $orderData['other_items_total'][$wid],
									  'order_by' => '1');
			}
			if(!empty($orderData['quantity_discount_items'] && isset($orderData['quantity_discount_items'][$wid])) && $orderData['quantity_discount_items'][$wid] > 0)
			{
			  $orderData['quantity_discount_items'][$wid] = number_format((float)$orderData['quantity_discount_items'][$wid], 2, '.', '');
			  $this->output[$wid][] = array('code' => 'ot_quantity','title' => 'Items Subtotal :',
									  'text' => "$".$orderData['quantity_discount_items'][$wid],
									  'value' => $orderData['quantity_discount_items'][$wid],
									  'order_by' => '1');
			}
		}
		return $this->output;
    }

    function keys() {
      return array('MODULE_ORDER_TOTAL_SUBTOTAL_STATUS', 'MODULE_ORDER_TOTAL_SUBTOTAL_SORT_ORDER');
    }
  }
?>
