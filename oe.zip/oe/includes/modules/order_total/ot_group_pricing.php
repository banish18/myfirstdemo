<?php
/**
 * ot_group_pricing order-total module
 *
 * @package orderTotal
 * @copyright Copyright 2003-2011 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: ot_group_pricing.php 18695 2011-05-04 05:24:19Z drbyte $
 */
 require($rootPath. 'constant/order_total/ot_group_pricing.php');
class ot_group_pricing {
  var $title, $output;

  function ot_group_pricing() {
    $this->code = 'ot_group_pricing';
    $this->title = MODULE_ORDER_TOTAL_GROUP_PRICING_TITLE;
    $this->description = MODULE_ORDER_TOTAL_GROUP_PRICING_DESCRIPTION;
    $this->sort_order = MODULE_ORDER_TOTAL_GROUP_PRICING_SORT_ORDER;
    $this->include_shipping = MODULE_ORDER_TOTAL_GROUP_PRICING_INC_SHIPPING;
    $this->include_tax = MODULE_ORDER_TOTAL_GROUP_PRICING_INC_TAX;
    $this->calculate_tax = MODULE_ORDER_TOTAL_GROUP_PRICING_CALC_TAX;
    $this->tax_class = MODULE_ORDER_TOTAL_GROUP_PRICING_TAX_CLASS;
    $this->credit_class = true;
    $this->output = array();
  }

  function process($orderValues) {
    global $order, $currencies, $db;
    foreach($orderValues["other_items_total"] as $key => $value){
		$this->title = MODULE_ORDER_TOTAL_GROUP_PRICING_TITLE;
		$od_amount = $this->calculate_deductions($value);
		if(!empty($od_amount)){
			$getdisCoutperc = $this->getdisCoutperc();
			if($getdisCoutperc != "0"){
				$this->title = $this->title.'('.(int)$getdisCoutperc.')%';
			}
			$od_amount['total'] = number_format((float)$od_amount['total'], 2, '.', '');
			$this->deduction = $od_amount['total'];
			if ($od_amount['total'] > 0) {
			  $this->output[$key][] = array('code' => $this->code,'title' => $this->title . ':',
			  'text' => '-$' . $od_amount['total'],
			  'value' => $od_amount['total'],
			  'order_by' => '2');
			  $_SESSION['gd_total_amt'][$key] = $od_amount['total'];
			}else{
			  $_SESSION['gd_total_amt'][$key] = "0";
			}
		}
	}
	return $this->output;
  }
  function get_order_total() {
    global  $order;
    $order_total_tax = $order->info['tax'];
    $order_total = $order->info['total'];
    if ($this->include_shipping != 'true') $order_total -= $order->info['shipping_cost'];
    if ($this->include_tax != 'true') $order_total -= $order->info['tax'];
    if (DISPLAY_PRICE_WITH_TAX == 'true' && $this->include_shipping != 'true')
    {
      $order_total += $order->info['shipping_tax'];
    }
    $taxGroups = array();
    foreach ($order->info['tax_groups'] as $key=>$value) {
      if (isset($_SESSION['shipping_tax_description']) && $key == $_SESSION['shipping_tax_description'])
      {
        if ($this->include_shipping != 'true')
        {
          $value -= $order->info['shipping_tax'];
        }
      }
      $taxGroups[$key] = $value;
    }
    $orderTotalFull = $order_total;
    $order_total = array('totalFull'=>$orderTotalFull, 'total'=>$order_total, 'tax'=>$order_total_tax, 'taxGroups'=>$taxGroups);
    return $order_total;
  }
  function calculate_deductions($order_total) {
    global $zendb, $order;
    $od_amount = array();
    if ($order_total == 0) return $od_amount;
    /*$orderTotal = $this->get_order_total();
    $orderTotalTax = $orderTotal['tax'];
    $taxGroups = $orderTotal['taxGroups'];*/
    $group_query = mysqli_query($zendb,"select customers_group_pricing from " . TABLE_CUSTOMERS . " where customers_id = '" . (int)$_SESSION['customer_id'] . "'");
	$group_res = mysqli_fetch_array($group_query);
    if ($group_res['customers_group_pricing'] != '0') {
      $group_discount = mysqli_query($zendb,"select group_name, group_percentage from " . TABLE_GROUP_PRICING . "
                                      where group_id = '" . (int)$group_res['customers_group_pricing'] . "'");
	  $group_discount = mysqli_fetch_array($group_discount);								  
      //$gift_vouchers = $_SESSION['cart']->gv_only();
      $gift_vouchers = 0;
      /************ Start Cutom Code to Add discount only on non sales items****************/
      $discount = ($order_total - $gift_vouchers) * $group_discount['group_percentage'] / 100;
      $od_amount['total'] = round($discount, 2);
      $ratio = $od_amount['total']/$order_total;
      /**
       * when calculating the ratio add some insignificant values to stop divide by zero errors
       */
     /* switch ($this->calculate_tax) {
        case 'None':
          if ($this->include_tax) {
            reset($order->info['tax_groups']);
            foreach ($order->info['tax_groups'] as $key=>$value) {
              $od_amount['tax_groups'][$key] = $order->info['tax_groups'][$key] * $ratio;
            }
          }
        break;
        case 'Standard':
          if ($od_amount['total'] >= $order_total) {
            $ratio = 1;
          }
          $adjustedTax = $orderTotalTax * $ratio;
          if ($order->info['tax'] == 0) return $od_amount;
          $ratioTax = ($orderTotalTax != 0 ) ? $adjustedTax/$orderTotalTax : 0;
          reset($order->info['tax_groups']);
          $tax_deduct = 0;
          foreach ($taxGroups as $key=>$value) {
            $od_amount['tax_groups'][$key] = $value * $ratioTax;
            $tax_deduct += $od_amount['tax_groups'][$key];
          }
          $od_amount['tax'] = $tax_deduct;
        break;
        case 'Credit Note':
          $tax_rate = zen_get_tax_rate($this->tax_class);
          $od_amount['tax'] = zen_calculate_tax($od_amount['total'], $tax_rate);
          $tax_description = zen_get_tax_description($this->tax_class);
          $od_amount['tax_groups'][$tax_description] = $od_amount['tax'];
        break;
      }*/
    }
    return $od_amount;
  }
  function pre_confirmation_check($order_total) {
    global $order;
    $od_amount = $this->calculate_deductions($order_total);
    $order->info['total'] = $order->info['total'] - $od_amount['total'];
    return $od_amount['total'] + (DISPLAY_PRICE_WITH_TAX == 'true' ? 0 : $od_amount['tax']);
  }

  function credit_selection() {
    return $selection;
  }

  function collect_posts() {
  }

  function update_credit_account($i) {
  }

  function apply_credit() {
  }
  /**
   * Enter description here...
   *
   */
  function clear_posts() {
  }
  function check() {
    global $db;
    if (!isset($this->_check)) {
      $check_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_ORDER_TOTAL_GROUP_PRICING_STATUS'");
      $this->_check = $check_query->RecordCount();
    }

    return $this->_check;
  }

  function keys() {
    return array('MODULE_ORDER_TOTAL_GROUP_PRICING_STATUS', 'MODULE_ORDER_TOTAL_GROUP_PRICING_SORT_ORDER', 'MODULE_ORDER_TOTAL_GROUP_PRICING_INC_SHIPPING', 'MODULE_ORDER_TOTAL_GROUP_PRICING_INC_TAX', 'MODULE_ORDER_TOTAL_GROUP_PRICING_CALC_TAX', 'MODULE_ORDER_TOTAL_GROUP_PRICING_TAX_CLASS');
  }

  function getdisCoutperc(){
	  global $zendb;
	$group_query = mysqli_query($zendb,"select customers_group_pricing from " . TABLE_CUSTOMERS . " where customers_id = '" . (int)$_SESSION['customer_id'] . "'");
	$group_res = mysqli_fetch_array($group_query);
    if ($group_res['customers_group_pricing'] != '0') {
      $group_discount = mysqli_query($zendb,"select group_name, group_percentage from " . TABLE_GROUP_PRICING . "
                                      where group_id = '" . (int)$group_res['customers_group_pricing'] . "'");
	  $group_discount = mysqli_fetch_array($group_discount);
	  $disc = 	$group_discount['group_percentage'];
	}else{
		$disc = "0";
	}
	return $disc;
  }
}
