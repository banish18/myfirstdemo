<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2004 Josh Dechant                                      |
// |                                                                      |
// | Portions Copyright (c) 2004 The zen-cart developers                  |
// |                                                                      |
// | http://www.zen-cart.com/index.php                                    |
// |                                                                      |
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
//  $Id: ot_order_discount.php,v 1.000 2004-08-22 dreamscape Exp $
//
 require($rootPath. 'constant/order_total/ot_order_discount.php');
 require_once($rootPath.'includes/classes/currencies.php');
  class ot_order_discount {
    var $title, $output;

    function ot_order_discount() {
      $this->code = 'ot_order_discount';
      $this->title = MODULE_ORDER_DISCOUNT_TITLE;
      $this->description = MODULE_ORDER_DISCOUNT_DESCRIPTION;
      $this->enabled = MODULE_ORDER_DISCOUNT_STATUS;
      $this->sort_order = MODULE_ORDER_DISCOUNT_SORT_ORDER;
      $this->include_shipping = MODULE_ORDER_DISCOUNT_INC_SHIPPING;
      $this->include_tax = MODULE_ORDER_DISCOUNT_INC_TAX;
      $this->calculate_tax = MODULE_ORDER_DISCOUNT_CALC_TAX;
      $this->output = array();
    }
    
    function process($orderValues) {
      global $currencies, $ot_subtotal;
	  
	  /*echo "<pre>";print_r($orderValues);
	  die;*/
	  $AllTot = 0;
      foreach($orderValues["other_items_total"] as $key => $value){
	    $AllTot += $value;
	  }

      /************ Start Cutom Code to Add discount only on non sales items****************/      
	  foreach($orderValues["other_items_total"] as $key => $value){
		  //$ff = "256";
		  $od_amount = $this->calculate_discount($value,$AllTot);  
		  $od_amount = number_format((float)$od_amount, 2, '.', '');          

		  /************ Start Cutom Code to Add discount only on non sales items****************/    

		  if ($od_amount > 0) {
			if (MODULE_ORDER_DISCOUNT_RATE_TYPE == 'percentage') $title_ext = sprintf(MODULE_ORDER_DISCOUNT_PERCENTAGE_TEXT_EXTENSION ,$this->calculate_rate($value,$AllTot));
			$this->output[$key][] = array('code' => 'ot_discount','title' => sprintf(MODULE_ORDER_DISCOUNT_FORMATED_TITLE, $title_ext),
									'text' => "-$".$od_amount,
									'value' => $od_amount,
									  'order_by' => '2');
			$_SESSION['d_total_amt'][$key] = $od_amount;
		  }else{
			  $_SESSION['d_total_amt'][$key] = "0";
		  }
	  }
	  return $this->output;
    }

    function calculate_discount($amount,$AllTot) {
      global $order_discount, $order_total_array;

      $od_amount = 0;
      if ((MODULE_ORDER_DISCOUNT_DISABLE_WITH_COUPON == 'true') && (isset($_SESSION['cc_id']))) return $od_amount;

      global $zendb, $order, $currencies;
      $group_query = mysqli_query($zendb,"select customers_group_pricing from " . TABLE_CUSTOMERS . " where customers_id = '" . $_SESSION['customer_id'] . "'");
	  $group_queryres = mysqli_fetch_array($group_query);
      if ($group_queryres['customers_group_pricing'] != '0') return $od_amount;

      /************ Start Cutom Code to Add discount only on non sales items****************/  
      $order_discount = $this->calculate_rate($amount,$AllTot);
      if ($order_discount > 0) {
        if (MODULE_ORDER_DISCOUNT_RATE_TYPE == 'percentage') {
          $od_amount = round((($amount*10)/10)*($order_discount/100), 2);
        } else {
          $od_amount = round((($order_discount*10)/10), 2);
        }
      }

      return $od_amount;
    }
  
    function calculate_rate($order_amt,$total) {
      $discount_rate = explode("," , MODULE_ORDER_DISCOUNT_RATES);
      $size = sizeof($discount_rate);
	  $order_discount = '0';
      for ($i=0, $n=$size; $i<$n; $i++) {
		$discRate = explode(":" , $discount_rate[$i]);
        if ($total >= $discRate[0]) {
          $order_discount = $discRate[1];
        }
      }
      return $order_discount;
    }

    function calculate_tax_effect($od_amount) {
      global $order;
      if (MODULE_ORDER_DISCOUNT_RATE_TYPE == 'percentage') {
        $tod_amount = 0; 
        reset($order->info['tax_groups']); 
        while (list($key, $value) = each($order->info['tax_groups'])) { 
          $god_amount = 0; 
         // echo $order->info['tax_rate_value'][$key];
          $discount_amt = $od_amount*$order->info['tax_rate_value'][$key]/100;
         // echo $discount_amt;
          $tax_rate = zen_get_tax_rate_from_desc($key); 
          $net = ($tax_rate * $order->info['tax_groups'][$key]);
          if ($net > 0) {
            //echo $order->info['tax_groups'][$key];
            $god_amount = $this->calculate_discount($order->info['tax_groups'][$key]);
           // echo $god_amount;
            $tod_amount += $god_amount+$discount_amt;
            $order->info['tax_groups'][$key] = $order->info['tax_groups'][$key] - $god_amount-$discount_amt; 
          } 
        }
      } else {
        $tod_amount = 0; 
        reset($order->info['tax_groups']); 
        while (list($key, $value) = each($order->info['tax_groups'])) { 
          $god_amount = 0; 
           $discount_amt = $od_amount*$order->info['tax_rate_value'][$key]/100;
          $tax_rate = zen_get_tax_rate_from_desc($key); 
          $net = ($tax_rate * $order->info['tax_groups'][$key]);
          if ($net>0) { 
            $god_amount = ($tax_rate/100)*$od_amount;
            $tod_amount += $god_amount; 
            $order->info['tax_groups'][$key] = $order->info['tax_groups'][$key] - $god_amount-$discount_amt; 
          } 
        }            
      }

      //echo $tod_amount;

      return $tod_amount;          
    }

    function get_order_total() {
      global $order;

      $order_total = $order->info['total'];
      if ($this->include_tax == 'false') $order_total = ($order_total - $order->info['tax']);
      if ($this->include_shipping == 'false') $order_total = ($order_total - $order->info['shipping_cost']);
      return $order_total;
    }   
  
    function check() {
      global $db;
      if (!isset($this->_check)) {
        $check_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_ORDER_DISCOUNT_STATUS'");
        $this->_check = $check_query->RecordCount();
      }

      return $this->_check;
    }

    function keys() {
      return array('MODULE_ORDER_DISCOUNT_STATUS', 'MODULE_ORDER_DISCOUNT_SORT_ORDER', 'MODULE_ORDER_DISCOUNT_DISABLE_WITH_COUPON', 'MODULE_ORDER_DISCOUNT_RATE_TYPE', 'MODULE_ORDER_DISCOUNT_RATES', 'MODULE_ORDER_DISCOUNT_INC_SHIPPING', 'MODULE_ORDER_DISCOUNT_INC_TAX', 'MODULE_ORDER_DISCOUNT_CALC_TAX');
    }

    function install() {
      global $db;

      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('This module is installed', 'MODULE_ORDER_DISCOUNT_STATUS', 'true', 'Do you want to enable the order total discount module?', '6', '1','zen_cfg_select_option(array(\'true\', \'false\'), ', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Sort Order', 'MODULE_ORDER_DISCOUNT_SORT_ORDER', '320', 'Sort order of display.', '6', '2', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Disable If Coupon Used', 'MODULE_ORDER_DISCOUNT_DISABLE_WITH_COUPON', 'true', 'Do you want to disable the order total discount module if a discount coupon is being used by the user?', '6', '3','zen_cfg_select_option(array(\'true\', \'false\'), ', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function ,date_added) values ('Discount Rate Type', 'MODULE_ORDER_DISCOUNT_RATE_TYPE', 'percentage', 'Choose the type of discount rate - percentage or flat rate', '6', '4','zen_cfg_select_option(array(\'percentage\', \'flat rate\'), ', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Discount Rates', 'MODULE_ORDER_DISCOUNT_RATES', '10:5,20:10', 'The discount is based on the total order.  Example: 10:5,20:10.. $10 or more get a 5% or $5 discount; $20 or more receive a 10% or $10 discount; depending on the rate type.', '6', '5', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function ,date_added) values ('Include Shipping', 'MODULE_ORDER_DISCOUNT_INC_SHIPPING', 'false', 'Include Shipping in calculation', '6', '6', 'zen_cfg_select_option(array(\'true\', \'false\'), ', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function ,date_added) values ('Include Tax', 'MODULE_ORDER_DISCOUNT_INC_TAX', 'false', 'Include Tax in calculation.', '6', '7','zen_cfg_select_option(array(\'true\', \'false\'), ', now())");
      $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function ,date_added) values ('Calculate Tax', 'MODULE_ORDER_DISCOUNT_CALC_TAX', 'true', 'Re-calculate Tax on discounted amount.', '6', '8','zen_cfg_select_option(array(\'true\', \'false\'), ', now())");
    }

    function remove() {
      global $db;

      $db->Execute("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }
  }
?>
