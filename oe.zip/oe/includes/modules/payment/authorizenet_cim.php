<?php
/**
 * authorize.net CIM payment method class
 *
 * @package paymentMethod
 * @copyright Copyright 2003-2007 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: authorizenet_cim.php 7620 2007-12-11 19:12:46Z drbyte $
 */
 
/**
 * Authorize.net Payment Module (CIM version)
 * You must have SSL active on your server to be compliant with merchant TOS
 *
 */

/*
SQL Update:
ALTER TABLE customers ADD `customers_customerProfileId` INT NOT NULL DEFAULT '0' AFTER `customers_paypal_ec` ,
ADD `customers_customerPaymentProfileId` INT NOT NULL DEFAULT '0' AFTER `customers_customerProfileId` ,
ADD `customers_customerShippingAddressId` INT NOT NULL DEFAULT '0' AFTER `customers_customerPaymentProfileId` ;

ALTER TABLE orders ADD `reorder` CHAR( 1 ) NOT NULL ;

*/ 

require($rootPath.'includes/functions/html_output.php');

class authorizenet_cim extends base {
  /**
   * $code determines the internal 'code' name used to designate "this" payment module
   *
   * @var string
   */
  var $code;
  
  var $commInfo;
  var $transaction_id;
  /**
   * $title is the displayed name for this payment method
   *
   * @var string
   */
  var $title;
  /**
   * $description is a soft name for this payment method
   *
   * @var string
   */
  var $description;
  /**
   * $enabled determines whether this module shows or not... in catalog.
   *
   * @var boolean
   */
  var $enabled;
  /**
   * $delimiter determines what separates each field of returned data from authorizenet
   *
   * @var string (single char)
   */
  var $delimiter = '|';
  /**
   * $encapChar denotes what character is used to encapsulate the response fields
   *
   * @var string (single char)
   */
  var $encapChar = '*';
  /**
   * log file folder
   *
   * @var string
   */
  var $_logDir = '';
  /**
   * communication vars
   */
  var $authorize = '';
  var $commErrNo = 0;
  var $commError = '';
  /**
   * debug content var
   */
  var $reportable_submit_data = array();

	/* cim variables */

// cim

	var $version = '1.3'; // the code revision number for this class
	var $params = array();
	var $LineItems = array();
	var $success = false;
	var $error = true;
	var $error_messages = array();
	var $response;
	var $xml;
	var $update = false;
	var $resultCode;
	var $cim_code;
	var $text;
	var $refId;
	var $customerProfileId;
	var $customerPaymentProfileId;
	var $customerAddressId;
	var $directResponse;
	var $transactionResponse;
	var $validationDirectResponse;
	var $responseDelimiter = ','; // Direct Response Delimiter. 
        // Make sure this value is the same in your Authorize.net login area.
        // Account->Settings->Transaction Format Settings->Direct Response
	var $approvalCode;
	var $transID;
	var $authCode;
	var $token;
	var $cardNumber;
	var $expirationDate;
	var $cardmonth;

// cim


  /**
   * Constructor
   *
   * @return authorizenet_cim
   */
  function authorizenet_cim() {
    global $order,$rootPath;
   
    $this->code = 'authorizenet_cim';
    $this->enabled = ((MODULE_PAYMENT_AUTHORIZENET_CIM_STATUS == 'True') ? true : false); // Whether the module is installed or not
    if (IS_ADMIN_FLAG === true) {
      // Payment module title in Admin
      $this->title = MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_ADMIN_TITLE;
      if (MODULE_PAYMENT_AUTHORIZENET_CIM_STATUS == 'True' && (MODULE_PAYMENT_AUTHORIZENET_CIM_LOGIN == 'testing' || MODULE_PAYMENT_AUTHORIZENET_CIM_TXNKEY == 'Test')) {
        $this->title .=  '<span class="alert"> (Not Configured)</span>';
      } elseif (MODULE_PAYMENT_AUTHORIZENET_CIM_TESTMODE == 'Test') {
        $this->title .= '<span class="alert"> (in Testing mode)</span>';
      }
      if ($this->enabled && !function_exists('curl_init')) $messageStack->add_session(MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_ERROR_CURL_NOT_FOUND, 'error');
    } else {
      $this->title = MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CATALOG_TITLE; // Payment module title in Catalog
    }
    $this->description = MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_DESCRIPTION; // Descriptive Info about module in Admin
    $this->sort_order = MODULE_PAYMENT_AUTHORIZENET_CIM_SORT_ORDER; // Sort Order of this payment option on the customer payment page
    $this->form_action_url = 'https://192.168.1.200/customer-order-tool/officeapp/oe/order/checkout_process.php'; // Page to go to upon submitting page info
    $this->order_status = (int)DEFAULT_ORDERS_STATUS_ID;
    if ((int)MODULE_PAYMENT_AUTHORIZENET_CIM_ORDER_STATUS_ID > 0) {
      $this->order_status = (int)MODULE_PAYMENT_AUTHORIZENET_CIM_ORDER_STATUS_ID;
    }

    $this->_logDir = DIR_FS_SQL_CACHE;

// cim
		$this->login = trim(MODULE_PAYMENT_AUTHORIZENET_CIM_LOGIN);
		$this->transkey = trim(MODULE_PAYMENT_AUTHORIZENET_CIM_TXNKEY);
		$this->test_mode = (MODULE_PAYMENT_AUTHORIZENET_CIM_TESTMODE == 'Test' ? true : false);
		$subdomain = ($this->test_mode) ? 'apitest' : 'api';
		$this->url = "https://" . $subdomain . ".authorize.net/xml/v1/request.api";
		$this->validationMode = MODULE_PAYMENT_AUTHORIZENET_CIM_VALIDATION; // none, testMode or liveMode
// cim

    if (is_object($order)) $this->update_status();
  }
  /**
   * calculate zone matches and flag settings to determine whether this module should display to customers or not
   *
   */
  function update_status() {
    global $order, $db;
    if ( ($this->enabled == true) && ((int)MODULE_PAYMENT_AUTHORIZENET_CIM_ZONE > 0) ) {
      $check_flag = false;
      $check = $db->Execute("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_AUTHORIZENET_CIM_ZONE . "' and zone_country_id = '" . $order->billing['country']['id'] . "' order by zone_id");
      while (!$check->EOF) {
        if ($check->fields['zone_id'] < 1) {
          $check_flag = true;
          break;
        } elseif ($check->fields['zone_id'] == $order->billing['zone_id']) {
          $check_flag = true;
          break;
        }
        $check->MoveNext();
      }

      if ($check_flag == false) {
        $this->enabled = false;
      }
    }
  }
  /**
   * JS validation which does error-checking of data-entry if this module is selected for use
   * (Number, Owner, and CVV Lengths)
   *
   * @return string
   */
  function javascript_validation() {
    $js = '  if (payment_value == "' . $this->code . '") {' . "\n" .
    '    var cc_owner = document.checkout_payment.authorizenet_cim_cc_owner.value;' . "\n" .
    '    var cc_sc = document.checkout_payment.authorizenet_cim_cc.value;' . "\n" .
    '    var cc_number = document.checkout_payment.authorizenet_cim_cc_number.value;' . "\n";
    if (MODULE_PAYMENT_AUTHORIZENET_CIM_USE_CVV == 'True')  {
      $js .= '    var cc_cvv = document.checkout_payment.authorizenet_cim_cc_cvv.value;' . "\n";
    }
    $js .= '   if(cc_sc == "new"){'."\n".
    '		error_message = error_message+"'.MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_JS_CC_SC.'";'."\n".
    '		error =1;'."\n".
    '		}'."\n";
    if (MODULE_PAYMENT_AUTHORIZENET_CIM_USE_CVV == 'True')  {
      $js .= '    if (cc_cvv == "" || cc_cvv.length < "3" || cc_cvv.length > "4") {' . "\n".
      '      error_message = error_message + "' . MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_JS_CC_CVV . '";' . "\n" .
      '      error = 1;' . "\n" .
      '    }' . "\n" ;
    }
    $js .= '  }' . "\n";

    return $js;
  }
  /**
   * Display Credit Card Information Submission Fields on the Checkout Payment Page
   *
   * @return array
   */
  function selection() {
    global $order,$db;
    global $reorder_var;

    for ($i=1; $i<13; $i++) {
      $expires_month[] = array('id' => sprintf('%02d', $i), 'text' => strftime('%B - (%m)',mktime(0,0,0,$i,1,2000)));
    }

    $today = getdate();
    for ($i=$today['year']; $i < $today['year']+10; $i++) {
      $expires_year[] = array('id' => strftime('%y',mktime(0,0,0,1,1,$i)), 'text' => strftime('%Y',mktime(0,0,0,1,1,$i)));
    }
    $onFocus = ' onfocus="methodSelect(\'pmt-' . $this->code . '\')"';

		for ($j = 0, $k = sizeof($reorder_var); $j < $k; $j++)
	    $reorder_info[] = array('id' => $j, 'text' => $reorder_var[$j]);
    $csql = "select * from " . TABLE_CUSTOMERS . " WHERE customers_id = :custID ";
	$csql = $db->bindVars($csql, ':custID', $_SESSION['customer_id'], 'integer');
	$user = $db->Execute($csql);	
	$this->setParameter('refId', $_SESSION['customer_id']);
	/***********Create customerProfileId if not exsits.*************/
	if($user->fields['customers_customerProfileId']==0)
	{
		  $email_address = $user->fields['customers_email_address'];
		  $description   = 'Monthly Membership No. ' . md5(uniqid(rand(), true));
		  $customer_id   = substr(md5(uniqid(rand(), true)), 16, 16);
		  // Create the profile
		 
		  $this->setParameter('email', $email_address);
		  $this->setParameter('description', $description);
		  $this->setParameter('merchantCustomerId', $customer_id);
		  $this->createCustomerProfileRequest();
		  if ($this->isSuccessful())
		  {
			 $this->setParameter('customerProfileId',$this->customerProfileId); 
		  }				 	 
	}			
	$expirationDate = array('','');
	$_fields = array();
    if($user->fields['customers_customerPaymentProfileId']!=0)
	{
		$customers_customerProfileId = $user->fields['customers_customerProfileId'];
		$this->setParameter('customerProfileId', $customers_customerProfileId);
		$customerPaymentProfileId = $user->fields['customers_customerPaymentProfileId'];
		$this->setParameter('customerPaymentProfileId', $customerPaymentProfileId);
		$this->getCustomerPaymentProfileRequest();		
		$default_card_num = 'XX'.$this->cardNumber;
		$expirationDate = explode('-',$this->expirationDate); 
		$expirationDate[0] = substr($expirationDate[0], -2);
		$default_card = $customerPaymentProfileId.' XX'.$this->cardNumber.' '.$expirationDate[1].' '.$expirationDate[0];
		$this->getCustomerProfileRequest();
		$response = str_replace('xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd"','',substr($this->response,strpos($this->response,"<getCustomerProfileResponse")));
		$response_obj = simplexml_load_string('<?xml version="1.0" encoding="utf-8"?>'.$response) or die("Error: Cannot create object");
		$customer_cards = array();
		$customer_payment_methods = array();
		if(isset($response_obj->profile->paymentProfiles) && count($response_obj->profile->paymentProfiles) > 0){
		foreach($response_obj->profile->paymentProfiles as $_paymentProfile)
		{	
			$customer_payment_methods[] = (string)$_paymentProfile->customerPaymentProfileId;	
		}
	}
		$_cards = array();
		if(count($customer_payment_methods)>0)
		{
				$this->setParameter('customerProfileId', $customers_customerProfileId);
						foreach($customer_payment_methods as $customer_paymentProfileId)
						{
							$this->setParameter('customerPaymentProfileId', $customer_paymentProfileId);					
							$this->getCustomerPaymentProfileRequest(); 		
							$_expirationDate = explode('-',$this->expirationDate); 
							$_expirationDate[0] = substr($_expirationDate[0], -2);
							$_cards[] = array("id"=>$customer_paymentProfileId.' '.'XX'.$this->cardNumber.' '.$_expirationDate[1].' '.$_expirationDate[0],'text'=>'XX'.$this->cardNumber.",Exp ".$_expirationDate[1].'/'.$_expirationDate[0]);
						}						
		}		
		if(count($_cards))
		{
			$_fields[] = array('title' => MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CATALOG_TITLE_SELECT_CARD,
                               'field' => zen_draw_pull_down_menu('authorizenet_cim_cc', $_cards, $default_card, 'id="'.$this->code.'-cc"' . $onFocus).' '.zen_draw_input_field('authorizenet_cim_cc_cvv', '', 'size="4", maxlength="4"' . ' id="'.$this->code.'-cc-cvv"' . $onFocus." placeholder='cvv'").'<div class="req_lab">*</div> '.'<div id="addPayDiv"><button type="button" id="addPaymentButton" data-toggle="modal" data-target="#myModal" class="btn btn-default holiday-bow-button">ADD NEW CREDIT CARD</button></div>',
                               'tag' => $this->code.'-cc');
		}
		
	}
	else
	{
			$_cards = array();
			$_cards[] = array("id"=>'new','text'=>"Please add your credit card");
			$_fields[] = array('title' => MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CATALOG_TITLE_SELECT_CARD,
					   'field' => zen_draw_pull_down_menu('authorizenet_cim_cc', $_cards, 'new','id="'.$this->code.'-cc"' . $onFocus).' '.zen_draw_input_field('authorizenet_cim_cc_cvv', '', 'size="4", maxlength="4"' . ' id="'.$this->code.'-cc-cvv"' . $onFocus." placeholder='cvv'").'<div class="req_lab">*</div> '.'<div id="addPayDiv"><button type="button" id="addPaymentButton" data-toggle="modal" data-target="#myModal" class="btn btn-default holiday-bow-button">ADD NEW CREDIT CARD</button></div>',
					   'tag' => $this->code.'-cc');    
	}
	$_fields[] = array('title' => MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CREDIT_CARD_OWNER,
                       'field' => zen_draw_input_field('authorizenet_cim_cc_owner', $order->billing['firstname'] . ' ' . $order->billing['lastname'], 'id="'.$this->code.'-cc-owner"'. $onFocus),
                       'tag' => $this->code.'-cc-owner');
    $_fields[] =  array('title' => MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CREDIT_CARD_NUMBER,
						'field' => zen_draw_input_field('authorizenet_cim_cc_number', $default_card_num, 'id="'.$this->code.'-cc-number"' . $onFocus),
                        'tag' => $this->code.'-cc-number');
    $_fields[] =  array('title' => MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CREDIT_CARD_EXPIRES,
                        'field' => zen_draw_pull_down_menu('authorizenet_cim_cc_expires_month', $expires_month, $expirationDate[1], 'id="'.$this->code.'-cc-expires-month"' . $onFocus) . '&nbsp;' . zen_draw_pull_down_menu('authorizenet_cim_cc_expires_year', $expires_year, $expirationDate[0], 'id="'.$this->code.'-cc-expires-year"' . $onFocus),
                        'tag' => $this->code.'-cc-expires-month');
    $selection = array('id' => $this->code,
                       'module' => MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CATALOG_TITLE,
                       'fields' => $_fields);
    return $selection;
   
  }
  /**
   * Evaluates the Credit Card Type for acceptance and the validity of the Credit Card Number & Expiration Date
   *
   */
  function pre_confirmation_check() {
    global $messageStack;      
    global $db;
    if(isset($_POST['authorizenet_cim_cc_number']))
    { 
		$csql = "select * from " . TABLE_CUSTOMERS . " WHERE customers_id = :custID ";
		$csql = $db->bindVars($csql, ':custID', $_SESSION['customer_id'], 'integer');
		$user = $db->Execute($csql);
		$this->setParameter('refId', $_SESSION['customer_id']);
		if($user->fields['customers_customerProfileId']==0)
		{
			  $email_address = $user->fields['customers_email_address'];
			  $description   = 'Monthly Membership No. ' . md5(uniqid(rand(), true));
			  $customer_id   = substr(md5(uniqid(rand(), true)), 16, 16);
			  // Create the profile
			 
			  $this->setParameter('email', $email_address);
			  $this->setParameter('description', $description);
			  $this->setParameter('merchantCustomerId', $customer_id);
			  $this->createCustomerProfileRequest();
			  if ($this->isSuccessful())
			  {
				 $this->setParameter('customerProfileId',$this->customerProfileId); 
			  }				 	 
		}
		else
		{
			$this->setParameter('customerProfileId',$user->fields['customers_customerProfileId']); 
		}			
		if($user->fields['customers_customerShippingAddressId']==0)
		{
			$csql = "select * from " . TABLE_ADDRESS_BOOK . " WHERE address_book_id = :adressID ";
			$csql = $db->bindVars($csql, ':adressID', $user->fields['customers_default_address_id'], 'integer');
			$primary_address = $db->Execute($csql);
			if($primary_address->fields['entry_zone_id']){
					$state_result = $db->Execute("select zone_code from ".TABLE_ZONES." where zone_country_id = '".$primary_address->fields['entry_country_id']."' and zone_id ='".$primary_address->fields['entry_zone_id']."' ");				
			}

			// Create the shipping profile  
			$countries_array = zen_get_countries($primary_address->fields['entry_country_id'], true);   
			$this->setParameter('shipTo_firstName', $primary_address->fields['entry_firstname']);    
			$this->setParameter('shipTo_lastName', $primary_address->fields['entry_lastname']);
			$this->setParameter('shipTo_address', $primary_address->fields['entry_street_address']);
			$this->setParameter('shipTo_city', $primary_address->fields['entry_city']);
			$this->setParameter('shipTo_state',  $state_result->fields['zone_code']);
			$this->setParameter('shipTo_zip', $primary_address->fields['entry_postcode']);
			$this->setParameter('shipTo_country', $countries_array['countries_name']);
			$this->setParameter('shipTo_phoneNumber', $user->fields['customers_telephone']);
			$this->createCustomerShippingAddressRequest();   
			if ($this->isSuccessful())
			{					
					$this->setParameter('customerShippingAddressId', $this->customerAddressId);
			}			
		}
		else
		{
			$this->setParameter('customerShippingAddressId', $user->fields['customers_customerShippingAddressId']);
		}
		$new_payment_profile = 1;
		if(isset($_POST['authorizenet_cim_cc']))
		{		
			if($_POST['authorizenet_cim_cc']=="new")
			{
				$new_payment_profile = 1;
			}
			else
			{
				$new_payment_profile = 0;
				$card_details = explode(' ',$_POST['authorizenet_cim_cc']); 
				$this->setParameter('customerPaymentProfileId', $card_details[0]);
			}
		}		
        if($user->fields['customers_customerPaymentProfileId']==0 || $new_payment_profile==1)
		{
			include(DIR_WS_CLASSES . 'cc_validation.php');

			$cc_validation = new cc_validation();
			$result = $cc_validation->validate($_POST['authorizenet_cim_cc_number'], $_POST['authorizenet_cim_cc_expires_month'], $_POST['authorizenet_cim_cc_expires_year'], $_POST['authorizenet_cim_cc_cvv']);
			$error = '';
			switch ($result) {
			  case -1:
			  $error = sprintf(TEXT_CCVAL_ERROR_UNKNOWN_CARD, substr($cc_validation->cc_number, 0, 4));
			  break;
			  case -2:
			  case -3:
			  case -4:
			  $error = TEXT_CCVAL_ERROR_INVALID_DATE;
			  break;
			  case false:
			  $error = TEXT_CCVAL_ERROR_INVALID_NUMBER;
			  break;
			}

			if ( ($result == false) || ($result < 1) ) {
			  $payment_error_return = 'payment_error=' . $this->code . '&authorizenet_cim_cc_owner=' . urlencode($_POST['authorizenet_cim_cc_owner']) . '&authorizenet_cim_cc_expires_month=' . $_POST['authorizenet_cim_cc_expires_month'] . '&authorizenet_cim_cc_expires_year=' . $_POST['authorizenet_cim_cc_expires_year'];
			  $messageStack->add_session('checkout_payment', $error . '<!-- ['.$this->code.'] -->', 'error');   
			  zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, $payment_error_return, 'SSL', true, false));
			}
			$csql = "select * from " . TABLE_ADDRESS_BOOK . " WHERE address_book_id = :adressID ";
			$csql = $db->bindVars($csql, ':adressID', $user->fields['customers_default_address_id'], 'integer');
			$primary_address = $db->Execute($csql);
			if($primary_address->fields['entry_zone_id']){
					$state_result = $db->Execute("select zone_code from ".TABLE_ZONES." where zone_country_id = '".$primary_address->fields['entry_country_id']."' and zone_id ='".$primary_address->fields['entry_zone_id']."' ");				
			}

			// Create the shipping profile  
			$countries_array = zen_get_countries($primary_address->fields['entry_country_id'], true);   
			$this->setParameter('billTo_firstName', $primary_address->fields['entry_firstname']);    
			$this->setParameter('billTo_lastName', $primary_address->fields['entry_lastname']);
			//$cim->setParameter('billTo_company', $primary_address->fields['entry_company']);
			$this->setParameter('billTo_address', $primary_address->fields['entry_street_address']);
			$this->setParameter('billTo_city', $primary_address->fields['entry_city']);
			$this->setParameter('billTo_state',  $state_result->fields['zone_code']);
			$this->setParameter('billTo_zip', $primary_address->fields['entry_postcode']);
			$this->setParameter('billTo_country', $countries_array['countries_name']);
			$this->setParameter('billTo_phoneNumber', $user->fields['customers_telephone']);			
			$this->setParameter('customerType', 'individual');	
			$this->setParameter('paymentType', 'creditCard');	
			$this->setParameter('cardNumber', $_POST['authorizenet_cim_cc_number']);	
			$this->setParameter('expirationDate', "20".$_POST['authorizenet_cim_cc_expires_year'].'-'.$_POST['authorizenet_cim_cc_expires_month']);							
			if(MODULE_PAYMENT_AUTHORIZENET_CIM_TESTMODE == 'Test') {
				$this->setParameter('validationMode','testMode');	
			}
			else
			{
				$this->setParameter('validationMode','liveMode');	
			}
			$this->createCustomerPaymentProfileRequest();
			if($this->isSuccessful())
			{					
					$this->setParameter('customerPaymentProfileId', $this->customerPaymentProfileId);
			}
			else
			{
				$payment_error_return = 'payment_error=' . $this->code . '&authorizenet_cim_cc_owner=' . urlencode($_POST['authorizenet_cim_cc_owner']) . '&authorizenet_cim_cc_expires_month=' . $_POST['authorizenet_cim_cc_expires_month'] . '&authorizenet_cim_cc_expires_year=' . $_POST['authorizenet_cim_cc_expires_year'];
				zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, $payment_error_return, 'SSL', true, false));
			}			
		}
	}
	else
	{
		$csql = "select * from " . TABLE_CUSTOMERS . " WHERE customers_id = :custID ";
		$csql = $db->bindVars($csql, ':custID', $_SESSION['customer_id'], 'integer');
		$user = $db->Execute($csql);
		$customers_customerPaymentProfileId = $user->fields['customers_customerPaymentProfileId'];
		if($customers_customerPaymentProfileId==0)
		{
			$payment_error_return = 'payment_error=' . $this->code . '&authorizenet_cim_cc_owner=' . urlencode($_POST['authorizenet_cim_cc_owner']) . '&authorizenet_cim_cc_expires_month=' . $_POST['authorizenet_cim_cc_expires_month'] . '&authorizenet_cim_cc_expires_year=' . $_POST['authorizenet_cim_cc_expires_year'];
			zen_redirect(zen_href_link(FILENAME_CHECKOUT_PAYMENT, $payment_error_return, 'SSL', true, false));
		}
	}   
  }
  /**
   * Display Credit Card Information on the Checkout Confirmation Page
   *
   * @return array
   */
  function confirmation() {
  	global $reorder_var;
    $confirmation = array('fields' => array(/*array('title' => MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CREDIT_CARD_TYPE,
                                                  'field' => $this->cc_card_type),
                                            array('title' => MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CREDIT_CARD_OWNER,
                                                  'field' => $_POST['authorizenet_cim_cc_owner']),
                                            array('title' => MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CREDIT_CARD_NUMBER,
                                                  'field' => substr($this->cc_card_number, 0, 4) . str_repeat('X', (strlen($this->cc_card_number) - 8)) . substr($this->cc_card_number, -4)),
                                            array('title' => MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CREDIT_CARD_EXPIRES,
                                                  'field' => strftime('%B, %Y', mktime(0,0,0,$_POST['authorizenet_cim_cc_expires_month'], 1, '20' . $_POST['authorizenet_cim_cc_expires_year']))), 

                                            array('title' => MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_REORDER,
                                                  'field' => $reorder_var[$_POST['authorizenet_cim_reorder']])
*/                                                  
                                            ));
    return $confirmation;
  }
  /**
   * Build the data and actions to process when the "Submit" button is pressed on the order-confirmation screen.
   * This sends the data to the payment gateway for processing.
   * (These are hidden fields on the checkout confirmation page)
   *
   * @return string
   */ 
  function process_button() {
    /*$process_button_string = zen_draw_hidden_field('cc_owner', $_POST['authorizenet_cim_cc_owner']) .
                             zen_draw_hidden_field('cc_expires', $this->cc_expiry_month . substr($this->cc_expiry_year, -2)) .
                             zen_draw_hidden_field('cc_expires_date', $this->cc_expiry_year."-".$this->cc_expiry_month) .
                             zen_draw_hidden_field('cc_type', $this->cc_card_type) .
                             zen_draw_hidden_field('reorder', $_POST['authorizenet_cim_reorder']) .
                             zen_draw_hidden_field('cc_number', $this->cc_card_number);*/
    global $db;
    
    $process_button_string = zen_draw_hidden_field('customers_customerProfileId', $this->params['customerProfileId']) .
							 zen_draw_hidden_field('customers_customerPaymentProfileId', $this->params['customerPaymentProfileId']) .
                             zen_draw_hidden_field('customers_customerShippingAddressId', $this->params['customerShippingAddressId']) .
							 zen_draw_hidden_field('reorder', $_POST['authorizenet_cim_reorder']);
    if (MODULE_PAYMENT_AUTHORIZENET_CIM_USE_CVV == 'True') {
      $process_button_string .= zen_draw_hidden_field('cc_cvv', $_POST['authorizenet_cim_cc_cvv']);
    }
    $process_button_string .= zen_draw_hidden_field(zen_session_name(), zen_session_id());

    return $process_button_string;
  }
  /**
   * Store the CC info to the order and process any results that come back from the payment gateway
   *
   */
   function before_process() {  
    global $response, $zendb, $order, $messageStack;
    unset($response);
	/*echo "<pre>";print_r($order);
	die;*/
	$customerProfileId 			= $_REQUEST['cpid'];
    $customerPaymentProfileId 	= $_REQUEST['cppid'];
    $customerShippingAddressId 	= $_REQUEST['caid'];
    $cvv					 	= $_REQUEST['cvv'];
    $tg = 1;
    $tgd = 0;
   foreach ($order->info['total'] as $key => $value) {
      /***************Authorize the card************/
	  $total = round($value, 2);
	  $total =  number_format($total,2);
	  $total  = str_replace(",","", $total);
     
      $this->setParameter('transaction_amount', $total);     
      for ($i=0; $i<sizeof($order->products[$key]); $i++) {
        $this->LineItems[] =  array("itemId"=>$order->products[$key][$i]['id'],
                  "name"=> substr($order->products[$key][$i]['name'],0,10),
                  "quantity"=>$order->products[$key][$i]['qty'],
                  "unitPrice"=>$order->products[$key][$i]['price']
                  );     
      }    
      $this->transactionLineItems();   
      $this->setParameter('customerProfileId', $_REQUEST['cpid']);
      $this->setParameter('customerPaymentProfileId', $_REQUEST['cppid']);
      $this->setParameter('customerShippingAddressId', $_REQUEST['caid']);
       $order_query 	= "select orders_id  from " . TABLE_ORDERS . " order by orders_id desc limit 1";
		$getorderRes 		= mysqli_query($zendb,$order_query);
		$getorderRow = mysqli_fetch_array($getorderRes);
		$getorderId =  $getorderRow['orders_id'];
		$newOrderId 	= $getorderId+1; 
      $this->setParameter('order_invoiceNumber', $newOrderId);
      $this->setParameter('transactionCardCode', $cvv);
      $transactionType = MODULE_PAYMENT_AUTHORIZENET_CIM_AUTHORIZATION_TYPE == 'Authorize' ? 'profileTransAuthOnly': 'profileTransAuthCapture';
      $this->setParameter('transactionType', $transactionType);//transactionType must be (profileTransCaptureOnly, profileTransAuthCapture or profileTransAuthOnly)   
      $this->createCustomerProfileTransactionRequest();   
     
      if ($this->isSuccessful())
      {
          $_SESSION['approvalCode'][$key] = $this->approvalCode;
          $_SESSION['transID'][$key] = $this->transID;
      }     
      
      
      $response = explode($this->responseDelimiter, $this->substring_between($this->response,'<directResponse>','</directResponse>'));   
      $response_code = $response[0];
	  $response_text = $response[3];  
	  $response_msg_to_customer = $response_text . ($this->commError == '' ? '' : ' Communications Error - Please notify webmaster.');
	  $response_msg_to_customer = $response_msg_to_customer .' - ' . MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_DECLINED_MESSAGE;
		if($response[2] == "E00027"){
			 $response_text = "Credit card declined. This can occur if there are not enough funds present in the account, if your bank is blocking the transaction, or if the card is no longer active. Please try another card or contact your bank.";
			  $response_msg_to_customer = $response_text . ($this->commError == '' ? '' : ' Communications Error - Please notify webmaster.');
		}else if($this->code == "E00040"){
			 $response_text = "Processing error. Please try again in a few minutes.";
			  $response_msg_to_customer = $response_text . ($this->commError == '' ? '' : ' Communications Error - Please notify webmaster.');
		}
      $_SESSION['total_paid'] = $response[9];
	  $order_time = '';
      $sessID = '';
      $this->_debugActions($response, $order_time, $sessID);
	  
	 /// echo "<pre>";print_r($this->substring_between($this->response,'<text>','</text>'));
      
      // If the response code is not 1 (approved) then redirect back to the payment page with the appropriate error message
     if ($response_code != '1') {
	    for ($i=0; $i<sizeof($order->allproducts[$tgd]); $i++) {
			$cstId = $_SESSION['customer_id'];
		  $PrevProductQty = $_SESSION['old_qty_'.$order->products[$i]['id'].'_'.$cstId];
		  $db->Execute("update " . TABLE_PRODUCTS . " set products_quantity = '".$PrevProductQty."' where products_id = '" . zen_get_prid($order->products[$i]['id']) . "'");
	    } 
        $res = array('status' => '5',"msg" => $this->substring_between($this->response,'<text>','</text>'));
		return $res;
      }
      $tg++;
      $tgd++;
    }
 
  }
  /**
   * Post-process activities. Updates the order-status history data with the auth code from the transaction.
   *
   * @return boolean
   */
  function after_process($insert_ids) {
    global $zendb, $order;
	// cim
    $gt = 0;
    foreach ($insert_ids as $key => $insert_id) {
       /* mysql_query("update " . TABLE_ORDERS  . "
         set reorder = ''
         where orders_id = '" . (int)$insert_id . "'");*/
         $address_book = mysqli_query($zendb,"select * from ".TABLE_ADDRESS_BOOK." where
     customers_id=".$_SESSION['customer_id']." and entry_street_address ='".$order->delivery['street_address']."'
      and entry_postcode ='".$order->delivery['postcode']."' ");  
      
        $address_book = mysqli_fetch_array($address_book);
        $orderComments = 'Credit Card payment.  AUTH: ' . $_SESSION['approvalCode'][$key] . '. TransID: ' . $_SESSION['transID'][$key];
        $orders_id = $insert_id;
        $orderStatus = $this->order_status;
        $date_added = '';
         
		$sql = "insert into " . TABLE_ORDERS_STATUS_HISTORY . " (comments, orders_id, orders_status_id, date_added) values ('".$orderComments."', '".$orders_id."', '". $orderStatus."', now() )";
		mysqli_query($zendb,$sql);    
		if(isset($_SESSION['custom_ship_code'])){
		  @$_SESSION['custom_ship_code'] = $_SESSION['custom_ship_code'];
		}else{
		  @$_SESSION['custom_ship_code'] = $order->info['shipping_module_code'];
		}
		$sql = "update orders_details set authorization ='".$_SESSION['approvalCode'][$key]."',transID='".$_SESSION['transID'][$key]."', authorization_date = now(), ship_address_id ='".$address_book['address_book_id']."', ship_service_code ='".$_SESSION['custom_ship_code']."' where orders_id = '" . (int)$insert_id . "' ";
		 mysqli_query($zendb,$sql);
			$gt++;
    }
   
    unset($_SESSION['approvalCode']); 
    unset($_SESSION['transID']); 
    unset($_SESSION['total_paid']); 
    unset($_SESSION['requested_ship_date']); 
    unset($_SESSION['special_shipping_instructions']); 
    unset($_SESSION['custom_ship_code']);

    return false;
  }
  /**
    * Build admin-page components
    *
    * @param int $zf_order_id
    * @return string
    */
  function RENAME_admin_notification($zf_order_id) {
    global $db;
    $output = '';
    $cimdata->fields = array();
    require(DIR_FS_CATALOG . DIR_WS_MODULES . 'payment/authorizenet/authorizenet_admin_notification.php');
    return $output;
  }
  /**
   * Used to display error message details
   *
   * @return array
   */
  function get_error() {
    $error = array('title' => MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_ERROR,
                   'error' => stripslashes(urldecode($_GET['error'])));
    return $error;
  }
  /**
   * Check to see whether module is installed
   *
   * @return boolean
   */
  function check() {
    global $db;
    if (!isset($this->_check)) {
      $check_query = $db->Execute("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_AUTHORIZENET_CIM_STATUS'");
      $this->_check = $check_query->RecordCount();
    }
    return $this->_check;
  }
  /**
   * Install the payment module and its configuration settings
   *
   */
  function install() {
    global $db;
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable Authorize.net (CIM) Module', 'MODULE_PAYMENT_AUTHORIZENET_CIM_STATUS', 'True', 'Do you want to accept Authorize.net payments via the CIM Method?', '6', '1', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Login ID', 'MODULE_PAYMENT_AUTHORIZENET_CIM_LOGIN', 'testing', 'The API Login ID used for the Authorize.net service', '6', '2', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added, use_function) values ('Transaction Key', 'MODULE_PAYMENT_AUTHORIZENET_CIM_TXNKEY', 'Test', 'Transaction Key used for encrypting TP data<br />(See your Authorizenet Account->Security Settings->API Login ID and Transaction Key for details.)', '6', '3', now(), 'zen_cfg_password_display')");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added, use_function) values ('MD5 Hash', 'MODULE_PAYMENT_AUTHORIZENET_CIM_MD5HASH', '*Set A Hash Value at AuthNet Admin*', 'Encryption key used for validating received transaction data (MAX 20 CHARACTERS)', '6', '4', now(), 'zen_cfg_password_display')");
    /* v. 0.7 */
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added, use_function) values ('Reorder Authentication Passkey', 'MODULE_PAYMENT_AUTHORIZENET_CIM_PASSKEY', 'Authentication string', 'Simple passkey used for authenticating on reorder file  (MAX 20 CHARACTERS)', '6', '5', now(), 'zen_cfg_password_display')");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Transaction Mode', 'MODULE_PAYMENT_AUTHORIZENET_CIM_TESTMODE', 'Test', 'Transaction mode used for processing orders', '6', '6', 'zen_cfg_select_option(array(\'Test\', \'Production\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Authorization Type', 'MODULE_PAYMENT_AUTHORIZENET_CIM_AUTHORIZATION_TYPE', 'Authorize', 'Do you want submitted credit card transactions to be authorized only, or authorized and captured?', '6', '7', 'zen_cfg_select_option(array(\'Authorize\', \'Authorize+Capture\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable Database Storage', 'MODULE_PAYMENT_AUTHORIZENET_CIM_STORE_DATA', 'True', 'Do you want to save the gateway communications data to the database?', '6', '8', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Customer Notifications', 'MODULE_PAYMENT_AUTHORIZENET_CIM_EMAIL_CUSTOMER', 'False', 'Should Authorize.Net email a receipt to the customer?', '6', '9', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Merchant Notifications', 'MODULE_PAYMENT_AUTHORIZENET_CIM_EMAIL_MERCHANT', 'False', 'Should Authorize.Net email a receipt to the merchant?', '6', '10', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Request CVV Number', 'MODULE_PAYMENT_AUTHORIZENET_CIM_USE_CVV', 'True', 'Do you want to ask the customer for the card\'s CVV number', '6', '11', 'zen_cfg_select_option(array(\'True\', \'False\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Validation Mode', 'MODULE_PAYMENT_AUTHORIZENET_CIM_VALIDATION', 'testMode', 'Validation Mode', '6', '12', 'zen_cfg_select_option(array(\'none\', \'testMode\', \'liveMode\'), ', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Sort order of display.', 'MODULE_PAYMENT_AUTHORIZENET_CIM_SORT_ORDER', '0', 'Sort order of display. Lowest is displayed first.', '6', '13', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added) values ('Payment Zone', 'MODULE_PAYMENT_AUTHORIZENET_CIM_ZONE', '0', 'If a zone is selected, only enable this payment method for that zone.', '6', '14', 'zen_get_zone_class_title', 'zen_cfg_pull_down_zone_classes(', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Completed Order Status', 'MODULE_PAYMENT_AUTHORIZENET_CIM_ORDER_STATUS_ID', '0', 'Set the status of orders made with this payment module to this value', '6', '15', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Refunded Order Status', 'MODULE_PAYMENT_AUTHORIZENET_CIM_REFUNDED_ORDER_STATUS_ID', '1', 'Set the status of refunded orders to this value', '6', '16', 'zen_cfg_pull_down_order_statuses(', 'zen_get_order_status_name', now())");
    $db->Execute("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Debug Mode', 'MODULE_PAYMENT_AUTHORIZENET_CIM_DEBUGGING', 'Off', 'Would you like to enable debug mode?  A complete detailed log of failed transactions may be emailed to the store owner.', '6', '17', 'zen_cfg_select_option(array(\'Off\', \'Log File\', \'Log and Email\'), ', now())");
  }
  /**
   * Remove the module and all its settings
   *
   */
  function remove() {
    global $db;
    $db->Execute("delete from " . TABLE_CONFIGURATION . " where configuration_key like 'MODULE\_PAYMENT\_AUTHORIZENET_CIM\_%'");
  }
  /**
   * Internal list of configuration keys used for configuration of the module
   *
   * @return array
   */
  function keys() {
    return array('MODULE_PAYMENT_AUTHORIZENET_CIM_STATUS', 'MODULE_PAYMENT_AUTHORIZENET_CIM_LOGIN', 'MODULE_PAYMENT_AUTHORIZENET_CIM_TXNKEY', 'MODULE_PAYMENT_AUTHORIZENET_CIM_MD5HASH', 'MODULE_PAYMENT_AUTHORIZENET_CIM_PASSKEY', 'MODULE_PAYMENT_AUTHORIZENET_CIM_TESTMODE', 'MODULE_PAYMENT_AUTHORIZENET_CIM_AUTHORIZATION_TYPE', 'MODULE_PAYMENT_AUTHORIZENET_CIM_STORE_DATA', 'MODULE_PAYMENT_AUTHORIZENET_CIM_EMAIL_CUSTOMER', 'MODULE_PAYMENT_AUTHORIZENET_CIM_EMAIL_MERCHANT', 'MODULE_PAYMENT_AUTHORIZENET_CIM_USE_CVV', 
    'MODULE_PAYMENT_AUTHORIZENET_CIM_VALIDATION','MODULE_PAYMENT_AUTHORIZENET_CIM_SORT_ORDER', 'MODULE_PAYMENT_AUTHORIZENET_CIM_ZONE', 'MODULE_PAYMENT_AUTHORIZENET_CIM_ORDER_STATUS_ID', 'MODULE_PAYMENT_AUTHORIZENET_CIM_REFUNDED_ORDER_STATUS_ID', 'MODULE_PAYMENT_AUTHORIZENET_CIM_DEBUGGING');
  }
  /**
   * Send communication request
   */
  function _sendRequest($submit_data) {

    // Populate an array that contains all of the data to be sent to Authorize.net
    $submit_data = array_merge(array(
                         'x_login' => trim(MODULE_PAYMENT_AUTHORIZENET_CIM_LOGIN),
                         'x_tran_key' => trim(MODULE_PAYMENT_AUTHORIZENET_CIM_TXNKEY),
                         'x_relay_response' => 'FALSE',
                         'x_delim_data' => 'TRUE',
                         'x_delim_char' => $this->delimiter,  // The default delimiter is a comma
                         'x_encap_char' => $this->encapChar,  // The divider to encapsulate response fields
                         'x_version' => '3.1',  // 3.1 is required to use CVV codes
                         ), $submit_data);

    if(MODULE_PAYMENT_AUTHORIZENET_CIM_TESTMODE == 'Test') {
      $submit_data['x_test_request'] = 'TRUE';
      $url = 'https://test.authorize.net/gateway/transact.dll';
    }
    else
    {
		$url = 'https://secure.authorize.net/gateway/transact.dll';
	}

    // set URL
   
    if (defined('AUTHORIZENET_DEVELOPER_MODE')) {
      if (AUTHORIZENET_DEVELOPER_MODE == 'on') $url = 'https://test.authorize.net/gateway/transact.dll';
      if (AUTHORIZENET_DEVELOPER_MODE == 'echo' || MODULE_PAYMENT_AUTHORIZENET_CIM_DEBUGGING == 'echo') $url = 'https://developer.authorize.net/param_dump.asp';
      if (AUTHORIZENET_DEVELOPER_MODE == 'certify') $url = 'https://certification.authorize.net/gateway/transact.dll';
    }
    if (MODULE_PAYMENT_AUTHORIZENET_CIM_DEBUGGING == 'echo') $url = 'https://developer.authorize.net/param_dump.asp';

    // concatenate the submission data into $data variable after sanitizing to protect delimiters
    $data = '';
    while(list($key, $value) = each($submit_data)) {
      if ($key != 'x_delim_char' && $key != 'x_encap_char') {
        $value = str_replace(array($this->delimiter, $this->encapChar,'"',"'",'&amp;','&', '='), '', $value);
      }
      $data .= $key . '=' . urlencode($value) . '&';
    }
    // Remove the last "&" from the string
    $data = substr($data, 0, -1);


    // prepare a copy of submitted data for error-reporting purposes
    $this->reportable_submit_data = $submit_data;
    $this->reportable_submit_data['x_login'] = '*******';
    $this->reportable_submit_data['x_tran_key'] = '*******';
    if (isset($this->reportable_submit_data['x_card_num'])) $this->reportable_submit_data['x_card_num'] = str_repeat('X', strlen($this->reportable_submit_data['x_card_num'] - 4)) . substr($this->reportable_submit_data['x_card_num'], -4);
    if (isset($this->reportable_submit_data['x_card_code'])) $this->reportable_submit_data['x_card_code'] = '****';
    $this->reportable_submit_data['url'] = $url;


    // Post order info data to Authorize.net via CURL - Requires that PHP has cURL support installed

    // Send CURL communication
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_VERBOSE, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); /* compatibility for SSL communications on some Windows servers (IIS 5.0+) */
    if (CURL_PROXY_REQUIRED == 'True') {
      $this->proxy_tunnel_flag = (defined('CURL_PROXY_TUNNEL_FLAG') && strtoupper(CURL_PROXY_TUNNEL_FLAG) == 'FALSE') ? false : true;
      curl_setopt ($ch, CURLOPT_HTTPPROXYTUNNEL, $this->proxy_tunnel_flag);
      curl_setopt ($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
      curl_setopt ($ch, CURLOPT_PROXY, CURL_PROXY_SERVER_DETAILS);
    }

    $this->authorize = curl_exec($ch);
    $this->commError = curl_error($ch);
    $this->commErrNo = curl_errno($ch);

    $this->commInfo = @curl_getinfo($ch);
    curl_close ($ch);

    // if in 'echo' mode, dump the returned data to the browser and stop execution
    if ((defined('AUTHORIZENET_DEVELOPER_MODE') && AUTHORIZENET_DEVELOPER_MODE == 'echo') || MODULE_PAYMENT_AUTHORIZENET_CIM_DEBUGGING == 'echo') {
      echo $this->authorize . ($this->commErrNo != 0 ? '<br />' . $this->commErrNo . ' ' . $this->commError : '') . '<br />';
      die('Press the BACK button in your browser to return to the previous page.');
    }

    // parse the data received back from the gateway, taking into account the delimiters and encapsulation characters
    $stringToParse = $this->authorize;
    if (substr($stringToParse,0,1) == $this->encapChar) $stringToParse = substr($stringToParse,1);
    $stringToParse = preg_replace('/.{*}' . $this->encapChar . '$/', '', $stringToParse);
    $response = explode($this->encapChar . $this->delimiter . $this->encapChar, $stringToParse);

    return $response;
  }
  /**
   * Calculate validity of response
   */
  function calc_md5_response($trans_id = '', $amount = '') {
    if ($amount == '' || $amount == '0') $amount = '0.00';
    $validating = md5(MODULE_PAYMENT_AUTHORIZENET_CIM_MD5HASH . MODULE_PAYMENT_AUTHORIZENET_CIM_LOGIN . $trans_id . $amount);
    return strtoupper($validating);
  }
  /**
   * Used to do any debug logging / tracking / storage as required.
   */
  function _debugActions($response, $order_time= '', $sessID = '') {
    global $zendb, $messageStack;
    if ($order_time == '') $order_time = date("F j, Y, g:i a");
    // convert output to 1-based array for easier understanding:
    $resp_output = array_reverse($response);
    $resp_output[] = 'Response from gateway';
    $resp_output = array_reverse($resp_output);

    // DEBUG LOGGING
      $errorMessage = date('M-d-Y h:i:s') .
                      "\n=================================\n\n" .
                      ($this->commError !='' ? 'Comm results: ' . $this->commErrNo . ' ' . $this->commError . "\n\n" : '') .
                      'Response Code: ' . $response[0] . ".\nResponse Text: " . $response[3] . "\n\n" .
                      'Sending to Authorizenet: ' . print_r($this->reportable_submit_data, true) . "\n\n" .
                      'Results Received back from Authorizenet: ' . print_r($resp_output, true) . "\n\n" .
                      'CURL communication info: ' . print_r($this->commInfo, true) . "\n";
     
      $errorMessage .= "\nRAW data received: \n" . $this->authorize . "\n\n";

    // DATABASE SECTION
    // Insert the send and receive response data into the database.
    // This can be used for testing or for implementation in other applications
    // This can be turned on and off if the Admin Section
   
      $db_response_text = $response[3] . ($this->commError !='' ? ' - Comm results: ' . $this->commErrNo . ' ' . $this->commError : '');
      $db_response_text .= ($response[0] == 2 && $response[2] == 4) ? ' NOTICE: Card should be picked up - possibly stolen ' : '';
      $db_response_text .= ($response[0] == 3 && $response[2] == 11) ? ' DUPLICATE TRANSACTION ATTEMPT ' : '';
      $orderidarr = explode("-",$response[7]);
      $orderid = $orderidarr[0];
      // Insert the data into the database
      $vd = preg_replace('/[^0-9]/', '', $orderid);
      $vd1 = print_r($this->reportable_submit_data, true);
      $vd2 = print_r($response, true);
      $sql = "insert into authorizenet  (id, customer_id, order_id, response_code, response_text, authorization_type, transaction_id, sent, received, time, session_id) values (NULL,'".$_SESSION['customer_id']."', '".$vd."', '".$response[0]."', '".$db_response_text."', '".$response[11]."', '".$this->transaction_id."', '".$vd1."', '".$vd2."', '".$order_time."', '".$sessID."' )";
      mysqli_query($zendb,$sql);
  }
  /*********Capture the Authoried transaction **************/
  public function _docapturetranstion($oID)
  {
	  global $db,$messageStack;
      $ip = $this->getRealIpAddr();
   
	  $new_order_status = (int)24;
      if ($new_order_status == 0) $new_order_status = DEFAULT_ORDERS_STATUS_ID;
      $captureNote = "";
	  $pre_authorised_trans = $db->Execute("select * from ".TABLE_ORDERS_DETAILS." where orders_id=".$oID." and paid =0");	  	  
	  $transID = trim($pre_authorised_trans->fields['transID']);
	  $_order = $db->Execute("select order_total,customers_id from ".TABLE_ORDERS." where orders_id=".$oID);	  
	  $customer_info = $db->Execute("Select * from ".TABLE_CUSTOMERS." where customers_id=".$_order->fields['customers_id']."");	
	  $order_total = $_order->fields['order_total'];
	  if($transID!="")
	  {
		 $this->xml = '<?xml version="1.0" encoding="utf-8"?>
							<createCustomerProfileTransactionRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">
							  <merchantAuthentication>
								<name>' . $this->login . '</name>
								<transactionKey>' . $this->transkey . '</transactionKey>
							  </merchantAuthentication>
							  <transaction>
							<profileTransPriorAuthCapture>
								  <amount>'.$order_total.'</amount>  
								  <customerProfileId>'.$customer_info->fields['customers_customerProfileId'].'</customerProfileId>								  
								  <transId>'.$transID.'</transId>
								</profileTransPriorAuthCapture>
							  </transaction>
							   <extraOptions>
									 <![CDATA[x_customer_ip='.$ip.'&x_duplicate_window=0]]>
								</extraOptions>
							</createCustomerProfileTransactionRequest>';			
			$this->process();			
			$response = explode($this->responseDelimiter,$this->substring_between($this->response,'<directResponse>','</directResponse>'));
			$response_code = $response[0];
			$response_text = $response[3];
			$response_alert = $response_text . ($this->commError == '' ? '' : ' Communications Error - Please notify webmaster.');
			$this->reportable_submit_data['Note'] = $captureNote;
			$this->_debugActions($response);

			if ($response_code != '1' || ($response[0]==1 && $response[2] == 311) ) {
			$messageStack->add_session($response_alert, 'error');
			} else {
			// Success, so save the results
			$sql_data_array = array('orders_id' => (int)$oID,
									'orders_status_id' => (int)$new_order_status,
									'date_added' => 'now()',
									'comments' => 'FUNDS COLLECTED. Auth Code: ' . $response[4] . "\n" . 'Trans ID: ' . $response[6] . "\n" . ' Amount: ' . ($response[9] == 0.00 ? 'Full Amount' : $response[9]) . "\n" . 'Time: ' . date('Y-m-D h:i:s') . "\n" . $captureNote,
									'customer_notified' => 0
								 );
		    $db->Execute('update '.TABLE_ORDERS_DETAILS.' set captured=1,paid=1,captured_date = now() where orders_id='.$oID);
			zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);
			$db->Execute("update " . TABLE_ORDERS  . "
						  set orders_status = '" . (int)$new_order_status . "'
						  where orders_id = '" . (int)$oID . "'");
			$db->Execute("insert into ".TABLE_ORDERS_PAYMENTS." (orders_id,payment_date,amount,transaction_type,transaction_number) 
				values('" . (int)$oID . "',now(),'".$response[9]."','Paid-CC','". $response[6] ."')");
			$messageStack->add_session(sprintf(MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CAPT_INITIATED, ($response[9] == 0.00 ? 'Full Amount' : $response[9]), $response[6], $response[4]), 'success');
			return true;
			}				
      }
	  
  }
  /**
   * Used to submit a refund for a given transaction.
   */
  function _doRefund($oID, $amount = 0) {
    global $db, $messageStack;
    $new_order_status = (int)MODULE_PAYMENT_AUTHORIZENET_CIM_REFUNDED_ORDER_STATUS_ID;
    if ($new_order_status == 0) $new_order_status = 1;
    $proceedToRefund = true;
    $refundNote = strip_tags(zen_db_input($_POST['refnote']));
    if (isset($_POST['refconfirm']) && $_POST['refconfirm'] != 'on') {
      $messageStack->add_session(MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_REFUND_CONFIRM_ERROR, 'error');
      $proceedToRefund = false;
    }
    if (isset($_POST['buttonrefund']) && $_POST['buttonrefund'] == MODULE_PAYMENT_AUTHORIZENET_CIM_ENTRY_REFUND_BUTTON_TEXT) {
      $refundAmt = (float)$_POST['refamt'];
      $new_order_status = (int)MODULE_PAYMENT_AUTHORIZENET_CIM_REFUNDED_ORDER_STATUS_ID;
      if ($refundAmt == 0) {
        $messageStack->add_session(MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_INVALID_REFUND_AMOUNT, 'error');
        $proceedToRefund = false;
      }
    }       
    $this->setParameter('refId', $_POST['customer_id']);
    $this->setParameter('customerProfileId', $_POST['customers_customerProfileId']);
    $this->setParameter('customerPaymentProfileId', $_POST['customers_customerPaymentProfileId']);	
    $this->getCustomerPaymentProfileRequest();
    $_POST['cc_number'] = $this->cardNumber;  
    $expirationDate = $this->expirationDate;
     
    if (isset($_POST['cc_number']) && trim($_POST['cc_number']) == '') {
      $messageStack->add_session(MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CC_NUM_REQUIRED_ERROR, 'error');
    }
    if (isset($_POST['trans_id']) && trim($_POST['trans_id']) == '') {
      $messageStack->add_session(MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_TRANS_ID_REQUIRED_ERROR, 'error');
      $proceedToRefund = false;
    }
    if($proceedToRefund)
    {
		$this->setParameter('amount', number_format($_POST['refamt'], 2));   
		$this->setParameter('cardNumber', $_POST['cc_number']);   
		$this->setParameter('expirationDate', $expirationDate);   
		$this->setParameter('trans_id', $_POST['trans_id']);   		
		$this->xml = '<?xml version="1.0" encoding="utf-8"?>
						<createCustomerProfileTransactionRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">
						  <merchantAuthentication>
							<name>'. $this->login .'</name>
							<transactionKey>' . $this->transkey .'</transactionKey>
						  </merchantAuthentication>
						  <transaction>
							<profileTransRefund>
							  <amount>'.$this->params['amount'].'</amount>      
							  <customerProfileId>'.$this->params['customerProfileId'].'</customerProfileId>
							  <customerPaymentProfileId>'.$this->params['customerPaymentProfileId'].'</customerPaymentProfileId>							 							  
							  <transId>'.$this->params['trans_id'].'</transId>
							</profileTransRefund>
						  </transaction>  
						</createCustomerProfileTransactionRequest>';
		$this->process();		
		$response = explode($this->responseDelimiter,$this->substring_between($this->response,'<directResponse>','</directResponse>'));
		$response_code = $response[0];
		$response_text = $response[3];
		$response_alert = $response_text . ($this->commError == '' ? '' : ' Communications Error - Please notify webmaster.');
		$this->reportable_submit_data['Note'] = $captureNote;
		$this->_debugActions($response);

		if ($response_code != '1' || ($response[0]==1 && $response[2] == 311) ) {
			$messageStack->add_session($response_alert, 'error');
		} else {
		// Success, so save the results
		$sql_data_array = array('orders_id' => (int)$oID,
							'orders_status_id' => (int)$new_order_status,
							'date_added' => 'now()',
							'comments' => 'FUNDS COLLECTED. Auth Code: ' . $response[4] . "\n" . 'Trans ID: ' . $response[6] . "\n" . ' Amount: ' . ($response[9] == 0.00 ? 'Full Amount' : $response[9]) . "\n" . 'Time: ' . date('Y-m-D h:i:s') . "\n" . $captureNote,
							'customer_notified' => 0
						 );
		zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);
		$db->Execute("update " . TABLE_ORDERS  . "
				  set orders_status = '" . (int)$new_order_status . "'
				  where orders_id = '" . (int)$oID . "'");
	    $transaction_type = "";
	    if($_POST['refund']=="full_refund")
	    {
			$transaction_type = "Refund-Complete";
		}
	    else
	    {
			$transaction_type = "Refund-Partial";			
		}
		$transaction_type = "Refund";
	    $db->Execute("insert into ".TABLE_ORDERS_PAYMENTS." (orders_id,payment_date,amount,transaction_type,transaction_number) 
				values('" . (int)$oID . "',now(),'".$response[9]."','".$transaction_type."','". $response[6] ."')");
		$messageStack->add_session(sprintf(MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CAPT_INITIATED, ($response[9] == 0.00 ? 'Full Amount' : $response[9]), $response[6], $response[4]), 'success');
		return true;
		}			
	}   
    return false;
  }

  /**
   * Used to capture part or all of a given previously-authorized transaction.
   */
  function _doCapt($oID, $amt = 0, $currency = 'USD') {
    global $db, $messageStack;

    //@TODO: Read current order status and determine best status to set this to
    $new_order_status = (int)MODULE_PAYMENT_AUTHORIZENET_CIM_ORDER_STATUS_ID;
    if ($new_order_status == 0) $new_order_status = 1;

    $proceedToCapture = true;
    $captureNote = strip_tags(zen_db_input($_POST['captnote']));
    if (isset($_POST['captconfirm']) && $_POST['captconfirm'] == 'on') {
    } else {
      $messageStack->add_session(MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CAPTURE_CONFIRM_ERROR, 'error');
      $proceedToCapture = false;
    }
    if (isset($_POST['btndocapture']) && $_POST['btndocapture'] == MODULE_PAYMENT_AUTHORIZENET_CIM_ENTRY_CAPTURE_BUTTON_TEXT) {
      $captureAmt = (float)$_POST['captamt'];
/*
      if ($captureAmt == 0) {
        $messageStack->add_session(MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_INVALID_CAPTURE_AMOUNT, 'error');
        $proceedToCapture = false;
      }
*/
    }
    if (isset($_POST['captauthid']) && trim($_POST['captauthid']) != '') {
      // okay to proceed
    } else {
      $messageStack->add_session(MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_TRANS_ID_REQUIRED_ERROR, 'error');
      $proceedToCapture = false;
    }
    /**
     * Submit capture request to Authorize.net
     */
    if ($proceedToCapture) {
      // Populate an array that contains all of the data to be sent to Authorize.net
      unset($submit_data);
      $submit_data = array(
                           'x_type' => 'PRIOR_AUTH_CAPTURE',
                           'x_amount' => number_format($captureAmt, 2),
                           'x_trans_id' => strip_tags(trim($_POST['captauthid'])),
//                         'x_invoice_num' => $new_order_id,
//                         'x_po_num' => $order->info['po_number'],
//                         'x_freight' => $order->info['shipping_cost'],
//                         'x_tax_exempt' => 'FALSE', /* 'TRUE' or 'FALSE' */
//                         'x_tax' => $order->info['tax'],
                           );

      $response = $this->_sendRequest($submit_data);
      $response_code = $response[0];
      $response_text = $response[3];
      $response_alert = $response_text . ($this->commError == '' ? '' : ' Communications Error - Please notify webmaster.');
      $this->reportable_submit_data['Note'] = $captureNote;
      $this->_debugActions($response);

      if ($response_code != '1' || ($response[0]==1 && $response[2] == 311) ) {
        $messageStack->add_session($response_alert, 'error');
      } else {
        // Success, so save the results
        $sql_data_array = array('orders_id' => (int)$oID,
                                'orders_status_id' => (int)$new_order_status,
                                'date_added' => 'now()',
                                'comments' => 'FUNDS COLLECTED. Auth Code: ' . $response[4] . "\n" . 'Trans ID: ' . $response[6] . "\n" . ' Amount: ' . ($response[9] == 0.00 ? 'Full Amount' : $response[9]) . "\n" . 'Time: ' . date('Y-m-D h:i:s') . "\n" . $captureNote,
                                'customer_notified' => 0
                             );
        zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);
        $db->Execute("update " . TABLE_ORDERS  . "
                      set orders_status = '" . (int)$new_order_status . "'
                      where orders_id = '" . (int)$oID . "'");
        $messageStack->add_session(sprintf(MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_CAPT_INITIATED, ($response[9] == 0.00 ? 'Full Amount' : $response[9]), $response[6], $response[4]), 'success');
        return true;
      }
    }
    return false;
  }
  /**
   * Used to void a given previously-authorized transaction.
   */
  function _doVoid($oID, $note = '') {
    global $db, $messageStack;    
    $new_order_status = (int)DEFAULT_ORDERS_STATUS_ID;
    if ($new_order_status == 0) $new_order_status = (int)16;  
    $order = new order($oID);    
    $authoried_trans = $db->Execute("Select * from ".TABLE_ORDERS_DETAILS." where orders_id='".$oID."'");
	$customer_info = $db->Execute("Select * from ".TABLE_CUSTOMERS." where customers_id=".$order->customer['id']."");		
    //$this->setParameter('refId', $order->customer['id']);
    $this->setParameter('transID', $authoried_trans->fields['transID']);
    $this->setParameter('customerProfileId', $customer_info->fields['customers_customerProfileId']);
    $this->setParameter('customerPaymentProfileId',$customer_info->fields['customers_customerPaymentProfileId']);	
    $this->xml = '<?xml version="1.0" encoding="utf-8"?>
						<createCustomerProfileTransactionRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">
						  <merchantAuthentication>
							<name>'. $this->login .'</name>
							<transactionKey>' . $this->transkey .'</transactionKey>
						  </merchantAuthentication>
						  <transaction>
							<profileTransVoid>
							  <customerProfileId>'.$this->params['customerProfileId'].'</customerProfileId>
							  <customerPaymentProfileId>'.$this->params['customerPaymentProfileId'].'</customerPaymentProfileId>							 
							  <transId>'.$this->params['transID'].'</transId>
							</profileTransVoid>
						  </transaction>
						</createCustomerProfileTransactionRequest>';
	$this->process();	
	$response = explode($this->responseDelimiter,$this->substring_between($this->response,'<directResponse>','</directResponse>'));	
	$response_code = $response[0];
	$response_text = $response[3];
	$response_alert = $response_text . ($this->commError == '' ? '' : ' Communications Error - Please notify webmaster.');
	$this->reportable_submit_data['Note'] = $voidNote;
	$this->_debugActions($response);

	if ($response_code != '1' || ($response[0]==1 && $response[2] == 310) ) {
	$messageStack->add_session($response_alert, 'error');
	} else {
	// Success, so save the results
	if($order->info['orders_status']==24)
	{
		$void_type = $_POST['void_type']; 
		$new_payment_method = $_POST['new_payment_method']; 
		if($void_type=="cancel")
		{
			$new_order_status = 60;
		}
		$sql_data_array = array('orders_id' => (int)$oID,
								'orders_status_id' => (int)$new_order_status,
								'date_added' => 'now()',
								'comments' => 'VOIDED. Trans ID: ' . $response[6] . ' Auth Code: ' . $response[4] . "\n" . $voidNote,
								'customer_notified' => 0
							 );
		zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);
		if($void_type=="new_payment")
		{
			$sql_data_array = array('orders_id' => (int)$oID,
								'orders_status_id' => (int)$new_order_status,
								'date_added' => 'now()',
								'comments' => 'New Payment Method: ' . $new_payment_method,
								'customer_notified' => 0
								 );
		    zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);
		}
		
		$db->Execute("update " . TABLE_ORDERS  . "
					  set orders_status = '" . (int)$new_order_status . "'
					  where orders_id = '" . (int)$oID . "'");
		$db->Execute("insert into ".TABLE_ORDERS_PAYMENTS." (orders_id,payment_date,amount,transaction_type,transaction_number) 
					values('" . (int)$oID . "',now(),'".number_format($order->info['total'], 2)."','Void','". $response[6] ."')");
	}
	else
	{
		$sql_data_array = array('orders_id' => (int)$oID,
								'orders_status_id' => (int)DEFAULT_ORDERS_STATUS_ID,
								'date_added' => 'now()',
								'comments' => 'VOIDED. Trans ID: ' . $response[6] . ' Auth Code: ' . $response[4] . "\n" . $voidNote,
								'customer_notified' => 0
							 );
		$db->Execute("insert into ".TABLE_ORDERS_PAYMENTS." (orders_id,payment_date,amount,transaction_type,transaction_number) 
					values('" . (int)$oID . "',now(),'".number_format($order->info['total'], 2)."','Void','". $response[6] ."')");
		zen_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array);
	}
	$messageStack->add_session(sprintf(MODULE_PAYMENT_AUTHORIZENET_CIM_TEXT_VOID_INITIATED, $response[6], $response[4]), 'success');
	return true;
	}
    return false;					   
  }

// cim

	function AuthNetCim($login, $transkey, $test_mode)
	{
		$this->login = $login;
		$this->transkey = $transkey;
		$this->test_mode = $test_mode;
		
		$subdomain = ($this->test_mode) ? 'apitest' : 'api';
		$this->url = "https://" . $subdomain . ".authorize.net/xml/v1/request.api";
	}
	
	function process($retries = 3)
	{
		// before we make a connection, lets check if there are basic validation errors
		/*if (count($this->error_messages) == 0)
		{*/$retries = 454646546464;
			$count = 0;
			while ($count < $retries)
			{
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $this->url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: text/xml"));
				curl_setopt($ch, CURLOPT_HEADER, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $this->xml);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				// proxy option for godaddy hosted customers (required)
				//curl_setopt($ch, CURLOPT_PROXY,"http://proxy.shr.secureserver.net:3128");
				$this->response = curl_exec($ch);
				/*echo "<pre>";print_r($this->response);
				die;***/
				$this->parseResults();
				if ($this->resultCode == "Ok")
				{
					$this->success = true;
					$this->error = false;
					 break;
				}
				else
				{
					$this->success = false;
					$this->error = true;
					break;
				}
				$count++;
			}
			curl_close($ch);
		/*}
		else
		{
			file_put_contents('/home/holidaynet/v2.2/paymentlog/log_'.$_SESSION['customer_id'].'-'.date("j.n.Y H:i:a").'.log', $this->error_messages, FILE_APPEND);
			$this->success = false;
			$this->error = true;
		}*/
	}
// from authorize sample	
//function to parse the api response
//The code uses SimpleXML. http://us.php.net/manual/en/book.simplexml.php 
//There are also other ways to parse xml in PHP depending on the version and what is installed.
function parse_api_response($content)
{
	$parsedresponse = simplexml_load_string($content, "SimpleXMLElement", LIBXML_NOWARNING);
	if ("Ok" != $parsedresponse->messages->resultCode) {
		echo "The operation failed with the following errors:<br>";
		foreach ($parsedresponse->messages->message as $msg) {
			echo "[" . htmlspecialchars($msg->code) . "] " . htmlspecialchars($msg->text) . "<br>";
		}
		echo "<br>";
	}
	return $parsedresponse;
}
// from authorize sample	
	
	// This function is used to create a new customer profile along with any 
	// customer payment profiles and customer shipping addresses for the customer profile.
	function createCustomerProfileRequest() {
    global $db;
	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<createCustomerProfileRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->refId() . "
	<profile>
		" . $this->merchantCustomerId() . "
		" . $this->description() . "
		" . $this->email() . "

	</profile>
	</createCustomerProfileRequest>";
	$this->process();

	if ($this->isSuccessful()) {		
		$sql = "UPDATE " . TABLE_CUSTOMERS . "
				SET customers_customerProfileId = '" . (int)$this->customerProfileId . "'
				WHERE customers_id = :custID ";
		$sql = $db->bindVars($sql, ':custID', $_SESSION['customer_id'], 'integer');

		$db->Execute($sql);
		$sql = "UPDATE " . TABLE_CUSTOMERS_DETAILS . "
				SET customers_CIM_customerProfileId = '" . (int)$this->customerProfileId . "'
				WHERE customers_id = :custID ";
		$sql = $db->bindVars($sql, ':custID', $_SESSION['customer_id'], 'integer');

		$db->Execute($sql);

	}

	}

  
	// This function is used to create a new customer payment profile for an existing customer profile
	function createCustomerPaymentProfileRequest() {
    global $db;
	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<createCustomerPaymentProfileRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->refId() . "
	" . $this->customerProfileId() . "
	<paymentProfile>
		" . $this->customerType() . "
		<billTo>
			" . $this->billTo_firstName() . "
			" . $this->billTo_lastName() . "
			" . $this->billTo_company() . "
			" . $this->billTo_address() . "
			" . $this->billTo_city() . "
			" . $this->billTo_state() . "
			" . $this->billTo_zip() . "
			" . $this->billTo_country() . "
			" . $this->billTo_phoneNumber() . "
			" . $this->billTo_faxNumber() . "
		</billTo>
		<payment>
			" . $this->paymentType() . "
		</payment>
	</paymentProfile>
	" . $this->validationMode() . "
	</createCustomerPaymentProfileRequest>";
	$this->process();

	if ($this->isSuccessful()) {
    $sql = "UPDATE " . TABLE_CUSTOMERS . "
            SET customers_customerPaymentProfileId = '" . (int)$this->customerPaymentProfileId . "'
            WHERE customers_id = :custID ";
    $sql = $db->bindVars($sql, ':custID', $_SESSION['customer_id'], 'integer');
    $db->Execute($sql);
    $sql = "UPDATE " . TABLE_CUSTOMERS_DETAILS . "
            SET customers_CIM_customerPaymentProfileId = '" . (int)$this->customerPaymentProfileId . "'
            WHERE customers_id = :custID ";
    $sql = $db->bindVars($sql, ':custID', $_SESSION['customer_id'], 'integer');
    $db->Execute($sql);

	}

	}
	
	// This function is used to create a new customer shipping address for an existing customer profile
	function createCustomerShippingAddressRequest() {
    global $db;
	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<createCustomerShippingAddressRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->refId() . "
	" . $this->customerProfileId() . "
	<address>
		" . $this->shipTo_firstName() . "
		" . $this->shipTo_lastName() . "
		" . $this->shipTo_company() . "
		" . $this->shipTo_address() . "
		" . $this->shipTo_city() . "
		" . $this->shipTo_state() . "
		" . $this->shipTo_zip() . "
		" . $this->shipTo_country() . "
		" . $this->shipTo_phoneNumber() . "
		" . $this->shipTo_faxNumber() . "
	</address>
	</createCustomerShippingAddressRequest>";
	$this->process();    
	if($this->isSuccessful()) {
    $sql = "UPDATE " . TABLE_CUSTOMERS . "
            SET customers_customerShippingAddressId = '" . (int)$this->customerAddressId . "'
            WHERE customers_id = :custID ";
    $sql = $db->bindVars($sql, ':custID', $_SESSION['customer_id'], 'integer');
    $db->Execute($sql);
    $sql = "UPDATE " . TABLE_CUSTOMERS_DETAILS . "
            SET customers_CIM_customerShippingAddressId = '" . (int)$this->customerAddressId . "'
            WHERE customers_id = :custID ";
    $sql = $db->bindVars($sql, ':custID', $_SESSION['customer_id'], 'integer');
    $db->Execute($sql);

	}
    }
	public function getProfilePageRequest2()
    {		
		$this->xml = '<?xml version="1.0" encoding="utf-8"?>
						<getHostedProfilePageRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">
						  <merchantAuthentication>
							<name>'.$this->login.'</name>
							<transactionKey>' . $this->transkey . '</transactionKey>
						  </merchantAuthentication>
						  <customerProfileId>'. $this->params['customerProfileId'].'</customerProfileId>
						  <hostedProfileSettings>
							<setting>
								<settingName>hostedProfilePageBorderVisible</settingName>
								<settingValue>false</settingValue>
							</setting>							
							<setting>
								<settingName>hostedProfileReturnUrl</settingName>
								<settingValue>'.HTTPS_SERVER . DIR_WS_CATALOG.'/'.DIR_WS_TEMPLATE.'/contentx/return.html</settingValue>
							</setting>
							<setting>
								<settingName>hostedProfileIFrameCommunicatorUrl</settingName>
								<settingValue>'.HTTPS_SERVER . DIR_WS_CATALOG.'/'.DIR_WS_TEMPLATE.'/contentx/IframeCommunicator2.html</settingValue>
							</setting>
						 </hostedProfileSettings>
						</getHostedProfilePageRequest>';
        $this->process();
	}
	public function getProfilePageRequest()
    {		
		$this->xml = '<?xml version="1.0" encoding="utf-8"?>
						<getHostedProfilePageRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">
						  <merchantAuthentication>
							<name>'.$this->login.'</name>
							<transactionKey>' . $this->transkey . '</transactionKey>
						  </merchantAuthentication>
						  <customerProfileId>'. $this->params['customerProfileId'].'</customerProfileId>
						  <hostedProfileSettings>
							<setting>
								<settingName>hostedProfilePageBorderVisible</settingName>
								<settingValue>false</settingValue>
							</setting>
							<setting>
								<settingName>hostedProfileReturnUrl</settingName>
								<settingValue>'.HTTPS_SERVER . DIR_WS_CATALOG.'/'.DIR_WS_TEMPLATE.'/contentx/return.html</settingValue>
							</setting>
							<setting>
								<settingName>hostedProfileIFrameCommunicatorUrl</settingName>
								<settingValue>'.HTTPS_SERVER . DIR_WS_CATALOG.'/'.DIR_WS_TEMPLATE.'/contentx/IframeCommunicator.html</settingValue>
							</setting>
						 </hostedProfileSettings>
						</getHostedProfilePageRequest>';
        $this->process();
	}
	
	
	public function getAnAcceptPaymentPage()
    {		
		$this->xml = '<?xml version="1.0" encoding="utf-8"?>
						<getHostedPaymentPageRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">
  <merchantAuthentication>
							<name>'.$this->login.'</name>
							<transactionKey>' . $this->transkey . '</transactionKey>
						  </merchantAuthentication>
						  <customerProfileId>'. $this->params['customerProfileId'].'</customerProfileId>
						  <hostedPaymentSettings>
							<setting>
							  <settingName>hostedPaymentPaymentOptions</settingName>
							  <settingValue>{"showBankAccount": flase}</settingValue>
							</setting>
						  </hostedPaymentSettings>
</getHostedPaymentPageRequest>';
        $this->process();
	}
	
	public function getCustomerPaymentProfileListRequest()
    {		
		$this->xml = '<?xml version="1.0" encoding="utf-8"?>
							<getCustomerPaymentProfileListRequest xmlns="AnetApi/xml/v1/schema/AnetApiSchema.xsd">
							  <merchantAuthentication>
								<name>'.$this->login.'</name>
							    <transactionKey>' . $this->transkey . '</transactionKey>
							  </merchantAuthentication>
							  <searchType>cardsExpiringInMonth</searchType>
							  <month>'.$this->cardmonth.'</month>
							  <sorting>
								<orderBy>id</orderBy>
								<orderDescending>false</orderDescending>
							  </sorting>
							  <paging>
								<limit>1000</limit>
								<offset>1</offset>
							  </paging>
						</getCustomerPaymentProfileListRequest>';
        $this->process();
	}

  function getRealIpAddr()
  {
      if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
      {
        $ip=$_SERVER['HTTP_CLIENT_IP'];
      }
      elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
      {
        $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
      }
      else
      {
        $ip=$_SERVER['REMOTE_ADDR'];
      }
      return $ip;
  }
  
	// This function is used to create a payment transaction from an existing customer profile
	function createCustomerProfileTransactionRequest() {
		global $db;
    $ip = $this->getRealIpAddr();
		$this->xml = "<?xml version='1.0' encoding='utf-8'?>
		<createCustomerProfileTransactionRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
		<merchantAuthentication>
			<name>" . $this->login . "</name>
			<transactionKey>" . $this->transkey . "</transactionKey>
		</merchantAuthentication>
		" . $this->refId() . "
		<transaction>
			<profileTransAuthOnly>
				" . $this->transaction_amount() . "
				" . $this->transactionTax() . "
				" . $this->transactionShipping() . "
				" . $this->transactionDuty() . "
				" . $this->transactionLineItems() . "
				" . $this->customerProfileId() . "
				" . $this->customerPaymentProfileId() . "
				" . $this->customerShippingAddressId() . "
				" . $this->transactionOrder() . "
				" . $this->transactionTaxExempt() . "
				" . $this->transactionRecurringBilling() . "
				" . $this->transactionCardCode() . "
				" . $this->transactionApprovalCode() . "
			</profileTransAuthOnly>
		</transaction>
		 <extraOptions>
      <![CDATA[x_customer_ip=".$ip."&x_duplicate_window=0]]>
		  </extraOptions>
		</createCustomerProfileTransactionRequest>";
		$this->process();
	}
	// This function is used to create a payment transaction from an existing customer profile
	function createCustomerProfileTransactionRequest2() {
		global $db;
     $ip = $this->getRealIpAddr();
		$this->xml = "<?xml version='1.0' encoding='utf-8'?>
		<createCustomerProfileTransactionRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
		<merchantAuthentication>
			<name>" . $this->login . "</name>
			<transactionKey>" . $this->transkey . "</transactionKey>
		</merchantAuthentication>
		" . $this->refId() . "
		<transaction>
			<" . $this->transactionType() . ">
				" . $this->transactionOrder() . "
			</" . $this->transactionType() . ">
		</transaction>
		 <extraOptions>
			 <![CDATA[x_customer_ip=".$ip."&x_duplicate_window=0]]>
		  </extraOptions>
		</createCustomerProfileTransactionRequest>";		
		$this->process();
	}
	// This function is used to delete an existing customer profile along 
	// with all associated customer payment profiles and customer shipping addresses.
	function deleteCustomerProfileRequest() {
    global $db;
	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<deleteCustomerProfileRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->refId() . "
	" . $this->customerProfileId() . "
	</deleteCustomerProfileRequest>";
	$this->process();
	}
	
	// This function is used to delete a customer payment profile from an existing customer profile.
	function deleteCustomerPaymentProfileRequest() {
    global $db;
	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<deleteCustomerPaymentProfileRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->refId() . "
	" . $this->customerProfileId() . "
	" . $this->customerPaymentProfileId() . "
	</deleteCustomerPaymentProfileRequest>";
	$this->process();
	}
	
	// This function is used to delete a customer shipping address from an existing customer profile.
	function deleteCustomerShippingAddressRequest() {
    global $db;
	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<deleteCustomerShippingAddressRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->refId() . "
	" . $this->customerProfileId() . "
	" . $this->customerAddressId() . "
	</deleteCustomerShippingAddressRequest>";
	$this->process();
	}
	
	// This function is used to retrieve an existing customer profile along 
	// with all the associated customer payment profiles and customer shipping addresses.
	function getCustomerProfileRequest() {
    global $db;
	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<getCustomerProfileRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->customerProfileId() . "
	</getCustomerProfileRequest>";
	$this->process();
	}
	
	// This function is used to retrieve a customer payment profile for an existing customer profile.
	function getCustomerPaymentProfileRequest() {
    global $db;
	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<getCustomerPaymentProfileRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->customerProfileId() . "
	" . $this->customerPaymentProfileId() . "
	<unmaskExpirationDate>true</unmaskExpirationDate>
	</getCustomerPaymentProfileRequest>";
	$this->process();
	}
	
	// This function is used to retrieve a customer shipping address for an existing customer profile.
	function getCustomerShippingAddressRequest() {
    global $db;
	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<getCustomerShippingAddressRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->customerProfileId() . "
	" . $this->customerAddressId() . "
	</getCustomerShippingAddressRequest>";
	$this->process();
	}
	
	// This function is used to update an existing customer profile.
	function updateCustomerProfileRequest() {
    global $db;
        	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<updateCustomerProfileRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->refId() . "
	<profile>
		" . $this->merchantCustomerId() . "
		" . $this->description() . "
		" . $this->email() . "
		" . $this->customerProfileId() . "
	</profile>
	</updateCustomerProfileRequest>";
	$this->process();
	}
	
	// This function is used to update a customer payment profile for an existing customer profile.
	function updateCustomerPaymentProfileRequest() {
    global $db;
	$this->update = false; // keep this false for now
	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<updateCustomerPaymentProfileRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->refId() . "
	" . $this->customerProfileId() . "
	<paymentProfile>
		" . $this->customerType() . "
		<billTo>
			" . $this->billTo_firstName() . "
			" . $this->billTo_lastName() . "
			" . $this->billTo_company() . "
			" . $this->billTo_address() . "
			" . $this->billTo_city() . "
			" . $this->billTo_state() . "
			" . $this->billTo_zip() . "
			" . $this->billTo_country() . "
			" . $this->billTo_phoneNumber() . "
			" . $this->billTo_faxNumber() . "
		</billTo>
		<payment>
			" . $this->paymentType() . "
		</payment>
	" . $this->customerPaymentProfileId() . "	
	</paymentProfile>
	</updateCustomerPaymentProfileRequest>";
	$this->process();
	}
	
	// This function is used to update a shipping address for an existing customer profile.
	function updateCustomerShippingAddressRequest() {
    global $db;
	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<updateCustomerShippingAddressRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->refId() . "
	" . $this->customerProfileId() . "
	<address>
		" . $this->shipTo_firstName() . "
		" . $this->shipTo_lastName() . "
		" . $this->shipTo_company() . "
		" . $this->shipTo_address() . "
		" . $this->shipTo_city() . "
		" . $this->shipTo_state() . "
		" . $this->shipTo_zip() . "
		" . $this->shipTo_country() . "
		" . $this->shipTo_phoneNumber() . "
		" . $this->shipTo_faxNumber() . "
		" . $this->customerAddressId() . "
	</address>
	</updateCustomerShippingAddressRequest>";
	$this->process();
	}
	
	// This function is used to verify an existing customer payment profile by generating a test transaction.
	function validateCustomerPaymentProfileRequest() {
    global $db;
	$this->xml = "<?xml version='1.0' encoding='utf-8'?>
	<validateCustomerPaymentProfileRequest xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'>
	<merchantAuthentication>
		<name>" . $this->login . "</name>
		<transactionKey>" . $this->transkey . "</transactionKey>
	</merchantAuthentication>
	" . $this->customerProfileId() . "
	" . $this->customerPaymentProfileId() . "
	" . $this->customerShippingAddressId() . "
	" . $this->validationMode() . "
	</validateCustomerPaymentProfileRequest>";
	$this->process();
	}
	
	function cardData()
	{
		/* v. 0.7 card update */
		$this->cardNumber = $this->substring_between($this->response,'<cardNumber>','</cardNumber>');
		$this->expirationDate = $this->substring_between($this->response,'<expirationDate>','</expirationDate>');
		$this->state = $this->substring_between($this->response,'<state>','</state>');
		$this->city = $this->substring_between($this->response,'<city>','</city>');
		$this->firstName = $this->substring_between($this->response,'<firstName>','</firstName>');
		$this->lastName = $this->substring_between($this->response,'<lastName>','</lastName>');
		$this->address = $this->substring_between($this->response,'<address>','</address>');
		$this->zip = $this->substring_between($this->response,'<zip>','</zip>');
		$this->country = $this->substring_between($this->response,'<country>','</country>');
	}
	
	function parseResults()
	{  
		$this->resultCode = $this->substring_between($this->response,'<resultCode>','</resultCode>');
		$this->token = $this->substring_between($this->response,'<token>','</token>');
		$this->cardNumber = $this->substring_between($this->response,'<cardNumber>','</cardNumber>');
		$this->expirationDate = $this->substring_between($this->response,'<expirationDate>','</expirationDate>');
		$this->cim_code = $this->substring_between($this->response,'<code>','</code>');
		$this->text = $this->substring_between($this->response,'<text>','</text>');
		$this->refId = $this->substring_between($this->response,'<refId>','</refId>');
		$this->customerProfileId = $this->substring_between($this->response,'<customerProfileId>','</customerProfileId>');
		$this->customerPaymentProfileId = $this->substring_between($this->response,'<customerPaymentProfileId>','</customerPaymentProfileId>');
		$this->customerAddressId = $this->substring_between($this->response,'<customerAddressId>','</customerAddressId>');
		$this->directResponse = $this->substring_between($this->response,'<directResponse>','</directResponse>');		
		$this->validationDirectResponse = $this->substring_between($this->response,'<validationDirectResponse>','</validationDirectResponse>');      
		if (!empty($this->directResponse))
		{
			$array = explode($this->responseDelimiter, $this->directResponse);
			$this->directResponse = $array[3];
			$this->approvalCode = $array[4];
			$this->transID = $array[6];
		}		
		if (!empty($this->validationDirectResponse))
		{
			$array = explode($this->responseDelimiter, $this->validationDirectResponse);
			$this->validationDirectResponse = $array[3];
		}
		
	}
	public function getProfilePageRequestToken()
    {
		return $this->token;
	}
	function substring_between($haystack,$start,$end)
	{
		if (strpos($haystack,$start) === false || strpos($haystack,$end) === false)
		{
			return false;
		}
		else
		{
			$start_position = strpos($haystack,$start)+strlen($start);
			$end_position = strpos($haystack,$end);
			return substr($haystack,$start_position,$end_position-$start_position);
		}
	}
  
	function setParameter($field = "", $value = NULL)
	{
		$this->params[$field] = $value;
	}
	
	function isSuccessful() 
	{
		return $this->success;
	}
	
	// This function will output the proper xml for a paymentType: (echeck or creditcard)
	// The elements within "bankAccount" is still incorrect in the manual. I fixed it here.
	function paymentType()
	{
		if (isset($this->params['paymentType']))
		{
			if (($this->params['paymentType'] == "echeck") 
			|| ($this->params['paymentType'] == "bankAccount"))
			{
				return "
				<bankAccount>
					" . $this->accountType() . "
					" . $this->routingNumber() . "
					" . $this->accountNumber() . "
					" . $this->nameOnAccount() . "
					" . $this->echeckType() . "
					" . $this->bankName() . "
				</bankAccount>";
			}
			elseif (($this->params['paymentType'] == "creditcard")
			|| ($this->params['paymentType'] == "creditCard"))
			{
				return "
				<creditCard>
					" . $this->cardNumber() . "
					" . $this->expirationDate() . "
				</creditCard>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): paymentType is required and must be (bankAccount or creditCard)';
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): paymentType is required and must be (bankAccount or creditCard)';
		}
	}
	
	// Merchant-assigned reference ID for the request (optional)
	function refId()
	{
		if (isset($this->params['refId']))
		{
			if ((strlen($this->params['refId']) > 0) 
			&& (strlen($this->params['refId']) <= 20))
			{
				return "<refId>" . $this->params['refId'] . "</refId>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): refId must be up to 20 characters';
			}
		}
	}
	
	// Contains tax information for the transaction (optional)
	function transactionTax()
	{
		if ((isset($this->params['tax_amount'])) 
		|| (isset($this->params['tax_name'])) 
		|| (isset($this->params['tax_description'])))
		{
			return "
			<tax>
				" . $this->tax_amount() . "
				" . $this->tax_name() . "
				" . $this->tax_description() . "
			</tax>";
		}
	}
	
	// The tax amount for the transaction (optional)
	// This amount must be included in the total amount for the transaction. Ex. 12.99 or 12.9999
	function tax_amount()
	{
		if (isset($this->params['tax_amount']))
		{
			if (preg_match('/(^[0-9]+\.[0-9]{1,4}$)/', $this->params['tax_amount']))
			{
				return "<amount>" . $this->params['tax_amount'] . "</amount>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): tax_amount must be up to 4 digits with a decimal point (no dollar symbol)';
			}
		}
	}
	
	// The name of the tax for the transaction (optional)
	function tax_name()
	{
		if (isset($this->params['tax_name']))
		{
			if ((strlen($this->params['tax_name']) > 0) 
			&& (strlen($this->params['tax_name']) <= 31))
			{
				return "<name>" . $this->params['tax_name'] . "</name>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): tax_name must be up to 31 characters';
			}
		}
	}
	
	// The tax description for the transaction (optional)
	function tax_description()
	{
		if (isset($this->params['tax_description']))
		{
			if ((strlen($this->params['tax_description']) > 0) 
			&& (strlen($this->params['tax_description']) <= 255))
			{
				return "<description>" . $this->params['tax_description'] . "</description>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): tax_description must be up to 255 characters';
			}
		}
	}
	
	// Contains tax information for the transaction (optional)
	function transactionShipping()
	{
		if ((isset($this->params['shipping_amount'])) 
		|| (isset($this->params['shipping_name'])) 
		|| (isset($this->params['shipping_description'])))
		{
			return "
			<shipping>
				" . $this->shipping_amount() . "
				" . $this->shipping_name() . "
				" . $this->shipping_description() . "
			</shipping>";
		}
	}
	
	// The shipping amount for the transaction (optional)
	// This amount must be included in the total amount for the transaction. Ex. 12.99 or 12.9999
	function shipping_amount()
	{
		if (isset($this->params['shipping_amount']))
		{
			if (preg_match('/(^[0-9]+\.[0-9]{1,4}$)/', $this->params['shipping_amount']))
			{
				return "<amount>" . $this->params['shipping_amount'] . "</amount>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipping_amount must be up to 4 digits with a decimal point. (no dollar symbol)';
			}
		}
	}
	
	// The name of the shipping for the transaction (optional)
	function shipping_name()
	{
		if (isset($this->params['shipping_name']))
		{
			if ((strlen($this->params['shipping_name']) > 0) 
			&& (strlen($this->params['shipping_name']) <= 31))
			{
				return "<name>" . $this->params['shipping_name'] . "</name>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipping_name must be up to 31 characters';
			}
		}
	}
	
	// The shipping description for the transaction (optional)
	function shipping_description()
	{
		if (isset($this->params['shipping_description']))
		{
			if ((strlen($this->params['shipping_description']) > 0) 
			&& (strlen($this->params['shipping_description']) <= 255))
			{
				return "<description>" . $this->params['shipping_description'] . "</description>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipping_description must be up to 255 characters';
			}
		}
	}
	
	// Contains duty information for the transaction (optional)
	function transactionDuty()
	{
		if ((isset($this->params['duty_amount'])) 
		|| (isset($this->params['duty_name'])) 
		|| (isset($this->params['duty_description'])))
		{
			return "
			<duty>
				" . $this->duty_amount() . "
				" . $this->duty_name() . "
				" . $this->duty_description() . "
			</duty>";
		}
	}
	
	// The duty amount for the transaction (optional)
	// This amount must be included in the total amount for the transaction. Ex. 12.99 or 12.9999
	function duty_amount()
	{
		if (isset($this->params['duty_amount']))
		{
			if (preg_match('/(^[0-9]+\.[0-9]{1,4}$)/', $this->params['duty_amount']))
			{
				return "<amount>" . $this->params['duty_amount'] . "</amount>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): duty_amount must be up to 4 digits with a decimal point. (no dollar symbol)';
			}
		}
	}
	
	// The name of the duty for the transaction (optional)
	function duty_name()
	{
		if (isset($this->params['duty_name']))
		{
			if ((strlen($this->params['duty_name']) > 0) 
			&& (strlen($this->params['duty_name']) <= 31))
			{
				return "<name>" . $this->params['duty_name'] . "</name>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): duty_name must be up to 31 characters';
			}
		}
	}
	
	// The duty description for the transaction (optional)
	function duty_description()
	{
		if (isset($this->params['duty_description']))
		{
			if ((strlen($this->params['duty_description']) > 0) 
			&& (strlen($this->params['duty_description']) <= 255))
			{
				return "<description>" . $this->params['duty_description'] . "</description>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): duty_description must be up to 255 characters';
			}
		}
	}
	
	// Contains line item details about the order (optional)
	// Up to 30 distinct instances of this element may be included per transaction to describe items included in the order.
	// USAGE: see the example code for createCustomerProfileTransactionRequest() in the examples provided.
	function transactionLineItems()
	{
		if (count($this->LineItems) > 30)
		{
			$this->error_messages[] .= '$object->LineItems: (multidimensional array) Up to 30 distinct instances of this element may be included';
		}
		else
		{
			if (count($this->LineItems) > 0)
			{
				$xmlcode = '';
				foreach($this->LineItems as $items)
				{
					$xmlcode .= "<lineItems>\n";
					foreach ($items as $key=>$value)
					{
						$xmlcode .= "<$key>$value</$key>\n";
					}
					$xmlcode .= "</lineItems>\n";
				}
				return $xmlcode;
			}
		}
	}
	
	// Contains duty information for the transaction (optional)
	function transactionOrder()
	{
		if ((isset($this->params['order_invoiceNumber'])) 
		|| (isset($this->params['order_description'])) 
		|| (isset($this->params['order_purchaseOrderNumber'])))
		{
			return "
			<order>
				" . $this->order_invoiceNumber() . "
				" . $this->order_description() . "
				" . $this->order_purchaseOrderNumber() . "
			</order>";
		}
	}
	
	// The merchant assigned invoice number for the transaction (optional)
	function order_invoiceNumber()
	{
		if (isset($this->params['order_invoiceNumber'])) 
		{
			if ((strlen($this->params['order_invoiceNumber']) > 0) 
			&& (strlen($this->params['order_invoiceNumber']) <= 20))
			{
				return "<invoiceNumber>" . $this->params['order_invoiceNumber'] . "</invoiceNumber>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): order_invoiceNumber must be up to 20 characters (no symbols)';
			}
		}
	}
	
	// The transaction description (optional)
	function order_description()
	{
		if (isset($this->params['order_description'])) 
		{
			if ((strlen($this->params['order_description']) > 0) 
			&& (strlen($this->params['order_description']) <= 255))
			{
				return "<description>" . $this->params['order_description'] . "</description>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): order_description must be up to 255 characters (no symbols)';
			}
		}
	}
	
	// The merchant assigned purchase order number (optional)
	function order_purchaseOrderNumber()
	{
		if (isset($this->params['order_purchaseOrderNumber'])) 
		{
			if ((strlen($this->params['order_purchaseOrderNumber']) > 0) 
			&& (strlen($this->params['order_purchaseOrderNumber']) <= 25))
			{
				return "<purchaseOrderNumber>" . $this->params['order_purchaseOrderNumber'] . "</purchaseOrderNumber>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): order_purchaseOrderNumber must be up to 25 characters (no symbols)';
			}
		}
	}
	
	/************************* Billing Functions *************************/
	
	// The customer's first name (optional)
	function billTo_firstName()
	{
		if (isset($this->params['billTo_firstName']))
		{
			if ($this->update === true)
			{
				return "<firstName>" . $this->params['billTo_firstName'] . "</firstName>";
			}
			else
			{
				if ((strlen($this->params['billTo_firstName']) > 0) && (strlen($this->params['billTo_firstName']) <= 50))
				{
					return "<firstName>" . $this->params['billTo_firstName'] . "</firstName>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): billTo_firstName must be up to 50 characters (no symbols)';
				}
			}
		}
	}
	
	// The customer's last name (optional)
	function billTo_lastName()
	{
		
		if (isset($this->params['billTo_lastName']))
		{
			if ($this->update === true)
			{
				return "<lastName>" . $this->params['billTo_lastName'] . "</lastName>";
			}
			else
			{
				if ((strlen($this->params['billTo_lastName']) > 0) && (strlen($this->params['billTo_lastName']) <= 50))
				{
					return "<lastName>" . $this->params['billTo_lastName'] . "</lastName>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): billTo_lastName must be up to 50 characters (no symbols)';
				}
			}
		}
	}
	
	// The name of the company associated with the customer, if applicable (optional)
	function billTo_company()
	{
		if (isset($this->params['billTo_company']))
		{
			if ($this->update === true)
			{
				return "<company>" . $this->params['billTo_company'] . "</company>";
			}
			else
			{
				if ((strlen($this->params['billTo_company']) > 0) && (strlen($this->params['billTo_company']) <= 50))
				{
					return "<company>" . $this->params['billTo_company'] . "</company>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): billTo_company must be up to 50 characters (no symbols)';
				}
			}
		}
	}
	
	// The customer's address (optional)
	function billTo_address()
	{
		if (isset($this->params['billTo_address']))
		{
			if ($this->update === true)
			{
				return "<address>" . $this->params['billTo_address'] . "</address>";
			}
			else
			{
				if ((strlen($this->params['billTo_address']) > 0) && (strlen($this->params['billTo_address']) <= 60))
				{
					return "<address>" . $this->params['billTo_address'] . "</address>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): billTo_address must be up to 60 characters (no symbols)';
				}
			}
		}
	}
	
	// The city of the customer's address (optional)
	function billTo_city()
	{
		if (isset($this->params['billTo_city']))
		{
			if ($this->update === true)
			{
				return "<city>" . $this->params['billTo_city'] . "</city>";
			}
			else
			{
				if ((strlen($this->params['billTo_city']) > 0) && (strlen($this->params['billTo_city']) <= 40))
				{
					return "<city>" . $this->params['billTo_city'] . "</city>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): billTo_city must be up to 40 characters (no symbols)';
				}
			}
		}
	}
	
	// The state of the customer's address (optional)
	// http://www.usps.com/ncsc/lookups/usps_abbreviations.html#states
	function billTo_state()
	{
		if (isset($this->params['billTo_state']))
		{
			if ($this->update === true)
			{
				return "<state>" . $this->params['billTo_state'] . "</state>";
			}
			else
			{
				if (preg_match('/^[a-z]{2}$/i', $this->params['billTo_state']))
				{
					return "<state>" . $this->params['billTo_state'] . "</state>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): billTo_state must be a valid two-character state code';
				}
			}
		}
	}
	
	// The ZIP code of the customer's address (optional)
	function billTo_zip()
	{
		if (isset($this->params['billTo_zip']))
		{
			if ($this->update === true)
			{
				return "<zip>" . $this->params['billTo_zip'] . "</zip>";
			}
			else
			{
				if ((strlen($this->params['billTo_zip']) > 0) && (strlen($this->params['billTo_zip']) <= 20))
				{
					return "<zip>" . $this->params['billTo_zip'] . "</zip>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): billTo_zip must be up to 20 characters (no symbols)';
				}
			}
		}
	}
	
	// This element is optional
	function billTo_country()
	{
		if (isset($this->params['billTo_country']))
		{
			if ($this->update === true)
			{
				return "<country>" . $this->params['billTo_country'] . "</country>";
			}
			else
			{
				if ((strlen($this->params['billTo_country']) > 0) && (strlen($this->params['billTo_country']) <= 60))
				{
					return "<country>" . $this->params['billTo_country'] . "</country>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): billTo_country must be up to 60 characters (no symbols)';
				}
			}
		}
	}
	
	// The phone number associated with the customer's address (optional)
	function billTo_phoneNumber()
	{
		if (isset($this->params['billTo_phoneNumber']))
		{
			if ($this->update === true)
			{
				return "<phoneNumber>" . $this->params['billTo_phoneNumber'] . "</phoneNumber>";
			}
			else
			{
				if ((strlen($this->params['billTo_phoneNumber']) > 0) && (strlen($this->params['billTo_phoneNumber']) <= 25))
				{
					return "<phoneNumber>" . $this->params['billTo_phoneNumber'] . "</phoneNumber>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): billTo_phoneNumber must be up to 25 digits (no letters). Ex. (123)123-1234';
				}
			}
		}
	}
	
	// This element is optional
	function billTo_faxNumber()
	{
		if (isset($this->params['billTo_faxNumber']))
		{
			if ($this->update === true)
			{
				return "<faxNumber>" . $this->params['billTo_faxNumber'] . "</faxNumber>";
			}
			else
			{
				if ((strlen($this->params['billTo_faxNumber']) > 0) && (strlen($this->params['billTo_faxNumber']) <= 25))
				{
					return "<faxNumber>" . $this->params['billTo_faxNumber'] . "</faxNumber>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): billTo_faxNumber must be up to 25 digits (no letters). Ex. (123)123-1234';
				}
			}
		}
	}
	
	/************************* Shipping Functions *************************/
	
	// The customer's first name (optional)
	function shipTo_firstName()
	{
		if (isset($this->params['shipTo_firstName']))
		{
			if ((strlen($this->params['shipTo_firstName']) > 0) && (strlen($this->params['shipTo_firstName']) <= 50))
			{
				return "<firstName>" . $this->params['shipTo_firstName'] . "</firstName>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipTo_firstName must be up to 50 characters (no symbols)';
			}
		}
	}
	
	// The customer's last name (optional)
	function shipTo_lastName()
	{
		if (isset($this->params['shipTo_lastName']))
		{
			if ((strlen($this->params['shipTo_lastName']) > 0) && (strlen($this->params['shipTo_lastName']) <= 50))
			{
				return "<lastName>" . $this->params['shipTo_lastName'] . "</lastName>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipTo_lastName must be up to 50 characters (no symbols)';
			}
		}
	}
	
	// The name of the company associated with the customer, if applicable (optional)
	function shipTo_company()
	{
		if (isset($this->params['shipTo_company']))
		{
			if ((strlen($this->params['shipTo_company']) > 0) && (strlen($this->params['shipTo_company']) <= 50))
			{
				return "<company>" . $this->params['shipTo_company'] . "</company>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipTo_company must be up to 50 characters (no symbols)';
			}
		}
	}
	
	// The customer's address (optional)
	function shipTo_address()
	{
		if (isset($this->params['shipTo_address']))
		{
			if ((strlen($this->params['shipTo_address']) > 0) && (strlen($this->params['shipTo_address']) <= 60))
			{
				return "<address>" . $this->params['shipTo_address'] . "</address>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipTo_address must be up to 60 characters (no symbols)';
			}
		}
	}
	
	// The city of the customer's address (optional)
	function shipTo_city()
	{
		if (isset($this->params['shipTo_city']))
		{
			if ((strlen($this->params['shipTo_city']) > 0) && (strlen($this->params['shipTo_city']) <= 40))
			{
				return "<city>" . $this->params['shipTo_city'] . "</city>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipTo_city must be up to 40 characters (no symbols)';
			}
		}
	}
	
	// The state of the customer's address (optional)
	// http://www.usps.com/ncsc/lookups/usps_abbreviations.html#states
	function shipTo_state()
	{
		if (isset($this->params['shipTo_state']))
		{
			if (preg_match('/^[a-z]{2}$/i', $this->params['shipTo_state']))
			{
				return "<state>" . $this->params['shipTo_state'] . "</state>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipTo_state must be a valid two-character state code';
			}
		}
	}
	
	// The ZIP code of the customer's address (optional)
	function shipTo_zip()
	{
		if (isset($this->params['shipTo_zip']))
		{
			if ((strlen($this->params['shipTo_zip']) > 0) && (strlen($this->params['shipTo_zip']) <= 20))
			{
				return "<zip>" . $this->params['shipTo_zip'] . "</zip>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipTo_zip must be up to 20 characters (no symbols)';
			}
		}
	}
	
	// The country of the customer's address (optional)
	function shipTo_country()
	{
		if (isset($this->params['shipTo_country']))
		{
			if ((strlen($this->params['shipTo_country']) > 0) && (strlen($this->params['shipTo_country']) <= 60))
			{
				return "<country>" . $this->params['shipTo_country'] . "</country>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipTo_country must be up to 60 characters (no symbols)';
			}
		}
	}
	
	// The phone number associated with the customer's address (optional)
	function shipTo_phoneNumber()
	{
		if (isset($this->params['shipTo_phoneNumber']))
		{
			if ((strlen($this->params['shipTo_phoneNumber']) > 0) && (strlen($this->params['shipTo_phoneNumber']) <= 25))
			{
				return "<phoneNumber>" . $this->params['shipTo_phoneNumber'] . "</phoneNumber>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipTo_phoneNumber must be up to 25 digits (no letters). Ex. (123)123-1234';
			}
		}
	}
	
	// The fax number associated with the customer's address (optional)
	function shipTo_faxNumber()
	{
		if (isset($this->params['shipTo_faxNumber']))
		{
			if ((strlen($this->params['shipTo_faxNumber']) > 0) && (strlen($this->params['shipTo_faxNumber']) <= 25))
			{
				return "<faxNumber>" . $this->params['shipTo_faxNumber'] . "</faxNumber>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): shipTo_faxNumber must be up to 25 digits (no letters). Ex. (123)123-1234';
			}
		}
	}
	
	/************************* Other Functions *************************/
	
	// This element is optional
	// Even though the manual states this is optional, it is actually conditional in a circumstance.
	// You must have either the merchantCustomerId and/or description defined for createCustomerProfileRequest()
	function merchantCustomerId()
	{
		if (isset($this->params['merchantCustomerId']))
		{
			if ((strlen($this->params['merchantCustomerId']) > 0) && (strlen($this->params['merchantCustomerId']) <= 20))
			{
				return "<merchantCustomerId>" . $this->params['merchantCustomerId'] . "</merchantCustomerId>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): merchantCustomerId must be up to 20 characters in length';
			}
		}
	}
	
	// This element is optional
	// Even though the manual states this is optional, it is actually conditional in a circumstance.
	// You must have either the description and/or merchantCustomerId defined for createCustomerProfileRequest()
	function description()
	{
		if (isset($this->params['description']))
		{
			if ((strlen($this->params['description']) > 0) && (strlen($this->params['description']) <= 255))
			{
				return "<description>" . $this->params['description'] . "</description>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): description must be up to 255 characters in length';
			}
		}
	}
	
	// This element is optional
	function email()
	{
		if (isset($this->params['email']))
		{
			if ((strlen($this->params['email']) > 0) && (strlen($this->params['email']) <= 255))
			{
				return "<email>" . $this->params['email'] . "</email>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): email must be up to 255 characters in length';
			}
		}
	}
	
	// This element is optional
	function customerType()
	{
		if (isset($this->params['customerType']))
		{
			if (preg_match('/^(individual|business)$/i', $this->params['customerType']))
			{
				return "<customerType>" . strtolower($this->params['customerType']) . "</customerType>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): customerType must be (individual or business)';
			}
		}
	}
	
	// This element is optional
	function accountType()
	{
		if (isset($this->params['accountType']))
		{
			if ($this->update === true)
			{
				return "<accountType>" . $this->params['accountType'] . "</accountType>";
			}
			else
			{
				if (preg_match('/^(checking|savings|businessChecking)$/', $this->params['accountType']))
				{
					return "<accountType>" . $this->params['accountType'] . "</accountType>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): accountType is required and must be (checking, savings or businessChecking)';
				}
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): accountType is required and must be (checking, savings or businessChecking)..';
		}
	}
	
	// This element is optional
	function nameOnAccount()
	{
		if (isset($this->params['nameOnAccount']))
		{
			if ($this->update === true)
			{
				return "<nameOnAccount>" . $this->params['nameOnAccount'] . "</nameOnAccount>";
			}
			else
			{
				if ((strlen($this->params['nameOnAccount']) > 0) && (strlen($this->params['nameOnAccount']) <= 22))
				{
					return "<nameOnAccount>" . $this->params['nameOnAccount'] . "</nameOnAccount>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): nameOnAccount is required and must be up to 22 characters in length';
				}
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): nameOnAccount is required and must be up to 22 characters in length..';
		}
	}
	
	// This element is optional
	function echeckType()
	{
		if (isset($this->params['echeckType']))
		{
			if ($this->update === true)
			{
				return "<echeckType>" . $this->params['echeckType'] . "</echeckType>";
			}
			else
			{
				if (preg_match('/^(CCD|PPD|TEL|WEB)$/', $this->params['echeckType']))
				{
					return "<echeckType>" . $this->params['echeckType'] . "</echeckType>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): echeckType is required and must be (CCD, PPD, TEL or WEB)';
				}
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): echeckType is required and must be (CCD, PPD, TEL or WEB)..';
		}
	}
	
	// This element is optional
	function bankName()
	{
		if (isset($this->params['bankName']))
		{
			if ($this->update === true)
			{
				return "<bankName>" . $this->params['bankName'] . "</bankName>";
			}
			else
			{
				if ((strlen($this->params['bankName']) > 0) && (strlen($this->params['bankName']) <= 60))
				{
					return "<bankName>" . $this->params['bankName'] . "</bankName>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): bankName is required and must be up to 50 characters in length';
				}
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): bankName is required and must be up to 50 characters in length..';
		}
	}
	
	// This element is required in some functions
	function routingNumber()
	{
		if (isset($this->params['routingNumber']))
		{
			if ($this->update === true)
			{
				return "<routingNumber>" . $this->params['routingNumber'] . "</routingNumber>";
			}
			else
			{
				if (preg_match('/^[0-9]{9}$/', $this->params['routingNumber']))
				{
					return "<routingNumber>" . $this->params['routingNumber'] . "</routingNumber>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): routingNumber is required and must be 9 digits';
				}
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): routingNumber is required and must be 9 digits..';
		}
	}
	
	// This element is required in some functions
	function accountNumber()
	{
		if (isset($this->params['accountNumber']))
		{
			if ($this->update === true)
			{
				return "<accountNumber>" . $this->params['accountNumber'] . "</accountNumber>";
			}
			else
			{
				if (preg_match('/^[0-9]{5,17}$/', $this->params['accountNumber']))
				{
					return "<accountNumber>" . $this->params['accountNumber'] . "</accountNumber>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): accountNumber is required and must be 5 to 17 digits';
				}
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): accountNumber is required and must be 5 to 17 digits..';
		}
	}
	
	// This element is required in some functions
	function cardNumber()
	{
		if (isset($this->params['cardNumber']))
		{
			if ($this->update === true)
			{
				return "<cardNumber>" . $this->params['cardNumber'] . "</cardNumber>";
			}
			else
			{
				if (preg_match('/^[0-9]{13,16}$/', $this->params['cardNumber']))
				{
					return "<cardNumber>" . $this->params['cardNumber'] . "</cardNumber>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): cardNumber is required and must be 13 to 16 digits';
				}
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): cardNumber is required and must be 13 to 16 digits..';
		}
	}
	
	// This element is required in some functions
	function expirationDate()
	{
		if (isset($this->params['expirationDate']))
		{
			if ($this->update === true)
			{
				return "<expirationDate>" . $this->params['expirationDate'] . "</expirationDate>";
			}
			else
			{
				if (preg_match('/^([0-9]{4})-([0-9]{2})$/', $this->params['expirationDate']))
				{
					return "<expirationDate>" . $this->params['expirationDate'] . "</expirationDate>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): expirationDate is required and must be YYYY-MM';
				}
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): expirationDate is required and must be YYYY-MM..';
		}
	}
	
	// This element is required in some functions
	// This amount should include all other amounts such as tax amount, shipping amount, etc. Ex. 12.99 or 12.9999
	function transaction_amount()
	{
		//$this->params['transaction_amount'] = 87.0015;
		
	
		if (isset($this->params['transaction_amount']))
		{
			
			if (preg_match('/(^[0-9]+\.[0-9]{1,4}$)/', $this->params['transaction_amount']))
			{
		
				return "<amount>" . $this->params['transaction_amount'] . "</amount>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): transaction_amount is required and must be up to 4 digits with a decimal (no dollar symbol)';
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): transaction_amount is required and must be up to 4 digits with a decimal';
		}
	}
	
	// This element is required in some functions
	function transactionType()
	{
		if (isset($this->params['transactionType']))
		{
			if (preg_match('/^(profileTransCaptureOnly|profileTransAuthCapture|profileTransAuthOnly)$/', $this->params['transactionType']))
			{
				return $this->params['transactionType'];
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): transactionType must be (profileTransCaptureOnly, profileTransAuthCapture or profileTransAuthOnly)';
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): transactionType must be (profileTransCaptureOnly, profileTransAuthCapture or profileTransAuthOnly)';
		}
	}
	
	// This element is required in some functions
	// Payment gateway assigned ID associated with the customer profile
	function customerProfileId()
	{
		if (isset($this->params['customerProfileId']))
		{
			if (preg_match('/^[0-9]+$/', $this->params['customerProfileId']))
			{
				return "<customerProfileId>" . $this->params['customerProfileId'] . "</customerProfileId>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): customerProfileId is required and must be numeric';
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): customerProfileId is required and must be numeric';
		}
	}
	
	// This element is required in some functions
	// Payment gateway assigned ID associated with the customer payment profile
	function customerPaymentProfileId()
	{
		if (isset($this->params['customerPaymentProfileId']))
		{
			if ($this->update === true)
			{
				return "<customerPaymentProfileId>" . $this->params['customerPaymentProfileId'] . "</customerPaymentProfileId>";
			}
			else
			{
				if (preg_match('/^[0-9]+$/', $this->params['customerPaymentProfileId']))
				{
					return "<customerPaymentProfileId>" . $this->params['customerPaymentProfileId'] . "</customerPaymentProfileId>";
				}
				else
				{
					$this->error_messages[] .= 'setParameter(): customerPaymentProfileId is required and must be numeric';
				}
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): customerPaymentProfileId is required and must be numeric..';
		}
	}
	
	// This element is required in some functions, otherwise optional
	// Payment gateway assigned ID associated with the customer shipping address
	// Note: If the customer AddressId is not passed, shipping information will not be included with the transaction.
	function customerAddressId()
	{
		if (isset($this->params['customerAddressId']))
		{
			if (preg_match('/^[0-9]+$/', $this->params['customerAddressId']))
			{
				return "<customerAddressId>" . $this->params['customerAddressId'] . "</customerAddressId>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): customerAddressId is required and must be numeric';
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): customerAddressId is required and must be numeric';
		}
	}
	
	// In validateCustomerPaymentProfileRequest(), customerShippingAddressId() is used in place of customerAddressId().
	// The Authorize.net manual is still incorrect on this.
	// Payment gateway assigned ID associated with the customer shipping address
	// Note: If the customer Shipping AddressId is not passed, shipping information will not be included with the transaction.
	function customerShippingAddressId()
	{
		if (isset($this->params['customerShippingAddressId']))
		{
			if (preg_match('/^[0-9]+$/', $this->params['customerShippingAddressId']))
			{
				return "<customerShippingAddressId>" . $this->params['customerShippingAddressId'] . "</customerShippingAddressId>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): customerShippingAddressId is required and must be numeric';
			}
		}
	}
	
	// This element is optional
	function transactionTaxExempt()
	{
		if (isset($this->params['transactionTaxExempt']))
		{
			if (preg_match('/^(true|false)$/i', $this->params['transactionTaxExempt']))
			{
				return "<taxExempt>" . $this->params['transactionTaxExempt'] . "</taxExempt>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): transactionTaxExempt is required and must be (true or false)';
			}
		}
	}
	
	// This element is optional
	function transactionRecurringBilling()
	{
		if (isset($this->params['transactionRecurringBilling']))
		{
			if (preg_match('/^(true|false)$/i', $this->params['transactionRecurringBilling']))
			{
				return "<recurringBilling>" . $this->params['transactionRecurringBilling'] . "</recurringBilling>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): transactionRecurringBilling must be (true or false)';
			}
		}
	}
	
	// The customer's card code (the three or four-digit number on the back or front of a credit card)
	// Required only when the merchant would like to use the Card Code Verification (CCV) filter (conditional)
	// For more information, please see the Merchant Integration Guide.
	function transactionCardCode()
	{
		if (isset($this->params['transactionCardCode']))
		{
			if (preg_match('/^[0-9]{3,4}$/', $this->params['transactionCardCode']))
			{
				return "<cardCode>" . $this->params['transactionCardCode'] . "</cardCode>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): transactionCardCode must be 3 to 4 digits';
			}
		}
	}
	
	// The authorization code of an original transaction required for a Capture Only (conditional)
	// This element is only required for the Capture Only transaction type.
	function transactionApprovalCode()
	{
		if (isset($this->params['transactionApprovalCode'])) 
		{
			if (($this->transactionType() == "profileTransCaptureOnly") 
			&& (strlen($this->params['transactionApprovalCode']) == 6))
			{
				return "<approvalCode>" . $this->params['transactionApprovalCode'] . "</approvalCode>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): transactionApprovalCode must be 6 characters and transactionType value must be (profileTransCaptureOnly)';
			}
		}
	}
	// This element is required in some functions
	function validationMode()
	{
		if (isset($this->params['validationMode']))
		{
			if (preg_match('/^(none|testMode|liveMode)$/', $this->params['validationMode']))
			{
				return "<validationMode>" . $this->params['validationMode'] . "</validationMode>";
			}
			else
			{
				$this->error_messages[] .= 'setParameter(): validationMode must be (none, testMode or liveMode)';
			}
		}
		else
		{
			$this->error_messages[] .= 'setParameter(): validationMode is required';
		}
	}

// cim

}
?>
