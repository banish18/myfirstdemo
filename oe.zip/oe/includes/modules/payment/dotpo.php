<?php
/**
 * COD Payment Module
 *
 * @package paymentMethod
 * @copyright Copyright 2003-2010 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: DrByte  Tue Jan 22 03:36:04 2013 -0500 Modified in v1.5.2 $
 */
  class dotpo {
    var $code, $title, $description, $enabled;

// class constructor
    function dotpo() {
      global $order;

      $this->code = 'dotpo';
      $this->title = MODULE_PAYMENT_DOTPO_TEXT_TITLE;
      $this->description = MODULE_PAYMENT_DOTPO_TEXT_DESCRIPTION;
      $this->sort_order = MODULE_PAYMENT_DOTPO_SORT_ORDER;
      $this->enabled = ((MODULE_PAYMENT_DOTPO_STATUS == 'True') ? true : false);

      if ((int)MODULE_PAYMENT_DOTPO_ORDER_STATUS_ID > 0) {
        $this->order_status = MODULE_PAYMENT_DOTPO_ORDER_STATUS_ID;
      }
	   $this->order_status = MODULE_PAYMENT_DOTPO_ORDER_STATUS_ID;

      if (is_object($order)) $this->update_status();
    }

// class methods
    function update_status() {
      global $order, $db;

      if ($this->enabled && (int)MODULE_PAYMENT_DOTPO_ZONE > 0 && isset($order->billing['country']['id'])) {
        $check_flag = false;
        $check = $db->Execute("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_DOTPO_ZONE . "' and zone_country_id = '" . $order->delivery['country']['id'] . "' order by zone_id");
        while (!$check->EOF) {
          if ($check->fields['zone_id'] < 1) {
            $check_flag = true;
            break;
          } elseif ($check->fields['zone_id'] == $order->delivery['zone_id']) {
            $check_flag = true;
            break;
          }
          $check->MoveNext();
        }

        if ($check_flag == false) {
          $this->enabled = false;
        }
      }

// disable the module if the order only contains virtual products
      if ($this->enabled == true) {
        if ($order->content_type != 'physical') {
          $this->enabled = false;
        }
      }
    }

    function javascript_validation() {
		$js = '  if (payment_value == "' . $this->code . '") {' . "\n" .
		'    var po_number = document.checkout_payment.dotpo_po_number.value;' . "\n" .		
		'    var term_condition = document.checkout_payment.dotpo_po_term_condition.checked;' . "\n";
		$js .= '   if(po_number==""){'."\n".
		'		error_message = error_message+"'.MODULE_PAYMENT_DOTPO_PO_NUMBER_TEXT_JS_CC_SC.'";'."\n".
		'		error =1;'."\n".
		'		}'."\n";
		$js .= '   if(!term_condition){'."\n".
		'		error_message = error_message+"'.MODULE_PAYMENT_DOTPO_PO_TERM_TEXT_JS_CC_SC.'";'."\n".
		'		error =1;'."\n".
		'		}'."\n";
        $js .= '  }' . "\n";

    return $js;
    }

    function selection() {
		global $db;
		$_fields = array();
		$term_page = $db->Execute("Select * from ".TABLE_EZPAGES." where pages_id=15");				
		$term_content = '<div class="po-term-btn-inf check_hover" data-toggle="modal" data-target="#po_term" style="cursor: pointer;">'.MODULE_PAYMENT_DOTPO_TERM_CONDITION_TEXT.'</div>
			<div class="modal fade" id="po_term"  tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="vertical-alignment-helper">
					<div class="modal-dialog vertical-align-center">

				<div class="modal-content" >
				 <div class="modal-header">
				 <h4 class="modal-title">Standard Terms and Conditions of Sale</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>					
				  </div>
				  <div class="modal-body term-popup-content">       
     
					'.$term_page->fields['pages_html_text'].'
					</div>				
				</div>    
			  </div>
			  </div>
			</div>';

		$onFocus = ' onfocus="methodSelect(\'pmt-' . $this->code . '\')"';
		$_fields[] = array('title' => MODULE_PAYMENT_DOTPO_NUMER_TEXT,
                       'field' => zen_draw_input_field('dotpo_po_number', "", 'id="'.$this->code.'-po-number"'. $onFocus . 'placeholder="Enter PO/Reference Number"'),
                       'tag' => $this->code.'-po-number');
		$_fields[] = array('title' => "",
                       'field' => zen_draw_checkbox_field('dotpo_po_term_condition',1,false, 'id="'.$this->code.'-term-condition"'. $onFocus).$term_content,
                       'tag' => $this->code.'-term-condition');
        return array('id' => $this->code,
                   'module' => $this->title,
                   'fields' => $_fields);
    }

    function pre_confirmation_check() {
      return false;
    }

    function confirmation() {
      return false;
    }

    function process_button() {
		global $db;    
		$process_button_string = zen_draw_hidden_field('dotpo_po_number', $_POST['dotpo_po_number']);
        return $process_button_string;
    }

    function before_process() {
      return false;
    }

    function after_process($insert_ids) {
  		global $insert_id, $zendb, $order;	
      $address_book = mysqli_query($zendb,"select * from address_book where
       customers_id=".$_SESSION['customer_id']." and entry_street_address ='".$order->delivery['street_address']."'
        and entry_postcode ='".$order->delivery['postcode']."' ");  
	 	$address_book = mysqli_fetch_array($address_book);
      if(isset($_SESSION['custom_ship_code'])){
        @$_SESSION['custom_ship_code'] = $_SESSION['custom_ship_code'];
      }else{
        @$_SESSION['custom_ship_code'] = $order->info['shipping_module_code'];
      }
	  
	 
      foreach ($insert_ids as $key => $value) {
          $sql = "insert into orders_status_history (comments, orders_id, orders_status_id, date_added) values ('PO Number: " . $_POST['po_check']. "', '".$value."', ".$this->order_status.", now() )";
		  
      mysqli_query($zendb,$sql);

      mysqli_query($zendb,"update orders
                        set pono = '" . (int)$_POST['po_check'] . "'
                        where orders_id = '" . (int)$value . "'");

      mysqli_query($zendb,"update orders_details set ship_address_id ='".$address_book['address_book_id']."', ship_service_code ='".$_SESSION['custom_ship_code']."' where orders_id = '" . (int)$value . "' ");
      }	
  		
        return false;
    }

    function get_error() {
      return false;
    }

    
  }
