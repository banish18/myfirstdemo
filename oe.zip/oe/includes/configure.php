<?php
  define('HTTP_SERVER', $_SERVER["HTTP_HOST"]);
  define('HTTP_CATALOG_SERVER', $_SERVER["HTTP_HOST"]);

  define('DIR_WS_CATALOG', '/oe/');
  
  define('DIR_WS_INCLUDES', 'includes/');
  define('DIR_WS_FUNCTIONS', DIR_WS_INCLUDES . 'functions/');
  define('DIR_WS_CLASSES', DIR_WS_INCLUDES . 'classes/');
  define('DIR_FS_CATALOG', realpath("./")."/");


// define our database connection
  define('DB_TYPE', 'mysql');
  define('DB_PREFIX', '');
  define('DB_SERVER', 'holidaybows.com');
  define('DB_SERVER_USERNAME', 'holidaybows');
  define('DB_SERVER_PASSWORD', 'fountain');
  define('DB_DATABASE', 'zencart');
  define('USE_PCONNECT', 'false');
  define('STORE_SESSIONS', 'db');

// EOF
?>