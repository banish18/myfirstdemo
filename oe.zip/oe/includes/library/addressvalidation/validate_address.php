<?php
require_once(getcwd().'/fedex_fnc.php');
$countries_array = zen_get_countries(SHIPPING_ORIGIN_COUNTRY, true);
      echo $countries_array['countries_iso_code_2'];
//die("here");
$response = FedEx_Address_Validation($_REQUEST);
if (isset($response['Error'])) {
	echo '<tr><td colspan="2" align="center">***Error: ' . $response['Error'] . '***</td></tr>';
	echo '<tr><td colspan="2"><pre>';
	print_r($response);
	echo '</pre></td></tr>';
}
else {
	echo '<tr><td>Address Match Score:</td><td>' . $response['Score'] . '</td></tr>';
	echo '<tr><td>Proposed Changes:</td><td>';
	if (is_array($response['Changes'])) {
		foreach($response['Changes'] as $changesValue){
			echo $changesValue . '<br>';
		}
	}
	else if (isset($response['Changes'])) {
			echo $response['Changes'] . '<br>';
	}
	echo '</td></tr>';
	echo '<tr><td>Residential Status:</td><td>' . $response['ResidentialStatus'] . '</td></tr>';
	echo '<tr><td>Delivery Point Address:</td><td>' . $response['DeliveryPointValidation'] . '</td></tr>';

	echo '<tr><td>Proposed Address:</td><td>';
	foreach($response['Address'] as $addressKey => $addressValue){
		echo $addressValue . '<br>';
	}
}*/
?>

