<?php
// Shipment Status, Delete Shipment, Create Shipment, Track Shipment, Shipment Rates
$function_dir = getcwd().'/includes/library/addressvalidation/';

require_once($function_dir .'fedex-common.php5');
$test=0; 
//In WSDL, at end,
//production: <s1:address location="https://ws.fedex.com:443/web-services/ship"/>
//test:       <s1:address location="https://wsbeta.fedex.com:443/web-services/ship"/>
if ($test) {
	$account= '510087623'; //Test
	$meter = '118506093'; //Test
	$key = 'vZEOSUuLOqK9v7oP'; //Test
	$password='tqGJxwBQhMJSjPZq0NFb7HSGl';
}
else { //Live
	$account= '268035427'; 
	$meter = '101575590';
	$key = 'WgOQO8OD4dqusJCr';
	$password = 'v6Iqjoep4YZkncI9aMPSOaQbc';
}

$FedExServices = array('fedex_firstovernight' => 'FIRST_OVERNIGHT',
						'fedex_priorityovernight' => 'PRIORITY_OVERNIGHT',
						'fedex_standardovernight' => 'STANDARD_OVERNIGHT',
						'fedex_2day_am' => 'FEDEX_2_DAY_AM',
						'fedex_2day' => 'FEDEX_2_DAY',
						'fedex_saver' => 'FEDEX_EXPRESS_SAVER',
						'fedex_ground' => 'FEDEX_GROUND',
						'fedex_groundhomedelivery' => 'GROUND_HOME_DELIVERY',
						
						'FIRST_OVERNIGHT' => '1st Overnight',
						'PRIORITY_OVERNIGHT' => 'Pri Overnight',
						'STANDARD_OVERNIGHT' => 'Std Overnight',
						'FEDEX_2_DAY_AM' => '2 Day AM',
						'FEDEX_2_DAY' => '2 Day',
						'FEDEX_EXPRESS_SAVER' => 'Saver',
						'FEDEX_GROUND' => 'Ground',
						'GROUND_HOME_DELIVERY' => 'Ground (Res)');

				
function FedEx_Package_Status($trackingnum) { // Returns Status DL=Delivered, DP=Not delivered
	global $account, $meter, $key, $password, $function_dir, $test;
	$path_to_wsdl = $function_dir . 'TrackService_v6.wsdl';
	ini_set("soap.wsdl_cache_enabled", "0");
	$client = new SoapClient($path_to_wsdl, array('trace' => 1)); 
	$request['WebAuthenticationDetail'] = array('UserCredential' => array('Key' => $key, 'Password' => $password));
	$request['ClientDetail'] = array('AccountNumber' => $account, 'MeterNumber' => $meter);
	$request['TransactionDetail'] = array('CustomerTransactionId' => 'Tracking Request');
	$request['Version'] = array('ServiceId' => 'trck', 'Major' => '6', 'Intermediate' => '0', 'Minor' => '0');
	$request['PackageIdentifier'] = array('Value' => $trackingnum, 'Type' => 'TRACKING_NUMBER_OR_DOORTAG');
	try {
		$resp = $client ->track($request);
		if ($resp->HighestSeverity != 'FAILURE' && $resp->HighestSeverity != 'ERROR') {
			if (isset($resp->TrackDetails->ActualDeliveryTimestamp)) {
				$actualdeliverydate = substr($resp->TrackDetails->ActualDeliveryTimestamp,0,10);
			}
			else $actualdeliverydate='';
			return array('Tracking' => $resp->TrackDetails->TrackingNumber, 'Code' => $resp->TrackDetails->StatusCode, 'DeliveryDate' =>$actualdeliverydate);
		}
		else return array('Error' => 'No Data Returned', 'Description' => objToArray($resp));
	}
	catch (SoapFault $exception) {
		return array('Error' => 'Failure/Error', 'Description' => $exception);
	}
}

function Fedex_Delete_Shipment($trackingnum, $shippingcode) { //Returns Confirmation
	global $account, $meter, $key, $password, $function_dir, $test;
	$path_to_wsdl = $function_dir . 'ShipService_v12.wsdl';
	ini_set("soap.wsdl_cache_enabled", "0");
	$client = new SoapClient($path_to_wsdl, array('trace' => 1)); // Refer to http://us3.php.net/manual/en/ref.soap.php for more information
	if ($test==1) {
		$old_location = $client->__setLocation('');
		$new_location = str_replace('https://ws.fedex.com', 'https://wsbeta.fedex.com', $old_location);
		$client->__setLocation($new_location);
	}
	$request['WebAuthenticationDetail'] = array('UserCredential' => array('Key' => $key, 'Password' => $password));
	$request['ClientDetail'] = array('AccountNumber' => $account, 'MeterNumber' => $meter);
	$request['TransactionDetail'] = array('CustomerTransactionId' => '*** Cancel Shipment Request using PHP ***');
	$request['Version'] = array('ServiceId' => 'ship', 'Major' => '12', 'Intermediate' => '1', 'Minor' => '0');
	$request['ShipTimestamp'] = date('c');
	$request['TrackingId'] = array('TrackingIdType' =>$shippingcode, // valid values EXPRESS, FEDEX, FREIGHT, GROUND, USPS
								'TrackingNumber'=>$trackingnum);  
	$request['DeletionControl'] = 'DELETE_ALL_PACKAGES'; // valid values DELETE_ALL_PACKAGES, DELETE_ONE_PACKAGE, LEGACY
	try {
		$resp = $client ->deleteShipment($request);
        if ($resp -> HighestSeverity != 'FAILURE' && $resp -> HighestSeverity != 'ERROR') {
			return objToArray($resp);
		}
		else return array('Error' => 'No Data Returned', 'Description' => objToArray($resp));
	}
	catch (SoapFault $exception) {
		return array('Error' => 'Failure/Error', 'Description' => $exception);
	}
}

function Fedex_Create_Shipment($shipment_details) { //Returns Labels
	global $account, $meter, $key, $password, $function_dir, $test;
	$path_to_wsdl = $function_dir . 'ShipService_v12.wsdl';
	ini_set("soap.wsdl_cache_enabled", "0");
	$client = new SoapClient($path_to_wsdl, array('trace' => 1)); // Refer to http://us3.php.net/manual/en/ref.soap.php for more information
	$request['WebAuthenticationDetail'] = array('UserCredential' => array('Key' => $key, 'Password' => $password));
	$request['ClientDetail'] = array('AccountNumber' => $account, 'MeterNumber' => $meter);
	$request['TransactionDetail'] = array('CustomerTransactionId' => '*** Domestic Shipping Request v10 using PHP ***');
	$request['Version'] = array('ServiceId' => 'ship', 'Major' => '10', 'Intermediate' => '0', 'Minor' => '0');
	
	$recipient = array(
		'Contact' => array(
			'PersonName' => $shipment_details['ship_name'],
			'CompanyName' => $shipment_details['ship_company'],
			'PhoneNumber' => $shipment_details['phone_number']), 
			'Address' => array(
				'StreetLines' => array($shipment_details['ship_street1'], $shipment_details['ship_street2']),
			'City' => $shipment_details['ship_city'],
			'StateOrProvinceCode' => $shipment_details['ship_state'],
			'PostalCode' => $shipment_details['ship_zip'],
			'CountryCode' => $shipment_details['ship_country'],
			'Residential' => ($res_fedex ? True : False) )); //***********************NEED VALIDATION**************************

	if ($blind == 1) $shipper = array(
			'Contact' => array(
				'PersonName' => $shipment_details['bill_name'],
				'CompanyName' => ($shipment_details['bill_company']=='' ? $shipment_details['bill_name']:$shipment_details['bill_company']),
				'PhoneNumber' => $shipment_details['bill_phone_number']), 
				'Address' => array(
					'StreetLines' => array($shipment_details['bill_street1']),
					'City' => $shipment_details['bill_city'],
					'StateOrProvinceCode' => $shipment_details['bill_state'],
					'PostalCode' => $shipment_details['bill_zip'],
					'CountryCode' => $shipment_details['bill_country']));
	else $shipper = array(
		'Contact' => array(
		'PersonName' => 'Shipping Department',
		'CompanyName' => 'Holiday Manufacturing Inc',
		'PhoneNumber' => '5088726171'),
		'Address' => array(
			'StreetLines' => array('4 Tripp Street'),
			'City' => 'Framingham',
			'StateOrProvinceCode' => 'MA',
			'PostalCode' => '01702',
			'CountryCode' => 'US'));

	$shippingChargesPayment = array(
		'PaymentType' => $shipment_details['shipping_payment_type'], // valid values RECIPIENT, SENDER and THIRD_PARTY
		'Payor' => array('AccountNumber' => ($shipment_details['shipping_payment_type'] == 'SENDER' ? $account: $shipment_details['bill_account_fedex']), 'CountryCode' => 'US'));

	$i=0;
	$package_count=0;
	while (isset($shipment_details["boxtype$i"])) {
		if ($shipment_details["boxqty$i"]>0) {
			for ($j = 0, $n = $shipment_details["boxqty$i"]; $j < $n; $j++) {
				$package_count++;	
				$packages[]= array(	'SequenceNumber'=>$package_count,
					'GroupPackageCount'=>1,
					'Weight' => array('Value' => $shipment_details["weight$i"],'Units' => 'LB'),
					'Dimensions' => array('Length' => $shipment_details["length$i"],'Width' => $shipment_details["width$i"],'Height' => $shipment_details["height$i"],'Units' => 'IN'),
					'CustomerReferences' => array('0' => array('CustomerReferenceType' => 'CUSTOMER_REFERENCE', 'Value' => ''), 
										'1' => array('CustomerReferenceType' => 'INVOICE_NUMBER', 'Value' => $oID),
										'2' => array('CustomerReferenceType' => 'P_O_NUMBER', 'Value' => '')));
			}
		}
		$i++;
	}

	$request['RequestedShipment'] = array(
		'ShipTimestamp' => date('c'),
		'DropoffType' => 'REGULAR_PICKUP', // valid values REGULAR_PICKUP, REQUEST_COURIER, DROP_BOX, BUSINESS_SERVICE_CENTER and STATION
		'ServiceType' => $FedExServices[$shipment_details['shipping_code']],
		'PackagingType' => 'YOUR_PACKAGING', // valid values FEDEX_BOX, FEDEX_PAK, FEDEX_TUBE, YOUR_PACKAGING, ...
		'Shipper' => $shipper,
		'Recipient' => $recipient,
		'ShippingChargesPayment' => $shippingChargesPayment,
		'LabelSpecification' => addLabelSpecification('zebra'), 
		'RateRequestTypes' => array('ACCOUNT'), // valid values ACCOUNT and LIST
		'PackageCount' => $package_count,
		'PackageDetail' => 'INDIVIDUAL_PACKAGES',                                        
		'RequestedPackageLineItems' => $packages[0] );
											   
	try {
		$resp = $client->processShipment($request); // FedEx web service invocation 
		if ($resp -> HighestSeverity != 'FAILURE' && $resp -> HighestSeverity != 'ERROR') 
			$label[] =$resp->CompletedShipmentDetail->CompletedPackageDetails->Label->Parts->Image;
		else return array('Error' => 'No Data Returned', 'Description' => $resp);
	}
	catch (SoapFault $exception) {
		return array('Error' => 'Failure/Error', 'Description' => $exception);
	}

	if ($package_count>1) {
		for ($i=1; $i<=$package_count; $i++) {
			$request['RequestedShipment']['MasterTrackingId'] = $resp->CompletedShipmentDetail->MasterTrackingId;
			$request['RequestedShipment']['RequestedPackageLineItems'] = $packages[$i];
			try {
				$resp = $client->processShipment($request); // FedEx web service invocation  
				if ($resp -> HighestSeverity != 'FAILURE' && $resp -> HighestSeverity != 'ERROR') 
					$label[] =$resp->CompletedShipmentDetail->CompletedPackageDetails->Label->Parts->Image;
				else return array('Error' => 'No Data Returned', 'Description' => $resp);
			}
			catch (SoapFault $exception) {
				return array('Error' => 'Failure/Error', 'Description' => $exception);
			}
		}
	}
}

function addLabelSpecification($type){
	switch ($type) {
		case 'pdf':
			return array(
			'LabelFormatType' => 'COMMON2D', // valid values COMMON2D, LABEL_DATA_ONLY
			'ImageType' => 'PDF',  // valid values DPL, EPL2, PDF, ZPLII and PNG
			'LabelStockType' => 'PAPER_7X4.75');
			break;
		case 'zebra':
			return array(
			'LabelFormatType' => 'COMMON2D', // valid values COMMON2D, LABEL_DATA_ONLY
			'ImageType' => 'EPL2', // valid values DPL, EPL2, PDF, ZPLII and PNG
			'LabelStockType' => 'STOCK_4X6.75_LEADING_DOC_TAB',
			'LabelPrintingOrientation' => 'TOP_EDGE_OF_TEXT_FIRST');
			break;
	}
	return False;
}

function FedEx_Rates($shipment_details) {
	global $account, $meter, $key, $password, $function_dir, $test;
	$path_to_wsdl = $function_dir . 'RateService_v10.wsdl';
	ini_set("soap.wsdl_cache_enabled", "0");
	$client = new SoapClient($path_to_wsdl, array('trace' => 1)); // Refer to http://us3.php.net/manual/en/ref.soap.php for more information
	$request['WebAuthenticationDetail'] = array('UserCredential' => array('Key' => $key, 'Password' => $password));
	$request['ClientDetail'] = array('AccountNumber' => $account, 'MeterNumber' => $meter);
	$request['TransactionDetail'] = array('CustomerTransactionId' => ' *** Rate Available Services Request v10 using PHP ***');
	$request['Version'] = array('ServiceId' => 'crs', 'Major' => '10', 'Intermediate' => '0', 'Minor' => '0');
	$request['ReturnTransitAndCommit'] = true;
	$request['RequestedShipment']['DropoffType'] = 'REGULAR_PICKUP'; // valid values REGULAR_PICKUP, REQUEST_COURIER, ...
	$request['RequestedShipment']['ShipTimestamp'] = date('c');

	$request['RequestedShipment']['ShippingChargesPayment'] = array('PaymentType' => 'SENDER',
				'Payor' => array('AccountNumber' => $account, 
                'CountryCode' => 'US'));
	$request['RequestedShipment']['RateRequestTypes'] = 'ACCOUNT'; //valid values ACCOUNT, LIST

	$addressFrom['StreetLines'] = array ( '4 Tripp Street', '', '');
	$addressFrom['City'] = 'Framingham';
	$addressFrom['StateOrProvinceCode'] = 'MA';
	$addressFrom['PostalCode'] = '01702';
	$addressFrom['CountryCode'] = 'US';
	$request['RequestedShipment']['Shipper']['Address'] = $addressFrom;

	$addressTo['StreetLines'] = array ($shipment_details['ship_street1'],$shipment_details['ship_street2']) ;
	$addressTo['City'] = $shipment_details['ship_city'];
	$addressTo['StateOrProvinceCode'] = strtoupper($shipment_details['ship_state']);
	$addressTo['PostalCode'] = $shipment_details['ship_zip'];
	$addressTo['CountryCode'] = $shipment_details['ship_country'];
	$addressTo['Residential'] = (isset($shipment_details['res_fedex'])?true:false ) ;
	$request['RequestedShipment']['Recipient']['Address'] = $addressTo;
	
	$packages = array();
	$package_count=$i=0;
	while (isset($shipment_details["boxtype$i"])) {
		if ($shipment_details["boxqty$i"]>0) {
			for ($j = 0, $n = $shipment_details["boxqty$i"]; $j < $n; $j++) {
				$package_count++;	

				$packageweight['Value'] = $shipment_details["weight$i"];
				$packageweight['Units'] = 'LB';

				$dimensions['Length'] = $shipment_details["length$i"];
				$dimensions['Width'] = $shipment_details["width$i"];
				$dimensions['Height'] = $shipment_details["height$i"];
				$dimensions['Units'] = 'IN';

				$packages[] = array("SequenceNumber" => $package_count, 
								"GroupPackageCount" => 1,
								"Weight" => $packageweight,
								"Dimensions" => $dimensions);
			}
		}
		$i++;
	}

	$request['RequestedShipment']['PackageCount'] = $package_count;
	$request['RequestedShipment']['RequestedPackageLineItems']= $packages;
	$request['RequestedShipment']['ReturnTransitAndCommit']= '';

	try {
		$resp = $client ->getRates($request);
        if ($resp -> HighestSeverity != 'FAILURE' && $resp -> HighestSeverity != 'ERROR') {
			$resp = objToArray($resp);
//			return $resp['RateReplyDetails'];
			return $resp;
		}
		else return array('Error' => 'No Data Returned', 'Description' => $resp);
	}
	catch (SoapFault $exception) {
		return array('Error' => 'Failure/Error', 'Description' => $exception);
	}
}
	
function objToArray($obj=false)  {
    if (is_object($obj))
        $obj= get_object_vars($obj);
    if (is_array($obj)) {
        return array_map(__FUNCTION__, $obj);
    } else {
        return $obj;
    }
}

function FedEx_Package_Tracking($trackingnum) { // Returns Entire Tracking Status
	global $account, $meter, $key, $password, $function_dir, $test;
	$path_to_wsdl = $function_dir . 'TrackService_v6.wsdl';
	ini_set("soap.wsdl_cache_enabled", "0");
	$client = new SoapClient($path_to_wsdl, array('trace' => 1)); 
	if ($test==1) {
		$old_location = $client->__setLocation('');
		$new_location = str_replace('https://ws.fedex.com', 'https://wsbeta.fedex.com', $old_location);
		$client->__setLocation($new_location);
	}
	$request['WebAuthenticationDetail'] = array('UserCredential' => array('Key' => $key, 'Password' => $password));
	$request['ClientDetail'] = array('AccountNumber' => $account, 'MeterNumber' => $meter);
	$request['TransactionDetail'] = array('CustomerTransactionId' => 'Tracking Request');
	$request['Version'] = array('ServiceId' => 'trck', 'Major' => '6', 'Intermediate' => '0', 'Minor' => '0');
	$request['PackageIdentifier'] = array('Value' => $trackingnum, 'Type' => 'TRACKING_NUMBER_OR_DOORTAG');
	$request['IncludeDetailedScans'] = 1;
	try {
		$resp = $client ->track($request);
		if ($resp->HighestSeverity != 'FAILURE' && $resp->HighestSeverity != 'ERROR') {
			$resp = objToArray($resp);
			return $resp['TrackDetails'];
		}
		else return array('Error' => 'No Data Returned', 'Description' => $resp);
	}
	catch (SoapFault $exception) {
		return array('Error' => 'Failure/Error', 'Description' => $exception);
	}
}

function FedEx_Address_Validation($address_details) { // Returns Entire Tracking Status
	global $account, $meter, $key, $password, $function_dir, $test;
	$path_to_wsdl = $function_dir . 'AddressValidationService_v2.wsdl';
	ini_set("soap.wsdl_cache_enabled", "0");
	$client = new SoapClient($path_to_wsdl, array('trace' => 1)); 
	
	
	if ($test==1) {
		$old_location = $client->__setLocation('https://ws.fedex.com');
		$new_location = str_replace('https://ws.fedex.com', 'https://wsbeta.fedex.com', $old_location);
		$client->__setLocation($new_location);
	}
	$request['WebAuthenticationDetail'] = array('UserCredential' => array('Key' => $key, 'Password' => $password));
	$request['ClientDetail'] = array('AccountNumber' => $account, 'MeterNumber' => $meter);
	$request['TransactionDetail'] = array('CustomerTransactionId' => ' *** Address Validation Request v2 using PHP ***');
	$request['Version'] = array('ServiceId' => 'aval', 'Major' => '2', 'Intermediate' => '0', 'Minor' => '0');
	$request['RequestTimestamp'] = date('c');

	$request['Options'] = array('CheckResidentialStatus' => 1,
                             'MaximumNumberOfMatches' => 5,
                             'StreetAccuracy' => 'LOOSE',
                             'DirectionalAccuracy' => 'LOOSE',
                             'CompanyNameAccuracy' => 'LOOSE',
                             'ConvertToUpperCase' => 1,
                             'RecognizeAlternateCityNames' => 1,
                             'ReturnParsedElements' => 1);
	$request['AddressesToValidate'] = array(0 => array('AddressId' => '1',
		'Address' => array('StreetLines' => array($address_details['street_address1'],$address_details['street_address2']),
		'City' => $address_details['city'],
		'StateOrProvinceCode' => $address_details['state'],
		'PostalCode' => $address_details['postcode'],
		'CountryCode' => $address_details['country'],
		'CompanyName' => ($address_details['company']==''?$address_details['name']:$address_details['company']))));

	try {
		$resp = $client ->addressValidation($request);
		if ($resp->HighestSeverity != 'FAILURE' && $resp->HighestSeverity != 'ERROR') {
			$resp = objToArray($resp);
			return $resp['AddressResults']['ProposedAddressDetails'];
		}
		else return array('Error' => 'No Data Returned', 'Description' => $resp, 'Old' => $old_location, 'New' => $new_location);
	}
	catch (SoapFault $exception) {
		return array('Error' => 'Failure/Error', 'Description' => $exception);
	}
}



?>
