<?php
//These are the rudimetary functions for Customer Management and Order Entry/Update

// Begin functions for lookup tables
function getCountries() {
	$sql = "SELECT  * FROM countries";
	$result = mysqli_query($zendb, $sql);
	while ($country = mysqli_fetch_array($result)) { 
		$countries[$country['countries_id']] = array (
			'country_name'	=>	$country['countries_name'],
			'country_code' 	=>	$country['countries_iso_code_2']
		);
	}
	$this->countries = $countries;
	return $this;
}

function getZones() {
	$sql = "SELECT  * FROM zones";
	$result = mysqli_query($zendb, $sql);
	while ($zone = mysqli_fetch_array($result)) { 
		$zones[$zone['zone_id']] = array (
			'country_id'	=>	$zone['zone_country_id'],
			'zone_code'		=>	$zone['zone_code'],
			'zone_name' 	=>	$zone['zone_name']
		);
	}
	$this->zones = $zones;
	return $this;
}

function getZonesCode() {
	$sql = "SELECT  * FROM zones";
	$result = mysqli_query($zendb, $sql);
	while ($zonecode = mysqli_fetch_array($result)) { 
		$zonescodes[$zonecode['zone_code']] = array (
			'country_id'	=>	$zonecode['zone_country_id'],
			'zone_id'		=>	$zonecode['zone_id'],
			'zone_name' 	=>	$zonecode['zone_name']
		);
	}
	$this->zonescodes = $zonescodes;
	return $this;
}

function getGroupPricing() {
	$sql = "SELECT  * FROM group_pricing";
	$result = mysqli_query($zendb, $sql);
	while ($price = mysqli_fetch_array($result)) { 
		$group_pricing[$price['group_id']] = array (
			'group_name'		=>	$price['group_name'],
			'group_percentage' 	=>	$price['group_percentage']
		);
	}
	$this->group_pricing = $group_pricing;
	return $this;
}
	
function getOrderTotalOptions() {
	$order_total_options[] = array ('title' => 'Items Subtotal :', 'class' => 'ot_subtotal', 'sort_order' => '100');
	$order_total_options[] = array ('title' => 'Order Discount :', 'class' => 'ot_order_discount', 'sort_order' => '150');
	$order_total_options[] = array ('title' => 'Discount Coupon :', 'class' => 'ot_coupon', 'sort_order' => '160');
	$order_total_options[] = array ('title' => 'Group Discount :', 'class' => 'ot_group_pricing', 'sort_order' => '175');
	$order_total_options[] = array ('title' => 'Sales Tax :', 'class' => 'ot_tax', 'sort_order' => '250');
	$order_total_options[] = array ('title' => ' :', 'class' => 'ot_shipping', 'sort_order' => '300');
	$order_total_options[] = array ('title' => 'Total :', 'class' => 'ot_total', 'sort_order' => '999');
	$this->order_total_options = $order_total_options;
	return $this;
}
// End functions for lookup tables

class customer {
	protected $zendb;					// zen database handle

	protected $countries;				// countries with id as index
	protected $zones;					// zones with id as index
	protected $zonecodes;				// zones with code as index
	protected $group_pricing;			// group pricing lookup table	

	protected $id;						// customer id
	protected $customer;				// customer details of selected customer
	
	protected $addresses;				// addresses for customer
	protected $address;					// address details for update/insert
	protected $address_book_id;			// address book id (for updating)
	protected $bill_to_address;			// id of bill to address
	protected $ship_to_address;			// id of ship to address

	protected $orders; 					// all orders
	protected $order;					// order details for update/insert
	protected $order_id;				// order id of selected order
	
	protected $order_totals;			// order totals
	protected $order_total;				// order total details for update/insert
	protected $order_total_id;			// order total id (for updating)
	protected $order_total_options;		// order total id (for updating)

	protected $order_products;			// order products
	protected $order_product;			// order product details for update/insert
	protected $order_product_id;		// order products id (for updating)

	protected $order_status_histories;	// order status histories
	protected $order_status_history;	// order_status_history details for update/insert
	protected $order_status_history_id;	// order status history id (for updating)

	public function setZenId($zendb) {
		$this->zendb = $zendb;
        return $this;
	}

	public function setCustomerId($id) {
		$this->id = $id;
        return $this;
	}

	public function lookUpCustomer($term) {
		$term = trim(strip_tags($term));
		$search_results = [];
		$search = '(entry_company LIKE "%' . $term . '%") ';
		$search .= 'OR (entry_firstname LIKE "%' . $term . '%")';
		$search .= 'OR (entry_lastname LIKE "%' . $term . '%")';
		$search .= 'OR (customers_firstname LIKE "%' . $term . '%")';
		$search .= 'OR (customers_lastname LIKE "%' . $term . '%")';
		$search .= 'OR (customers_email_address LIKE "%' . $term . '%")';
		$search .= 'OR (customers_telephone LIKE "%' . $term . '%")';
		
		$sql = "SELECT DISTINCT CONCAT(customers_firstname,' ',customers_lastname) as name, customers_firstname ,customers_lastname ,customers_email_address,customers_fax, customers_customerProfileId,customers_telephone, customers_terms,customers_blind_ship_default,customers_terms_special,customers_ship_collect,customers_resale_tax_id_date,customers_resale_tax_id,customers_special_order_notes,customers_special_shipping_notes,customers_ups_acct,customers_fedex_acct,customers_ltl_capable,customers_invoice_email,customer_wholesale,customers_invoice_mail,customers_invoice_fax,customers_store_pickup_enabled,customers_custom_ship_date_enabled,customers_blind_ship_enabled,customers_ltl_capable,customers_group_pricing,customers_terms,c.customers_id 
			FROM customers c
			LEFT JOIN address_book ab ON ab.customers_id=c.customers_id LEFT JOIN customers_details cd ON cd.customers_id=c.customers_id 
			WHERE " . $search . "";
		$result = mysqli_query($this->zendb, $sql); //query the database for entries containing the term
	
		$row_set='';
		if(mysqli_num_rows($result) > 0)
		{
			while($row = mysqli_fetch_array($result)){
				$search_results[] = array (
					'id'						=> (int)$row['customers_id'],
					'label'						=> htmlentities(stripslashes($row['name'])) . "|" . htmlentities(stripslashes($row['customers_email_address'])) . "|" . htmlentities(stripslashes($row['customers_telephone'])),
					'name'						=> htmlentities(stripslashes($row['name'])),
					'customers_email_address'	=> htmlentities(stripslashes($row['customers_email_address'])),
					'customers_firstname'	=> htmlentities(stripslashes($row['customers_firstname'])),
					'customers_lastname'	=> htmlentities(stripslashes($row['customers_lastname'])),
					'customers_terms'	=> htmlentities(stripslashes($row['customers_terms'])),
					'customers_group_pricing'	=> htmlentities(stripslashes($row['customers_group_pricing'])),
					'customers_ltl_capable'	=> htmlentities(stripslashes($row['customers_ltl_capable'])),
					'customers_blind_ship_enabled'	=> htmlentities(stripslashes($row['customers_blind_ship_enabled'])),
					'customers_custom_ship_date_enabled'	=> htmlentities(stripslashes($row['customers_custom_ship_date_enabled'])),
					'customers_store_pickup_enabled'	=> htmlentities(stripslashes($row['customers_store_pickup_enabled'])),
					'customer_wholesale'	=> htmlentities(stripslashes($row['customer_wholesale'])),
					'customers_fedex_acct'	=> htmlentities(stripslashes($row['customers_fedex_acct'])),
					'customers_blind_ship_default'	=> htmlentities(stripslashes($row['customers_blind_ship_default'])),
					'customers_ltl_capable'	=> htmlentities(stripslashes($row['customers_ltl_capable'])),
					'customers_ups_acct'	=> htmlentities(stripslashes($row['customers_ups_acct'])),
					'customers_invoice_mail'	=> htmlentities(stripslashes($row['customers_invoice_mail'])),
					'customers_invoice_fax'	=> htmlentities(stripslashes($row['customers_invoice_fax'])),
					'customers_ship_collect'	=> htmlentities(stripslashes($row['customers_ship_collect'])),
					'customers_invoice_email'	=> htmlentities(stripslashes($row['customers_invoice_email'])),
					'customers_special_shipping_notes'	=> htmlentities(stripslashes($row['customers_special_shipping_notes'])),
					'customers_special_order_notes'	=> htmlentities(stripslashes($row['customers_special_order_notes'])),
					'customers_resale_tax_id'	=> htmlentities(stripslashes($row['customers_resale_tax_id'])),
					'customers_resale_tax_id_date'	=> htmlentities(stripslashes($row['customers_resale_tax_id_date'])),
					'customers_terms_special'	=> htmlentities(stripslashes($row['customers_terms_special'])),
					'customers_terms'	=> htmlentities(stripslashes($row['customers_terms'])),
					'customers_fax'	=> htmlentities(stripslashes($row['customers_fax'])),
					'customers_customerProfileId'	=> htmlentities(stripslashes($row['customers_customerProfileId'])),
					'customers_telephone'		=> preg_replace('/[^0-9]+/', '', $row['customers_telephone'])
				);
			}
		}
		
		return $search_results;//format the array into json data: [{"value":"Some Name","id":1},{"value":"Some Othername","id":2}]
	}
	
	
	public function lookUpProduct($term) {
		$term = trim(strip_tags($term));
		session_start();
		$search_results = [];
		$storeType = $_SESSION['store_type'];
		if($storeType == "Holiday Manufacturing Inc"){
			$storeType = 'holidaysbow';
		}
		$select_str = "SELECT DISTINCT p.products_image, p.products_model, p.products_quantity , m.manufacturers_id, p.products_id, pd.products_name, p.products_price, p.products_tax_class_id, p.products_price_sorter, p.products_qty_box_status, p.master_categories_id,pde.sku_old";
		$from_str = " FROM (products p LEFT JOIN products_details pde ON pde.products_id= p.products_id LEFT JOIN manufacturers m USING(manufacturers_id) INNER JOIN categories_description cd ON (p.master_categories_id = cd.categories_id AND cd.language_id=1 AND cd.categories_description LIKE '%-".$storeType."-%') , products_description pd, categories c, products_to_categories p2c ) LEFT JOIN meta_tags_products_description mtpd ON mtpd.products_id= p2c.products_id AND mtpd.language_id = 1 WHERE ((p.products_status = 1 or (pde.availability_status = 3 or pde.availability_status = 2 or pde.availability_status = 1)) AND p.products_id = pd.products_id AND pd.language_id = 1 AND p.products_id = p2c.products_id AND p2c.categories_id = c.categories_id";
		$where_str = "";
		$keyword = trim($term);	
		$pieces = explode(" ", $keyword);
	
		$where_str .= " AND (";
		for ($i=0, $n=sizeof($pieces); $i<$n; $i++ ) {
			switch ($pieces[$i]) {
				case '(':
				case ')':
				case 'and':
				case 'or':
				$where_str .= " " . $pieces[$i] . " ";
				break;
				default:
				$where_str .= "(pd.products_name LIKE '%".$pieces[$i]."%'
												OR p.products_model
												LIKE '%".$pieces[$i]."%'
												OR pde.sku_old
												LIKE '%".$pieces[$i]."%'
												OR m.manufacturers_name
												LIKE '%".$pieces[$i]."%'";
			$where_str .= " OR (mtpd.metatags_keywords
								LIKE '%".$pieces[$i]."%'
								AND mtpd.metatags_keywords !='')";
			$where_str .= " OR (mtpd.metatags_description
								LIKE '%".$pieces[$i]."%'
								AND mtpd.metatags_description !='')";
				$where_str .= " OR (pde.sku_old
								LIKE '%".$pieces[$i]."%')";
				$where_str .= " OR pd.products_description
								LIKE '%".$pieces[$i]."%'";
				$where_str .= ') AND';
				break;
				}
			}
	$where_str = rtrim($where_str, 'AND');
    $where_str .= " ))";
    $where_str .=  "and p.products_id IN (select products_id from products_details where 1 ) order by p.products_sort_order, pd.products_name";
	
	
   $listing_sql = $select_str . $from_str . $where_str;
   
   //echo $listing_sql;
   $result = mysqli_query($this->zendb, $listing_sql);
   while($row = mysqli_fetch_array($result)){
		$search_results[] = array (
			'id'			    => (int)$row['products_id'],
			'label'			    => htmlentities(stripslashes($row['products_model'])).' '.htmlentities(stripslashes($row['products_name'])),
			'products_name'	    => htmlentities(stripslashes($row['products_name'])),
			'products_image'	=> htmlentities(stripslashes($row['products_image'])),
			'products_model'	=> htmlentities(stripslashes($row['products_model'])),
			'products_quantity'	=> htmlentities(stripslashes($row['products_quantity'])),
			'products_id'	    => htmlentities(stripslashes($row['products_id'])),
			'products_price'	=> htmlentities(stripslashes(round($row['products_price'],2))),
			'master_categories_id'	=> htmlentities(stripslashes($row['master_categories_id'])),
			'sku_old'	=> htmlentities(stripslashes($row['sku_old']))
		);
	}

return $search_results;
}

/* product lookup using product description */
	
public function lookUpProductdesc($term) {
		$term = trim(strip_tags($term));
		session_start();
		$search_results = [];
		$storeType = $_SESSION['store_type'];
		if($storeType == "Holiday Manufacturing Inc"){
			$storeType = 'holidaysbow';
		}
		$select_str = "SELECT DISTINCT p.products_image, p.products_model, p.products_quantity , m.manufacturers_id, p.products_id, pd.products_name, p.products_price, p.products_tax_class_id, p.products_price_sorter, p.products_qty_box_status, p.master_categories_id,pde.sku_old";
		$from_str = " FROM (products p LEFT JOIN products_details pde ON pde.products_id= p.products_id LEFT JOIN manufacturers m USING(manufacturers_id) INNER JOIN categories_description cd ON (p.master_categories_id = cd.categories_id AND cd.language_id=1 AND cd.categories_description LIKE '%-".$storeType."-%') , products_description pd, categories c, products_to_categories p2c ) LEFT JOIN meta_tags_products_description mtpd ON mtpd.products_id= p2c.products_id AND mtpd.language_id = 1 WHERE ((p.products_status = 1 or (pde.availability_status = 3 or pde.availability_status = 2 or pde.availability_status = 1)) AND p.products_id = pd.products_id AND pd.language_id = 1 AND p.products_id = p2c.products_id AND p2c.categories_id = c.categories_id";
		$where_str = "";
		$keyword = trim($term);	
		$pieces = explode(" ", $keyword);
	
		$where_str .= " AND (";
		for ($i=0, $n=sizeof($pieces); $i<$n; $i++ ) {
			switch ($pieces[$i]) {
				case '(':
				case ')':
				case 'and':
				case 'or':
				$where_str .= " " . $pieces[$i] . " ";
				break;
				default:
				$where_str .= "(pd.products_description
								LIKE '%".$pieces[$i]."%'";
				$where_str .= ') AND';
				break;
				}
			}
	$where_str = rtrim($where_str, 'AND');
    $where_str .= " ))";
    $where_str .=  "and p.products_id IN (select products_id from products_details where 1 ) order by p.products_sort_order, pd.products_name";
	
	
   $listing_sql = $select_str . $from_str . $where_str;
   
  /* echo $listing_sql;
   die;*/
   $result = mysqli_query($this->zendb, $listing_sql);
   while($row = mysqli_fetch_array($result)){
		$search_results[] = array (
			'id'			    => (int)$row['products_id'],
			'label'			    => htmlentities(stripslashes($row['products_model'])).' '.htmlentities(stripslashes($row['products_name'])),
			'products_name'	    => htmlentities(stripslashes($row['products_name'])),
			'products_image'	=> htmlentities(stripslashes($row['products_image'])),
			'products_model'	=> htmlentities(stripslashes($row['products_model'])),
			'products_quantity'	=> htmlentities(stripslashes($row['products_quantity'])),
			'products_id'	    => htmlentities(stripslashes($row['products_id'])),
			'products_price'	=> htmlentities(stripslashes(round($row['products_price'],2))),
			'master_categories_id'	=> htmlentities(stripslashes($row['master_categories_id'])),
			'sku_old'	=> htmlentities(stripslashes($row['sku_old']))
		);
	}

return $search_results;
}
	public function lookUpCustomerByAddress($term) {
		$term = trim(strip_tags($term));
		$search_results = [];
		$search = '(entry_street_address LIKE "%' . $term . '%") ';
		$search .= 'OR (entry_city LIKE "%' . $term . '%")';
		$search .= 'OR (entry_postcode LIKE "%' . $term . '%")';

		$sql = "SELECT DISTINCT CONCAT(customers_firstname,' ',customers_lastname) as name, customers_firstname ,customers_lastname ,customers_email_address,customers_fax, customers_customerProfileId,customers_telephone, customers_terms,customers_blind_ship_default,customers_terms_special,customers_ship_collect,customers_resale_tax_id_date,customers_resale_tax_id,customers_special_order_notes,customers_special_shipping_notes,customers_ups_acct,customers_fedex_acct,customers_ltl_capable,customers_invoice_email,customer_wholesale,customers_invoice_mail,customers_invoice_fax,customers_store_pickup_enabled,customers_custom_ship_date_enabled,customers_blind_ship_enabled,customers_ltl_capable,customers_group_pricing,customers_terms,c.customers_id 
			FROM customers c
			LEFT JOIN address_book ab ON ab.customers_id=c.customers_id LEFT JOIN customers_details cd ON cd.customers_id=c.customers_id 
			WHERE " . $search . "";
			

		
		$result = mysqli_query($this->zendb, $sql); //query the database for entries containing the term
	
		$row_set='';
		if(mysqli_num_rows($result) > 0 )
		{
			while($row = mysqli_fetch_array($result)){
				$search_results[] = array (
					'id'						=> (int)$row['customers_id'],
					'label'						=> htmlentities(stripslashes($row['name'])) . "|" . htmlentities(stripslashes($row['customers_email_address'])) . "|" . htmlentities(stripslashes($row['customers_telephone'])),
					'name'						=> htmlentities(stripslashes($row['name'])),
					'customers_email_address'	=> htmlentities(stripslashes($row['customers_email_address'])),
					'customers_firstname'	=> htmlentities(stripslashes($row['customers_firstname'])),
					'customers_lastname'	=> htmlentities(stripslashes($row['customers_lastname'])),
					'customers_terms'	=> htmlentities(stripslashes($row['customers_terms'])),
					'customers_group_pricing'	=> htmlentities(stripslashes($row['customers_group_pricing'])),
					'customers_ltl_capable'	=> htmlentities(stripslashes($row['customers_ltl_capable'])),
					'customers_blind_ship_enabled'	=> htmlentities(stripslashes($row['customers_blind_ship_enabled'])),
					'customers_custom_ship_date_enabled'	=> htmlentities(stripslashes($row['customers_custom_ship_date_enabled'])),
					'customers_store_pickup_enabled'	=> htmlentities(stripslashes($row['customers_store_pickup_enabled'])),
					'customer_wholesale'	=> htmlentities(stripslashes($row['customer_wholesale'])),
					'customers_fedex_acct'	=> htmlentities(stripslashes($row['customers_fedex_acct'])),
					'customers_blind_ship_default'	=> htmlentities(stripslashes($row['customers_blind_ship_default'])),
					'customers_ltl_capable'	=> htmlentities(stripslashes($row['customers_ltl_capable'])),
					'customers_ups_acct'	=> htmlentities(stripslashes($row['customers_ups_acct'])),
					'customers_invoice_mail'	=> htmlentities(stripslashes($row['customers_invoice_mail'])),
					'customers_invoice_fax'	=> htmlentities(stripslashes($row['customers_invoice_fax'])),
					'customers_ship_collect'	=> htmlentities(stripslashes($row['customers_ship_collect'])),
					'customers_invoice_email'	=> htmlentities(stripslashes($row['customers_invoice_email'])),
					'customers_special_shipping_notes'	=> htmlentities(stripslashes($row['customers_special_shipping_notes'])),
					'customers_special_order_notes'	=> htmlentities(stripslashes($row['customers_special_order_notes'])),
					'customers_resale_tax_id'	=> htmlentities(stripslashes($row['customers_resale_tax_id'])),
					'customers_resale_tax_id_date'	=> htmlentities(stripslashes($row['customers_resale_tax_id_date'])),
					'customers_terms_special'	=> htmlentities(stripslashes($row['customers_terms_special'])),
					'customers_terms'	=> htmlentities(stripslashes($row['customers_terms'])),
					'customers_fax'	=> htmlentities(stripslashes($row['customers_fax'])),
					'customers_customerProfileId'	=> htmlentities(stripslashes($row['customers_customerProfileId'])),
					'customers_telephone'		=> preg_replace('/[^0-9]+/', '', $row['customers_telephone'])
				);
			}
		}
		return $search_results;//format the array into json data: [{"value":"Some Name","id":1},{"value":"Some Othername","id":2}]
	}
	
	public function lookUpState($term,$country) {
		$term = trim(strip_tags($term));
		$search_results = [];
		$search = '(zone_name LIKE "%' . $term . '%")';
		$search .= 'AND (zone_country_id = '.$country.')';

		$sql = "SELECT zone_id,zone_name from zones
			WHERE " . $search . "";
		$result = mysqli_query($this->zendb, $sql); //query the database for entries containing the term
		$row_set='';
		if(mysqli_num_rows($result) > 0 )
		{
			while($row = mysqli_fetch_array($result)){
				$search_results[] = array (
					'id'						=> (int)$row['zone_id'],
					'label'	=> htmlentities(stripslashes($row['zone_name'])),
					'name'	=> htmlentities(stripslashes($row['zone_name'])),
				);
			}
		}
		return $search_results;//format the array into json data: [{"value":"Some Name","id":1},{"value":"Some Othername","id":2}]
	}
	
 	public function getCustomer() {
 		$sql = "SELECT customers_firstname, customers_lastname, customers_email_address, customers_default_address_id, customers_telephone, customers_fax, customers_group_pricing, customers_store_pickup_enabled, customers_custom_ship_date_enabled, customers_terms, customers_terms_special, customers_blind_ship_enabled, customers_blind_ship_default, customers_ship_collect, customers_ups_acct, customers_fedex_acct, customers_ltl_capable, customers_special_shipping_notes, customers_special_order_notes, customers_invoice_mail, customers_invoice_fax, customers_invoice_email, customers_resale_tax_id, customers_resale_tax_id_date, customers_CIM_customerProfileId, customers_CIM_customerPaymentProfileId, customers_CIM_customerShippingAddressId, customer_wholesale
		FROM customers c
		LEFT JOIN customers_details cdt on c.customers_id=cdt.customers_id
		WHERE c.customers_id = '" . $this->id . "'";
		$result = mysqli_query($this->zendb, $sql);
		$customer = mysqli_fetch_array($result);
		$this->customer = $customer;
        return $this->customer;
	}

	public function setCustomer($customer) {
		$this->customer = $customer;
        return $this;
	}
	
	public function addCustomer() {
		$sql = "INSERT INTO customers
			( customers_firstname, customers_lastname, customers_email_address, customers_default_address_id, customers_telephone, customers_fax, customers_group_pricing )	
			VALUES( '". 
				$customer['customers_firstname'] . "', '" .
				$customer['customers_lastname'] . "', '" .
				$customer['customers_email_address'] . "', '" .
				$customer['customers_default_address_id'] . "', '" .
				$customer['customers_telephone'] . "', '" .
				$customer['customers_fax'] . "', '" .
				$customer['customers_group_pricing'] . "')";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT ADD CUSTOMER:' . mysqli_error($zendb);
		$customer_id = mysqli_insert_id($zendb);

		$sql = "INSERT INTO customers_details
			(  customers_id, customers_store_pickup_enabled, customers_custom_ship_date_enabled, customers_terms, customers_terms_special, customers_blind_ship_enabled, customers_blind_ship_default, customers_ship_collect, customers_ups_acct, customers_fedex_acct, customers_ltl_capable, customers_special_shipping_notes, customers_special_order_notes, customers_invoice_mail, customers_invoice_fax, customers_invoice_email, customers_resale_tax_id, customers_resale_tax_id_date, customers_CIM_customerProfileId, customers_CIM_customerPaymentProfileId, customers_CIM_customerShippingAddressId, customer_wholesale )	
			VALUES( '". $customer_id . "', '" .
				$customer['customers_store_pickup_enabled'] . "', '" .
				$customer['customers_custom_ship_date_enabled'] . "', '" .
				$customer['customers_terms'] . "', '" .
				$customer['customers_terms_special'] . "', '" .
				$customer['customers_blind_ship_enabled'] . "', '" .
				$customer['customers_blind_ship_default'] . "', '" .
				$customer['customers_ship_collect'] . "', '" .
				$customer['customers_ups_acct'] . "', '" .
				$customer['customers_fedex_acct'] . "', '" .
				$customer['customers_ltl_capable'] . "', '" .
				$customer['customers_special_shipping_notes'] . "', '" .
				$customer['customers_special_order_notes'] . "', '" .
				$customer['customers_invoice_mail'] . "', '" .
				$customer['customers_invoice_fax'] . "', '" .
				$customer['customers_invoice_email'] . "', '" .
				$customer['customers_resale_tax_id'] . "', '" .
				$customer['customers_resale_tax_id_date'] . "', '" .
				$customer['customers_CIM_customerProfileId'] . "', '" .
				$customer['customers_CIM_customerPaymentProfileId'] . "', '" .
				$customer['customers_CIM_customerShippingAddressId'] . "', '" .
				$customer['customer_wholesale'] . "')";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT ADD CUSTOMER DETAIL:' . mysqli_error($zendb);

		return;
	}

	public function updateCustomer() {
		$sql = "UPDATE customers SET
				customers_firstname = '" . $customer['customers_firstname'] . "',
				customers_lastname = '" . $customer['customers_lastname'] . "',
				customers_email_address = '" . $customer['customers_email_address'] . "',
				customers_default_address_id = '" . $customer['customers_default_address_id'] . "',
				customers_telephone = '" . $customer['customers_telephone'] . "',
				customers_fax = '" . $customer['customers_fax'] . "'
				customers_group_pricing = '" . $customer['customers_group_pricing'] . "'
				WHERE customers_id='".  $customers_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT UPDATE CUSTOMER:' . mysqli_error($zendb);

		$sql = "UPDATE customers_details SET
					customers_store_pickup_enabled = '" . $customer['customers_store_pickup_enabled'] . "',
					customers_custom_ship_date_enabled = '" . $customer['customers_custom_ship_date_enabled'] . "',
					customers_terms = '" . $customer['customers_terms'] . "',
					customers_terms_special = '" . $customer['customers_terms_special'] . "',
					customers_blind_ship_enabled = '" . $customer['customers_blind_ship_enabled'] . "',
					customers_blind_ship_default = '" . $customer['customers_blind_ship_default'] . "',
					customers_ship_collect = '" . $customer['customers_ship_collect'] . "',
					customers_ups_acct = '" . $customer['customers_ups_acct'] . "',
					customers_fedex_acct = '" . $customer['customers_fedex_acct'] . "',
					customers_ltl_capable = '" . $customer['customers_ltl_capable'] . "',
					customers_special_shipping_notes = '" . $customer['customers_special_shipping_notes'] . "',
					customers_special_order_notes = '" . $customer['customers_special_order_notes'] . "',
					customers_invoice_mail = '" . $customer['customers_invoice_mail'] . "',
					customers_invoice_fax = '" . $customer['customers_invoice_fax'] . "',
					customers_invoice_email = '" . $customer['customers_invoice_email'] . "',
					customers_resale_tax_id = '" . $customer['customers_resale_tax_id'] . "',
					customers_resale_tax_id_date = '" . $customer['customers_resale_tax_id_date'] . "',
					customers_CIM_customerProfileId = '" . $customer['customers_CIM_customerProfileId'] . "',
					customers_CIM_customerPaymentProfileId = '" . $customer['customers_CIM_customerPaymentProfileId'] . "',
					customers_CIM_customerShippingAddressId = '" . $customer['customers_CIM_customerShippingAddressId'] . "',
					customer_wholesale = '" . $customer['customer_wholesale'] . "'
				WHERE customers_id='".  $customers_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT UPDATE CUSTOMER DETAIL:' . mysqli_error($zendb);

		return;
	}


	public function getAddresses() {
		$sql = "SELECT  ab.address_book_id, entry_company, entry_firstname, entry_lastname, entry_street_address, entry_suburb, entry_postcode, entry_city, entry_state, entry_country_id, 	zone_code, blind_shipping, ups_validated, fedex_validated, ups_residential, fedex_residential, blind_ship_to, dropship_fee, dropship_fee_threshhold
		FROM address_book ab
		LEFT JOIN address_details ad ON ab.address_book_id = ad.address_book_id
		LEFT JOIN zones z on ab.entry_zone_id=z.zone_id
		WHERE ab.customers_id = '" . $this->id . "'";
		$result = mysqli_query($this->zendb, $sql);
		while ($address = mysqli_fetch_array($result)) { 
			
			$addresses12[] = array (
				'id' 				=>	$address['address_book_id'],
				'company' 			=>	$address['entry_company'],
				'firstname'			=>	$address['entry_firstname'],
				'lastname' 			=>	$address['entry_lastname'],
				'street1' 			=>	$address['entry_street_address'],
				'street2' 			=>	$address['entry_suburb'],
				'postcode'			=>	$address['entry_postcode'],
				'city'	 			=>	$address['entry_city'],
				'state' 			=>	($address['entry_country_id']=='223' ? $address['zone_code'] : $address['entry_state']),
				'bs' 				=>	$address['blind_shipping'],
				'ups_validated' 	=>	$address['ups_validated'],
				'fedex_validated' 	=>	$address['fedex_validated'],
				'ups_residential' 	=>	$address['ups_residential'],
				'fedex_residential' =>	$address['fedex_residential'],
				'blind_ship_to' 	=>	$address['blind_ship_to'],
				'ds_fee' 			=>	$address['dropship_fee'],
				'ds_fee_threshhold'	=>	$address['dropship_fee_threshhold']
			);
		}
		//echo json_encode($addresses);
		//$this->addresses = $addresses;
		//echo "<pre>";
		//print_r($addresses12);
		//echo "</pre>";
		return $addresses12;
	}

	public function setAddressId($address_book_id) {
		$this->address_book_id = $address_book_id;
        return $this;
	}

	public function setAddress($address) {
		$this->address = $address;
        return $this;
	}
	
	public function addAddress() {
		$zones = getZonesCode();
		$sql = "INSERT INTO address_book
			(customers_id, entry_company, entry_firstname, entry_lastname, entry_street_address, entry_suburb, entry_postcode, entry_city, entry_state, entry_country_id, entry_zone_id, blind_shipping)	
			VALUES( '". $id . "', '" .
				$address['company'] . "', '" .
				$address['firstname'] . "', '" .
				$address['lastname'] . "', '" .
				$address['street1'] . "', '" .
				$address['street2'] . "', '" .
				$address['postcode'] . "', '" .
				$address['city'] . "', '" .
				$address['entry_state'] . "', '" .
				$zones[$address['entry_state']]['country_id'] . "', '" .
				$zones[$address['entry_state']]['zone_id'] . "', '" .
				$address['bs'] . "')";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT ADD ADDRESS:' . mysqli_error($zendb);
		setAddressId(mysqli_insert_id($zendb));

		$sql = "INSERT INTO address_details
			(  address_book_id, ups_validated, fedex_validated, ups_residential, fedex_residential, blind_ship_to, dropship_fee, dropship_fee_threshhold )	
			VALUES( '". $address_book_id . "', '" .
				$address['ups_validated'] . "', '" .
				$address['fedex_validated'] . "', '" .
				$address['ups_residential'] . "', '" .
				$address['fedex_residential'] . "', '" .
				$address['blind_ship_to'] . "', '" .
				$address['dropship_fee'] . "', '" .
				$address['dropship_fee_threshhold'] . "')";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT ADD ADDRESS DETAILS:' . mysqli_error($zendb);

		return;
	}

	public function updateAddress() {
		$zones = getZonesCode();
		$sql = "UPDATE address_book SET
					customers_id = '" . $id . "',
					entry_company = '" . $address['company'] . "',
					entry_firstname = '" . $address['firstname'] . "',
					entry_lastname = '" . $address['lastname'] . "',
					entry_street_address = '" . $address['street1'] . "',
					entry_suburb = '" . $address['street2'] . "',
					entry_postcode = '" . $address['postcode'] . "',
					entry_city = '" . $address['city'] . "',
					entry_state = '" . $address['entry_state'] . "',
					entry_country_id = '" . $zones[$address['entry_state']]['country_id'] . "',
					entry_zone_id  = '" . $zones[$address['entry_state']]['zone_id'] . "',
					blind_shipping  = '" . $address['bs'] . "
				WHERE address_book_id='".  $address_book_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT UPDATE ADDRESS:' . mysqli_error($zendb);

		$sql = "UPDATE address_details SET
					ups_validated = '" . $address['ups_validated'] . "',
					fedex_validated = '" . $address['fedex_validated'] . "',
					ups_residential = '" . $address['ups_residential'] . "',
					fedex_residential = '" . $address['fedex_residential'] . "',
					blind_ship_to = '" . $address['blind_ship_to'] . "',
					dropship_fee = '" . $address['dropship_fee'] . "',
					dropship_fee_threshhold = '" . $address['dropship_fee_threshhold'] . "'
				WHERE address_book_id='".  $address_book_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT UPDATE ADDRESS DETAILS:' . mysqli_error($zendb);

		return;
	}

	public function deleteAddress() {
		$sql = "DELETE FROM address_book WHERE address_book_id='".  $address_book_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT DELETE ADDRESS:' . mysqli_error($zendb);

		$sql = "DELETE FROM address_details WHERE address_book_id='".  $address_book_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT DELETE ADDRESS DETAILS:' . mysqli_error($zendb);

		return;
	}

	public function setShipToAddress($address_id) {
		$this->ship_to_address = $address_id;
        return $this;
	}
	
	public function setBillToAddress($address_id) {
		$this->bill_to_address = $address_id;
        return $this;
	}


	public function getOrders() {
		$sql = "SELECT o.orders_id, customers_name, customers_company, customers_street_address, customers_suburb, customers_city, customers_postcode, customers_state, customers_country, customers_telephone, customers_email_address, delivery_name, delivery_company, delivery_street_address, delivery_suburb, delivery_city, delivery_postcode, delivery_state, delivery_country, billing_name, billing_company, billing_street_address, billing_suburb, billing_city, billing_postcode, billing_state, billing_country, payment_method, payment_module_code, shipping_method,	shipping_module_code, coupon_code, last_modified, date_purchased, orders_status, order_total, order_tax, ip_address, order_site, blind_shipping, shipping_comments, checkout_comments, 	collect_act, pono, warehouse_id, requested_ship_date, authorization, authorization_date, captured, captured_date, paid, special_production_instructions, special_shipping_instructions, order_notes_private, order_notes_public, transID, collect_acct, tracking_number, ship_address_id, ship_service_code, placed_by, confirmed, packaging_details
		FROM orders o
		LEFT JOIN orders_details odt on o.orders_id=odt.orders_id
		WHERE o.customers_id = '" . $this->id . "'";
		$result = mysqli_query($this->zendb, $sql);
		while ($order = mysqli_fetch_array($result)) { 
			$orders[$order['orders_id']] = array (
			'name'			=>	$order['customers_name'],
			'company'		=>	$order['customers_company'],
			'street1'		=>	$order['customers_street_address'],
			'street2'		=>	$order['customers_suburb'],
			'city'			=>	$order['customers_city'],
			'postcode'		=>	$order['customers_postcode'],
			'state'			=>	$order['customers_state'],
			'country'		=>	$order['customers_country'],
			'telephone'		=>	$order['customers_telephone'],
			'email'			=>	$order['customers_email_address'],
			'ship_name'		=>	$order['delivery_name'],
			'ship_company'	=>	$order['delivery_company'],
			'ship_street1'	=>	$order['delivery_street_address'],
			'ship_street2'	=>	$order['delivery_suburb'],
			'ship_city'		=>	$order['delivery_city'],
			'ship_zip'		=>	$order['delivery_postcode'],
			'ship_state'	=>	$order['delivery_state'],
			'ship_country'	=>	$order['delivery_country'],
			'bill_name'		=>	$order['billing_name'],
			'bill_company'	=>	$order['billing_company'],
			'bill_street1'	=>	$order['billing_street_address'],
			'bill_street2'	=>	$order['billing_suburb'],
			'bill_city'		=>	$order['billing_city'],
			'bill_zip'		=>	$order['billing_postcode'],
			'bill_state'	=>	$order['billing_state'],
			'bill_country'	=>	$order['billing_country'],
			'payment_method'	=>	$order['payment_method'],
			'payment_module'	=>	$order['payment_module_code'],
			'shipping_method'	=>	$order['shipping_method'],
			'shipping_module'	=>	$order['shipping_module_code'],
			'coupon_code'		=>	$order['coupon_code'],
			'last_modified'		=>	$order['last_modified'],
			'date_purchased'	=>	$order['date_purchased'],
			'orders_status'		=>	$order['orders_status'],
			'order_total'		=>	$order['order_total'],
			'order_tax'			=>	$order['order_tax'],
			'ip_address'		=>	$order['ip_address'],
			'order_site'		=>	$order['order_site'],
			'blind_ship'		=>	$order['blind_shipping'],
			'shipping_comments'	=>	$order['shipping_comments'],
			'checkout_comments'	=>	$order['checkout_comments'],
			'collect_act'		=>	$order['collect_act'],
			'pono'				=>	$order['pono'],
			'warehouse_id'		=>	$order['warehouse_id'],
			'ship_date'			=>	$order['requested_ship_date'],
			'authorization'		=>	$order['authorization'],
			'auth_date'			=>	$order['authorization_date'],
			'captured'			=>	$order['captured'],
			'captured_date'		=>	$order['captured_date'],
			'paid'				=>	$order['paid'],
			'production_instr'	=>	$order['special_production_instructions'],
			'shipping_instr'	=>	$order['special_shipping_instructions'],
			'notes_private'		=>	$order['order_notes_private'],
			'notes_public'		=>	$order['order_notes_public'],
			'transID'			=>	$order['transID'],
			'collect_acct'		=>	$order['collect_acct'],
			'tracking_number'	=>	$order['tracking_number'],
			'ship_address_id'	=>	$order['ship_address_id'],
			'ship_service_code'	=>	$order['ship_service_code'],
			'placed_by'			=>	$order['placed_by'],
			'confirmed'			=>	$order['confirmed'],
			'packaging_details'	=>	$order['packaging_details']
			);
		}
		$this->orders = $orders;
        return $this->orders;
	}

	public function setOrderId($order_id) {
		$this->order_id = $order_id;
        return $this;
	}

	public function setOrder($order) {
		$this->order = $order;
        return $this;
	}

	public function addOrder() {
		$sql = "INSERT INTO orders
			(customers_id, customers_name, customers_company, customers_street_address, customers_suburb, customers_city, customers_postcode, customers_state, customers_country, customers_telephone, customers_email_address, delivery_name, delivery_company, delivery_street_address, delivery_suburb, delivery_city, delivery_postcode, delivery_state, delivery_country, billing_name, billing_company, billing_street_address, billing_suburb, billing_city, billing_postcode, billing_state, billing_country, payment_method, payment_module_code, shipping_method,	shipping_module_code, coupon_code, last_modified, date_purchased, orders_status, order_total, order_tax, ip_address, order_site, blind_shipping, shipping_comments, checkout_comments, 	collect_act, pono )	
			VALUES( '" . 
			$id . "', '" .
			$order['customers_name'] . "', '" .
			$order['customers_company'] . "', '" .
			$order['customers_street_address'] . "', '" .
			$order['customers_suburb'] . "', '" .
			$order['customers_city'] . "', '" .
			$order['customers_postcode'] . "', '" .
			$order['customers_state'] . "', '" .
			$order['customers_country'] . "', '" .
			$order['customers_telephone'] . "', '" .
			$order['customers_email_address'] . "', '" .
			$order['delivery_name'] . "', '" .
			$order['delivery_company'] . "', '" .
			$order['delivery_street_address'] . "', '" .
			$order['delivery_suburb'] . "', '" .
			$order['delivery_city'] . "', '" .
			$order['delivery_postcode'] . "', '" .
			$order['delivery_state'] . "', '" .
			$order['delivery_country'] . "', '" .
			$order['billing_name'] . "', '" .
			$order['billing_company'] . "', '" .
			$order['billing_street_address'] . "', '" .
			$order['billing_suburb'] . "', '" .
			$order['billing_city'] . "', '" .
			$order['billing_postcode'] . "', '" .
			$order['billing_state'] . "', '" .
			$order['billing_country'] . "', '" .
			$order['payment_method'] . "', '" .
			$order['payment_module_code'] . "', '" .
			$order['shipping_method'] . "', '" .
			$order['shipping_module_code'] . "', '" .
			$order['coupon_code'] . "', '" .
			$order['last_modified'] . "', '" .
			$order['date_purchased'] . "', '" .
			$order['orders_status'] . "', '" .
			$order['order_total'] . "', '" .
			$order['order_tax'] . "', '" .
			$order['ip_address'] . "', '" .
			$order['order_site'] . "', '" .
			$order['blind_shipping'] . "', '" .
			$order['shipping_comments'] . "', '" .
			$order['checkout_comments'] . "', '" .
			$order['collect_act'] . "', '" .
			$order['pono'] . "')";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT ADD ORDER:' . mysqli_error($zendb);
		setOrderId(mysqli_insert_id($zendb));

		$sql = "INSERT INTO orders_details
			( orders_id, warehouse_id, requested_ship_date, authorization, authorization_date, captured, captured_date, paid, special_production_instructions, special_shipping_instructions, order_notes_private, order_notes_public, transID, collect_acct, tracking_number, ship_address_id, ship_service_code, placed_by, confirmed, packaging_details )	
			VALUES( '" . 
			$order['orders_id'] . "', '" .
			$order['warehouse_id'] . "', '" .
			$order['requested_ship_date'] . "', '" .
			$order['authorization'] . "', '" .
			$order['authorization_date'] . "', '" .
			$order['captured'] . "', '" .
			$order['captured_date'] . "', '" .
			$order['paid'] . "', '" .
			$order['special_production_instructions'] . "', '" .
			$order['special_shipping_instructions'] . "', '" .
			$order['order_notes_private'] . "', '" .
			$order['order_notes_public'] . "', '" .
			$order['transID'] . "', '" .
			$order['collect_acct'] . "', '" .
			$order['tracking_number'] . "', '" .
			$order['ship_address_id'] . "', '" .
			$order['ship_service_code'] . "', '" .
			$order['placed_by'] . "', '" .
			$order['confirmed'] . "', '" .
			$order['packaging_details'] . "')";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT ADD ORDER DETAILS:' . mysqli_error($zendb);

		return;
	}

	public function updateOrder() {
		$zones = getZonesCode();
		$sql = "UPDATE orders SET
					customers_id = '" . $id . "',
					customers_name = '" . $order['customers_name'] . "',
					customers_company = '" . $order['customers_company'] . "',
					customers_street_address = '" . $order['customers_street_address'] . "',
					customers_suburb = '" . $order['customers_suburb'] . "',
					customers_city = '" . $order['customers_city'] . "',
					customers_postcode = '" . $order['customers_postcode'] . "',
					customers_state = '" . $order['customers_state'] . "',
					customers_country = '" . $order['customers_country'] . "',
					customers_telephone = '" . $order['customers_telephone'] . "',
					customers_email_address = '" . $order['customers_email_address'] . "',
					delivery_name = '" . $order['delivery_name'] . "',
					delivery_company = '" . $order['delivery_company'] . "',
					delivery_street_address = '" . $order['delivery_street_address'] . "',
					delivery_suburb = '" . $order['delivery_suburb'] . "',
					delivery_city = '" . $order['delivery_city'] . "',
					delivery_postcode = '" . $order['delivery_postcode'] . "',
					delivery_state = '" . $order['delivery_state'] . "',
					delivery_country = '" . $order['delivery_country'] . "',
					billing_name = '" . $order['billing_name'] . "',
					billing_company = '" . $order['billing_company'] . "',
					billing_street_address = '" . $order['billing_street_address'] . "',
					billing_suburb = '" . $order['billing_suburb'] . "',
					billing_city = '" . $order['billing_city'] . "',
					billing_postcode = '" . $order['billing_postcode'] . "',
					billing_state = '" . $order['billing_state'] . "',
					billing_country = '" . $order['billing_country'] . "',
					payment_method = '" . $order['payment_method'] . "',
					payment_module_code = '" . $order['payment_module_code'] . "',
					shipping_method = '" . $order['shipping_method'] . "',
					shipping_module_code = '" . $order['shipping_module_code'] . "',
					coupon_code = '" . $order['coupon_code'] . "',
					last_modified = '" . $order['last_modified'] . "',
					date_purchased = '" . $order['date_purchased'] . "',
					orders_status = '" . $order['orders_status'] . "',
					order_total = '" . $order['order_total'] . "',
					order_tax = '" . $order['order_tax'] . "',
					ip_address = '" . $order['ip_address'] . "',
					order_site = '" . $order['order_site'] . "',
					blind_shipping = '" . $order['blind_shipping'] . "',
					shipping_comments = '" . $order['shipping_comments'] . "',
					checkout_comments = '" . $order['checkout_comments'] . "',
					collect_act = '" . $order['collect_act'] . "',
					pono = '" . $order['pono'] . "
				WHERE orders_id='".  $order_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT UPDATE ORDER:' . mysqli_error($zendb);
		$sql = "UPDATE orders_details SET
					warehouse_id =  '" . $order['warehouse_id'] . "',
					requested_ship_date =  '" . $order['requested_ship_date'] . "',
					authorization =  '" . $order['authorization'] . "',
					authorization_date =  '" . $order['authorization_date'] . "',
					captured =  '" . $order['captured'] . "',
					captured_date =  '" . $order['captured_date'] . "',
					paid =  '" . $order['paid'] . "',
					special_production_instructions =  '" . $order['special_production_instructions'] . "',
					special_shipping_instructions =  '" . $order['special_shipping_instructions'] . "',
					order_notes_private =  '" . $order['order_notes_private'] . "',
					order_notes_public =  '" . $order['order_notes_public'] . "',
					transID =  '" . $order['transID'] . "',
					collect_acct =  '" . $order['collect_acct'] . "',
					tracking_number =  '" . $order['tracking_number'] . "',
					ship_address_id =  '" . $order['ship_address_id'] . "',
					ship_service_code =  '" . $order['ship_service_code'] . "',
					placed_by =  '" . $order['placed_by'] . "',
					confirmed =  '" . $order['confirmed'] . "',
					packaging_details =  '" . $order['packaging_details'] . "
				WHERE orders_id='".  $order_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT UPDATE ORDER DETAILS:' . mysqli_error($zendb);

		return;
	}

	public function deleteOrder() {
		$sql = "DELETE FROM orders WHERE orders_id='".  $order_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT DELETE ORDER:' . mysqli_error($zendb);

		$sql = "DELETE FROM orders_details WHERE orders_id='".  $order_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT DELETE ORDER DETAILS:' . mysqli_error($zendb);

		return;
	}


	public function getOrderTotals() {
 		$sql = "SELECT orders_total_id, title, text, value, class, sort_order
		FROM orders_total
		WHERE orders_id = '" . $this->order_id . "'
		ORDER BY sort_order ASC";
		$result = mysqli_query($this->zendb, $sql);
		while ($order_total = mysqli_fetch_array($result)) {
			$order_totals[] = $order_total;
		}
		$this->order_totals = $order_totals;
        return $this->order_totals;
	}

	public function setOrderTotalId($order_total_id) {
		$this->order_total_id = $order_total_id;
        return $this;
	}

	public function setOrderTotal($order_total) {
		$this->order_total = $order_total;
        return $this;
	}

	public function addOrderTotal() {
		$sql = "INSERT INTO orders_total
			( orders_id, title, text, value, class, sort_order)	
			VALUES( '". 
				$order_id . "', '" .
				$order_total['title'] . "', '" .
				$order_total['text'] . "', '" .
				$order_total['value'] . "', '" .
				$order_total['class'] . "', '" .
				$order_total['sort_order'] . "')";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT ADD ORDER TOTAL:' . mysqli_error($zendb);
		setOrderTotalId(mysqli_insert_id($zendb));
		return;
	}

	public function updateOrderTotal() {
		$sql = "UPDATE orders_total SET
					orders_id = '" . $order_id . "',
					title = '" . $order_total['title'] . "',
					text = '" . $order_total['text'] . "',
					value = '" . $order_total['value'] . "',
					class = '" . $order_total['class'] . "',
					sort_order  = '" . $order_total['sort_order'] . "
				WHERE orders_total_id='".  $order_total_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT UPDATE ORDERS TOTAL:' . mysqli_error($zendb);
		return;
	}
	
	public function deleteOrderTotal() {
		$error="";
		$sql = "DELETE FROM order_totals WHERE orders_total_id='".  $order_total_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT DELETE ORDER TOTAL:' . mysqli_error($zendb);

		return;
	}


	public function getOrderProducts() {
 		$sql = "SELECT orders_products_id, products_id, products_model, products_name, products_price, final_price, products_tax, products_quantity
		FROM orders_products
		WHERE orders_id = '" . $this->order_id . "' 
		ORDER BY products_model ASC"; //warehouse_id,  for v2.2
		$result = mysqli_query($this->zendb, $sql);
		while ($order_product = mysqli_fetch_array($result)) {
			$order_products[] = $order_product;
		}
		$this->order_products = $order_products;
        return $this->order_products;
	}
	
	public function setOrderProductsId($order_product_id) {
		$this->order_product_id = $order_product_id;
        return $this;
	}

	public function setOrderProduct($order_product) {
		$this->order_product = $order_product;
        return $this;
	}

	public function addOrderProduct() {
		$sql = "INSERT INTO orders_products
			( orders_id, products_id, warehouse_id, products_model, products_name, products_price, final_price, products_tax, products_quantity)	
			VALUES( '". 
				$order_id . "', '" .
				$order_product['products_id'] . "', '" .
				$order_product['warehouse_id'] . "', '" .
				$order_product['products_model'] . "', '" .
				$order_product['products_name'] . "', '" .
				$order_product['products_price'] . "', '" .
				$order_product['final_price'] . "', '" .
				$order_product['products_tax'] . "', '" .
				$order_product['products_quantity'] . "')";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT ADD ORDER PRODUCT:' . mysqli_error($zendb);
		setOrderProductsId(mysqli_insert_id($zendb));
		return;
	}

	public function updateOrderProduct() {
		$sql = "UPDATE orders_products SET
					orders_id = '" . $order_id . "',
					products_id = '" . $order_product['products_id'] . "',
					warehouse_id = '" . $order_product['warehouse_id'] . "',
					products_model = '" . $order_product['products_model'] . "',
					products_name = '" . $order_product['products_name'] . "',
					products_price = '" . $order_product['products_price'] . "',
					final_price = '" . $order_product['final_price'] . "',
					products_tax = '" . $order_product['products_tax'] . "',
					products_quantity  = '" . $order_product['products_quantity'] . "
				WHERE orders_products_id='".  $order_product_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT UPDATE ORDERS TOTAL:' . mysqli_error($zendb);
		return;
	}

	public function deleteOrderProduct() {
		$sql = "DELETE FROM orders_products WHERE orders_product_id='".  $order_product_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT DELETE ORDER PRODUCT:' . mysqli_error($zendb);
		return;
	}


	public function getOrderStatusHistories() {
 		$sql = "SELECT orders_status_id, date_added, customer_notified, comments
		FROM orders_status_history
		WHERE orders_id = '" . $this->order_id . "'
		ORDER BY date_added ASC";
		$result = mysqli_query($this->zendb, $sql);
		while ($order_status_history = mysqli_fetch_array($result)) {
			$order_status_histories[] = $order_status_history;
		}
		$this->order_status_histories = $order_status_histories;
        return $this->order_status_histories;
	}

	public function setOrderStatusHistoryId($order_status_history_id) {
		$this->order_status_history_id = $order_status_history_id;
        return $this;
	}

	public function setOrderStatusHistory($order_status_history) {
		$this->order_status_history = $order_status_history;
        return $this;
	}

	public function addOrderStatusHistory() {
		$sql = "INSERT INTO orders_status_history
			( orders_id, orders_status_id, date_added, customer_notified, comments)	
			VALUES( '". 
				$order_id . "', '" .
				$order_status_history['orders_status_id'] . "', '" .
				$order_status_history['date_added'] . "', '" .
				$order_status_history['customer_notified'] . "', '" .
				$order_status_history['comments'] . "')";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT ADD ORDER STATUS HISTORY:' . mysqli_error($zendb);
		order_status_history_id(mysqli_insert_id($zendb));
		return;
	}

	public function updateOrderStatusHistory() {
		$sql = "UPDATE orders_status_history SET
					orders_id = '" . $order_id . "',
					orders_status_id = '" . $order_status_history['orders_status_id'] . "',
					date_added = '" . $order_status_history['date_added'] . "',
					customer_notified = '" . $order_status_history['customer_notified'] . "',
					comments  = '" . $order_status_history['comments'] . "
				WHERE order_status_history_id='".  $order_status_history_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT UPDATE ORDER STATUS HISTORY:' . mysqli_error($zendb);
		return;
	}

	public function deleteOrderStatusHistory() {
		$sql = "DELETE FROM orders_status_history WHERE orders_status_history_id='".  $order_status_history_id . "'";
		$result = mysqli_query($zendb, $sql);
		if (!$result) return $sql . '<br>COULD NOT DELETE ORDER STATUS HISTORY:' . mysqli_error($zendb);
		return;
	}
	
	public function changePassword($plain_text) {
		$password = '';
		for($i = 0; $i < 40; $i ++) {
			$password .= mt_rand();
		}
		$salt = hash('sha256', $password);
		$password = hash('sha256', $salt . $plain_text) . ':' . $salt;
		$sql = "UPDATE `customers` 
		SET `customers_password` = '" . $password . "'  
		WHERE `customers_id` = " . $this->id;
		$result = mysqli_query($this->zendb, $sql);
		if (!$result) die($sql . '<br>COULD NOT UPDATE PASSWORD:' . mysqli_error($this->zendb));
		return "Sucessfully changed password for customer id: $this->id";
	}	

/*	public function recalculateShipping($packages) {
		
		$packages[]= array(
			'weight' 	=> $_POST["{$boxprefix}weight{$i}"],
			'commodity'	=> $_POST["{$boxprefix}commodity{$i}"],
			'length'	=> $_POST["{$boxprefix}length{$i}"],
			'width'		=> $_POST["{$boxprefix}width{$i}"],
			'height'	=> $_POST["{$boxprefix}height{$i}"]
		);

	}
	
	public function recalculateOrder() {
		getCustomer();
		getOrderProducts();
		getOrderTotals(); 
		//Subtotal
		//Discount Applied
		//Coupon
		//Tax
		//Shipping ...calc has already been done
		return $_orderTotals; //temp total. Must commit to db (order totals and orders)
	}
*/
}

class shipping {
	protected $shipment;					// shipment array
	protected $packages;					// packages array
	protected $errors;						// errors array
	protected $alerts;						// alerts array
	protected $rates;						// rates array

	public function setShipment($shipment) {
		$this->shipment = $shipment;
        return $this;
	}
	public function setPackages($packages) {
		$this->packages = $packages;
        return $this;
	}
	

	function getUpsRates() { // GET UPS RATES
		require_once('..\shipping\UPSFunctions.php');
		$alerts = array();
		$markup = (1 + $this->shipment['mark_up']/100) * (1 + $this->shipment['ds_fee']/100);
		$this->shipment['rate_type'] = 'Shoptimeintransit';
		$ups_shipping_rate = get_ups_rate($this->shipment, $this->packages);
	
		//PARSE RETURNED DATA
		if (is_soap_fault($ups_shipping_rate)) {
			$this->errors[] = array ('rator' => 'ups', 'data' => $ups_shipping_rate->detail->Errors->ErrorDetail->PrimaryErrorCode->Description );
			var_dump($ups_shipping_rate);
		}
		else {
			if (isset($ups_shipping_rate->Service)) $ups_rates[] = $ups_shipping_rate;  //One rate returned...make into an array before itterating
			else $ups_rates = $ups_shipping_rate;
			foreach ($ups_rates as $rate){
				if (isset($rate->RatedShipmentAlert)) { //There are Alerts! 
					if (isset($rate->RatedShipmentAlert->Code))  
						$this->alerts[] = array ('rator' => 'ups', 'data' => $rate->RatedShipmentAlert->Description);
					else {
						foreach ($rate->RatedShipmentAlert as $ups_alert) {
							$this->alerts[] = array ('rator' => 'ups', 'data' => $ups_alert->Description);
						}
					}
				}
				$this->rates_returned[] = array(
					'rator' 			=> 'ups',
					'service_code' 		=> (string)$rate->Service->Code,
					'service' 			=> $upsservice_level[(string)$rate->Service->Code],
					'transit'			=> $rate->TimeInTransit->ServiceSummary->EstimatedArrival->BusinessDaysInTransit,
					'listPrice'			=> number_format( $rate->TotalCharges->MonetaryValue, 2, '.', ''),
					'negotiatedRate'	=> number_format( $rate->NegotiatedRateCharges->TotalCharge->MonetaryValue * (1+$markup), 2, '.', '')
				);
				if ((string)$rate->Service->Code =='03') $ground_time_in_transit = $rate->TimeInTransit->ServiceSummary->EstimatedArrival->BusinessDaysInTransit;
			}
		}
		return array ('errors' => $this->errors, 'alerts' => $this->alerts, 'rates' => $this->rates_returned);
	}

	function getUpsGfRates() { //GET UPS GROUND FREIGHT RATES
		require_once('..\shipping\UPSFunctions.php');
		$markup = (1 + $this->shipment['mark_up']/100) * (1 + $this->shipment['ds_fee']/100);
		$markup_gf_only=1.1;
		$this->shipment['shipping_code'] = '03';
		$this->shipment['rate_type'] = 'RATE';
		$this->shipment['gfp'] = (bool) 1;
		$upsgf_shipping_rate = get_ups_rate($this->shipment, $this->packages);

		//PARSE RETURNED DATA
		if (is_soap_fault($upsgf_shipping_rate)) {
			$this->errors[] = array ('rator' => 'upsgf', 'data' => $ups_shipping_rate->detail->Errors->ErrorDetail->PrimaryErrorCode->Description );
		}
		else {
			$this->rates_returned[] = array(
				'rator' 			=> 'upsgf',
				'service_code' 			=> '03',
				'service' 			=> 'UPS Ground Freight',
				'transit'			=> '',
				'listPrice'			=> number_format( $upsgf_shipping_rate,2,'.',','),
				'negotiatedRate'	=> number_format( $upsgf_shipping_rate * $markup * $markup_gf_only,2,'.',',')
				);
		}		
		return array ('errors' => $this->errors, 'alerts' => $this->alerts, 'rates' => $this->rates_returned);
	}

	function getFedexRates() { //GET FEDEX RATES
		require_once('..\shipping\FedexFunctions.php');
		$markup = (1 + $this->shipment['mark_up']/100) * (1 + $this->shipment['ds_fee']/100);
		$this->shipment['rate_type'] = 'SHOP'; //Comment out so that it is 'RATE'... testing only. getallrates should always be shopping
		$fedex_shipping_rate = get_fedex_rate2($this->shipment, $this->packages);

		//PARSE RETURNED DATA
		$days = array('ONE_DAY' => 1, 'TWO_DAYS' => 2, 'THREE_DAYS' => 3, 'FOUR_DAYS' => 4, 'FIVE_DAYS' => 5, 'SIX_DAYS' => 6);
		if (is_soap_fault($fedex_shipping_rate) ){
			$this->errors[] = array ('rator' => 'fedex', 'data' => $fedex_shipping_rate );
		}
		else {
			if ($fedex_shipping_rate->HighestSeverity == 'WARNING') {
				$this->errors[] = array ('rator' => 'fedex', 'data' => $fedex_shipping_rate->Notifications->Message );
			}
			if ($this->shipment['rate_type'] =='SHOP') {
				foreach ($fedex_shipping_rate->RateReplyDetails as $rates) {
					if (isset($rates->RatedShipmentDetails->ShipmentRateDetail)) $rate = $rates->RatedShipmentDetails->ShipmentRateDetail->TotalNetCharge->Amount;
					else $rate = $rates->RatedShipmentDetails[0]->ShipmentRateDetail->TotalNetCharge->Amount;
					$this->rates_returned[] = array(
						'rator' 			=> 'fedex',
						'service_code' 		=> $rates->ServiceType,
						'service' 			=> $fedexservice_level[$rates->ServiceType],
						'transit'			=> (isset($rates->DeliveryTimestamp) ? substr($rates->DeliveryTimestamp,5,11) : (isset($rates->TransitTime) ? $days[$rates->TransitTime] . ($rates->TransitTime=='1'?' day':' days'):'')),
						'listPrice'			=> 'NA',
						'negotiatedRate'	=> number_format( $rate * $markup ,2,'.',',')
					);
				}
			}
			else {  //This is used for testing only. getallrates should always be shopping
				$this->rates_returned[] = array(
					'rator' 			=> 'fedex',
					'service_code'		=> 'NA',
					'service' 			=> 'Shopped rate',
					'transit'			=> '',
					'listPrice'			=> 'NA',
					'negotiatedRate'	=> number_format( $fedex_shipping_rate * $markup ,2,'.',',')
				);		
			}
		}
		return array ('errors' => $this->errors, 'alerts' => $this->alerts, 'rates' => $this->rates_returned);
	}

	function getUspsRates() { //GET USPS RATES (DONT RUN FOR MORE THAN 10 PACKAGES. USPS is too slow)
		require_once('..\shipping\StampsFunctions.php');
		$package_count=count($this->packages);
		$markup = (1 + $this->shipment['mark_up']/100) * (1 + $this->shipment['ds_fee']/100);
		if ($package_count<11) $usps_shipping_rate=get_stamps_rates($this->shipment, $this->packages);
		else $usps_shipping_rate='NONE';

		//PARSE RETURNED DATA
		if ($usps_shipping_rate<>'NONE') {  //DONT RUN FOR MORE THAN 10 PACKAGES. USPS is too slow
			if (is_soap_fault($usps_shipping_rate) || isset($usps_shipping_rate['error'])){
				$this->errors[] = array ('rator' => 'usps', 'data' => $usps_shipping_rate->detail->sdcerror );
			}
			else {
				foreach ($uspsservice_level as $service => $details){
					if (isset($usps_shipping_rate[$service])) {
						$this->rates_returned[] = array(
							'rator' 			=> 'usps',
							'service_code'		=> $service,
							'service' 			=> $uspsservice_level[$service]['service_text'],
							'transit'			=> $usps_shipping_rate[$service]['Transit'] . ' day' . ($usps_shipping_rate[$service]['Transit']=='1'?'':'s'),
							'listPrice'			=> 'NA',
							'negotiatedRate'	=> number_format( $usps_shipping_rate[$service]['Amount'] * $markup,2,'.',',')
						);		
					}
				}
			}
		}
		else {
			$this->errors[] = array ('rator' => 'usps', 'data' => 'MORE THAN 10 PACKAGES. USPS NOT QUOTED' );
		}
		return array ('errors' => $this->errors, 'alerts' => $this->alerts, 'rates' => $this->rates_returned);
	}

}
?>
