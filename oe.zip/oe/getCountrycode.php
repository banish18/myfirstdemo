<?php
require_once( '../db/db.inc' );

function getcountriesCode($country_id) {
	$sql = "SELECT  * FROM countries where countries_id'".$country_id."'";
		$result = mysqli_query($zendb, $sql);
		while ($country = mysqli_fetch_array($result)) { 
			$countries[$country['countries_id']] = array (
				'country_name'	=>	$country['countries_name'],
				'country_code' 	=>	$country['countries_iso_code_2']
			);
		}
		return $countries;
}
