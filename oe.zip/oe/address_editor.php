<?php
ini_set('memory_limit','256M');
// DataTables PHP library
include( "../lib/dataTables/php/DataTables.php" );
 
// Alias Editor classes so they are easy to use
use
    DataTables\Editor,
    DataTables\Editor\Field,
    DataTables\Editor\Format,
    DataTables\Editor\Mjoin,
    DataTables\Editor\Options,
    DataTables\Editor\Upload,
    DataTables\Editor\Validate,
    DataTables\Editor\ValidateOptions;
 
// Build our Editor instance and process the data coming from _POST
Editor::inst( $db2, 'address_book', 'address_book_id' )
    ->fields(
        Field::inst( 'address_book.address_book_id' )
            ->validator( Validate::notEmpty( ValidateOptions::inst()
			->message( 'An Item ID is required' ) 
            ) ),
//Hidden items that have defaults
//Visible items that are not edited directly
        Field::inst( 'address_book.customers_id' ),
//Visible items that are edited
        Field::inst( 'address_book.entry_gender' ),
        Field::inst( 'address_book.entry_company' ),
        Field::inst( 'address_book.entry_firstname' ),
        Field::inst( 'address_book.entry_lastname' ),
        Field::inst( 'address_book.entry_street_address' ),
        Field::inst( 'address_book.entry_suburb' ),
        Field::inst( 'address_book.entry_postcode' ),
        Field::inst( 'address_book.entry_city' ),
        Field::inst( 'address_book.entry_state' ),
        Field::inst( 'zones.zone_code' ),
        Field::inst( 'countries.countries_iso_code_2' ),
        Field::inst( 'address_book.blind_shipping' ),
		Field::inst( 'address_details.ups_validated' ),
		Field::inst( 'address_details.fedex_validated' ),
		Field::inst( 'address_details.ups_residential' ),
		Field::inst( 'address_details.fedex_residential' ),
		Field::inst( 'address_details.blind_ship_to' ),
		Field::inst( 'address_details.dropship_fee' ),
        Field::inst( 'address_details.dropship_fee_threshhold' )
    )

    ->leftJoin( 'address_details', 'address_details.address_book_id', '=', 'address_book.address_book_id' )
    ->leftJoin( 'zones', 'zones.zone_id', '=', 'address_book.entry_zone_id' )
    ->leftJoin( 'countries', 'countries.countries_id', '=', 'address_book.entry_country_id' )
    ->where( 'address_book.customers_id', $_POST['customer_id'] )
    ->process( $_POST )
    ->json();

 