 $(document).ready(function() {
	 /* password reset */
		$("#save_password").click(function() {
			var validator = $("#form-reset").validate({
			rules: {
				 new_password: {
                                required: true,
                                pwcheck: true,
                                minlength: 8
                            },
				 confirm_password: {
						equalTo: "#password"
					}
				},
				messages: {
					 new_password: {
                                required: "Enter password",
                                pwcheck: "Password must contain at least one number, one lowercase and character !!",
                                minlength: "Password must contain at least Eight characters"
                            },
					confirm_password: " Enter Confirm Password Same as Password"
				}
			});
			$.validator.addMethod("pwcheck", function(value) {
				return /^[A-Za-z0-9\d=!\-@#$%=._*]*$/.test(value) // consists of only these
					&& /[a-z]/.test(value) // has a lowercase letter
					&& /\d/.test(value) // has a digit
			});
			if (validator.form()) {
				var form_data = $('#form-reset').serialize();
					jQuery.ajax({
						method: "POST",
						url: "ajax.php",
						dataType:"json",
						data: { 
									form_data,
									act:"CustomerDetail",
									method:"passwordReset"
							}
					}).done(function(response) {
						swal({title: response, type: "success"}).then(() => {
									$("#cancel_reset").click();
									$("#form-reset").trigger("reset");
								}
							);
						
					});
				
			}
			
		});
	 
	 /* date picker */
	 
		$('#customers_resale_tax_id_date').datepicker({ dateFormat: 'yy-mm-dd' });
		
	/* reset form */
		
		$("#reset_form").click(function(){
			$("#customer_detail").trigger("reset");
			$("#customer_search_name").val("");
			$("#customer_search_address").val();
			localStorage.removeItem("customer_emailaddress");
			resetData();
			location.reload();
		});
	 
	 /* character allowed on text box validation */
	 
       $("#customers_firstname,#customers_lastname,#first_name,#last_name,#city").keypress(function (event) {
			var inputValue = event.which;
			// allow letters and whitespaces only.
			if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)) { 
				event.preventDefault(); 
			}
	   });
		
	/* display default toggle on blind ship checked */
	
		$("#blind-ship").on("click",function() {
			var chkchecked = document.getElementById("blind-ship"); 
			if (chkchecked.checked) {
				$("#blind_by_default").css("display","block");
			}
			else
			{
				$("#blind_by_default").css("display","none");
			}
		});
		
		
	/* phone number and fax format and lenght validation */
		
		$("#customers_fax").keypress(function() {
			var tval = jQuery(this).val();
			var	tlength = tval.length;
			set = 15,
				remain = parseInt(set - tlength);
			if (remain <= 0 && e.which !== 0 && e.charCode !== 0) {
				return false;
			}
			var input = $('#customers_fax')
			input.mobilePhoneNumber({allowPhoneWithoutPrefix: '+1'});
		});
		
		$("#customers_telephone").keypress(function() {
			var tval = jQuery(this).val();
			var	tlength = tval.length;
			set = 15,
				remain = parseInt(set - tlength);
			if (remain <= 0 && e.which !== 0 && e.charCode !== 0) {
				return false;
			}
			var input = $('#customers_telephone')
			input.mobilePhoneNumber({allowPhoneWithoutPrefix: '+1'});
		});
		
	/* save button click validate the form field */ 	
	   
	   $("#save_customer,#insert_cusform").click(function() {
		   var fname = $("#customers_firstname").val();
		   var lname = $("#customers_lastname").val();
		   var tel 	 = $("#customers_telephone").val();
		   var email = $("#customers_email_address").val();
		   var address = $("#address").val();
		   var error = 0;
		   if(fname == "")
		   {
			 $("#customers_firstname").next(".error").css("display","block"); 
			 var error = 1; 
		   }
		   
		   if(lname == "")
		   {
			 $("#customers_lastname").next(".error").css("display","block");
			 var error = 1; 
		   }
		   
		   if(tel == "")
		   {
			 $("#customers_telephone").next(".error").css("display","block");
			 var error = 1; 
		   }
		   
		   if(email == "")
		   {
			 $("#customers_email_address").next(".error").css("display","block"); 
			 var error = 1;
		   }
		   if($("#ship-collect").prop("checked") == true){
			   
			   var ups_acct = $("#customers_ups_acct").val();
			   var fedex_acct = $("#customers_fedex_acct").val();

                if(ups_acct == "")
				{
					if(fedex_acct == "")
					{
						 $("#customers_ups_acct").next(".error").css("display","block");
						 var error = 1;
					}
					else
					{
						 $("#customers_ups_acct").next(".error").css("display","none");
						 var error = 0;
					}
				}
				else if(fedex_acct == "")
				{
					if(ups_acct == "")
					{
						 $("#customers_ups_acct").next(".error").css("display","block");
						 var error = 1;
					}
					else
					{
						 $("#customers_ups_acct").next(".error").css("display","none");
						 var error = 0;
					}
				}
				else
				{
				}
			}
		   
		   if(error == 0)
		   {
			   var form_data = $('#customer_detail').serialize();
										
			   jQuery.ajax({
					method: "POST",
					url: "ajax.php",
					dataType:"json",
					data: { 
								form_data,
								act:"CustomerDetail",
								method:"savecustomer"
						}
				}).done(function(response) {
					if(response == 1)
					{
						
						swal({title: "Customer detail successfully added !!", type: "success"}).then(() => {
								localStorage.setItem("customer_emailaddress",email);
							    location.reload();
							}
						);
					}
					else
					{
						swal({title: "Customer already exist !!", type: "error"}).then(() => {
								location.reload();
							}
						);
					}
				});
					
			}
		});
		
	 /* input field blur validation event */ 
		
	   $("#customers_firstname,#customers_lastname,#customers_telephone,#first_name,#last_name,#customeraddress,#city,#state,#zipcode,#country,#customers_ups_acct,#update_state,#update_city,#update_customeraddress,#update_Company,#update_first_name,#update_last_name,#update_zipcode").blur(function(){
			if($(this).val() != "")
			{
				$(this).next(".error").css("display","none");
			}
	  });
	   
	 /* email format validation */
	  
		var email_regx = /^\w+([-+.'][^\s]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/;
		jQuery("#customers_email_address").blur(function() {
			if(jQuery(this).val() != "")
			{
				var email = jQuery(this).val();
				if (!(email_regx.test(email)))
				{
					jQuery(this).val("");
					jQuery(this).next(".error").text("Please enter valid email address");
					jQuery(this).next(".error").css("display","block");
				}
				else
				{
					jQuery(this).next(".error").css("display","none"); 
				}
			}
		});
		
		$("#orderHistory-tab").click(function(){
			var cid = $("#customer_id_head").text();
			getordercustomerData(cid);
		});

	 
	  /* textbox field blur check empty value */
	 
		$(".customers_telephone,#customers_fax,#customers_resale_tax_id,#customers_ups_acct,#customers_fedex_acct").keypress(function(e) {
			if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
				return false;
			}
		});
	 /* customer search result */
		$('#customer_search').autocomplete({
			source: 'oeFunctions.php?do=lookUpCustomer',
			minLength: 3,//search after three characters
			select: function(event,ui){
				$('#customer_id').val(ui.item.id);
				get_address(ui.item.id);
				$(".address_form").css("display","none");
				$("#address_data").trigger("reset");
				$("#update_address").css("display","none");
				$("#update_address").trigger("reset");
				return false;
			}
		});
		
		$(".custom-select").change(function(){
			 $("#contry_id_per").val($(this).val());
		});
		
		 $(".cstate").autocomplete({
			source: function(request, response) {
				$.ajax({
					url: 'oeFunctions.php',
					dataType: "json",
					 
					data: {
						'do'   : 'lookUpState',
						term : request.term,
						cont : $("#country").val()
					},
					success: function(data) {
						response(data);
					}
				});
			},
			min_length: 1,
			delay: 300
		});
		
		 $("#update_state").autocomplete({
			source: function(request, response) {
				$.ajax({
					url: 'oeFunctions.php',
					dataType: "json",
					 
					data: {
						'do'   : 'lookUpState',
						term : request.term,
						cont : $("#update_country").val()
					},
					success: function(data) {
						response(data);
					}
				});
			},
			min_length: 1,
			delay: 300
		});
			
		
		/* Customer Address */
		
		//var cisd = getCid();
		/* customer search result */
		/*$('.cstate').autocomplete({
			source: 'oeFunctions.php?do=lookUpState&cont='+getCid()+'',
			minLength: 1,//search after three characters
			select: function(event,ui){
				$('#state').val(ui.item.name);
				return false;
			}
		});*/
		
		 /* product search result */
		/*$('#sku_search').autocomplete({
			source: 'oeFunctions.php?do=lookUpProduct',
			minLength: 3,//search after three characters
			select: function(event,ui){
				$('#product_id').val(ui.item.id);
				get_product(ui.item.id);
				return false;
			}
		});*/
	
	/* add address event */
		
		$("#add_address").click(function() {
			$("#address_data").trigger("reset");
			$(".address_form").css("display","block");
			$(".address_detail").css("display","none");
			
		});
		
	/* address confirm event */
	var address = "";address_selected = "";
	jQuery(document).on("click" ,"#suggestion-confirm,.suggested_address,#suggestion-cancel",function(){
		{
			
			if(jQuery(this).hasClass('suggested_address'))
			{
				address = jQuery(this).val();
				if(jQuery(this).hasClass('user_entered_adddress'))
				{
					address_selected = "user_entered_adddress";
				}
				else
				{
					address_selected = "fedex_suggestion";
				}
				jQuery('.suggestion-confirm').addClass('btn-primary');
				jQuery('.suggestion-confirm').attr('data-dismiss','modal');
			}
			else if(jQuery(this).hasClass('suggestion-confirm'))
			{
				if(jQuery(this).hasClass('btn-primary'))
				{
					var res = address.split(", ");
					jQuery('#customeraddress').val(res[0]);
					jQuery('#city').val(res[1]);
					jQuery('#state').val(res[2]);
					jQuery('#zipcode').val(res[3]);
					if(address_selected=="user_entered_adddress")
					{
						jQuery("#fedex_validated").val(0);
						
					}
					else if(address_selected == "fedex_suggestion")
					{
						jQuery("#fedex_validated").val(1);
						
					}				
					var form_data = $('#address_data').serialize();
										
					jQuery.ajax({
							method: "POST",
							url: "ajax.php",
							dataType:"json",
							data: { 
										form_data,
										suggested:"suggested_address",
										act:"CustomerDetail",
										method:"saveaddress"
								  }
					}).done(function(response) {
						jQuery('.loader-overlay').css('visibility','hidden');
						swal({title: response, type: "success"}).then(() => {
								location.reload();
							}
						);
					});	
				}			
			}
						
		}
		});
		
		/* update confrm address event */
		
		jQuery(document).on("click" ,"#update_suggestion_confirm,.suggested_address,#suggestion-cancel",function(){
		{
			
			if(jQuery(this).hasClass('suggested_address'))
			{
				address = jQuery(this).val();
				if(jQuery(this).hasClass('user_entered_adddress'))
				{
					address_selected = "user_entered_adddress";
				}
				else
				{
					address_selected = "fedex_suggestion";
				}
				jQuery('.suggestion-confirm').addClass('btn-primary');
				jQuery('.suggestion-confirm').attr('data-dismiss','modal');
			}
			else if(jQuery(this).hasClass('suggestion-confirm'))
			{
				if(jQuery(this).hasClass('btn-primary'))
				{
					var res = address.split(", ");
					jQuery('#update_customeraddress').val(res[0]);
					jQuery('#update_city').val(res[1]);
					jQuery('#update_state').val(res[2]);
					jQuery('#update_zipcode').val(res[3]);
					if(address_selected=="user_entered_adddress")
					{
						jQuery("#fedex_validated").val(0);
						
					}
					else if(address_selected == "fedex_suggestion")
					{
						jQuery("#fedex_validated").val(1);
						
					}				
					var form_data = $('#update_address').serialize();
										
					jQuery.ajax({
						method: "POST",
						url: "ajax.php",
						dataType:"json",
						data: { 
									form_data,
									suggested:"suggested_address",
									act:"CustomerDetail",
									method:"updateAddress"
							}
					}).done(function(response) {
						jQuery('.loader-overlay').css('visibility','hidden');
						swal({title: response, type: "success"}).then(() => {
								location.reload();
							}
						);
					});	
				}			
			}
						
		}
		});
		
		/* save address event */
		$("#save_customer_detail").click(function() {
		   var first_name = $("#first_name").val();
		   var last_name = $("#last_name").val();
		   var address 	 = $("#customeraddress").val();
		   var city = $("#city").val();
		   var state = $("#state").val();
		   var zipcode = $("#zipcode").val();
		   var country = $("#country").val();
		   var error = 0;
		   if(first_name == "")
		   {
			 $("#first_name").next(".error").css("display","block"); 
			 var error = 1; 
		   }
		   
		   if(last_name == "")
		   {
			 $("#last_name").next(".error").css("display","block");
			 var error = 1; 
		   }
		   
		   if(address == "")
		   {
			 $("#customeraddress").next(".error").css("display","block");
			 var error = 1; 
		   }
		   
		   if(city == "")
		   {
			 $("#city").next(".error").css("display","block"); 
			 var error = 1;
		   }
		   if(state == "")
		   {
			 $("#state").next(".error").css("display","block");
			 var error = 1; 
		   }
		   
		   if(zipcode == "")
		   {
			 $("#zipcode").next(".error").css("display","block");
			 var error = 1; 
		   }
		   
		   if(country == "")
		   {
			 $("#country").next(".error").css("display","block"); 
			 var error = 1;
		   }
		   
		   
		   
		   if(error == 0)
		   {
			  jQuery('.loader-overlay').css('visibility','visible');
			  if(jQuery('#country').val()=="223")
				{   
					
				jQuery.ajax({
							method: "POST",
							url: "ajax.php",
							dataType:"json",
							data: { 
										company: jQuery('#Company').val(),							
										name: jQuery('#first_name').val()+" "+jQuery('#last_name').val(),							
										street_address1: jQuery('#customeraddress').val(),							
										street_address2: jQuery('#address2').val(),
										city: jQuery('#city').val(),
										state: jQuery('#state').val(),							
										zone_id: jQuery('#stateZone').val(),							
										postcode: jQuery('#zipcode').val(),
										country: jQuery('#country').val(),
										act:"AddressValidation",
										method:"ValidateAddress"
									}
							}).done(function(response) {
								
								if(response.ResidentialStatus=="RESIDENTIAL")
								{
									jQuery("#fedex_residential").val(1);
								}
								else if(response.ResidentialStatus=="BUSINESS")
								{
									jQuery("#fedex_residential").val(2);
								}
								else
								{
									jQuery("#fedex_residential").val(0);
								}
								if(response.UPSScore==1)
								{
									jQuery("#ups_validated").val(1);								
									jQuery("#ups_residential").val(1);
								}
								
								if(response.Score == 100)
								{							
									jQuery("#fedex_validated").val(1);
									var form_data = $('#address_data').serialize();
										
									jQuery.ajax({
										method: "POST",
										url: "ajax.php",
										dataType:"json",
										data: { 
													form_data,
													suggested:"",
													act:"CustomerDetail",
													method:"saveaddress"
											}
									}).done(function(response) {
										jQuery('.loader-overlay').css('visibility','hidden');
										swal({title: response, type: "success"}).then(() => {
												location.reload();
											}
										);
									});	
								}
								else if(response.Score > 75)
								{
									jQuery('.loader-overlay').css('visibility','hidden');										
									jQuery('#suggestionmodel .modal-body').html(response.suggestion);	
									jQuery('.suggestion-btn-info').trigger('click');						
								}
								else if(response.Score == 0 || response.Score<=75 )
								{
									jQuery('.loader-overlay').css('visibility','hidden');
									jQuery('.error-btn-info').trigger('click');							
								}
								else if(response.Score > 90)
								{
									var form_data = $('#address_data').serialize();
										
									 jQuery.ajax({
											method: "POST",
											url: "ajax.php",
											dataType:"json",
											data: { 
														form_data,
														suggested:"",
														act:"CustomerDetail",
														method:"saveaddress"
												  }
										}).done(function(response) {
											jQuery('.loader-overlay').css('visibility','hidden');
											swal({title: response, type: "success"}).then(() => {
													location.reload();
												}
											);
										});	
										
								}      
								
							});
				return false;
			}
			else
			{
				var form_data = $('#address_data').serialize();
										
				 jQuery.ajax({
						method: "POST",
						url: "ajax.php",
						dataType:"json",
						data: { 
									form_data,
									suggested:"",
									act:"CustomerDetail",
									method:"saveaddress"
							  }
					}).done(function(response) {
						jQuery('.loader-overlay').css('visibility','hidden');
						swal({title: response, type: "success"}).then(() => {
								location.reload();
							}
						);
					});	
				return true;
			}
			  
				
				
		   }
		});
		
		
		/* save address event */
		$("#Update_address_detail").click(function() {
		   var first_name = $("#update_first_name").val();
		   var last_name = $("#update_last_name").val();
		   var address 	 = $("#update_customeraddress").val();
		   var city = $("#update_city").val();
		   var state = $("#update_state").val();
		   var zipcode = $("update_#zipcode").val();
		   var country = $("update_#country").val();
		   var error = 0;
		   if(first_name == "")
		   {
			 $("#update_address_detailfirst_name").next(".error").css("display","block"); 
			 var error = 1; 
		   }
		   
		   if(last_name == "")
		   {
			 $("#update_last_name").next(".error").css("display","block");
			 var error = 1; 
		   }
		   
		   if(address == "")
		   {
			 $("#update_customeraddress").next(".error").css("display","block");
			 var error = 1; 
		   }
		   
		   if(city == "")
		   {
			 $("#update_city").next(".error").css("display","block"); 
			 var error = 1;
		   }
		   if(state == "")
		   {
			 $("#update_state").next(".error").css("display","block");
			 var error = 1; 
		   }
		   
		   if(zipcode == "")
		   {
			 $("#update_zipcode").next(".error").css("display","block");
			 var error = 1; 
		   }
		   
		   if(country == "")
		   {
			 $("#update_country").next(".error").css("display","block"); 
			 var error = 1;
		   }
		   
		   
		   
		   if(error == 0)
		   {
			  jQuery('.loader-overlay').css('visibility','visible'); 
			  if(jQuery('#update_country').val()=="223")
				{   
				jQuery('.loader-overlay').css('visibility','visible');
				jQuery.ajax({
							method: "POST",
							url: "ajax.php",
							dataType:"json",
							data: { 
										company: jQuery('#update_Company').val(),							
										name: jQuery('#update_first_name').val()+" "+jQuery('#update_last_name').val(),							
										street_address1: jQuery('#update_customeraddress').val(),							
										street_address2: jQuery('#update_address2').val(),
										city: jQuery('#update_city').val(),
										state: jQuery('#update_state').val(),							
										zone_id: jQuery('#update_stateZone').val(),							
										postcode: jQuery('#update_zipcode').val(),
										country: jQuery('#update_country').val(),
										act:"AddressValidation",
										method:"ValidateAddress"
									}
							}).done(function(response) {
								jQuery('.loader-overlay').css('display','none');
								if(response.ResidentialStatus=="RESIDENTIAL")
								{
									jQuery("#update_fedex_residential").val(1);
								}
								else if(response.ResidentialStatus=="BUSINESS")
								{
									jQuery("#update_fedex_residential").val(2);
								}
								else
								{
									jQuery("#update_fedex_residential").val(0);
								}
								if(response.UPSScore==1)
								{
									jQuery("#update_ups_validated").val(1);								
									jQuery("#update_ups_residential").val(1);
								}
								
								if(response.Score == 100)
								{							
									jQuery("#update_fedex_validated").val(1);
									var form_data = $('#update_address').serialize();
										
									jQuery.ajax({
										method: "POST",
										url: "ajax.php",
										dataType:"json",
										data: { 
													form_data,
													suggested:"",
													act:"CustomerDetail",
													method:"updateAddress"
											}
									}).done(function(response) {
										jQuery('.loader-overlay').css('visibility','hidden');
										swal({title: response, type: "success"});
										var customer_id = $("#update_customer_id").val();
										get_address(customer_id);
										$("#update_address").trigger("reset");
										$("#update_address").css("display","none");
										$(".address_detail").css("display","block");
									});	
								}
								else if(response.Score > 75)
								{
									jQuery('.loader-overlay').css('visibility','hidden');										
									jQuery('#suggestionmodel .modal-body').html(response.suggestion);	
									jQuery('.suggestion-btn-info').trigger('click');
									$(".suggestion-confirm").attr("id","update_suggestion_confirm");						
								}
								else if(response.Score == 0 || response.Score<=75 )
								{
									jQuery('.loader-overlay').css('visibility','hidden');		
									jQuery('.error-btn-info').trigger('click');							
								}
								else if(response.Score > 90)
								{
									var form_data = $('#update_address').serialize();
										
									jQuery.ajax({
										method: "POST",
										url: "ajax.php",
										dataType:"json",
										data: { 
													form_data,
													suggested:"",
													act:"CustomerDetail",
													method:"updateAddress"
											}
									}).done(function(response) {
										jQuery('.loader-overlay').css('visibility','hidden');
										swal({title: response, type: "success"});
										var customer_id = $("#update_customer_id").val();
										get_address(customer_id);
										$("#update_address").trigger("reset");
										$("#update_address").css("display","none");
										$(".address_detail").css("display","block");
									});		
										
								}      
								
							});
				return false;
			}
			else
			{
				var form_data = $('#update_address').serialize();
										
				 jQuery.ajax({
					 method: "POST",
					 url: "ajax.php",
					 dataType:"json",
					 data: { 
								 form_data,
								 suggested:"",
								 act:"CustomerDetail",
								 method:"updateAddress"
						 }
				 }).done(function(response) {
					 jQuery('.loader-overlay').css('visibility','hidden');
					 swal({title: response, type: "success"});
					 var customer_id = $("#update_customer_id").val();
					 get_address(customer_id);
					 $("#update_address").trigger("reset");
					 $("#update_address").css("display","none");
					 $(".address_detail").css("display","block");
					 location.reload();

				 });		
				return true;
			}
				
		   }
		});
		
		/* delete address */
		
	   jQuery(document).on('click',".delete_address",function() {
		   swal({
			  title: 'Are you sure want to remove this item?',
			  text: "You won't be able to revert this!",
			  icon: 'warning',
			  showCancelButton: true,
			  confirmButtonColor: '#3085d6',
			  cancelButtonColor: '#d33',
			  buttons: true,
			  dangerMode: true,
			}).then((isConfirm) => {
			  if (isConfirm){
				  var book_id = jQuery(this).data("id");
				  jQuery('.loader-overlay').css('visibility','visible');
					jQuery.ajax({
						method: "POST",
						url: "ajax.php",
						dataType:"json",
						data: { 
									address_book_id: book_id,
									act:"CustomerDetail",
									method:"deleteAddress"
							}
					}).done(function(response) {
						jQuery('.loader-overlay').css('visibility','hidden');
						swal({title: response, type: "success"}).then(() => {
										location.reload();
									}
								);
					});
			  }
			});	
	   });
	   
	   /* edit address event */
	   jQuery(document).on('click',".edit_address",function() {
		  var book_id = jQuery(this).data("id");
		  jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							address_book_id: book_id,
							act:"CustomerDetail",
							method:"addressDetail"
					}
			}).done(function(response) {
				
				$(".address_detail").css("display","none");
				$("#update_address").css("display","block");
				$("#address_form").css("display","none");
				$("#add_address").css("display","none");
				$("#address_form").css("display","none");
				$("#update_first_name").val(response.firstname);
				$("#update_last_name").val(response.lastname);
				$("#update_Company").val(response.company);
				$("#update_customeraddress").val(response.street1);
				$("#update_address2").val(response.street2);
				$("#update_city").val(response.city);
				$("#update_state").val(response.state);
				$("#update_zipcode").val(response.postcode);
				$('#update_country option[value="'+response.country_id+'"]').attr('selected','selected');
				$('#address_book_id').val(response.address_book_id);
				var customer_id = $("#customer_id").val();
				if(response.customers_default_address_id == response.address_book_id){
					$("#update_primary-address").prop("checked", true);
				}else{
					$("#update_primary-address").prop("checked", false);
				}
				$("#update_customer_id").val(customer_id);
				$(".address_form").css("display","none");
				$("#address_data").trigger("reset");
				
			});	
	   });
	   
	   
	  /* set customer data base on session */
	  var emailId = localStorage.getItem("customer_emailaddress");
	  if(emailId != null){
		   getPecustomerData(emailId);
		  
	  }
	   
	   
	   /* get customer data base on search by name*/
	   
	   $('#customer_search_name').autocomplete({
			source: 'oeFunctions.php?do=lookUpCustomer',
			minLength: 3,//search after three characters
			select: function(event,ui){
				
			  if(localStorage.getItem("customer_emailaddress") != null)
				{
					location.reload();
				}
				console.log(JSON.stringify(ui));
				$("#reset_password").removeClass("disabled");
				$("#save_customer").css("display","none");
				$("#customer_id_head").text(ui.item.id);
				getordercustomerData(ui.item.id);
			    $('#update_customerID,#resetcustomers_id').val(ui.item.id);
				$('#customer_profile').val(ui.item.customers_customerProfileId);
				$('#customers_firstname').val(ui.item.customers_firstname);
				$('#customers_lastname').val(ui.item.customers_lastname);
				$('#customers_telephone').val(ui.item.customers_telephone);
				$('#customers_email_address').val(ui.item.customers_email_address);
				$('#customers_fax').val(ui.item.customers_fax);
				$('#customers_terms_special').val(ui.item.customers_terms_special);
				$('#customers_resale_tax_id_date').val(ui.item.customers_resale_tax_id_date);
				$('#customers_terms_special').val(ui.item.customers_terms_special);
				$('#customers_resale_tax_id').val(ui.item.customers_resale_tax_id);
				$('#customers_special_order_notes').val(ui.item.customers_special_order_notes);
				$('#customers_special_shipping_notes').val(ui.item.customers_special_shipping_notes);
				$('#customers_ups_acct').val(ui.item.customers_ups_acct);
				$('#customers_fedex_acct').val(ui.item.customers_fedex_acct);
				
				if(ui.item.customers_invoice_email == 1){ $('#invoice').attr('checked', true); }
				if(ui.item.customers_invoice_mail == 1){ $('#mail-invoice').attr('checked', true); }
				if(ui.item.customers_invoice_fax == 1){ $('#fax-invoice').attr('checked', true); }
				if(ui.item.customers_blind_ship_enabled == 1){ $('#blind-ship').attr('checked', true); $("#blind_by_default").css("display","block"); }
				if(ui.item.customers_blind_ship_default == 1){ $('#by-default').attr('checked', true); }
				if(ui.item.customer_wholesale == 1){ $('#wholesale').attr('checked', true); }
				if(ui.item.customers_store_pickup_enabled == 1){ $('#store-pickup').attr('checked', true); }
				if(ui.item.customers_custom_ship_date_enabled == 1){ $('#custom_ship_date').attr('checked', true); }
				if(ui.item.customers_ship_collect == 1){ $('#ship-collect').attr('checked', true); $("#fedex_account").css("display","block"); }
				
				$("input[name='customers_ltl_capable'][value='"+ui.item.customers_ltl_capable+"']").prop('checked', true);
				
				$('#inputState option[value="'+ui.item.customers_terms+'"]').attr('selected','selected');
				$('#discount_grp option[value="'+ui.item.customers_group_pricing+'"]').attr('selected','selected');
				localStorage.setItem("customer_emailaddress",ui.item.customers_email_address);
				getPecustomerData(ui.item.customers_email_address);
				resetData();
				$('#customer_id').val(ui.item.id);
				get_address(ui.item.id);
				$(".address_form").css("display","none");
				$("#address_data").trigger("reset");
				$("#update_address").css("display","none");
				$(".error").css("display","none");
				$("#update_address").trigger("reset");
				$("#address-tab").removeClass("disabled");
				$("#payment-tab").removeClass("disabled");
				$("#insert_cusform").addClass("disabled");
				$("#customer_profile_id").val(ui.item.customers_customerProfileId);
				
				if(ui.item.customers_customerProfileId == "0")
				{
					addAuthID(ui.item.id,ui.item.customers_email_address,ui.item.customers_customerProfileId);
				}
				else
				{
					get_customerDetil(ui.item.customers_customerProfileId);
				}
				
				
				/*if(ui.item.customers_customerProfileId == 0)
				{
					addAuthID(ui.item.id,ui.item.customers_email_address);
				}*/
				
				cart_table(ui.item.id,'cart-table');
				
				return false;
			}
		});
		
		/* search customer by address */
		
		$('#customer_search_address').autocomplete({
			source: 'oeFunctions.php?do=lookUpCustomerByAddress',
			minLength: 3,//search after three characters
			select: function(event,ui){
			  if(localStorage.getItem("customer_emailaddress") != null)
				{
					location.reload();
				}
				console.log(JSON.stringify(ui));
				$("#reset_password").removeClass("disabled");
				$("#save_customer").css("display","none");
			    $('#update_customerID,#resetcustomers_id').val(ui.item.id);
				$('#customer_profile').val(ui.item.customers_customerProfileId);
				$('#customers_firstname').val(ui.item.customers_firstname);
				$('#customers_lastname').val(ui.item.customers_lastname);
				$('#customers_telephone').val(ui.item.customers_telephone);
				$('#customers_email_address').val(ui.item.customers_email_address);
				$('#customers_fax').val(ui.item.customers_fax);
				$('#customers_terms_special').val(ui.item.customers_terms_special);
				$('#customers_resale_tax_id_date').val(ui.item.customers_resale_tax_id_date);
				$('#customers_terms_special').val(ui.item.customers_terms_special);
				$('#customers_resale_tax_id').val(ui.item.customers_resale_tax_id);
				$('#customers_special_order_notes').val(ui.item.customers_special_order_notes);
				$('#customers_special_shipping_notes').val(ui.item.customers_special_shipping_notes);
				$('#customers_ups_acct').val(ui.item.customers_ups_acct);
				$('#customers_fedex_acct').val(ui.item.customers_fedex_acct);
				$(".error").css("display","none");
				if(ui.item.customers_invoice_email == 1){ $('#invoice').attr('checked', true); }
				if(ui.item.customers_invoice_mail == 1){ $('#mail-invoice').attr('checked', true); }
				if(ui.item.customers_invoice_fax == 1){ $('#fax-invoice').attr('checked', true); }
				if(ui.item.customers_blind_ship_enabled == 1){ $('#blind-ship').attr('checked', true); $("#blind_by_default").css("display","block"); }
				if(ui.item.customers_blind_ship_default == 1){ $('#by-default').attr('checked', true); }
				if(ui.item.customer_wholesale == 1){ $('#wholesale').attr('checked', true); }
				if(ui.item.customers_store_pickup_enabled == 1){ $('#store-pickup').attr('checked', true); }
				if(ui.item.customers_custom_ship_date_enabled == 1){ $('#custom_ship_date').attr('checked', true); }
				if(ui.item.customers_ship_collect == 1){ $('#ship-collect').attr('checked', true); $("#fedex_account").css("display","block"); }
				
				$("input[name='customers_ltl_capable'][value='"+ui.item.customers_ltl_capable+"']").prop('checked', true);
				
				$('#inputState option[value="'+ui.item.customers_terms+'"]').attr('selected','selected');
				$('#discount_grp option[value="'+ui.item.customers_group_pricing+'"]').attr('selected','selected');
				localStorage.setItem("customer_emailaddress",ui.item.customers_email_address);
				$('#customer_id').val(ui.item.id);
				get_address(ui.item.id);
				$(".address_form").css("display","none");
				$("#address_data").trigger("reset");
				$("#update_address").css("display","none");
				$("#update_address").trigger("reset");
				$("#customer_profile_id").val(ui.item.customers_customerProfileId);
				if(ui.item.customers_customerProfileId == 0)
				{
					addAuthID(ui.item.id,ui.item.customers_email_address,ui.item.customers_customerProfileId);
				}
				else
				{
					get_customerDetil(ui.item.customers_customerProfileId);
				}
				cart_table(ui.item.id,'cart-table');
				
				return false;
			}
		});
		
		/* update customer */
		
		 $("#update_customer").click(function() {
		   var fname = $("#customers_firstname").val();
		   var lname = $("#customers_lastname").val();
		   var tel 	 = $("#customers_telephone").val();
		   var email = $("#customers_email_address").val();
		   var address = $("#address").val();
		   var error = 0;
		   if(fname == "")
		   {
			 $("#customers_firstname").next(".error").css("display","block"); 
			 var error = 1; 
		   }
		   
		   if(lname == "")
		   {
			 $("#customers_lastname").next(".error").css("display","block");
			 var error = 1; 
		   }
		   
		   if(tel == "")
		   {
			 $("#customers_telephone").next(".error").css("display","block");
			 var error = 1; 
		   }
		   
		   if(email == "")
		   {
			 $("#customers_email_address").next(".error").css("display","block"); 
			 var error = 1;
		   }
		   if($("#ship-collect").prop("checked") == true){
			   
			   var ups_acct = $("#customers_ups_acct").val();
			   var fedex_acct = $("#customers_fedex_acct").val();

                if(ups_acct == "")
				{
					if(fedex_acct == "")
					{
						 $("#customers_ups_acct").next(".error").css("display","block");
						 var error = 1;
					}
					else
					{
						 $("#customers_ups_acct").next(".error").css("display","none");
						 var error = 0;
					}
				}
				else if(fedex_acct == "")
				{
					if(ups_acct == "")
					{
						 $("#customers_ups_acct").next(".error").css("display","block");
						 var error = 1;
					}
					else
					{
						 $("#customers_ups_acct").next(".error").css("display","none");
						 var error = 0;
					}
				}
				else
				{
				}
			}
		   
		   if(error == 0)
		   {
			   if($("#customers_resale_tax_id").val() == ""){
					$(".rTaxdate").addClass('d-none');
				}else{
					$(".rTaxdate").removeClass('d-none');
				}
			   var form_data = $('#customer_detail').serialize();
										
			   jQuery.ajax({
					method: "POST",
					url: "ajax.php",
					dataType:"json",
					data: { 
								form_data,
								act:"CustomerDetail",
								method:"updateCustomer"
						}
				}).done(function(response) {
					if(response == 1)
					{
						$("#update_customer").hide();
						swal({title: "customer update successfully !!", type: "success"});
						
					}
				});
					
			}
		});
		
		
		
		/* Customer search on payment page */
		
		 $('#paymentcustomer_search').autocomplete({
			source: 'oeFunctions.php?do=lookUpCustomer',
			minLength: 3,//search after three characters
			select: function(event,ui){
			
			console.log(ui.item.customers_customerProfileId);
			
				$('#customer_id').val(ui.item.id);
				$('#customer_profile').val(ui.item.customers_customerProfileId);
				get_address(ui.item.id);
				var currentURL = location.protocol + '//' + location.host + location.pathname;
				window.location.href = currentURL+"?cid="+ui.item.customers_customerProfileId;
				return false;
			}
		});
		
		/* reload on payment events */
		//
		$(document).on('click','#myModal',function(){
			var customer_profile_id = $("#customer_profile_id").val();
			get_customerDetil(customer_profile_id);
		});
		
		/* remove cid from the url */
		
		$(".nav-item a").click(function()
		{
			if($(this).attr("id") != "payment-tab")
			{
				if (window.location.href.indexOf('?cid=') > 0) {
					var uri = window.location.toString();
					var clean_uri = uri.substring(0, uri.indexOf("?"));
					window.history.replaceState({}, document.title, clean_uri);
					$("#payment_record").remove();
					$("#addPayDiv").remove();
				}
			}
		});
		
		/* back btn on address tab */
		
		$("#back_btn").click(function() {
			$(".address_form").css("display","none");
			$(".address_detail").css("display"," block");
		});
		$("#updateback_btn").click(function() {
			$("#update_address").css("display","none");
			$(".address_detail").css("display"," block");
			$("#add_address").css("display","block");
		});
		
		/* nav tab active base on session storage */
		
		$(".nav-link").click(function() {
			localStorage.setItem("active_tab",$(this).attr("id"));
		});
		
		if(localStorage.getItem("active_tab") != null)
		{
			var active_id = localStorage.getItem("active_tab");
			var active_hrefid = $("#"+active_id).attr("href");
			activaTab(active_hrefid);
			
		}
		
		
		 /* product search result */
		$('#product_search_name').autocomplete({
			source: 'oeFunctions.php?do=lookUpProduct',
			minLength: 3,//search after three characters
			select: function(event,ui){
				var producthtml = '<div class="col-sm-12 col-md-6 col-lg-4 mb-3 product-space text-center"><div class="image-box object-non-visible animated object-visible fadeInLeft" data-animation-effect="fadeInLeft" data-effect-delay="300"><div class="overlay-container"><img src="https://www.holidaybows.com/images/thumbnails/'+ui.item.products_image+'" alt="'+ui.item.products_name+'" title="'+ui.item.products_name+'" class="listingProductImage" width="200" height="100"><div class="overlay"><div class="overlay-links"> <a href="https://www.holidaybows.com/images/thumbnails/'+ui.item.products_image+'" class="popup-img"><i class="fa fa-search-plus"></i></a></div></div></div><div class="image-box-body"><h5 class="text-uppercase PlayfairDisplayBold text-center w-100 mt-3 text-red">$'+ui.item.products_price+'</h5><p class="text-center w-100 font-weight-light py-0 prdct_name">'+ui.item.products_name+'</p><p><b>SKU :</b>'+ui.item.sku_old+'</p> <a class="product-addcart btn btn-primary mt-2 btn-p px-4 text-center text-uppercase bg-red" data-productid ="'+ui.item.id+'" data-productprice="'+ui.item.products_price+'" href="JavaScript:void(0);">Add to cart</a></div></div></div>';
				$(".product-listing").html(producthtml);
			}
		});
		
		
		/* add store cart in new order */
		
		 jQuery(document).on('click',".cart-submit",function() {
			 var store_type = $(this).data("store");
			 var customerId = $(this).data("cusid");
			 $("#newOrder-tab").removeClass("disabled");
			 order_cartable(store_type,customerId);
			 
			 var active_hrefid = $("#newOrder-tab").attr("href");
			 activaTab(active_hrefid);
			 localStorage.setItem("store_type", store_type);
		 });
		 
		 /* new order store cart value display base on session */
		 
		 if(localStorage.getItem("store_type") != null)
			{
				var store_type = localStorage.getItem("store_type");
				var customerId = $("#update_customerID").val();
				if(customerId != ""){
					order_cartable(store_type,customerId);
				}
				 
			}
			jQuery(document).on("change","#shippingaddress",function() {
				var addrId = $(this).val();
				var shipAdd = $(this).attr('data-id');
				$("#shipAdd").html(shipAdd);
				var customerId = $("#customer_id").val();
				updateDefaultAddressId(addrId,customerId);
			});
			/* Set billing address */
			jQuery(document).on("change","#billingaddress",function() {
				var addrId = $(this).val();
				var billAdd = $(this).attr('data-id');
				$("#billAdd").html(billAdd);
				var customerId = $("#customer_id").val();
				updateDefaultbillingAddressId(addrId,customerId);
			});
			
			/* Apply Tax */
			jQuery("#apply_tax").click(function(){
				var taxVal = jQuery(this).val();
				applyTax(taxVal);
			});
			
			/* Set customer */
			jQuery(".issame").change(function(){
				var customer_id_head = $("#customer_id_head").text();
				if(customer_id_head != ""){
					$("#update_customer").show();
				}
			});
			
			/* Get Updated Cart Table*/
			jQuery("#cart-tab").click(function(){
				var customer_id = $("#customer_id_head").text();
				cart_table(customer_id,'cart-table');
			});
	 
	});
	
	/* Add to Cart */
	function add_to_carts(){
		var pid = $("#product_id").val();
		var qty = $("#qty").val();
		var sku_search = $("#sku_search").val();
		var store_name = $("#store_name").text();
		if(sku_search == ""){
			swal({title: 'Please add product!!', type: "error"});
			return false;
		}
		if($("#description").val() == ""){
			swal({title: 'Please select product!!', type: "error"});
			return false;
		}
		if(qty == ""){
			swal({title: 'Please add Quantity!!', type: "error"});
			return false;
		}
		if(parseInt(qty) < 0){
			swal({title: 'Quantity negative value are not allowed!!', type: "error"});
			return false;
		}
		jQuery(".lbs-wrap").css("display","block");
			jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							pid:pid,
							act:"ProductDetail",
							method:"checkProd"
					}
			}).done(function(response) {
				jQuery(".lbs-wrap").css("display","none");
				var obj = jQuery.parseJSON(response);
				if(obj.status == "1"){
					/*swal({
					  title: 'Are you sure want to overwrite this item?',
					  text: "This item is already added in the cart.",
					  icon: 'warning',
					  showCancelButton: true,
					  confirmButtonColor: '#3085d6',
					  cancelButtonColor: '#d33',
					  confirmButtonText: 'Add / Overwrite Quantity!'
					},
					 function(isConfirm){
					   if (isConfirm){
							addCart(pid,qty,store_name);
					   }
					 });*/
					 
					 swal("This item is already added in the cart!", {
						  buttons: {
							cancel: true,
							catch: {
							  text: "Add",
							  value: "add",
							},
							defeat: 'Overwrite',
						  },
						})
						.then((value) => {
						  switch (value) {
						 
							case "defeat":
							  addCart(pid,qty,store_name,'1');
							  break;
						 
							case "add":
							  addCart(pid,qty,store_name,'2');
							  break;
						 
							default:
							  
						  }
						});
				}else{
					addCart(pid,qty,store_name,'3');
				}
			});
	}
	function addCart(pid,qty,store_name,isaction){
		jQuery(".lbs-wrap").css("display","block");
		jQuery.ajax({
			method: "POST",
			url: "ajax.php",
			dataType:"json",
			data: { 
						pid:pid,
						qty:qty,
						store_name:store_name,
						isaction:isaction,
						act:"ProductDetail",
						method:"add_to_cart"
				}
		}).done(function(response) {
			jQuery(".lbs-wrap").css("display","none");
			var obj = jQuery.parseJSON(response);
			$('.cart_table_contect').html(obj.html.cart);
			$('.pproductStat').html('');
			$('.pproductStat').html(obj.status);
			if(obj.status != ""){
				$('#statusModal').modal('show');
			}
			$("#sku_search").val('');
			$("#description").val('');
			$("#qty").val('');
			$("#price").val('');
			$('.updatecrtData').show();
			$('.neworder-submit').hide();
		});
	}
	/* Set shipping rates */
	function setShipping(elm) {
		var shipping_title = $(elm).find('.seletitlePst').text();
		if($(".ordershipping #ship_collect_check_back").prop('checked')){
			var shipping_cost = '0.00';
			var splitCost = $(elm).find('.selecsstTil').data('splstcost');
			if(shipping_title.charAt(0) == "F"){
				var shipAccVal = $('#fedexwebservices_ship_collect').val();
			}else if(shipping_title.charAt(0) == "G"){
				var shipAccVal = $('#fedexwebservices_ship_collect').val();
			}else{
				var shipAccVal = $('#upsxml_ship_collect').val();
			}
			var shipping_title =  shipping_title+' Collect (ACC : '+shipAccVal+')';
		}else{
			var shipping_cost = parseFloat($(elm).find('.selecstTil').text().replace('$','')).toFixed(2);
			var splitCost = $(elm).find('.selecstTil').data('spltcost');
		}
		var splitTaxclass = $(elm).find('.selecstTil').data('txcls');
		var splitTaxBasis = $(elm).find('.selecstTil').data('taxbasis');
		var shipping_id = jQuery(elm).data('shipid');
		var shipping_method = '<div class="cart_shipping text-right text-primary mt-2 mb-2 font-weight-bold"><span id="shippingttitle">'+shipping_title + ' :</span> $' + '<span class="slpit_ship_cost">'+shipping_cost+'</span> <i onclick="changeShip()" class="fa fa-angle-down shipIcon" aria-hidden="true"></i></div>';
		var subtotal_val = jQuery(".sub_ot_subtotal").text().replace('$','');
		
		$('.titlePst').text(shipping_title);
		$('.cstTil').text("$"+shipping_cost);
		$('.cstTil').attr('data-cost',"$"+splitCost);
		subtotal_val = parseFloat(subtotal_val);
		jQuery(".cart_shipping").remove();
		jQuery(".ot_total").before(shipping_method);
		var total_val = parseFloat(shipping_cost) + subtotal_val;
		if(jQuery('.sub_ot_tax').text()){
			var taxAmount = jQuery('.sub_ot_tax').text().replace('$','');
		}else{
			var taxAmount = '0';
		}
		var isTan = "0";
		calculate(shipping_cost,subtotal_val,shipping_cost,taxAmount,isTan);
		
		/* Show cod payment method if shipping is cash on delivery */
		
		if(shipping_id == "storepickup0"){
			$(".cod_pay").show();
		}else{
			$("#cash_on_delivery").prop('checked',false);
			$("#credit_card").prop('checked',true);
			$(".cod_pay").hide();
		}
		
		
		store_shippingSession(shipping_title,shipping_id,shipping_cost,splitCost,splitTaxBasis,splitTaxclass);
	}
	
	/* Set Tan shipping */
	
	function settanShipping() {
		var shipping_title = 'Tantative Shipping';
		var shipping_cost = '0.00';
	    var splitCost = '0.00';
		var splitTaxclass = 'no';
		var splitTaxBasis = 'no';
		var shipping_id = 'tan_ship';
		var shipping_method = '<div class="cart_shipping text-right text-primary mt-2 mb-2 font-weight-bold"><span id="shippingttitle">'+shipping_title + ' :</span>' + '<span class="slpit_ship_cost">TBD</span></div>';
		var subtotal_val = jQuery(".sub_ot_subtotal").text().replace('$','');
		subtotal_val = parseFloat(subtotal_val);
		jQuery(".cart_shipping").remove();
		jQuery(".ot_total").before(shipping_method);
		var total_val = parseFloat(shipping_cost) + subtotal_val;
		if(jQuery('.sub_ot_tax').text()){
			var taxAmount = jQuery('.sub_ot_tax').text().replace('$','');
		}else{
			var taxAmount = '0';
		}
		var isTan = "1";
		calculate(shipping_cost,subtotal_val,shipping_cost,taxAmount,isTan);
		store_shippingSession(shipping_title,shipping_id,shipping_cost,splitCost,splitTaxBasis,splitTaxclass);
	}
	
	/* store shipping in session */
	
	function store_shippingSession(shipping_title,shipping_id,shipping_cost,splitCost,splitTaxBasis,splitTaxclass)
	{
			jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							shipping_title:shipping_title,
							shipping_id:shipping_id,
							shipping_cost:shipping_cost,
							splitCost:splitCost,
							splitTaxclass:splitTaxclass,
							splitTaxBasis:splitTaxBasis,
							act:"CustomerDetail",
							method:"store_shippingSession"
					}
			}).done(function(response) {
				
			});
	}
	
	function changeShip(){
		if($('.ordershipping').html() != ""){
			$(".ordershipping .ship_data").show();
			$('#shppingModal').modal('show');
		}else{
			$('.ordershipping').html('');
			var shipHtml = $(".ship_methodl .ship_data").html();
			$('.ordershipping').html(shipHtml);
			$(".ship_data").html('');
			$('#shppingModal').modal('show');
		}
	}
	
	/* update default address */
	
	function updateDefaultAddressId(addrId,customerId)
	{
		jQuery(".lbs-wrap").css("display","block");
		 jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							customerId:customerId,
							addressId:addrId,
							act:"CustomerDetail",
							method:"updateDefaultaddrId"
					}
			}).done(function(response) {
				jQuery(".lbs-wrap").css("display","none");
				 var store_type = $(".cart-submit").data("store");
				 var customerId = $(".cart-submit").data("cusid");
				 $("#newOrder-tab").removeClass("disabled");
				 order_cartable(store_type,customerId);
				 var active_hrefid = $("#newOrder-tab").attr("href");
				 activaTab(active_hrefid);
				 localStorage.setItem("store_type", store_type);
			});
	}
	
	/* update Default billing address */
	function updateDefaultbillingAddressId(addrId,customerId)
	{
		jQuery(".lbs-wrap").css("display","block");
		 jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							customerId:customerId,
							addressId:addrId,
							act:"CustomerDetail",
							method:"updateDefaultbillingAddressId"
					}
			}).done(function(response) {
				jQuery(".lbs-wrap").css("display","none");
				 var store_type = $(".cart-submit").data("store");
				 var customerId = $(".cart-submit").data("cusid");
				 $("#newOrder-tab").removeClass("disabled");
				 order_cartable(store_type,customerId);
				 var active_hrefid = $("#newOrder-tab").attr("href");
				 activaTab(active_hrefid);
				 localStorage.setItem("store_type", store_type);
			});
	}
		
	/*Apply Tax */
	function taxVal(taxVal){
		//jQuery(".lbs-wrap").css("display","block");
		 jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							taxVal:taxVal,
							act:"CustomerDetail",
							method:"taxCalculate"
					}
			}).done(function(response) {
				jQuery(".lbs-wrap").css("display","none");
			});
		
	}
	/* new order cart table */
	
	function order_cartable(store_type,customerId)
	{
		jQuery(".lbs-wrap").css("display","block");
		 jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							store_type:store_type,
							customerId:customerId,
							act:"ProductDetail",
							method:"store_cart"
					}
			}).done(function(response) {
				jQuery(".lbs-wrap").css("display","none");
				$('#newOrder_cartable').html(response);
				 
				if($('.ship_methodl .tanlnk').length == 1){
				
				settanShipping()
			 }
				$(".ship_methodl .preselct").trigger('click');
				$(".cod_pay").hide();
				$('.ordershipping').html('');
				$('#sku_search').autocomplete({
					//source: 'oeFunctions.php?do=lookUpProduct',
					source: function(request, response) {
					$.ajax({
					  url: 'oeFunctions.php?do=lookUpProduct',
					  dataType: "json",
					  data: request,                    
					  success: function (data) {
						// No matching result
						if (data.length == 0) {
						  swal({title: 'Product not found! or exists of the another store!', type: "error"});
						  $("#sku_search").val('');
						}
						else {
						  response(data);
						  $("#qty").val('1');
						}
					  }});
					},
					minLength: 3,//search after three characters
					select: function(event,ui){
						$('#product_id').val(ui.item.id);
						get_product(ui.item.id);
						$(".ship_methodl .preSelct").trigger('click');
						return false;
					}
				});
				
				/* Search by description */
				
				$('#description').autocomplete({
					//source: 'oeFunctions.php?do=lookUpProduct',
					source: function(request, response) {
					$.ajax({
					  url: 'oeFunctions.php?do=lookUpProductdesc',
					  dataType: "json",
					  data: request,                    
					  success: function (data) {
						// No matching result
						if (data.length == 0) {
						  swal({title: 'Product not found! or exists of the another store!', type: "error"});
						  $("#sku_search").val('');
						}
						else {
						  response(data);
						  $("#qty").val('1');
						}
					  }});
					},
					minLength: 3,//search after three characters
					select: function(event,ui){
						$('#product_id').val(ui.item.id);
						get_product(ui.item.id);
						$(".ship_methodl .preSelct").trigger('click');
						return false;
					}
				});
			});
	}
	/* cart table */
	
	function cart_table(cid,divID) {
		jQuery(".lbs-wrap").css("display","block");
		jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							customerId:cid,
							act:"ProductDetail",
							method:"cartTable"
					}
			}).done(function(response) {
				jQuery(".lbs-wrap").css("display","none");
				$("#"+divID).html(response);
			});
	}
	
	
	function activaTab(tab){
		setTimeout(function(){
			$(document).find('a[href="' + tab + '"]').tab('show');
		}, 100);
	
		
	};
	
	function Check_ship_collect() {
			var chkPassport = document.getElementById("ship-collect");
			if (chkPassport.checked) {
			$("#fedex_account").css("display","block");
			}
			else
			{
				$("#fedex_account").css("display","none");
			}
		}
		
	function Check_blind_ship() {
			var chkPassport = document.getElementById("blind_ship");
			if (chkPassport.checked) {
			$("#blind_by_default").css("display","block");
			}
			else
			{
				$("#blind_by_default").css("display","none");
			}
		}
	function get_address(id) {
		
		jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							customer:id,
							act:"CustomerDetail",
							method:"getaddress"
					}
			}).done(function(response) {
				
				if(response != "")
				{
					$(".address_detail").html("");
					$(".address_detail").html(response);
				}
				else
				{
					$(".address_form").css("display","block");
					$(".address_detail").html("");
					$(".address_detail").html(response);
				}
				
			});
		
		}
		
		function get_product(id) {
		jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							product_id:id,
							act:"ProductDetail",
							method:"get_product"
					}
			}).done(function(obj) {
				var response = jQuery.parseJSON( obj );
				$("#sku_search").val(response.products_model);
				$("#description").val(response.products_name);
				$("#price").val(response.products_price);
			});
		
		}
		
		
	
	/* Authrized payment scripts */
	
	var baseUrl = "https://test.authorize.net/customer/";
	var onLoad = true;
	tab = null;
	
	function returnLoaded() {
		console.log("Return Page Called ! ");
		$('.close').trigger('click');
		showTab(tab);
	}
	
	window.CommunicationHandler = {};
	function parseQueryString(str) {
		var vars = [];
		var arr = str.split('&');
		var pair;
		for (var i = 0; i < arr.length; i++) {
			pair = arr[i].split('=');
			vars[pair[0]] = unescape(pair[1]);
		}
		return vars;
	}
	

	function showTab(target){
		onLoad = true;
		var currTime = sessionStorage.getItem("lastTokenTime");
		if (currTime === null || (Date.now()-currTime)/60000 > 15){
			location.reload(true);
			onLoad = true;
		}
		if (onLoad) {
			setTimeout(function(){ 
				$("#send_token").attr({"action":baseUrl+"addPayment","target":"add_payment"}).submit();
			} ,100);
			onLoad = false;
		}

		
		switch(target){
			case "#home" 		: $("#home").show();$("#acceptJSPayDiv").show();break;
			case "#payment" 	: $("#payment").show(); $("#addPayDiv").show(); break;
		}
	}

	/* add authorized customer id */
		
		function addAuthID(id,email,profileid)
		{
			jQuery.ajax({
					method: "POST",
					url: "ajax.php",
					dataType:"json",
					data: { 
								customer_id:id,
								customer_email:email,
								act:"CustomerDetail",
								method:"customerAuthId"
						}
				}).done(function(response) {
					 get_customerDetil(profileid);
			});
		}

	function DeletePaymentProfiler(paymentid,cpid)
	{   
		if(confirm("Are you sure you want to delete this?")){
			$.ajax({
			  type: 'POST',
			  url: "payment/paymentdetail.php",
			  data: {action:'delete_card',paymentid:paymentid,cpid:cpid},
			  dataType: "text",
			  success: function(resultData) {
				   var customer_profile_id = $("#customer_profile_id").val();
				   get_customerDetil(customer_profile_id);	
			  }
			});
		}
		else{
			return false;
		}
	}
	/*New Profile Id*/
	function newCustomerProfile(cid){
		jQuery(".lbs-wrap").css("display","block");
		jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							cid:cid,
							act:"CustomerDetail",
							method:"createCustomerproile"
					}
			}).done(function(response) {
				if(response == "1"){
					location.reload();
				}
			});
	}
	function get_customerDetil(cid) {
		jQuery(".lbs-wrap").css("display","block");
    $('.loader').css('display', 'block');
	$('.loader').load('demo_ajax_load.asp');
	$.ajax({ 
		data: {'cid': cid,'action':'get_payments'}, 
		type: 'POST', 
		url: 'payment/paymentdetail.php/'+cid, 
		success: function(response) {
			$('.loader').css('display', 'none');
			jQuery(".lbs-wrap").css("display","none");
			$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
				tab = $(e.target).attr("href") // activated tab
				sessionStorage.setItem("tab",tab);
				showTab(tab);
			});
			onLoad = true;
			sessionStorage.setItem("lastTokenTime",Date.now());
			tab = sessionStorage.getItem("tab");
			if (tab === null) {
				$("[href='#home']").parent().addClass("active");
				tab = "#home";
			}
			else{
				$("[href='"+tab+"']").parent().addClass("active");
			}
			console.log("Tab : "+tab);
			showTab(tab);
			$("#addPaymentButton").click(function() {
				$("#myModalLabel").text("Add Details");
				$("#edit_payment").hide();
				$("#add_payment").show();
				$(window).scrollTop($('#add_payment').offset().top-50);
			});
			
			 jQuery(document).on('click',".editPay",function() {
				$ppid = $(this).attr("value");
				$("#send_token [name=paymentProfileId]").attr("value",$ppid);
				$("#add_payment").hide();
				$("#edit_payment").show();
				$("#send_token").attr({"action":baseUrl+"editPayment","target":"edit_payment"}).submit();
				$("#send_token [name=paymentProfileId]").attr("value","");
				$("#myModalLabel").html("Edit Details")
				$(window).scrollTop($("#edit_payment").offset().top-30);
			});
				
				
					
			CommunicationHandler.onReceiveCommunication = function (argument) {
			params = parseQueryString(argument.qstr)
			parentFrame = argument.parent.split('/')[4];
			console.log(params);
			console.log(parentFrame);
			console.log(params['height']);
			$frame = null;
			switch(parentFrame){
				case "addPayment" 	: $frame = $("#add_payment");break;
				case "editPayment" 	: $frame = $("#edit_payment");break;
			}
			switch(params['action']){
				case "resizeWindow" 	: if( parentFrame== "manage" && parseInt(params['height'])<1150) params['height']=1150;
											$frame.outerHeight(parseInt(params['height']));
											break;
				case "successfulSave" 	: $('#myModal').modal('hide'); location.reload(false); break;
				case "cancel" 			: 	switch(parentFrame){
											case "addPayment"   : $("#send_token").attr({"action":baseUrl+"addPayment","target":"add_payment"}).submit(); $("#add_payment").hide();  $('#myModal').modal('toggle');  break; 										
											case "editPayment"  :  $('#myModal').modal('toggle'); $("#payment").show(); $("#addPayDiv").show(); break;  
											}
											break;
				}
			}
			$('.getdata').html(response);
		}
	});
}

function getCid(){
	alert($("#country").val());
	return $("#country").val();
}

	/*
	 * 
	 * Order Ajax
	 * 
	 */
	 
	 function generateOrder(cpid,cppid,caid) {
		/*alert("Order Saving Process In Going");
		return false;*/
		var shipping_instruction = $('#shipping_instruction').val();
		var production_instruction = $('#production_instruction').val();
		var multiOrderdatatitle = {};
		var multiOrderdatavalues = {};
		var warehouseIds = '';
		$( ".all_warehouse" ).each(function( index ) {
			var wid = $( this ).val();
			warehouseIds = warehouseIds+'_'+wid;
			var titles = [];
			$( ".alltitle_"+wid ).each(function( index ) {
				titles.push($(this).text());
			});
			var values = [];
			$( ".allvalues_"+wid ).each(function( index ) {
				values.push($(this).text());
			});
			multiOrderdatatitle["titles_"+wid]  = titles;
			multiOrderdatavalues["values_"+wid] = values;
		});
		if ($("#credit_card").prop("checked")){
			var payment_type = "authorizenet_cim";
			var cvv = $('#-cc-cvv').val();
			if(cvv == ""){
				swal({title: 'Please enter cvv!!', type: "error"});
				return false;
			}
		}else{
			var cvv = '';
		}
		if ($("#po_check").prop("checked")){
			var payment_type = "dotpo";
			var po_check = $('#po_number').val();
			if(po_check == ""){
				swal({title: 'Please enter PO number!!', type: "error"});
				return false;
			}
		}else{
			var po_check = '';
		}
		if ($("#cash_on_delivery").prop("checked")){
			var payment_type = "cod";
		}
		
		if($(".ordershipping #ship_collect_check_back").prop('checked')){
			var shipTxt = $("#shippingttitle").text();
			if(shipTxt.charAt(0) == "F"){
				if($(".ordershipping #fedexwebservices_ship_collect").val() == ""){
					swal({title: 'Please enter feDex ship collect number!!', type: "error"});
					return false;
				}
			}else if(shipTxt.charAt(0) == "U"){
				if($(".ordershipping #upsxml_ship_collect").val() == ""){
					swal({title: 'Please enter UPS ship collect number!!', type: "error"});
					return false;
				}
			}
		}
		swal({
			  title: 'Are you sure?',
			  text: "Once Confirm, your order be successfully generate!",
			  icon: 'warning',
			  showCancelButton: true,
			  confirmButtonColor: '#3085d6',
			  cancelButtonColor: '#d33',
			  confirmButtonText: 'Yes, Confirm it!',
			  buttons: true,
			  dangerMode: true
			}).then((isConfirm) => {
			   if (isConfirm){
				
			jQuery(".lbs-wrap").css("display","block");
			$.ajax({ 
				data: {'shipping_instruction':shipping_instruction,'production_instruction':production_instruction,'cvv': cvv,'cpid':cpid,'cppid' : cppid,'caid':caid,multiOrderdatatitle,multiOrderdatavalues,warehouseIds:warehouseIds,payment_type:payment_type,po_check:po_check}, 
				type: 'POST', 
				url: 'order/checkout_process.php/', 
				success: function(response) {
					var obj = jQuery.parseJSON(response);
					console.log(obj);
					if(obj.status == "1"){
						swal("Congratulations!", "Order has been successfully placed!", "success");
						$("#newOrder_cartable").html('');
						$("#newOrder_cartable").html(obj.order);
						jQuery(".lbs-wrap").css("display","none");
						$("#Order-tab").removeClass('disabled');
						$("#newOrder-tab").addClass('disabled');
						//$("#customer-tab").addClass("disabled");
						//$("#address-tab").addClass("disabled");
						//$("#payment-tab").addClass("disabled");
						//$("#cart-tab").addClass("disabled");
					}else if(obj.status == "0"){
						jQuery(".lbs-wrap").css("display","none");
						swal({title: 'Please select shipping!!', type: "error"});
					}else if(obj.status == "5"){
						jQuery(".lbs-wrap").css("display","none");
						swal({title: obj.order, type: "error"});
					}else{
						jQuery(".lbs-wrap").css("display","none");
						swal({title: 'Something went wrong!!', type: "error"});
					}
				}
			});
			 
			}
			 });
	
		
	}
	
	
	/* Apply Coupon */
	function applyCoupon(wid){
		jQuery("#split_ware_coupon").val(wid);
	}
	
	/* add Coupon */
	function addCoupon(){
		var wid 		= jQuery("#split_ware_coupon").val();
		var couponCode 	= jQuery('#coupon_code').val();
		if(couponCode == ""){
			swal({title: 'Please enter coupon code!!', type: "error"});
			return false;
		}else{
			jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							coupon_code:couponCode,
							wid:wid,
							act:"ProductDetail",
							method:"applyCoupon"
					}
			}).done(function(obj) {
				var response = jQuery.parseJSON( obj );
				if(response.status == '1'){
					couponHtml = response.html;
					$('.sub_ot_tax').html("$"+response.taxvalues);
					var isAdd = "1";
					taxVal = response.taxvalues;
					calculateAmt('1',response.values,taxVal,isAdd);
					$(".ot_coupon").remove();
					jQuery('.ot_subtotal').before(couponHtml);
					$('.couponData').hide();
					$('.rmcouponData').show();
					$('.rmcouponData').html(response.rmchtml);
				}else{
					swal({title: 'Coupon not applicable!!', type: "error"});
				}
			});
			$("#couponModal").modal("hide");
		}
	}
	
	/* calculateAmt */
	
	function calculateAmt(wid,cAmt,taxVal,isAdd){
		if(isAdd == "1"){
			var subtotal = parseFloat(jQuery(".sub_ot_subtotal").text().replace('$',''))-parseFloat(cAmt);
		}else{
			var subtotal = parseFloat(jQuery(".sub_ot_subtotal").text().replace('$',''))+parseFloat(cAmt);
		}
		if(jQuery('.slpit_ship_cost').text()){
			var shipCost = jQuery('.slpit_ship_cost').text();
		}else{
			var shipCost = "0";
		}
		if(taxVal == ''){
			taxVal = 0;
		}
		var shpTxt = shipCost;
		if(shipCost == '' || shipCost == 'TBD'){
			shipCost = 0;
		}
		if(subtotal == ''){
			subtotal = 0;
		}
		
		var total 	 = parseFloat(subtotal)+parseFloat(taxVal)+parseFloat(shipCost);
		if(shpTxt == "TBD"){
			jQuery(".sub_ot_subtotal").html("$"+subtotal.toFixed(2));
			jQuery(".sub_ot_total").html(shpTxt);
		}else{
			jQuery(".sub_ot_subtotal").html("$"+subtotal.toFixed(2));
			jQuery(".sub_ot_total").html("$"+total.toFixed(2));
		}
		
		
	}
	
	/* Remove coupon */
	function removeCoupon(camt){
		if (confirm('Are you sure want to remove coupon?')) {
			jQuery.ajax({
					method: "POST",
					url: "ajax.php",
					dataType:"json",
					data: { 
								coupon_amt:camt,
								act:"ProductDetail",
								method:"removeCoupon"
						}
				}).done(function(obj) {
					var response = jQuery.parseJSON( obj );
					$('.sub_ot_tax').html("$"+response.taxvalues);
						taxVal = response.taxvalues;
						var isAdd = "0";
						var scamt = $("#splitCmat").val();
						calculateAmt('1',scamt,taxVal,isAdd);
						$(".ot_coupon").remove();
					$('.couponData').show();
					$('.rmcouponData').html('');
				});
		}
	}
	
	/* For all calculation */
    function calculate(wid,subTotal,shipVal,taxAmount,isTan){
		var gTotal 		= parseFloat(subTotal)+parseFloat(shipVal)+parseFloat(taxAmount);
		console.log(subTotal);
		console.log(shipVal);
		console.log(taxAmount);
		if(isTan == "0"){
			$(".sub_ot_total").text("$"+gTotal.toFixed(2));
		}else{
			$(".sub_ot_total").text("TBD");
		}
		
		
	}
	/* Show hide special terms */
	function showSpecialterms(elm){
		if($(elm).val() == "1"){
			$(".sp_terms").removeClass('d-none');	
		}else{
			$(".sp_terms").addClass('d-none');
			$("#customers_terms_special").val('');
		}
	}
	
	function getordercustomerData(cid,page='1'){
		jQuery(".lbs-wrap").css("display","block");
		jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
					customer_id:cid,
					page:page,
					act:"CustomerDetail",
					method:"orderCustomerData"
				}
			}).done(function(response) {
				jQuery(".lbs-wrap").css("display","none");
				$(".order_data").html(response.html);
		});
	}
	
	function getsingleOrder(oid,cid){
		jQuery(".lbs-wrap").css("display","block");
		jQuery.ajax({
			method: "POST",
			url: "ajax.php",
			dataType:"json",
			data: { 
				order_id:oid,
				customer_id:cid,
				act:"CustomerDetail",
				method:"orderData"
			}
		}).done(function(response) {
			jQuery(".lbs-wrap").css("display","none");
			$(".order_data").html(response.html);
		});
	}
	function resetData(){
		jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							act:"ProductDetail",
							method:"resetsessionCustomerData"
					}
			}).done(function(response) {
			});
	}
	
	function getPecustomerData(emailId){
		jQuery.ajax({
				method: "POST",
				url: "ajax.php",
				dataType:"json",
				data: { 
							emailId:emailId,
							act:"CustomerDetail",
							method:"sessionCustomerData"
					}
			}).done(function(response) {
				$("#customer_id_head").text(response.id);
				 getordercustomerData(response.id);
				$("#reset_password").removeClass("disabled");
				$("#save_customer").css("display","none");
			    $('#update_customerID,#resetcustomers_id').val(response.id);
				$('#customer_profile').val(response.customers_customerProfileId);
				$('#customers_firstname').val(response.customers_firstname);
				$('#customers_lastname').val(response.customers_lastname);
				$('#customers_telephone').val(response.customers_telephone);
				$('#customers_email_address').val(response.customers_email_address);
				$('#customers_fax').val(response.customers_fax);
				$('#customers_terms_special').val(response.customers_terms_special);
				$('#customers_resale_tax_id_date').val(response.customers_resale_tax_id_date);
				$('#customers_terms_special').val(response.customers_terms_special);
				$('#customers_resale_tax_id').val(response.customers_resale_tax_id);
				if(response.customers_resale_tax_id == ""){
					$(".rTaxdate").addClass('d-none');
				}else{
					$(".rTaxdate").removeClass('d-none');
				}
				$('#customers_special_order_notes').val(response.customers_special_order_notes);
				$('#customers_special_shipping_notes').val(response.customers_special_shipping_notes);
				$('#customers_ups_acct').val(response.customers_ups_acct);
				$('#customers_fedex_acct').val(response.customers_fedex_acct);
				
				if(response.customers_invoice_email == 1){ $('#invoice').attr('checked', true); }
				if(response.customers_invoice_mail == 1){ $('#mail-invoice').attr('checked', true); }
				if(response.customers_invoice_fax == 1){ $('#fax-invoice').attr('checked', true); }
				if(response.customers_blind_ship_enabled == 1){ $('#blind-ship').attr('checked', true); $("#blind_by_default").css("display","block"); }
				if(response.customers_blind_ship_default == 1){ $('#by-default').attr('checked', true); }
				if(response.customer_wholesale == 1){ $('#wholesale').attr('checked', true); }
				if(response.customers_store_pickup_enabled == 1){ $('#store-pickup').attr('checked', true); }
				if(response.customers_custom_ship_date_enabled == 1){ $('#custom_ship_date').attr('checked', true); }
				if(response.customers_ship_collect == 1){ $('#ship-collect').attr('checked', true); $("#fedex_account").css("display","block"); }
				
				$("input[name='customers_ltl_capable'][value='"+response.customers_ltl_capable+"']").prop('checked', true);
				
				$('#customers_terms option[value="'+response.customers_terms+'"]').attr('selected','selected');
				if(response.customers_terms == "1"){
					$(".sp_terms").removeClass('d-none');
				}
				
				$('#discount_grp option[value="'+response.customers_group_pricing+'"]').attr('selected','selected');
				$('#customer_id').val(response.id);
				get_address(response.id);
				$(".address_form").css("display","none");
				$("#address_data").trigger("reset");
				$("#update_address").css("display","none");
				$(".error").css("display","none");
				$("#update_address").trigger("reset");
				$("#address-tab").removeClass("disabled");
				$("#cart-tab").removeClass("disabled");
				$("#payment-tab").removeClass("disabled");
				$("#insert_cusform").addClass("disabled");
				$("#customer_profile_id").val(response.customers_customerProfileId);
				
				
				if(response.customers_customerProfileId == 0)
				{
					addAuthID(response.id,response.customers_email_address,response.customers_customerProfileId);
				}
				else
				{
					get_customerDetil(response.customers_customerProfileId);
				}
				 var customer_id = $("#update_customerID").val();
				cart_table(customer_id,'cart-table');
				return false;
				
			});
	}
	
	/* Update Cart */
	function updateCart(pid){

		// Incorrect:
		var qtyArr = [];
		$( ".pqty" ).each( function( index, element ){
			var val = $(this).attr("data-cost")+'_'+$(this).val();
			qtyArr.push(val);
		});
		jQuery(".lbs-wrap").css("display","block");
		jQuery.ajax({
			method: "POST",
			url: "ajax.php",
			dataType:"json",
			data: { 
						pdata:qtyArr,
						act:"ProductDetail",
						method:"updateCart"
				}
		}).done(function(response) {
			jQuery(".lbs-wrap").css("display","none");
			 var obj = jQuery.parseJSON(response);
			$('.cart_table_contect').html(obj.html.cart);
			$('.pproductStat').html('');
			if(obj.stutsHtml != ""){
				$('.pproductStat').html(obj.stutsHtml);
				$('#statusModal').modal('show'); 
				$.each(obj.status, function( index, value ) {
				  $('.pt_'+index).val(value);
				});
			}
			$('.ship_data').html('');
			$('.ship_methodl').html(obj.html.shipping);
			$('.ordershipping').html(obj.html.shipping);
			$('.updatecrtData').hide();
			$('.neworder-submit').show();
			$('.pqty').on('click', function() {
				$('.updatecrtData').show();
				$('.neworder-submit').hide();
			});
			if($('.ship_methodl .tanlnk').length == 1){
				settanShipping();
			 }
			$(".ship_methodl .preSelct").trigger('click');
		});
	}
	
	function changeqty(){
		$('.updatecrtData').show();
		$('.neworder-submit').hide();
	}
	
	/* Remove Cart */
	function removeCart(pid){
		swal({
			  title: 'Are you sure want to remove this item?',
			  text: "You won't be able to revert this!",
			  icon: 'warning',
			  showCancelButton: true,
			  confirmButtonColor: '#3085d6',
			  cancelButtonColor: '#d33',
			  buttons: true,
			  dangerMode: true,
			}).then((isConfirm) => {
			   if (isConfirm){
					jQuery(".lbs-wrap").css("display","block");
					jQuery.ajax({
						method: "POST",
						url: "ajax.php",
						dataType:"json",
						data: { 
									pid:pid,
									act:"ProductDetail",
									method:"removeCart"
							}
					}).done(function(response) {
						jQuery(".lbs-wrap").css("display","none");
						var obj = jQuery.parseJSON(response);
						$('.cart_table_contect').html(obj.cart);
						$('.updatecrtData').show();
						$('.neworder-submit').hide();
					});
			   }
			});
	}
	
	function setshipCOllect(elm){
		
			if ($(elm).prop("checked")){
				$('.store_pickup').hide();
				$('.usps_pick').hide();
				$('.cstTil').text("$0.00");
				
				$('.slpit_ship_cost').text("0.00");
				$('.cstTil').attr('data-cost',"$0.00");
				 $(".nprice_FedEx").show();
				 $(".price_FedEx").hide();
				 $(".nprice_UPS").show();
				 $(".price_UPS").hide();
				 $(".usps").hide();
				 $(".storepickup").hide();
				 var Usps = $('.usps').length;
				  for(var i=0;i<=Usps;i++){
					  console.log(".usps_"+i);
					  $(".usps_"+i).prop('checked', false);
				  }
				  var shiNumber = $('#fedexwebservices_ship_collect').val();
				 // alert($('.shipval').data('shipid'));
				 if($('.shipval[data-shipid="FEDEXGROUND"]').length > 0){
					  $('.shipval[data-shipid="FEDEXGROUND"]').get(0).click();
					   var tlt =  $('.shipval[data-shipid="FEDEXGROUND"] .seletitlePst').text()+(' Collect (ACC : '+shiNumber+')');
				 }
				 
				 if($('.shipval[data-shipid="GROUNDHOMEDELIVERY"]').length > 0){
					  $('.shipval[data-shipid="GROUNDHOMEDELIVERY"]').get(0).click();
					   var tlt =  $('.shipval[data-shipid="GROUNDHOMEDELIVERY"] .seletitlePst').text()+(' Collect (ACC : '+shiNumber+')');
				 }
				
				  $('#shippingttitle').text(tlt);
			}else{
				 $(".price_FedEx").show();
				 $(".nprice_FedEx").hide();
				 $(".price_UPS").show();
				 $(".nprice_UPS").hide();
				 $(".usps").show();
				 $(".storepickup").show();
				 $('.store_pickup').show();
				$('.usps_pick').show();
				if($('.shipval[data-shipid="FEDEXGROUND"]').length > 0){
					 $('.shipval[data-shipid="FEDEXGROUND"]').get(0).click();
				 }
				 
				 if($('.shipval[data-shipid="GROUNDHOMEDELIVERY"]').length > 0){
					 $('.shipval[data-shipid="GROUNDHOMEDELIVERY"]').get(0).click();
				 }
				
			}
		}