<script type="text/javascript" class="init" id="address_js">
var editor;
var table;
// Data Tables Editor Initialization
editor = new $.fn.dataTable.Editor( {
	ajax: {url: "address_editor.php", type: "POST", data :{'customer_id' : id}},
       table: "#addresses",
//	template: '#addressForm',
	fields: [
		{label: "ID:", name: "address_book.address_book_id"}, 
		{label: "Gender:", name: "address_book.entry_gender"}, 
		{label: "Company:", name: "address_book.entry_company"}, 
		{label: "First Name:", name: "address_book.entry_firstname"}, 
		{label: "Last Name:", name: "address_book.entry_lastname"}, 
		{label: "Street Address 1:", name: "address_book.entry_street_address"}, 
		{label: "Street Address 2:", name: "address_book.entry_suburb"}, 
		{label: "Postcode:", name: "address_book.entry_postcode"}, 
		{label: "City:", name: "address_book.entry_city"}, 
		{label: "State:", name: "address_book.entry_state"}, 
		{label: "State Code:", name: "zones.zone_code"}, 
		{label: "Country:", name: "countries.countries_iso_code_2"}, 
		{label: "Bling Shipping:", name: "address_book.blind_shipping", type: "radio", 
			options: [{ label: "Off", value: 0 },{ label: "On",  value: 1 }], def: 0},
		{label: "Validated for UPS:", name: "address_details.ups_validated", type: "radio", 
			options: [{ label: "Off", value: 0 },{ label: "On",  value: 1 }], def: 0},
		{label: "Validated for Fedex:", name: "address_details.fedex_validated", type: "radio", 
			options: [{ label: "Off", value: 0 },{ label: "On",  value: 1 }], def: 0},
		{label: "UPS Residential:", name: "address_details.ups_residential", type: "radio", 
			options: [{ label: "Off", value: 0 },{ label: "On",  value: 1 }], def: 0},
		{label: "Fedex Residential:", name: "address_details.fedex_residential", type: "radio", 
			options: [{ label: "Off", value: 0 },{ label: "On",  value: 1 }], def: 0},
		{label: "Blind ship to:", name: "address_details.blind_ship_to", type: "radio", 
			options: [{ label: "Off", value: 0 },{ label: "On",  value: 1 }], def: 0},
		{label: "Drop Ship Fee:", name: "address_details.dropship_fee"},
		{label: "Drop Ship  Threshhold:", name: "address_details.dropship_fee_threshhold"}
	]
});
	
//Submit on blur (INLINE)
$('#addresses').on( 'click', 'tbody td:not(:first-child)', function (e) {
	editor.inline( this, {onBlur: 'submit'} );
} );

//Data table
var address_table = $('#addresses').DataTable( {
	autoWidth: false,
	serverSide: true,
	dom: '<<"fl"<"toolbar">><"fl"B>f<t>ip>',
	lengthMenu: [ [5, 10, 25, 50,100,-1], [5, 10, 25, 50, 100, "All"] ],
	ajax: {url: "address_editor.php", type: "POST", data :{'customer_id' : id}},
	select: true,
	buttons: [
		{ extend: "create", editor: editor },
		{ extend: "edit",   editor: editor },
		{ extend: "remove", editor: editor },
		{ extend: 'collection', text: 'Export', buttons: ['copy','excel','csv','pdf','print']}	
	],
	columns : [
		{data: 'address_book.address_book_id', type: 'num' },
		{data: 'address_book.entry_company' },
		{data: 'address_book.entry_firstname' },
		{data: 'address_book.entry_lastname' },
		{data: 'address_book.entry_street_address' },
		{data: 'address_book.entry_suburb' },
		{data: 'address_book.entry_city' },
		{data: 'zones.zone_code' },
		{data: 'address_book.entry_postcode' }
	],
	fnInitComplete: function(){
		options = '';
		address_table.columns( 0 ).data()
			.eq( 0 )      // Reduce the 2D array into a 1D array of data
//			.sort()       // Sort data alphabetically
			.unique()     // Reduce to unique values
			.each(function ( value, index ) {
				options += '<option' + (customers_default_address_id==value?' selected ':'') + ' value="' + value + '">' + value + '</option>';
			});
		$('div.toolbar').html('<div class="tr default_address"><div class="tc sm_head">Default Address Id</div></div><div class="tr default_address"><div class="tc cj"><select name="customers_default_address_id" id="customers_default_address_id">' + options +'</select></div></div>');
		$('#customers_default_address_id').on('change', function() {
			customers_default_address_id=$('#customers_default_address_id').val();
			address_table.column( 0 ).data()
				.each(function ( value, index ) { //loop through values
					if ( value == customers_default_address_id ) {
						$('tr.default_address').removeClass("default_address");
						$('#row_'+value).addClass('default_address');
					}
				});
		});
	},
	createdRow: function( row, data, dataIndex ) {
		if ( data['DT_RowId'] == 'row_'+customers_default_address_id ) {
			$(row).addClass('default_address');
		}
	}
});

function filterGlobal () {
	$('#addresses').DataTable().search($('#global_filter').val()).draw();
}


</script>	
<style>
.newline {clear:both;}
.default_address {background-color: lightgreen !important;}
.fl{float:left;display:inline-block}
.cj{text-align:center;}
.toolbar {padding-right:50px;}
</style></head>
<body>
<table id="addresses" class="display" cellspacing="0" style="width:100%; table-layout:fixed; word-wrap:break-word;">
<thead><tr>
	<th>ID</th>
	<th>Company</th>
	<th>First Name</th>
	<th>Last Name</th>
	<th>Street Address 1</th>
	<th>Street Address 2</th>
	<th>City</th>
	<th>State</th>
	<th>Postcode</th>
</tr></thead>
<tbody>
</tbody></table>

</body>
</html>
