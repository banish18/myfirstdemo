LaravelFCM\Response\Exceptions\UnauthorizedRequestException
===============

Class UnauthorizedRequestException




* Class name: UnauthorizedRequestException
* Namespace: LaravelFCM\Response\Exceptions
* Parent class: Exception







Methods
-------


### __construct

    mixed LaravelFCM\Response\Exceptions\UnauthorizedRequestException::__construct(\GuzzleHttp\Psr7\Response $response)

UnauthorizedRequestException constructor.



* Visibility: **public**


#### Arguments
* $response **GuzzleHttp\Psr7\Response**


