<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NoteCommentData extends Model
{
  public function doc_detail() {				  
	  return $this->belongsTo('App\User', 'doctor_assistant_ids');	  
	}
	public function doc_image() {				  
	  return $this->hasOne('App\UserDetail', 'user_id', 'doctor_assistant_ids');	  
	}
	public function doc_profile() {		
		return $this->belongsTo('App\Doctors',  'doctor_assistant_ids', 'user_id');	
	}
}
