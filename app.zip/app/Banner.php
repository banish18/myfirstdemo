<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
	function cityBanner(){
		return $this->hasOne('App\CityOffer' , 'id', 'city_id');
	}
	
	function service() {		
		return $this->belongsTo('App\Service' , 'service');
	}
}

