<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppoitmentTimeslot extends Model
{
    
	
}
