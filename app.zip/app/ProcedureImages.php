

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProcedureImages extends Model
{
   protected $table = 'procedure_foloup_images';
   protected $fillable = ['procedure_id','user_id','images','appointment_id'];

}
