<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DoctorTimeslot extends Model
{
    
	
}
