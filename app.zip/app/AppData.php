<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppData extends Model
{
    
	
}
