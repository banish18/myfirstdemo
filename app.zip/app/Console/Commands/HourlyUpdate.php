<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Mail;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests;
use Auth;
use Config;
use Hash;
use App;
use DateTime;
use App\User;
use App\AppointmentList;
use App\Mail\AppointmentNotifyMail;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;
use FCM;

class HourlyUpdate extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'hour:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send an hourly email to all the user for pending booking';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
		$today 		= date('Y-m-d 00:00:00');
		$AppointmentLists = AppointmentList::where('appointment_date', '>',[$today])->where('is_visited','0')->get();
		if(!$AppointmentLists->isEmpty()){
			foreach($AppointmentLists as $list){
				$user = User::where("id",$list->user_id)->first();
				/*
				 * 
				 * Email to the user 
				 * 
				 **/
				$name 		= $user->name;
				$email 		= "dottechnologies123@gmail.com";
				$message 	= 'Appointment';
				$data = array('subject' => "Contact us",'from' => "support@kabera.com", 'name' => $name, 'email' => $email, 'appointment_date' => $list->appointment_date, 'message' => $message);
				Mail::to($email)->send(new AppointmentNotifyMail($data));
				/*
				 * 
				 * Notification to the user 
				 * 
				 **/
				if(isset($user->device_id)){
					$deviceToken = $user->device_id;
					if(!empty($deviceToken)){
						$optionBuilder = new OptionsBuilder();
						$optionBuilder->setTimeToLive(60*20);
						$option = $optionBuilder->build();
						$notificationBuilder = new PayloadNotificationBuilder();
						$title = "Appointment Notifiction";
						$description = "Your appointment is scheduled on Date :- ".date('Y-m-d',strtotime($list->appointment_date))." Time :- ".date('H:i: A',strtotime($list->appointment_date));
						$notificationBuilder->setTitle($title)
							->setBody($description)
							->setSound('default');
						$notification 		= $notificationBuilder->build();
						$dataBuilder 		= new PayloadDataBuilder();
						$dataBuilder->addData(['a_data' => 'my_data']);
						$data 				= $dataBuilder->build();
						$token 				= $deviceToken;
						$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);
						$downstreamResponse->numberSuccess();
						$downstreamResponse->numberFailure();
						$downstreamResponse->numberModification();
						echo "Notification Sent";
					}else{
						return $this->sendResponse(Config::get('constants.status.OK'),"N/A", null);
					}
				}
			}
		}
		
    }
}
