<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\FollowUpReminder;
use App\OperationList;
use App\ReminderList;
use App\User;
use App\Mail\ReminderEmail;
use App\SmsApi;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;

class FollowReminder extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'follow:reminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send follow up on mail to clients who taken a treatment';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
      date_default_timezone_set('Asia/Kolkata');
	  $currentdate = date( 'Y-m-d');
	  $checkreminder = ReminderList::where("reminder_date",$currentdate)->get();
	  $reminder_mail_data = [];
	  foreach($checkreminder as $reminder)
	  {
		  $reminder_id = $reminder->reminder_id;
		  $reminder_did = $reminder->id;
		  $user_id = $reminder->user_id;
		  $user_detail = User::find($user_id);
		  $useremail = $user_detail->email;
		  $username = $user_detail->name;
		  $phone = $user_detail->phone;
		  
		  
		  $reminders_data =  FollowUpReminder::where('id' ,$reminder_id)->first();
		  
		  
		  $reminder_title = $reminders_data['title'];
		  $reminder_des = strip_tags($reminders_data['description']);
		  $reminder_mail_data = array('title' => $reminder_title,'desc' => $reminder_des,'username' => $username);
		  
		  $mail_send = Mail::to($useremail)->send(new ReminderEmail($reminder_mail_data));
		  $message = strip_tags($reminder_des);
		  $SmsApi 	 = new SmsApi();
		 // $send_message = $SmsApi->sendSMS($phone, $message);
		//if($mail_send)
		//{
		//	ReminderList::where('id',$reminder_did)->delete();	 
		//}
		  
	  }
	  
	  
	  
    }
}
