<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeamStatusReports extends Model
{
	 public function user_detail() {				  
	  return $this->belongsTo('App\User','comment_to');	  
	 }
	
}
