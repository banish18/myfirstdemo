<?php

namespace App;
use App\SubService;

use Illuminate\Database\Eloquent\Model;

class ProcedureReview extends Model
{
	public function subservice()
	{
	  return $this->belongsTo(Subservice::class,'service_id','service_id' );  
	}
	
}
