<?php

namespace App;
use App\SubService;

use Illuminate\Database\Eloquent\Model;

class Procedure extends Model
{

	
	public function user()
	{  
	  return $this->belongsTo(User::class,'user_id' );
	}
	public function userDetail()
	{  
	  return $this->belongsTo(UserDetail::class,'user_id','user_id' );
	}
    public function serviceDetail()
	{  
		return $this->belongsTo(Subservice::class,'service','id' );
	}
	public function doctor()
	{  
	  return $this->belongsTo(Doctors::class,'doctor_id' );
	}	
	public function Offer()
	{  
	  return $this->belongsTo(Offer::class,'offer_apply' );
	}
	
	public function paymentOption()
	{  
	  return $this->belongsTo(ProcedureOption::class,'payment_option' );
	}
	
	public static function getUser($id){
		$user = User::find($id);
		return $user;
	}
}
