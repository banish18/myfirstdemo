<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReferralPoint extends Model
{
   protected $table = 'referral_points';
   protected $fillable = ['user_id','total_points','used_points'];
   
   public function user()
	{
	  return $this->belongsTo('App\User','user_id');
	}
}
