<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProcedureOtp extends Model
{
	  protected $fillable = [
        'phone', 'otp', 'expired_at'
		];
}
