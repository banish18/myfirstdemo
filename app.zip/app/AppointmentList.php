<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppointmentList extends Model
{    
    public function user_detail() {				  
	  return $this->belongsTo('App\User', 'user_id');	  
	}
	public function doc_detail() {				  
	  return $this->belongsTo('App\User', 'doctor_id');	  
	}
	public function doc_image() {				  
	  return $this->hasOne('App\UserDetail', 'user_id', 'doctor_id');	  
	}
	
	public function serviceDetail() {				  
	  return $this->belongsTo('App\SubService', 'service_id');	  
	}	
	
	public function procedure() {				  
	  return $this->belongsTo('App\Procedure', 'procedure_id');	  
	}	
	
	public function doctorDetail() {				  
	  return $this->hasOne('App\Doctors', 'user_id','doctor_id');	  
	}
	public static function whereInMultiple(array $columns, $values)
    {
        $values = array_map(function (array $value) {
            return "('".implode($value, "', '")."')"; 
        }, $values);

        return static::query()->whereRaw(
            '('.implode($columns, ', ').') in ('.implode($values, ', ').')'
        );
    }    
    public function call_records() {				  
	  return $this->hasMany('App\Dials', 'appointment_id');	  
	}
	
}
