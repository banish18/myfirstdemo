<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OperationList extends Model
{
	public function user() {				  
	  return $this->belongsTo('App\User', 'user_id');	  
	} 
	   
	public function user_detail() {				  
	  return $this->belongsTo('App\UserDetail', 'user_id');	  
	}    

	public function serviceDetail() {				  
	  return $this->belongsTo('App\Service', 'service_id');	  
	}
	public function subserviceDetail() {				  
	  return $this->belongsTo('App\SubService', 'service_id');	  
	}
	
	public function doctorDetail() {				  
	  return $this->hasOne('App\Doctors', 'user_id','doctor_id');	  
	}
}
