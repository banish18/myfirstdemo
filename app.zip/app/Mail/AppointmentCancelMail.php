<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class AppointmentCancelMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return user
     */
    public function __construct($user)
    {
         $this->data = $user;
    }
 
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {	
		
        return $this->from('support@kabera.com')
        ->subject('Cancellation update of your appointment')
        ->view('emails.appointmentcancel')
        ->with(['data'=>$this->data]);
        //return $this->subject('Kabera Verification')->view('emails.verifyUser')->with(['user'=>$this->user]);;
    }
}
