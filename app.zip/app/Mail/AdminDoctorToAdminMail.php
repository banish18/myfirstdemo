<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class AdminDoctorToAdminMail extends Mailable
{
    use Queueable, SerializesModels;

   public function __construct($data)
    {
        $this->data = $data;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
		 return $this->from('support@kabera.com')
        ->subject('A New Message From Doctor')
        ->view('emails.admin_doctor_to_admin')
        ->with(['data'=>$this->data]);
    }
}
