<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppointmentRequest extends Model
{    
   public function appointment()
	{  
	  return $this->belongsTo('App\AppointmentList','appointment_id');

	} 
	public function subService() {
		
		return $this->belongsTo('App\SubService','service_id');
	}
}
