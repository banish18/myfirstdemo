<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class DirectPaymentRecord extends Model
{

}
