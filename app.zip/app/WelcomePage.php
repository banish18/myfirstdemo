<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WelcomePage extends Model
{
	protected $table    = 'app_welcome_pages';
    protected $fillable = [
        'title_en',
        'title_fr',
        'description_en',
        'description_fr',
        'image_name',
        'image_path'
    ];
}
