<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CartItem extends Model
{
	public function productDetail()
    {
    	return $this->belongsTo('App\Product','product_id');
    }
    
    public function procedureDetail() {
		return $this->belongsTo('App\HairTransplantReport','product_id');		
	}
    
    public function offerDetail() {
		return $this->belongsTo('App\Offer','product_id');		
	}
}
