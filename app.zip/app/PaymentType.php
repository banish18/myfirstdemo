<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentType extends Model
{
	 protected $fillable = [
        'user_id',
        'procedure_id',
        'amount',
        'payment_type',
        'created_at',
        'updated_at'
    ];
    
    public function user(){
		return $this->hasOne('App\User','id','doctor_id');
	}
}
