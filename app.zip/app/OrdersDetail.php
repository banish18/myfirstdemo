<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrdersDetail extends Model
{
	protected $table = 'order_details';
    //
    public function productDetails()
	{
		return $this->hasMany('App\Product','id','product_id');
	}
	public function procedureDetails()
	{
		return $this->hasMany('App\Procedure','id','product_id');
	}
}
