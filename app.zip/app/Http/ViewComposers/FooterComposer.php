<?php

namespace App\Http\ViewComposers;

use App\Page;

class FooterComposer
{
    public function compose($view)
    {
		$Footer  =  Page::where('template','Footer')->where('data_type','footer data')->first();
        $view->with('footer', $Footer);
    }
}
