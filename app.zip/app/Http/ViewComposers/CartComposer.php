<?php

namespace App\Http\ViewComposers;

use Auth;
use App\Cart;
use App\CartItem;
class CartComposer
{
    public function compose($view)
    {
		$cartQty  	     = "0";
		$headcart        = [];
		$cartContent     = [];
		if(Auth::check()){
			 $user_id		= Auth::user()->id;
			 $headcart 		= Cart::where('user_id',$user_id)->first();
			 if($headcart){
				 //$cartContent  = CartItem::where('cart_id',$headcart->id)->with('productDetail')->get()->toArray();
				 $cartContent['product']   = CartItem::where('cart_id',$headcart->id)->where('is_type','product')->with('productDetail')->get()->toArray();
				 $cartContent['procedure'] = CartItem::where('cart_id',$headcart->id)->where('is_type','procedure')->with('procedureDetail')->get()->toArray();
				 $cartContent['package']   = CartItem::where('cart_id',$headcart->id)->where('is_type','package')->with('offerDetail')->get()->toArray();
				//echo "<pre>"; print_r($cartContent['procedure']); die;
			 }
		}
		$data = array('headcart' => $headcart,'carts' => $cartContent);
		$view->with('cartData', $data);
    }
}
