<?php

namespace App\Http\ViewComposers;
use Auth;
use App\User;
use App\NoteCommentData;
use App\AppointmentList;
use Config;


class CommonComposer
{
    public function compose($view)
    {	
		$lang = Config::get('app.locale');
		$User         = [];
		$comment_data = [];
		$appoitment_data = [];
		$total        = [];
		if(Auth::check()){
			$User = User::where('id',Auth::user()->id)->with('userDetail')->first();
			$comment_data  = NoteCommentData::with(['doc_detail','doc_image'])->with(array('doc_profile'=>function($query){$query->select('id','user_id','profile_picture');}))->where('user_id',Auth::user()->id)->where('visible_to',1)->orderby('id','desc')->get();
			
			$appoitment_data  = AppointmentList::where('user_id',Auth::user()->id)->orderby('id','desc')->get();
			
			$total = count($comment_data);
			
		}
		$dataArray = array('lang' => $lang, 'User' => $User,'comment_data' => $comment_data,'total' => $total,'appoitment_data' => $appoitment_data);
        $view->with($dataArray);
   
    }
}
