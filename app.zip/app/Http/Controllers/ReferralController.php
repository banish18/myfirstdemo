<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\ReferralData;
use App\ReferralPoint;
use Auth;
use Session;
use Validator;
use App\Mail\ReferralEmail;
use App\Mail\ReferralAdminEmail;
use App\Mail\DirectReferralEmail;
use App\Mail\DirectReferralUserEmail;
use App\SmsApi;
use App\ReferralPointsData;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;

class ReferralController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       // $this->middleware(['auth','verified']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('user.refer');
    }

    public function postReffer(Request $request)
    {
		
		 $validatedData = $request->validate([
				'email' => 'required|email|unique:users',
				'phone'	=> 'required|min:9|numeric', 
			]);
		
		$referto_email = $request->input('email');
		$referto_phone = $request->input('phone');
		$refer_type = $request->input('ref_type');
		$referby_id =  auth()->user()->id; 
		$referby_name =  auth()->user()->name; 
		$referraCode = $this->random_strings(6);
		$encrypt_ref = encrypt($referraCode);
		$super_admin_email = env('KABERA_ADMIN_EMAIL');
		$referral_url = URL::to('/register?refferal='.$encrypt_ref.'&reffer_email='.$referto_email);
		$images = array();
		
		
		
		if($request->hasfile('photo')) 
			{
				$allowedfileExtension=['jpg','png','jpeg','gif'];
				
				$size = [];
				foreach($request->file('photo') as $image)
				{	
					$folder           = 'referred_images/';
					$random_number 	  = mt_rand(100000, 999999);
					$extension = $image->getClientOriginalExtension();
					$name = $random_number.'.'.$extension; 
				    
					$size[] = $image->getSize();  
					
					$check = in_array($extension , $allowedfileExtension); 
					  if($check)
					  {
						$image_size = 2000000;
						$total_size = array_sum($size);
						if($total_size > $image_size)
						{
						return redirect('/refer')->with('error', 'Images size must be less than 2 mb');	
						}
					  	$image->move(public_path().'/images/referred_images/', $name);                  
					  	array_push($images , $folder.$name);
					  }
					  else
					  {
						return redirect('/refer')->with('error', 'Sorry Only Upload png , jpg , gif images');  
					  }
					}
					$user_image_data = implode(",",$images);
				}
				else
				{
					$images = [];
					$user_image_data = "";
				}
				
				
		$user_image_path = $images;
		$check_user_already_referred =  ReferralData::where("ref_to_email",$referto_email)->first();
		
		
		
		if(empty($check_user_already_referred))
		{
		$check_ref_exist = ReferralData::where("ref_from",$referby_id)->where("ref_to_email",$referto_email)->first();
		
		if($check_ref_exist == null)
		{
		//$decrypt_ref = decrypt($referraCode);
			$referralData = new ReferralData;
			$referralData->user_id = $referby_id;
			$referralData->ref_from = $referby_id;
			$referralData->ref_from = $referby_id;
			$referralData->ref_code = $referraCode;
			$referralData->ref_to_email = $referto_email;
			$referralData->ref_to_phone = $referto_phone;
			$referralData->status = 0;
			$referralData->ref_type = $refer_type;
			$referralData->points = 0;
			$referralData->ref_photo_path = $user_image_data;
			$referralData->point_des = "Referred to someone";
			$referralData->expire_date = "";
			$referralData->save();
		}
		else
		{
			ReferralData::where("ref_from",$referby_id)->where("ref_to_email",$referto_email)->update(['ref_code' => $referraCode,'ref_to_phone' => $referto_phone,'ref_photo_path' => implode(",",$images)]);
		}
		
		$message  = 'you will got a 250 point by register using the refferal link or using refferal code on kabera';
		$message .= 'Referral url :'.$referral_url;
		$message .= 'Referral code :'.$referraCode;
		
		$SmsApi 	 = new SmsApi();
		$send_message = $SmsApi->sendSMS($referto_phone, $message);
		
		$data = array('referral_url' => $referral_url,'referral_code' => $referraCode,'user_image' => $user_image_path);
		
		$adminData = array('Ref_by' => $referby_name,'ref_email' => $referto_email,'ref_phone' => $referto_phone,'user_image' => $user_image_path);
		
		
       Mail::to($referto_email)->send(new ReferralEmail($data));
       Mail::to($super_admin_email)->send(new ReferralAdminEmail($adminData));
       
       if($send_message['success'] == 1)
		{
			$sms_response = "Successfully Referred !! Mail/SMS has been sent to their referred email address/phone number";
		}
		else
		{
			$sms_response = "Successfully Referred !! Mail has been sent and your phone number have ".$send_message['message']."error";
		}
		
		return redirect('/refer')->with('success', $sms_response);
	  }
	  else
	  {
		  return redirect('/refer')->with('error', 'Sorry user already referred!!');
	  }
		
    }
    
    public function directReffer(Request $request)
    {
		$validatedData = $request->validate([
				'name'			=> 'required', 
				'email' 		=> 'required|email|unique:users',
				'phone'			=> 'required|min:9|numeric', 
				'photo'			=> 'required', 
				'service_type'	=> 'required'
			]);
	    $images = array();
		$random_number	= mt_rand(100000, 999999);
		$referto_name = $request->input('name');
		$referto_email = $request->input('email');
		$referto_phone = $request->input('phone');
		$refer_type = $request->input('ref_type');
		$referto_service = $request->input('service_type');
		$referby_id =  auth()->user()->id; 
		$referby_name =  auth()->user()->name; 
		$direct_points = ReferralPointsData::all();
		
		 if($request->hasfile('photo')) 
			{
				$allowedfileExtension=['jpg','png','jpeg','gif'];
				
				$size = [];
				foreach($request->file('photo') as $image)
				{	
					$folder           = 'referred_images/';
					$random_number 	  = mt_rand(100000, 999999);
					$extension = $image->getClientOriginalExtension();
					$name = $random_number.'.'.$extension;
					$size[] = $image->getSize();  
					
					$check = in_array($extension , $allowedfileExtension); 
					  if($check)
					  {
						$image_size = 2000000;
						$total_size = array_sum($size);
						if($total_size > $image_size)
						{
						return redirect('/refer')->with('error', 'Images size must be less than 2 mb');	
						}
					  	$image->move(public_path().'/images/referred_images/', $name);                  
					  	array_push($images , $folder.$name);
					  }
					  else
					  {
						return redirect('/refer')->with('error', 'Sorry Only Upload png , jpg , gif images');  
					  }
					}
				
			}
		
		
		    
			
			
			$referral_point = $direct_points[0]->direct_points;
			$super_admin_email = env('KABERA_ADMIN_EMAIL');
			$user_image_path = $images;
			
			
			$check_user_already_referred =  ReferralData::where("ref_to_email",$referto_email)->first();
			$check_point_data = ReferralPoint::where("user_id",$referby_id)->first();
			
			if($check_user_already_referred == null)
			{
				$referralData = new ReferralData;
				$referralData->user_id = $referby_id;
				$referralData->ref_from = $referby_id;
				$referralData->ref_code = "";
				$referralData->ref_to_email = $referto_email;
				$referralData->ref_to_phone = $referto_phone;
				$referralData->status = 1;
				$referralData->ref_type = $refer_type;
				$referralData->service_type = $referto_service;
				$referralData->ref_photo_path = implode(",",$images);
				$referralData->points = $referral_point;
				$referralData->point_des = "direct referred to someone";
				$referralData->expire_date = "";
				$referralData->save();
				
				
				
				/* insert total points of direct referred by user */
				if(count($check_point_data) > 0)
				{
					$reffrom_user_points = ReferralData::where("user_id", $referby_id)->sum('points');
					$reffrom_used_points = $check_point_data->used_points;
					$reffrom_pending_points = $reffrom_user_points - $reffrom_used_points;
					ReferralPoint::where("user_id",$referby_id)->update(['total_points' => $reffrom_pending_points]);
				}
				
					
				
				
				$data = array('name' => $referto_name,'email' => $referto_email, 'phone' => $referto_phone, 'user_image' => $user_image_path, 'service_type' => $referto_service);
				
				$user_message =  "You have reffered by ".$referby_name.", Kabera team contact to you soon !!";
				$udata = array('user_message' => $user_message);
				
				$SmsApi 	 = new SmsApi();
				$SmsApi->sendSMS($referto_phone, $user_message);
				
				Mail::to($referto_email)->send(new DirectReferralUserEmail($udata));
				Mail::to($super_admin_email)->send(new DirectReferralEmail($data));
				
				return redirect('/refer')->with('success', 'Successfully submitted our team contact to Referred user as soon as possible');
			}
			else
			{
				return redirect('/refer')->with('error', 'Sorry user already referred!!');
			}
		
		
		
		
    }
    
     public function totalPoints()
    {
		$current_user_id =  auth()->user()->id; 
	    $get_total_points = ReferralPoint::where("user_id",$current_user_id)->first();
	    if(!empty($get_total_points))
	    {
	    $total_points = $get_total_points->total_points;
	    $used_points = $get_total_points->used_points;
	    $total_referral_recode = array();
		$referral_points['total_points'] = $total_points;
		$referral_points['used_points'] = $used_points;
		$total_referral_recode[] = $referral_points;
		}
		else
		{
			$total_referral_recode = [];
		}
	    
	    $referred_data = ReferralData::where("user_id",$current_user_id)->get();
	    
		
		
		return view('user.refer-point', compact(['referred_data','total_referral_recode']));
		
	}

	// This function will return a random 
	// string of specified length 
	function random_strings($length_of_string) { 
		
		// md5 the timestamps and returns substring 
		// of specified length 
		return substr(md5(time()), 0, $length_of_string); 
	}
	

}
