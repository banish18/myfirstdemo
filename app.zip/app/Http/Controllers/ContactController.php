<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Contact;
use App\BecomeAPatner;
use Auth;
use Session;
use Validator;
use App\Mail\AdminpartnerEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Response;
use App\Countries;
use App\HairTransplantReport;
use App\DirectPaymentRecord;
use DB;


class ContactController extends Controller
{
    /**
     * Create a new Function to save contact us data.
     *
     * @return slides, offers
    */
	public function savecontact(Request $request) {
		
		$validatedData = $request->validate([
			'name' => 'required',
			'emailaddress' => 'required|email',
			'phone'	=> 'required|min:9|unique:users', 
			'city' => 'required',
			'your-message' => 'required',
		]);
		
		$name = $request->input('name');
		$email = $request->input('emailaddress');
		$phone = $request->input('phone');
		$city = $request->input('city');
		$message = $request->input('your-message');
		$super_admin_email = "dotstudent203@gmail.com";
		
		$contact = new Contact;
		$contact->name = $name;
		$contact->email = $email;
		$contact->phone = $phone;
		$contact->city = $city;
		$contact->message = $message;
		$contact->save();
		
		$data = array('subject' => "Contact us",'from' => "support@kabera.com", 'name' => $name, 'email' => $email, 'phone' => $phone, 'city' => $city, 'contactmessage' => $message);
		
		Mail::to($email)->send(new ContactEmail($data));
		Mail::to($super_admin_email)->send(new AdmincontactEmail($data));
        //Mail::send('emails.contact', $data, function($messaged)use($email){
		//  $messaged->from('support@kabera.com');
		//  $messaged->to($email);
		//  $messaged->subject('Contact us');
		//});		
		
		return redirect('/contact-us')->with('success', 'Thank you for your message. It has been sent.');
		
		
	}
	
	
	//~ public function payment(Request $request) 
	//~ {
		
		//~ $report = HairTransplantReport::all(); 
			
		//~ //$countries = Countries::all();	
		//~ $countries = DB::table("countries")->pluck("name","id");
		//~ return view('payment',compact(['countries','report']));

	//~ }
	
	
	public function payment()
        {
            $countries = DB::table("countries")->pluck("name","id");
            return view('payment',compact('countries'));
        }

        public function getStateList(Request $request)
        {
            $states = DB::table("states")
            ->where("country_id",$request->country_id)
            ->pluck("name","id");
            return response()->json($states);
        }

        public function getCityList(Request $request)
        {
            $cities = DB::table("cities")
            ->where("state_id",$request->state_id)
            ->pluck("name","id");
            return response()->json($cities);
        }
	public function paymentsave(Request $request) {
		$DirectPaymentRecord 				= new DirectPaymentRecord;
		$DirectPaymentRecord->name 			= $request->name;
		$DirectPaymentRecord->email 		= $request->email;
		$DirectPaymentRecord->phone_number 	= $request->phone;
		$DirectPaymentRecord->address 		= $request->address;
		$DirectPaymentRecord->country 		= $request->state;
		$DirectPaymentRecord->state 		= $request->city;
		$DirectPaymentRecord->city 			= $request->amount;
		$DirectPaymentRecord->save();
	}
	
	public function becomepatnerContact(Request $request) {
		
		$validatedData = $request->validate([
			'name' => 'required',
			'emailaddress' => 'required|email',
			'phone'	=> 'required|min:9|unique:users', 
			'clinic_address' => 'required',
			'your-message' => 'required',
		]);
		
		$name = $request->input('name');
		$email = $request->input('emailaddress');
		$phone = $request->input('phone');
		$clinic_address = $request->input('clinic_address');
		$message = $request->input('your-message');
		$super_admin_email = "dotstudent203@gmail.com";
		
		$BecomeAPatner = new BecomeAPatner;
		$BecomeAPatner->name = $name;
		$BecomeAPatner->email = $email;
		$BecomeAPatner->phone = $phone;
		$BecomeAPatner->clinic_address = $clinic_address;
		$BecomeAPatner->description = $message;
		$BecomeAPatner->save();
		
		$data = array('subject' => "Become a partner",'from' => "support@kabera.com", 'name' => $name, 'email' => $email, 'phone' => $phone, 'clinic_address' => $clinic_address, 'contactmessage' => $message);
		
		Mail::to($super_admin_email)->send(new AdminpartnerEmail($data));
        //Mail::send('emails.contact', $data, function($messaged)use($email){
		//  $messaged->from('support@kabera.com');
		//  $messaged->to($email);
		//  $messaged->subject('Contact us');
		//});		
		
		return redirect('/become-kabera-clinic')->with('success', 'Thank you for your message. It has been sent.');
		
	}
   
}
