<?php
namespace App\Http\Controllers\Doctor;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\User;
use App\Role;
use App\RoleUser;
use App\Doctors;
use App\Service;
use App\DoctorAssistant;
use Auth;


class DoctorController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
     
    public function __construct() {
		 
		$this->middleware(['auth','verified']);
	}
   
    /**
     * Get Doctors  
    **/
	public function index(){
		$doctor		  = Auth::user();
		$DoctorProile = Doctors::where('user_id',$doctor->id)->first();
		$skills       = json_decode($DoctorProile->skills);	
		$skills       = $DoctorProile->sub_skills;	
		return view('doctor.dashboard',compact(['doctor','DoctorProile']));
	}
}
