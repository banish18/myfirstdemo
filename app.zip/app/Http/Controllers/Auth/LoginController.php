<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Session;
use DateTime;
use DateInterval;
use App\User;
use App\SmsApi;
use App\ForgotOtp;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendOtpMail;
use DB;
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    //protected $redirectTo = '/profile';
    
    //The redirectTo method will take precedence over the redirectTo property. 
    //This allows us to define logic to handle users with different role to different paths.
	public function redirectTo(){
		$role = Auth::user()->role;
		/*if(Auth::user()->notVerified()) {			
			Auth::logout();	
			Session::flash('error', 'Your Account has not been activated yet');		 
			return '/login';
		}*/
		if(Auth::user()->isAdmin()){
			return '/admin/dashboard';
		}elseif(Auth::user()->isNormalUser()){
			return '/';
		}else{
			Auth::logout();	
			Session::flash('error', 'Sorry! You are not authorized to login here.');		 
			return '/login'; 
		}
		echo $role;
		die;
	}

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
    
    
    
	/*** function to check login detail and send otp **/	
	public function login(Request $request)
    {	 
        if(!empty($request->input('phone')) && empty($request->input('email')) ) {
			$user = User::where('phone', $request->get('phone'))->where('role','3')->first();
				 if($user == null) {
					return redirect()->back()->with(['error' => 'Your phone number not match in our system..!!']);
				  } else {
					        $time 	 = new DateTime(date('Y-m-d H:i:s'));
							$time->add(new DateInterval('PT5M'));
							$expTime = $time->format('Y-m-d H:i:s');
							$OTP     =  mt_rand(100000, 999999);
							
							$forgotOtp  = ForgotOtp::firstOrNew(['user_id'=>$user->id,'type'=>'login']);
							$forgotOtp->user_id    =  $user->id;
							$forgotOtp->type   	   =  'login';
							$forgotOtp->otp 	   =  $OTP;
							$forgotOtp->expired_at = $expTime;							
							$forgotOtp->save();
								
							$message	 = "Dear ".$user->name.", Please use this otp to login (".$OTP .")";
							$SmsApi 	 =  new SmsApi();
							$SmsApi->sendSMS($user->phone, $message);
							
							$mdata['email']     = $user->email;
						    $mdata['name']      = $user->name;
						    $mdata['otp']  		= $OTP;	
							Mail::to($user->email)->send(new SendOtpMail($mdata));
		
							return redirect('/login/match-otp/'.$user->id)
							  ->with(['success' => 'You will receive OTP on phone and email to login your account']);
						}
		} else if (!empty($request->get('email')) && empty($request->get('phone'))) {
			$user = User::where('email', $request->get('email'))->where('role','3')->first();
				 if($user == null) {
					return redirect()->back()->with(['error' => 'Your E-mail not match in our system..!!']);
				  } else {
					  
							$time 	 = new DateTime(date('Y-m-d H:i:s'));
							$time->add(new DateInterval('PT5M'));
							$expTime = $time->format('Y-m-d H:i:s');
							$OTP     =  mt_rand(100000, 999999);
							
							$forgotOtp  = ForgotOtp::firstOrNew(['user_id'=>$user->id,'type'=>'login']);
							$forgotOtp->user_id    =  $user->id;
							$forgotOtp->type   	   =  'login';
							$forgotOtp->otp 	   =  $OTP;
							$forgotOtp->expired_at = $expTime;							
							$forgotOtp->save();
							
						    $message	 = "Dear ".$user->name.", Please use this otp to login (".$OTP .")";
							$SmsApi 	 =  new SmsApi();
							$SmsApi->sendSMS($user->phone, $message);
							
							$mdata['email']     = $user->email;
						    $mdata['name']      = $user->name;
						    $mdata['otp']  		= $OTP;	
							Mail::to($user->email)->send(new SendOtpMail($mdata));
							
							return redirect('/login/match-otp/'.$user->id)
							  ->with(['success' => 'You will receive OTP on phone and email to login your account']);
				  }
		} else {
			return redirect()->back()->with(['error' => 'Credential wrong ..!!']);	
			
		}        
    }
    
    /** resend Login OTP **/    
    public function resendOTP($id) {
		
		$user = User::find($id);
		if($user == null) {
			return redirect()->back()->with(['error' => 'Sorry! this user is not exist on our system.']);
		} else {
			  
				$time 	 = new DateTime(date('Y-m-d H:i:s'));
				$time->add(new DateInterval('PT5M'));
				$expTime = $time->format('Y-m-d H:i:s');
				$OTP     =  mt_rand(100000, 999999);
				
				$forgotOtp  = ForgotOtp::firstOrNew(['user_id'=>$user->id,'type'=>'login']);
				$forgotOtp->user_id    =  $user->id;
				$forgotOtp->type   	   =  'login';
				$forgotOtp->otp 	   =  $OTP;
				$forgotOtp->expired_at = $expTime;							
				$forgotOtp->save();
				
				$message	 = "Dear ".$user->name.", Please use this otp to login (".$OTP .")";
				$SmsApi 	 =  new SmsApi();
				$SmsApi->sendSMS($user->phone, $message);
				
				$mdata['email']     = $user->email;
				$mdata['name']      = $user->name;
				$mdata['otp']  		= $OTP;	
				Mail::to($user->email)->send(new SendOtpMail($mdata));
				
				return redirect('/login/match-otp/'.$user->id)
					  ->with(['success' => 'OTP resend on your email/phone']);
		}
		
	}
    
    
    public function LoginOTPView($user_id) {
		$_COOKIE['device_id'] = 'cXhuHq0npa0mJFcZiVPia8:APA91bEyDv5erZvrSvLYK8NtMcPbOicSYSvdZ5gSHFwME-gKvwUabUava736QKzHDc8zxm8dmykEb5E0Bw4RVN2eRbT0Tk9kzXrrZuUqJwR7C0v1q1Wp1ZNYBGDfqvS2Df8_bZrsZDHN';
		
		if(isset($_COOKIE['device_id']) ){
		 $device_id = 	$_COOKIE['device_id'];
		 DB::table('users')->where('id', $user_id)->update(['device_id' => $device_id]);
		 
		}
		$verifyUser = ForgotOtp::where('user_id', $user_id)->first();
        if(isset($verifyUser) ){
            return View('auth.loginotp', compact(['verifyUser','user_id'])); 
            
        }else{
            return redirect('/login')->with('warning', "Sorry your email cannot be identified.");
        }		
	}
    
    /*** function to match login otp and login user **/	
    public function matchLoginOTP(Request $request)
    {
		$user_id      = $request->input('user_id');
		$type     	  = $request->input('type');
        $verifyUser	  = forgotOtp::where('user_id', $user_id)->where('type', $type)->first();
        if(isset($verifyUser) ) {
			$user   = $verifyUser->user;
		
			$d1 = new DateTime(date('Y-m-d H:i:s'));
			$d2 = new DateTime($verifyUser->expired_at);
			
			if($verifyUser->otp == $request->input('otp') && $d1 <= $d2) {					
				Auth::loginUsingId($user->id);	
				return redirect()->intended('/');									
			}else if($verifyUser->otp == $request->input('otp') && $d1 > $d2) {
				return redirect('/login')->with('error','Sorry! This OTP is expired. Please try again.');		
			} else {
				return back()->with('error','Sorry! OTP Not Match, Please Try Again');
			}
                
        }else{
            return redirect('/login')->with('warning', "Sorry your email cannot be identified.");
        }

        return redirect('/login')->with('success', "Your E-mail is already verified. You can now login.");
    }
    
    /*
     * Function to Login with password for admin 
     * @return View
    */     
     public function adminLogin(Request $request) {
		 
		 $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required'
            ]);
        if (Auth::attempt(['email' => $request['email'], 'password' => $request['password'], 'role' => '1'])) {
            
            return redirect()->route('dashboard');
        }
        return redirect()->back()->with(['fail' => 'Could not Login']);
		 
	 }
    
}
