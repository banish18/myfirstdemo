<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\SmsApi;
use App\UserDetail;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use Illuminate\Auth\Events\Registered;
use App\VerifyUser;
use App\Role;
use App\ReferralPoint;
use App\ReferralPointsData;
use Illuminate\Support\Str;
use DateTime;
use DateInterval;
use Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\VerifyMail;
use App\Mail\SendOtpMail;
use App\ReferralData;
use DB;


class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
    */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name'  => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'phone' => ['required', 'min:10', 'max:10', 'unique:users'],
           //'password' => ['required', 'string', 'min:6', 'confirmed'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {  
		//echo "sxdzvds";die;
	  // echo "<pre>"; print_r($_COOKIE['device_id']); die;
	  
	  $_COOKIE['device_id'] = 'cXhuHq0npa0mJFcZiVPia8:APA91bEyDv5erZvrSvLYK8NtMcPbOicSYSvdZ5gSHFwME-gKvwUabUava736QKzHDc8zxm8dmykEb5E0Bw4RVN2eRbT0Tk9kzXrrZuUqJwR7C0v1q1Wp1ZNYBGDfqvS2Df8_bZrsZDHN';
	  
	  
	  if(isset($_COOKIE['device_id']) ){
	   $device_id = $_COOKIE['device_id'];
   }
	   //echo "<pre>"; print_r($data);die;
       $user =  User::create([
            'name'       => $data['name'],
            'customer_number'   => mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999),
            'email'      => $data['email'],
            'phone'      => $data['phone'],
            'api_token'  => Str::random(60),
          
            'isVerified' => 1,
            'email_verified_at' => date("Y-m-d h:i:s"),
            
            //'password' => Hash::make($data['password']),
        ]);
        
       // echo "<pre>"; print_r($user);die;
        
        $user
       ->roles()
       ->attach(Role::where('name', 'user')->first());
       
       
    //    echo "<pre>"; print_r($user); die;
        // Create user detail when user is created
		$UserDetail = new UserDetail;
		$UserDetail->user_id  =  $user->id;
		$UserDetail->save();
		
		if(isset($_COOKIE['device_id']) ){		
			DB::table('users')->where('id', $user->id)->update(['device_id' => $device_id]);
		}
        $time 	 = new DateTime(date('Y-m-d H:i:s'));
		$time->add(new DateInterval('PT5M'));
		$expTime = $time->format('Y-m-d H:i:s');
        $OTP     =  mt_rand(100000, 999999);
        $verifyUser   = VerifyUser::create([
            'user_id' => $user->id,
            'token'   => Str::random(40),
            'otp'     => $OTP,
            'expired_at' => $expTime
        ]);
        
        Mail::to($user->email)->send(new VerifyMail($user)); 

        $message	 = "Dear ".$data['name'].", Welcome to Kabera Global. Your registered email-id is ".$user->email.". Please use this otp to login with us (".$OTP .")";
        $SmsApi 	 = new SmsApi();
		$SmsApi->sendSMS($data['phone'], $message);
		
        return $user;
    }
    
    public function register(Request $request)
    {
        /*$this->validator($request->all())->validate();

        event(new Registered($user = $this->create($request->all())));

        return redirect()->route('login')
            ->with(['success' => 'Congratulations! your account is registered, you will shortly receive an email to activate your account.']);*/
            
             
        $this->validator($request->all())->validate();
        
        /* referral code */
        
        $refrrel_linkcode = $request->input('refrrel_linkcode');
        $ref_code = $request->input('refferal_code');
        $register_email   = $request->input('email');
        $register_phone   = $request->input('phone');
        
        $direct_points = ReferralPointsData::all();
       
        $referra_bypoint = $direct_points[0]->ref_by_points;
	    $referra_topoint = $direct_points[0]->ref_to_points;
        $status = 0;
        $referra_by_status = "reffered by someone";
        $referra_to_status = "reffered to someone";
        
        /* points base on refferal link */
        
        if(!empty($refrrel_linkcode))
        {
			$decrypt_ref = decrypt($refrrel_linkcode);
			$status = 0;
			
			/* check user is register to referal email id or not */
			
			$check_refcodelink = ReferralData::where("ref_code", $decrypt_ref)->where('status', $status)->where('ref_to_email',$register_email)->first();

			if($check_refcodelink !== null)
			{

				$referral_from = $check_refcodelink->user_id;
				$referto_email   = $check_refcodelink->ref_to_email;
				$referral_type   = $check_refcodelink->ref_type;
				
				/* register user */
				$user = $this->create($request->all());
				
				/* check user is registered or not */
				$check_user_registered = User::where("email", $register_email)->first();
				
				
				if($check_user_registered != null)
				{
					$register_user_id = $check_user_registered->id;
					
					/* update referred by user points */
					
					ReferralData::where("user_id",$referral_from)->where("ref_to_email",$referto_email)->update(['points' => $referra_bypoint,'point_des' => $referra_to_status,'status' => 1]);
					
					/* insert referred to user points */
					
					$new_registered_points = new ReferralData;
					$new_registered_points->user_id = $register_user_id;
					$new_registered_points->ref_from = $referral_from;
					$new_registered_points->ref_code = "";
					$new_registered_points->ref_to_email = $referto_email;
					$new_registered_points->ref_to_phone = $register_phone;
					$new_registered_points->status = 1;
					$new_registered_points->ref_type = $referral_type;
					$new_registered_points->points = $referra_topoint;
					$new_registered_points->point_des = $referra_by_status;
					$new_registered_points->save();
					
					/* insert total points of referred to user */
					$check_user_point_exist = 	ReferralPoint::where("user_id",$register_user_id)->first();
					
					if(empty($check_user_point_exist))
					{
						$total_user_points = ReferralData::where("user_id", $register_user_id)->sum('points');
						$used_points = 0;
						$points_data = new ReferralPoint;
						$points_data->user_id = $register_user_id;
						$points_data->total_points = $total_user_points;
						$points_data->used_points = $used_points;
						$points_data->save();
					}
					else
					{
						$total_user_points = ReferralData::where("user_id", $register_user_id)->sum('points');
						$used_points = $check_user_point_exist->used_points;
						$pending_points = $total_user_points - $used_points;
						ReferralPoint::where("user_id",$register_user_id)->update(['total_points' => $pending_points]);
						
					}
					
					/* insert total points of referred by user */
					
					$check_point_data = ReferralPoint::where("user_id",$referral_from)->first();
					
					if(empty($check_point_data))
					{
						$reffrom_user_points = ReferralData::where("user_id", $referral_from)->sum('points');
						$reffrom_used_points = 0;
						$points_data = new ReferralPoint;
						$points_data->user_id = $referral_from;
						$points_data->total_points = $reffrom_user_points;
						$points_data->used_points = $reffrom_used_points;
						$points_data->save();
					}
					else
					{
						$reffrom_user_points = ReferralData::where("user_id", $referral_from)->sum('points');
						$reffrom_used_points = $check_point_data->used_points;
						$reffrom_pending_points = $reffrom_user_points - $reffrom_used_points;
						ReferralPoint::where("user_id",$referral_from)->update(['total_points' => $reffrom_pending_points]);
						
					}
					
					return redirect('/user/match-otp/'.$user->id)
				->with(['success' => 'Congratulations! your account is registered, you will receive OTP on email or phone to activate your account']);
					
				}
				
			} else{				
				return redirect()->back()->with('error_code', 'error');
			}
			
		}
		/* points base on refferal code */
		else if($ref_code != null)
		{
			$check_refcode 		 =  ReferralData::where("ref_code", $ref_code)->first();
			$check_refcodestatus =  ReferralData::where("ref_code", $ref_code)->where('status', $status)->first();
			$check_refemail		 =  ReferralData::where("ref_code", $ref_code)->where('ref_to_email',$register_email)->first();
			if($check_refcode  != null)
			{
				if($check_refcodestatus == null)
				{
					return redirect()->back()->with(['error' => 'Referral code already used !!']);
				}
				else if($check_refemail == null)
				{
					return redirect()->back()->with(['error' => 'Referral email address belong to referral code is different from the registered email address ']);
				}
				else
				{
				    $get_record = ReferralData::where("ref_code", $ref_code)->where('status', $status)->first();
					$referral_from = $get_record->ref_from;
					$referto_email = $get_record->ref_to_email;
					$referral_type   = $get_record->ref_type;
					
				/* register user */
				$user = $this->create($request->all());
				
				/* check user is registered or not */
				$check_user_registered = User::where("email", $register_email)->first();
				
				
				if($check_user_registered != null)
				{
					$register_user_id = $check_user_registered->id;
					
					/* update referred by user points */
					
					ReferralData::where("user_id",$referral_from)->where("ref_to_email",$referto_email)->update(['points' => $referra_bypoint,'point_des' => $referra_to_status,'status' => 1]);
					
					/* insert referred to user points */
					
					$new_registered_points = new ReferralData;
					$new_registered_points->user_id = $register_user_id;
					$new_registered_points->ref_from = $referral_from;
					$new_registered_points->ref_code = "";
					$new_registered_points->ref_to_email = $referto_email;
					$new_registered_points->ref_to_phone = $register_phone;
					$new_registered_points->status = 1;
					$new_registered_points->ref_type = $referral_type;
					$new_registered_points->points = $referra_topoint;
					$new_registered_points->point_des = $referra_by_status;
					$new_registered_points->save();
					
					/* insert total points of referred to user */
					$check_user_point_exist = 	ReferralPoint::where("user_id",$register_user_id)->first();
					
					if(empty($check_user_point_exist))
					{
						$total_user_points = ReferralData::where("user_id", $register_user_id)->sum('points');
						$used_points = 0;
						$points_data = new ReferralPoint;
						$points_data->user_id = $register_user_id;
						$points_data->total_points = $total_user_points;
						$points_data->used_points = $used_points;
						$points_data->save();
					}
					else
					{
						$total_user_points = ReferralData::where("user_id", $register_user_id)->sum('points');
						$used_points = $check_user_point_exist->used_points;
						$pending_points = $total_user_points - $used_points;
						ReferralPoint::where("user_id",$register_user_id)->update(['total_points' => $pending_points]);
						
					}
					
					/* insert total points of referred by user */
					
					$check_point_data = ReferralPoint::where("user_id",$referral_from)->first();
					
					if(empty($check_point_data))
					{
						$reffrom_user_points = ReferralData::where("user_id", $referral_from)->sum('points');
						$reffrom_used_points = 0;
						$points_data = new ReferralPoint;
						$points_data->user_id = $referral_from;
						$points_data->total_points = $reffrom_user_points;
						$points_data->used_points = $reffrom_used_points;
						$points_data->save();
					}
					else
					{
						$reffrom_user_points = ReferralData::where("user_id", $referral_from)->sum('points');
						$reffrom_used_points = $check_point_data->used_points;
						$reffrom_pending_points = $reffrom_user_points - $reffrom_used_points;
						ReferralPoint::where("user_id",$referral_from)->update(['total_points' => $reffrom_pending_points]);
						
					}
					
						return redirect('/user/match-otp/'.$user->id)
					->with(['success' => 'Congratulations! your account is registered, you will receive OTP on email or phone to activate your account']);
					
					}
				
				}
			}
			else
			{
				return redirect()->back()->with(['error' => 'Referral code is wrong !!']);
			}
		} else { // Register user 
			
			$user = $this->create($request->all());
			
			/* check user is registered or not */
				$check_user_registered = User::where("email", $register_email)->first();
				
				
				if($check_user_registered != null)
				{
					$register_user_id = $check_user_registered->id;
					
					/* insert referred to user points */
					
					$new_registered_points = new ReferralData;
					$new_registered_points->user_id = $register_user_id;
					$new_registered_points->ref_from = "";
					$new_registered_points->ref_code = "";
					$new_registered_points->ref_to_email = "";
					$new_registered_points->ref_to_phone = $register_phone;
					$new_registered_points->status = 1;
					$new_registered_points->ref_type = "new user";
					$new_registered_points->points = $referra_topoint;
					$new_registered_points->point_des = "First Signup";
					$new_registered_points->save();
					
					/* insert total points of referred to user */
					
					$total_user_points = ReferralData::where("user_id", $register_user_id)->sum('points');
					$used_points = 0;
					$points_data = new ReferralPoint;
					$points_data->user_id = $register_user_id;
					$points_data->total_points = $total_user_points;
					$points_data->used_points = $used_points;
					$points_data->save();
					return redirect('/user/match-otp/'.$user->id)
					->with(['success' => 'Congratulations! your account is registered, you will receive OTP on email or phone to activate your account']);
				}
		}
	}
    
    public function matchOTP($user_id) {
		
		$verifyUser = VerifyUser::where('user_id', $user_id)->first();
        if(isset($verifyUser) ){
            $user = $verifyUser->user;
            return View('auth.matchotp', compact(['verifyUser','user_id'])); 
            
        }else{
            return redirect('/login')->with('warning', "Sorry your email cannot be identified.");
        }		
	}
    
    public function verifyUser(Request $request)
    {
		$token      = $request->input('token');
        $verifyUser = VerifyUser::where('token', $token)->first();
        if(isset($verifyUser) ) {
			$user   = $verifyUser->user;
		
			$d1 = new DateTime(date('Y-m-d H:i:s'));
			$d2 = new DateTime($verifyUser->expired_at);
			
			if($verifyUser->otp == $request->input('otp') && $d1 <= $d2) {					
				Auth::loginUsingId($user->id);	
				return redirect('/');									
			}else if($verifyUser->otp == $request->input('otp') && $d1 > $d2) {
				return redirect('/login')->with('error','Sorry! This OTP is expired. Please try again.');		
			} else {
				return back()->with('error','Sorry! OTP Not Match, Please Try Again');
			}
                
        }else{
            return redirect('/login')->with('warning', "Sorry your email cannot be identified.");
        }

        return redirect('/login')->with('success', "Your E-mail is already verified. You can now login.");
    }
    
     /** resend signup OTP **/    
    public function resendOTP($id) {
		
		$user = User::find($id);
		if($user == null) {
			return redirect()->back()->with(['error' => 'Sorry! this user is not exist on our system.']);
		} else {
			  
				$time 	 = new DateTime(date('Y-m-d H:i:s'));
				$time->add(new DateInterval('PT5M'));
				$expTime = $time->format('Y-m-d H:i:s');
				$OTP     =  mt_rand(100000, 999999);
				
				$verifyUser             =  VerifyUser::where('user_id',$id)->first();
				$verifyUser->otp 	    =  $OTP;
				$verifyUser->expired_at =  $expTime;							
				$verifyUser->save();
				
				//Mail::to($user->email)->send(new VerifyMail($user)); 

				$message	 = "Dear ".$user->name.", Welcome to Kabera Global. Your registered email-id is ".$user->email.". Please use this otp to login with us (".$OTP .")";
				$SmsApi 	 = new SmsApi();
				$SmsApi->sendSMS($user->phone, $message);
		
				
				$mdata['email']     = $user->email;
				$mdata['name']      = $user->name;
				$mdata['otp']  		= $OTP;	
				Mail::to($user->email)->send(new SendOtpMail($mdata));
				
				return redirect('/user/match-otp/'.$user->id)
					  ->with(['success' => 'OTP resend on your email/phone']);
		}
		
	}
}
