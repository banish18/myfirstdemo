<?php
namespace App\Http\Controllers;
use Auth;
use DB;
use Session;
use App\SmsApi;
use App\ProcedureOtp;
use DateTime;
use DateInterval;
use App\Countries;
use App\States;
use App\User;
use App\UserDetail;
use App\Role;
use App\Banner;
use App\Page;
use App\Offer;
use App\TempOrder;
use App\Order;
use App\OrderDetail;
use App\SubService;
use App\BeforeAfterImage;
use App\BeforeAfterReview;
use App\ProcedureReview;
use App\GraftOption;
use App\HairTransplantReport;
use App\Procedure;
use App\ProcedureOption;
use App\Mail\WelcomeMail;
use App\Mail\ExpertTalkEmail;
use App\GraftRate;
use App\TalkToExpert;
use App\OptionProbability;
use Illuminate\Http\Request;
use Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str; 
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Response;

class HairprocedureController extends Controller
{
	
	/**
     * Function to redirect page beardtransplant.
     * @return view
    */
	public function beardTransplant()
	{
		 $service_id    = '7';
		 $services	    =  SubService::where('service_id', $service_id)->get();	
		 $procedure     =  Page::where('template','Hair Procedure')->where('data_type','hair-procdeure-data')->first();
		 $data 		    =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		 if($procedure !== null) {
			$procedureData         = json_decode($procedure->content_en);
			$procedureDatafr       = json_decode($procedure->content_fr);
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
			$data['first_offer']   = Banner::find($procedureData->first_banner);	
			$data['second_offer']  = Banner::find($procedureData->second_banner);		
		 }
		 
		$images    = BeforeAfterImage::where('service_id',$service_id)->get();
		$bareviews = BeforeAfterReview::where('service_id',$service_id)->where('review_status','1')->get();
		
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		$percentage = 0;
		if($count){
			$percentage 	   =  array();
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}
		$countries = Countries::all();	
		
		$offers     = Offer::where('services',$service_id)->paginate(4);
		$countoffers     = Offer::where('services',$service_id)->count();
		$cityOffers = [];
		foreach($offers as $key=>$offer) {
		  if($offer->city) {
		
				if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
					$cityOffers[] = $offer;
				}
			} else {
				$cityOffers[] = $offer;
				
			}
		}	
		$offers	   = $cityOffers;
		$skip      = 4;
		return view('procedure.hair.beardtransplant',compact(['services','images', 'bareviews', 'reviews', 'count', 'avrage', 'percentage','countries','offers','skip','service_id','countoffers']));
	}
	
	/**
     * Function to redirect page eyebrowstransplant.
     * @return view
    */
	public function cosmeticTransplant()
	{
		$countries 		= Countries::all();
		$service_id     = '9';
		$services	    =  SubService::where('service_id', $service_id)->get();	
		 $procedure     =  Page::where('template','Hair Procedure')->where('data_type','hair-procdeure-data')->first();
		 $data 		    =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		 if($procedure !== null) {
			$procedureData         = json_decode($procedure->content_en);
			$procedureDatafr       = json_decode($procedure->content_fr);
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
			$data['first_offer']   = Banner::find($procedureData->first_banner);	
			$data['second_offer']  = Banner::find($procedureData->second_banner);		
		 }
		 
		$images    = BeforeAfterImage::where('service_id',9)->get();
		$bareviews = BeforeAfterReview::where('service_id',9)->where('review_status','1')->get();
		
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		$percentage = 0;
		if($count){
			$percentage 	   =  array();
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}	
		$offers     = Offer::where('services',$service_id)->paginate(4);
		$countoffers     = Offer::where('services',$service_id)->count();
		$cityOffers = [];
		foreach($offers as $key=>$offer) {
		  if($offer->city) {
		
				if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
					$cityOffers[] = $offer;
				}
			} else {
				$cityOffers[] = $offer;
				
			}
		}	
		$offers	   = $cityOffers;
		$skip      = 4;
		return view('procedure.skin.cosmetictransplant',compact(['services','images', 'bareviews', 'reviews', 'count', 'avrage', 'percentage','countries','offers','skip','service_id','countoffers']));
	}
	
	/**
     * Function to redirect page cosmatictransplant.
     * @return view
    */
	public function eyebrowTransplant()
	{
		 $service_id    = '3';
		 $services	    =  SubService::where('service_id', $service_id )->get();	
		 $procedure     =  Page::where('template','Hair Procedure')->where('data_type','hair-procdeure-data')->first();
		 $data 		    =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		 if($procedure !== null) {
			$procedureData         = json_decode($procedure->content_en);
			$procedureDatafr       = json_decode($procedure->content_fr);
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
			$data['first_offer']   = Banner::find($procedureData->first_banner);	
			$data['second_offer']  = Banner::find($procedureData->second_banner);		
		 }
		 
		$images    = BeforeAfterImage::where('service_id',3)->get();
		$bareviews = BeforeAfterReview::where('service_id',3)->where('review_status','1')->get();
		
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		$percentage = 0;
		if($count){
			$percentage 	   =  array();
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}	
		$countries   = Countries::all();	
		$offers      = Offer::where('services',$service_id)->paginate(4);
		$countoffers = Offer::where('services',$service_id)->count();
		$cityOffers = [];
		foreach($offers as $key=>$offer) {
		  if($offer->city) {
		
				if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
					$cityOffers[] = $offer;
				}
			} else {
				$cityOffers[] = $offer;
				
			}
		}	
		$offers	   = $cityOffers;
		$skip      = 4;
		return view('procedure.hair.eyebrowtransplant',compact(['services','images', 'bareviews', 'reviews', 'count', 'avrage', 'percentage','countries','offers','skip','service_id','countoffers']));
	}
	
	/*
	 * Function to add appointment
	 * @return redirect to url
	*/		
	public function addOtherAppointment(Request $request) {
		$offer 	       = $request->input('offer_apply');
	    $OfferDetail   = Offer::find($offer);   
	    $sid 		   = $request->input('service_id');
	    return redirect('/package-detail/'.$OfferDetail->id.'/'.str_slug($OfferDetail->offer_name_en, '-').'/'.$sid);
	}
	
	
	
	/** 
	 *Function to get package detail
	*/
	public function getPackageDetail($id, $slug,$sid) {
		$Offer 		    = Offer::with('subService')->find($id);
		if($Offer == null) {
			return abort(404);
		}
		$options 		= ProcedureOption::all();
		$gst_rate		=  env('GST_RATE');
		$packagePrice 						 = $Offer->package_price - $Offer->discount;
		$finalPayment['packagecost']         = $Offer->package_price;
		$finalPayment['totalcost']			 = floor($packagePrice + ($packagePrice * $gst_rate)/100) ;
		$finalPayment['totaldiscount']		 = $Offer->discount;	                                
		$finalPayment['balance']		   	 = $finalPayment['totalcost'];	
		$finalPayment['gst_rate']		   	 = $gst_rate;	
		$finalPayment['gst']		   	 	 = floor(($packagePrice * $gst_rate)/100);	
		$countries 	   = Countries::all(); 
		$states   	   = States::where('country_id',1)->get();
		if(Auth::User()){
			$isLoggedIn = 1;
			$User  = UserDetail::where('user_id',  Auth::user()->id)->first();
		}else{
			$isLoggedIn = 0;
			$User  = [];
		}
		
		return view('procedure.other-package',compact(['Offer', 'finalPayment', 'options','countries','isLoggedIn','sid','User','states']));		
	}
	
	
	/* 
	 * Function to Save beard Procedire Data and Register User 
	*/
	
	public function saveBeardReport(Request $request) {
		$data  = $request->all();
		if (Auth::check()) {
			$user   = Auth::user();			
		} else {
			$validator = Validator::make($request->all(), [ 
				'email' => 'required|email|unique:users',
				'phone'	=> 'required|min:9|unique:users', 
			]);
			$err = '';
			if ($validator->fails()) { 
				$err = '<ul>';						
				foreach($validator->errors()->toArray() as $key=>$er) {
					$err .= '<li>'.$er[0].'</li>';
				}
				$err .= '</li>';
				return Response::json(array('status'=>'0','message'=>$err));
			}
			$password = Str::random(8);
			$user 	  = User::create([
				'customer_number'   => mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999),
				'name'        		=> $data['name'],
				'email'       		=> $data['email'],
				'phone'       		=> $data['phone'],
				//'password'    		=> Hash::make($password),
				'api_token'   		=> Str::random(60),
				'role'	      		=> '3',
				'isVerified'  		=>  1,
				'email_verified_at' => date("Y-m-d h:i:s")
			]);
			$user
		   ->roles()
		   ->attach(Role::where('name', 'user')->first());
		   
		    // Create user detail when user is created
			$UserDetail = new UserDetail;
			$UserDetail->user_id =  $user->id;
			$UserDetail->save();
           
		   $mdata['email']     = $data['email'];
		   $mdata['name']      = $data['name'];
		   Mail::to($data['email'])->send(new WelcomeMail($mdata));
		  
		   Auth::loginUsingId($user->id);
		}	
		
		//print_r($data);die;
		
		$successStatus = 200;
        if($user){
			$procedure_stat = 'consult';   
			$HairReport = new HairTransplantReport;
			$HairReport->user_id		  = $user->id;
			$HairReport->affected_ids	  = "";
			$HairReport->service_id	      = $data['service_id'];
			$HairReport->total_graft	      = "";
			$HairReport->total_hair	      = "";
			$HairReport->medical_condition = "";
			$HairReport->age 			  = $data['age'];
			$HairReport->country 		  = $data['country'];
			$HairReport->state	 		  = $data['state'];
			$HairReport->city	 		  = $data['city'];
			$HairReport->cost_per_graft	  = 0;
			$HairReport->total_cost		  = 0;
			$HairReport->is_stat		  = "new";
			$HairReport->sitting		  = "";
			$HairReport->transplant_type  = $data['set_service_type'];
			$HairReport->procedure_stat	  = $procedure_stat;
			$HairReport->save();
			
			if( $data['update_on_profile'] == '1') {			   
			   $userProfile = UserDetail::where('user_id', $user->id)->first(); 
			   $userProfile->country =  $data['country'];
			   $userProfile->state   =  $data['state'];
			   $userProfile->city	 =  $data['city'];
			   $userProfile->age 	 =  $data['age'];
			   $userProfile->save();
		   }
		   
			$appointment_id = $HairReport->id;
			$OfferDetail = Offer::find($data['offer_id']);
			 Session::put('region', $data['city']);
			return Response::json(array('status'=>'1','message'=>'Success','offer_id' => $OfferDetail->id,'offer_name' => str_slug($OfferDetail->offer_name_en, '-'),'report_id' => $HairReport->id));
		} else {
			return Response::json(array('status'=>'2','message'=>'Appointment Scheduled Error'));
		}
	  }	
	  
	/* 
	 * Function to Save eyebrow Procedire Data and Register User 
	*/
	
	public function saveEyebrowReport(Request $request) {
		$data  = $request->all();
		
		
		if (Auth::check()) {
			// The user is logged in...
			$user   = Auth::user();			
			
		} else {
			$validatedData = $request->validate([
				'email' => 'required|email|unique:users',
				'phone'	=> 'required|min:9|unique:users', 
			]);
			
			$password = Str::random(8);
			$user 	  = User::create([
				'customer_number'   => mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999),
				'name'        		=> $data['name'],
				'email'       		=> $data['email'],
				'phone'       		=> $data['phone'],
				//'password'    		=> Hash::make($password),
				'api_token'   		=> Str::random(60),
				'role'	      		=> '3',
				'isVerified'  		=>  1,
				'email_verified_at' => date("Y-m-d h:i:s")
			]);
			$user
		   ->roles()
		   ->attach(Role::where('name', 'user')->first());
		   
		    // Create user detail when user is created
			$UserDetail = new UserDetail;
			$UserDetail->user_id =  $user->id;
			$UserDetail->save();
        
		   $mdata['email']     = $data['email'];
		   $mdata['name']      = $data['name'];
		   Mail::to($data['email'])->send(new WelcomeMail($mdata));
		   
		   Auth::loginUsingId($user->id);
		}
		
        if($user) {	
		   $procedure_stat = 'fix';
		   		   
		   $HairReport = new HairTransplantReport;
		   $HairReport->user_id		      = $user->id;
		   $HairReport->affected_ids	  = "";
		   $HairReport->total_graft	      = "";
		   $HairReport->total_hair	      = "";
		   $HairReport->medical_condition = "";
		   $HairReport->age 			  = $data['age'];
		   $HairReport->country 		  = $data['country'];
		   $HairReport->state	 		  = $data['state'];
		   $HairReport->city	 		  = $data['city'];
		   $HairReport->cost_per_graft	  = 0;
		   $HairReport->total_cost		  = 0;
		   $HairReport->sitting		  	  = "";
		   $HairReport->transplant_type	  = 'Beard';
		   $HairReport->procedure_stat	  = $procedure_stat;
		   $HairReport->save();	
		  
		   
		 $appointment_id = $HairReport->id;
		 $HairReport     = HairTransplantReport::with(['user','applied_offer'])->find($appointment_id);	 		
		 if($HairReport !== null) {
			 $HairReport->appointment_status = 1;
			 $HairReport->save();	
			
			$User  = UserDetail::where('user_id',  Auth::user()->id)->first();
			
			$Procedure 				  	   = new Procedure;
			$Procedure->user_id 		   = Auth::user()->id;
			$Procedure->report_id 	  	   = $HairReport->id;
			$Procedure->service     	   = 3; //fixed for hair transplant custom
			$Procedure->type     	  	   = 'offer';
			//$Procedure->offer_apply      = '';
			//$Procedure->offer_name       = '';
			$Procedure->procedure_stat      = 'consult';
			$Procedure->total_payment      = 0;
			$Procedure->advanced_payment   = 0;
			$Procedure->pending_payment    = 0;
			//$Procedure->payment_type     = '';
			//$Procedure->note         	   = '';
			$Procedure->save();
			$procedure_id = $Procedure->id;
			
			
			$TempOrder  = new TempOrder;
		   	$TempOrder->status 		= 0;
			$TempOrder->save();
			        
			$Order 	   				= new Order;		
			$Order->id 				= $TempOrder->id;
			$Order->user_id 		= Auth::user()->id;
			$Order->address 		= ($User->address) ? $User->address : '';
			$Order->country 		= ($User->country) ? $User->country : '';
			$Order->state 			= ($User->state) ? $User->state : '';
			$Order->zip 			= ($User->post_code) ? $User->post_code : '';
			$Order->city 			= ($User->city) ? $User->city : '';
			$Order->billing_address = ($User->address) ? $User->address : '';
			$Order->billing_city 	= ($User->city) ? $User->city : '';
			$Order->billing_state 	= ($User->state) ? $User->state : '';
			$Order->billing_country = ($User->country) ? $User->country : '';
			$Order->billing_zip 	= ($User->post_code) ? $User->post_code : '';
			$Order->total 			= $HairReport->total_cost;
			$Order->grand_total 	= $HairReport->total_cost;
			$Order->status 			= 0;
			$Order->payment_status 	= 'Pending';
			$Order->save();
						
			$OrderDetail 				   = new OrderDetail;
			$OrderDetail->order_id 		   = $Order->id;
			$OrderDetail->user_id 		   = $Order->user_id;
			$OrderDetail->product_id 	   = $Procedure->id;
			$OrderDetail->product_price    = $HairReport->total_cost;
			$OrderDetail->product_type     = 'procedure';
			$OrderDetail->product_quantity = 1;
			$OrderDetail->save();
			
			TempOrder::where('id',$TempOrder->id)->delete();	
			return redirect("/user/track/procedure/".$procedure_id);	 
			
			} else {
				return redirect()->route('procedure/eyebrow-transplant')->with(['error' => 'Appointment Scheduled Error']);			
				
			} 
		   
		  
	    }	 
	  }	
	    
	    
	 /* 
	 * Function to Save cosmetic Procedire Data and Register User 
	*/
	
	public function saveCosmeticReport(Request $request) {
		$data  = $request->all();
		
		
		if (Auth::check()) {
			// The user is logged in...
			$user   = Auth::user();			
			
		} else {
			$validatedData = $request->validate([
				'email' => 'required|email|unique:users',
				'phone'	=> 'required|min:9|unique:users', 
			]);
			
			$password = Str::random(8);
			$user 	  = User::create([
				'customer_number'   => mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999),
				'name'        		=> $data['name'],
				'email'       		=> $data['email'],
				'phone'       		=> $data['phone'],
				//'password'    		=> Hash::make($password),
				'api_token'   		=> Str::random(60),
				'role'	      		=> '3',
				'isVerified'  		=>  1,
				'email_verified_at' => date("Y-m-d h:i:s")
			]);
			$user
		   ->roles()
		   ->attach(Role::where('name', 'user')->first());
		   
		    // Create user detail when user is created
			$UserDetail = new UserDetail;
			$UserDetail->user_id =  $user->id;
			$UserDetail->save();
        
		   $mdata['email']     = $data['email'];
		   $mdata['name']      = $data['name'];
		   Mail::to($data['email'])->send(new WelcomeMail($mdata));
		   
		   Auth::loginUsingId($user->id);
		}
		
        if($user) {	
		   $procedure_stat = 'fix';
		   		   
		   $HairReport = new HairTransplantReport;
		   $HairReport->user_id		      = $user->id;
		   $HairReport->affected_ids	  = "";
		   $HairReport->total_graft	      = "";
		   $HairReport->total_hair	      = "";
		   $HairReport->medical_condition = "";
		   $HairReport->age 			  = $data['age'];
		   $HairReport->country 		  = $data['country'];
		   $HairReport->state	 		  = $data['state'];
		   $HairReport->city	 		  = $data['city'];
		   $HairReport->cost_per_graft	  = 0;
		   $HairReport->total_cost		  = 0;
		   $HairReport->sitting		  	  = "";
		   $HairReport->transplant_type	  = 'Beard';
		   $HairReport->procedure_stat	  = $procedure_stat;
		   $HairReport->save();	
		  
		   
		 $appointment_id = $HairReport->id;
		 $HairReport     = HairTransplantReport::with(['user','applied_offer'])->find($appointment_id);	 		
		 if($HairReport !== null) {
			 $HairReport->appointment_status = 1;
			 $HairReport->save();
			$User  = UserDetail::where('user_id',  Auth::user()->id)->first();
			$Procedure 				  	   = new Procedure;
			$Procedure->user_id 		   = Auth::user()->id;
			$Procedure->report_id 	  	   = $HairReport->id;
			$Procedure->service     	   = 9; //fixed for hair transplant custom
			$Procedure->type     	  	   = 'offer';
			//$Procedure->offer_apply      = '';
			//$Procedure->offer_name       = '';
			$Procedure->total_payment      = 0;
			$Procedure->advanced_payment   = 0;
			$Procedure->pending_payment    = 0;
			$Procedure->procedure_stat      = 'consult';
			//$Procedure->payment_type     = '';
			//$Procedure->note         	   = '';
			$Procedure->save();
			$procedure_id = $Procedure->id;
			
			
			$TempOrder  = new TempOrder;
		   	$TempOrder->status 		= 0;
			$TempOrder->save();
			        
			$Order 	   				= new Order;		
			$Order->id 				= $TempOrder->id;
			$Order->user_id 		= Auth::user()->id;
			$Order->address 		= ($User->address) ? $User->address : '';
			$Order->country 		= ($User->country) ? $User->country : '';
			$Order->state 			= ($User->state) ? $User->state : '';
			$Order->zip 			= ($User->post_code) ? $User->post_code : '';
			$Order->city 			= ($User->city) ? $User->city : '';
			$Order->billing_address = ($User->address) ? $User->address : '';
			$Order->billing_city 	= ($User->city) ? $User->city : '';
			$Order->billing_state 	= ($User->state) ? $User->state : '';
			$Order->billing_country = ($User->country) ? $User->country : '';
			$Order->billing_zip 	= ($User->post_code) ? $User->post_code : '';
			$Order->total 			= $HairReport->total_cost;
			$Order->grand_total 	= $HairReport->total_cost;
			$Order->status 			= 0;
			$Order->payment_status 	= 'Pending';
			$Order->save();
						
			$OrderDetail 				   = new OrderDetail;
			$OrderDetail->order_id 		   = $Order->id;
			$OrderDetail->user_id 		   = $Order->user_id;
			$OrderDetail->product_id 	   = $Procedure->id;
			$OrderDetail->product_price    = $HairReport->total_cost;
			$OrderDetail->product_type     = 'procedure';
			$OrderDetail->product_quantity = 1;
			$OrderDetail->save();
			
			TempOrder::where('id',$TempOrder->id)->delete();	
			return redirect("/user/track/procedure/".$procedure_id);	 
			
			} else {
				return redirect()->route('procedure/cosmetic-transplant')->with(['error' => 'Appointment Scheduled Error']);			
				
			} 
		   
		  
	    } 
	  }	
	    
	/**
     * Function to view final beard transplant report by id.
     * @return view
    */
	public function beardReport()
	{
		return view('procedure.hair.beardreport');
	}
	
	/**
     * Function to view final eyebrow transplant report by id.
     * @return view
    */
	public function eyebrowReport()
	{
		return view('procedure.hair.eyebrowreport');
	}
		
	/**
     * Function to view final cosmetic transplant report by id.
     * @return view
    */
	public function cosmeticReport()
	{
		return view('procedure.skin.cosmeticreport');
	}	
	
	/**
     * Function to view final cosmetic transplant report by id.
     * @return view
    */
	public function getOffer(Request $request)
	{
		
		$start = $request->input('start_val');
		$limit = $request->input('limit');
		$min_graft = $request->input('mingraft');
		$max_graft = $request->input('maxgraft');
		$total_offer = $request->input('totaloffer');
		$used_rel = $request->input('used_rel');
		$used_inrel = $request->input('used_inrel');
		$services  = 2;
		$offers   = Offer::where('services',$services)->get();
		
		
	    $relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->get();
		$count_relevent_offer = count($relevent_offer);
		//$count_relevent_offer = 13;
		
		
		$data = [];
		
		if($count_relevent_offer > $used_rel)
		{
			$pending_rel = $count_relevent_offer - $used_rel;
			if($pending_rel >= $limit)
			{
				$data = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip($start)->take($limit)->get();
				
				$used_relevent = $used_rel + count($data);
				$used_inrelevent = $used_inrel;
				
			}
			else
			{
				
				$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip($start)->take($limit)->get();
				$inrelevent_offer = Offer::where('services',$services)->whereNotBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip($used_rel)->take($pending_rel)->get();
				
				$used_relevent = $used_rel + count($relevent_offer);
				$used_inrelevent = $used_inrel + count($inrelevent_offer);
				
				$data = $relevent_offer->merge($inrelevent_offer);
				
			}
		} else {	
			
			if($count_relevent_offer == $used_rel)
			{
				$data = Offer::where('services',$services)->whereNotBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip($used_inrel)->take($limit)->get();
				$used_relevent = $used_rel;
				$used_inrelevent = $used_inrel + count($data);
			}
			else
			{
				$pending_rel = $limit - $used_rel;
				$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip($start)->take($limit)->get();
			
				$inrelevent_offer = Offer::where('services',$services)->whereNotBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip($used_inrel)->take($pending_rel)->get();
				
				$used_relevent = $used_rel + count($relevent_offer);
				$used_inrelevent = $used_inrel + count($inrelevent_offer);
				
				$data = $relevent_offer->merge($inrelevent_offer);
			}
	
		}	
		if($data){
			return response()->json(['data'=>$data, 'used_relevent'=>$used_relevent,'used_inrelevent'=>$used_inrelevent]);
		}
		else
		{
			return response()->json(['error'=>true, 'data'=>$data]);
		}
	}
	
	/* Function all report data */
	public function allReport($id)
	{	
		$report    = HairTransplantReport::with(['user','applied_offer'])->where('id',$id)->where('appointment_status','!=',1)->first();
		$service_id = $report->service_id;
		if($report == null) {
			return abort(403);
		}
		if(Auth::user()->id != $report->user_id) {
			return abort(401);
		}
		$breakDown = '';	
		$offers     = Offer::where('services',$service_id)->paginate(4);
		$countoffers     = Offer::where('services',$service_id)->count();
		$cityOffers = [];
		foreach($offers as $key=>$offer) {
		  if($offer->city) {
		
				if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
					$cityOffers[] = $offer;
				}
			} else {
				$cityOffers[] = $offer;
				
			}
		}	
		$offers	   = $cityOffers;
		$images    = BeforeAfterImage::where('service_id',$service_id)->get();
		$bareviews = BeforeAfterReview::where('service_id',$service_id)->where('review_status','1')->get();
		
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',$service_id)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',$service_id)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		$skip = 4;
		return view('procedure.hair.report',compact(['report', 'offers','skip','countoffers']));
	}
	
	/* Function loadmore report data */
	public function loadMoreReport(Request $request)
	{	
		$skip 		= $request->skip;
		$service_id = $request->service_id;
		$offers     = Offer::where('services',$service_id)->skip($request->skip)->take(4)->get();
		$html = '';
		$countoffers = 0;
		if(!$offers->isEmpty()){
			foreach($offers as $offer){
				$countoffers++;
				$imgae = asset("images/$offer->banner_image");
				$cont = $offer['offer_name_en'];
				$html .= '<div class="col-sm-12 col-md-3 mb-4">
					<div class="pro-content image-radio">
						<img src="'.$imgae.'" alt="pro-img" class="img-fluid">
							<input type="radio" name="offer_apply" value="'.$offer->id.'" />
						<h5 class="text-uppercase text-center"><a href="javascript:void();" class="d-block">'.$cont.'</a></h5>
					</div>
				</div>';
			}
			$message = 'success';
		}else{
			$message = 'error';
		}
		if($countoffers < $skip){
			$message = 'error';
		}
		$successStatus = 200;
		return response()->json(['status'=>$message, 'html' => $html,'skip' => $skip+4], $successStatus); 
	}
}
