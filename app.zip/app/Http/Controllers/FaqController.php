<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Page;
use Auth;
use Session;
use Validator;



class FaqController extends Controller
{
    /**
     * Create a new Function to display FAQ data.
     *
     */
	public function faqdata() {
		$get_Mfaq  =  Page::where('template', 'FAQ')->where('data_type', 'Mfaq')->get();
		$get_Cfaq  =  Page::where('template', 'FAQ')->where('data_type', 'Cfaq')->get();
		
		$MfaqData     =  array();
		$CfaqData     =  array();
		
		if($get_Mfaq !== null) {
			foreach($get_Mfaq as $Mfdata)
			{
				$MfaqDataen   = json_decode($Mfdata->content_en);
				$MfaqDatafr   = json_decode($Mfdata->content_fr);
				$Mfaqtype     = $Mfdata->data_type;
				$data['id']  = $Mfdata->id;
				$data['answer_en']  = $MfaqDataen->answer;
				$data['question_en']  = $MfaqDataen->question;
				$data['answer_fr']  = $MfaqDatafr->answer;
				$data['question_fr']  = $MfaqDatafr->question;
				$data['data_type']  = $Mfaqtype;
				$MfaqData[] = $data;
			}
		}
		
		if($get_Cfaq !== null) {
			foreach($get_Cfaq as $Cfdata)
			{
				$CfaqDataen   = json_decode($Cfdata->content_en);
				$CfaqDatafr   = json_decode($Cfdata->content_fr);
				$Cfaqtype     = $Cfdata->data_type;
				$data['id']  = $Cfdata->id;
				$data['answer_en']  = $CfaqDataen->answer;
				$data['question_en']  = $CfaqDataen->question;
				$data['answer_fr']  = $CfaqDatafr->answer;
				$data['question_fr']  = $CfaqDatafr->question;
				$data['data_type']  = $Cfaqtype;
				$CfaqData[] = $data;
			}
		}
		
		
		return View('faq',compact(['MfaqData','CfaqData']));
		  
	}
   
}
