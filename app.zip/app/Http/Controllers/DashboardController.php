<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use View;
use Config;
use Auth;
use App\Orders as Order;
use App\OrdersDetail as OrderDetail;
use App\User;
use App\UserDetail;
use App\OperationList;
use App\HairTransplantReport;
use App\AppointmentList;
use App\AppointmentRequest;
use App\Doctors;
use App\DoctorAssistant;
use App\GraftOption;
use App\CarryThing;
use App\Product;
use App\Procedure;
use App\Offer;
use App\NoteCommentData;
use App\Package;
use App\PaymentType;
use App\FollowUpReminder;
use App\ReminderList;
use App\AppoitmentTimeslot;
use App\Countries;
use App\States;

use Illuminate\Support\Facades\Response;
use DB;
use Session;
use Softon\Indipay\Facades\Indipay;
use Illuminate\Support\Facades\Mail;
use Redirect;
use LaravelFCM\Message\Topics;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;
use FCM;
use App\Providers\IcicipaymentServiceProvider;
use Google\Cloud\Firestore\FirestoreClient;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */   
    public $successStatus = 200;
    public function __construct()
    {
	   /*if(!Auth::check()){
		   die('Login');
	   }*/
       $this->middleware(['auth','verified']);
    }
    
	/**
     * Create a new Function to display data on home page.
     * @return Dashboard View
    */
	public function index() {
		return View('user.dashboard');
	}
	
	/**
     * Create a new Function to get user procedure.
     * @return Dashboard View
    */
	public function userProcedure() {
		$reports = HairTransplantReport::Where('user_id', Auth::user()->id);
		return View('user.procedure');
	}
	
	/**
     * Create a new Function to get user procedure.
     * @return Dashboard View
    */
	public function userOrders() {
		$orders = Order::where('user_id',Auth::user()->id)->with('user')->with('OrderDetails')->with('orderStatus')->orderBy('id','desc')->get();
		return View('user.order.read',compact(['orders']));
	}
	
	/**
     * Create a new Function to get user orders.
     * @return Order List View
    */
	public function viewOrder($id) {
		$order 				= Order::where('user_id',Auth::user()->id)->where('id',$id)->with('user')->with('OrderDetails')->with('orderComments')->with('orderStatus')->first();		
		$orderProducts 		= OrderDetail::where('order_id',$order->id)->where('product_type','product')->with('productDetails')->get();
		$orderProcedure 	= OrderDetail::where('order_id',$order->id)->where('product_type','procedure')->with('procedureDetails')->get();

		return View('user.order.view',compact(['order','orderProducts','orderProcedure']));
	}
	
	public function viewProfile(){
		$User = User::where('id',Auth::user()->id)->with('userDetail')->first();
		return View('user.profile',compact(['User']));
	}
	
	public function editProfile(){
		$countries  = Countries::all();
		$states   	= States::where('country_id',1)->get();
		$user = User::where('id',Auth::user()->id)->with('userDetail')->first();
		return View('user.edit-profile',compact(['user','countries','states']));
	}
	
	public function updateProfile(Request $request){
		$user = User::where('id',Auth::user()->id)->with('userDetail')->first();
        $user->name      	= $request->input('name');
        $user->email      	= $request->input('email');
        $user->phone      	= $request->input('phone');
		$user->save();
        $userDetail = UserDetail::where('user_id',$user->id)->first();
        if($userDetail){
			$userDetail->address   = $request->input('address');
			$userDetail->city      = $request->input('city');
			$userDetail->state     = $request->input('state');
			$userDetail->country   = $request->input('country');
			$userDetail->post_code = $request->input('post_code');  
			//die($request->input('age'));
			$userDetail->age = $request->input('age');
			$userDetail->gender = $request->input('gender');
			if($request->hasfile('profile_picture')) {
				$folder           = 'patient/';
				$userImage        = $request->file("profile_picture");
				$random_number 	  = mt_rand(100000, 999999);
				$userimgname      = $random_number.$userImage->getClientOriginalName();
				$userImage->move(public_path().'/images/patient/', $userimgname); 
				$userDetail->profile_picture   = $folder.$userimgname;
			}
			$userDetail->save();
		}
		return Redirect('user/profile')->with('message', 'Profile Updated successfully');
       // return back()->with('message', 'Profile Updated successfully');
	}	
	
	/* view Procedure */	
	public function viewProcedures(){
		$user 		= User::where('id',Auth::user()->id)->with('userDetail')->first();		
		$procedures = Procedure::where('user_id',$user->id)->with(['serviceDetail','Offer'])->orderby('id','desc')->get();		
		$products 	= Product::where('status','1')->get();
		return View('user.procedure/read',compact(['procedures', 'products']));
	}
	
	
	public function reportbydoctorlist(){
		//die('dfsgdf');
		$user 		= User::where('id',Auth::user()->id)->with('userDetail')->first();		
		//$procedures = Procedure::where('user_id',$user->id)->with(['serviceDetail','Offer'])->with('doctor')->orderby('id','desc')->get();		
		$AppointmentList = AppointmentList::where('user_id',$user->id)->where('report_by_doctors','!=' ,'')->get();		
		$products 	= Product::where('status','1')->get();
		return View('user.procedure/readbydoctor',compact(['AppointmentList', 'products', 'doctor_detail']));
	}
	
	public function reportData($procedureid) {
		$get_uploaded_report = Procedure::where("id",$procedureid)->first();
		$convert_report_to_arr = [];
		$date = "";
		if(!empty($get_uploaded_report))
		{
			$report = $get_uploaded_report->user_report_images;
			if(!empty($report))
			{
				$convert_report_to_arr = explode("," , $report);
			}
			$date = $get_uploaded_report->updated_at;
		}
		
		$doctor_ass_report = AppointmentList::where('procedure_id',$procedureid)->get();
		$doc_ass_report_arr = [];
		$doc_ass_report_arr1 = [];
		$arrr = array();
		if(count($doctor_ass_report) != 0)
		{
			foreach($doctor_ass_report as $doctor_report)
			{
				if(!empty($doctor_report->report_by_doctors))
				{
					$id = $doctor_report->id;
					$date = $doctor_report->updated_at;
					$doc_ass_report_arr[$id]['date'] = $date;
					$doc_ass_report_arr[$id]['images'] = array_filter(explode(",",$doctor_report->report_by_doctors));
					//$doc_ass_report_arr[] = 
					//$doc_ass_report_arr[$id]['date'] = $date;
					
				}
			}
			
			
		}
		
		return View('user.procedure/reportdetail',compact(['procedureid','convert_report_to_arr','date','doc_ass_report_arr']));
	}
	
	public function uploadrUserreport(Request $request)
	{
		$procedure_id = $request->input('procedure_id');
		$images = array();
		if($request->hasfile('uploadreport')) 
			{
				$allowedfileExtension=['jpg','png','jpeg','gif'];
				
				$size = [];
				foreach($request->file('uploadreport') as $image)
				{	
					//echo '<pre>'; print_r($image); echo '</pre>';
					$folder           = 'report/';
					$random_number 	  = mt_rand(100000, 999999);
					$img_name = str_replace(' ', '', $image->getClientOriginalName());
					
					$name = $random_number.$img_name; 
				    $extension = $image->getClientOriginalExtension();
				    $extension = strtolower($extension);
				   
					$size[] = $image->getSize();  
					
					$check = in_array($extension , $allowedfileExtension); 
					  if($check){
						$image_size = 2000000;
						$total_size = array_sum($size);
						if($total_size > $image_size){
							//echo 'no';
							return redirect('/user/report/procedure/'.$procedure_id)->with('error', 'Images size must be less than 2 mb');	
						} else {
							//echo public_path().'/images/report/', $name;
							$image->move(public_path().'/images/report/', $name);                  
							array_push($images , $folder.$name);
							
						}
						
					  } else {
						  
						return redirect('/user/report/procedure/'.$procedure_id)->with('error', 'Sorry Only Upload png , jpg , gif images');  
					  }
					}
					$check_image_exist = Procedure::where('id',$procedure_id)->first();
					if(!empty($check_image_exist))
					{
						$user_report = $check_image_exist->user_report_images;
						if(!empty($user_report))
						{
							$procedure = Procedure::find($procedure_id);
							$procedure->user_report_images = $user_report.','.implode(",",$images);
							$procedure->save();
						}
						else
						{
							$procedure = Procedure::find($procedure_id);
							$procedure->user_report_images = implode(",",$images);
							$procedure->save();
						}
						return redirect('/user/report/procedure/'.$procedure_id)->with('success', 'report uploaded successfully !!');
					}
			}
			else
			{
				return redirect('/user/report/procedure/'.$procedure_id)->with('error', 'no report uploaded !!');
			}
	}
	
	
	public function doctorlistAppointmentList(){
		//die('dfsgdf');
		$user 		= User::where('id',Auth::user()->id)->with('userDetail')->first();		
		//$procedures = Procedure::where('user_id',$user->id)->with(['serviceDetail','Offer'])->with('doctor')->orderby('id','desc')->get();		
		$AppointmentList = AppointmentList::where('user_id',$user->id)->where('report_by_doctors','!=' ,'')->get();		
		$products 	= Product::where('status','1')->get();
		return View('user.procedure/readbydoctor',compact(['AppointmentList', 'products', 'doctor_detail']));
	}
	
	public function paymentListDetail($id)
	{
		
		$reports = PaymentType::Where('procedure_id', $id)->get();
		return View('user.paymentdetail',compact(['reports']));
		
	}
	
	/* track Procedure */
	
	public function trackProcedure($id){
		
		$user = User::where('id',Auth::user()->id)->with('userDetail')->first();
		$procedure = Procedure::with(['Offer'])->where('id',$id)->where('user_id',$user->id)->first();
		
		
		if($procedure){
			$packages  = Offer::where('offer_type','package')->where('services',$procedure->service)->get();
			$procedureId   = $procedure->id;
			$track_status   = $procedure->track_status;
			$paymentTypes  = PaymentType::where('procedure_id',$procedureId)->get();
			$cash_payment   = "0";
			$online_payment = "0";
			if(!$paymentTypes->isEmpty()){
				foreach($paymentTypes as $paymentType){
					if($paymentType->payment_type == "cash"){
						$cash_payment   += $paymentType->amount;
					}else{
						$online_payment += $paymentType->amount;
					}
				}	
			}
			$status = $procedure->track_status;
			if($status == 'fix_app'){
				$OperationList = OperationList::where("user_id", $user->id)->where('procedure_id',$procedureId)->where("status","1")->with('serviceDetail')->with('doctorDetail')->first();
				$AppointmentList = AppointmentList::where('user_id',$user->id)->where('procedure_id',$id)->with('serviceDetail')->first();
				/* Pooja code start */	
				/* appoitment timeslot */
				$get_appoitment_timeslot = AppoitmentTimeslot::get();
				$current_time = date("G:i");
				 $current_time_strtime =  strtotime($current_time);
				 $time_array = [];
				 foreach($get_appoitment_timeslot as $timeslot)
					{
						$endtime = $timeslot->end_time;
						$starttime = $timeslot->start_time;
						$convertend_to_24hours = date("G:i", strtotime($endtime));
						$convertstart_to_24hours = date("G:i", strtotime($starttime));
						$endtime_strtime = strtotime($convertend_to_24hours);
						$starttime_strtime = strtotime($convertstart_to_24hours);
						if($current_time_strtime < $endtime_strtime)
						{
							$time_array[$convertstart_to_24hours.'-'.$convertend_to_24hours] = $starttime.' TO '.$endtime;
						}
					}
				/* Pooja code end */	
				/* appoitment timeslot */
					
					if(!$AppointmentList)
						$AppointmentList = [];
				return View('user.procedure/fix-appointment',compact(['AppointmentList','procedureId','packages','procedure','OperationList','time_array','track_status']));
					
			}else if($status == 'visit_doc'){
				
				$CarryThing 		= CarryThing::where('carry_type','visit_doctor')->where('sub_service_id',$procedure->service)->orWhere('service_id',$procedure->service)->first();
				
				$AppointmentLists   = AppointmentList::with('doc_detail')->where('user_id',$user->id)->where('status','1')->where('procedure_id',$procedureId)->with('serviceDetail')->with('doctorDetail')->orderBy('appointment_date', 'asc')->get();
				
				$comments_data      = NoteCommentData::with(['doc_detail','doc_image'])->with(array('doc_profile'=>function($query){$query->select('id','user_id','profile_picture');}))->where('user_id',$user->id)->where('procedure_id',$procedureId)->where('visible_to',1)->where('type','note')->orderby('id','desc')->get();
				
				$OperationList      = OperationList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$procedureId)->first();
				
				return View('user.procedure/visit-doctor',compact(['AppointmentLists','procedureId','procedure','CarryThing','comments_data','OperationList','track_status']));
				
			}else if($status == 'payment'){
				$AppointmentList 		= AppointmentList::where('user_id',$user->id)->where('status','1')->with('serviceDetail')->with('doctorDetail')->first();
				$OperationList = OperationList::where("user_id", $user->id)->where('procedure_id',$procedureId)->where("status","1")->with('serviceDetail')->with('doctorDetail')->first();
				return View('user.procedure/payment',compact(['AppointmentList','procedureId','procedure','OperationList','packages','cash_payment','online_payment','track_status']));
			
			}else if($status == 'operation'){
				$CarryThing 		= CarryThing::where('carry_type','procedure')->where('sub_service_id',$procedure->service)->first();
				$AppointmentList 	= AppointmentList::where('user_id',$user->id)->where('status','1')->with('serviceDetail')->with('doctorDetail')->first();
				$OperationList = OperationList::where("user_id", $user->id)->where('procedure_id',$procedureId)->with('serviceDetail')->with('doctorDetail')->first();
				//echo "<pre>";
				//print_r($OperationList);
				//echo "</pre>";
				//die;
				return View('user.procedure/detail',compact(['AppointmentList','procedureId','CarryThing','OperationList','track_status']));
			
			}else if($status == 'follow_up' || $status == 'completed'){
				$AppointmentList = AppointmentList::where('user_id',$user->id)->where('procedure_id',$id)->with('serviceDetail')->first();
				$OperationList   = OperationList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$id)->first();
				$current_user_id = auth()->user()->id; 
				$user_opertion_record = OperationList::where("user_id", $current_user_id)->where('procedure_id',$procedureId)->where("status","1")->first();
		
				if(count($user_opertion_record) != 0)
				{
					$opr_date = $user_opertion_record->operation_date;
					$date = date('Y-m-d', strtotime($opr_date));
					
					$service_id = $user_opertion_record->service_id;
					$reminders_data =  FollowUpReminder::where('sub_service_id',$service_id)->get();
					
					if(count($reminders_data) != 0)
					{
						$reminders =  $reminders_data;
					}else{
						$reminders = [];
					}
				} else {
					$reminders = [];
					$date = "";
				}
				return View('user.procedure/follow-up',compact(['reminders','date','user_opertion_record','AppointmentList','procedureId','OperationList','track_status']));
			
			}else if($status == 'review'){
				return View('user.procedure/review',compact(['procedures','track_status']));
			}
			
		}else{
			return Redirect()->route('userUpdateProcedures')->with('message', 'Procedure are no longer with this user.');
		}
	}
	
	public function viewProcedurePayment($id,$type){
		
//		echo $id;die;
		
		$procedure = Procedure::with(['Offer','paymentOption'])->find($id); 
		$packages  = Offer::where('offer_type','package')->where('services',$procedure->service)->get();
		
		$Offers  = Offer::where('id',$procedure->offer_apply)->get();
		
		//print_r($Offers);die;
		
		$procedureId 		= $id;
		$user               = Auth::user();
		if($procedure){
			$track_status = $procedure->track_status; 
			$paymentTypes  = PaymentType::where('procedure_id',$procedureId)->get();
			$cash_payment   = "0";
			$online_payment = "0";
			if(!$paymentTypes->isEmpty()){
				foreach($paymentTypes as $paymentType){
					if($paymentType->payment_type == "cash"){
						$cash_payment   += $paymentType->amount;
					}else{
						$online_payment += $paymentType->amount;
					}
				}	
			}
			
			if($type == "payment"){
				$AppointmentList = AppointmentList::where('user_id',$user->id)->where('status','1')->with(['serviceDetail','doctorDetail'])->first();			
				//echo "<pre>"; print_r($AppointmentList); die;		
				$OperationList   = OperationList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$id)->first();
				return View('user.procedure/payment',compact(['AppointmentList','procedureId','procedure','OperationList','packages','cash_payment','online_payment','track_status']));
				
			}else if($type == "detail"){
				$CarryThing 		= CarryThing::where('carry_type','procedure')->where('sub_service_id',$procedure->service)->first();
				/*$AppointmentList 		= AppointmentList::where('user_id',$user->id)->where('status','1')->with('serviceDetail')->with('doctorDetail')->first();*/
				
				$AppointmentList 		= AppointmentList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$procedureId)->with('serviceDetail')->with('doctorDetail')->orderBy('appointment_date', 'asc')->first();
				
				$OperationList 			= OperationList::where("user_id", $user->id)->where('procedure_id',$procedureId)->with('subserviceDetail')->with('doctorDetail')->first();	
				
				$apt_detail = AppointmentList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$procedureId)->with('serviceDetail')->with('doctorDetail')->get();
				$comments_data  = NoteCommentData::with('doc_detail','doc_image')->where('user_id',$user->id)->where('visible_to',1)->where('procedure_id',$procedureId)->where('type','note')->orderby('id','desc')->get();
				//echo "<pre>";
				//print_r($OperationList);
				//echo "</pre>";
				//die;
						
				return View('user.procedure/detail',compact(['AppointmentList','procedureId','CarryThing','OperationList','comments_data','apt_detail','procedure','track_status']));
			}else if($type == "followup"){
				$AppointmentList = AppointmentList::where('user_id',$user->id)->where('status','1')->with('serviceDetail')->with('doctorDetail')->first();
				$OperationList   = OperationList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$id)->first();
				$current_user_id = auth()->user()->id; 
			
				$user_opertion_record = OperationList::where("user_id", $current_user_id)->where('procedure_id',$procedureId)->where("status","1")->first();
		
				if(count($user_opertion_record) != 0)
				{
					$opr_date = $user_opertion_record->operation_date;
					$date = date('Y-m-d', strtotime($opr_date));
					
					$service_id = $user_opertion_record->service_id;
					$reminders_data =  FollowUpReminder::where('sub_service_id',$service_id)->get();
					
					if(count($reminders_data) != 0)
					{
						$reminders =  $reminders_data;
					}else{
						$reminders = [];
					}
				} else {
					$reminders = [];
					$date = "";
				}
				
				return View('user.procedure/follow-up',compact(['reminders','date','user_opertion_record','AppointmentList','procedureId','OperationList','track_status']));
			}else if($type == 'visit'){
					$CarryThing 		= CarryThing::where('carry_type','visit_doctor')->where('sub_service_id',$procedure->service)->first();
					$AppointmentLists 		= AppointmentList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$procedureId)->with('serviceDetail')->with('doctorDetail')->orderBy('appointment_date', 'asc')->get();
					$comments_data = [];
					$comments_data  = NoteCommentData::with('doc_detail','doc_image')->where('user_id',$user->id)->where('visible_to',1)->where('procedure_id',$procedureId)->where('type','note')->orderby('id','desc')->get();
					$OperationList   = OperationList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$id)->first();
					
				return View('user.procedure/visit-doctor',compact(['AppointmentLists','procedureId','procedure','CarryThing','comments_data','OperationList','track_status']));
					
			}else if($type == 'review'){
				$AppointmentList = AppointmentList::where('user_id',$user->id)->where('status','1')->with('serviceDetail')->with('doctorDetail')->first();
				$OperationList   = OperationList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$id)->first();
				$procedure_detail = Procedure::where('user_id',$user->id)->where('id',$id)->first();
				$current_user_id =  auth()->user()->id; 
				$userId    = Auth::id();
				$userdata  = UserDetail::where('user_id',$userId)->first();
				$userimage = $userdata->profile_picture;
				return View('user.procedure/review',compact(['AppointmentList','procedureId','OperationList','userimage','id','procedure_detail','track_status']));
			}
			else if($type == "report"){
				$current_user_id =  auth()->user()->id;
				$GraftOptions =[];
				$images = [];
				$report = [];
				$report_id = "";
				$comment = "";
				$OperationList   = OperationList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$id)->first();
				$doctorcomment = NoteCommentData::with('doc_detail','doc_image')->where('user_id',$user->id)->where('visible_to',1)->where('procedure_id',$procedureId)->where('type','comment')->orderby('id','desc')->get();
				$get_report_id = Procedure::where('id',$id)->where('user_id',$current_user_id)->first();
				$procedures = Procedure::where('user_id',$user->id)->with(['serviceDetail','Offer'])->orderby('id','desc')->first();
				
				if(!empty($procedures))
				{
					$report_id = $procedures->report_id;
				}
				
				if(count($get_report_id) > 0)
				{
					//if($get_report_id->type == "offer")
					//{
					//	$report_id = $get_report_id->report_id;
					//}
					//else
					//{
					//	$report_id = $get_report_id->preportid;	
					//}
					$report_id = $get_report_id->report_id;
					
					$report = HairTransplantReport::where('id',$report_id)->first();
					
					if(count($report) > 0)
					{
						
						/* graft distribution data */
						$graftArea = $report->affected_ids;
						if($graftArea == "1,2,3,4"){
						$graftOption = "option1";
						}elseif($graftArea == "1,2,3,4,6"){
						$graftOption = "option2";
						}elseif($graftArea == "1,2,3,4,5,6"){
						$graftOption = "option3";
						}elseif($graftArea == "1,2,3,4,5,6,7"){
						$graftOption = "option4";
						}elseif($graftArea == "1,2"){
						$graftOption = "option5";
						}elseif($graftArea == "1,2,3"){
						$graftOption = "option6";
						}else{
							$graftOption = "";
						}
						
						//$GraftOptions 		=  GraftOption::where('option_type',$graftOption)->get();
						
						if(!empty($report->affected_gallery)) {
							$images = explode(",", $report->affected_gallery);
						}
					}
				}
				
				return View('user.procedure/report',compact(['procedureId', 'graftOption','images','report','doctorcomment','track_status','Offers','procedures','get_report_id','OperationList','report_id','track_status']));	
			}
		}else{
			return Redirect()->route('userUpdateProcedures')->with('message', 'Procedure are no longer with this user.');
		}
	}
	
	public function fixAppointment(Request $request){		
		$user = User::where('id',Auth::user()->id)->with('userDetail')->first();
		$procedure = Procedure::where('id',$request->procedure_id)->first();		
		$appointmentDate 			= date('Y-m-d',strtotime($request->appointment_date));
		$appointmentTime 			= explode("-",$request->appointment_time);
		$appointmentFromDatetime 	= $appointmentDate.' '.$appointmentTime[0];
		$appointmentToDatetime 		= $appointmentDate.' '.$appointmentTime[1];
		$city 						= $request->city;
		$apiKey                     = env("GOOGLE_API_KEY");
		$country                    = "India";
		if(isset($request->manual_city) && $request->manual_city == "1"){
			$city 		= Session::get('region');
			if($city == ""){
				/*$user_ip 	= getenv('REMOTE_ADDR');
				$geo 		= unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));
				if(!empty($goe)){
					$city 		= $geo["geoplugin_city"];
				}*/
				$city = "Mohali";
			}
			
		}
				
		$url = "https://maps.google.com/maps/api/geocode/json?address=".preg_replace('/\s+/', '+', $city)."&sensor=false&region=".$country."&key=".$apiKey;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		$response = curl_exec($ch);
		curl_close($ch);
		$response = json_decode($response);
		if(!empty($response->results)){
			$latitude  = $response->results[0]->geometry->location->lat;
			$longitude = $response->results[0]->geometry->location->lng;
		}else{
			return response()->json(['success'=>true, 'message' => 'Your location are not found!'], $this->successStatus);	
		}
		$service_id 				= $procedure->service;
		$user_id 					= $user->id;
		$timeSlot               	= date('H:i a',strtotime($appointmentFromDatetime));
		/* Check if same user id,service_id and status=0 are exists or not */
		$AppointmentList 			= AppointmentList::where('user_id',$user_id)->where('service_id',$service_id)->where('status','0')->where('procedure_id',$request->procedure_id)->first();
		if($AppointmentList){
			return response()->json(['success'=>true, 'message' => 'Your request has been under doctor confirmation. We will update you soon!'], $this->successStatus);
		}
		/* Get clinic details which comes under 5 km of user's current location */
		$clinicDetails        	= Doctors::select(DB::raw('id,user_id,clinic_name,clinic_address,clinic_name,clinic_name,clinic_name,sub_skills, ( 6367 * acos( cos( radians('.$latitude.') ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians('.$longitude.') ) + sin( radians('.$latitude.') ) * sin( radians( latitude ) ) ) ) AS distance'))
			->having('distance', '<', 100)
			->orderBy('distance')
			->with('user')
			->where('skills', 'like', '%1%')->get()->toArray();		
					
		if(!empty($clinicDetails)){
			$AppointmentList = new AppointmentList;
			$AppointmentList->user_id 			= $user->id;
			$AppointmentList->doctor_id 		= '0';
			$AppointmentList->service_id 		= $service_id;
			$AppointmentList->procedure_id 		= $request->procedure_id;
			$AppointmentList->appointment_status 	= "new";
			$AppointmentList->appointment_date 	= $appointmentFromDatetime;
			$AppointmentList->appointment_to_date 	= $appointmentToDatetime;
			$AppointmentList->save();
			foreach($clinicDetails as $clinicDetail){				
			    $skills = ($clinicDetail['sub_skills']) ? json_decode($clinicDetail['sub_skills']) : array();
			    if($clinicDetail['user']['isVerified'] == 1  && in_array($service_id, $skills) ) {
					$AppointmentRequest 				= new AppointmentRequest;
					$AppointmentRequest->appointment_id = $AppointmentList->id;
					$AppointmentRequest->doctor_id 		= $clinicDetail['user_id'];
					$AppointmentRequest->service_id 	= $service_id;
					$AppointmentRequest->request_date 	= $appointmentFromDatetime;
					$AppointmentRequest->request_time 	= date('H:I A',strtotime($appointmentFromDatetime));
					$AppointmentRequest->save();
					$service  = new Doctors;
					$serviceA = $service->service($service_id);
					$serviceName = 'N/A';
					if(!empty($serviceA)){
						$serviceName = $serviceA->service_name;
					}
					/* appointment request email to all doctors whoese under distance */
					$email = $clinicDetail['user']['email'];
					//$email = "dottechnologies123@gmail.com";
					$name  = $clinicDetail['user']['name'];
					$link  = url('/').'/api/user/confirm-request/'.$AppointmentRequest->id;
					$fromEmail = env('MAIL_FROM_ADDRESS');
					$data = array(
							'name'		=> $name,
							'service' 	=> $serviceName,
							'date' 		=> $appointmentDate,
							'time' 		=> $timeSlot,
							'email' 	=> $email,
							'from' 		=> $fromEmail,
							'link' 		=> $link);
					
					
						Mail::send('requestMail', $data, function($message) use ($data) {
							$message->to($data['email'], 'KABERA')->subject
							('Customer Appointment Request');
							$message->from($data['from'],'Kabera');
						});
					$users 		= User::where('id',$clinicDetail['user_id'])->first();
					if($users){
						$device_token = $users->device_token;
						if($device_token != ""){
							$this->AppointmentNotification($device_token);	
						}
						
					$assistantt = DoctorAssistant::with(array('user' => function($q){ 
						 $q->select('id','name','email', 'phone','added_by','request_recieve_per_day','device_token');
					}))->where('doctor_id', $clinicDetail['user_id'])->get();
						
							foreach($assistantt as $assistants){
								if($assistants->user->device_token != ''){								
									$device_token = $assistants->user->device_token;
									//print_r($device_token);  die;
									$this->NoteNotificationForDoctor($device_token);
								
								} 
						}
				
				
					}	
				}
			}
			
			
							/*$otherDetail = array(
								'appointment_date' => $appointmentDatetime,
								'day_name'         => 'Monday', 
								'timeslot'         => $timeSlot, 
								'required_grafts'  => $required_grafts,
								'grafts_in_cart'   => $grafts_in_cart,
								'cost_per_graft'   => $cost_per_graft,
								'total_cost'       => $total_cost,
								'balance'          => $grandTotal
							);*/
							
				
			return response()->json(['success'=>true,'message' => 'Your request has been submitted. We will update you soon!']); 					
		}else{
			return response()->json(['success'=>true, 'message' => 'No doctors are found on this location.'], $this->successStatus);
		}
	}
	
	
	public function updateAppointment(Request $request){	       	
		
		$appointment_id             = $request->appointment_id; 			
		$appointmentDate 			= date('Y-m-d',strtotime($request->appointment_date));
		$appointmentTime 			= explode("-",$request->appointment_time);
		$appointmentFromDatetime 	= $appointmentDate.' '.$appointmentTime[0];
		$appointmentToDatetime 		= $appointmentDate.' '.$appointmentTime[1];
		
		$timeSlot               	= date('H:i a',strtotime($appointmentFromDatetime));
		
		if($appointment_id){
			$AppointmentList 			= AppointmentList::find($appointment_id);
			$AppointmentList->appointment_date 	= $appointmentFromDatetime;
			$AppointmentList->appointment_to_date 	= $appointmentToDatetime;
			$AppointmentList->save();			
				
			return response()->json(['success'=>true,'message' => 'Your Appointment updated succesfully ']); 					
		}else{
			return response()->json(['success'=>false, 'message' => 'Error in updation.'], $this->successStatus);
		}
	}
	
	public function processPayment(Request $request){
		$user 		 	= Auth::user();
		$id 			= $request->procedure_id;
		$Procedure      = Procedure::find($id);
		/* All Required Parameters by your Gateway */
		$redirectUrl 	= url('/').'/procedure/payment/success';
		$cancelUrl 	 	= url('/').'procedure/payment/cancel';
		$oid = $id.''.rand(5, 15);
		if($user && $Procedure){
			if($request->amount != ""){
				$amount = $request->amount;
			}else{
				$amount = $Procedure->pending_payment;
			}
			
			if($amount < 0){
				 return Response::json(array('success'=>false,'message'=>'No need to payment.'));
			}
			if($amount > $Procedure->pending_payment ){
				 return Response::json(array('success'=>false,'message'=>'Payment amount is greater then pending amount.'));
			}
			$userDetail     = UserDetail::where('user_id',$user->id)->first();
			$parameters = [
				'merchant_id' 		=> Config::get('indipay.ccavenue.merchantId'),
				'currency' 			=> Config::get('indipay.ccavenue.currency'),
				'redirect_url' 		=> $redirectUrl,
				'cancel_url' 		=> $cancelUrl,
				'tid' 				=> $oid,
				'language' 			=> Config::get('indipay.ccavenue.language'),
				'order_id' 			=> $oid,
				'amount' 			=> $amount,
				'billing_name' 		=> $user->name,
				'billing_address' 	=> $userDetail->address,
				'billing_city' 		=> $userDetail->city,
				'billing_state' 	=> $userDetail->state,
				'billing_zip' 		=> $userDetail->post_code,
				'billing_country' 	=> $userDetail->country,
				'delivery_name' 	=> $user->name,
				'delivery_address' 	=> $userDetail->address,
				'delivery_city' 	=> $userDetail->city,
				'delivery_state' 	=> $userDetail->state,
				'delivery_zip' 		=> $userDetail->post_code,
				'delivery_country' 	=> $userDetail->country,
				'delivery_tel' 		=> $userDetail->phone,
				'merchant_param1' 	=> $id
			  ];
			  Session::put('proceduredata_'.$user->id, $parameters);
			  return Response::json(array('success'=>true,'message'=>'Product added to Wishlist successfully'));
		  }else{
			  return Redirect::back()->with(['message', 'something went wrong']);
		  }
	}
/* procedurePayment  */
	
	 /**
     * Function to checkout payment.
     * @return Response
    */
    public function procedurePayment()
    {
		$user 		 	= Auth::user();
		if($user){
			$proceduredata = Session::get('proceduredata_'.$user->id);
			if(!empty($proceduredata)){
				$responseSuccessURL 	 = url('/').'/procedure/payment/success';
				$responseFailURL 	 	 = url('/').'/procedure/payment/cancel';
				$storeId         		 = Config::get('icicipay.icici.storeid');
				$sharedSecret            = Config::get('icicipay.icici.sharedsecret');
				$currency            	 = Config::get('icicipay.icici.currency');
				$order 					 = Session::get('orderdata');
				$UserEmail       		 = $user->email;
				$userId          		 = Config::get('icicipay.icici.userid');
				$parameters = ['responseSuccessURL' => $responseSuccessURL,'responseFailURL' => $responseFailURL,'storeId' => $storeId,'userId' => $userId,'UserEmail' => $UserEmail,'amount' => $proceduredata['amount'],'sharedSecret' => $sharedSecret,'currency' => $currency,'extra_param' => $proceduredata['merchant_param1']];
				return IcicipaymentServiceProvider::process($parameters);
			}else{
				return Redirect::back()->with(['message', 'something went wrong']);
			}
		}else{
			return Redirect::back()->with(['message', 'something went wrong']);
		}
    }
    
    /**
     * Function to check payment response.
     * @return Response
    */
    public function paymentResponse(Request $request)
    {
		$encResponse 	= $request->input();
        if($encResponse){
			$email     = env('KABERA_ADMIN_EMAIL'); //user admin email to testing
			if($encResponse['status'] == "APPROVED"){
				$message = "Thank You! Your payment has been successfully Completed.";
				$id 			= $encResponse['extra_param'];
				$Procedure      = Procedure::find($id);
				if($Procedure){
					$pending_pmt = $Procedure->pending_payment - $encResponse['chargetotal'];
					$Procedure->track_status      = 'payment'; 
					$Procedure->total_payment     = $Procedure->total_payment; 
					$Procedure->pending_payment   = $Procedure->pending_payment-$encResponse['chargetotal']; 
					$Procedure->advanced_payment   = $Procedure->advanced_payment+$encResponse['chargetotal']; 
					$Procedure->save();
					$PaymentType 				= new PaymentType;
					$PaymentType->user_id  	    = $Procedure->user_id;
					$PaymentType->procedure_id  = $Procedure->id;
					$PaymentType->amount 		= $encResponse['chargetotal'];
					$PaymentType->payment_type  = 'online';
					$PaymentType->save();
					
					$orders = Order::find($Procedure->order_id);
					$orders->total          = $Procedure->total_payment;
					$orders->grand_total    = $Procedure->total_payment;
					$orders->pending_amount = $pending_pmt;
					$orders->payment_status = "Success";
					$orders->save();
				}
			}else{
				$message = "Your payment has been declined due to your card problem. Please contact to admin support.";
			}
			
			/*$data = array('order_id' => decResponse['order_id'],'message' => $message);
			Mail::send('emails.procedureconfirmation', $data, function($messaged)use($email){
			  $messaged->from(env('KABERA_SUPPORT_EMAIL'));
			  $messaged->to($email);
			  $messaged->subject('Order Confirmation');
			});*/
		}	
		return Redirect()->route('trackProcedure', ['id' => $encResponse['extra_param']])->with('message', $message);
	}
	
	/**
     * Function to return checkout cancel page.
     * @return Response
    */
	public function paymentCancel(Request $request)
    {
		return Redirect()->route('trackProcedure', ['id' => $request->input('extra_param')])->with('message',$request->input('fail_reason'));
	}
	
	
	/**
     * CCAvenue Decrypt Function
     *
     * @param $encryptedText
     * @param $key
     * @return string
     */
    protected function decrypt($encryptedText,$key)
    {
        $secretKey = $this->hextobin(md5($key));
        $initVector = pack("C*", 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f);
        $encryptedText=$this->hextobin($encryptedText);
        $openMode = @mcrypt_module_open(MCRYPT_RIJNDAEL_128, '','cbc', '');
        @mcrypt_generic_init($openMode, $secretKey, $initVector);
        $decryptedText = @mdecrypt_generic($openMode, $encryptedText);
        $decryptedText = rtrim($decryptedText, "\0");
        @mcrypt_generic_deinit($openMode);
        return $decryptedText;

    }
    
    /**
     * @param $hexString
     * @return string
     */
    protected function hextobin($hexString)
    {
        $length = strlen($hexString);
        $binString="";
        $count=0;
        while($count<$length)
        {
            $subString =substr($hexString,$count,2);
            $packedString = pack("H*",$subString);
            if ($count==0)
            {
                $binString=$packedString;
            }

            else
            {
                $binString.=$packedString;
            }

            $count+=2;
        }
        return $binString;
    }
    
    /**
     * Function to save reminder images.
     * @return Response
    */
  /* code by nikhil*/
	public function reminderImages(Request $request)
    {
		
	//echo '<pre>';	print_r($_FILES);
	//echo '<pre>';	print_r($request->input());die;
		
		
		$images = array();
		$total = count($request->file('fileUpload'));
		 if($request->hasfile('fileUpload')) 
			{
				$allowedfileExtension=['jpg','png','jpeg','gif'];
				
				$size = [];
				foreach($request->file('fileUpload') as $image)
				{	
					
					
					$folder           = 'reminder_images/';
					$random_number 	  = mt_rand(100000, 999999);
					$img_name = str_replace(' ', '', $image->getClientOriginalName());
					
					$name = $random_number.$img_name; 
				    $extension = $image->getClientOriginalExtension();
				    $extension = strtolower($extension);
				   
					$size[] = $image->getSize();  
					
					$check = in_array($extension , $allowedfileExtension); 
					  if($check)
					  {
						$image_size = 20000000;
						$total_size = array_sum($size);
						if($total_size > $image_size)
						{
							return response()->json(['error'=>'Images size must be less than 2 mb']); 
						}
						else
						{
					  	$image->move(public_path().'/images/reviews/', $name);                  
					  	array_push($images , $folder.$name);
						}
					  }
					  else
					  {
						return response()->json(['error'=>'Sorry Only Upload png , jpg , gif images']); 
					  }
				
					$appointment_id = $request->input('appointment_id');
					$user_id = $request->input('user_id');
					$procedure_id = $request->input('procedure_id');
					$upload = DB::table('procedure_foloup_images')->insert(['images' => $name , 'appointment_id'=> $appointment_id , 'user_id'=> $user_id , 'procedure_id'=> $procedure_id]);
					if($upload){
						$result = 1;
					} else {
						$result = 0;
					}	
					
					
				}
				if($result == 1){
				return response()->json(['success'=>true, 'message'=> 'Image upload successfully']); 
				} else {
					return response()->json(['success'=>true, 'message'=> 'No image uploaded']);
				}
				
			}
	}

	
	/**Function to change Procedure Offer 
	 * @return Response
	*/	
	function changeProcedureOffer(Request $request) {
		$id 	   = $request->input('procedure_id');
		$offer_id  = $request->input('offer');
		$Procedure = Procedure::find($id);
		$Package   = Offer::find($offer_id);
				
		$paidAmt 		 =  $Procedure->advanced_payment;
		$optionDiscount  =  $Procedure->option_discount;
		$packageAmt 	 =  $Package->package_price;
		$packageDiscount =  $Package->discount;
	
		$finalAmount 	 =  $packageAmt-$packageDiscount;
		$pending		 =  $finalAmount - $paidAmt - $optionDiscount;
		if($offer_id != $Procedure->offer_apply) {
			$Procedure->type 			 = 'package';
			$Procedure->offer_apply 	 = $offer_id;
			$Procedure->required_grafts  = $Package->offer_grafts;
			$Procedure->total_payment	 = $finalAmount;
			$Procedure->discount		 = $packageDiscount;
			$Procedure->pending_payment	 = $pending;
			$Procedure->save();
			return response()->json(['success'=>true, 'package'=>asset('/images').'/'.$Package->banner_image, 'message'=> 'Offer Changed Successfully']);
		} else {
			return response()->json(['success'=>true, 'message'=> 'This Offer Already Added on your Procedure']);
		}				
	}
	
	
	public function AppointmentNotification($token) 
	{
		//die('svsdfs');
		
		//echo $message; die;
		
		//Android Token
		
		
		//$token = 'epweoOXplKw:APA91bG_pxWZBE5w4KEK6pFoU9Fgzn8JVpkrbqwV-MawLlaOkAdVMKMOQptYwUyyZ0CcpH825l0pJUptUKopL2mnmLVNZTdFcyOe1Wvq__t4Djcz0j_mtdcpCX4kRrv_tBN_e_3SilK0';

		
		$optionBuilder = new OptionsBuilder();
		
		$optionBuilder->setTimeToLive(60*20);
		
		$notificationBuilder = new PayloadNotificationBuilder('Kabera');
		$notificationBuilder->setBody('You have received a new user Appointment Notification')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		
		//$message1 =  Response::json(array('success'=>false,'message'=>$message));	
		
		
		$dataBuilder->addData(['message' => 'Appointment Notification']);
			
		
			
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();

		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();

		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();

		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();

		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
		
		
	}
	
	
	public function myAccount()
	{
		return View('user.my-account');
	}	
			
	function appoitmentslot(Request $request) {
		
		
		$selected_date = $request->input('appointment_date');

		$selected_date_str = strtotime($selected_date);
		$current_date = date("m/d/Y");
		
		$current_date_str = strtotime($current_date);
		
		$time_array = [];
		if($current_date == $selected_date)
		{
					$get_appoitment_timeslot = AppoitmentTimeslot::get();
					$current_time = date("G:i");
					 $current_time_strtime =  strtotime($current_time);
					if(count($get_appoitment_timeslot) != 0)
					 {
					 foreach($get_appoitment_timeslot as $timeslot)
						{
							$endtime = $timeslot->end_time;
							$starttime = $timeslot->start_time;
							$convertend_to_24hours = date("G:i", strtotime($endtime));
							$convertstart_to_24hours = date("G:i", strtotime($starttime));
							$endtime_strtime = strtotime($convertend_to_24hours);
							$starttime_strtime = strtotime($convertstart_to_24hours);
							if($current_time_strtime < $endtime_strtime)
							{
								$time_array[$convertstart_to_24hours.'-'.$convertend_to_24hours] = $starttime.' TO '.$endtime;
							}
						}
						
					}
				}
		else
		{
					$get_appoitment_timeslot = AppoitmentTimeslot::get();
					$current_time = date("G:i");
					 $current_time_strtime =  strtotime($current_time);
					 if(count($get_appoitment_timeslot) != 0)
					 {
						foreach($get_appoitment_timeslot as $timeslot)
						{
							$endtime = $timeslot->end_time;
							$starttime = $timeslot->start_time;
							$convertend_to_24hours = date("G:i", strtotime($endtime));
							$convertstart_to_24hours = date("G:i", strtotime($starttime));
							$endtime_strtime = strtotime($convertend_to_24hours);
							$starttime_strtime = strtotime($convertstart_to_24hours);
							$time_array[$convertstart_to_24hours.'-'.$convertend_to_24hours] = $starttime.' TO '.$endtime;
							
						}
					}
			
		}
		
		
		return response()->json($time_array);
	}
	
	
	
	
	public function NoteNotificationForDoctor($token)
	{				
		
		$optionBuilder = new OptionsBuilder();
		
		$optionBuilder->setTimeToLive(60*20);
		
		$notificationBuilder = new PayloadNotificationBuilder('Kabera Glocal');
		$notificationBuilder->setBody('You have recieved new Notification From user')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		
		//$message1 =  Response::json(array('success'=>false,'message'=>$message));	
		
		
		$dataBuilder->addData(['message' => 'New note is added successfully']);
			
		
			
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();
//print_r($downstreamResponse); die;

		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();

		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();

		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();

		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
		
	} 
		

	
	
}
