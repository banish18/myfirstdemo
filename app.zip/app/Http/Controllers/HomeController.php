<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Page;
use App\Offer;
use App\CityOffer;
use App\Banner;
use View;
use Session;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */   
    private $region;
    public function __construct()
    {
        //$this->middleware(['auth','verified']);
        $this->region = "";
		if(!empty(Session::get('region'))) { 
			$this->region = Session::get('region');
		}
    }
    
	/**
     * Create a Function to display data on home page.
     * @return slides, offers
    */
	public function index() {
		$offers  = array();				
		$slides  = Page::where('template', 'Home')->where('data_type','home slider')->get();	
		$banners = Page::where('template', 'Home')->where('data_type','home banner')->orderBy('position', 'ASC')->get();
		foreach($banners as $key=>$val) {
			$offers[] = $val;
			$data 	  = json_decode($val['content_en'], true);
			$offers[$key]['banner_column']  = $data['banner_column'];
			if($data['banner_column'] == '1') {
				//one column
				if(CityOffer::where('type_id', $data['offer'])->where('city',$this->region)->first() !== null) {
					$offers[$key]['offer']   =  CityOffer::where('type_id', $data['offer'])->where('city',$this->region)->first();
				} else {                     
					$offers[$key]['offer']   =  Banner::find($data['offer']);
				}				
			} else if($data['banner_column'] == '2') {
				//first column
				if(CityOffer::where('type_id', $data['offer_first'])->where('city',$this->region)->first() !== null) {
					$offers[$key]['offer_first']   =  CityOffer::where('type_id', $data['offer_first'])->where('city',$this->region)->first();
				} else {
					$offers[$key]['offer_first']   =  Banner::find($data['offer_first']);
				}
				
				//second column
				if(CityOffer::where('type_id', $data['offer_second'])->where('city',$this->region)->first() !== null) {
					$offers[$key]['offer_second']    = CityOffer::where('type_id', $data['offer_second'])->where('city',$this->region)->first();
				} else {
					$offers[$key]['offer_second']    =  Banner::find($data['offer_second']);	
				}			
			}
		}
		return View('home',compact(['slides', 'offers']));
	}
	
	/**
     * Create a new Function to update user region.
     * @return response
    */
	public function updateRegion(Request $request) {
		$region = $request->input('region');
		Session::put('region', $region);
		return Response::json(array('success'=>true,'message'=>'Region Updated Successfully'));
	}
   
}
