<?php
namespace App\Http\Controllers;

use Auth;
use App\Orders as Order;
use App\OrdersDetail as OrderDetail;
use App\TempOrder;
use Stripe;
use Session;
use App\Cart;
use App\CartItem;
use App\Product;
use App\PaymentType;
use App\Procedure;
use App\ProcedureOption;
use App\HairTransplantReport;
use App\ProductProductOrderDetail;
use App\Service;
use App\Page;
use App\Offer;
use App\Countries;
use App\States;
use App\Banner;
use App\UserDetail;
use App\Wishlist;
use App\CityOffer;
use App\Mail\OrderEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Config;
use DB;
use Softon\Indipay\Facades\Indipay;
use App\Providers\IcicipaymentServiceProvider;

class ShopController extends Controller
{
	/**
     * Create a new controller instance.
     * @return void
    */   
    private $region;
    private $GST;
    public function __construct()
    {
        //$this->middleware(['auth','verified']);
        $this->region = "";
		if(!empty(Session::get('region'))) { 
			$this->region = Session::get('region');
		}
		$this->GST = env('GST_RATE');
		
		//$this->orderdata = [];
    }
    
	/*
     * Function to get hair category products.
     * @return products
    */
	public function getHairProducts()
	{
		$service  = 1; //hair
		$category = 'Hair';
		$products = Product::with('gallery')->where('cat_id',$service)->get();
		
		$slides  		 =  Page::where('template', 'Hair Products')->where('data_type','hair-products-slider')->get()->toArray();		 
		$productContent  =  Page::where('template','Hair Products Page')->where('data_type','hair-product-data')->first();
		$offers 		 =  [];	
		 if($productContent !== null) {
			$productData   	  	     = json_decode($productContent->content_en);
			
			if(CityOffer::where('type_id', $productData->first_offer)->where('city',$this->region)->first() !== null) {
				$offers['first_offer']  = CityOffer::where('type_id',  $productData->first_offer)->where('city',$this->region)->first();
			} else {
				$offers['first_offer']   = Banner::find($productData->first_offer);
			}
			
			if(CityOffer::where('type_id', $productData->second_offer)->where('city',$this->region)->first() !== null) {
				$offers['second_offer']  = CityOffer::where('type_id', $productData->second_offer)->where('city',$this->region)->first();
			} else {
				$offers['second_offer']  = Banner::find($productData->second_offer);
			}
			
			if(CityOffer::where('type_id', $productData->third_offer)->where('city',$this->region)->first() !== null) {
				$offers['third_offer']   = CityOffer::where('type_id', $productData->third_offer)->where('city',$this->region)->first();
			} else { 
				$offers['third_offer']   = Banner::find($productData->third_offer);
			}
			
			if(CityOffer::where('type_id', $productData->left_banner)->where('city',$this->region)->first() !== null) {
				$offers['left_banner']   = CityOffer::where('type_id', $productData->left_banner)->where('city',$this->region)->first();
			} else { 
				$offers['left_banner']   = Banner::find($productData->left_banner);	
			}
				
			if(CityOffer::where('type_id', $productData->first_right_banner)->where('city',$this->region)->first() !== null) {
				$offers['first_right_banner']   = CityOffer::where('type_id', $productData->first_right_banner)->where('city',$this->region)->first();
			} else { 
				$offers['first_right_banner']   = Banner::find($productData->first_right_banner);
			}	
			
			if(CityOffer::where('type_id', $productData->second_right_banner)->where('city',$this->region)->first() !== null) {
				$offers['second_right_banner']   = CityOffer::where('type_id', $productData->second_right_banner)->where('city',$this->region)->first();
			} else { 
				$offers['second_right_banner']  = Banner::find($productData->second_right_banner);
			}	
			
			if(CityOffer::where('type_id', $productData->third_right_banner)->where('city',$this->region)->first() !== null) {
				$offers['third_right_banner']   = CityOffer::where('type_id', $productData->third_right_banner)->where('city',$this->region)->first();
			} else { 			
				$offers['third_right_banner']   = Banner::find($productData->third_right_banner);
			}
		 }		 
		
		return view('shop.products',compact(['products', 'category', 'slides', 'offers']));
	}

	/**
     * Function to get skin category products.
     * @return products
    */
	public function getSkinProducts()
	{
		$service  = 2; //skin
		$category = 'Skin';
		$products = Product::where('cat_id',$service)->get();
		
		//pending comment by naveen
		//This will be change when we create page for skin products content now showing only hair data
		$slides  		 =  Page::where('template', 'Hair Products')->where('data_type','hair-products-slider')->get()->toArray();		 
		$productContent  =  Page::where('template','Hair Products Page')->where('data_type','hair-product-data')->first();
		$offers 		 =  [];	
		 if($productContent !== null) {
			$productData   	  	     = json_decode($productContent->content_en);
			
			if(CityOffer::where('type_id', $productData->first_offer)->where('city',$this->region)->first() !== null) {
				$offers['first_offer']  = CityOffer::where('type_id',  $productData->first_offer)->where('city',$this->region)->first();
			} else {
				$offers['first_offer']   = Banner::find($productData->first_offer);
			}
			
			if(CityOffer::where('type_id', $productData->second_offer)->where('city',$this->region)->first() !== null) {
				$offers['second_offer']  = CityOffer::where('type_id', $productData->second_offer)->where('city',$this->region)->first();
			} else {
				$offers['second_offer']  = Banner::find($productData->second_offer);
			}
			
			if(CityOffer::where('type_id', $productData->third_offer)->where('city',$this->region)->first() !== null) {
				$offers['third_offer']  = CityOffer::where('type_id', $productData->third_offer)->where('city',$this->region)->first();
			} else { 
				$offers['third_offer']   = Banner::find($productData->third_offer);
			}
			
			if(CityOffer::where('type_id', $productData->left_banner)->where('city',$this->region)->first() !== null) {
				$offers['left_banner']   = CityOffer::where('type_id', $productData->left_banner)->where('city',$this->region)->first();
			} else { 
				$offers['left_banner']   = Banner::find($productData->left_banner);	
			}
				
			if(CityOffer::where('type_id', $productData->first_right_banner)->where('city',$this->region)->first() !== null) {
				$offers['first_right_banner']   = CityOffer::where('type_id', $productData->first_right_banner)->where('city',$this->region)->first();
			} else { 
				$offers['first_right_banner']   = Banner::find($productData->first_right_banner);
			}	
			
			if(CityOffer::where('type_id', $productData->second_right_banner)->where('city',$this->region)->first() !== null) {
				$offers['second_right_banner']   = CityOffer::where('type_id', $productData->second_right_banner)->where('city',$this->region)->first();
			} else { 
				$offers['second_right_banner']  = Banner::find($productData->second_right_banner);
			}	
			
			if(CityOffer::where('type_id', $productData->third_right_banner)->where('city',$this->region)->first() !== null) {
				$offers['third_right_banner']   = CityOffer::where('type_id', $productData->third_right_banner)->where('city',$this->region)->first()->toArray();
			} else { 			
				$offers['third_right_banner']   = Banner::find($productData->third_right_banner);
			}
		 }		 
		return view('shop.products',compact(['products','category', 'slides', 'offers']));
	}

	/**
     * Function to get dental category products.
     * @return products
    */
	public function getDentalProducts()
	{
		$service  = 3; //dental
		$products = Product::where('cat_id',$service)->get();
		$category = 'Dental';
		
		//pending comment by naveen
		//This will be change when we create page for skin products content now showing only hair data
		$slides  		 =  Page::where('template', 'Hair Products')->where('data_type','hair-products-slider')->get()->toArray();		 
		$productContent  =  Page::where('template','Hair Products Page')->where('data_type','hair-product-data')->first();
		$offers 		 =  [];	
		 if($productContent !== null) {
			$productData   	  	     = json_decode($productContent->content_en);
			
			if(CityOffer::where('type_id', $productData->first_offer)->where('city',$this->region)->first() !== null) {
				$offers['first_offer']  = CityOffer::where('type_id',  $productData->first_offer)->where('city',$this->region)->first()->toArray();
			} else {
				$offers['first_offer']   = Banner::find($productData->first_offer)->toArray();
			}
			
			if(CityOffer::where('type_id', $productData->second_offer)->where('city',$this->region)->first() !== null) {
				$offers['second_offer']  = CityOffer::where('type_id', $productData->second_offer)->where('city',$this->region)->first()->toArray();
			} else {
				$offers['second_offer']  = Banner::find($productData->second_offer)->toArray();
			}
			
			if(CityOffer::where('type_id', $productData->third_offer)->where('city',$this->region)->first() !== null) {
				$offers['third_offer']   = CityOffer::where('type_id', $productData->third_offer)->where('city',$this->region)->first()->toArray();
			} else { 
				$offers['third_offer']   = Banner::find($productData->third_offer)->toArray();
			}
			
			if(CityOffer::where('type_id', $productData->left_banner)->where('city',$this->region)->first() !== null) {
				$offers['left_banner']   = CityOffer::where('type_id', $productData->left_banner)->where('city',$this->region)->first()->toArray();
			} else { 
				$offers['left_banner']   = Banner::find($productData->left_banner)->toArray();	
			}
				
			if(CityOffer::where('type_id', $productData->first_right_banner)->where('city',$this->region)->first() !== null) {
				$offers['first_right_banner']   = CityOffer::where('type_id', $productData->first_right_banner)->where('city',$this->region)->first()->toArray();
			} else { 
				$offers['first_right_banner']   = Banner::find($productData->first_right_banner)->toArray();
			}	
			
			if(CityOffer::where('type_id', $productData->second_right_banner)->where('city',$this->region)->first() !== null) {
				$offers['second_right_banner']   = CityOffer::where('type_id', $productData->second_right_banner)->where('city',$this->region)->first()->toArray();
			} else { 
				$offers['second_right_banner']  = Banner::find($productData->second_right_banner)->toArray();
			}	
			
			if(CityOffer::where('type_id', $productData->third_right_banner)->where('city',$this->region)->first() !== null){
				$offers['third_right_banner']   = CityOffer::where('type_id', $productData->third_right_banner)->where('city',$this->region)->first()->toArray();
			} else { 			
				$offers['third_right_banner']   = Banner::find($productData->third_right_banner)->toArray();
			}
		 }		 
		return view('shop.products',compact(['products','category', 'slides', 'offers']));
	}
	
	
	/**
     * Function to get single product detail.
     * @return products
    */
	public function showProduct($id, $name)
	{
		$product = Product::with('gallery')->find($id);
		return view('shop.productdetail',compact(['product']));
	}

	/**
     * Function to add to cart.
     * @return response
    */
	public function addToCart(Request $request)
    {   
		$user_id = '';
		if(Auth::user()){
			$user_id = Auth::user()->id;	
			$data				= $request->all();
			$product_id 		= $data['product_id'];
			$cart_quantity 		= $data['cart_quantity'];
			$user_id 			= $user_id;
			$is_type 			= 'product';
			$product 			= Product::find($product_id);
			if(!$product && $is_type == 'product') {
				return Response::json(array('success'=>false,'message'=>'Product not found'));
			}
    	}else{
			return Response::json(array('success'=>false,'message'=>'Please login in'));	
		}
		
        $cart = Cart::where('user_id',$user_id)->first();
        if(!$cart){
            $cart = new Cart;
            $cart->user_id 			= $user_id;
            $cart->quantity_total 	= $cart_quantity;
            $cart->save();
            /*** Add cart items entry ***/   
            $CartItem = new CartItem;
            
            $CartItem->cart_id 			= $cart->id;
            $CartItem->product_id 		= $product_id;
            $CartItem->product_price 	= $product->product_price;
            $CartItem->discount 		= 0;
            $CartItem->total_price 		= $product->product_price*$cart_quantity;
            $CartItem->gst_price		= floor((($product->product_price*$cart_quantity) * $this->GST)/100);
            $CartItem->quantity 		= $cart_quantity;
            $CartItem->is_type 			= $is_type;
            $CartItem->save();
          
            /* Update Cart values */
            $cart = Cart::where('user_id',$user_id)->first();
            $cart->raw_total 	  		= $CartItem->total_price;
            $cart->discount_total 		= $CartItem->discount;
            $cart->grand_total    		= $CartItem->total_price;
            $cart->save();
            return Response::json(array('success'=>true,'message'=>'Product added to cart successfully','cart_quantity' => $cart->quantity_total));
        }else{
            $CartItem 	= CartItem::where('product_id',$product_id)->where('cart_id',$cart->id)->first();
            if(!$CartItem){
				if($product->stock < $cart_quantity && $is_type == 'cart'){
					return Response::json(array('success'=>false,'message'=>'No more products in stock'));
				}else{
					
					$CartItem = new CartItem;
					$CartItem->cart_id 			= $cart->id;
					$CartItem->product_id 		= $product_id;
					$CartItem->product_price 	= $product->product_price;
					$CartItem->discount 		= 0;
					$CartItem->total_price 		= $product->product_price*$cart_quantity;
					$CartItem->gst_price		= floor((($product->product_price*$cart_quantity) * $this->GST)/100);
					$CartItem->quantity 		= $cart_quantity;
					$CartItem->is_type 			= $is_type;
					$CartItem->save();
					 /* Update Cart values */
					$cartSum                    = CartItem::where('cart_id',$cart->id)->sum('total_price');
					$cartQtySum                 = CartItem::where('cart_id',$cart->id)->sum('quantity');
					$cartDicSum                 = CartItem::where('cart_id',$cart->id)->sum('discount');
					$cart->quantity_total 	  	= $cartQtySum;
					$cart->raw_total 	  		= $cartSum;
					$cart->discount_total 		= $cartDicSum;
					$cart->grand_total    		= $cartSum-$cartDicSum;
					$cart->save();
					return Response::json(array('success'=>true,'message'=>'Product added to cart successfully','cart_quantity' => $cart->quantity_total));	
				}
			}else{
				if($product->stock < $CartItem->quantity+$cart_quantity && $is_type == 'product'){
					return Response::json(array('success'=>false,'message'=>'No more products in stock'));
				}else{
					
					$CartItem->quantity 		= $CartItem->quantity+$cart_quantity;
					$CartItem->total_price 		= $CartItem->total_price+$product->product_price*$cart_quantity;
					$CartItem->gst_price		= floor((($product->product_price*($CartItem->quantity)) * $this->GST)/100);
					$CartItem->save();
					$cartSome                   = CartItem::where('cart_id',$cart->id)->sum('total_price');
					$cartQtySum                 = CartItem::where('cart_id',$cart->id)->sum('quantity');
					$cartDicSum                 = CartItem::where('cart_id',$cart->id)->sum('discount');
					$cart->quantity_total 	  	= $cartQtySum;
					$cart->raw_total 	  		= $cartSome;
					$cart->discount_total 		= $cartDicSum;
					$cart->grand_total    		= $cartSome-$cartDicSum;
					$cart->save();							
					
					return Response::json(array('success'=>true,'message'=>'Product added to cart successfully','cart_quantity' => $cart->quantity_total));	
					
				}
			}
        }
    }    
    
    /**
     *  Function Add to Cart Procedure Offer
     *  return response 
    */ 
    public function addToCartProcedure(Request $request)
    {	
		$user_id 		    = Auth::user()->id;	
		$data				= $request->all();
		$report_id	 		= $data['report_id'];
		$user_id 			= $user_id;
		$is_type 			= 'procedure';
		$HairReport 		= HairTransplantReport::find($report_id); 
		$payment  		    = $this->appontmentPayment($report_id);	
		if($HairReport) {
			$HairReport->appointment_status	=	1;
			$HairReport->total_payment		=	$payment['balance'];
			$HairReport->discount			=	$payment['totaldiscount'];
			$HairReport->save();
		}
				
		$Option				= ProcedureOption::find($data['option']);		
		$OfferPrice			= $payment['totalcost'];
		$totaldiscount		= $payment['totaldiscount'];		
		$totalCoast		   	= $payment['balance'];
		$finalcost		   	= $totalCoast;
		
		if($Option->discount_type == 'p') {
			$finalcost      =  ($finalcost * $Option->total_coast)/100;
			$optionDiscount	=  ($totalCoast * $Option->discount)/100;
		 } else {				 
			$finalcost      =  $Option->total_coast;
			$optionDiscount	=  $Option->discount;
		 }
		 
		$balance			= $totalCoast - $finalcost;
		$gstPrice			= $payment['gst_price'];
		 					
        $cart = Cart::where('user_id',$user_id)->first();        
        if(!$cart){
            $cart = new Cart;
            $cart->user_id 			= $user_id;
            $cart->quantity_total 	= 1;
            $cart->save();
            /*** Add cart items entry ***/   
            $CartItem = new CartItem;
            $CartItem->cart_id 			= $cart->id;
            $CartItem->product_id 		= $report_id;
            $CartItem->product_price 	= $OfferPrice;
            $CartItem->gst_price 		= $gstPrice;
            $CartItem->discount 		= 0;
            $CartItem->offer_discount 	= $totaldiscount;
            $CartItem->option_discount 	= $optionDiscount;
            $CartItem->total_price 		= $finalcost;
            $CartItem->quantity 		= 1;
            $CartItem->note 			= $data['note'];
            $CartItem->is_type 			= $is_type;
            $CartItem->payment_option   = $data['option'];
            $CartItem->save();
          
            /* Update Cart values */
            $cart = Cart::where('user_id',$user_id)->first();
            $cart->raw_total 	  		= $CartItem->total_price;
            $cart->discount_total 		= $CartItem->discount;
            $cart->grand_total    		= $CartItem->total_price;
            $cart->save();
            return Response::json(array('success'=>true,'message'=>'Procedure added to cart successfully','cart_quantity' => $cart->quantity_total));
        }else{
            $CartItem 	= CartItem::where('product_id',$report_id)->where('cart_id',$cart->id)->first();
            if(!$CartItem){
				
					$CartItem = new CartItem;
					$CartItem->cart_id 			= $cart->id;
					$CartItem->product_id 		= $report_id;
					$CartItem->product_price 	= $OfferPrice;
					$CartItem->gst_price 		= $gstPrice;
					$CartItem->discount 		= 0;
					$CartItem->offer_discount 	= $totaldiscount;
					$CartItem->option_discount 	= $optionDiscount;
					$CartItem->total_price 		= $finalcost;
					$CartItem->quantity 		= 1;
					$CartItem->is_type 			= $is_type;
					$CartItem->note 			= $data['note'];
					$CartItem->payment_option   = $data['option'];
					$CartItem->save();
					 /* Update Cart values */
					$cartSum                    = CartItem::where('cart_id',$cart->id)->sum('total_price');
					$cartQtySum                 = CartItem::where('cart_id',$cart->id)->sum('quantity');
					$cartDicSum                 = CartItem::where('cart_id',$cart->id)->sum('discount');
					$cart->quantity_total 	  	= $cartQtySum;
					$cart->raw_total 	  		= $cartSum;
					$cart->discount_total 		= $cartDicSum;
					$cart->grand_total    		= $cartSum-$cartDicSum;
					$cart->save();
					return Response::json(array('success'=>true,'message'=>'Procedure added to cart successfully','cart_quantity' => $cart->quantity_total));	
				
			}else{
					return Response::json(array('success'=>false,'message'=>'Procedure alredy added in cart'));
				
			}
        }
    }
    /**
     *  Function Add to Cart Package
     *  return response 
    */ 
    public function addToCartPackage(Request $request)
    {	
		$user_id 		    = Auth::user()->id;	
		$data				= $request->all();
		$offer_id	 		= $data['offer_id'];
		$user_id 			= $user_id;
		$is_type 			= 'package';
		$Option				= ProcedureOption::find($data['option']);
		$Offer 				= Offer::with('subService')->find($offer_id);
		$gst_rate           = env('GST_RATE');
		
		$packagePrice		= $Offer->package_price;
		$afterdiscountPrice = $Offer->package_price - $Offer->discount;
		$totaldiscount		= $Offer->discount;		
		$gstPrice			= floor(($afterdiscountPrice * $gst_rate)/100);
		$totalCost		   	= floor($afterdiscountPrice + ($afterdiscountPrice * $gst_rate)/100) ;
		$finalcost		   	= $totalCost;
		
		if($Option->discount_type == 'p') {
			$finalcost      =  ($finalcost * $Option->total_coast)/100;
			$optionDiscount	=  ($totalCost * $Option->discount)/100;
		 } else {				 
			$finalcost      =  $Option->total_coast;
			$optionDiscount	=  $Option->discount;
		 }
		 
		 $balance			= $totalCost - $finalcost;
		
								
        $cart = Cart::where('user_id',$user_id)->first();        
        if(!$cart) {
            $cart = new Cart;
            $cart->user_id 			= $user_id;
            $cart->quantity_total 	= 1;
            $cart->save();
            /*** Add cart items entry ***/   
            $CartItem = new CartItem;
            $CartItem->cart_id 			= $cart->id;
            $CartItem->product_id 		= $offer_id;
            $CartItem->report_id 		= $request->report_id;
            $CartItem->product_price 	= $Offer->package_price;
            $CartItem->discount 		= 0;
            $CartItem->offer_discount 	= $totaldiscount;
            $CartItem->option_discount 	= $optionDiscount;
            $CartItem->total_price 		= $finalcost;
            $CartItem->gst_price 		= $gstPrice;
            $CartItem->quantity 		= 1;
            $CartItem->note 			= $data['note'];
            $CartItem->is_type 			= $is_type;
            $CartItem->payment_option   = $data['option'];
            $CartItem->save();
          
            /* Update Cart values */
            $cart = Cart::where('user_id',$user_id)->first();
            $cart->raw_total 	  		= $CartItem->total_price;
            $cart->discount_total 		= $CartItem->discount;
            $cart->grand_total    		= $CartItem->total_price;
            $cart->save();
            return Response::json(array('success'=>true,'message'=>'Procedure added to cart successfully','cart_quantity' => $cart->quantity_total));
        } else {
            $CartItem 	= CartItem::where('product_id',$offer_id)->where('cart_id',$cart->id)->first();
            if(!$CartItem){
				
					$CartItem = new CartItem;
					$CartItem->cart_id 			= $cart->id;
					$CartItem->product_id 		= $offer_id;
					$CartItem->report_id 		= $request->report_id;
					$CartItem->product_price 	= $Offer->package_price;
					$CartItem->discount 		= 0;
					$CartItem->offer_discount 	= $totaldiscount;
					$CartItem->option_discount 	= $optionDiscount;
					$CartItem->total_price 		= $finalcost;
					$CartItem->gst_price 		= $gstPrice;
					$CartItem->quantity 		= 1;
					$CartItem->is_type 			= $is_type;
					$CartItem->note 			= $data['note'];
					$CartItem->payment_option   = $data['option'];
					$CartItem->save();
					/* Update Cart values */
					$cartSum                    = CartItem::where('cart_id',$cart->id)->sum('total_price');
					$cartQtySum                 = CartItem::where('cart_id',$cart->id)->sum('quantity');
					$cartDicSum                 = CartItem::where('cart_id',$cart->id)->sum('discount');
					$cart->quantity_total 	  	= $cartQtySum;
					$cart->raw_total 	  		= $cartSum;
					$cart->discount_total 		= $cartDicSum;
					$cart->grand_total    		= $cartSum-$cartDicSum;					
					$cart->save();
					return Response::json(array('success'=>true,'message'=>'Procedure added to cart successfully','cart_quantity' => $cart->quantity_total));	
				
			}else{
					return Response::json(array('success'=>false,'message'=>'Procedure alredy added in cart'));
				
			}
        }
    }
    
    
    /**
     * Function to get appointment payment.
     * @return response
    */
	public function appontmentPayment($id) {
		$report = HairTransplantReport::with(['user','applied_offer'])->find($id); 
				
	    $costPerGraft 	 =  $report->cost_per_graft; 
	    $fue_graft_rate  =  env('FUE_GRAFT_RATE');		    
	    $rob_graft_rate  =  env('ROBOTIC_GRAFT_RATE');		
	    $dhi_graft_rate  =  env('DHI_GRAFT_RATE');	
	    $bio_graft_rate  =  env('BIO_GRAFT_RATE');	
	    $gst_reate		 =  env('GST_RATE');    
	    $totalGraft	     =  $report->total_graft;
	    
	    $payment['totalcost'] 		=  $totalGraft * $costPerGraft;
	    $payment['discount'] 	 	=  $report->applied_offer->discount;
		$payment['fue_totalcost'] 	=  $totalGraft * $fue_graft_rate;
		$payment['rob_totalcost'] 	=  $totalGraft * $rob_graft_rate;
		$payment['dhi_totalcost'] 	=  $totalGraft * $dhi_graft_rate;
		$payment['bio_totalcost'] 	=  $totalGraft * $bio_graft_rate;
	    
		if($report->applied_offer->discount_type == 'g') {
			$payment['discount_type'] 		=  'Grafts in Offer';			
			$payment['totaldiscount']		=  $payment['discount']  * $costPerGraft;
			
			$payment['fue_totaldiscount'] 	=  $payment['discount']  * $fue_graft_rate;
			$payment['rob_totaldiscount'] 	=  $payment['discount']  * $rob_graft_rate;
			$payment['dhi_totaldiscount'] 	=  $payment['discount']  * $dhi_graft_rate;
			$payment['bio_totaldiscount'] 	=  $payment['discount']  * $bio_graft_rate;
			
		} else if($report->applied_offer->discount_type == 'p') {
			$payment['discount_type'] 		=  'Discount Offer in (%)'; 
			$payment['totaldiscount']		=  ($payment['totalcost']*$payment['discount'])/100;
			
			$payment['fue_totaldiscount'] 	=  ($payment['fue_totalcost']*$payment['discount'])/100;
			$payment['rob_totaldiscount'] 	=  ($payment['rob_totalcost']*$payment['discount'])/100;
			$payment['dhi_totaldiscount'] 	=  ($payment['dhi_totalcost']*$payment['discount'])/100;
			$payment['bio_totaldiscount'] 	=  ($payment['bio_totalcost']*$payment['discount'])/100;
			
			
		} else {
			$payment['discount_type'] 		=  'Discount Flat Off in Offer';
			$payment['totaldiscount']		=  $payment['discount'];
			
			$payment['fue_totaldiscount'] 	=  $payment['discount'];
			$payment['rob_totaldiscount'] 	=  $payment['discount'];
			$payment['dhi_totaldiscount'] 	=  $payment['discount'];
			$payment['bio_totaldiscount'] 	=  $payment['discount'];
		}
		
		$payment['balance']		   	    =  $payment['totalcost'] - $payment['totaldiscount'];
		$payment['requiredGrafts']	    =  $totalGraft;
		$payment['costPerGraft']	    =  $costPerGraft;
	
		//fue					
		$payment['fue_balance']			=  $payment['fue_totalcost'] - $payment['fue_totaldiscount'];
		$payment['fue_costPerGraft']	=  $fue_graft_rate;
		$payment['fue_type']			=  "FUE";
		
		//robotic			
		$payment['rob_totalcost'] 		=  $totalGraft * $rob_graft_rate;
		$payment['rob_balance']		    =  $payment['rob_totalcost'] - $payment['rob_totaldiscount'];
		$payment['rob_costPerGraft']	=  $rob_graft_rate;
		$payment['rob_type']			=  "ROBOTICS";
		
		//dhi					
		$payment['dhi_totalcost'] 		=  $totalGraft * $dhi_graft_rate;
		$payment['dhi_balance']		    =  $payment['dhi_totalcost'] - $payment['dhi_totaldiscount'];
		$payment['dhi_costPerGraft']	=  $dhi_graft_rate;
		$payment['dhi_type']			=  "DHI";
		
		//bio						
		$payment['bio_totalcost'] 		=  $totalGraft * $bio_graft_rate;
		$payment['bio_balance']		    =  $payment['bio_totalcost'] - $payment['bio_totaldiscount'];
		$payment['bio_costPerGraft']	=  $bio_graft_rate;
		$payment['bio_type']			=  "BIO-FUE";
		
		$transplant_type = ($report->transplant_type == '') ? 'fue_' : $report->transplant_type.'_';
	    
	    $finalPayment['procedure_cost'] =  $payment[$transplant_type.'totalcost'];		
	    $finalPayment['totaldiscount'] 	=  $payment[$transplant_type.'totaldiscount'] ;
	    $finalPayment['totalcost'] 		=  floor(($finalPayment['procedure_cost'] -  $finalPayment['totaldiscount']) + (($finalPayment['procedure_cost'] -  $finalPayment['totaldiscount']) * $gst_reate)/100) ;
	   
	    $finalPayment['gst_price']		=  floor((($finalPayment['procedure_cost'] - $finalPayment['totaldiscount']) * $gst_reate)/100);	    
	    $finalPayment['costPerGraft']	=  $payment[$transplant_type.'costPerGraft'];
	    $finalPayment['balance']		=  $finalPayment['totalcost'];
	    $finalPayment['type']			=  $payment[$transplant_type.'type'];
	    
		return $finalPayment;
	}	
    
    
    /**
     * Function to add to cart.
     * @return response
    */
	public function addToWishlist(Request $request)
    {
        $data 		= $request->all();
        $product_id = $data['product_id'];
        $user_id 	= Auth::user()->id;
    	$product 	= Product::find($product_id);
        if(!$product) {
            return Response::json(array('success'=>false,'message'=>'Product not found'));
        }
        $Wishlist = Wishlist::where('product_id',$product_id)->where('user_id',$user_id)->get();
        if(!$Wishlist->count()){
            $Wishlist = new Wishlist;
            $Wishlist->product_id = $product_id;
            $Wishlist->user_id = $user_id;
            $Wishlist->save();
            return Response::json(array('success'=>true,'message'=>'Product added to Wishlist successfully'));
        }else{
			return Response::json(array('success'=>true,'message'=>'Product is already in your Wishlist'));
            
        }
    }

	/**
     * Function to get cart added products.
     * @return cart products
    */
    public function getCart()
    {
		$cartTotal    = 0;
		$cart_items   = array();
        $cart		  = Cart::where('user_id',Auth::user()->id)->first();
       
        if($cart){
			 $cartTotal    = $cart->grand_total;
			 $cart_items['product']   = CartItem::where('cart_id',$cart->id)->where('is_type','product')->with('productDetail')->get()->toArray();
			 $cart_items['procedure'] = CartItem::where('cart_id',$cart->id)->where('is_type','procedure')->with('procedureDetail')->get()->toArray();		
			 $cart_items['package']   = CartItem::where('cart_id',$cart->id)->where('is_type','package')->with('offerDetail')->get()->toArray();
			 $cart_items['product_gst'] =   CartItem::where('cart_id',$cart->id)->where('is_type','product')->sum('gst_price');				 
		}
        
    	return view('shop.cart',compact(['cart_items','cartTotal','url']));
    }
    
    /**
     * Function to update cart products.
     * @return response
    */
	public function updateCart(Request $request)
	{
		if($request->id and $request->quantity)
		{
            $CartItem 				= CartItem::find($request->id);
            $product				= Product::find($CartItem->product_id);
            $CartItem->quantity 	= $request->quantity;
            $CartItem->gst_price	= floor((($product->product_price*$request->quantity) * $this->GST)/100);
            $CartItem->total_price 	= $product->product_price*$request->quantity;
            $CartItem->save();
            $cart 						= Cart::where('user_id',Auth::user()->id)->first();
			$cartSome                   = CartItem::where('cart_id',$cart->id)->sum('total_price');
			$cartQtySum                 = CartItem::where('cart_id',$cart->id)->sum('quantity');
			$cartDicSum                 = CartItem::where('cart_id',$cart->id)->sum('discount');
			$cart->quantity_total 	  	= $cartQtySum;
			$cart->raw_total 	  		= $cartSome;
			$cart->discount_total 		= $cartDicSum;
			$cart->grand_total    		= $cartSome-$cartDicSum;
			$cart->save();

			session()->flash('success', 'Cart updated successfully');
		}
	}

	/**
     * Function to remove Item from cart.
     * @return response
    */
	public function emptyCart(Request $request)
	{

		if($request->id) {
			$cart 		= Cart::where('user_id',Auth::user()->id)->first();
			if($cart){
				
				$Item = CartItem::find($request->id);
				if($request->type == 'procedure') {
					HairTransplantReport::find($Item->product_id)->delete();
				}
				$Item->delete();
				$cartSome                   = CartItem::where('cart_id',$cart->id)->sum('total_price');
				$cartQtySum                 = CartItem::where('cart_id',$cart->id)->sum('quantity');
				$cartDicSum                 = CartItem::where('cart_id',$cart->id)->sum('discount');
				$cart->quantity_total 	  	= $cartQtySum;
				$cart->raw_total 	  		= $cartSome;
				$cart->discount_total 		= $cartDicSum;
				$cart->grand_total    		= $cartSome-$cartDicSum;
				$cart->save();
				$cartItem 	= CartItem::where('cart_id',$cart->id)->first();
				if(!$cartItem){
					Cart::where('user_id',Auth::user()->id)->delete();
				}
			}
            
            session()->flash('success', 'Product removed successfully');
		}
	}

	/**
     * Function to add cart Items to checkout.
     * @return View
    */
    public function CheckOut()
    {
        $cart_contents 		   = Cart::where('user_id',Auth::user()->id)->first();
        
        if( $cart_contents !== NULL) {
			//$cartItems 	       = CartItem::where('cart_id',$cart_contents->id)->with('productDetail')->get();
			$cartItems['product']  = CartItem::where('cart_id',$cart_contents->id)->where('is_type','product')->with('productDetail')->get()->toArray();
			$cartItems['procedure'] = CartItem::where('cart_id',$cart_contents->id)->where('is_type','procedure')->with('procedureDetail')->get()->toArray();	
			$cartItems['package']   = CartItem::where('cart_id',$cart_contents->id)->where('is_type','package')->with('offerDetail')->get()->toArray();	
			$cartItems['product_gst'] =  CartItem::where('cart_id',$cart_contents->id)->where('is_type','product')->sum('gst_price');	
			$Countries   = Countries::all();
			$states   	 = States::where('country_id',1)->get();			
			$user 		 = UserDetail::where('user_id',Auth::user()->id)->first();
				return view('shop.checkout',compact(['cart_contents','cartItems','Countries','user','states']));
			}else{
				return redirect('/');
			}
    }
    
    /**
     * Function to Proceed to payment.
     * @return Response
    */
    public function checkoutProceed(Request $request)
    {
		$cart_contents     = Cart::where('user_id',Auth::user()->id)->first();   
		$product_gst	   = CartItem::where('cart_id',$cart_contents->id)->where('is_type','product')->sum('gst_price');  
        
        $TempOrder 		   = TempOrder::where('user_id',Auth::user()->id)->delete();
        $TempOrder 		   = new TempOrder;
        $TempOrder->user_id 		= Auth::user()->id;
        $TempOrder->cart_id 		= $cart_contents->id;
        $TempOrder->address 		= $request->firstName.' '.$request->lastName.','.$request->email.','.$request->address.','.$request->address2;
        $TempOrder->country 		= $request->country;
        $TempOrder->state 			= $request->state;
        $TempOrder->zip 			= $request->zip;
        $TempOrder->city 			= $request->city;
        $TempOrder->billing_address = $request->address;
        $TempOrder->billing_city 	= $request->city;
        $TempOrder->billing_state 	= $request->state;
        $TempOrder->billing_country = $request->country;
        $TempOrder->billing_zip 	= $request->zip;
        $TempOrder->payment_method 	= "";
        $TempOrder->total 			= $cart_contents->raw_total;
        $TempOrder->grand_total 	= $cart_contents->grand_total + $product_gst ;
        $TempOrder->status 			= 0;
        $TempOrder->save();
        $orderdata = ['order_id' => $TempOrder->id, 'cart_id' => $TempOrder->cart_id,'amount' =>$TempOrder->grand_total,'billing_name' => $request->firstName.' '.$request->lastName,'shipping_name' => $request->firstName.' '.$request->lastName];
        Session::put('orderdata', $orderdata);
      
		return Response::json(array('success'=>true,'message'=>'Thank you for your order'));
    }
    
    /**
     * Function to Confirm checkout.
     * @return Response
    */
    public function checkoutConfirmation(Request $request)
    {
		$cart_contents 		= Cart::where('user_id',Auth::user()->id)->first();
        //$cartItems 	    = CartItem::where('cart_id',$cart_contents->id)->with('productDetail')->get();
        $cartItems['product']   = CartItem::where('cart_id',$cart_contents->id)->where('is_type','product')->with('productDetail')->get()->toArray();
		$cartItems['procedure'] = CartItem::where('cart_id',$cart_contents->id)->where('is_type','procedure')->with('procedureDetail')->get()->toArray();	
		$cartItems['package']   = CartItem::where('cart_id',$cart_contents->id)->where('is_type','package')->with('offerDetail')->get()->toArray();		
		$cartItems['product_gst'] =   CartItem::where('cart_id',$cart_contents->id)->where('is_type','product')->sum('gst_price');	
		$order 		   =  Session::get('orderdata');
		return view('shop.confirmation',compact(['order','cart_contents','cartItems']));
    }
    
    /**
     * Function to checkout payment.
     * @return Response
    */
    public function checkoutPayment(Request $request)
    {
		/* All Required Parameters by your Gateway */
		$order 		=  Session::get('orderdata');
		$TempOrder 	= TempOrder::where('id',$order['order_id'])->first();
		if($TempOrder){
			$parameters = [
				'merchant_id' 	=> Config::get('indipay.ccavenue.merchantId'),
				'currency' 		=> Config::get('indipay.ccavenue.currency'),
				'redirect_url' 	=> Config::get('indipay.ccavenue.redirectUrl'),
				'cancel_url' 	=> Config::get('indipay.ccavenue.cancelUrl'),
				'tid' 			=> $order['order_id'],
				'language' 		=> Config::get('indipay.ccavenue.language'),
				'order_id' 		=> $order['order_id'],
				'amount' 		=> $order['amount'],
				'billing_name' 		=> $order['billing_name'],
				'billing_address' 	=> $TempOrder->billing_address,
				'billing_city' 		=> $TempOrder->billing_city,
				'billing_state' 	=> $TempOrder->billing_state,
				'billing_zip' 		=> $TempOrder->billing_zip,
				'billing_country' 	=> $TempOrder->billing_country,
				'delivery_name' 	=> $order['shipping_name'],
				'delivery_address' 	=> $TempOrder->address,
				'delivery_city' 	=> $TempOrder->city,
				'delivery_state' 	=> $TempOrder->state,
				'delivery_zip' 		=> $TempOrder->zip,
				'delivery_country' 	=> $TempOrder->country,
				'delivery_tel' 		=> '9876654556'
			  ];
			$order = Indipay::gateway('CCAvenue')->prepare($parameters);
			return Indipay::process($order);
		}
		
    }
    
    /**
     * Function to check payment response.
     * @return Response
    */
    public function checkoutResponse(Request $request)
    {
		$orderdata 		= Session::get('orderdata');
		$encResponse 	= $request->encResp;
        $rcvdString 	= $this->decrypt($encResponse,Config::get('indipay.ccavenue.workingKey'));
        parse_str($rcvdString, $decResponse);
        if($decResponse){
			$TempOrder = TempOrder::where('id',$orderdata['order_id'])->first();
			$Order 	   = new Order;
			$Order->id 				= $TempOrder->id;
			$Order->user_id 		= Auth::user()->id;
			$Order->address 		= $TempOrder->address;
			$Order->country 		= $TempOrder->country;
			$Order->state 			= $TempOrder->state;
			$Order->zip 			= $TempOrder->zip;
			$Order->city 			= $TempOrder->city;
			$Order->billing_address = $TempOrder->address;
			$Order->billing_city 	= $TempOrder->billing_city;
			$Order->billing_state 	= $TempOrder->state;
			$Order->billing_country = $TempOrder->country;
			$Order->billing_zip 	= $TempOrder->zip;
			$Order->payment_method 	= $decResponse['payment_mode'];
			$Order->total 			= $TempOrder->total;
			$Order->grand_total 	= $TempOrder->grand_total;
			$Order->status 			= 0;
			$Order->payment_status 	= $decResponse['order_status'];
			$Order->response_code 	= $decResponse['response_code'];
			$Order->save();
			$TempOrderDetails 	    = CartItem::where('cart_id',$orderdata['cart_id'])->get();
			
			if($TempOrderDetails){
				foreach ($TempOrderDetails as $key => $value) {
					if($value->is_type == "product") {
						$OrderDetail 				   = new OrderDetail;
						$OrderDetail->order_id 		   = $Order->id;
						$OrderDetail->user_id 		   = $Order->user_id;
						$OrderDetail->product_id 	   = $value->product_id;
						$OrderDetail->product_price    = $value->product_price;
						$OrderDetail->product_quantity = $value->quantity;
						$OrderDetail->gst_price 	   = $value->gst_price;
						$OrderDetail->save();
					} else if($value->is_type == "procedure") { //procedure with offer
						$Report = HairTransplantReport::with(['user','applied_offer'])->find($value->report_id); 
						if($Report !== null) {
							 $Report->appointment_status = 1;
							 $Report->save();
						   }
						$Procedure 				  	   = new Procedure;
						
						$totalCoast		   	           = $Report->total_payment;
						$finalcost		   	           = $value->total_price;	
														 
						$balance		               = $totalCoast - $finalcost - $value->option_discount;	
						
						$Procedure->order_id 		   = $Order->id;
						$Procedure->user_id 		   = $Order->user_id;
						$Procedure->report_id 	  	   = $value->report_id;
						$Procedure->service     	   = $Report->applied_offer->services;
						$Procedure->type     	  	   = 'offer';
						$Procedure->offer_apply        = $Report->offer_apply;
						$Procedure->offer_name         = $Report->applied_offer->offer_name_en;
						$Procedure->discount           = $Report->discount;
						$Procedure->option_discount    = $value->option_discount;
						$Procedure->total_payment      = $totalCoast;
						$Procedure->gst_price     	   = $value->gst_price;
						$Procedure->advanced_payment   = $finalcost;
						$Procedure->pending_payment    = $balance;
						$Procedure->required_grafts    = $Report->total_graft;
						$Procedure->payment_option     = $value->payment_option;
						$Procedure->note         	   = $value->note;
						$Procedure->preportid          = $value->report_id;
						$Procedure->save();
						
						$OrderDetail 				   = new OrderDetail;
						$OrderDetail->order_id 		   = $Order->id;
						$OrderDetail->user_id 		   = $Order->user_id;
						$OrderDetail->product_id 	   = $Procedure->id;
						$OrderDetail->product_price    = $totalCoast;
						$OrderDetail->product_quantity = 1;
						$OrderDetail->product_type     = 'procedure';
						$OrderDetail->save();
						
						$PaymentType 				= new PaymentType;
						$PaymentType->user_id  	    = $Order->user_id;
						$PaymentType->procedure_id  = $Procedure->id;
						$PaymentType->amount 		= $finalcost;
						$PaymentType->payment_type  = 'online';
						$PaymentType->save();
						
					} else { //package
						$offer  = Offer::find($value->product_id);
						$Option = ProcedureOption::find($value->payment_option);
						$Report = HairTransplantReport::with(['user','applied_offer'])->find($value->report_id); 
						if($Report !== null) {
							 $Report->appointment_status = 1;
							 $Report->save();
						}
						
						$packagePrice		         = $offer->package_price+$value->gst_price;
						$totaldiscount		         = $value->offer_discount;		
						$totalCoast		   	         = $packagePrice - $totaldiscount;
						$finalcost		   	         = $value->total_price;											 
						$balance		             = $totalCoast - $finalcost - $value->option_discount;	
							 
						$Procedure 				  	 = new Procedure;
						$Procedure->order_id 		 = $Order->id;
						$Procedure->user_id 		 = $Order->user_id;
						$Procedure->report_id 	  	 = $value->report_id;
						$Procedure->service     	 = $offer->services;
						$Procedure->type     	  	 = 'package';
						$Procedure->offer_apply      = $value->product_id;
						$Procedure->offer_name       = $offer->offer_name_en;
						$Procedure->discount         = $offer->discount;
						$Procedure->option_discount  = $value->option_discount;
						$Procedure->total_payment    = $totalCoast;
						$Procedure->gst_price     	 = $value->gst_price;
						$Procedure->advanced_payment = $value->total_price;
						$Procedure->pending_payment  = $balance;
						$Procedure->required_grafts  = $offer->offer_grafts;
						$Procedure->payment_option   = $value->payment_option;
						$Procedure->note         	 = $value->note;
						$Procedure->preportid        = $value->report_id;
						$Procedure->save();
						
						$OrderDetail 				   = new OrderDetail;
						$OrderDetail->order_id 		   = $Order->id;
						$OrderDetail->user_id 		   = $Order->user_id;
						$OrderDetail->product_id 	   = $Procedure->id;
						$OrderDetail->product_price    = $totalCoast;
						$OrderDetail->product_quantity = 1;
						
						
						$OrderDetail->product_type     = 'procedure';
						$OrderDetail->save();
						
						$PaymentType 				= new PaymentType;
						$PaymentType->user_id  	    = $Order->user_id;
						$PaymentType->procedure_id  = $Procedure->id;
						$PaymentType->amount 		= $value->total_price;
						$PaymentType->payment_type  = 'online';
						$PaymentType->save();
					}				
				}
			}
			
		
			//$email = Auth::user()->email;
			$email     = env('KABERA_ADMIN_EMAIL'); //user admin email to testing
			$TempOrder = TempOrder::where('id',$orderdata['order_id'])->delete();
			if($decResponse['order_status'] == "Success"){
				$message = "Thank You! Your order has been successfully Completed.";
			}else{
				$message = "Thank You! Your order has been declined due to payment issue. Please contact to admin support.";
			}
			$data = array('order_id' => $Order->id,'message' => $message);
			Mail::send('emails.orderconfirmation', $data, function($messaged)use($email){
			  $messaged->from(env('KABERA_SUPPORT_EMAIL'));
			  $messaged->to($email);
			  $messaged->subject('Order Confirmation');
			});
		}
		$cart_contents = Cart::where('user_id',Auth::user()->id)->first();
		Cart::where('user_id',Auth::user()->id)->delete();
		CartItem::where('cart_id',$cart_contents->id)->delete();
		return redirect()->route('checkoutSuccess', ['id' => $Order->id,'amount' => $Order->grand_total]);
	  
	}
	
	/**
     * Function to return checkout success page.
     * @return Response
    */
	public function checkoutSuccess($id,$amount){
		return view('shop.success',compact(['id','amount']));
	}
	
	/**
     * Function to return checkout cancel page.
     * @return Response
    */
	public function checkoutCancel(Request $request)
    {
		return redirect()->route('Checkout');
	}
	
	/**
     * CCAvenue Decrypt Function
     *
     * @param $encryptedText
     * @param $key
     * @return string
     */
    protected function decrypt($encryptedText,$key)
    {
        $secretKey = $this->hextobin(md5($key));
        $initVector = pack("C*", 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f);
        $encryptedText=$this->hextobin($encryptedText);
        $openMode = @mcrypt_module_open(MCRYPT_RIJNDAEL_128, '','cbc', '');
        @mcrypt_generic_init($openMode, $secretKey, $initVector);
        $decryptedText = @mdecrypt_generic($openMode, $encryptedText);
        $decryptedText = rtrim($decryptedText, "\0");
        @mcrypt_generic_deinit($openMode);
        return $decryptedText;

    }
    
    /**
     * @param $hexString
     * @return string
     */
    protected function hextobin($hexString)
    {
        $length = strlen($hexString);
        $binString="";
        $count=0;
        while($count<$length)
        {
            $subString =substr($hexString,$count,2);
            $packedString = pack("H*",$subString);
            if ($count==0)
            {
                $binString=$packedString;
            }

            else
            {
                $binString.=$packedString;
            }

            $count+=2;
        }
        return $binString;
    }
    
    /*
     * 
     * Ipg Icici Payment Gatway Integuration
     * 
     * 
     * */
    
    public function checkoutIciciPayment(){
		$responseSuccessURL 	 = Config::get('icicipay.icici.redirectUrl');
		$responseFailURL	 	 = Config::get('icicipay.icici.cancelUrl');
		$storeId         		 = Config::get('icicipay.icici.storeid');
		$sharedSecret            = Config::get('icicipay.icici.sharedsecret');
		$currency            	 = Config::get('icicipay.icici.currency');
		$order 					 = Session::get('orderdata');
		$UserEmail       		 = Auth::user()->email;
		$userId          		 = Config::get('icicipay.icici.userid');
		$parameters = ['responseSuccessURL' => $responseSuccessURL,'responseFailURL' => $responseFailURL,'storeId' => $storeId,'userId' => $userId,'UserEmail' => $UserEmail,'extra_param' => '1','amount' => $order['amount'],'sharedSecret' => $sharedSecret,'currency' => $currency];
		return IcicipaymentServiceProvider::process($parameters);
	}
	
	
	 /**
     * Function to check payment icici response.
     * @return Response
    */
    public function checkoutIciciResponse(Request $request)
    {
		$response 		= $request->input();
		$orderdata 		= Session::get('orderdata');
        if($response){
			$TempOrder = TempOrder::where('id',$orderdata['order_id'])->first();
			$Order 	   = new Order;
			$Order->id 				= $TempOrder->id;
			$Order->user_id 		= Auth::user()->id;
			$Order->address 		= $TempOrder->address;
			$Order->country 		= $TempOrder->country;
			$Order->state 			= $TempOrder->state;
			$Order->zip 			= $TempOrder->zip;
			$Order->city 			= $TempOrder->city;
			$Order->billing_address = $TempOrder->address;
			$Order->billing_city 	= $TempOrder->billing_city;
			$Order->billing_state 	= $TempOrder->state;
			$Order->billing_country = $TempOrder->country;
			$Order->billing_zip 	= $TempOrder->zip;
			$Order->payment_method 	= $response['paymentMethod'];
			$Order->total 			= $TempOrder->total;
			$Order->grand_total 	= $TempOrder->grand_total;
			$Order->status 			= 0;
			$Order->payment_status 	= $response['status'];
			$Order->response_code 	= $response['ccbin'];
			$Order->save();
			$TempOrderDetails 	    = CartItem::where('cart_id',$orderdata['cart_id'])->get();
			
			if($TempOrderDetails){
				foreach ($TempOrderDetails as $key => $value) {
					if($value->is_type == "product") {
						$OrderDetail 				   = new OrderDetail;
						$OrderDetail->order_id 		   = $Order->id;
						$OrderDetail->user_id 		   = $Order->user_id;
						$OrderDetail->product_id 	   = $value->product_id;
						$OrderDetail->product_price    = $value->product_price;
						$OrderDetail->product_quantity = $value->quantity;
						$OrderDetail->gst_price 	   = $value->gst_price;
						$OrderDetail->save();
					} else if($value->is_type == "procedure") { //procedure with offer
						$Report = HairTransplantReport::with(['user','applied_offer'])->find($value->product_id); 
						$Procedure 				  	   = new Procedure;
						$totalCoast		   	           = $Report->total_payment;
						$finalcost		   	           = $value->total_price;						 
						$balance		               = $totalCoast - $finalcost - $value->option_discount;
						$Procedure->order_id 		   = $Order->id;
						$Procedure->user_id 		   = $Order->user_id;
						$Procedure->report_id 	  	   = $value->report_id;
						$Procedure->service     	   = ($Report->applied_offer ? $Report->applied_offer->services:"");
						$Procedure->type     	  	   = 'offer';
						$Procedure->offer_apply        = $Report->offer_apply;
						$Procedure->offer_name         = $Report->applied_offer->offer_name_en;
						$Procedure->discount           = $Report->discount;
						$Procedure->option_discount    = $value->option_discount;
						$Procedure->total_payment      = $totalCoast;
						$Procedure->gst_price     	   = $value->gst_price;
						$Procedure->advanced_payment   = $finalcost;
						$Procedure->pending_payment    = $balance;
						$Procedure->required_grafts    = $Report->total_graft;
						$Procedure->payment_option     = $value->payment_option;
						$Procedure->note         	   = $value->note;
						$Procedure->preportid          = $value->report_id;
						$Procedure->save();
						
						$OrderDetail 				   = new OrderDetail;
						$OrderDetail->order_id 		   = $Order->id;
						$OrderDetail->user_id 		   = $Order->user_id;
						$OrderDetail->product_id 	   = $Procedure->id;
						$OrderDetail->product_price    = $totalCoast;
						$OrderDetail->product_quantity = 1;
						$OrderDetail->product_type     = 'procedure';
						$OrderDetail->save();
						
						$PaymentType 				= new PaymentType;
						$PaymentType->user_id  	    = $Order->user_id;
						$PaymentType->procedure_id  = $Procedure->id;
						$PaymentType->amount 		= $finalcost;
						$PaymentType->payment_type  = 'online';
						$PaymentType->save();
						
					} else { //package
						$offer  = Offer::find($value->product_id);
						$Option = ProcedureOption::find($value->payment_option);
						
						$packagePrice		         = $offer->package_price+$value->gst_price;
						$totaldiscount		         = $value->offer_discount;		
						$totalCoast		   	         = $packagePrice - $totaldiscount;
						$finalcost		   	         = $value->total_price;											 
						$balance		             = $totalCoast - $finalcost - $value->option_discount;	
							 
						$Procedure 				  	 = new Procedure;
						$Procedure->order_id 		 = $Order->id;
						$Procedure->user_id 		 = $Order->user_id;
						$Procedure->report_id 	  	 = $value->report_id;
						$Procedure->service     	 = $offer->services;
						$Procedure->type     	  	 = 'package';
						$Procedure->offer_apply      = $value->product_id;
						$Procedure->offer_name       = $offer->offer_name_en;
						$Procedure->discount         = $offer->discount;
						$Procedure->option_discount  = $value->option_discount;
						$Procedure->total_payment    = $totalCoast;
						$Procedure->gst_price     	 = $value->gst_price;
						$Procedure->advanced_payment = $value->total_price;
						$Procedure->pending_payment  = $balance;
						$Procedure->required_grafts  = $offer->offer_grafts;
						$Procedure->payment_option   = $value->payment_option;
						$Procedure->note         	 = $value->note;
						$Procedure->preportid        = $value->report_id;
						$Procedure->save();
						
						$OrderDetail 				   = new OrderDetail;
						$OrderDetail->order_id 		   = $Order->id;
						$OrderDetail->user_id 		   = $Order->user_id;
						$OrderDetail->product_id 	   = $Procedure->id;
						$OrderDetail->product_price    = $totalCoast;
						$OrderDetail->product_quantity = 1;
						
						
						$OrderDetail->product_type     = 'procedure';
						$OrderDetail->save();
						
						$PaymentType 				= new PaymentType;
						$PaymentType->user_id  	    = $Order->user_id;
						$PaymentType->procedure_id  = $Procedure->id;
						$PaymentType->amount 		= $value->total_price;
						$PaymentType->payment_type  = 'online';
						$PaymentType->save();
					}				
				}
			}
			//$email = Auth::user()->email;
			$email     = env('KABERA_ADMIN_EMAIL'); //user admin email to testing
			$TempOrder = TempOrder::where('id',$orderdata['order_id'])->delete();
			if($response['status'] == "APPROVED"){
				$message = "Thank You! Your order has been successfully Completed.";
			}else{
				$message = "Thank You! Your order has been declined due to payment issue. Please contact to admin support.";
			}
			$data = array('order_id' => $Order->id,'message' => $message);
			Mail::send('emails.orderconfirmation', $data, function($messaged)use($email){
			  $messaged->from(env('KABERA_SUPPORT_EMAIL'));
			  $messaged->to($email);
			  $messaged->subject('Order Confirmation');
			});
		}
		$cart_contents = Cart::where('user_id',Auth::user()->id)->first();
		Cart::where('user_id',Auth::user()->id)->delete();
		CartItem::where('cart_id',$cart_contents->id)->delete();
		return redirect()->route('checkoutSuccess', ['id' => $Order->id,'amount' => $Order->grand_total]);
	}
	
	/**
     * Function to return checkout icici cancel page.
     * @return Response
    */
	public function checkoutIciciCancel(Request $request)
    {
		return redirect()->route('Checkout')->with('message',$request->input('fail_reason'));
	}
}
