<?php
namespace App\Http\Controllers;
use Auth;
use DB;
use Session;
use App\ProcedureReview;
use App\UserDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Response;

class ReviewController extends Controller
{
	/*
     * Function to get Review.
     * @return view
    */
	public function reviewContent()
	{
		$reviews    = ProcedureReview::where('review_status','=','1')->paginate(5);
		$count      = ProcedureReview::where('review_status','=','1')->count();
		$avrage     = ProcedureReview::where('review_status','1')->avg('rating');
		$percentage = 0;
		if($count){
			$percentage 	   =  array();
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}
		return view('review',compact(['reviews', 'count', 'avrage', 'percentage']));
	}
	
	/*
     * Function to save review & rating after one year.
     * @return view
    */
	public function savereview(Request $request)
	{
		$validatedData = $request->validate([
				'message' => 'required',
				'rate'	=> 'required', 
			]);
		$user_id = $request->input('userid');
		$user_name = $request->input('username');
		$user_email = $request->input('useremail');
		$user_img = $request->input('userimage');
		$subservice = $request->input('subservice');
		$review = $request->input('message');
		$ratings = $request->input('rate');
		$procedure_id = $request->input('procedure_id');
		
		
		$images = array();
		 if($request->hasfile('review_images')) 
			{
				$allowedfileExtension=['jpg','png','jpeg','gif'];
				
				$size = [];
				foreach($request->file('review_images') as $image)
				{	
					$folder           = 'reviews/';
					$random_number 	  = mt_rand(100000, 999999);
					$img_name = str_replace(' ', '', $image->getClientOriginalName());
					
					$name = $random_number.$img_name; 
				    $extension = $image->getClientOriginalExtension();
				    $extension = strtolower($extension);
				   
					$size[] = $image->getSize();  
					
					$check = in_array($extension , $allowedfileExtension); 
					  if($check)
					  {
						$image_size = 2000000;
						$total_size = array_sum($size);
						if($total_size > $image_size)
						{
						return redirect('/user/view/procedure/'.$procedure_id.'/review')->with('error', 'Images size must be less than 2 mb');	
						}
						else
						{
					  	$image->move(public_path().'/images/reviews/', $name);                  
					  	array_push($images , $folder.$name);
						}
					  }
					  else
					  {
						  
						return redirect('/user/view/procedure/'.$procedure_id.'/review')->with('error', 'Sorry Only Upload png , jpg , gif images');  
					  }
					}
				
			}
			
			
			$ProcedureReview = new ProcedureReview;
			$ProcedureReview->service_id = $subservice;
			$ProcedureReview->user_id = $user_id;
			$ProcedureReview->rating = $ratings;
			$ProcedureReview->review = $review;
			$ProcedureReview->review_image	 = $user_img;
			$ProcedureReview->reviewer_name = $user_name;
			$ProcedureReview->reviewer_email = $user_email;
			$ProcedureReview->review_status = '0';
			$ProcedureReview->one_year_images = implode(",",$images);
			$ProcedureReview->procedure_id = $procedure_id;
			$ProcedureReview->save();
			
			return redirect('/user/view/procedure/'.$procedure_id.'/review')->with('success', 'Review successfully submitted !!');
			
	}
	
	/*
     * Function to view review content.
     * @return view
    */
	public function viewreview()
	{
		$userId = Auth::id();
		$userdata = UserDetail::where('user_id',$userId)->first();
		$userimage = $userdata->profile_picture;
		return view('user/reviews',compact('userimage'));
	}
	
	
	
	
	
}
