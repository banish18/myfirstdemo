<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use App\User;
use App\Service;
use App\SubService;
use App\BeforeAfterImage;
use App\BeforeAfterReview;
use App\ProcedureReview;
use Image;
use Auth;

class ReviewsController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
     
    public function __construct() {
		 
		$this->middleware(['auth']);
	}
	
	/*
	 * Before After Images
	 * @return View
	*/	
	public function beforeAfterImages(){
		$images   = BeforeAfterImage::all();
		$services =  SubService::all();
		return View('admin.pages.beforeafterimages',compact(['images', 'services']));
	} 
	
	
	/**
	  * Save Before After Images
	  * return Response  
    */	 
	public function saveBeforeAfter(Request $request) {
				 
		$folder        = 'pages/';
		$beforeImage   = $request->file("before_image");
		$random_number = mt_rand(100000, 999999);
		$beforeimgname = $random_number.$beforeImage->getClientOriginalName(); 
		$beforeImage->move(public_path().'/images/pages/', $beforeimgname); 
		$before_image  = $folder.$beforeimgname;	
		
		$afterImage   = $request->file("after_image");
		$random_number= mt_rand(100000, 999999);
		$afterimgname = $random_number.$afterImage->getClientOriginalName(); 
		$afterImage->move(public_path().'/images/pages/', $afterimgname); 
		$after_image  = $folder.$afterimgname;	
				
		$Images 			  =  new BeforeAfterImage;
		$Images->service_id	  =  $request->input('service');
		$Images->before_image =  $before_image;
		$Images->after_image  =  $after_image;
		$Images->save();
		
		return Response::json(array('success'=>true,'message'=>'Images Added Successfully'));		 
	 }
	 	 
	 /**
	  * Delete Before After Images
	  * @return Response
	 */
	public function deleteBeforeAfter(Request $request) {
		
		$Images    = BeforeAfterImage::find($request->input('id'));	
		
		if(file_exists(public_path('/images/'.$Images->before_image ))){ //delete image if exist
			unlink(public_path('/images/'.$Images->before_image));
		}
		if(file_exists(public_path('/images/'.$Images->after_image ))){ //delete image if exist
			unlink(public_path('/images/'.$Images->after_image));
		}		
		$Images->delete();
		return Response::json(array('success'=>true,'message'=>'Images Deleted Successfully'));
	 } 
	 
	 
	 /**
	  * Update Before After Images	 
	  * return Response  
	 */	 
	public function updateBeforeAfter(Request $request) {
		 
		$id			   = $request->input('id');		
		$Images 	   = BeforeAfterImage::find($id);	
		
		$folder        = 'pages/';		
		if($request->hasfile('before_image')) {  
			if(file_exists(public_path('/images/'.$Images->before_image ))){ //delete image if exist
				unlink(public_path('/images/'.$Images->before_image));
			}
		
			$beforeImage   = $request->file("before_image");
			$random_number = mt_rand(100000, 999999);
			$beforeimgname = $random_number.$beforeImage->getClientOriginalName(); 
			$beforeImage->move(public_path().'/images/pages/', $beforeimgname); 
			$before_image  = $folder.$beforeimgname;	
			$Images->before_image =  $before_image;
		}
		
		if($request->hasfile('after_image')) { 
			
			if(file_exists(public_path('/images/'.$Images->after_image ))){ //delete image if exist
				unlink(public_path('/images/'.$Images->after_image));
			}
		
			$afterImage    = $request->file("after_image");
			$random_number = mt_rand(100000, 999999);
			$afterimgname  = $random_number.$afterImage->getClientOriginalName(); 
			$afterImage->move(public_path().'/images/pages/', $afterimgname); 
			$after_image   = $folder.$afterimgname;
			$Images->after_image  =  $after_image;	
		}
		
		$Images->service_id	  =  $request->input('service');
		
		$Images->save();
		return Response::json(array('success'=>true,'message'=>'Images Updated Successfully'));		 
	}	 
	
	/*
	 * Before After Reviews
	 * @return View
	*/	
	public function beforeAfterReviews(){
		$reviews  =  BeforeAfterReview::all();
		$services =  SubService::all();
		return View('admin.pages.beforeafterreviews',compact(['reviews', 'services']));
	} 
	
	/*
	* Save Before After Review
	* @return Response
	*/
	public function saveBeforeAfterReview(Request $request) {		
		$Reviews = new BeforeAfterReview;
		
		$Reviews->reviewer_name  = $request->input('reviewer_name');
		$Reviews->rating	     = $request->input('rate');
		$Reviews->service_id	 = $request->input('service');
		$Reviews->review_en	     = $request->input('review_en');
		$Reviews->review_fr	     = $request->input('review_fr');
				
		if($request->hasfile('user_image')) {            
            $folder           = 'reviews/';
            $userImage        = $request->file("user_image");
            $random_number 	  = mt_rand(100000, 999999);
            $userimgname      = $random_number.$userImage->getClientOriginalName();
            $userImage->move(public_path().'/images/reviews/', $userimgname); 
            $Reviews->image   = $folder.$userimgname;
        }
        $Reviews->save();
        return back()->with('success', 'Review Added Successfully');
	}
	
	/*
	* Update Before After Review
	* @return response
	*/
	public function updateBeforeAfterReview(Request $request) {
		
		$Reviews = BeforeAfterReview::find($request->input('id'));
		
		$Reviews->reviewer_name  = $request->input('reviewer_name');
		$Reviews->rating	     = $request->input('rate');
		$Reviews->service_id	 = $request->input('service');
		$Reviews->review_en	     = $request->input('review_en');
		$Reviews->review_fr	     = $request->input('review_fr');
		$Reviews->review_status  = $request->input('status');
				
		if($request->hasfile('user_image')) {   
			
			if(file_exists(public_path('/images/'.$Reviews->image ))){ //delete image if exist
				unlink(public_path('/images/'.$Reviews->image));
			}	
		         
            $folder           = 'reviews/';
            $userImage        = $request->file("user_image");
            $random_number 	  = mt_rand(100000, 999999);
            $userimgname      = $random_number.$userImage->getClientOriginalName();
            $userImage->move(public_path().'/images/reviews/', $userimgname); 
            $Reviews->image   = $folder.$userimgname;
        }
        $Reviews->save();	
        return back()->with('success', 'Review Updated Successfully');	
	}
	
	 	 
	/**
	  * Delete Before After Review
	  * @return Response
	*/
	public function deleteBeforeAfterReview(Request $request) {
		
		$Review    = BeforeAfterReview::find($request->input('id'));	
		if($Review->image) {
			if(file_exists(public_path('/images/'.$Review->image ))){ //delete image if exist
				unlink(public_path('/images/'.$Review->image));
			}	
		}	
		$Review->delete();
		return Response::json(array('success'=>true,'message'=>'Review Deleted Successfully'));
	 }
	  /*
	 * After One Year Reviews
	 * @return View
	*/	
	public function AfterOneYearReviews(){
		$reviews = ProcedureReview::with('subservice')->get();
		$services = Service::all();
		return View('admin.pages.afteroneyearreviews',compact(['reviews', 'services']));
	} 
	
	/**
	  * Delete After One Year Review
	  * @return Response
	*/
	public function deleteAfterOneYearReview(Request $request) {
		
		$Review = ProcedureReview::find($request->input('id'));	
		/*if($Review->image) {
			if(file_exists(public_path('/images/'.$Review->image ))){ //delete image if exist
				unlink(public_path('/images/'.$Review->image));
			}	
		}	*/
		$Review->delete();
		return Response::json(array('success'=>true,'message'=>'Review Deleted Successfully'));
	} 
	 
	/*
	* Update After One Year Review
	* @return response
	*/
	public function updateAfterOneYearReview(Request $request) {
		
		$Reviews = ProcedureReview::find($request->input('id'));
		
		$Reviews->reviewer_name  = $request->input('reviewer_name');
		$Reviews->rating	     = $request->input('rate');
		$Reviews->review	     = $request->input('review_en');
		$Reviews->review_status  = $request->input('status');
		$Reviews->save();	
        return back()->with('success', 'Review Updated Successfully');	
	}	 	
}


