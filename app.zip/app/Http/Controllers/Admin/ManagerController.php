<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use App\User;
use App\Role;
use App\RoleUser;
use App\Service;
use App\ManagerDetail;
use Auth;

class ManagerController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
    */
     
     public function __construct() {
		 
		  $this->middleware(['auth','verified']);
	 }
	 
    /**
     * Get Managers
     * @return users
    */  
	public function getManagers(){
		$managers = User::where('role',4)->get();
		if(!$managers->count()){
			$managers = array();
		}
		return view('admin.manager.managers',compact(['managers']));
	}
	
	/**
     * Add Manager
     * @return users
    */ 
	public function AddManager(Request $request){
		
		$validator = Validator::make($request->all(), [ 
            'email'    => 'required|email|unique:users',
            'phone'	   => 'required|min:9|unique:users', 
            'region'   => 'required', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err]);            
        }
        
		$data  = $request->all();
        $user =  User::create([
            'name'     => $data['manager_name'],
            'email'    => $data['email'],
            'phone'    => $data['phone'],
            'password' => Hash::make($data['password']),
            'api_token'=> Str::random(60),
            'role'	   => '4',
        ]);
        
        $Manager = new ManagerDetail; 
        $Manager->user_id  = $user->id;
        $Manager->type  = 'marketing manager';
        $Manager->region  = $request->input('region');
        $Manager->save();
        
        $user
       ->roles()
       ->attach(Role::where('name', 'manager')->first());
        return Response::json(array('success'=>true,'message'=>'Manager created successfully'));
    }
    
    /**
     * Edit Manager
    **/
    public function editManager($id)
    {
        $manager_id = $id;
        $user 	   = User::find($manager_id);
        $manager_details= ManagerDetail::where('user_id',$manager_id)->first();;
        return view('admin.manager.editmanager',compact(['manager_details','user']));
    }

	/**
     * Update Manager
     * @return manager
    */ 
    public function UpdateManager(Request $request){
		
		$validatedData = $request->validate([					
			'name'  => 'required|max:255',
            'email' => 'required|max:255|email',
            'phone' => 'required|max:10|min:10'
		]);

        $id     = $request->input('user_id');
        $name   = $request->input('name');
        $email  = $request->input('email');
        $phone  = $request->input('phone');
        
        $User 	= User::find($id);
        $User->name   = $name;
        $User->email  = $email;
        $User->phone  = $phone;                
        $User->save();
        return back()->with('success', 'Profile Updated successfully');
    }
    
    /**
     * Update Clinic Address
    **/
    public function updateManagerInfo(Request $request){

        $manager_id = $request->input('user_id');
        $Manager    = ManagerDetail::where('user_id',$manager_id)->first();
        
        $Manager->description        = $request->input('manager_desc');
        $Manager->address  		     = $request->input('manager_address');
        $Manager->region  		     = $request->input('region');
        $Manager->manager_permission = !empty($request->input('add_manager_access')) ? $request->input('add_manager_access') : '0';
		
        if($request->hasfile('manager_image')) {
			
            $folder = 'manager/';
            $managerImage     = $request->file("manager_image");
            $random_number 	  = mt_rand(100000, 999999);
            $managerimgname   = $random_number.$managerImage->getClientOriginalName();
            $managerImage->move(public_path().'/images/manager/', $managerimgname); 
            $Manager->profile_pic   = $folder.$managerimgname;
        }
        
        $Manager->save();

        return back()->with('success', 'Detail Updated successfully');
    }
	
    /**
     * Delete Manager
     * @return manager
    */ 
    public function DeleteManager(Request $request){		
        $id = $request->input('id');
        User::where('id',$id)->delete();
        RoleUser::where('user_id',$id)->delete();
        ManagerDetail::where('user_id',$id)->delete();
        return Response::json(array('success'=>true,'message'=>'Manager Deleted successfully'));
    }	
    
}
