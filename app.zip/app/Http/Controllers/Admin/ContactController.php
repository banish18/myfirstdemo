<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use Session;
use App\User;
use App\Setting;
use App\Contact;
use App\BecomeAPatner;
use Image;
use Auth;
use DB;


class ContactController extends Controller
{

    
    /**
     * Create a new controller instance.
     * @return void
    */
     
    public function __construct() {
		 
		$this->middleware(['auth']);
	}
	
	public function viewcontact() {
		
		$contacts = Contact::orderBy('id', 'DESC')->get();
		return View('admin.pages.contactus',compact(['contacts']));
		
	}
	
	public function viewbecomePartner() {
				$BecomeAPatner = BecomeAPatner::orderBy('id', 'DESC')->get();
		return View('admin.pages.becomeapartner',compact(['BecomeAPatner']));
	}
   
	 public function doctorrequestsetting() {
				$settings = Setting::all();
		return View('admin.pages.doctorsetting',compact(['settings']));
	}
	
	public function Updatedoctorsetting(request $request) {
		
		$request_per_day = $request->input('request_per_day');
		 DB::table('settings')->where('id', 1)->update(['request_per_day' => $request_per_day]);
		return redirect('admin/doctor-request-setting')->with('message', 'Request setting change successfully!');
		
		//return back();
        //return redirect()->route('update-doctor-setting');
		//return View('admin.pages.doctorsetting',compact(['settings']));
	}
   
   
}
