<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use App\User;
use App\Role;
use App\RoleUser;
use App\Doctors;
use App\Service;
use App\DoctorAssistant;
use App\ClinicGallery;
use Auth;


class DoctorController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
     
    public function __construct() {
		 
		$this->middleware(['auth','verified']);
	}
   
    /**
     * Get Doctors  
    **/
	public function getDoctors() {
		$doctors = User::where('role',2)->get();
		if(!$doctors->count()){
			$doctors = array();
		}
		return view('admin.doctor.doctors',compact(['doctors']));
	}
	
	/**
     * Add Doctor
    **/
	public function addDoctor(Request $request){
		$data = $request->all();
		
		$validator = Validator::make($request->all(), [ 
            'email' => 'required|email|unique:users',
            'phone'	=> 'required|min:9|unique:users', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err]);            
        }
        
         $user =  User::create([
            'name' => $data['doctor_name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'password' => Hash::make($data['password']),
            'api_token' => Str::random(60),
            'role' => isset($data['role']) ? $data['role'] : '2',
            
        ]);
        $user->roles()->attach(Role::where('name', 'doctor')->first());

        // Create doctor profile when user is created
        $Doctor = new Doctors;
        $Doctor->user_id =  $user->id;
        $Doctor->save();

        return Response::json(array('success'=>true,'message'=>'Doctor created successfully'));
    }

	/**
     * Edit Doctor
    **/
    public function editDoctor($id)
    {
        $doctor_id = $id;
        $user 	   = User::find($doctor_id);
        $doctor_details= Doctors::with(['gallery'])->where('user_id',$doctor_id)->first();
      
		$services      = Service::with('subService')->get();
		/*echo "<pre>";print_r($services);
        die;*/
        return view('admin.doctor.editDoctor',compact(['doctor_details','user', 'services']));
    }
    
    /**
     * Update Doctor
    **/
    public function UpdateDoctor(Request $request){
		 
	    $validatedData = $request->validate([					
			'name' => 'required|max:255',
            'email' => 'required|max:255|email',
            'phone' =>  'required|max:10|min:10',
             'request_recieve_per_day' =>  'required|max:2|min:1'
		]);
		
        $id     = $request->input('doctor_id');
        $name   = $request->input('name');
        $email  = $request->input('email');
        $phone  = $request->input('phone');
        $request_recieve_per_day  = $request->input('request_recieve_per_day');
        $User 		  		= User::find($id);
        $User->name   		= $name;
        $User->email  		= $email;
        $User->phone  		= $phone;
        $User->request_recieve_per_day  = $request_recieve_per_day;
		$User->isVerified 	= $request->input('isVerified');
		$User->save();
		
           
        $User->save();
        return back()->with('success','Profile updated successfully');
    }
    
    /**
     * Update Clinic Address
    **/
    public function updateDoctorInfo(Request $request){

        $doctor_id = $request->input('doctor_id');
        //Add new fields for Doctor
			$education  = !empty($request->input('education'))?implode(',',$request->input('education')):'';
			$experience  = $request->input('experience');
			$awards  = !empty($request->input('awards'))?implode(',',$request->input('awards')):'';
			$speciality  = $request->input('speciality');
        //End
        
        $Doctor    = Doctors::where('user_id',$doctor_id)->first();

        $Doctor->clinic_name      = $request->input('clinic_name');
        $Doctor->description      = $request->input('doctor_desc');
        $Doctor->clinic_address   = $request->input('clinic_address');
        $Doctor->doctor_city      = $request->input('doctor_city');
        $Doctor->doctor_state     = $request->input('doctor_state');
        $Doctor->doctor_country   = $request->input('doctor_country');
        $Doctor->doctor_zip  	  = $request->input('doctor_zipcode');
        $Doctor->open_time  	  = $request->input('open_time');
        $Doctor->close_time  	  = $request->input('close_time');
        $Doctor->latitude  		  = $request->input('doctor_latitude');
        $Doctor->longitude 		  = $request->input('doctor_longitude');
        
        //Assigning values to new fields
			$Doctor->education   = $education;
			$Doctor->experience   = $experience;
			$Doctor->awards   = $awards;
			$Doctor->speciality   = $speciality;
		//End
		
		
        if($request->input('services'))
			$Doctor->skills 	  = json_encode($request->input('services'));
        
        if($request->input('sub_services'))
			$Doctor->sub_skills   = json_encode($request->input('sub_services'));
        
        if($request->hasfile('doctor_image')) {
            
            $folder           = 'doctor/';
            $doctorImage      = $request->file("doctor_image");
            $random_number 	  = mt_rand(100000, 999999);
            $doctorimgname    = $random_number.$doctorImage->getClientOriginalName();
            $doctorImage->move(public_path().'/images/doctor/', $doctorimgname); 
            $Doctor->profile_picture   = $folder.$doctorimgname;
        }
        
        if($request->hasfile('gallery'))
         {
			$gallery = array();
            foreach($request->file('gallery') as $image)
            {	
				$folder           = 'doctor/';
				$random_number 	  = mt_rand(100000, 999999);
                $name = $random_number.$image->getClientOriginalName();                
                $image->move(public_path().'/images/doctor/', $name);  
                $Clinicgallery = new ClinicGallery;
				$Clinicgallery->doctor_id  = $Doctor->id;
				$Clinicgallery->image_path = $folder.$name;
				$Clinicgallery->save();
            }
         }
        $Doctor->save();
        return back()->with('success', 'Profile Updated successfully');
    }

    /**
     * Delete Doctor
    **/
    public function deleteDoctor(Request $request){		
        $id = $request->input('id');
        $Doctor = Doctor::where('user_id',$id)->first();
        if(file_exists(public_path('/images/'.$Doctor->profile_picture))){ //delete image if exist
			unlink(public_path('/images/'.$Doctor->profile_picture));
		}
		$Gallery  = ClinicGallery::where('doctor_id',$id)->get();
		if($Gallery !== null ) {
			foreach($Gallery as $key=>$img) {
				if(file_exists(public_path('/images/'.$img->image_path))){ //delete image if exist
					unlink(public_path('/images/'.$img->image_path));
				}	
			}
		}
		ClinicGallery::where('user_id',$Doctor->id)->delete();
        User::where('id',$id)->delete();
        RoleUser::where('user_id',$id)->delete();
        Doctor::where('user_id',$id)->delete();       
        DoctorAssistant::where('user_id',$id)->delete();
        return Response::json(array('success'=>true,'message'=>'Doctor Deleted successfully'));
    }
    
    /**
     * Delete Doctor Gallery Images
    **/
    public function deleteGalleryImg(Request $request) {
		$id		 		= $request->input('id');
		$ClinicGallery  = ClinicGallery::find($id);
		$ClinicGallery->delete();
		if(file_exists(public_path('/images/'.$ClinicGallery->image_path))){ //delete image if exist
			unlink(public_path('/images/'.$ClinicGallery->image_path));
		}
		return Response::json(array('success'=>true,'message'=>'Image Deleted successfully'));     
	} 
	
	/**
     * Get Doctor Assistant
    **/
	public function doctorAssistant($doctor_id) {
		$assistant  = DoctorAssistant::where('doctor_id', $doctor_id)->with('user')->get()->toArray();
		return View('admin.doctor.assistant',compact(['assistant', 'doctor_id']));		
	}
	
	/**
     * Add Assistant
    **/
	public function addAssistant(Request $request) {
		
		$validator = Validator::make($request->all(), [ 
            'email' => 'required|email|unique:users',
            'phone'	=> 'required|min:9|unique:users', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return back()->with('error',"Add Assistant Error: '". $err[0] ."'" );    
        }
        
        $user =  User::create([
            'name' 		=> $request->input('name'),
            'email' 	=> $request->input('email'),
            'phone' 	=> $request->input('phone'),
            'password'  => Hash::make(Str::random(6)),
            'isVerified'=> 1,
            'email_verified_at'=> date('Y-m-d h:i:s'),
            'api_token' => Str::random(60),
            'role' 		=> isset($data['role']) ? $data['role'] : '6',
            
        ]);
        $user->roles()->attach(Role::where('name', 'assistant')->first());
        
		$Assistant = new DoctorAssistant;
		$Assistant->doctor_id = $request->input('doctor_id');
		$Assistant->user_id = $user->id;
		
		
		/* if($request->hasfile('profile_image')) {
			$folder 	   = "assistant/";           
            $astImage      = $request->file("profile_image");
            $random_number = mt_rand(100000, 999999);
            $astimgname    = $random_number.$astImage->getClientOriginalName();
            $astImage->move(public_path().'/images/assistant/', $astimgname); 
            $Assistant->profile_pic  = $folder.$astimgname;
        } */
        
        $Assistant->save();
        
        //send login credentials on email to assistant pending yet ....
        
        return back()->with('success', 'Assistant Added Successfully');		
	}
	
	/**
     * Update Assistant
     **/
	public function updateAssistant(Request $request) { 
		
		$User = User::find($request->input('ast_id'));
		$User->name      = $request->input('name');
		$User->email     = $request->input('email');
		$User->phone	 = $request->input('phone');
		
        $User->save();
        return back()->with('success', 'Assistant Updated Successfully');	
	}
	
	/**
     * Delete Assistant
     **/
	public function deleteAssistant(Request $request) {
		$Assistant = DoctorAssistant::find($request->input('id'));
        if(file_exists(public_path('/images/'.$Assistant->profile_pic))) {  //delete image if exist
            unlink(public_path('/images/'.$Assistant->profile_pic));
        }
        User::where('id',$request->input('user_id'))->delete();
        RoleUser::where('user_id',$request->input('user_id'))->delete();
        DoctorAssistant::where('id',$request->input('id'))->delete();
        return Response::json(array('success'=>true,'message'=>'Assistant Deleted successfully'));
	}
	
	
}
