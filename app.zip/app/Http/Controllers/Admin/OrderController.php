<?php

namespace App\Http\Controllers\Admin;

use Auth;
use Image;
use App\Role;
use App\User;
use App\Orders as Order;
use App\OrdersDetail as OrderDetail;
use App\OrderComment;
use App\OrderStatus;
use App\Mail\CustomeroderNotifyEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;

class OrderController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
    */
    public function index(Request $request)
    {
		$orders = Order::with('user')->with('OrderDetails')->orderby('id','desc')->paginate(20);
		
		return view('admin.orders.read',compact(['orders']));
    }
    
     /**
     * Change the order status
     *
     * @return \Illuminate\Contracts\Support\Renderable
    */
    public function changeStatus(Request $request)
    {
		$shipping_amount 			= $request->shipping_amount;
		$shipping_tracking_number 	= $request->tracking_number;
		$orders 							= Order::find($request->order_id);
		if($orders){
			$orders->status 					= $request->status;
			$orders->shipping_tracking_number 	= $shipping_tracking_number;
			if($orders->shipping == ""){
				$orders->grand_total = $orders->total+$shipping_amount;
			}
			if($orders->shipping != "" && $orders->shipping != $shipping_amount){
				$orders->grand_total = $orders->total+$shipping_amount;
			}
			$orders->shipping 					= $shipping_amount;
			$orders->save();
		}
		$user = User::find($orders->user_id);
		$comments 	= $request->comments;
		$oid 		= $request->order_id;
		if($request->notify == "on"){
			$notify = 1;
			if($user){
				$email 	= "dottechnologies123@gmail.com";
				$data 	= ['ordermessage' => $comments,'order_id' => $oid];
				Mail::send('emails.admin.order.notify', $data, function($messaged)use($email){
				  $messaged->from('support@kabera.com');
				  $messaged->to($email);
				  $messaged->subject('Order Update');
				});
			}
			
		}else{
			$notify = 1;
		}
		
		
		
		/* */
		$OrderComment 						= new OrderComment;
		$OrderComment->order_id 			= $request->order_id;
		$OrderComment->order_status 		= $request->status;
		$OrderComment->order_comment 		= $request->comments;
		$OrderComment->customer_notified 	= $notify;
		$OrderComment->save();
		return Response::json(array('success'=>true,'message'=>'Order Successfully Updated'));
    }
    
    /**
     * Change the order status
     *
     * @return \Illuminate\Contracts\Support\Renderable
    */
    public function viewOrder($id)
    {
		/*$order 			= Order::where('id',$id)->with('user')->with('userDetails')->with('orderComments')->first();
		$orderProducts 	= OrderDetail::where('order_id',$order->id)->with('productDetails')->get();*/
		$OrderStatus = OrderStatus::all();
		
		$order 			= Order::where('id',$id)->with('user')->with('OrderDetails')->with('orderComments')->with('orderStatus')->first();		
		$orderProducts 		= OrderDetail::where('order_id',$order->id)->where('product_type','product')->with('productDetails')->get();
		$orderProcedure 	= OrderDetail::where('order_id',$order->id)->where('product_type','procedure')->with('procedureDetails')->get();
		
		return view('admin.orders.view',compact(['order','orderProducts','OrderStatus','orderProcedure']));
    }
    
    
    
    
   
}
