<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\User;
use App\Doctors;
use App\Agent;
use App\Service;
use App\SubService;
use App\Page;
use App\Offer;
use App\Banner;
use App\CityOffer;
use App\Countries;
use Auth;
use DB;

class OffersController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
    */
     
     public function __construct() {
		 
		  $this->middleware(['auth','verified']);
	 }
	 
	 /** Get Offers
	  * @return View offers with offers and services 
	  ***/
	 public function index(){
		 $offers    = Offer::where('offer_type','offer')->paginate(10);	
		 $countries = Countries::all();	 
		 $services  = SubService::all();	
		 return view('admin.offers.offers',compact(['offers','services','countries']));
	 }
	 
	 
	 /** Get Banners
	  * @return View banner with banners and services 
	  ***/
	 public function banners(){
		 $banners  = Banner::paginate(10);	
		 $services = Service::all();	
		return view('admin.offers.banners',compact(['banners','services']));
	 }
	 
	 /** Get Packages
	  * @return View packages with packages and services 
	  ***/
	 public function packages(){
		 $banners  = Offer::where('offer_type','package')->paginate(10);		
		 $services = Service::all();	
		return view('admin.offers.packages',compact(['banners','services']));
	 }
	 
	 /** Get Offer By Id 
	  *  @return View edit offer with offer and services 
	  ***/
	 public function editOffer($id) {
		 $offer     = Offer::find($id);
		 if( $offer === null)
		   abort(404);
		 $states = [];
		 $cities = [];
		 if(!empty($offer->state)) {
			 $country_id  =  DB::table("countries")->where("name",$offer->country)->pluck('id'); 
			 $states 	  =  DB::table("states")->where("country_id",$country_id)->get(["id","name"]); 
            
             $state_id 	  =  DB::table("states")->where("name",$offer->state)->pluck('id'); 
             $cities 	  =  DB::table("cities")->where("state_id",$state_id)->get(["id","name"]);          
		 }
		 $services  = SubService::all();
		 $countries = Countries::all();
		 return view('admin.offers.editoffer',compact(['offer','services','countries','states', 'cities']));
	 }
	 
	 /** Get Packages By Id 
	  *  @return View edit package with offer and services 
	  ***/
	 public function editPackage($id) {
		 $offer     = Offer::find($id);
		 if( $offer === null)
		   abort(404);
		 $states = [];
		 $cities = [];
		 if(!empty($offer->state)) {
			 $country_id  =  DB::table("countries")->where("name",$offer->country)->pluck('id'); 
			 $states 	  =  DB::table("states")->where("country_id",$country_id)->get(["id","name"]); 
            
             $state_id 	  =  DB::table("states")->where("name",$offer->state)->pluck('id'); 
             $cities 	  =  DB::table("cities")->where("state_id",$state_id)->get(["id","name"]);          
		 }
		 $services  = SubService::all();
		 $countries = Countries::all();
		 return view('admin.offers.editpackage',compact(['package','services','countries','states', 'cities']));
	 }
	 
	 /**
	 * Split Offers by service id
	 * @return View
	 **/
	  public function offersServiceWise($service){
		 $offers    = Offer::where('services',$service)->paginate(5);	
		 $services  = SubService::all();	
		 $countries = Countries::all();
		 return view('admin.offers.offers',compact(['offers','services','countries']));
	 }
	 
	 /** 
	  * Add Home offers *** 
	  * @return Vesponse
	 */
	 public function addOffer(Request $request) {
		
		 $offer_name_en  = $request->input('offer_name_en');
		 $offer_name_fr  = $request->input('offer_name_fr');
		 $description_en = $request->input('description_en');
		 $description_fr = $request->input('description_fr');
		 $product   	 = $request->input('product');
		 $discount   	 = $request->input('discount');
		 $discount_type  = $request->input('discount_type');
		 $service  		 = $request->input('service');
		 $product_offer  = $request->input('add_offer_product');
		 $product_offer_type = $request->input('product_offer');
		 $product  		 = $request->input('product');
		 $offer_rate  	 = $request->input('offer_product_rate');
		 $offer_status 	 = $request->input('offer_status');
		 $offer_type     = $request->input('offer_type');
		 $package_price  = $request->input('package_price');
		 $offer_is_type  = $request->input('is_type');
		 $offer_grafts   = $request->input('offer_grafts');
		 		 
		 $folder         = 'banners/';
		 $offerImage     = $request->file("offer_image");
		 $random_number  = mt_rand(100000, 999999);
		 $offerimgname   = $random_number.$offerImage->getClientOriginalName();
		 $offerImage->move(public_path().'/images/banners/', $offerimgname); 
		 $offer_image    = $folder.$offerimgname;
		 
		 $folder            = 'banners/';
		 $offerPortImage    = $request->file("portrait_banner");
		 $random_number     = mt_rand(100000, 999999);
		 $offerporimgname   = $random_number.$offerPortImage->getClientOriginalName();
		 $offerPortImage->move(public_path().'/images/banners/', $offerporimgname); 
		 $offer_port_image  = $folder.$offerporimgname;
		 
		 $folder        	= 'app/';
		 $appofferImage     = $request->file("app_offer_image");
		 $random_number  	= mt_rand(100000, 999999);
		 $appofferimgname   = $random_number.$appofferImage->getClientOriginalName();
		 $appofferImage->move(public_path().'/images/app/', $appofferimgname); 
		 $app_offer_image   = $folder.$appofferimgname;
       
		 $Offer  	  	  	    = new Offer;
		 $Offer->offer_name_en  = $offer_name_en;
		 $Offer->offer_name_fr  = $offer_name_fr;
		 $Offer->description_en = $description_en;
		 $Offer->description_fr = $description_fr;
		 $Offer->discount     	= $discount;		 
		 $Offer->offer_type 	= $offer_type;		 
		 $Offer->is_type 		= $offer_is_type;
		 
		 if($offer_type == 'package') {
			$Offer->discount_type   = null; 
			$Offer->package_price 	= $package_price;
			$Offer->offer_grafts 	= $offer_grafts;
		 } else {
			 $Offer->discount_type  = $discount_type;
			 $Offer->package_price 	= null;			 
			 $Offer->offer_grafts 	= null;			 
		 }
		 
		 if($offer_is_type == 2) {
			 $Offer->country 		= $request->input("country");
			 $Offer->state 			= $request->input("state");	
			 $Offer->city 			= implode(",", $request->input("city"));
		 }
		 $Offer->coupon_code 	= Str::random(9);	
		 $Offer->services  		= $service;	
		 if($product_offer == 'Y') {
			$Offer->products  			= $product;	 
			$Offer->product_offer_type  = $product_offer_type;	 
			$Offer->product_offer_rate  = $offer_rate;	 
		 }
		
		 $Offer->status  		   = $offer_status;	
		 $Offer->banner_image  	   = $offer_image;	
		 $Offer->app_banner_image  = $app_offer_image;	
		 $Offer->portrait_banner   = $offer_port_image;	
		 	 
		 $Offer->save();
		 return Response::json(array('success'=>true,'message'=>'Offer Addded Successfully'));
	 }
	 
	 /** 
	  * Update Offer *** 
	  * @return redirect to back page with response
	 */
	 public function updateOffer(Request $request) {
		 $id 			 = $request->input('id');
		 $Offer  	  	 = Offer::find($id);	
		 $offer_name_en  = $request->input('offer_name_en');
		 $offer_name_fr  = $request->input('offer_name_fr');
		 $description_en = $request->input('description_en');
		 $description_fr = $request->input('description_fr');
		 $product   	 = $request->input('product');
		 $discount   	 = $request->input('discount');
		 $discount_type  = $request->input('discount_type');
		 $service  		 = $request->input('service');
		 $product  		 = $request->input('product');
		 $offer_status 	 = $request->input('offer_status');
		 $product_offer  = $request->input('add_offer_product');
		 $product_offer_type= $request->input('product_offer');
		 $product  		    = $request->input('product');
		 $offer_rate  	    = $request->input('offer_product_rate');
		 $offer_is_type     = $request->input('is_type');
		 $offer_type      	= $request->input('offer_type');
		 $package_price     = $request->input('package_price');
		 $offer_grafts   	= $request->input('offer_grafts');
		 
		 $Offer->offer_name_en  = $offer_name_en;
		 $Offer->offer_name_fr  = $offer_name_fr;
		 $Offer->description_en = $description_en;
		 $Offer->description_fr = $description_fr;
		 $Offer->discount     	= $discount;
		 $Offer->status 		= $offer_status;
		 //$Offer->coupon_code 	= Str::random(9);
		 $Offer->product_offer  = $product_offer;
		 $Offer->offer_type 	= $offer_type;
		 $Offer->is_type 		= $offer_is_type;
		 
		 if($offer_type == 'package') {
			$Offer->discount_type   = null; 
			$Offer->package_price 	= $package_price;
			$Offer->offer_grafts 	= $offer_grafts;
		 } else {
			 $Offer->discount_type  = $discount_type;
			 $Offer->package_price 	= null;			 
			 $Offer->offer_grafts 	= null;			 
		 }
		 
		 if($product_offer == 'Y') {				 
			$Offer->products  			= $product;	 
			$Offer->product_offer_type  = $product_offer_type;	 
			$Offer->product_offer_rate  = $offer_rate;	 
		 } else {
			$Offer->products  			= null;	 
			$Offer->product_offer_type  = null; 
			$Offer->product_offer_rate  = null;			 
		 }
				 
		 if($offer_is_type == 2 && !empty($request->input("city"))) {
			 $Offer->country 		= $request->input("country");
			 $Offer->state 			= $request->input("state");	
			 $Offer->city 			= implode(",", $request->input("city"));
		 } else {
			 $Offer->country 		= null;	
			 $Offer->state 			= null; 
			 $Offer->city 			= null;				 
		 }
		
		 $Offer->services  	= $service;	
		 $Offer->status  	= $offer_status;
		 
        if($request->hasfile("offer_image")) {
			 $folder               = 'banners/';
			 $offerImage           = $request->file("offer_image");
			 $random_number        = mt_rand(100000, 999999);
			 $offerimgname         = $random_number.$offerImage->getClientOriginalName();
			 $offerImage->move(public_path().'/images/banners/', $offerimgname); 
			 $offer_image   	   = $folder.$offerimgname;	
			 $Offer->banner_image  = $offer_image;			 
        }	
		 
        if($request->hasfile("portrait_banner")) {
			  $folder            = 'banners/';
			  $offerPortImage    = $request->file("portrait_banner");
			  $random_number     = mt_rand(100000, 999999);
			  $offerporimgname   = $random_number.$offerPortImage->getClientOriginalName();
			  $offerPortImage->move(public_path().'/images/banners/', $offerporimgname); 
			  $offer_port_image  = $folder.$offerporimgname;	
			 $Offer->portrait_banner = $offer_port_image;			 
        }	
		 
        if($request->hasfile("app_offer_image")) {
			 $folder            = 'app/';
			 $appofferImage     = $request->file("app_offer_image");
			 $random_number  	= mt_rand(100000, 999999);
			 $appofferimgname   = $random_number.$appofferImage->getClientOriginalName();
			 $appofferImage->move(public_path().'/images/app/', $appofferimgname); 
			 $app_offer_image   = $folder.$appofferimgname;	
			 $Offer->app_banner_image  = $app_offer_image;			 
        }	
		 $Offer->save();
		 return redirect()->back()->with('success', 'Offer Updated Successfully');
	 }
	 
	 /**
	  * Delete Offer
	  * @return response
	 */
	 public function deleteOffer(Request $request) {		
        if(file_exists(public_path('/images/'.$request->input('image')))){ //delete image if exist
			unlink(public_path('/images/'.$request->input('image')));
		}
		
        if(file_exists(public_path('/images/'.$request->input('app_image')))){ //delete image if exist
			unlink(public_path('/images/'.$request->input('app_image')));
		}
		
		$banners  = Page::where('template', 'Home')->where('data_type','home banner')->orderBy('position', 'ASC')->get();
		foreach($banners as $key=>$val) {
			$data = json_decode($val->content_en, true);
			if($data['banner_column'] == '1') {
				if($data['offer'] == $request->input('id')) {
					Page::where('id',$val->id)->delete();
				}				
			} else if($data['banner_column'] == '2') {
				if($data['offer_first'] == $request->input('id') || $data['offer_second'] == $request->input('id') ) {
					Page::where('id',$val->id)->delete();
				}
			}
		}
		
		$Offer   = Offer::where('id',$request->input('id'))->delete();
		return Response::json(array('success'=>true,'message'=>'Offer Deleted Successfully'));
	 }
	 	 
	 
	 /** Get Banner By Id 
	  *  @return View edit banner with banner and services 
	 ***/
	 public function editBanner($id) {
		 $banner    = Banner::find($id);
		 if( $banner === null)
		   abort(404);
		   
		 $services = Service::all();
		 return view('admin.offers.editbanner',compact(['banner','services']));
	 }
	 
	 /**
	  * Split Offers by service id
	  * @return View
	 **/
	  public function bannerServiceWise($service){
		 $banners   = Banner::where('service',$service)->paginate(5);	
		 $services  = Service::all();	
		 return view('admin.offers.banners',compact(['banners','services']));
	 }
	 
	 /** 
	  * Add Home offers *** 
	  * @return Vesponse
	 */
	 public function addBanner(Request $request) {
		 
		 $banner_name	  = $request->input('banner_name');
		 $service  		  = $request->input('service');
		 $banner_status   = $request->input('banner_status');
		 $banner_url 	  = $request->input('banner_url');
		 		 
		 $folder            = 'banners/';
		 $bannerImage       = $request->file("banner_image");
		 $random_number     = mt_rand(100000, 999999);
		 $bannerimgname     = $random_number.$bannerImage->getClientOriginalName();
		 $bannerImage->move(public_path().'/images/banners/', $bannerimgname); 
		 $banner_image      = $folder.$bannerimgname;
		 
		 $folder        	= 'app/';
		 $appBannerImage    = $request->file("app_banner_image");
		 $random_number  	= mt_rand(100000, 999999);
		 $appBannerImgName  = $random_number.$appBannerImage->getClientOriginalName();
		 $appBannerImage->move(public_path().'/images/app/', $appBannerImgName); 
		 $app_banner_image  = $folder.$appBannerImgName;
       
		 $Banner  	  	  	    = new Banner;
		 $Banner->banner_name   = $banner_name;	
		 $Banner->service	  	= $service;	
		 $Banner->banner_url	= $banner_url;	
		
		 $Banner->status  		= $banner_status;	
		 $Banner->banner_image  = $banner_image;	
		 $Banner->mobile_image  = $app_banner_image;	
		 	 
		 $Banner->save();
		 return Response::json(array('success'=>true,'message'=>'Banner Addded Successfully'));
	 }
	 
	 /** 
	  * Update Banner *** 
	  * @return redirect to back page with response
	 */
	 public function updateBanner(Request $request) {
		 
		 $id 			 = $request->input('id');
		 $banner_name	 = $request->input('banner_name');
		 $service  		 = $request->input('service');
		 $banner_status  = $request->input('banner_status');
		 $banner_url 	 = $request->input('banner_url');
		 
		 $Banner 		 = Banner::find($id);
		 $Banner->banner_name   = $banner_name;	
		 $Banner->service  		= $service;	
		 $Banner->banner_url  	= $banner_url;		
		 $Banner->status  		= $banner_status;	
		 
        if($request->hasfile("banner_image")) {
			 $folder               = 'banners/';
			 $offerImage           = $request->file("banner_image");
			 $random_number        = mt_rand(100000, 999999);
			 $offerimgname         = $random_number.$offerImage->getClientOriginalName();
			 $offerImage->move(public_path().'/images/banners/', $offerimgname); 
			 $offer_image   	   = $folder.$offerimgname;	
			 $Banner->banner_image = $offer_image;			 
         }	
		 
        if($request->hasfile("app_banner_image")) {
			 $folder            = 'app/';
			 $appofferImage     = $request->file("app_banner_image");
			 $random_number  	= mt_rand(100000, 999999);
			 $appofferimgname   = $random_number.$appofferImage->getClientOriginalName();
			 $appofferImage->move(public_path().'/images/app/', $appofferimgname); 
			 $app_offer_image   = $folder.$appofferimgname;	
			 $Banner->mobile_image = $app_offer_image;			 
         }	
		 $Banner->save();
		 return redirect()->back()->with('success', 'Banner Updated Successfully');
	 }
	 
	 /**
	  * Delete Offer
	  * @return response
	 */
	 public function deleteBanner(Request $request) {		
        if(file_exists(public_path('/images/'.$request->input('image')))){ //delete image if exist
			unlink(public_path('/images/'.$request->input('image')));
		}
		
        if(file_exists(public_path('/images/'.$request->input('app_image')))){ //delete image if exist
			unlink(public_path('/images/'.$request->input('app_image')));
		}
		
		$banners  = Page::where('template', 'Home')->where('data_type','home banner')->orderBy('position', 'ASC')->get();
		foreach($banners as $key=>$val) {
			$data = json_decode($val->content_en, true);
			if($data['banner_column'] == '1') {
				if($data['offer'] == $request->input('id')) {
					Page::where('id',$val->id)->delete();
				}				
			} else if($data['banner_column'] == '2') {
				if($data['offer_first'] == $request->input('id') || $data['offer_second'] == $request->input('id') ) {
					Page::where('id',$val->id)->delete();
				}
			}
		}
		
		 Banner::where('id',$request->input('id'))->delete();
		return Response::json(array('success'=>true,'message'=>'Offer Deleted Successfully'));
	 }
	 
	  /* City Banners */
	 
	 public function cityBanner($id){
		 $banners   = CityOffer::where('type_id',$id)->get();
		 $offers    = Banner::where('status','1')->get(['id','banner_name']);
		 $services  = Service::all();
		 $countries = Countries::all();	
		 $bannerId  = $id;
	
		 return view('admin.banners.city.read',compact(['banners','offers','services','countries','bannerId']));
	 }
	 
	 
	  /** 
	  * Add City Home Banners *** 
	  * Return Response
	 */
	 public function addcityHomeBanner(Request $request) {
		 $banner_name	  = $request->input('banner_name');
		 $service  		  = $request->input('service');
		 $banner_status   = $request->input('banner_status');
		 $banner_url 	  = $request->input('banner_url');
		 $CityOffer   	  = CityOffer::where('type_id',$request->id)->where('city',$request->input('city'))->first();
		 if(!$CityOffer){
			 $folder            = 'banners/';
			 $bannerImage       = $request->file("banner_image");
			 $random_number     = mt_rand(100000, 999999);
			 $bannerimgname     = $random_number.$bannerImage->getClientOriginalName();
			 $bannerImage->move(public_path().'/images/banners/', $bannerimgname); 
			 $banner_image      = $folder.$bannerimgname;
			 
			 $folder        	= 'app/';
			 $appBannerImage    = $request->file("app_banner_image");
			 $random_number  	= mt_rand(100000, 999999);
			 $appBannerImgName  = $random_number.$appBannerImage->getClientOriginalName();
			 $appBannerImage->move(public_path().'/images/app/', $appBannerImgName); 
			 $app_banner_image  = $folder.$appBannerImgName;
			 
			 $CityOffer 				= new CityOffer;
			 $CityOffer->type_id 		= $request->id;
			 $CityOffer->offer_type 	= 'banners';
			 $CityOffer->country 		= $request->input('country');
			 $CityOffer->state 			= $request->input('state');
			 $CityOffer->city 			= $request->input('city');
			 $CityOffer->banner_name    = $banner_name;
			 $CityOffer->banner_image  = $banner_image;	
			 $CityOffer->mobile_image  = $app_banner_image;
			 $CityOffer->status 		= '1';
			 $CityOffer->save();
			return Response::json(array('success'=>true,'message'=>'Banner Addded Successfully'));
		}else{
			return Response::json(array('success'=>true,'message'=>'Banner already Addded for this city'));
		}
	 }
	 
	   /*Edit  City Banners */
	 
	 public function editCityBanner($id){
		 $banner = CityOffer::find($id);
		 if( $banner === null)
		   abort(404);
		 $countries = Countries::all();	 
		 $services = Service::all();
		 return view('admin.banners.city.edit',compact(['banner','services','countries']));
	 }
	 
	  /** 
	  * Update city Banner *** 
	  * @return redirect to back page with response
	 */
	 public function updateCityBanner(Request $request) {

		 $CityOffer 		 		= CityOffer::find($request->input('id'));
		 $CityOffer->banner_name   	= $request->input('banner_name');	
		 $CityOffer->country 		= $request->input('country');
		 $CityOffer->state 			= $request->input('state');
		 $CityOffer->city 			= $request->input('city');
		 
        if($request->hasfile("banner_image")) {
			 $folder               = 'banners/';
			 $offerImage           = $request->file("banner_image");
			 $random_number        = mt_rand(100000, 999999);
			 $offerimgname         = $random_number.$offerImage->getClientOriginalName();
			 $offerImage->move(public_path().'/images/banners/', $offerimgname); 
			 $offer_image   	   = $folder.$offerimgname;	
			 $CityOffer->banner_image = $offer_image;			 
         }	
		 
        if($request->hasfile("app_banner_image")) {
			 $folder            = 'app/';
			 $appofferImage     = $request->file("app_banner_image");
			 $random_number  	= mt_rand(100000, 999999);
			 $appofferimgname   = $random_number.$appofferImage->getClientOriginalName();
			 $appofferImage->move(public_path().'/images/app/', $appofferimgname); 
			 $app_offer_image   = $folder.$appofferimgname;	
			 $CityOffer->mobile_image = $app_offer_image;			 
         }	
		 $CityOffer->save();
		 return redirect()->back()->with('success', 'Banner Updated Successfully');
	 }
	 
	 
	  /**
	  * Delete cityBanner
	  * @return response
	 */
	 public function deleteCityBanner(Request $request) {	
		if(file_exists(public_path('/images/'.$request->input('image')))){ //delete image if exist
			unlink(public_path('/images/'.$request->input('image')));
		}
		
        if(file_exists(public_path('/images/'.$request->input('app_image')))){ //delete image if exist
			unlink(public_path('/images/'.$request->input('app_image')));
		}
		CityOffer::find($request->id)->delete();
		return Response::json(array('success'=>true,'message'=>'Offer Deleted Successfully'));
	 }
	
}
