<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use App\AppoitmentTimeslot;

use Auth;

class AppoitmentController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
     
    public function __construct() {
		 
		$this->middleware(['auth']);
	}
	
	/**
	  * view appoitment timeslot
	  * @return Response
	*/
	public function viewTimeslot() {
		$slots = AppoitmentTimeslot::orderBy('id', 'DESC')->get();
		return View('admin.appoitmenttimeslot',compact(['slots']));
	 }
	
	/*
     * Create function to add Time slot
     * @return response
    */
    public function addTimeslot(Request $request) {
		
		 $start_time = $request->input('starttime');
		 $end_time = $request->input('endtime');
		
		 $check_availablity = AppoitmentTimeslot::where('start_time', $start_time)->where('end_time', $end_time)->first();
		
		 
		if($check_availablity != null)
		{
			return Response::json(array('error'=>true,'message'=>'You have been already entered this Timeslot'));
		}
		else
		{
			$AppoitmentTimeslot  =  new AppoitmentTimeslot;
			$AppoitmentTimeslot->start_time  = $request->input('starttime');
			$AppoitmentTimeslot->end_time 	 =  $request->input('endtime');
			$AppoitmentTimeslot->save();
			return Response::json(array('success'=>true,'message'=>'Timeslot Added Successfully'));
	    }
		  
	}
	
	/*
     * Create function to update Time slot
     * @return response
    */
    public function updateTimeslot(Request $request) {
				
		 $AppoitmentTimeslot =  AppoitmentTimeslot::find($request->input('id'));
		 $AppoitmentTimeslot->start_time  = $request->input('starttime');
		 $AppoitmentTimeslot->end_time 	  =  $request->input('endtime');
		 $AppoitmentTimeslot->save();
		 return Response::json(array('success'=>true,'message'=>'Timeslot Updated Successfully'));
		  
	}
	
	/**
     * Create a function to delete time slot.
     * @return response
    */
    public function deleteTimeslot(Request $request)
    {
    	$id = $request->input('id');
    	AppoitmentTimeslot::where('id',$id)->delete();		
    	return Response::json(array('success'=>true,'message'=>'Timeslot Deleted Successfully'));
    }
	
 	
}


