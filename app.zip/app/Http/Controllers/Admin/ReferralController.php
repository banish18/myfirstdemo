<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Auth;
use Image;
use Storage;
use App\ReferralPointsData;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

class ReferralController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
    public function __construct()
    {
        $this->middleware('auth');
    }
    

	public function savePoint(Request $request)
    {
		 $ref_by_points       = $request->input('ref_by_points');
		 $ref_to_points 		= $request->input('ref_to_points');
		 $apt_points       = $request->input('apt_points');
		 $direct_points 		= $request->input('direct_points');
		 $ot_points    		= $request->input('ot_points');
		 $firstlogin    	= $request->input('firstlogin_points');
		 
		 $ReferralPointsData  	  	   =  new ReferralPointsData;
		 $ReferralPointsData->ref_by_points   =  $ref_by_points;
		 $ReferralPointsData->ref_to_points  =  $ref_to_points;
		 $ReferralPointsData->appointment_points 	   =  $apt_points;
		 $ReferralPointsData->ot_points =  $ot_points;	
		 $ReferralPointsData->direct_points =  $direct_points;
		 $ReferralPointsData->first_login =  $firstlogin;
		 $ReferralPointsData->save();
		 
		 return Response::json(array('success'=>true,'message'=>'Points Addded Successfully'));
	}
	
	public function referralPoints() {
		$get_points  =  ReferralPointsData::paginate(10);
		return view('admin.referralpoints',compact('get_points'));
	}
	
	/*
     * Create function to update referral points
     * @return response
    */
    public function updatePoints(Request $request) {
		
		 $ref_by_points       = $request->input('update_ref_by_points');
		 $ref_to_points 		= $request->input('update_ref_to_points');
		 $apt_points       = $request->input('update_apt_points');
		 $direct_points 		= $request->input('update_direct_points');
		 $ot_points    		= $request->input('update_ot_points');
		 $points_id    		= $request->input('ref_point_id');
		 $firstlogin    		= $request->input('update_firstlogin_points');
		 
		 $ReferralPointsData  =  ReferralPointsData::find($points_id);
		 $ReferralPointsData->ref_by_points   =  $ref_by_points;
		 $ReferralPointsData->ref_to_points  =  $ref_to_points;
		 $ReferralPointsData->appointment_points 	   =  $apt_points;
		 $ReferralPointsData->ot_points =  $ot_points;	
		 $ReferralPointsData->direct_points =  $direct_points;
		 $ReferralPointsData->first_login =  $firstlogin;
		 $ReferralPointsData->save();
		 
		 return Response::json(array('success'=>true,'message'=>'Points updated Successfully'));
		  
	}
	
	/**
     * Create a function to delete referral points.
     * @return response
    */
    public function deletePoints(Request $request)
    {
			$id = $request->input('id');
			ReferralPointsData::where('id',$id)->delete();		
			return Response::json(array('success'=>true,'message'=>'Referral Points Deleted Successfully'));
    }
    
}
