<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Input;
use Validator;
use App\User;
use App\Orders as Order;
use App\Role;
use App\RoleUser;
use App\Doctors;
use App\GraftRate;
use App\Agent;
use App\Service;
use App\SubService;
use App\UserDetail;
use App\PatientGallery;
use App\Countries;
use App\Procedure;
use App\AppointmentList;
use App\OperationList;
use Auth;
use DB;


class AdminController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
    */
     
     public function __construct() {
		 
		//  $this->middleware(['auth']);
	 }    

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
		if($user = Auth::user()) {
		    $request->user()->authorizeRoles('admin');
		    $orders  = Order::count();
		    $agents  = User::Where('role',5)->count();
		    $doctors = User::Where('role',2)->count();
		    $users   = User::Where('role',3)->count();
			return view('admin.dashboard',compact(['orders','agents','users','doctors']));
	    } else {
			return view('admin.login');	
		}
    }    
      
	/*public function adminLogin(Request $request)
	{
		if($user = Auth::user())
		{
		  $request->user()->authorizeRoles('admin');
		  return view('admin.dashboard');
	    } else {
			return view('admin.login');	
		}		
	}*/

	/**
     * Get Users
     * @return array
     */
	public function getUsers(Request $request){
	
		$query   = User::where('role',3);
		$filter  = "";
		if(Input::has('filter_by')) {
			$usersIds = array();
			$filter = Input::get('filter_by');
			if($filter == "clients") {
				
				$usersIds = DB::table('procedures')
							  ->leftJoin('operation_lists', 'operation_lists.procedure_id', '=', 'procedures.id')
							  ->whereIn('procedures.track_status',['follow_up','review','completed'])
							  ->where('operation_lists.doctor_approved','=', '1')
							  ->where('operation_lists.user_approved','=', '1')
							  ->pluck('procedures.user_id');
			} else if($filter == "walkin") {	
							 
				 $usersIds = DB::table('procedures')
							  ->leftJoin('appointment_lists', 'appointment_lists.procedure_id', '=', 'procedures.id')
							  ->where('procedures.track_status', '=', 'visit_doc')
							  ->where('appointment_lists.visit_first', '=', 1)
							  ->pluck('procedures.user_id');
				 
				 
			} else if($filter == "leads") {	
							 
				$usersIds = DB::table('procedures')
							  ->leftJoin('appointment_lists', 'appointment_lists.procedure_id', '=', 'procedures.id')
							  ->where('procedures.track_status', '=', 'visit_doc')
							  ->where('appointment_lists.visit_first', '=', 0)
							  ->pluck('procedures.user_id');
				 
			}
			
			if(count($usersIds) > 0) {
				$usersIds =  array_unique($usersIds->toArray());
				$query->whereIn('id',$usersIds);
			}
		
		}

		if(Input::has('name')) {
			$query->where('name', 'LIKE', '%' . Input::get('name') . '%');
		}
		$counts = $query->count();
		$users  = $query->paginate(10);
		
		if(!$users->count()){
			$users = array();
		}
		$userData = json_encode($users);
		return view('admin.users',compact(['users', 'userData','counts']));
	}
	
	/**
     * Add User
     * @return void
    */
	public function AddUser(Request $request){
		$data  = $request->all();
		
		$validator  = Validator::make($request->all(), [ 
            'email' => 'required|email|unique:users',
            'phone'	=> 'required|min:9|unique:users', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err]);            
        }
        
         $user =  User::create([
			'customer_number'   => mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999),
            'name'     => $data['user_name'],
            'email'    => $data['email'],
            'phone'    => $data['phone'],
            'password' => Hash::make($data['password']),
            'api_token' => Str::random(60),
            'role'	   =>  isset($data['role']) ? $data['role'] : '3',
        ]);
        $user
       ->roles()
       ->attach(Role::where('name', 'user')->first());
       
        // Create user detail when user is created
        $UserDetail = new UserDetail;
        $UserDetail->user_id =  $user->id;
        $UserDetail->save();
        return Response::json(array('success'=>true,'message'=>'User Created Successfully'));
    }
    
    
	/**
     * Edit User
     * @return view
    **/
    public function editUser($id)
    {
        $user_id      = $id;
        $user 	      = User::find($user_id);
        $user_detail  = UserDetail::where('user_id',$user_id)->first(); 
		
        return view('admin.edituser',compact(['user_detail','user','user_id']));
    }

	/**
     * Update User
     * @return back with response
    */
    public function UpdateUser(Request $request){

        $id     = $request->input('user_id');
        $name   = $request->input('name');
        $email  = $request->input('email');
        $phone  = $request->input('phone');

        $User 		  = User::find($id);
        $User->name   = $name;
        $User->email  = $email;
        $User->phone  = $phone;
                
        $User->save();
        return redirect()->back()->with('success', 'User Updated Successfully');
    }
        
    /**
     * Update User Information
    **/
    public function updateUserInfo(Request $request){

        $user_id 		= $request->input('user_id');
        $UserDetail     = UserDetail::where('user_id',$user_id)->first();
       
        $UserDetail->address  	 =  $request->input('user_address');
        $UserDetail->city        =  $request->input('user_city');
        $UserDetail->state       =  $request->input('user_state');
        $UserDetail->country     =  $request->input('user_country');
        $UserDetail->post_code   =  $request->input('post_code');
        $UserDetail->age   =  $request->input('age');
        $UserDetail->gender   =  $request->input('gender');
                
        if($request->hasfile('user_image')) {
            
            $folder           = 'patient/';
            $userImage        = $request->file("user_image");
            $random_number 	  = mt_rand(100000, 999999);
            $userimgname      = $random_number.$userImage->getClientOriginalName();
            $userImage->move(public_path().'/images/patient/', $userimgname); 
            $UserDetail->profile_picture   = $folder.$userimgname;
        }
        
       $UserDetail->hb_report    = $request->input('hb_report');
	   $UserDetail->hiv_report   = $request->input('hiv_report');
	   $UserDetail->hbsag_report = $request->input('hbsag_report');
	   $UserDetail->hcv_report   = $request->input('hcv_report');
	   $UserDetail->bt_ct_report = $request->input('btct_report');
	   $UserDetail->comment		 = $request->input('user_comment');
	   $folder = 'patient/';
	    if($request->hasfile('diabetes_report')) {
            $diabetes_report     = $request->file("diabetes_report");
            $random_number 	     = mt_rand(100000, 999999);
            $diabetes_reportname = $random_number.$diabetes_report->getClientOriginalName();
            $diabetes_report->move(public_path().'/images/patient/', $diabetes_reportname); 
            $UserDetail->diabetes_report   = $folder.$diabetes_reportname;
        }
        
	    if($request->hasfile('bp_report')) {
            $bp_report     = $request->file("bp_report");
            $random_number = mt_rand(100000, 999999);
            $bp_reportname = $random_number.$bp_report->getClientOriginalName();
            $bp_report->move(public_path().'/images/patient/', $bp_reportname); 
            $UserDetail->blood_pressure_report   = $folder.$bp_reportname;
        }
        
	    if($request->hasfile('heart_disease_report')) {
            $heart_disease_report = $request->file("heart_disease_report");
            $random_number 	      = mt_rand(100000, 999999);
            $heart_disease_reportname = $random_number.$heart_disease_report->getClientOriginalName();
            $heart_disease_report->move(public_path().'/images/patient/', $heart_disease_reportname); 
            $UserDetail->heart_disease_report   = $folder.$heart_disease_reportname;
        }
        
	    if($request->hasfile('depression_report')) {
            $depression_report     = $request->file("depression_report");
            $random_number 	       = mt_rand(100000, 999999);
            $depression_reportname = $random_number.$depression_report->getClientOriginalName();
            $depression_report->move(public_path().'/images/patient/', $depression_reportname); 
            $UserDetail->depression_report   = $folder.$depression_reportname;
        }
        

        
        $UserDetail->save();
        return back()->with('success', 'Information Updated Successfully');
    }
    
     /**
     * Search Users
     * @return array
     */
     
     public function searchUsers(Request $request){
		$search_val = $request->input('q');
		if(!empty($search_val))
		{
			$user = User::where('role',3)->where('name','LIKE','%'.$search_val.'%')->orWhere('email','LIKE','%'.$search_val.'%')->orWhere('phone','LIKE','%'.$search_val.'%')->get();
			
			if(count($user) != 0)
			{
			return response()->json(['success'=>true, 'data'=> $user]); 		
			}
			else
			{
			return response()->json(['success'=>false, 'data'=> $user]); 	
			}
		}
		else
		{
			return response()->json(['success'=>false, 'data'=> 'empty search']);
		}
	}

    
    /**
     * Patient Images 
     * @return data
    */
    
    public function patientImages($userId) {	  	
	 $gallery  = PatientGallery::where('user_id',$userId)->get();
	 $services = Service::all();
	 return View('admin.patientimages', compact(['gallery', 'userId', 'services']));
	}
	
    /**
     * Upload Patient Images 
     * @return void
    */
    
    public function uploadPatientImages(Request $request) {	
	 $user_id  = $request->input('user_id');  	
	 $PatientGallery  = new PatientGallery;
	   if($request->hasfile('gallery_1')) //Hair service
        {
			$gallery = array();
            foreach($request->file('gallery_1') as $image)
            {	
				$folder           = 'patient/';
				$random_number 	  = mt_rand(100000, 999999);
                $name = $random_number.$image->getClientOriginalName();                
                $image->move(public_path().'/images/patient/', $name);                  
				$PatientGallery->user_id    = $user_id;
				$PatientGallery->service_id = 1;
				$PatientGallery->image_path = $folder.$name;
				$PatientGallery->save();
            }
        }	  
         
	   if($request->hasfile('gallery_2')) //Skin service
        {
			$gallery = array();
            foreach($request->file('gallery_2') as $image)
            {	
				$folder           = 'patient/';
				$random_number 	  = mt_rand(100000, 999999);
                $name = $random_number.$image->getClientOriginalName();                
                $image->move(public_path().'/images/patient/', $name);                  
				$PatientGallery->user_id    = $user_id;
				$PatientGallery->service_id = 2;
				$PatientGallery->image_path = $folder.$name;
				$PatientGallery->save();
            }
        }	  
        
	   if($request->hasfile('gallery_3')) //Dentel service
        {
			$gallery = array();
            foreach($request->file('gallery_3') as $image)
            {	
				$folder           = 'patient/';
				$random_number 	  = mt_rand(100000, 999999);
                $name = $random_number.$image->getClientOriginalName();                
                $image->move(public_path().'/images/patient/', $name);                  
				$PatientGallery->user_id    = $user_id;
				$PatientGallery->service_id = 3;
				$PatientGallery->image_path = $folder.$name;
				$PatientGallery->save();
            }
        }
        
        return redirect()->back()->with('success', 'Images Updated Successfully');	  
	}
	
    /**
     * Change Password 
     * @return void
    */    
    public function changePassword(Request $request)
    {
        $user = User::find($request->input('user_id'));
        $user->password = bcrypt($request->get('password'));
        $user->save();
        return Response::json(array('success'=>true,'message'=>'Password Updated Successfully'));   
    }
    
    /**
     * Delete User 
     * @return void
    */
    public function DeleteUser(Request $request){		
        $id = $request->input('id');
        User::where('id',$id)->delete();
        RoleUser::where('user_id',$id)->delete();
        AppointmentList::where('user_id',$id)->delete();
        OperationList::where('user_id',$id)->delete();       
        PatientGallery::where('user_id',$id)->delete();
        return Response::json(array('success'=>true,'message'=>'User Deleted Successfully'));
    }	
    
    /**
     * Delete User Gallery Image
     * @return void
    */
    public function deleteUserGalleryImg(Request $request){	
      
        $id		 		= $request->input('id');
		$PatientGallery  = PatientGallery::find($id);		
		if(file_exists(public_path('/images/'.$PatientGallery->image_path))){ //delete image if exist
			unlink(public_path('/images/'.$PatientGallery->image_path));
		}
		PatientGallery::where('id',$id)->delete();  
		return Response::json(array('success'=>true,'message'=>'Image Deleted Successfully'));    
		
    }	
    
    /**
     * Get Services
     * @return array('services')
    */
    public function getServices(){
		$services = Service::all();
		return view('admin.services',compact(['services']));
	}
    
    /**
     *Add Services 
     * @retrun void
    */
    public function addService(Request $request){
		$service = new Service;
		$service->service_name 		  	 = $request->input('cat_name');
		$service->service_name_fr 		 = $request->input('cat_name_fr');
		$service->service_description_en = $request->input('cat_description_en');
		$service->service_description_fr = $request->input('cat_description_fr');
		
		$random_number	  	= mt_rand(100000, 999999);
		$service_image      = $request->file('app_icon');
		$folder 	      	= 'app/';        
        $service_image_name = $random_number.$service_image->getClientOriginalName();
        $service_image->move(public_path().'/images/app/', $service_image_name);
		$ServiceImage 	  	   = $folder.$service_image_name;
		$service->service_icon = $ServiceImage;
		$service->save();
		return redirect()->back()->with('success', 'Service Added Successfully');
	}
	
	/** 
	 * Update Services 
	*/	 
    public function updateService(Request $request){
		$service = Service::where('id', $request->input('cat_id'))->first();
		$service->service_name 			 = $request->input('cat_name');
		$service->service_name_fr 		 = $request->input('cat_name_fr');
		$service->service_description_en = $request->input('cat_description_en');
		$service->service_description_fr = $request->input('cat_description_fr');
		
		if($request->hasfile('app_icon')) {
			$random_number	  	= mt_rand(100000, 999999);
			$service_image      = $request->file('app_icon');
			$folder 	      	= 'app/';
			$service_image_name    = $random_number.$service_image->getClientOriginalName();
			$service_image->move(public_path().'/images/app/', $service_image_name);
			
			$ServiceImage 	       = $folder.$service_image_name;
			$service->service_icon = $ServiceImage;
		}
		
		$service->save();
		return redirect()->back()->with('success', 'Service Updated Successfully');
	}
	
    /*
     * Deleter Services
    */     
    public function deleteService(Request $request){
		
		$service_id = $request->input('id');
		Service::where('id', $service_id)->delete();			
		SubService::where('service_id', $service_id)->delete();			
        return Response::json(array('success'=>true,'message'=>'Service Deleted Successfully'));
	}
    
    /**
     *  Get Sub Services
     *  @return (array('arg1', 'arg2'))
     */
    public function getSubServices(){
		$services 	 = Service::all();
		$subservices = SubService::with(['service'])->get();
		return view('admin.subservices',compact(['subservices','services']));
	}
    
    /**
     * Add Sub Services 
     * @retrun void  
     */
    public function addSubService(Request $request){
		$random_number	  	= mt_rand(100000, 999999);
		$service_image      = $request->file('service_image');
		$folder 	      	= 'app/';        
        $service_image_name = $random_number.$service_image->getClientOriginalName();
        $service_image->move(public_path().'/images/app/', $service_image_name);
		$ServiceImage 	  	   = $folder.$service_image_name;
		$service = new SubService;
		$service->sub_name_en   			= $request->input('cat_name_en');
		$service->sub_name_fr   		= $request->input('cat_name_fr');
		$service->sub_description_en   	= $request->input('description_en');
		$service->sub_description_fr   	= $request->input('description_fr');
		$service->service_image   		= $ServiceImage;
		$service->service_id 			= $request->input('parent_category');
		$service->save();
		return redirect()->back()->with('success', 'Service Added Successfully');
	}
	/**
	 * 
	 * Update Sub Services 
	 *
	*/
    
    public function updateSubService(Request $request){
		$service = SubService::where('id', $request->input('id'))->first();
		$service->sub_name_en   = $request->input('sub_cat_name');
		$service->sub_name_fr   		= $request->input('cat_name_fr');
		$service->sub_description_en   	= $request->input('description_en');
		$service->sub_description_fr   	= $request->input('description_fr');
		$service->service_id = $request->input('parent_category');
		if($request->hasfile('service_image')) {
			$random_number	  	= mt_rand(100000, 999999);
			$service_image      = $request->file('service_image');
			$folder 	      	= 'app/';
			$service_image_name    = $random_number.$service_image->getClientOriginalName();
			$service_image->move(public_path().'/images/app/', $service_image_name);
			
			$ServiceImage 	       = $folder.$service_image_name;
			$service->service_image = $ServiceImage;
		}
		$service->save();
		return redirect()->back()->with('success', 'Service Updated Successfully');
	}
    
    /**
     * Delete Sub Services 
    */
    public function deleteSubService(Request $request){
		$service_id = $request->input('id');
		SubService::where('id', $service_id)->delete();			
        return Response::json(array('success'=>true,'message'=>'Service Deleted Successfully'));
	}
	
	/**
     * Get Agent
    */
	public function getAgents() {
		
		$agents = User::where('role',5)->get();
		if(!$agents->count()){
			$agents = array();
		}
		return view('admin.agent.agents',compact(['agents']));
	}
	
	/**
      Add Agent
    */
	public function addAgent(Request $request) {
		
		$validator  =  Validator::make($request->all(), [ 
            'email' => 'required|email|unique:users',
            'phone'	=> 'required|min:9|unique:users', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err]);            
        }
        
        $user =  User::create([
            'name' 		=> $request->input('agent_name'),
            'email' 	=> $request->input('email'),
            'phone' 	=> $request->input('phone'),
            'password'  => Hash::make($request->input('password')),
            'isVerified'=> 1,
            'email_verified_at'=> date('Y-m-d h:i:s'),
            'api_token' => Str::random(60),
            'role' 		=> isset($data['role']) ? $data['role'] : '5',
            
        ]);
        $user->roles()->attach(Role::where('name', 'agent')->first());
        
		$Agent 			  = new Agent;
		$Agent->user_id   = $user->id;
		
		 if($request->hasfile('profile_image')) {
			$folder           = 'agent/';
			$agentImage       = $request->file("profile_image");
			$random_number 	  = mt_rand(100000, 999999);
			$agentimgname     = $random_number.$agentImage->getClientOriginalName();
			$agentImage->move(public_path().'/images/agent/', $agentimgname); 
			$Agent->profile_pic = $folder.$agentimgname;
		}		
		
        $Agent->save();
        
        return Response::json(array('success'=>true,'message'=>'Agent Created Successfully'));	
	}
	
	/**
     * Update Agent
    */
	public function updateAgent(Request $request) { 
		
		$User = User::find($request->input('id'));
		$User->name      = $request->input('agent_name');
		$User->email     = $request->input('email');
		$User->phone	 = $request->input('phone');
		$User->save();
		
		$Agent 			   =  Agent::where('user_id', $request->input('id'))->first();
		if($request->hasfile('profile_image')) {
			$folder        = 'agent/';
			$agentImage    = $request->file("profile_image");
			$random_number = mt_rand(100000, 999999);
			$agentimgname  = $random_number.$agentImage->getClientOriginalName();
			$agentImage->move(public_path().'/images/agent/', $agentimgname); 
			$Agent->profile_pic = $folder.$agentimgname;
		}
		$Agent->save();
		
         return Response::json(array('success'=>true,'message'=>'Agent Updated Successfully'));	
	}
	
	/**
     * Delete Agent
    */
	public function deleteAgent(Request $request) {
			
        User::where('id',$request->input('id'))->delete();
        RoleUser::where('user_id',$request->input('id'))->delete();
        $Agent = Agent::where('user_id',$id)->first();
        if(file_exists(public_path('/images/'.$Agent->profile_pic))){ //delete image if exist
			unlink(public_path('/images/'.$Agent->profile_pic));
		}
        Agent::where('user_id',$request->input('id'))->delete();
        return Response::json(array('success'=>true,'message'=>'Agent Deleted Successfully'));
	}
	
	/**
     * Graft Rates
     * @return View
    */
	public function getGraftRates(Request $request) {
	   $rates = GraftRate::all();
	   $countries = Countries::all();
       return View('admin.graftrate',compact(['rates','countries']));
	}
	
	/**
	 * Add Graft Rate
	 * @return response
	*/
	public function addGraftRate(Request $request) {
        
		$GraftRate 		  	   = new GraftRate;
		$GraftRate->country	   = $request->input('country');
		$GraftRate->city  	   = $request->input('city');
		$GraftRate->state  	   = $request->input('state');
		$GraftRate->fue_rate   = $request->input('fue_rate');
		$GraftRate->robotic_rate = $request->input('robotic_rate');		
		$GraftRate->dhi_rate   = $request->input('dhi_rate');		
		$GraftRate->boi_rate   = $request->input('boi_rate');		
        $GraftRate->save();
        
        return redirect()->back()->with('success', 'Graft Rate Added Successfully');	
	}
	
	/**
     * Update Graft Rate
     * @return response
    */
	public function updateGraftRate(Request $request) { 
		
		$GraftRate 		  	   = GraftRate::find($request->input('graft_id'));
		$GraftRate->country	   = $request->input('country');
		$GraftRate->city  	   = $request->input('city');
		$GraftRate->state  	   = $request->input('state');
		$GraftRate->fue_rate   = $request->input('fue_rate');
		$GraftRate->robotic_rate = $request->input('robotic_rate');		
		$GraftRate->dhi_rate   = $request->input('dhi_rate');		
		$GraftRate->boi_rate   = $request->input('boi_rate');			
        $GraftRate->save();
        return redirect()->back()->with('success', 'Graft Rate Updated Successfully');		
	}
	
	/**
     * Delete Graft Rate
     * @return response
    */
	public function deleteGraftRate(Request $request) {	
		$id = $request->input('id');
        GraftRate::where('id',$id)->delete();
        return Response::json(array('success'=>true,'message'=>'Rates Deleted Successfully'));
	}
	
}
