<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use App\User;
use App\Service;
use App\SubService;
use App\Page;
use App\Blogs;
use App\Offer;
use App\Banner;
use App\ReferralData;
use App\ReferralPoint;
use App\Countries;
use App\CityOffer;
use App\TalkToExpert;
use Auth;

class ExpertController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
    public function __construct()
    {
        $this->middleware('auth');
    }
    

	public function callExpert()
    {
		$expert_data = TalkToExpert::with('talkexpert')->orderBy('id', 'DESC')->paginate(10);
		return view('admin.callexpert',compact('expert_data'));
	}
}
