<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use App\User;
use App\Service;
use App\SubService;
use App\BeforeAfterReview;
use App\ProcedureReview;
use Auth;
use App\FollowUpReminder;
use App\OperationList;
use App\ReminderList;
use App\Mail\ReminderEmail;
use App\SmsApi;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;

class FollowupController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
     
    public function __construct() {
		 
		$this->middleware(['auth']);
	}
	
	/*
	 * Before After Images
	 * @return View
	*/	
	public function hairfollowup(){
		$services   = Service::all();
		$subservices =  SubService::where('service_id',1)->get();
		$reminders =  FollowUpReminder::where('service_id',1)->get();
		return View('admin.pages.hairfollowreminder',compact(['subservices', 'services', 'reminders']));
	}
	public function skinfollowup(){
		$services   = Service::all();
		$subservices =  SubService::where('service_id',2)->get();
		$reminders =  FollowUpReminder::where('service_id',2)->get();
		return View('admin.pages.skinfollowreminder',compact(['subservices', 'services', 'reminders']));
	}
	public function dentalfollowup(){
		$services   = Service::all();
		$subservices =  SubService::where('service_id',3)->get();
		$reminders =  FollowUpReminder::where('service_id',3)->get();
		return View('admin.pages.dentalfollowreminder',compact(['subservices', 'services', 'reminders']));
	}	
	/**
	  * Save Follow Up Reminder
	  * return Response  
    */	 
	public function saveFollowupReminder(Request $request) {
					 
		$Reminder = new FollowUpReminder;		
		$Reminder->title  = $request->input('reminder_title');
		$Reminder->service_id	  = $request->input('service');
		$Reminder->sub_service_id  = $request->input('sub_service');
		$Reminder->reminder_day	  = $request->input('reminder_day');
		$Reminder->description	 = $request->input('description');
				
        $Reminder->save();
        return back()->with('success', 'Reminder Added Successfully');
	 } 
	 
	 /**
	  * Delete Follow Up Reminder
	  * @return Response
	*/
	public function deleteFollowupReminder(Request $request) {
		
		$Reminder = FollowUpReminder::find($request->input('id'));	
		$Reminder->delete();
		return Response::json(array('success'=>true,'message'=>'Reminder Deleted Successfully'));
	} 
	
	/**
	  * Update Follow Up Reminder
	  * @return Response
	*/
	 public function updateFollowupReminder(Request $request) {
		
		$Reminder = FollowUpReminder::find($request->input('id'));
		
		$Reminder->title  = $request->input('reminder_title');
		$Reminder->sub_service_id  = $request->input('sub_service');
		$Reminder->reminder_day	  = $request->input('reminder_day');
		$Reminder->description	  = $request->input('description');
		$Reminder->reminder_status  = $request->input('status');
				
        $Reminder->save();	
        return back()->with('success', 'Reminder Updated Successfully');	
	}
	
			
}


