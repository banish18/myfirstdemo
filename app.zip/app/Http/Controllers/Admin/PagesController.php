<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use App\User;
use App\Service;
use App\SubService;
use App\Page;
use App\Blogs;
use App\Offer;
use App\Banner;
use App\ReferralData;
use App\ReferralPoint;
use App\Countries;
use App\CityOffer;
use Auth;


class PagesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
    */
     
     public function __construct() {
		 
		  $this->middleware(['auth','verified']);
	 }
	 
	 
	 public function index() {
		 
		 $slides   = Page::where('template', 'Home')->where('data_type','home slider')->get();	
		 $offers   = Banner::where('status','1')->get(['id','banner_name']);
		 $services = Service::all();
		 $banners  = Page::where('template', 'Home')->where('data_type','home banner')->orderBy('position', 'ASC')->get();
		 $countries = Countries::all();	
		 return view('admin.pages.home',compact(['slides','offers','banners', 'services','countries']));
	 }
	
	 /** 
	  * Add Home Slides *** 
	  * Return Response
	 */
	 public function addHomeSlide(Request $request) {
		 
		 $title_en       = $request->input('title_en');
		 $description_en = $request->input('description_en');
		 $title_fr       = $request->input('title_fr');
		 $description_fr = $request->input('description_fr');
		 $content_pos    = $request->input('content_pos');
		 $service    	 = $request->input('slide_service');
		 $slide_type     = $request->input('slide_type');
		 $page_template  = $request->input('template_name');
		 $procedure_url  = $request->input('procedure_url');
		 $product_url    = $request->input('product_url');
		
		 $folder         = 'pages/';
		 $slideImage     = $request->file("slide_image");
		 $random_number  = mt_rand(100000, 999999);
		 $slideimgname   = $random_number.$slideImage->getClientOriginalName();
		 $slideImage->move(public_path().'/images/pages/', $slideimgname); 
		 $slide_image    = $folder.$slideimgname;
		 $sliderData_en  = array('title'=>$title_en, 'description'=>$description_en, 'image'=> $slide_image );
		 $sliderData_fr  = array('title'=>$title_fr, 'description'=>$description_fr, 'image'=> $slide_image );
         $extra_en 		 = array('content_position' => $content_pos, 'service'=> $service, 'procedure_url'=> $procedure_url, 'product_url'=> $product_url);	
       
		 $page  	  	   =  new Page;
		 $page->template   =  $page_template;
		 $page->data_type  =  $slide_type;
		 $page->title 	   = 'Slide';
		 $page->content_en =  json_encode($sliderData_en);	
		 $page->content_fr =  json_encode($sliderData_fr);	
		 $page->extras_en  =  json_encode($extra_en);	
		 	 
		 $page->save();
		 return Response::json(array('success'=>true,'message'=>'Slider Addded Successfully'));
	 }
	 
	 /** 
	  * Update Home Slides *** 
	  * Return Response
	 */
	 public function updateHomeSlide(Request $request) {
		 
		 $id 			 = $request->input('id');
		 $title_en       = $request->input('title_en');
		 $description_en = $request->input('description_en');
		 $title_fr       = $request->input('title_fr');
		 $description_fr = $request->input('description_fr');
		 $content_pos    = $request->input('content_pos');
		 $service    	 = $request->input('slide_service');
		 $procedure_url  = $request->input('procedure_url');
		 $product_url    = $request->input('product_url');
		 
		 $page  	  	 = Page::find($id);		 
		 $slide_image	 = json_decode($page->content_en)->image;	
		 	 
		if($request->hasfile("slide_image")) {
			 $folder        = 'pages/';
			 $slideImage    = $request->file("slide_image");
			 $random_number = mt_rand(100000, 999999);
			 $slideimgname  = $random_number.$slideImage->getClientOriginalName();
			 $slideImage->move(public_path().'/images/pages/', $slideimgname); 
			 $slide_image   = $folder.$slideimgname;			 
         }	
         
         $sliderData_en    = array('title'=>$title_en, 'description'=>$description_en, 'image'=> $slide_image );
		 $sliderData_fr    = array('title'=>$title_fr, 'description'=>$description_fr, 'image'=> $slide_image );
		 $extra_en 		 = array('content_position' => $content_pos, 'service'=> $service, 'procedure_url'=> $procedure_url, 'product_url'=> $product_url);		
		 
		 $page->content_en =  json_encode($sliderData_en);	
		 $page->content_fr =  json_encode($sliderData_fr);	
		 $page->extras_en  =  json_encode($extra_en);	
		 	 
		 $page->save();
		 return Response::json(array('success'=>true,'message'=>'Slider Addded Successfully'));
	 }
	 
	 /**
	  * Delete Home Page Slide
	  * Return Response
	 */
	 public function deleteHomePageSlide(Request $request) {		
        if(file_exists(public_path('/images/'.$request->input('image')))){ //delete image if exist
			unlink(public_path('/images/'.$request->input('image')));
		}
		Page::where('id',$request->input('id'))->delete();
		return Response::json(array('success'=>true,'message'=>'Slide Deleted Successfully'));
	 } 
	 
	 
	 /** 
	  * Add Home Banners *** 
	  * Return Response
	 */
	 public function addHomeBanner(Request $request) {
		 
		 $bannerCount 		 =  Page::where('template', 'Home')->where('data_type', 'home banner')->count();
		 $banner_sections    =  $request->input('banner_section');
		 if($banner_sections == '2') {
			$bannerData    = array('banner_column'=> $banner_sections, 'offer_first'=>$request->input('offer_first'), 'offer_second'=>$request->input('offer_second') );
		 } else {
			$bannerData    = array('banner_column'=> $banner_sections,'offer'=>$request->input('offer')); 
		 }
		
         $position 		   = ($bannerCount !== null) ? $bannerCount + 1  : 1;	
       
		 $page  	  	   =  new Page;
		 $page->template   = 'Home';
		 $page->data_type  = 'home banner';
		 $page->title 	   = 'Banner';
		 $page->content_en =  json_encode($bannerData);	
		 $page->position   =  $position;	
		 $page->save();
		 return Response::json(array('success'=>true,'message'=>'Banner Addded Successfully'));
	 }
	 
	 
	 
	 /** 
	  * Update Home Banner *** 
	  * Return Response
	 */
	 public function updateHomeBanner(Request $request) {
		 
		 $id 			 = $request->input('id');
		 $banner_sections    =  $request->input('banner_section');
		 if($banner_sections == '2') {
			$bannerData    	 = array('banner_column'=> $banner_sections, 'offer_first'=>$request->input('offer_first'), 'offer_second'=>$request->input('offer_second') );
		 } else {
			$bannerData    = array('banner_column'=> $banner_sections,'offer'=>$request->input('offer')); 
		 }
		       
		 $page  	  	   =  Page::where('id',$id);
		 $page->template   = 'Home';
		 $page->data_type  = 'home banner';
		 $page->title 	   = 'Banner';
		 $page->content_en =  json_encode($bannerData);		
		 	 
		 $page->save();
		 return Response::json(array('success'=>true,'message'=>'Slider Addded Successfully'));
	 }
	 
	 /**
	  * Update Banner Position
	  * Return Response
	 */	 
	 public function updateHomeBannerPosition(Request $request) {
		   $positions = $request->positions;		   	
		   $i=1;	   
		   foreach($positions as $key=>$val) {
			Page::where('id', $val)
            ->update(['position' => $i]);    
            $i++; 
		   }
		  return Response::json(array('success'=>true,'message'=>'Position Updated Successfully'));
	  }
	 
	 /**
	  * Delete Home Page Slide
	  * Return Response
	 */
	 public function deleteHomeBanner(Request $request) {
		Page::where('id',$request->input('id'))->delete();
		return Response::json(array('success'=>true,'message'=>'Banner Deleted Successfully'));
	 } 
	 
	 
	
	
	
	 /**
	  * Hair Procedure Content	   
	  * Return View
	 */
	 public function hairProcedure() {
		 $banners 	 =  Banner::where('status','1')->get(['id','banner_name']);
		 $procedure  =  Page::where('template','Hair Procedure')->where('data_type','hair-procdeure-data')->first();
		 $data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		 if($procedure !== null) {
			$procedureData   = json_decode($procedure->content_en);
			$procedureDatafr = json_decode($procedure->content_fr);
			$extraData       = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
		 }
		 $images = "";
		 
		 return View('admin.pages.hairprocedure',compact(['data', 'banners']));
	 }
	 
	 
	 /**
	  * Save Hair Procedure Content	  
	  * return back with response 
	 */
	 public function hairProcedureSave(Request $request) {
		$validatedData 		     =  $request->validate([
			'testimony_video'	 => 'required', 
            'first_banner'		 => 'required', 
            'second_banner'		 => 'required', 
            'work_step_1_en'	 => 'required', 
            'work_step_1_fr'	 => 'required', 
            'work_step_2_en'	 => 'required', 
            'work_step_2_fr'	 => 'required', 
            'work_step_3_en'	 => 'required', 
            'work_step_3_fr'	 => 'required', 
            'available_hair_en'  => 'required', 
            'available_hair_fr'  => 'required', 
		]);
		
		$available_hair_en   =  $request->input('available_hair_en');
		$available_hair_fr   =  $request->input('available_hair_fr');
		$video 			     =  $request->input('testimony_video');
		$first_banner 	     =  $request->input('first_banner');
		$second_banner 	     =  $request->input('second_banner');
		$work_step_1_en      =  $request->input('work_step_1_en');
		$work_step_1_fr      =  $request->input('work_step_1_fr');
		$work_step_2_en      =  $request->input('work_step_2_en');
		$work_step_2_fr      =  $request->input('work_step_2_fr');
		$work_step_3_en      =  $request->input('work_step_3_en');
		$work_step_3_fr      =  $request->input('work_step_3_fr');
		
		$extras_en  =  array('banner'=>'');
		$procedure  =  Page::where('template','Hair Procedure')->where('data_type','hair-procdeure-data')->first();
		
		if($procedure !== null) {			
			$banner    = json_decode($procedure->extras_en)->banner;
			$extras_en = array('banner'=>$banner);
		}
		
		if($request->hasfile("page_banner")) {	
			 $folder        = 'pages/';
			 $bannerImage   = $request->file("page_banner");
			 $random_number = mt_rand(100000, 999999);
			 $bannerimgname = $random_number.$bannerImage->getClientOriginalName(); 
			 $bannerImage->move(public_path().'/images/pages/', $bannerimgname); 
			 $banner_image  = $folder.$bannerimgname;	
			 $extras_en	    = array('banner'=>$banner_image);
         }	
         
		$procedureDataEn  =  array('available_hair'=>$available_hair_en, 'testimony_video'=>$video, 'first_banner'=>$first_banner, 'second_banner'=>$second_banner, 'work_step_1'=>$work_step_1_en, 'work_step_1'=>$work_step_1_en, 'work_step_2'=>$work_step_2_en, 'work_step_3'=>$work_step_3_en); 
		$procedureDataFr  =  array('available_hair'=>$available_hair_fr, 'testimony_video'=>$video, 'fisrt_banner'=>$first_banner, 'second_banner'=>$second_banner, 'work_step_1'=>$work_step_1_fr, 'work_step_2'=>$work_step_2_fr, 'work_step_3'=>$work_step_3_fr); 
		
		if($procedure !== null) {
		  $procedure->content_en =  json_encode($procedureDataEn);
		  $procedure->extras_en  =  json_encode($extras_en);
		  $procedure->content_fr =  json_encode($procedureDataFr);
			
		} else {
		  $procedure = new Page;
		  $procedure->template   = 'Hair Procedure';
		  $procedure->data_type  = 'hair-procdeure-data';
		  $procedure->title	 	 = 'Hair Procedure';
		  $procedure->content_en =  json_encode($procedureDataEn);
		  $procedure->extras_en  =  json_encode($extras_en);
		  $procedure->content_fr =  json_encode($procedureDataFr);
		}
		$procedure->save();
		return redirect()->back()->with('success', 'Updated successfully');
	 }
	 
	 
	 /**
	  * Hair Product Page Content
	  * Return View	   
	 */
	 public function hairProductPageContent() {
		 $slides  		  =  Page::where('template', 'Hair Products')->where('data_type','hair-products-slider')->get();	
		 $banners 	 	  =  Banner::where('status','1')->get(['id','banner_name']);
		 $productContent  =  Page::where('template','Hair Products Page')->where('data_type','hair-product-data')->first();
		 $data 		 	  =  array('product'=>'');
		 $services        =  '';
		 if($productContent !== null) {
			$productData   = json_decode($productContent->content_en);
			$data['product']  = $productData;
		 }
		return View('admin.pages.hairproducts',compact(['data', 'services', 'banners', 'slides']));
	 }
	 
	  
	 /**
	  * Save Hair Product Content	  
	  * return back with response 
	 */
	 public function hairProductContentSave(Request $request) {
		$validatedData 		      =  $request->validate([			 
            'first_offer'		  => 'required', 
            'second_offer'		  => 'required', 
            'third_offer'    	  => 'required', 
            'left_banner'    	  => 'required', 
            'first_right_banner'  => 'required', 
            'second_right_banner' => 'required', 
            'third_right_banner'  => 'required', 
		]);
		
		$fisrt_offer 	      =  $request->input('first_offer');
		$second_offer 	      =  $request->input('second_offer');
		$third_offer   	      =  $request->input('third_offer');
		$left_banner   	      =  $request->input('left_banner');
		$first_right_banner   =  $request->input('first_right_banner');
		$second_right_banner  =  $request->input('second_right_banner');
		$third_right_banner   =  $request->input('third_right_banner');
		
		
		$products  	    =  Page::where('template','Hair Products Page')->where('data_type','hair-product-data')->first();
		               
		$productsData   =  array('first_offer'=>$fisrt_offer, 'second_offer'=>$second_offer, 'left_banner'=>$left_banner, 'third_offer'=>$third_offer, 'first_right_banner'=>$first_right_banner, 'second_right_banner'=>$second_right_banner, 'third_right_banner'=>$third_right_banner); 
		 
		
		if($products !== null) {
		  $products->content_en =  json_encode($productsData);
			
		} else {
		  $products = new Page;
		  $products->template   = 'Hair Products Page';
		  $products->data_type  = 'hair-product-data';
		  $products->title	 	 = 'Hair Products';
		  $products->content_en =  json_encode($productsData);
		}
		$products->save();
		return redirect()->back()->with('success', 'Updated successfully');
	 }
	 
	 
	 /** 
	  * Add Slides *** 
	  * Return Response
	 */
	 public function addSlide(Request $request) {
		 
		 $title_en       = $request->input('title_en');
		 $title_fr       = $request->input('title_fr');
		 $slide_type     = $request->input('slide_type');
		 $page_template  = $request->input('template_name');
		 
		 $folder         = 'pages/';
		 $slideImage     = $request->file("slide_image");
		 $random_number  = mt_rand(100000, 999999);
		 $slideimgname   = $random_number.$slideImage->getClientOriginalName();
		 $slideImage->move(public_path().'/images/pages/', $slideimgname); 
		 $slide_image    = $folder.$slideimgname;
		 $sliderData_en  = array('title'=>$title_en, 'image'=> $slide_image );
		 $sliderData_fr  = array('title'=>$title_fr, 'image'=> $slide_image );
               
		 $page  	  	   =  new Page;
		 $page->template   =  $page_template;
		 $page->data_type  =  $slide_type;
		 $page->title 	   = 'Slide';
		 $page->content_en =  json_encode($sliderData_en);	
		 $page->content_fr =  json_encode($sliderData_fr);	
		 	 
		 $page->save();
		 return Response::json(array('success'=>true,'message'=>'Slider Addded Successfully'));
	 }
	 
	 /** 
	  * Update Slides *** 
	  * Return Response
	 */
	 public function updateSlide(Request $request) {
		 
		 $id 			 = $request->input('id');
		 $title_en       = $request->input('title_en');
		 $title_fr       = $request->input('title_fr');
		 
		 $page  	  	 = Page::find($id);		 
		 $slide_image	 = json_decode($page->content_en)->image;	
		 	 
		 if($request->hasfile("slide_image")) {
			 $folder        = 'pages/';
			 $slideImage    = $request->file("slide_image");
			 $random_number = mt_rand(100000, 999999);
			 $slideimgname  = $random_number.$slideImage->getClientOriginalName();
			 $slideImage->move(public_path().'/images/pages/', $slideimgname); 
			 $slide_image   = $folder.$slideimgname;			 
         }	
         
         $sliderData_en    = array('title'=>$title_en, 'image'=> $slide_image );
		 $sliderData_fr    = array('title'=>$title_fr, 'image'=> $slide_image );
		 
		 $page->content_en =  json_encode($sliderData_en);	
		 $page->content_fr =  json_encode($sliderData_fr);	
		 	 
		 $page->save();
		 return Response::json(array('success'=>true,'message'=>'Slider Addded Successfully'));
	 }
	 
	 /**
	  * Hair Transplant Content	   
	  * Return View
	 */	 
	 public function hairTransplant() {
		 $hairTransplant =  Page::where('template','Hair Transplant')->where('data_type','hair-transplant-data')->first();
		 $data 		  	 =  array('transplant_en'=>'', 'transplant_fr'=>'');
		 if($hairTransplant !== null) {
			$transplantData   = json_decode($hairTransplant->content_en);
			$transplantDatafr = json_decode($hairTransplant->content_fr);
			$data['transplant_en']  = $transplantData;
			$data['transplant_fr']  = $transplantDatafr;	
		 }
		
		 return View('admin.pages.hairtransplant',compact(['data']));
	 }
	 
	 /**
	  * Save Hair Transplant Content	  
	  * return back with response 
	 */
	 public function hairTransplantSave(Request $request) {
		$validatedData 		     =  $request->validate([
            'kabera_guarantee_en'=> 'required', 
            'kabera_guarantee_fr'=> 'required', 
            'first_step_en'	  	 => 'required', 
            'first_step_fr'	  	 => 'required', 
            'second_step_en'	 => 'required', 
            'second_step_fr'	 => 'required', 
            'third_step_en'	  	 => 'required', 
            'third_step_fr'	 	 => 'required', 
            'transplant_text_en' => 'required', 
            'transplant_text_fr' => 'required', 
            
		]);
		
		$kabera_guarantee_en   =  $request->input('kabera_guarantee_en');
		$kabera_guarantee_fr   =  $request->input('kabera_guarantee_fr');
		$first_step_en 	   	   =  $request->input('first_step_en');
		$first_step_fr 	   	   =  $request->input('first_step_fr');
		$second_step_en 	   =  $request->input('second_step_en');
		$second_step_fr 	   =  $request->input('second_step_fr');
		$third_step_en 	   	   =  $request->input('third_step_en');
		$third_step_fr	   	   =  $request->input('third_step_fr');
		$transplant_text_en    =  $request->input('transplant_text_en');
		$transplant_text_fr	   =  $request->input('transplant_text_fr');
		
		$extras_en   =  array('banner'=>'');
		$transplant  =  Page::where('template','Hair Transplant')->where('data_type','hair-transplant-data')->first();
		
		
		$transplantDataEn  =  array('kabera_guarantee'=>$kabera_guarantee_en, 'first_step'=>$first_step_en, 'second_step'=>$second_step_en, 'third_step'=>$third_step_en, 'transplant_text'=>$transplant_text_en); 
		$transplantDataFr  =  array('kabera_guarantee'=>$kabera_guarantee_fr, 'first_step'=>$first_step_fr, 'second_step'=>$second_step_fr, 'third_step'=>$third_step_fr, 'transplant_text'=>$transplant_text_fr);
		
		if($transplant !== null) {
		  $transplant->content_en =  json_encode($transplantDataEn);
		  $transplant->content_fr =  json_encode($transplantDataFr);
			
		} else {
		  $transplant = new Page;
		  $transplant->template   = 'Hair Transplant';
		  $transplant->data_type  = 'hair-transplant-data';
		  $transplant->title	 	 = 'Hair Transplant';
		  $transplant->content_en =  json_encode($transplantDataEn);
		  $transplant->content_fr =  json_encode($transplantDataFr);
		}
		$transplant->save();
		return redirect()->back()->with('success', 'Data Updated successfully');
	 }
	 
	 	 
	 /**
	  * Footer Content	
	  * Return View   
	 */
	 public function footerContent() {
		 $Footer  =  Page::where('template','Footer')->where('data_type','footer data')->first();
		 return View('admin.pages.footer',compact(['Footer']));
	 }
	 
	 /**
	  * Add Footer Content	  
	  * return back with response 
	 */
	 public function addFooterContent(Request $request) {
		        
         $validatedData 	=  $request->validate([
			'content_en'	=> 'required', 
            'phone'			=> 'required', 
		 ]);
		$footerDataEn  =  array('content'=>$request->input('content_en'), 'phone'=>$request->input('phone')); 
		$footerDataFr  =  array('content'=>$request->input('content_fr'), 'phone'=>$request->input('phone')); 
		
		$Footer  =  Page::where('template','Footer')->where('data_type','footer data')->first();
		if($Footer !== null) {
		  $Footer->content_en =  json_encode($footerDataEn);
		  		  
		if(!empty($request->input('content_fr')))
			$Footer->content_fr =  json_encode($footerDataFr);
			
		} else {
		  $Footer = new Page;
		  $Footer->template   = 'Footer';
		  $Footer->data_type  = 'footer data';
		  $Footer->title	  = 'Footer';
		  $Footer->content_en =  json_encode($footerDataEn);
		  if(!empty($request->input('content_fr')))
			$Footer->content_fr =  json_encode($footerDataFr);
		}
		$Footer->save();
		return redirect()->back()->with('success', 'Updated successfully');
	 }
	 
	  
	  /**
	  * Skin Procedure Content	   
	  * Return View
	 */
	 public function SkinProcedure() {
		 $banners 	 =  Banner::where('status','1')->get(['id','banner_name']);
		 $skinprocedure  =  Page::where('template','Skin Procedure')->where('data_type','skin-procdeure-data')->first();
		 $data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		 if($skinprocedure !== null) {
		 	$skinprocedureDataen   = json_decode($skinprocedure->content_en);
		 	$skinprocedureDatafr = json_decode($skinprocedure->content_fr);
		 	$extraData       = json_decode($skinprocedure->extras_en);
		 	$data['banner_image']  = $extraData->banner;
		 	$data['procedure_en']  = $skinprocedureDataen;
		 	$data['procedure_fr']  = $skinprocedureDatafr;	
		 }
		//$images = "";
		 
		 return View('admin.pages.skinprocedure',compact(['data', 'banners']));
	}
	 
	  /**
	  * Save Hair Procedure Content	  
	  * return back with response 
	 */
	 public function skinProcedureSave(Request $request) {
		$validatedData 		     =  $request->validate([
			'testimony_video'	 => 'required', 
            'first_banner'		 => 'required', 
            'second_banner'		 => 'required', 
            'work_step_1_en'	 => 'required', 
            'work_step_1_fr'	 => 'required', 
            'work_step_2_en'	 => 'required', 
            'work_step_2_fr'	 => 'required', 
            'work_step_3_en'	 => 'required', 
            'work_step_3_fr'	 => 'required', 
            'available_hair_en'  => 'required', 
            'available_hair_fr'  => 'required', 
		]);
		
		$available_skin_en   =  $request->input('available_hair_en');
		$available_skin_fr   =  $request->input('available_hair_fr');
		$video 			     =  $request->input('testimony_video');
		$first_banner 	     =  $request->input('first_banner');
		$second_banner 	     =  $request->input('second_banner');
		$work_step_1_en      =  $request->input('work_step_1_en');
		$work_step_1_fr      =  $request->input('work_step_1_fr');
		$work_step_2_en      =  $request->input('work_step_2_en');
		$work_step_2_fr      =  $request->input('work_step_2_fr');
		$work_step_3_en      =  $request->input('work_step_3_en');
		$work_step_3_fr      =  $request->input('work_step_3_fr');
		
		
		
		 $extras_en  =  array('banner'=>'');
		 $procedure  =  Page::where('template','Skin Procedure')->where('data_type','skin-procdeure-data')->first();
		 
		 if($procedure !== null) {			
		 	$banner    = json_decode($procedure->extras_en)->banner;
		 	$extras_en = array('banner'=>$banner);
		 }
		 
		 if($request->hasfile("page_banner")) {	
		 	 $folder        = 'pages/';
		 	 $bannerImage   = $request->file("page_banner");
		 	 $random_number = mt_rand(100000, 999999);
		 	 $bannerimgname = $random_number.$bannerImage->getClientOriginalName(); 
		 	 $bannerImage->move(public_path().'/images/pages/', $bannerimgname); 
		 	 $banner_image  = $folder.$bannerimgname;	
		 	 $extras_en	    = array('banner'=>$banner_image);
          }	
         
		$procedureSkinDataEn  =  array('available_skin_en_text'=>$available_skin_en, 'testimony_video'=>$video, 'first_banner'=>$first_banner, 'second_banner'=>$second_banner, 'work_step_1'=>$work_step_1_en, 'work_step_1'=>$work_step_1_en, 'work_step_2'=>$work_step_2_en, 'work_step_3'=>$work_step_3_en); 
		$procedureSkinDataFr  =  array('available_skin_fr_text'=>$available_skin_fr, 'testimony_video'=>$video, 'fisrt_banner'=>$first_banner, 'second_banner'=>$second_banner, 'work_step_1'=>$work_step_1_fr, 'work_step_2'=>$work_step_2_fr, 'work_step_3'=>$work_step_3_fr); 
		
		if($procedure !== null) {
		  $procedure->content_en =  json_encode($procedureSkinDataEn);
		  $procedure->extras_en  =  json_encode($extras_en);
		  $procedure->content_fr =  json_encode($procedureSkinDataFr);
			
		} else {
		  $procedure = new Page;
		  $procedure->template   = 'Skin Procedure';
		  $procedure->data_type  = 'skin-procdeure-data';
		  $procedure->title	 	 = 'Skin Procedure';
		  $procedure->content_en =  json_encode($procedureSkinDataEn);
		  $procedure->extras_en  =  json_encode($extras_en);
		  $procedure->content_fr =  json_encode($procedureSkinDataFr);
		}
		$procedure->save();
		return redirect()->back()->with('success', 'Updated successfully');
	 }
	 
	 /**
	  * Dental Procedure Content	   
	  * Return View
	 */
	 public function dentalProcedure() {
		 $banners 	 =  Banner::where('status','1')->get(['id','banner_name']);
		 $dentalprocedure  =  Page::where('template','Dental Procedure')->where('data_type','dental-procdeure-data')->first();
		 $data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		 if($dentalprocedure !== null) {
		 	$dentalprocedureDataen   = json_decode($dentalprocedure->content_en);
		 	$dentalprocedureDatafr = json_decode($dentalprocedure->content_fr);
		 	$extraData       = json_decode($dentalprocedure->extras_en);
		 	$data['banner_image']  = $extraData->banner;
		 	$data['procedure_en']  = $dentalprocedureDataen;
		 	$data['procedure_fr']  = $dentalprocedureDatafr;	
		 }
		//$images = "";
		 
		 return View('admin.pages.dentalprocedure',compact(['data', 'banners']));
	}
	 
	  /**
	  * Save Dental Procedure Content	  
	  * return back with response 
	 */
	 public function dentalProcedureSave(Request $request) {
		
		$validatedData 		     =  $request->validate([
			'testimony_video'	 => 'required', 
            'first_banner'		 => 'required', 
            'second_banner'		 => 'required', 
            'work_step_1_en'	 => 'required', 
            'work_step_1_fr'	 => 'required', 
            'work_step_2_en'	 => 'required', 
            'work_step_2_fr'	 => 'required', 
            'work_step_3_en'	 => 'required', 
            'work_step_3_fr'	 => 'required', 
            'available_hair_en'  => 'required', 
            'available_hair_fr'  => 'required', 
		]);
		
		$available_dental_en =  $request->input('available_hair_en');
		$available_dental_fr =  $request->input('available_hair_fr');
		$video 			     =  $request->input('testimony_video');
		$first_banner 	     =  $request->input('first_banner');
		$second_banner 	     =  $request->input('second_banner');
		$work_step_1_en      =  $request->input('work_step_1_en');
		$work_step_1_fr      =  $request->input('work_step_1_fr');
		$work_step_2_en      =  $request->input('work_step_2_en');
		$work_step_2_fr      =  $request->input('work_step_2_fr');
		$work_step_3_en      =  $request->input('work_step_3_en');
		$work_step_3_fr      =  $request->input('work_step_3_fr');
		
		
		
		 $extras_en  =  array('banner'=>'');
		 $procedure  =  Page::where('template','Dental Procedure')->where('data_type','dental-procdeure-data')->first();
		 
		 if($procedure !== null) {			
		 	$banner    = json_decode($procedure->extras_en)->banner;
		 	$extras_en = array('banner'=>$banner);
		 }
		 
		 if($request->hasfile("page_banner")) {	
		 	 $folder        = 'pages/';
		 	 $bannerImage   = $request->file("page_banner");
		 	 $random_number = mt_rand(100000, 999999);
		 	 $bannerimgname = $random_number.$bannerImage->getClientOriginalName(); 
		 	 $bannerImage->move(public_path().'/images/pages/', $bannerimgname); 
		 	 $banner_image  = $folder.$bannerimgname;	
		 	 $extras_en	    = array('banner'=>$banner_image);
          }	
         
		$procedureDentalDataEn  =  array('available_dental_en_text'=>$available_dental_en, 'testimony_video'=>$video, 'first_banner'=>$first_banner, 'second_banner'=>$second_banner, 'work_step_1'=>$work_step_1_en, 'work_step_1'=>$work_step_1_en, 'work_step_2'=>$work_step_2_en, 'work_step_3'=>$work_step_3_en); 
		$procedureDentalDataFr  =  array('available_dental_fr_text'=>$available_dental_fr, 'testimony_video'=>$video, 'fisrt_banner'=>$first_banner, 'second_banner'=>$second_banner, 'work_step_1'=>$work_step_1_fr, 'work_step_2'=>$work_step_2_fr, 'work_step_3'=>$work_step_3_fr); 
		
		if($procedure !== null) {
		  $procedure->content_en =  json_encode($procedureDentalDataEn);
		  $procedure->extras_en  =  json_encode($extras_en);
		  $procedure->content_fr =  json_encode($procedureDentalDataFr);
			
		} else {
		  $procedure = new Page;
		  $procedure->template   = 'Dental Procedure';
		  $procedure->data_type  = 'dental-procdeure-data';
		  $procedure->title	 	 = 'Dental Procedure';
		  $procedure->content_en =  json_encode($procedureDentalDataEn);
		  $procedure->extras_en  =  json_encode($extras_en);
		  $procedure->content_fr =  json_encode($procedureDentalDataFr);
		}
		$procedure->save();
		return redirect()->back()->with('success', 'Updated successfully');
	 }
	 
	  /**
	  * FAQ Content	   
	  * Return View
	 */
	 
	 public function getFaqs() {
		$get_faq  =  Page::where('template', 'FAQ')->paginate(5);
		
		$faqData     =  array();
		if($get_faq !== null) {
			foreach($get_faq as $fdata)
			{
				$faqDataen   = json_decode($fdata->content_en);
				$faqDatafr   = json_decode($fdata->content_fr);
				$faqtype     = $fdata->data_type;
				$data['id']  = $fdata->id;
				$data['answer_en']  = $faqDataen->answer;
				$data['question_en']  = $faqDataen->question;
				$data['answer_fr']  = $faqDatafr->answer;
				$data['question_fr']  = $faqDatafr->question;
				$data['data_type']  = $faqtype;
				$data['faq_data']  = $fdata;
				$faqData[] = $data;
			}
		}
		
		return View('admin.pages.faq',compact(['get_faq','faqData']));
	 }
	 
	 /*
     * Create function to add FAQ
     * @return response
    */
    public function addFaqs(Request $request) {
		
		 $question_en       = $request->input('question_en');
		 $answer_en 		= $request->input('answer_en');
		 $question_fr       = $request->input('question_fr');
		 $answer_fr 		= $request->input('answer_fr');
		 $faq_type    		= $request->input('faq_type');
		 $page_template 	= "FAQ";
		 
		 $content_en_text  =  array('question'=>$question_en, 'answer'=>$answer_en); 
		 $content_fr_text  = array('question'=>$question_fr, 'answer'=>$answer_fr); 
		
		 $page  	  	   =  new Page;
		 $page->template   =  $page_template;
		 $page->data_type  =  $faq_type;
		 $page->title 	   =  $page_template;
		 $page->content_en =  json_encode($content_en_text);	
		 $page->content_fr =  json_encode($content_fr_text); 	 
		 $page->save();
		 return Response::json(array('success'=>true,'message'=>'FAQ Addded Successfully'));
	}
	
	/*
     * Create function to update FAQ
     * @return response
    */
    public function updateFaqs(Request $request) {
		
		 $update_qes_en       = $request->input('update_qes_en');
		 $update_ans_en 	  = $request->input('update_ans_en');
		 $update_qes_fr       = $request->input('update_qes_fr');
		 $update_ans_fr 	  = $request->input('update_ans_fr');
		 $update_faq_type     = $request->input('update_faq_type');
		 $page_template 	  = "FAQ";
		 
		 $content_en_text  =  array('question'=>$update_qes_en, 'answer'=>$update_ans_en); 
		 $content_fr_text  = array('question'=>$update_qes_fr, 'answer'=>$update_ans_fr); 
		
		 $faqData =  Page::find($request->input('id'));
		 $faqData->template   =  $page_template;
		 $faqData->data_type  =  $update_faq_type;
		 $faqData->title 	   =  $page_template;
		 $faqData->content_en =  json_encode($content_en_text);	
		 $faqData->content_fr =  json_encode($content_fr_text); 	 
		 $faqData->save();
		 return Response::json(array('success'=>true,'message'=>'FAQ Updated Successfully'));
		  
	}
	
	/**
     * Create a function to delete FAQ.
     * @return response
    */
    public function deleteFaqs(Request $request)
    {
			$id = $request->input('id');
			Page::where('id',$id)->delete();		
			return Response::json(array('success'=>true,'message'=>'FAQ Deleted Successfully'));
    }
    
     /**
	  * Referral Content	   
	  * Return View
	 */
	 
	 public function referralRecord() {
		$referred_data = ReferralPoint::with('user')->paginate(10);
		
	    return view('admin.pages.referral', compact(['referred_data']));
	}
	
	public function referralPoints($id) {
		
		$user_id      = $id;
        $referred_data = ReferralData::with('user','ref_data')->where('user_id',$user_id)->get();
        
        //echo "<pre>";
        //print_r($referred_data);
        //echo "</pre>";
		
        return view('admin.pages.referraldetail', compact(['referred_data']));
        
		
	}
    
    /**
	  * Blog Content	   
	  * Return View
	 */
	 
	public function blogRecord() {
		$get_blogs  =  Blogs::paginate(10);
		return view('admin.pages.blogs', compact(['get_blogs']));
	}
	
	 /** 
	  * Blog add
	  * Return Response
	 */
	
	 public function addBlog(Request $request) {
		 
		 $title_en      = $request->input('blog_title_en');
		 $desc_en 		= $request->input('blog_des_en');
		 $title_fr      = $request->input('blog_title_fr');
		 $desc_fr 		= $request->input('blog_des_fr');
		 $date    		= $request->input('blogdate');
		 $status    	= $request->input('blog_status');
		 
		  if($request->hasfile("blog_image")) {
			 $allowedfileExtension = ['jpg','png','jpeg','gif'];	
		 	 $folder        = 'blog/';
		 	 $blogImage   = $request->file("blog_image");
		 	 $random_number = mt_rand(100000, 999999);
		 	 $extension = $blogImage->getClientOriginalExtension();
		 	 $blogimgname = $random_number.$blogImage->getClientOriginalName();
		 	 $blog_images  = $folder.$blogimgname;	
		 	 $check_type = in_array($extension , $allowedfileExtension);
		 	 if($check_type)
		 	 { 
		 	   $blogImage->move(public_path().'/images/blog/', $blogimgname);
			 }
			 else
			 {
				return Response::json(array('error'=>true,'message'=>'Sorry Only Upload png , jpg , gif images')); 
			 } 
		 	 
		  }
		  else
		  {
			$blog_images = "";  
		  }	
          
		 
		 $blog  	  	   =  new Blogs;
		 $blog->title_en   =  $title_en;
		 $blog->desc_en    =  $desc_en;
		 $blog->title_fr   =  $title_fr;
		 $blog->desc_fr    =  $desc_fr;	
		 $blog->blog_img   = $blog_images;	
		 $blog->date       =  $date;	 
		 $blog->status     =  $status;	 
		 $blog->save();
		 return Response::json(array('success'=>true,'message'=>'Blogs Addded Successfully'));
		
	}
	 /**
	  * Blog edit	   
	  * Return View
	 */
	 
	 public function updateBlog(Request $request) {
		 
		 $ublog_title_en       = $request->input('ublog_title_en');
		 $ublog_des_en 	  = $request->input('ublog_des_en');
		 $ublog_title_fr       = $request->input('ublog_title_fr');
		 $ublog_des_fr 	  = $request->input('ublog_des_fr');
		 $ublogdate     = $request->input('ublogdate');
		 $ublog_status     = $request->input('ublog_status');
		 $id = $request->input('blog_id');
		 
		if($request->hasfile("update_image")) {
			$image_val = Blogs::where('id', $id)->first();
			$file_path = public_path().'/images/'.$image_val->blog_img;
			 if(file_exists($file_path)) {
				@unlink($file_path);
			 }
			 $allowedfileExtension = ['jpg','png','jpeg','gif'];	
		 	 $folder        = 'blog/';
		 	 $blogImage   = $request->file("update_image");
		 	 $random_number = mt_rand(100000, 999999);
		 	 $extension = $blogImage->getClientOriginalExtension();
		 	 $blogimgname = $random_number.$blogImage->getClientOriginalName();
		 	 $blog_images  = $folder.$blogimgname;	
		 	 $check_type = in_array($extension , $allowedfileExtension);
		 	 if($check_type)
		 	 { 
		 	   $blogImage->move(public_path().'/images/blog/', $blogimgname);
		 	   
			 }
			 else
			 {
				return Response::json(array('error'=>true,'message'=>'Sorry Only Upload png , jpg , gif images')); 
			 } 
		 	 
		  }
		  else
		  {
			$blog_images = "";  
		  }	
		 
		
		 
		 $blog  	  	   =  Blogs::find($request->input('blog_id'));
		 $blog->title_en   =  $ublog_title_en;
		 $blog->desc_en    =  $ublog_des_en;
		 $blog->title_fr   =  $ublog_title_fr;
		 $blog->desc_fr    =  $ublog_des_fr;
		 $blog->blog_img   = $blog_images;		
		 $blog->date       =  $ublogdate;	 
		 $blog->status     =  $ublog_status;	 
		 $blog->save();
		 return Response::json(array('success'=>true,'message'=>'Blogs updated Successfully'));
		
	}
	
	 /** 
	  * Blog delete
	  * Return Response
	 */
	public function deleteBlog(Request $request)
    {
			$id = $request->input('id');
			$image_val = Blogs::where('id', $id)->first();
			$file_path = public_path().'/images/'.$image_val->blog_img;
			 if(file_exists($file_path)) {
				@unlink($file_path);
			 }
			Blogs::where('id',$id)->delete();		
			return Response::json(array('success'=>true,'message'=>'Blog Deleted Successfully'));
    }
}
