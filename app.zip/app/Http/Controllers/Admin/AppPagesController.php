<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use App\User;
use Image;
use Storage;
use App\Role;
use App\Offer;
use App\Banner;
use App\RoleUser;
use App\Doctors;
use App\Service;
use App\SubService;
use App\AppData;
use App\DoctorAssistant;
use App\DoctorTimeslot;
use App\WelcomePage;
use Auth;

class AppPagesController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
     
    public function __construct() {
		 
		$this->middleware(['auth','verified']);
	}
	
	/*
	 * App welcome page content
	**/	
	public function index(){
		$data = WelcomePage::all();
		return view('admin.mobile.welcomepage.read',compact(['data']));
	} 
	
	/*
	 * App welcome page content
	**/	
	public function editWelcome($id){
		$content = WelcomePage::findOrFail($id);
		return view('admin.mobile.welcomepage.edit',compact(['content']));
	} 
	
	
	/**
     * Create a function to add welcome page content.
     * @return redirct back with response
    */
    public function addContent(Request $request)
    {
		
        $random_number	  	= mt_rand(100000, 999999);
        $title_en  			= $request->input('title_en');
        $title_fr  			= $request->input('title_fr');
        $description_en  	= $request->input('description_en');
        $description_fr 	= $request->input('description_fr');
        $content_image    	= $random_number.$request->file('content_image')->getClientOriginalName();
        $file             	= $request->file('content_image');
		$folder 	      	= 'app/';
        $file->move(public_path().'/images/app/', $content_image);
		$ContentImage = $folder.$content_image;
		$content = WelcomePage::create(array(
            'title_en' 				=> $title_en,
			'title_fr' 		 		=> $title_fr,
			'description_en' 		=> $description_en,
			'description_fr' 		=> $description_fr,
			'image_name' 		 	=> $content_image,
			'image_path' 		 	=> $ContentImage,
		));
		if($content){
        	return redirect()->back()->with('success', 'Content Addedd Successfully');
		}else{
			return redirect()->back()->with('error', 'Something went wrong please try again');
		}
    }
    
	/**
     * Create a function to upade welcome page content.
     * @return redirct back with response
    */
    public function updateWelcome(Request $request)
    {
		 $validatedData = $request->validate([					
			'content_image'  => 'dimensions:min_width=400',
		]);
		
        $random_number	  	= mt_rand(100000, 999999);
        $id                 = $request->input('id');
        $title_en  			= $request->input('title_en');
        $title_fr  			= $request->input('title_fr');
        $description_en  	= $request->input('description_en');
        $description_fr 	= $request->input('description_fr');
        $file             	= $request->file('content_image');
		$content 						= WelcomePage::findOrFail($id);
		if($file != ""){
			$content_image    	= $random_number.$request->file('content_image')->getClientOriginalName();
			$folder 	      	= 'app/';
			$file->move(public_path().'/images/app/', $content_image);
			$ContentImage 					= $folder.$content_image;
		}else{
			$content_image = $content->image_name;
			$ContentImage  = $content->image_path;
		}
		$content->title_en 				= $title_en;
		$content->title_fr 		 		= $title_fr;
		$content->description_en 		= $description_en;
		$content->description_fr		= $description_fr;
		$content->image_name 		 	= $content_image;
		$content->image_path 		 	= $ContentImage;
		$content->save();
		if($content){
        	return redirect()->back()->with('success', 'Content Updated Successfully');
		}else{
			return redirect()->back()->with('error', 'Something went wrong please try again');
		}
    }
	
	
	/**
     * Create a function to delete content.
     * @return response
    */
    public function deleteContent(Request $request)
    {
    	$id = $request->input('id');
    	$content = WelcomePage::where('id',$id)->first();
    	 if(file_exists(public_path('/images/'.$content->image_name))){ //delete image if exist
			unlink(public_path('/images/'.$content->image_name));
		}
		$content->delete();	
		
    	return Response::json(array('success'=>true,'message'=>'Content Deleted Successfully'));
    }
	
    
    /*
     * Create function to get home content
     * @return View
    */
    public function homeContent() {
		$home    =  '';
		$banners = [];
		$homeBanners =  AppData::where('template','Home')->where('data_type','home-banners')->first();
		$homeBanners =  $homeBanners !== null ? json_decode($homeBanners->content_en, true) : ['first_banner'=>'','second_banner'=>''];
		$offers 	 =  Banner::where('status','1')->get(['id','banner_name']);
		$homeOffers  =  AppData::where('template','Home')->where('data_type','home-offers')->get();
		if($homeOffers)
		{
			foreach($homeOffers as $key=>$offer) {
				$offer_data = Banner::where('id',json_decode($offer->content_en)->offer)->first();
				if($offer_data)
				{
					$data['id'] 	= $offer->id;
					$data['offer'] = json_decode($offer->content_en)->offer;
					//$data['offer_name'] = Offer::where('id',json_decode($offer->content_en)->offer)->first()->offer_name_en;
					$offer_data = Banner::where('id',json_decode($offer->content_en)->offer)->first();
					
					$data['offer_name'] = $offer_data->banner_name;
					$banners[] 	= $data;
				}
			}
		}
		
		return view('admin.mobile.homepage.read',compact(['home','banners','offers','homeBanners']));
	}
	
    /*
     * Create function to save home content
     * @return response
    */
    public function addHomeContent(Request $request) {		
        
        $validatedData = $request->validate([					
			'first_banner'  => 'dimensions:min_width=1660',
            'second_banner'	=> 'dimensions:min_width=1660', 
		]);

        		
		$first_banner	= '';
		$second_banner	= '';
		$AppData	    =  AppData::where('template','Home')->where('data_type','home-banners')->first();
		if($AppData !== null) {			
		   $first_banner  =  json_decode($AppData->content_en)->first_banner;
		   $second_banner =  json_decode($AppData->content_en)->second_banner;			
		}
		
		if($request->hasfile("first_banner")) {	
			 $folder        = 'app/';
			 $firstImage    = $request->file("first_banner");
			 $random_number = mt_rand(100000, 999999);
			 $firstimgname  = $random_number.$firstImage->getClientOriginalName(); 
			 $firstImage->move(public_path().'/images/app/', $firstimgname); 
			 $first_banner  = $folder.$firstimgname;	
        }	
        
		if($request->hasfile("second_banner")) {	
			 $folder        = 'app/';
			 $secondImage   = $request->file("second_banner");
			 $random_number = mt_rand(100000, 999999);
			 $secondimgname = $random_number.$secondImage->getClientOriginalName(); 
			 $secondImage->move(public_path().'/images/app/', $secondimgname); 
			 $second_banner = $folder.$secondimgname;	
        }	
         
		$HomeData    =  array('first_banner'=>$first_banner, 'second_banner'=>$second_banner); 
		
		if($AppData !== null) {
		  $AppData->content_en =  json_encode($HomeData);
			
		} else {
		  $AppData = new AppData;
		  $AppData->template   = 'Home';
		  $AppData->data_type  = 'home-banners';
		  $AppData->content_en =  json_encode($HomeData);
		}
		$AppData->save();
		return redirect()->back()->with('success', 'Updated successfully');
		
	}
	
	/*
     * Create function to add app home page offers
     * @return response
    */
    public function addHomeBanner(Request $request) {
				
		  $AppData 			   =  new AppData;
		  $AppData->template   = 'Home';
		  $AppData->data_type  = 'home-offers';
		  $offerData		   =  array('offer'=>$request->input('offer'));
		  $AppData->content_en =  json_encode($offerData);
		  $AppData->save();
		  return Response::json(array('success'=>true,'message'=>'Banner Added Successfully'));
		  
	}
	
	/**
     * Create a function to delete app home offer.
     * @return response
    */
    public function deleteHomeBanner(Request $request)
    {
    	$id = $request->input('id');
    	AppData::where('id',$id)->delete();		
    	return Response::json(array('success'=>true,'message'=>'Banner Deleted Successfully'));
    }
    
    /*
     * Create function to update app home page offers
     * @return response
    */
    public function updateHomeBanner(Request $request) {
		  $id				   = $request->input('id');
		  $AppData 			   =  AppData::find($id);
		  $offerData		   =  array('offer'=>$request->input('offer'));
		  $AppData->content_en =  json_encode($offerData);
		  $AppData->save();
		  return Response::json(array('success'=>true,'message'=>'Offer Updated Successfully'));
		  
	}
	
	/*
	 * Hair Procedure Content
	*/
	 public function hairProcedure(){
		
		$banners = [];
		$procedureBanners =  AppData::where('template','Hair-Procedure')->where('data_type','hair-procedure')->first();
		$procedureBanners =  $procedureBanners !== null ? json_decode($procedureBanners->content_en, true) : ['first_banner'=>'','second_banner'=>''];
		$offers 	 	  =  Offer::where('status','1')->get(['id','offer_name_en']);
		$procedureOffers  =  AppData::where('template','Hair-Procedure')->where('data_type','hair-procedure')->get();
		foreach($procedureOffers as $key=>$offer) {
			 $offer_data = Offer::where('id',json_decode($offer->content_en)->offer)->first();
			 if(count($offer_data))
			 {
				$data['id'] 			= $offer->id;
				$data['service-id'] 	= json_decode($offer->content_en)->service;
				$data['offer']		    = json_decode($offer->content_en)->offer;
				$data['offer_name']    = Offer::where('id',json_decode($offer->content_en)->offer)->first()->offer_name_en;
				$data['service_name']  = SubService::where('id',json_decode($offer->content_en)->service)->first()->sub_name_en;
				$banners[] 		    = $data;
			 }
		}
		
		$subServices = SubService::where('service_id',1)->get();
		
		return view('admin.mobile.hairprocedure.read',compact(['banners','offers','subServices']));
	 }
	 
	
	/*
     * Create function to add app hair procedure offers
     * @return response
    */
    public function addHairProceduresOffers(Request $request) {
				
		  $AppData 			   =  new AppData;
		  $AppData->template   = 'Hair-Procedure';
		  $AppData->data_type  = 'hair-procedure';
		  $offerData		   =  array('offer'=>$request->input('offer'),'service' => $request->input('service'));
		  $AppData->content_en =  json_encode($offerData);
		  $AppData->save();
		  return Response::json(array('success'=>true,'message'=>'Offer Added Successfully'));
		  
	}
	
	/*
     * Create function to update app home page offers
     * @return response
    */
    public function updateHairProceduresOffers(Request $request) {
		  $id				   = $request->input('id');
		  $AppData 			   =  AppData::find($id);
		  $offerData		   =  array('offer'=>$request->input('offer'),'service' => $request->input('service'));
		  $AppData->content_en =  json_encode($offerData);
		  $AppData->save();
		  return Response::json(array('success'=>true,'message'=>'Offer Updated Successfully'));
		  
	}
	
	
	
	/*
	 * Time slot Content
	*/
	 public function timeslotData(){
		
		$slots = DoctorTimeslot::all();
		return view('admin.mobile.timeslot.slot',compact(['slots']));
	 }
	 
	
	/*
     * Create function to add Time slot
     * @return response
    */
    public function addTimeslot(Request $request) {
		
		 $start_time = $request->input('starttime');
		 $end_time = $request->input('endtime');
		
		 $check_availablity = DoctorTimeslot::where('start_time', $start_time)->where('end_time', $end_time)->first();
		
		 
		if($check_availablity != null)
		{
			return Response::json(array('error'=>true,'message'=>'You have been already entered this Timeslot'));
		}
		else
		{
			$DoctorTimeslot 		=  new DoctorTimeslot;
			$DoctorTimeslot->start_time  = $request->input('starttime');
			$DoctorTimeslot->end_time 	  =  $request->input('endtime');
			$DoctorTimeslot->status	  =  $request->input('status');
			$DoctorTimeslot->save();
			return Response::json(array('success'=>true,'message'=>'Timeslot Added Successfully'));
	    }
		  
	}
	
	/*
     * Create function to update Time slot
     * @return response
    */
    public function updateTimeslot(Request $request) {
				
		 $DoctorTimeslot =  DoctorTimeslot::find($request->input('id'));
		 $DoctorTimeslot->start_time  = $request->input('starttime');
		 $DoctorTimeslot->end_time 	  =  $request->input('endtime');
		 $DoctorTimeslot->status	  =  $request->input('status');
		 $DoctorTimeslot->save();
		 return Response::json(array('success'=>true,'message'=>'Timeslot Updated Successfully'));
		  
	}
	
	/**
     * Create a function to delete time slot.
     * @return response
    */
    public function deleteTimeslot(Request $request)
    {
    	$id = $request->input('id');
    	DoctorTimeslot::where('id',$id)->delete();		
    	return Response::json(array('success'=>true,'message'=>'Timeslot Deleted Successfully'));
    }
	
	 
	
}


