<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Auth;
use Image;
use Storage;
use App\Product;
use App\ProductGallery;
use App\Service;
use App\SubService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

class ProductsController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
    public function __construct()
    {
        $this->middleware('auth');
    }

	/**
     * Create a function to get all products.
     * @return products
    */
	public function getProducts()
    {
    	$products = Product::with('service')->paginate(5);
    	$services = Service::all();
    	return view('admin.shop.products',compact(['products','services']));
    }
    
    /**
     * search products.
     * @return products
    */
	public function searchProducts(Request $request)
    {
		$search_val = $request->input('q');
		$search_type = $request->input('search_type');
		$search_type1 = ucfirst($search_val);
		
		if($search_type == "product")
		{
			$products = Product::with('service')->where('product_name_en','LIKE','%'.$search_val.'%')->orWhere('product_price','LIKE','%'.$search_val.'%')->orWhere('stock','LIKE','%'.$search_val.'%')->get();
			if(count($products) != 0)
			{
				return response()->json(['success'=>true, 'data'=> $products]); 		
			}
			else
			{
				return response()->json(['success'=>false, 'data'=> $products]); 	
			}
		}
		else
		{
			$check_service_id = Service::where("service_name",$search_type1)->first();
			
			if(count($check_service_id) != 0)
			{
				$service_id = $check_service_id['id'];
				$products = Product::with('service')->where('cat_id',$service_id)->get();
				return response()->json(['success'=>true, 'data'=> $products]);
			}
			else
			{
				$products = [];
				return response()->json(['success'=>false, 'data'=> $products]); 	
			}
		}
    	
    }
    
	/**
     * Create a function to add product.
     * @return redirct back with response
    */
    public function addProduct(Request $request)
    {
		
        $random_number	  = mt_rand(100000, 999999);
        $product_name_en  = $request->input('product_name_en');
        $product_name_fr  = $request->input('product_name_fr');
        $product_desc_en  = $request->input('description_en');
        $product_desc_fr  = $request->input('description_fr');
        $product_price 	  = $request->input('product_price');
        $actual_price 	  = $request->input('product_actual_price');
        $stock            = $request->input('product_quantity');
        $status           = $request->input('product_status');
        $cid              = $request->input('service');
        $file             = $request->file('product_image');
        
        $discount_avl	  = $request->input('discount_on_prod');
        $discount_type	  = $request->input('discount_type');
        $discount_rate	  = $request->input('discount');
        
        $product_image    = $random_number.$request->file('product_image')->getClientOriginalName();
		$folder 	      = 'products/';
        $file->move(public_path().'/images/products/', $product_image);
        			
		// open an image file
		//$img = Image::make(public_path().'/products/'.$product_image);
		// now you are able to resize the instance generate thumbnail with Image Library
		//$img->resize(500, 300);		
		//$img->save(public_path().'/images/products/thumbs/'.$product_image);	
		
		
		$productImage = $folder.$product_image;
               
		$product = Product::create(array(
            'cat_id' 				 => $cid,
			'product_name_en' 		 => $product_name_en,
			'product_name_fr' 		 => $product_name_fr,
			'product_description_en' => $product_desc_en,
			'product_description_fr' => $product_desc_fr,
			'product_image' 		 => $product_image,
			'stock'					 => $stock,
			'product_price'			 => $product_price,
			'actual_price'			 => $actual_price,
			'status'				 => $status,
			'product_image'			 => $productImage,
			'discount_avl'			 => $discount_avl,
			'discount_type'			 => $discount_type,
			'discount_rate'			 => $discount_rate,
		));
		
		if($request->hasfile('photos')) {
			foreach($request->file('photos') as $image)
            {	
				$random_number 	  = mt_rand(100000, 999999);
                $name = $random_number.$image->getClientOriginalName();                
                $image->move(public_path().'/images/products/', $name);  
                $Productgallery 			 = new ProductGallery;
				$Productgallery->product_id  = $product->id;
				$Productgallery->image 		 = $folder.$name;
				$Productgallery->save();
            }
		}
		
		if($product){
        	return redirect()->back()->with('success', 'Product Addedd Successfully');
		}else{
			return redirect()->back()->with('error', 'Something went wrong please try again');
		}
    }

    /**
     * Create a function to get product detail by id.
     * @return redirct back with response
    */
    
    public function editProduct($id) {
		$product 	= Product::with('gallery')->find($id);	
		if($product === null)
		   abort(404);
    	$services = Service::all();
    	return view('admin.shop.editproduct',compact(['product','services']));
		
	}

    /**
     * Create a function to update product.
     * @return redirct back with response
    */
    public function updateProduct(Request $request)
    {
    	$prod_id		  = $request->input('id');
    	$Product		  =	Product::find($prod_id);
    	$random_number	  = mt_rand(100000, 999999);
        $product_name_en  = $request->input('product_name_en');
        $product_name_fr  = $request->input('product_name_fr');
        $product_desc_en  = $request->input('description_en');
        $product_desc_fr  = $request->input('description_fr');
        $product_price 	  = $request->input('product_price');
        $actual_price 	  = $request->input('product_actual_price');
        $stock            = $request->input('product_quantity');
        $status           = $request->input('product_status');
        $cid              = $request->input('service');
        $file             = $request->file('product_image');
        
        $discount_avl	  = $request->input('discount_on_prod');
        $discount_type	  = $request->input('discount_type');
        $discount_rate	  = $request->input('discount');
        
        $Product->cat_id 				 = $cid;
		$Product->product_name_en 		 = $product_name_en;
		$Product->product_name_fr 		 = $product_name_fr;
		$Product->product_description_en = $product_desc_en;
		$Product->product_description_fr = $product_desc_fr;
		$Product->stock					 = $stock;
		$Product->product_price			 = $product_price;
		$Product->actual_price			 = $actual_price;
		$Product->status				 = $status;
		
		$Product->discount_avl			 = $discount_avl;
		if( $discount_avl == 'Y') {
			$Product->discount_type		 = $discount_type;
			$Product->discount_rate		 = $discount_rate;
		} else {                        
			$Product->discount_type		 = null;
			$Product->discount_rate		 = null;
		}
		$folder 	      = 'products/';
        
        if($request->hasfile('product_image')) {
			$product_image    = $random_number.$request->file('product_image')->getClientOriginalName();			
			$file->move(public_path().'/images/products/', $product_image);
						
			// open an image file
			//$img = Image::make(public_path().'/products/'.$product_image);
			// now you are able to resize the instance generate thumbnail with Image Library
			//$img->resize(500, 300);		
			//$img->save(public_path().'/images/products/thumbs/'.$product_image);	
			
			$productImage = $folder.$product_image;
			$Product->product_image	 = $productImage;
		}     
		
		if($request->hasfile('photos')) {
			foreach($request->file('photos') as $image)
            {	
				$random_number 	  = mt_rand(100000, 999999);
                $name = $random_number.$image->getClientOriginalName();                
                $image->move(public_path().'/images/products/', $name);  
                $Productgallery 			 = new ProductGallery;
				$Productgallery->product_id  = $Product->id;
				$Productgallery->image 		 = $folder.$name;
				$Productgallery->save();
            }
		}
		     
				
        $update = $Product->save();               
		if($update){
        	return redirect()->back()->with('success', 'Product Addedd Successfully');
		}else{
			return redirect()->back()->with('error', 'Something went wrong please try again');
		}    	
    }

	/**
     * Create a function to delete product.
     * @return response
    */
    public function deleteProduct(Request $request)
    {
    	$pid = $request->input('id');
    	$product = Product::where('id',$pid)->first();
    	 if(file_exists(public_path('/images/'.$product->product_image))){ //delete image if exist
			unlink(public_path('/images/'.$product->product_image));
		}
		
		$gallery = ProductGallery::where('product_id',$pid)->get();
		if($gallery !== null) {
			foreach($gallery as $key=>$img) {
				if(file_exists(public_path('/images/'.$img->image))){ //delete image if exist
					unlink(public_path('/images/'.$img->image));
				}	
			}
		  $gallery->delete();
		}
		$product->delete();	
		
    	return Response::json(array('success'=>true,'message'=>'Product Deleted Successfully'));
    }
    
	/**
     * Create a function to delete product gallery image.
     * @return response
    */
    public function deleteProductGalleryImg(Request $request)
    {
    	$id		 		= $request->input('id');
		$ProductGallery = ProductGallery::find($id);
		
		if(file_exists(public_path('/images/'.$ProductGallery->image))){ //delete image if exist
			unlink(public_path('/images/'.$ProductGallery->image));
		}
		$ProductGallery->delete();
		return Response::json(array('success'=>true,'message'=>'Image Deleted successfully')); 
		   
    }
  
}
