<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Auth;
use Session;
use Validator;
use Image;
use Storage;
use URL;
use DB;
use App\Procedure;
use App\AppointmentList;
use App\User;
use App\Mail\PaymentlinkEmail;
use App\Mail\ImageuploadEmail;
use App\PaymentType;
use App\OperationList;
use App\ProcedureOption;
use App\GraftOption;
use App\OptionProbability;
use App\HairTransplantReport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Response;

class ProcedureController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
    public function __construct()
    {
        $this->middleware('auth');
    }
    

	public function procedurePrice()
    {
		$ProcedureOption = ProcedureOption::paginate(10);
		return view('admin.procedureprice',compact('ProcedureOption'));
		 
	}
	 public function updateprocedurePrice(Request $request) {
		
		 $procedure =  ProcedureOption::find($request->input('procedure_id'));
		 $procedure->option_name   =  $request->input('update_opn_name');
		 $procedure->discount_type  =  $request->input('update_discount_type');
		 $procedure->total_coast 	   =  $request->input('update_coast');
		 $procedure->discount =  $request->input('update_discount');
		 $procedure->description =  $request->input('update_des');
		 $procedure->save();
		 return Response::json(array('success'=>true,'message'=>'Procedure option price Updated Successfully'));
		  
	}
	
	/* procedure list display */
	
	public function procedureList($id)
	{
		//echo $id; die;
		$filter   = isset($_REQUEST["filter_by"]) ? $_REQUEST["filter_by"] : "";
		
		    if($filter == "clients") {				
				$ids = DB::table('procedures')
							  ->leftJoin('operation_lists', 'operation_lists.procedure_id', '=', 'procedures.id')
							  ->whereIn('procedures.track_status',['follow_up','review','completed'])
							  ->where('procedures.user_id',$id)
							  ->where('operation_lists.doctor_approved','=', '1')
							  ->where('operation_lists.user_approved','=', '1')
							  ->pluck('procedures.id');
			
			} else if($filter == "walkin") {								 
				 $ids = DB::table('procedures')
							  ->leftJoin('appointment_lists', 'appointment_lists.procedure_id', '=', 'procedures.id')
							  ->where('procedures.track_status', '=', 'visit_doc')
							  ->where('procedures.user_id',$id)
							  ->where('appointment_lists.visit_first', '=', 1)
							  ->pluck('procedures.id');
				 
			} else if($filter == "leads") {								 
				$ids = DB::table('procedures')
							  ->leftJoin('appointment_lists', 'appointment_lists.procedure_id', '=', 'procedures.id')
							  ->where('procedures.track_status', '=', 'visit_doc')
							  ->where('procedures.user_id',$id)
							  ->where('appointment_lists.visit_first', '=', 0)
							  ->pluck('procedures.id');
				
			
				 
			} else {				
				//$procedures = Procedure::where('user_id',$id)->with(['serviceDetail','Offer'])->orderby('id','desc')->get();
				$ids = Procedure::where('user_id',$id)->pluck('id');
			}
		  	
		  $ids  = (count($ids) > 0) ? array_unique($ids->toArray()) : array();
		  
		  $procedures = Procedure::whereIn('id',$ids)->with(['serviceDetail','Offer'])->orderby('id','desc')->get();
		 // echo "<pre>"; print_r($procedures); die;
		
		
		return view('admin.proceduredetail',compact(['procedures','id']));	
	}
	
	
	
	public function procedure_list_images($id, $pid)
	{
		
		$proceduresImg = DB::table('procedure_foloup_images')->select('images')->where('user_id', $id)->where('procedure_id', $pid)->get();
		
		$procedures = Procedure::where('user_id',$id)->with(['serviceDetail','Offer'])->orderby('id','desc')->get();
		return view('admin.procedureImages',compact(['procedures','id','proceduresImg']));	
	}
	
	
	
	//~ public function procedure_list_images()
	//~ {

		//~ //return view('admin.procedureImages');
		
		//~ //die;

		//~ $procedures = Procedure::where('user_id',$id)->with(['serviceDetail','Offer'])->orderby('id','desc')->get();
		//~ return view('admin.procedureImages',compact(['procedures','id']));	
	//~ }
	
	
	/* appoitment list display */
	
	public function appoitmentList($id,$pid)
	{
		$AppointmentLists 		= AppointmentList::where('user_id',$id)->where('status','1')->where('procedure_id',$pid)->with('serviceDetail')->with('doctorDetail')->get();
		return view('admin.appoitmentlist',compact(['AppointmentLists','id','pid']));
	}
	
	/* payment list display */
	
	public function paymentList($id,$pid)
	{
			$procedure = Procedure::with(['Offer','paymentOption'])->find($pid); 
			if($procedure){
				$track_status = $procedure->track_status; 
				$paymentTypes  = PaymentType::where('procedure_id',$pid)->get();
				$cash_payment   = "0";
				$online_payment = "0";
				if(!$paymentTypes->isEmpty()){
					foreach($paymentTypes as $paymentType){
						if($paymentType->payment_type == "cash"){
							$cash_payment   += $paymentType->amount;
						}else{
							$online_payment += $paymentType->amount;
						}
					}	
				}
			}
			$AppointmentList = AppointmentList::where('user_id',$id)->where('status','1')->with(['serviceDetail','doctorDetail'])->first();			
				//echo "<pre>"; print_r($AppointmentList); die;		
			$OperationList   = OperationList::where('user_id',$id)->where('status','1')->where('procedure_id',$pid)->first();
			
			return View('admin.paymentlist',compact(['AppointmentList','id','pid','OperationList','procedure','cash_payment','online_payment']));
	}
	
	public function sendPaymentLink($id,$pid) {
		$user = User::where('id',$id)->with('userDetail')->first();
		//$useremail = $user->email;
		$useremail = "dottechnologies890@gmail.com";
		$username = $user->name;
		$baseURL = URL::to('/');
		$link = $baseURL.'/user/view/procedure/'.$pid.'/payment';
		$data = array('payment_link' => $link,'username' => $username);
		Mail::to($useremail)->send(new PaymentlinkEmail($data));
		 if (Mail::failures()) {
			return redirect()->back()->with('message', 'Mail send error !!');
		}
		else
		{
			return redirect()->back()->with('message', 'Mail send successfully !!');
		}	
	}
	
	public function imageuploadLink($id,$pid) {
		$user = User::where('id',$id)->with('userDetail')->first();
		//$useremail = $user->email;
		$useremail = "dottechnologies890@gmail.com";
		$username = $user->name;
		$baseURL = URL::to('/');
		$link = $baseURL.'/user/view/procedure/'.$pid.'/followup';
		$data = array('image_link' => $link,'username' => $username);
		$mail = Mail::to($useremail)->send(new ImageuploadEmail($data));
		if($mail) {
			return redirect()->back()->with('message', 'Mail send successfully !!');
		} else {
			return redirect()->back()->with('message', 'Mail send error !!');
		}
	}
	
	/**
     * Function to view self analysis report by id as a link for selfanalysis page.
     * @return view
    */
	public function selfAnalysisReport($id)
	{	
		$report    = HairTransplantReport::with(['user','applied_offer'])->find($id);
		
		if($report == null) {
			return view('admin.procedurereport',compact(['report']));
		}
		
		$breakDown = '';
		$services  = 2; // 2 is an id, for hair transplant
		if($report->sitting >= 1) {			
			$endBreakDown = $report->total_graft - (5000 * ($report->sitting - 1));
			
			for($i=1; $i<=$report->sitting; $i++ ) {
				if($i == $report->sitting ) {
					$breakDown .= "Sitting ".$i." ".$endBreakDown;
				} else {
					$breakDown .= " Sitting ".$i." 5000 "; 	
				}		
			}
			
		}
		
		$countZones = count(explode(",",$report->affected_ids));
		 $damage    = 14.2857 * $countZones;
		 $healthy   = 100 - $damage; 
		
		$region     = $report->city;				
		
		
		/* graft distribution data */
		$graftArea = $report->affected_ids;
		if($graftArea == "1,2,3,4"){
		   $graftOption = "option1";
		}elseif($graftArea == "1,2,3,4,6"){
		   $graftOption = "option2";
		}elseif($graftArea == "1,2,3,4,5,6"){
		   $graftOption = "option3";
		}elseif($graftArea == "1,2,3,4,5,6,7"){
		   $graftOption = "option4";
		}elseif($graftArea == "1,2"){
		   $graftOption = "option5";
		}elseif($graftArea == "1,2,3"){
		   $graftOption = "option6";
		}else{
			$graftOption = "";
		}
		$GraftOptions 		=  GraftOption::where('option_type',$graftOption)->get();
		
		/* get offer code start here.. */
		if(!$GraftOptions->isEmpty()){
			$required_graft = $GraftOptions[0]->grafts;
			$graft_array = explode('-', $required_graft);
			$min_graft  = $graft_array[0];
			$max_graft  = $graft_array[1];
		}else{
			$required_graft = "0";	
			$min_graft = "0";
			$max_graft = "0";
		}
		
		$OptionProbability  =  OptionProbability::where('option_type',$graftOption)->get();		
		return view('admin.procedurereport',compact(['report','breakDown', 'damage', 'healthy','GraftOptions','OptionProbability']));
	}	
	
    
}
