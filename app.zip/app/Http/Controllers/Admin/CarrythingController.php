<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use App\User;
use App\Service;
use App\SubService;
use App\BeforeAfterReview;
use App\ProcedureReview;
use Auth;
use App\CarryThing;


class CarrythingController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
     
    public function __construct() {
		 
		$this->middleware(['auth']);
	}
	
	/*
	 * Before After Images
	 * @return View
	*/	
	public function haircarrything(){
		$services   = Service::all();
		$subservices =  SubService::where('service_id',1)->get();
		$reminders =  CarryThing::where('service_id',1)->get();
		return View('admin.pages.haircarrything',compact(['subservices', 'services', 'reminders']));
	}
	public function skincarrything(){
		$services   = Service::all();
		$subservices =  SubService::where('service_id',2)->get();
		$reminders =  CarryThing::where('service_id',2)->get();
		//echo "<pre>";
		//print_r($reminders);
		//echo "</pre>";
		
		//die;
		return View('admin.pages.skincarrything',compact(['subservices', 'services', 'reminders']));
	}
	public function dentalcarrything(){
		$services   = Service::all();
		$subservices =  SubService::where('service_id',3)->get();
		$reminders =  CarryThing::where('service_id',3)->get();
		return View('admin.pages.dentalcarrything',compact(['subservices', 'services', 'reminders']));
	}	
	/**
	  * Save Follow Up Reminder
	  * return Response  
    */	 
	public function saveCarryThings(Request $request) {
					 
		$CarryThing = new CarryThing;		
		$CarryThing->title  = $request->input('carry_title');
		$CarryThing->service_id	  = $request->input('service');
		$CarryThing->sub_service_id  = $request->input('sub_service');
		$CarryThing->description	 = $request->input('description');
		$CarryThing->status	 = $request->input('carray_status');
		$CarryThing->carry_type  = $request->input('carray_type');		
        $CarryThing->save();
        return back()->with('success', 'Carry Things Added Successfully');
	 } 
	 
	 /**
	  * Delete Follow Up Reminder
	  * @return Response
	*/
	public function deleteCarryThings(Request $request) {
		
	$id = $request->input('id');
	CarryThing::where('id',$id)->delete();		
	   return Response::json(array('success'=>true,'message'=>'Carry Things Deleted Successfully'));
	} 
	
	/**
	  * Update Follow Up Reminder
	  * @return Response
	*/
	 public function updateCarryThings(Request $request) {
		
		$CarryThing = CarryThing::find($request->input('id'));
		
		$CarryThing->title  = $request->input('update_title');
		$CarryThing->sub_service_id  = $request->input('update_subservice');
		$CarryThing->description	  = $request->input('update_desc');
		$CarryThing->status  = $request->input('update_status');
		$CarryThing->carry_type  = $request->input('carray_type');
				
        $CarryThing->save();	
        return back()->with('success', 'Carry Things Updated Successfully');	
	}		
}
