<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class DropdownController extends Controller
{
    
        public function getStateList(Request $request)
        {
            $states = DB::table("states")
            ->where("country_id",$request->country_id)
            ->pluck("name","id");
            return response()->json($states);
        }

        public function getCityList(Request $request)
        {
            $cities = DB::table("cities")
            ->where("state_id",$request->state_id)
            ->pluck("name","id");
            return response()->json($cities);
        }
        
        public function getAllCities($country)
        {  
			$country_id = DB::table("countries")->where("name",$country)->pluck('id');			
            $cities = DB::table("cities")
            ->where("country_id",$country_id)
            ->pluck("name");
            return response()->json($cities);
        }
        
        public function getCities(){
			$cities = DB::table("cities")->orderBy('name','asc')
            ->pluck("name","id");
            $html = '<select name="city" id="city" class="form-control">';
            if($cities){
				foreach($cities as $key => $value){
					$html .= '<option value="'.$value.'">'.$value.'</option>';
				}
			}
			$html .= '</select>';
            return response()->json($html);
		}
}
