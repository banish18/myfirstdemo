<?php
namespace App\Http\Controllers;
use Auth;
use DB;
use Session;
use App\SmsApi;
use App\ProcedureOtp;
use DateTime;
use DateInterval;
use App\Countries;
use App\User;
use App\UserDetail;
use App\Role;
use App\Banner;
use App\Page;
use App\Offer;
use App\TempOrder;
use App\Order;
use App\AppointmentList;
use App\OrderDetail;
use App\SubService;
use App\BeforeAfterImage;
use App\BeforeAfterReview;
use App\ProcedureReview;
use App\GraftOption;
use App\HairTransplantReport;
use App\Procedure;
use App\ProcedureOption;
use App\Mail\WelcomeMail;
use App\Mail\ExpertTalkEmail;
use App\GraftRate;
use App\TalkToExpert;
use App\OptionProbability;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str; 
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Response;

class ProcedureController extends Controller
{
	
	/*
	 * Function to send otp for procedure verification 
	 * @return otp
	*/
	public function verificationOTP($phone) {
		$time 	 = new DateTime(date('Y-m-d H:i:s'));
		$time->add(new DateInterval('PT5M'));
		$expTime = $time->format('Y-m-d H:i:s');
		$OTP     =  mt_rand(100000, 999999);
		
		$ProcedureOtp  = ProcedureOtp::firstOrNew(['phone'=>$phone]);
		$ProcedureOtp->phone  =  $phone;
		$ProcedureOtp->otp 	  =  $OTP;
		$ProcedureOtp->expired_at = $expTime;							
		$ProcedureOtp->save();
		
		$message	 = "Welcome to Kabera Gloabal. Please use this otp to proceed your procedure. (".$OTP .")";
		$SmsApi 	 =  new SmsApi();
		if($SmsApi->sendSMS($phone, $message)) {
			return Response::json(array('success'=>true, 'otp'=>$OTP, 'message'=>'OTP Sent Successfully')); //remove otp key when site will be live
		} else {
			return Response::json(array('success'=>false,'message'=>'Error Occured'));			
		}
	}
	
	/*
	 * Function to send otp for procedure verification 
	 * @return otp
	*/
	public function matchProcedureOTP(Request $request) {
		$verifyUser	  = ProcedureOtp::where('phone', $request->input('phone'))->first();
       
        if(isset($verifyUser) ) {
		
			$d1 = new DateTime(date('Y-m-d H:i:s'));
			$d2 = new DateTime($verifyUser->expired_at);
			if($verifyUser->otp == $request->input('otp') && $d1 <= $d2) {					
				return Response::json(array('success'=>true,'message'=>'OTP Match'));								
			}else if($verifyUser->otp == $request->input('otp') && $d1 > $d2) {
				return Response::json(array('success'=>false, 'message'=>'OTP Expired'));		
			} else {
				return Response::json(array('success'=>false, 'message'=>'OTP Not Match'));
			}
                
        }else{
            return Response::json(array('success'=>false, 'message'=>'Your account not identified'));
        }		
	}
	 
	/*
     * Function to get hair procedure.
     * @return view
    */
	public function hairProcedure()
	{
		 $services	    =  SubService::where('service_id', 1)->get();	
		 $procedure     =  Page::where('template','Hair Procedure')->where('data_type','hair-procdeure-data')->first();
		 $data 		    =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		 if($procedure !== null) {
			$procedureData         = json_decode($procedure->content_en);
			$procedureDatafr       = json_decode($procedure->content_fr);
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
			$data['first_offer']   = Banner::find($procedureData->first_banner);	
			$data['second_offer']  = Banner::find($procedureData->second_banner);		
		 }
		 
		$images    = BeforeAfterImage::where('service_id',2)->get();
		$bareviews = BeforeAfterReview::where('service_id',2)->where('review_status','1')->get();
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		
		$percentage = 0;
		if($count){
			$percentage 	   =  array();
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}
		
		return view('procedure.hair.hair',compact(['services','images', 'data', 'bareviews', 'reviews', 'count', 'avrage', 'percentage']));
	}
	
	/* 
	 * Function to Save Hair Procedire Data and Register User 
	*/
	
	public function saveHairReport(Request $request) {
			$data  = $request->all();
			
		if (Auth::check()) { // The user is logged in...
			$user   = Auth::user();			
			
		} else {
			$validatedData = $request->validate([
				'email' => 'required|email|unique:users',
				'phone'	=> 'required|min:9|unique:users', 
			]);
			
			$password = Str::random(8);
			$user 	  = User::create([
				'customer_number'   => mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999),
				'name'        		=> $data['name'],
				'email'       		=> $data['email'],
				'phone'       		=> $data['phone'],
				//'password'    		=> Hash::make($password),
				'api_token'   		=> Str::random(60),
				'role'	      		=> '3',
				'isVerified'  		=>  1,
				'email_verified_at' => date("Y-m-d h:i:s")
			]);
			$user
		   ->roles()
		   ->attach(Role::where('name', 'user')->first());
		   
		    // Create user detail when user is created
			$UserDetail = new UserDetail;
			$UserDetail->user_id =  $user->id;
			
			
			if(isset($_COOKIE['device_id'])){
			$device_id = 	$_COOKIE['device_id'];
			DB::table('users')->where('id', $UserDetail->user_id)->update(['device_id' => $device_id]);
		}
			
			$UserDetail->save();
        
		   $mdata['email']     = $data['email'];
		   $mdata['name']      = $data['name'];
		   Mail::to($data['email'])->send(new WelcomeMail($mdata));
		   
		   Auth::loginUsingId($user->id);
		}
		
        if($user) {	
		   $images = array();
		   $HairReport = HairTransplantReport::with(['user','applied_offer'])->where('user_id', Auth::user()->id)->where('appointment_status', 0 )->first(); 
		   if($HairReport == null) {   
				$HairReport = new HairTransplantReport;
		   } else {
			   if(!empty($HairReport->affected_gallery)) {
				   foreach(explode(",", $HairReport->affected_gallery) as $img) {					   					
						array_push($images , $img);
					}
			   }
		   }
		   
		   $hairPerGraft = 2; //hair per grafts
		   $rate         = env('FUE_GRAFT_RATE'); //default per graft rate
		   $grafts = array(1000,2000,1200,1500,2000,1500,700); //graft values define by kabera statically			 

		   $graftRate     = GraftRate::where('state',$data['state'])->where('city',$data['city'])->first(); 
		   if($graftRate !== null) {
			 $rate = $graftRate->graft_rate;
		   } 	
		   
		   $totalGraft   = 0; 
		   
		   
		   //echo '<pre>'; print_r($data); die;
		   
		   
		   
		  /* foreach($data['area'] as $area ) { // Old graft calculation
			 $totalGraft +=   $grafts[$area-1];			   
		   }*/
		   /* New graft calculation */
		   $procedure_stat = 'fix';
		   $graftArea = implode(',',$data['area']);
		   if($graftArea == "1,2,3,4"){
			   $totalGraft = "5500";
		   }elseif($graftArea == "1,2"){
			   $totalGraft = "3000";
		   }elseif($graftArea == "1,2,3"){
			   $totalGraft = "4500";
		   }elseif($graftArea == "1,2,3,4,6"){
			   $totalGraft = "5500";
		   }elseif($graftArea == "1,2,3,4,5,6"){
			   $totalGraft = "4000";
		   }elseif($graftArea == "1,2,3,4,5,6,7"){
			   $totalGraft = "2500";
		   }else{
			   $totalGraft = "0";
			   $procedure_stat = 'consult';
		   }
		   $sitting	 				      = ($totalGraft/5000 > 1) ? (int)($totalGraft/5000) +1 : 1; //get total sittings		   
		   $totalHair   				  = $totalGraft * $hairPerGraft; 
		   $HairReport->user_id		      = $user->id;
		   $HairReport->affected_ids	  = implode(",",$data['area']);
		   $HairReport->username		  = $data['name'];
		   $HairReport->service_id	      = $request->service_id;
		   $HairReport->total_graft	      = $totalGraft;
		   //$HairReport->service_id	      = $data['service_id'];
		   $HairReport->total_hair	      = $totalHair;
		   $HairReport->medical_condition = $data['medical'];
		   $HairReport->age 			  = $data['age'];
		   $HairReport->country 		  = $data['country'];
		   $HairReport->state	 		  = $data['state'];
		   $HairReport->city	 		  = $data['city'];
		   $HairReport->cost_per_graft	  = $rate;
		   $HairReport->total_cost		  = $totalGraft*$rate;
		   $HairReport->sitting		  	  = $sitting;
		   $HairReport->transplant_type	  = 'fue';
		   $HairReport->procedure_stat	  = $procedure_stat;
		   
		   $username = User::find($user->id);
		  // $username->name = $data['name'];
		   $username->save();
		   
		   if( $data['update_on_profile'] == '1') {			   
			   $userProfile = UserDetail::where('user_id', $user->id)->first(); 
			   $userProfile->country =  $data['country'];
			   $userProfile->state   =  $data['state'];
			   $userProfile->city	 =  $data['city'];
			   $userProfile->age 	 =  $data['age'];
			   $userProfile->save();
		   }
		   Session::put('region', $data['city']); // update region session value
		   
		   		  
		   if($request->hasfile('photos')) 
			{
				foreach($request->file('photos') as $image)
				{	
					$folder           = 'transplant/';
					$random_number 	  = mt_rand(100000, 999999);
					$name = $random_number.$image->getClientOriginalName();                
					$image->move(public_path().'/images/transplant/', $name);                  
					array_push($images , $folder.$name);
				}
			}			
			$HairReport->affected_gallery = implode(",",$images);			
			$HairReport->save();	
			
			
			return redirect('/procedure/hair/'.$HairReport->id.'/report');	 
	    }	
	}
	 	
	/**
     * Function to redirect page hairtransplant.
     * @return view
    */	    
	public function hairTransplant()
	{	 
		$hairTransplant     =  Page::where('template','Hair Transplant')->where('data_type','hair-transplant-data')->first();
		$data 		  	    =  array('transplant_en'=>'', 'transplant_fr'=>'');
		if($hairTransplant !== null) {
			$transplantData   = json_decode($hairTransplant->content_en);
			$transplantDatafr = json_decode($hairTransplant->content_fr);
			$data['transplant_en'] = $transplantData;
			$data['transplant_fr'] = $transplantDatafr;	
		}
		$report = array();	
		
	    if (Auth::check()) {
			
			$report = HairTransplantReport::with(['user','applied_offer'])->where('user_id', Auth::user()->id)->where('appointment_status', 0 )->first(); 
			if($report == null) {
				$report = array();
			}
		}
		
		if (!empty(Auth::user())){
		$User  = UserDetail::where('user_id',  Auth::user()->id)->first();
		//print_r($hairTransplant);die;
		}
		if(isset($_COOKIE['device_id'])){
		$device_id = 	$_COOKIE['device_id'];
		DB::table('users')->where('id', Auth::user()->id)->update(['device_id' => $device_id]);	
		
		}
		
		$countries = Countries::all();		
		return view('procedure.hair.hairtransplant',compact(['data','report','countries','User']));
	}
	
	/**
     * Function to view final hair transplant report by id.
     * @return view
    */
	public function hairReport($id)
	{	
		$report    = HairTransplantReport::with(['user','applied_offer'])->where('id',$id)->where('appointment_status','!=',1)->first();
		
		if($report == null) {
			return abort(403);
		}
		if(Auth::user()->id != $report->user_id) {
			return abort(401);
		}
		$breakDown = '';
		$services  = 2; // 2 is an id, for hair transplant
		if($report->sitting >= 1) {			
			$endBreakDown = $report->total_graft - (5000 * ($report->sitting - 1));
			
			for($i=1; $i<=$report->sitting; $i++ ) {
				if($i == $report->sitting ) {
					$breakDown .= "Sitting ".$i." ".$endBreakDown;
				} else {
					$breakDown .= " Sitting ".$i." 5000 "; 	
				}		
			}
			
		}
		
		$countZones = count(explode(",",$report->affected_ids));
		$damage    = 14.2857 * $countZones;
		$healthy   = 100 - $damage; 
		
		$region     = $report->city;				
		$offers     = Offer::where('services',$services)->get();
		$cityOffers = [];
			foreach($offers as $key=>$offer) {
			  if($offer->city) {
			
					if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
						$cityOffers[] = $offer;
					}
				} else {
					$cityOffers[] = $offer;
					
				}
			}	
		$offers	   = $cityOffers;
		$images    = BeforeAfterImage::where('service_id',$services)->get();
		$bareviews = BeforeAfterReview::where('service_id',$services)->where('review_status','1')->get();
		
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',$services)->avg('rating');
		
		$percentage = 0;
		if($count){
			$percentage 	   =  array();		
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}	
		
		/* graft distribution data */
		$graftArea = $report->affected_ids;
		if($graftArea == "1,2,3,4"){
		   $graftOption = "option1";
		}elseif($graftArea == "1,2,3,4,6"){
		   $graftOption = "option2";
		}elseif($graftArea == "1,2,3,4,5,6"){
		   $graftOption = "option3";
		}elseif($graftArea == "1,2,3,4,5,6,7"){
		   $graftOption = "option4";
		}elseif($graftArea == "1,2"){
		   $graftOption = "option5";
		}elseif($graftArea == "1,2,3"){
		   $graftOption = "option6";
		}else{
			$graftOption = "";
		}
		$GraftOptions 		=  GraftOption::where('option_type',$graftOption)->get();
		
		/* get offer code start here.. */
		if(!$GraftOptions->isEmpty()){
			$required_graft = $GraftOptions[0]->grafts;
			$graft_array = explode('-', $required_graft);
			$min_graft  = $graft_array[0];
			$max_graft  = $graft_array[1];
		}else{
			$required_graft = "0";	
			$min_graft = "0";
			$max_graft = "0";
		}
		
		
		//$total_offer = count($offers);
		//
		//$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->get();
		//$inrelevent_offer = Offer::where('services',$services)->whereNotBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take(10)->get();
		//$count_relevent_offer = count($relevent_offer);
		//$count_inrelevent_offer = count($inrelevent_offer);
		//
		//if($count_relevent_offer >= 16)
		//{
		//	$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take(16)->get();
		//	$inrelevent_offer = [];
		//}
		//else
		//{
		//	$pending_graft = 16 - $count_relevent_offer;
		//	$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take(16)->get();
		//	$inrelevent_offer = Offer::where('services',$services)->whereNotBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take($pending_graft)->get();
		//}
		
		
		
		/* today code */
		
		$limit = 8;
		
		$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->get();
		
		$count_relevent_offer = count($relevent_offer);
		$total_offer = count($offers);
		if($count_relevent_offer >= $limit)
		{
			$used_relevent = $limit;
			$used_inrelevent = 0;
		}
		else
		{
			$used_relevent = $count_relevent_offer;
			$used_inrelevent = $limit - $count_relevent_offer;
		}
		
		if($count_relevent_offer >= $limit)
		{
			$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take($limit)->get();
			$inrelevent_offer = [];
		}
		else
		{
			$pending_graft = $limit - $count_relevent_offer;
			$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take($limit)->get();
			$inrelevent_offer = Offer::where('services',$services)->whereNotBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take($pending_graft)->get();
		}
		$OptionProbability  =  OptionProbability::where('option_type',$graftOption)->get();	
		return view('procedure.hair.hairreport',compact(['report', 'offers', 'images', 'bareviews', 'breakDown', 'reviews', 'count', 'avrage', 'percentage', 'damage', 'healthy','GraftOptions','OptionProbability','relevent_offer','inrelevent_offer','total_offer','min_graft','max_graft','used_relevent','used_inrelevent','limit']));
	}
	
	
	/**
     * Function to view self analysis report by id as a link for selfanalysis page.
     * @return view
    */
	public function selfanalysisReport($id)
	{	
		$report    = HairTransplantReport::with(['user','applied_offer'])->where('id',$id)->first();
		
		if($report == null) {
			return abort(403);
		}
		if(Auth::user()->id != $report->user_id) {
			return abort(401);
		}
		$breakDown = '';
		$services  = 2; // 2 is an id, for hair transplant
		if($report->sitting >= 1) {			
			$endBreakDown = $report->total_graft - (5000 * ($report->sitting - 1));
			
			for($i=1; $i<=$report->sitting; $i++ ) {
				if($i == $report->sitting ) {
					$breakDown .= "Sitting ".$i." ".$endBreakDown;
				} else {
					$breakDown .= " Sitting ".$i." 5000 "; 	
				}		
			}
			
		}
		
		$countZones = count(explode(",",$report->affected_ids));
		 $damage    = 14.2857 * $countZones;
		 $healthy   = 100 - $damage; 
		
		$region     = $report->city;				
		//$offers     = Offer::where('services',$services)->get();
		//$cityOffers = [];
		//	foreach($offers as $key=>$offer) {
		//	  if($offer->city) {
		//	
		//			if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
		//				$cityOffers[] = $offer;
		//			}
		//		} else {
		//			$cityOffers[] = $offer;
		//			
		//		}
		//	}	
		//$offers	   = $cityOffers;
		//$images    = BeforeAfterImage::where('service_id',2)->get();
		//$bareviews = BeforeAfterReview::where('service_id',2)->where('review_status','1')->get();
		//
		//$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		//$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		//$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		//
		//$percentage = 0;
		//if($count){
		//	$percentage 	   =  array();		
		//	for($i=1; $i<=5; $i++ ){
		//		$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
		//			$x = $rats;
		//			$total = $count;
		//			$percentage[$i] = ($x*100)/$total;
		//	}
		//}	
		
		/* graft distribution data */
		$graftArea = $report->affected_ids;
		if($graftArea == "1,2,3,4"){
		   $graftOption = "option1";
		}elseif($graftArea == "1,2,3,4,6"){
		   $graftOption = "option2";
		}elseif($graftArea == "1,2,3,4,5,6"){
		   $graftOption = "option3";
		}elseif($graftArea == "1,2,3,4,5,6,7"){
		   $graftOption = "option4";
		}elseif($graftArea == "1,2"){
		   $graftOption = "option5";
		}elseif($graftArea == "1,2,3"){
		   $graftOption = "option6";
		}else{
			$graftOption = "";
		}
		$GraftOptions 		=  GraftOption::where('option_type',$graftOption)->get();
		
		/* get offer code start here.. */
		if(!$GraftOptions->isEmpty()){
			$required_graft = $GraftOptions[0]->grafts;
			$graft_array = explode('-', $required_graft);
			$min_graft  = $graft_array[0];
			$max_graft  = $graft_array[1];
		}else{
			$required_graft = "0";	
			$min_graft = "0";
			$max_graft = "0";
		}
		
		
		//$total_offer = count($offers);
		//
		//$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->get();
		//$inrelevent_offer = Offer::where('services',$services)->whereNotBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take(10)->get();
		//$count_relevent_offer = count($relevent_offer);
		//$count_inrelevent_offer = count($inrelevent_offer);
		//
		//if($count_relevent_offer >= 16)
		//{
		//	$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take(16)->get();
		//	$inrelevent_offer = [];
		//}
		//else
		//{
		//	$pending_graft = 16 - $count_relevent_offer;
		//	$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take(16)->get();
		//	$inrelevent_offer = Offer::where('services',$services)->whereNotBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take($pending_graft)->get();
		//}
		
		
		
		/* today code */
		
		//$limit = 8;
		//
		//$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->get();
		//
		//$count_relevent_offer = count($relevent_offer);
		//$total_offer = count($offers);
		//if($count_relevent_offer >= $limit)
		//{
		//	$used_relevent = $limit;
		//	$used_inrelevent = 0;
		//}
		//else
		//{
		//	$used_relevent = $count_relevent_offer;
		//	$used_inrelevent = $limit - $count_relevent_offer;
		//}
		//
		//if($count_relevent_offer >= $limit)
		//{
		//	$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take($limit)->get();
		//	$inrelevent_offer = [];
		//}
		//else
		//{
		//	$pending_graft = $limit - $count_relevent_offer;
		//	$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take($limit)->get();
		//	$inrelevent_offer = Offer::where('services',$services)->whereNotBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->skip(0)->take($pending_graft)->get();
		//}
		
		$OptionProbability  =  OptionProbability::where('option_type',$graftOption)->get();
		
		//return view('procedure.hair.hairreport',compact(['report', 'offers', 'images', 'bareviews', 'breakDown', 'reviews', 'count', 'avrage', 'percentage', 'damage', 'healthy','GraftOptions','OptionProbability','relevent_offer','inrelevent_offer','total_offer','min_graft','max_graft','used_relevent','used_inrelevent','limit']));
		
		return view('procedure.hair.selfanalysis',compact(['report','breakDown', 'damage', 'healthy','GraftOptions','OptionProbability']));
	}
	
	
	
	
	/* 
	 * Function to delete affected image
	*/
	public function removeAffectedImage(Request $request) {
		
		$data = $request->all();
		$name = $data['name']; 
		$id   = $data['p_id'];
		$HairReport = HairTransplantReport::find($id); 
		if(!empty($HairReport->affected_gallery)) {
		   $images = explode(",", $HairReport->affected_gallery);
		  
			   if(file_exists(public_path('/images/'.$name))) { //delete image if exist
					unlink(public_path('/images/'.$name));
				}						
				
				if (($key = array_search($name, $images)) !== false) {
					unset($images[$key]);
				}
		$HairReport->affected_gallery = empty($images) ? null :  implode(",",$images);
		$HairReport->save();
	   }
	   return Response::json(array('success'=>true,'message'=>'Image Deleted Successfully'));
	}
	
	/**
     * Function to view schedule appointment page.
     * @return view
    */
	public function scheduleAppointment($id) {		
		$report    = HairTransplantReport::with(['user','applied_offer'])->find($id);
		$options   = ProcedureOption::all();
		if($report == null) {
			return abort(403);
		}
		if(Auth::user()->id != $report->user_id) {
			return abort(401);
		}
		if($report->appointment_status == 1 ) {
			return redirect('/procedure/hair-transplant');
		}
			
	    $costPerGraft 	 =  $report->cost_per_graft; 
	    $fue_graft_rate  =  env('FUE_GRAFT_RATE');		    
	    $rob_graft_rate  =  env('ROBOTIC_GRAFT_RATE');		
	    $dhi_graft_rate  =  env('DHI_GRAFT_RATE');	
	    $bio_graft_rate  =  env('BIO_GRAFT_RATE');	    
	    $gst_rate		 =  env('GST_RATE');	    
	    $totalGraft	     =  $report->total_graft;
	    	    
	    $payment['totalcost'] 		=  $totalGraft * $costPerGraft;
	    $payment['discount'] 	 	=  $report->applied_offer->discount;
		$payment['fue_totalcost'] 	=  $totalGraft * $fue_graft_rate;
		$payment['rob_totalcost'] 	=  $totalGraft * $rob_graft_rate;
		$payment['dhi_totalcost'] 	=  $totalGraft * $dhi_graft_rate;
		$payment['bio_totalcost'] 	=  $totalGraft * $bio_graft_rate;
	    
		if($report->applied_offer->discount_type == 'g') {
			$payment['discount_type'] 		=  'Grafts in Offer';			
			$payment['totaldiscount']		=  $payment['discount']  * $costPerGraft;
			
			$payment['fue_totaldiscount'] 	=  $payment['discount']  * $fue_graft_rate;
			$payment['rob_totaldiscount'] 	=  $payment['discount']  * $rob_graft_rate;
			$payment['dhi_totaldiscount'] 	=  $payment['discount']  * $dhi_graft_rate;
			$payment['bio_totaldiscount'] 	=  $payment['discount']  * $bio_graft_rate;
			
		} else if($report->applied_offer->discount_type == 'p') {
			$payment['discount_type'] 		=  'Discount Offer in (%)'; 
			$payment['totaldiscount']		=  ($payment['totalcost']*$payment['discount'])/100;
			
			$payment['fue_totaldiscount'] 	=  ($payment['fue_totalcost']*$payment['discount'])/100;
			$payment['rob_totaldiscount'] 	=  ($payment['rob_totalcost']*$payment['discount'])/100;
			$payment['dhi_totaldiscount'] 	=  ($payment['dhi_totalcost']*$payment['discount'])/100;
			$payment['bio_totaldiscount'] 	=  ($payment['bio_totalcost']*$payment['discount'])/100;
			
			
		} else {
			$payment['discount_type'] 		=  'Discount Flat Off in Offer';
			$payment['totaldiscount']		=  $payment['discount'];
			
			$payment['fue_totaldiscount'] 	=  $payment['discount'];
			$payment['rob_totaldiscount'] 	=  $payment['discount'];
			$payment['dhi_totaldiscount'] 	=  $payment['discount'];
			$payment['bio_totaldiscount'] 	=  $payment['discount'];
		}
		
		$payment['balance']		   	    =  $payment['totalcost'] - $payment['totaldiscount'];
		$payment['requiredGrafts']	    =  $totalGraft;
		$payment['costPerGraft']	    =  $costPerGraft;
	
		//fue					
		$payment['fue_balance']			=  $payment['fue_totalcost'] - $payment['fue_totaldiscount'];
		$payment['fue_costPerGraft']	=  $fue_graft_rate;
		$payment['fue_type']			=  "FUE";
		
		//robotic			
		$payment['rob_totalcost'] 		=  $totalGraft * $rob_graft_rate;
		$payment['rob_balance']		    =  $payment['rob_totalcost'] - $payment['rob_totaldiscount'];
		$payment['rob_costPerGraft']	=  $rob_graft_rate;
		$payment['rob_type']			=  "ROBOTICS";
		
		//dhi					
		$payment['dhi_totalcost'] 		=  $totalGraft * $dhi_graft_rate;
		$payment['dhi_balance']		    =  $payment['dhi_totalcost'] - $payment['dhi_totaldiscount'];
		$payment['dhi_costPerGraft']	=  $dhi_graft_rate;
		$payment['dhi_type']			=  "DHI";
		
		//bio						
		$payment['bio_totalcost'] 		=  $totalGraft * $bio_graft_rate;
		$payment['bio_balance']		    =  $payment['bio_totalcost'] - $payment['bio_totaldiscount'];
		$payment['bio_costPerGraft']	=  $bio_graft_rate;
		$payment['bio_type']			=  "BIO-FUE";
		
		$transplant_type = ($report->transplant_type == '') ? 'fue_' : $report->transplant_type.'_';
		$finalPayment['procedure_cost'] =  $payment[$transplant_type.'totalcost'];		
	    $finalPayment['totaldiscount'] 	=  $payment[$transplant_type.'totaldiscount'] ;
	    $finalPayment['totalcost'] 		=  ($finalPayment['procedure_cost'] -  $finalPayment['totaldiscount']) + (($finalPayment['procedure_cost'] -  $finalPayment['totaldiscount']) * $gst_rate)/100;
	    
	    $finalPayment['gst_price']		=  (($finalPayment['procedure_cost'] - $finalPayment['totaldiscount']) * $gst_rate)/100;
	    $finalPayment['costPerGraft']	=  $payment[$transplant_type.'costPerGraft'];
	    $finalPayment['balance']		=  $finalPayment['totalcost'];
	    $finalPayment['type']			=  $payment[$transplant_type.'type'];
	    	
		return view('procedure.hair.hairappointment',compact(['report', 'payment', 'finalPayment', 'options']));
	}
	

	/**
     * Function to apply offer.
     * @return view
    */
	public function addOffer($id) {
		$offer 	= Offer::find($id);
		if($offer == null) {
		  return abort(403);
		}		
	   session()->put('offer', $offer);	   
	   //$value = session()->get('offer');
	   return redirect('/procedure/hair-transplant');
	}
	
	/*
	 * Function to add appointment
	 * @return redirect to url
	*/		
	public function addAppointment(Request $request) {
		$offer 	       = $request->input('offer_apply');
		$appintment_id = $request->input('appintment_id');
			
		if($offer) {
		 $HairReport   = HairTransplantReport::find($appintment_id);
		 if($HairReport){
			  $HairReport->offer_apply = $offer;
			  $HairReport->save();
		 }
		
	    }
	    $OfferDetail   = Offer::find($offer);	   	    
	    if($OfferDetail && $OfferDetail->offer_type == 'package') {
			$hairReport = HairTransplantReport::find($appintment_id);
			if($hairReport){
				$id = $hairReport->id;
			}else{
				$id = '';	
			}
			 
			 return redirect('/package/'.$OfferDetail->id.'/'.str_slug($OfferDetail->offer_name_en, '-').'/'.$id);
		}
	    
		return redirect('/procedure/'.$appintment_id.'/schedule-appointment');
	}
	
   
    /*
	 * Function to schedule an appointment
	 * @return redirect to url
	*/	
	public function scheduleAnAppointment($id) {
			///	die('nikhil');
		 $appointment_id = $id;
		 $HairReport     = HairTransplantReport::with(['user','applied_offer'])->find($appointment_id);		
		 if($HairReport !== null) {
			 $HairReport->appointment_status = 1;
			 $HairReport->save();	
			 
			$gst_price = $HairReport->total_cost*18/100;
			
			$User  = UserDetail::where('user_id',  Auth::user()->id)->first();
			
			$HairReport->total_cost 	 = $HairReport->total_cost+$gst_price;
			$HairReport->pending_payment = $HairReport->total_cost+$gst_price;
			
			$TempOrder  = new TempOrder;
		   	$TempOrder->status 		= 0;
			$TempOrder->save();
			        
			$Order 	   				= new Order;		
			$Order->id 				= $TempOrder->id;
			$Order->user_id 		= Auth::user()->id;
			$Order->address 		= (isset($User->address)) ? $User->address : '';
			$Order->country 		= ($User->country) ? $User->country : '';
			$Order->state 			= ($User->state) ? $User->state : '';
			$Order->zip 			= ($User->post_code) ? $User->post_code : '';
			$Order->city 			= ($User->city) ? $User->city : '';
			$Order->billing_address = ($User->address) ? $User->address : '';
			$Order->billing_city 	= ($User->city) ? $User->city : '';
			$Order->billing_state 	= ($User->state) ? $User->state : '';
			$Order->billing_country = ($User->country) ? $User->country : '';
			$Order->billing_zip 	= ($User->post_code) ? $User->post_code : '';
			$Order->total 			= $HairReport->total_cost;
			$Order->grand_total 	= $HairReport->total_cost;
			$Order->status 			= 0;
			$Order->payment_status 	= 'Pending';
			$Order->save();
			
			
			
			
			$Procedure 				  	   = new Procedure;
			$Procedure->user_id 		   = Auth::user()->id;
			$Procedure->order_id 		   = $Order->id;
			$Procedure->report_id 	  	   = $HairReport->id;
			$Procedure->service     	   = $HairReport->service_id; //fixed for hair transplant custom
			$Procedure->type     	  	   = 'offer';
			//$Procedure->offer_apply      = '';
			//$Procedure->offer_name       = '';
			$Procedure->total_payment      = floor($HairReport->total_cost);
			$Procedure->advanced_payment   = 0;
			$Procedure->pending_payment    = floor($HairReport->total_cost);
			$Procedure->gst_price    	   = floor($gst_price);
			//$Procedure->payment_type     = '';
			$Procedure->procedure_stat     =$HairReport->procedure_stat;
			$Procedure->save();
			
						
			$OrderDetail 				   = new OrderDetail;
			$OrderDetail->order_id 		   = $Order->id;
			$OrderDetail->user_id 		   = $Order->user_id;
			$OrderDetail->product_id 	   = $Procedure->id;
			$OrderDetail->product_price    = $HairReport->total_cost;
			$OrderDetail->product_type     = 'procedure';
			$OrderDetail->product_quantity = 1;
			$OrderDetail->save();
			
			TempOrder::where('id',$TempOrder->id)->delete();						  
			return Response::json(array('success'=>true,'id'=>$Procedure->id, 'message'=>'Appointment Scheduled Successfully'));
		} else {			
			return Response::json(array('success'=>false, 'message'=>'Appointment Scheduled Error'));
		} 
	}
	
	/**
     * Function to change procedure transplant type.
     * @return response
    */
	public function changeProcedureType(Request $request)
	{	
		$report_id      = $request->input('report_id');
		$procedure_type = $request->input('procedure_type');
		$HairReport     = HairTransplantReport::find($report_id);		 
		 if($HairReport !== null) {
			 $HairReport->transplant_type = $procedure_type;
			 $HairReport->save();	  
			return Response::json(array('success'=>true, 'message'=>'Procedure Changed Successfully'));
		} else {			
			return Response::json(array('success'=>false, 'message'=>'Report Not Exist'));
		} 
	}
	
	
	/*
	 * Function to Talk To Expert
	 * @return redirect to url
	*/	
	public function talkToExpert(Request $request) {
	
		$user_id   = $request->input('user_id');
		$service   = $request->input('service');
		$calling_reason = $request->input('calling_reason');
		$call_time = $request->input('call_time');
		
		$super_admin_email  = "dotstudent203@gmail.com";
		$get_user_detail 	= User::where('id', $user_id)->first();
		$username 		    = $get_user_detail->name;
		$useremail 		    = $get_user_detail->email;
		$userphone 		    = $get_user_detail->phone;
		
		$user_detail = array('username' => $username,'useremail' => $useremail,'userphone' => $userphone,'service' => 'hair','calling_reason' => $calling_reason,'call_time' => $call_time);
		
		Mail::to($super_admin_email)->send(new ExpertTalkEmail($user_detail));
		
		$talk_data = new TalkToExpert;
		$talk_data->user_id =  $user_id;
		$talk_data->service_id =  $service;
		$talk_data->reason  =  $calling_reason;
		$talk_data->available_time =  $call_time;
		$talk_data->save();		
		return Response::json(array('success'=>true));
	}
	
	
	/**
     * Function to get skin procedure.
     * @return view
    */
	public function skinProcedure()
	{
		$service_id    = '6';
		
		$countoffers     = Offer::where('services',$service_id)->count();
		//$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$services   =  SubService::where('service_id', 6)->get();
		$procedure  =  Page::where('template','Skin Procedure')->where('data_type','skin-procdeure-data')->first();
		 
		$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		if($procedure !== null) {
			$procedureData         = json_decode($procedure->content_en);
			$procedureDatafr       = json_decode($procedure->content_fr);
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
			$data['first_offer']   = Banner::find($procedureData->first_banner);	
			$data['second_offer']  = Banner::find($procedureData->second_banner);		
		 }
		
		$images    = BeforeAfterImage::where('service_id',6)->get();
		$bareviews = BeforeAfterReview::where('service_id',6)->where('review_status','1')->get();
		$countoffers  = Offer::where('services',$service_id)->count();
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		
		$percentage = 0;
		if($count){
			$percentage 	   =  array();		
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}		
		
		
		$countries = Countries::all();
		
		
		$cityOffers = [];
		foreach($offers as $key=>$offer) {
		  if($offer->city) {
		
				if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
					$cityOffers[] = $offer;
				}
			} else {
				$cityOffers[] = $offer;
				
			}
		}	
		$offers	   = $cityOffers;
		
		
		$skip      = 4;
		
		
		return view('procedure.skin.skin',compact(['services', 'countoffers', 'service_id' , 'images', 'data', 'bareviews', 'reviews', 'count', 'avrage', 'percentage','offers','skip','offers']));
	}
	
		/**
     * Function to redirect page skinwhiteningProcedure.
     * @return view
    */
	public function skinwhiteningProcedure()
	{
		
		
		$service_id    = '6';
		
		$countoffers     = Offer::where('services',$service_id)->count();
		//$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$services   =  SubService::where('service_id', $service_id)->get();
		$procedure  =  Page::where('template','Skin Procedure')->where('data_type','skin-procdeure-data')->first();
		 
		$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		if($procedure !== null) {
			$procedureData         = json_decode($procedure->content_en);
			$procedureDatafr       = json_decode($procedure->content_fr);
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
			$data['first_offer']   = Banner::find($procedureData->first_banner);	
			$data['second_offer']  = Banner::find($procedureData->second_banner);		
		 }
		
		$images    = BeforeAfterImage::where('service_id',$service_id)->get();
		$bareviews = BeforeAfterReview::where('service_id',$service_id)->where('review_status','1')->get();
		$countoffers  = Offer::where('services',$service_id)->count();
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		
		$percentage = 0;
		if($count){
			$percentage 	   =  array();		
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}		
		
		$countries = Countries::all();	
		
		$cityOffers = [];
		foreach($offers as $key=>$offer) {
		  if($offer->city) {
		
				if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
					$cityOffers[] = $offer;
				}
			} else {
				$cityOffers[] = $offer;
				
			}
		}	
		$offers	   = $cityOffers;
		$skip      = 4;
		$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		return view('procedure.skin.skinwhitening',compact(['services','images', 'data', 'bareviews', 'reviews', 'count', 'avrage', 'percentage','offers','skip','offers','countoffers','countries','service_id']));
	}
	
		/**
     * Function to redirect page acnes.
     * @return view
    */
	public function acnesProcedure()
	{
		
		$service_id    = '14';
		
		$countoffers     = Offer::where('services',$service_id)->count();
		//$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$services   =  SubService::where('service_id', $service_id)->get();
		$procedure  =  Page::where('template','Skin Procedure')->where('data_type','skin-procdeure-data')->first();
		 
		$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		if($procedure !== null) {
			$procedureData         = json_decode($procedure->content_en);
			$procedureDatafr       = json_decode($procedure->content_fr);
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
			$data['first_offer']   = Banner::find($procedureData->first_banner);	
			$data['second_offer']  = Banner::find($procedureData->second_banner);		
		 }
		
		$images    = BeforeAfterImage::where('service_id',$service_id)->get();
		$bareviews = BeforeAfterReview::where('service_id',$service_id)->where('review_status','1')->get();
		$countoffers  = Offer::where('services',$service_id)->count();
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		
		$percentage = 0;
		if($count){
			$percentage 	   =  array();		
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}		
		
		
		$countries = Countries::all();	
		
		$cityOffers = [];
		foreach($offers as $key=>$offer) {
		  if($offer->city) {
		
				if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
					$cityOffers[] = $offer;
				}
			} else {
				$cityOffers[] = $offer;
				
			}
		}	
		$offers	   = $cityOffers;
		
		
		$skip      = 4;
		
		
		
		
		
			$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		return view('procedure.skin.acnes',compact(['services','images', 'data', 'bareviews', 'reviews', 'count', 'avrage', 'percentage','offers', 'skip','countoffers','countries','service_id']));
	}
	/**
     * Function to redirect page antiaging.
     * @return view
    */
	public function antiagingProcedure()
	{
		
		$service_id    = '12';
		
		$countoffers     = Offer::where('services',$service_id)->count();
		//$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$services   =  SubService::where('service_id', 12)->get();
		$procedure  =  Page::where('template','Skin Procedure')->where('data_type','skin-procdeure-data')->first();
		 
		$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		if($procedure !== null) {
			$procedureData         = json_decode($procedure->content_en);
			$procedureDatafr       = json_decode($procedure->content_fr);
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
			$data['first_offer']   = Banner::find($procedureData->first_banner);	
			$data['second_offer']  = Banner::find($procedureData->second_banner);		
		 }
		
		$images    = BeforeAfterImage::where('service_id',12)->get();
		$bareviews = BeforeAfterReview::where('service_id',12)->where('review_status','1')->get();
		$countoffers  = Offer::where('services',$service_id)->count();
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		
		
		$percentage = 0;
		if($count){
			$percentage 	   =  array();		
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}		
		
		
		$countries = Countries::all();	
		
		$cityOffers = [];
		foreach($offers as $key=>$offer) {
		  if($offer->city) {
		
				if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
					$cityOffers[] = $offer;
				}
			} else {
				$cityOffers[] = $offer;
				
			}
		}	
		$offers	   = $cityOffers;
		
		
		$skip      = 4;
		
			$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		return view('procedure.skin.antiaging',compact(['services','images', 'data', 'bareviews', 'reviews', 'count', 'avrage', 'percentage','offers', 'skip','countoffers','countries','service_id']));
	}
	
	/**
     * Function to redirect page botox.
     * @return view
    */
	public function botoxProcedure()
	{
		$service_id    = '15';
		
		$countoffers     = Offer::where('services',$service_id)->count();
		//$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$services   =  SubService::where('service_id', $service_id)->get();
		$procedure  =  Page::where('template','Skin Procedure')->where('data_type','skin-procdeure-data')->first();
		 
		$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		if($procedure !== null) {
			$procedureData         = json_decode($procedure->content_en);
			$procedureDatafr       = json_decode($procedure->content_fr);
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
			$data['first_offer']   = Banner::find($procedureData->first_banner);	
			$data['second_offer']  = Banner::find($procedureData->second_banner);		
		 }
		
		$images    = BeforeAfterImage::where('service_id',$service_id)->get();
		$bareviews = BeforeAfterReview::where('service_id',$service_id)->where('review_status','1')->get();
		$countoffers  = Offer::where('services',$service_id)->count();
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		
		$percentage = 0;
		if($count){
			$percentage 	   =  array();		
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id', 1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}		
		
		
		$countries = Countries::all();	
		
		$cityOffers = [];
		foreach($offers as $key=>$offer) {
		  if($offer->city) {
		
				if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
					$cityOffers[] = $offer;
				}
			} else {
				$cityOffers[] = $offer;
				
			}
		}	
		$offers	   = $cityOffers;
		
		
		$skip      = 4;
		
			$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		return view('procedure.skin.botox',compact(['services','images', 'data', 'bareviews', 'reviews', 'count', 'avrage', 'percentage','offers', 'skip','countoffers','countries','service_id']));
	}
	/**
     * Function to redirect page facial.
     * @return view
    */
	public function facialProcedure()
	{
			$service_id    = '13';
		
		$countoffers     = Offer::where('services',$service_id)->count();
		//$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$services   =  SubService::where('service_id', $service_id)->get();
		$procedure  =  Page::where('template','Skin Procedure')->where('data_type','skin-procdeure-data')->first();
		 
		$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		if($procedure !== null) {
			$procedureData         = json_decode($procedure->content_en);
			$procedureDatafr       = json_decode($procedure->content_fr);
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
		
		 }
		
		$images    = BeforeAfterImage::where('service_id',$service_id)->get();
		$bareviews = BeforeAfterReview::where('service_id',$service_id)->where('review_status','1')->get();
		$countoffers  = Offer::where('services',$service_id)->count();
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		
		$percentage = 0;
		if($count){
			$percentage 	   =  array();		
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id', 1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}		
		
		
		$countries = Countries::all();	
		
		$cityOffers = [];
		foreach($offers as $key=>$offer) {
		  if($offer->city) {
		
				if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
					$cityOffers[] = $offer;
				}
			} else {
				$cityOffers[] = $offer;
				
			}
		}	
		$offers	   = $cityOffers;
		
		
		$skip      = 4;
		
		$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		return view('procedure.skin.facial',compact(['services','images', 'data', 'bareviews', 'reviews', 'count', 'avrage', 'percentage','offers', 'skip','countoffers','countries','service_id']));
	}
	/**
     * Function to redirect page laserhairremoval.
     * @return view
    */
	public function laserhairremovalProcedure()
	{
		
			$service_id    = '16';
		
		$countoffers     = Offer::where('services',$service_id)->count();
		//$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$services   =  SubService::where('service_id', $service_id)->get();
		$procedure  =  Page::where('template','Skin Procedure')->where('data_type','skin-procdeure-data')->first();
		 
		$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		if($procedure !== null) {
			$procedureData         = json_decode($procedure->content_en);
			$procedureDatafr       = json_decode($procedure->content_fr);
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
		
		 }
		
		$images    = BeforeAfterImage::where('service_id',$service_id)->get();
		$bareviews = BeforeAfterReview::where('service_id',$service_id)->where('review_status','1')->get();
		$countoffers  = Offer::where('services',$service_id)->count();
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		
		$percentage = 0;
		if($count){
			$percentage 	   =  array();		
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}		
		
		
		$countries = Countries::all();	
		
		$cityOffers = [];
		foreach($offers as $key=>$offer) {
		  if($offer->city) {
		
				if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
					$cityOffers[] = $offer;
				}
			} else {
				$cityOffers[] = $offer;
				
			}
		}	
		$offers	   = $cityOffers;
		
		
		$skip      = 4;
		
			$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		return view('procedure.skin.laserhairremoval',compact(['services','images', 'data', 'bareviews', 'reviews', 'count', 'avrage', 'percentage','offers', 'skip','countoffers','countries','service_id']));
	}
	/**
     * Function to get dental procedure.
     * @return view
    */
	public function dentalProcedure()
	{
		$services   =  SubService::where('service_id', 1)->get();		
		$procedure  =  Page::where('template','Dental Procedure')->where('data_type','dental-procdeure-data')->first();
		 		 
		 $data 		=  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		 if($procedure !== null) {
			$procedureData         = json_decode($procedure->content_en);
			$procedureDatafr       = json_decode($procedure->content_fr);
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
			$data['first_offer']   = Banner::find($procedureData->first_banner);	
			$data['second_offer']  = Banner::find($procedureData->second_banner);		
		 }
		
		$images    = BeforeAfterImage::where('service_id',2)->get();
		$bareviews = BeforeAfterReview::where('service_id',2)->where('review_status','1')->get();
		
		return view('procedure.dental.dental',compact(['services','images', 'data', 'bareviews']));
	}
	
	
	
	/**
     * Function to redirect page beardtransplant.
     * @return view
    */
	public function beardTransplant()
	{
		return view('procedure.hair.beardtransplant');
	}
	
	/**
     * Function to redirect page eyebrowstransplant.
     * @return view
    */
	public function cosmeticTransplant()
	{
		return view('procedure.skin.cosmetictransplant');
	}
	
	/**
     * Function to redirect page cosmatictransplant.
     * @return view
    */
	public function eyebrowTransplant()
	{
		return view('procedure.hair.eyebrowtransplant');
	}
	
	
	/* 
	 * Function to Save beard Procedire Data and Register User 
	*/
	
	public function saveBeardReport(Request $request) {
		return redirect('/procedure/beard/18/report');	 
	  }	
	  
	/* 
	 * Function to Save eyebrow Procedire Data and Register User 
	*/
	
	public function saveEyebrowReport(Request $request) {
		return redirect('/procedure/eyebrow/18/report');	 
	  }	
	    
	    
	 /* 
	 * Function to Save cosmetic Procedire Data and Register User 
	*/
	
	public function saveCosmeticReport(Request $request) {
		return redirect('/procedure/cosmetic/18/report');	 
	  }	
	    
	/**
     * Function to view final beard transplant report by id.
     * @return view
    */
	public function beardReport()
	{
		return view('procedure.hair.beardreport');
	}
	
	/**
     * Function to view final eyebrow transplant report by id.
     * @return view
    */
	public function eyebrowReport()
	{
		return view('procedure.hair.eyebrowreport');
	}
		
	/**
     * Function to view final cosmetic transplant report by id.
     * @return view
    */
	public function cosmeticReport()
	{
		return view('procedure.skin.cosmeticreport');
	}	
	
	
	
	/** 
	 *Function to get package detail
	*/
	public function getPackageDetail($id, $slug,$rid) {
		
		
		if(!Auth::check()){
		$validatedData = $request->validate([
				'email' => 'required|email|unique:users',
				'phone'	=> 'required|min:9|unique:users', 
			]);
		
		}
		
		$Offer 		    = Offer::with('subService')->find($id);
		$options 		= ProcedureOption::all();
		
		$gst_rate		=  env('GST_RATE');
		$packagePrice 						 = $Offer->package_price - $Offer->discount;
		$finalPayment['packagecost']         = $Offer->package_price;
		$finalPayment['totalcost']			 = floor($packagePrice + ($packagePrice * $gst_rate)/100) ;
		$finalPayment['totaldiscount']		 = $Offer->discount;	                                
		$finalPayment['balance']		   	 = $finalPayment['totalcost'];	
		$finalPayment['gst_rate']		   	 = $gst_rate;	
		$finalPayment['gst']		   	 	 = floor(($packagePrice * $gst_rate)/100);	
						
		return view('procedure.package',compact(['Offer', 'finalPayment', 'options','rid']));		
	}
	
    /*
     * Function to change option price on package 
     * @return response
    */
    
    public function changeOptionPrice(Request $request) {
		
		$optionId 		    =  $request->option_id;
		$offer_id 		    =  $request->offer_id;
		$is_type 			=  $request->is_type;
		$gst_rate			=  env('GST_RATE');
		
		$Option				= ProcedureOption::find($optionId);
		$Offer 				= Offer::with('subService')->find($offer_id);
		
		if($is_type == 'package') {
			$packagePrice		= $Offer->package_price;
			$afterdiscountPrice = $Offer->package_price - $Offer->discount;
			$totaldiscount		= $Offer->discount;		
			$totalCost		   	= floor($afterdiscountPrice + ($afterdiscountPrice * $gst_rate)/100) ;
			$finalcost		   	= $totalCost;
			
			if($Option->discount_type == 'p') {
				$finalcost      =  ($finalcost * $Option->total_coast)/100;
				$optionDiscount	=  ($totalCost * $Option->discount)/100;
			 } else {				 
				$finalcost      =  $Option->total_coast;
				$optionDiscount	=  $Option->discount;
			 }			 
			 $balance			= $totalCost - $finalcost;			 
		} else {
			$report_id = $request->report_id;
			$payment   = app('App\Http\Controllers\ShopController')->appontmentPayment($report_id);		
			$OfferPrice			= $payment['totalcost'];
			$totaldiscount		= $payment['totaldiscount'];		
			$totalCost		   	= $payment['balance'];
			$finalcost		   	= $totalCost;
			
			if($Option->discount_type == 'p') {
				$finalcost      =  ($finalcost * $Option->total_coast)/100;
				$optionDiscount	=  ($totalCost * $Option->discount)/100;
			 } else {				 
				$finalcost      =  $Option->total_coast;
				$optionDiscount	=  $Option->discount;
			 }			 
			$balance			= $totalCost - $finalcost;			
		}
		
		$html    = "";
		$html   .= "<p><span>Balance</span><span>: Rs. ".$balance."</span></p>";
		$html   .= "<p><span><b>PAYMENT</b></span><span>: <b>Rs. ".$finalcost."</b></span></p>";
		
		$content = "<span class='mb-2'><b>".$Option->option_name."</b></span>";
		
		return Response::json(array('success'=>true, 'message'=>'Option Updated Successfully', 'html'=>$html, 'content'=>$content));						
		
	}
	
	/** 
	 *Function to get package detail
	*/
	public function procedureappointmentReports($id) {
		$AppointmentList = AppointmentList::find($id);
		return view('user.procedure.readreport',compact(['AppointmentList']));		
	}
	
	public function matchEmail(Request $request) {
		
		
		
		$emailaddress 	= $request->input('emailadr');
		$check_user_email = User::where('email', $emailaddress)->first();
		if(count($check_user_email) != 0 && !Auth::check())
		{
			return Response::json(array('success'=>true));	
		}
		else
		{
			return Response::json(array('success'=>false));	
		}
		
	}
	
	/* Code by nikhil */
		/* phone  no validation */
	 public function matchPhone(Request $request) {
	
		$phone 	= $request->input('phone_number');		
		$check_user_no = User::where('phone', $phone)->first();
		
			if(count($check_user_no) != 0 && !Auth::check()) {
				return Response::json(array('success'=>true , 'check_user_no'=>$check_user_no));	
			} else {
				return Response::json(array('success'=>false));
				
			}
		
		
	}
		
}
