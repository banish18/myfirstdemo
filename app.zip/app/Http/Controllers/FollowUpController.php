<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Service;
use App\SubService;
use App\FollowUpReminder;
use App\OperationList;
use App\ReminderList;
use Auth;
use App\User;
use Session;
use Validator;
use App\Mail\ReminderEmail;
use App\SmsApi;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;

class FollowUpController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */   
    public function create(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'email'=>'required',
            'review'=>'required',
            'rate'=>'required'
        ]);
        
        $ProcedureReview = new ProcedureReview;
        $ProcedureReview->reviewer_name = $request->post('name');
        $ProcedureReview->reviewer_email = $request->post('email');
        $ProcedureReview->review = $request->post('review');
        $ProcedureReview->rating = $request->post('rate');
        $ProcedureReview->service_id = $request->post('service');
        $ProcedureReview->save();
        return redirect('/reviews')->with('success', 'Record Inserted!');
    }
    
	/**
     * Create a new Function to display data on home page.
     * @return slides, offers
    */
	public function index() {
		
	    $current_user_id =  auth()->user()->id; 
	    
		$user_opertion_record = OperationList::where("user_id", $current_user_id)->where("status","1")->first();

		if(count($user_opertion_record) != 0)
		{
			$opr_date = $user_opertion_record->operation_date;
			$date = date('Y-m-d', strtotime($opr_date));
			
			$service_id = $user_opertion_record->service_id;
			$reminders_data =  FollowUpReminder::where('sub_service_id',$service_id)->get();
			
			if(count($reminders_data) != 0)
			{
				$reminders =  $reminders_data;
			}
			else
			{
				$reminders = [];
			}
		}
		else
		{
			$reminders = [];
			$date = "";
		}
		return View('user/follow-ups',compact('reminders','date','user_opertion_record'));
		
	}
	
	/**
	 * Add user Reminders
	 */
	 
	 public function reminderList() {
		$user_opertion_record = OperationList::where("status","1")->where("type","O")->get();
		if(count($user_opertion_record) != 0)
		{
			foreach($user_opertion_record as $user_detail)
			{
				$user_id = $user_detail->user_id; 
				$service_id = $user_detail->service_id; 
				$operation_date = $user_detail->operation_date;
				$operation_date = date_create($operation_date);
				$operation_date = date_format($operation_date,"Y-m-d");
				$reminders_data =  FollowUpReminder::where('sub_service_id',$service_id)->get();
				if(count($reminders_data) != 0)
				{
					foreach($reminders_data as $reminders)
					{
						$reminder_day = $reminders->reminder_day;
						$reminder_id = $reminders->id;
						$day = $reminder_day.'days';
						$reminder_date = date('Y-m-d', strtotime($operation_date."+".$reminder_day." days"));
						$ReminderList = new ReminderList;
						$ReminderList->user_id = $user_id;
						$ReminderList->reminder_id = $reminder_id;
						$ReminderList->reminder_date = $reminder_date;
						$ReminderList->save();
					}
				}
					
			}
		}  
	 }
	 
	public function reminderSend()
	{
	  date_default_timezone_set('Asia/Kolkata');
	  $currentdate = date( 'Y-m-d');
	  $checkreminder = ReminderList::where("reminder_date",$currentdate)->get();
	  $reminder_mail_data = [];
	  foreach($checkreminder as $reminder)
	  {
		  $reminder_id = $reminder->reminder_id;
		  $reminder_did = $reminder->id;
		  $user_id = $reminder->user_id;
		  $user_detail = User::find($user_id);
		  $useremail = $user_detail->email;
		  $username = $user_detail->name;
		  $phone = $user_detail->phone;
		  
		  
		  $reminders_data =  FollowUpReminder::where('id' ,$reminder_id)->first();
		  
		  
		  $reminder_title = $reminders_data['title'];
		  $reminder_des = strip_tags($reminders_data['description']);
		  $reminder_mail_data = array('title' => $reminder_title,'desc' => $reminder_des,'username' => $username);
		  
		  $mail_send = Mail::to($useremail)->send(new ReminderEmail($reminder_mail_data));
		  $message = strip_tags($reminder_des);
		  $SmsApi 	 = new SmsApi();
		 // $send_message = $SmsApi->sendSMS($phone, $message);
		//if($mail_send)
		//{
		//	ReminderList::where('id',$reminder_did)->delete();	 
		//}
		  
	  }
	}
	}
