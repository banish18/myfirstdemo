<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Input;
use App\User;
use App\MobileNotification;
use App\Role;
use App\RoleUser;
use App\Doctors;
use App\ManagerDetail;
use App\DoctorAssistant;
use App\Dials;
use App\Setting;
use App\Capping;
use App\AppointmentRequest;
use App\Service;
use App\AppointmentList;
use App\ReferralData;
use App\ReferralPointsData;
use App\OperationList;
use App\ClinicGallery;
use App\PatientGallery;
use App\Procedure;
use App\HairTransplantReport;
use App\UserDetail;
use App\SubService;
use LaravelFCM\Message\Topics;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;

use Auth;
use Validator;
use DateTime;
use DateInterval;
use File;
use FCM;
use DB;

class DoctorController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
    public $successStatus = 200;
	public $errorStatus = 401;
    public function doctorServices() {
		$services = Service::with(['subService'])->get()->toArray();
		 return response()->json(['success' => $services], $this->successStatus); 
	}
	
	
	/***
	 * Doctor list
    **/	
	public function doctorList() {
		$Doctors = Doctors::with(['user'])->get()->toArray();
		return response()->json(['success' => $Doctors], $this->successStatus); 
	}
	
	public function getSkilldetail($id){
		$SubService = Service::find($id);
		if($SubService !== null) {
			return $SubService;
		} else {
			return "";
		}
	}
	
	public function getsubSkilldetail($id){
		$SubService = SubService::find($id);
		if($SubService !== null) {
			return $SubService;
		} else {
			return "";
		}
	}
	/***
	 * Update Doctor Profile
	**/
	public function updateDoctorProfile(Request $request) {
		//Add new fields for Doctor
			$education  = !empty($request->input('education'))?$request->input('education'):'';
			$experience  = $request->input('experience');
			$awards  = !empty($request->input('awards'))?$request->input('awards'):'';
			$speciality  = $request->input('speciality');
        //End
		$validator = Validator::make($request->all(), [ 
            'user_id'	   => 'required', 
            'doctor_name'  => 'required', 
            'education'  => 'required', 
            'experience'  => 'required', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
        
		$user_id      = $request->input('user_id');
		$name         = $request->input('doctor_name');
        $profile      = $request->input('profile_picture');
        $servics     = !empty($request->input('services')) ? json_encode(explode(",",$request->input('services'))) : null;
        $subServices  = !empty($request->input('sub_services')) ? json_encode(explode(",",$request->input('sub_services'))) : null;
        $skills     = array();
        $sub_skills     = array();
        $allServ     = array();
		$skills		 =explode(",",$request->input('services'));
		$sub_skills	 =explode(",",$request->input('sub_services'));			
		$services = Service::with(['subService'])->get()->toArray();
		$skillName = "";
		$subskillName = "";
		$skillName = "";
		$subskillName = "";
		
		if(!empty($skills) && is_array($skills)){
			foreach($skills as $skill){
				if(!empty($sub_skills) && is_array($skills)){
					$sub_skillsd = [];
					foreach($sub_skills as $sub_skill){
						$parentServ  = !empty($this->getsubSkilldetail($sub_skill)->service_id)?$this->getsubSkilldetail($sub_skill)->service_id:'';
						$skillName   = ($this->getSkilldetail($skill) ? $this->getSkilldetail($skill)->service_name : "");
						$subskillName   = ($this->getsubSkilldetail($sub_skill) ? $this->getsubSkilldetail($sub_skill)->sub_name : "");
						
						
						if($skill == $parentServ){
							$sub_skillsd[] = array('id' => $sub_skill,'name' => $subskillName);
						}
					}
				}else{
					$sub_skillsd = [];
				}
				$allServ[] = array('id' => $skill,'name' => $skillName,'sub_service' => $sub_skillsd);
			}
		}
	
		$skillIdArr = [];
		$subskillIdArr = [];
		foreach($allServ as $key => $servic){
			$skillIdArr[] = $servic['id'];
			foreach($servic['sub_service'] as $key2 => $subser){
				$subskillIdArr[] = $subser['id'];
			}
		}
		foreach($services as $key => $servic){
			if(in_array($servic['id'],$skillIdArr)){
				$servic['ischeck'] = '1';
			}else{
				$servic['ischeck'] = '0';
			}
			if(isset($servic['sub_service']) && !empty($servic['sub_service'])){
				foreach($servic['sub_service'] as $key2 => $subser){
					if(in_array($subser['id'],$subskillIdArr)){
							$subser['ischeck'] = '1';
					}else{
						$subser['ischeck'] = '0';	
					}
					$servic['sub_service'][$key2] = $subser;
				}
			}
			$services[$key] = $servic;
		}	
		
        $description  = $request->input('description');
		$User    	  = User::where('id', $user_id)->first();
		
		if($User !== null) {
			$User->name   = $name;
			$User->save();
			
			$Doctor 	  = Doctors::where('user_id', $user_id)->first();
			if(!empty($Doctor)){
				$imagepAth = '';
				if(!empty($request->input('profile_picture'))){
					$image   = $request->input('profile_picture');
					$folder         = 'doctor/';
					$random_number 	= mt_rand(100000, 999999);
					$f = finfo_open();
					$imgdata   = base64_decode($image);
					$mime_type = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
					$mime_type = explode('/',$mime_type);
					$imageName = $random_number.'.'.$mime_type[1];  
					if($mime_type[1]!="octet-stream"){
						File::put(public_path().'/images/doctor/' . $imageName, base64_decode($image));   
						$imagepAth = $folder.$imageName;
						$Doctor->profile_picture  = $imagepAth;
					}
				}
				
				$Doctor->skills= $servics;	
				$Doctor->sub_skills 	  = $subServices;
				$Doctor->description 	  = $description;    
				//Assigning values to new fields
					$Doctor->education   = $education;
					$Doctor->experience   = $experience;
					$Doctor->awards   = $awards;
					$Doctor->speciality   = $speciality;
				//End           
				$Doctor->save();
				$profile= false;
				
				if((empty($request->input('skills')))||(empty($request->input('sub_skills')))||(empty($request->input('description')))||(empty($request->input('education')))||(empty($request->input('experience')))||(empty($request->input('awards')))||(empty($request->input('speciality')))){
					$profile = true;
				}
				$user = User::with('role_detail')->find($user_id);
				$data = Doctors::with(['gallery'])->where('user_id', $user_id)->first();
				if(empty($services)){
					$data->skills= [];
				}else{
					$data->skills  = $services;	
				}
				$success['id']   	=  $user->id; 
				$success['token']   =  $user->api_token; 
				$success['name']    =  $user->name; 
				$success['email']   =  $user->email; 
				$success['phone']   =  $user->phone; 
				$success['role']    =  $user->role; 
				$success[$user->role_detail->name]   =  ($data != null) ? $data : [] ;
				//$success['doctor_profile'] = DB::table('doctor_detail')->select('*')->where('user_id', $user_id)->get();
				
				return Response::json(array('status'=>true,'message'=>'Profile Updated Successfully','profile'=>$profile,'success'=>$success),$this->successStatus);
			}else{
				return Response::json(array('status'=>false,'message'=>'User data not found.'), $this->errorStatus);
			}
		} else {			
			return Response::json(array('status'=>false,'message'=>'Invalid Data! Please send valid parameters.'), $this->errorStatus);
		}
	}
	
	/***
	 * Update Clinic API
	**/
	public function updateClinic(Request $request) {
		
		$validator = Validator::make($request->all(), [ 
            'user_id'   => 'required', 
            'clinic_address' => 'required', 
            'city'		=> 'required', 
            'state'		=> 'required', 
            'zip'	    => 'required', 
            'country'   => 'required', 
            'latitude'  => 'required', 
            'longitude' => 'required', 
            'open_time' => 'required', 
            'close_time'=> 'required', 
            'clinic_name'=> 'required', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
        
		$user_id     	= $request->input('user_id');		
        $clinic_address = $request->input('clinic_address');
        $clinic_name 	= $request->input('clinic_name');
        $city    	    = $request->input('city');
        $state   		= $request->input('state');
        $zip		    = $request->input('zip');
        $country 	    = $request->input('country');
        $latitude 	    = $request->input('latitude');
        $longitude 	    = $request->input('longitude');
        $open_time 	    = $request->input('open_time');
        $close_time 	= $request->input('close_time');
                 
        $Doctor = Doctors::where('user_id', $user_id)->first();
        
        if($Doctor !== null) {
			$Doctor->clinic_address   = $clinic_address;
			$Doctor->clinic_name   	  = $clinic_name;
			$Doctor->doctor_city  	  = $city;
			$Doctor->doctor_state 	  = $state;
			$Doctor->doctor_zip 	  = $zip;
			$Doctor->doctor_country   = $country;
			$Doctor->latitude 	  	  = $latitude;                
			$Doctor->longitude 	  	  = $longitude;                
			$Doctor->open_time 	  	  = $open_time;                
			$Doctor->close_time 	  = $close_time;                               
			$Doctor->save();
			
			return Response::json(array('success'=>true,'message'=>'Clinic Updated Successfully', $this->successStatus));
	    } else {
			return Response::json(array('error'=>'Invalid Data! Please send valid parameters.'), 401);
		}
	}
	
	
	/***
	 * Add Clinic gallery Images
	**/
	public function addClinicImage(Request $request) {
		$validator = Validator::make($request->all(), [ 
            'doctor_id'	   => 'required',
            'gallery'	   => 'required' 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
        
       
        
		$doctor_id = $request->input('doctor_id');
		$Doctor    = Doctors::where('user_id',$doctor_id)->first();
		if($Doctor !== null) {
			
			 
			// $image   =  preg_replace('/\s/', '+', $request->input('gallery'));
			 $image   =  $request->input('gallery');
			
			/*if(is_array($gallery) && !empty($gallery)){
				foreach($gallery as $image){*/
					$folder         = 'doctor/';
					$random_number 	= mt_rand(100000, 999999);
					$f		   = finfo_open();
					$imgdata   = base64_decode($image);
					$mime_type = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
					$mime_type = explode('/',$mime_type);
					$imageName 		= $random_number.'.'.$mime_type[1];  
					File::put(public_path().'/images/doctor/' . $imageName, base64_decode($image));   
					//$image->move(public_path().'/images/doctor/', $imageName);   
					$Clinicgallery = new ClinicGallery;
					$Clinicgallery->doctor_id  = $Doctor->id;
					$Clinicgallery->image_path = $folder.$imageName;
					$Clinicgallery->save();
				/*}
			}*/
			return Response::json(array('success'=>true,'message'=>'Images Added Successfully', $this->successStatus));
		} else {
			return Response::json(array('error'=>'Invalid Data! Please send valid parameters.'), 401);
		}
	}
	
	 
    /**
     * Delete Doctor Gallery Images
    **/
    public function deleteGalleryImg(Request $request) {
		
		$validator = Validator::make($request->all(), [ 
            'id'   => 'required',
        ]);
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
		$id		 		= $request->input('id');
		$ClinicGallery  = ClinicGallery::find($id);
		if($ClinicGallery) {
				$ClinicGallery->delete();
				if(file_exists(public_path('/images/'.$ClinicGallery->image_path))){ //delete image if exist
					unlink(public_path('/images/'.$ClinicGallery->image_path));
				}
			return Response::json(array('success'=>true,'message'=>'Image Deleted successfully', $this->successStatus));  
		}else {
			return Response::json(array('error'=>'Image Not Exist'),401);  
		}   
	} 
	
	/***
	 * View Clinic API
	 *  
	**/
	public function viewClinic(Request $request) {
		$validator = Validator::make($request->all(), [ 
            'user_id'   => 'required',
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
        
		 $user_id = $request->input('user_id');
		 $clinic  = Doctors::with(['gallery'])->where('user_id',$user_id)->get()->toArray();
		 if($clinic !== null) {
			 return response()->json(['success' => $clinic], $this->successStatus); 
		 } else {			 
			 return response()->json(['error' => 'Clinic Not Found'],401); 
		 }
	}
	
	
	/***
	 * Add Assistatnt API
	*/	
	public function addAssistant(Request $request) {
		
		
		$validator = Validator::make($request->all(), [ 
            'doctor_id'	    	=> 'required', 
			'name'  			=> 'required', 
            'email' 			=> 'required|email|unique:users',
            'phone'				=> 'required|min:9|unique:users'
           // 'address' 			=> 'required'            
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
         
        if(!empty($request->input('added_by'))){
			$addedBy = $request->input('added_by');
		}else{
			$addedBy = $request->input('doctor_id');
		}
        
        $user =  User::create([
            'name' 		=> $request->input('name'),
            'email' 	=> $request->input('email'),
            'phone' 	=> $request->input('phone'),
            'password'  => Hash::make(Str::random(6)),
            'isVerified'=> 1,
            'email_verified_at'=> date('Y-m-d h:i:s'),
            'api_token' => Str::random(60),
            'added_by'  => $addedBy,
            'role' 		=> isset($data['role']) ? $data['role'] : '6',
            
        ]);
        $user->roles()->attach(Role::where('name', 'assistant')->first());
        
        $doctor = Doctors::where('user_id',$request->input('doctor_id'))->first();
        
		$Assistant = new DoctorAssistant;
		$Assistant->doctor_id = $request->input('doctor_id');
		$Assistant->user_id   = $user->id;	
		$Assistant->emp_id    = $request->input('emp_id');	
		$Assistant->address   = $doctor->clinic_address;	
		
		$folder         = 'assistant/';
		if(!empty($request->input('profile_picture'))){
			$image   		= $request->input('profile_picture');
			$random_number 	= mt_rand(100000, 999999);
			$f 				= finfo_open();
			$imgdata   		= base64_decode($image);
			$mime_type 		= finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
			$mime_type 		= explode('/',$mime_type);
			$imageName 		= $random_number.'.'.$mime_type[1];
			if($mime_type[1]!="octet-stream"){
				File::put(public_path().'/images/assistant/' . $imageName, base64_decode($image));   
				$Assistant->profile_pic= $folder.$imageName;
			}
		}
			
		$Assistant->save();
		
		/*
		 * User credentials are sent to resigtered user by using email (Pending)
		*/
		$user = User::with('role_detail')->find($user->id);
        $success['id']   	=  $user->id; 
		$success['token']   =  $user->api_token; 
		$success['name']    =  $user->name; 
		$success['email']   =  $user->email; 
		$success['phone']   =  $user->phone; 
		$success['role']    =  $user->role; 
		$success[$user->role_detail->name]   =  ($Assistant != null) ? $Assistant : [] ;
        return response()->json(['status'=>true, 'message' => 'Assistant Added Successfully'], $this->successStatus);          
	}
	
	/***
	 * Update Assistatnt API
	*/
	public function updateAssistant(Request $request) {
		
		$validator = Validator::make($request->all(), [ 
            'id'	 => 'required', 
            'user_id'=> 'required', 
            'name'   => 'required', 
            //'phone'  => 'required', 
            //'email'  => 'required', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
        
        $User = User::find($request->input($request->input('user_id')));
        if($User !== null) {
			$User->name      = $request->input('name');
			//$User->email     = $request->input('email');
			//$User->phone	 = $request->input('phone');		
			$User->save();
			
			$Assistant 			    = DoctorAssistant::find($request->input('id'));  
			$Assistant->address     = $request->input('address');
			$Assistant->description = $request->input('description');
			$folder         = 'assistant/';
			if(!empty($request->input('profile_picture'))){
				$image   		= $request->input('profile_picture');
				$random_number 	= mt_rand(100000, 999999);
				$f 				= finfo_open();
				$imgdata   		= base64_decode($image);
				$mime_type 		= finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
				$mime_type 		= explode('/',$mime_type);
				$imageName 		= $random_number.'.'.$mime_type[1]; 
				File::put(public_path().'/images/assistant/' . $imageName, base64_decode($image));   
				$Assistant->profile_pic= $folder.$imageName;
			}
			$Assistant->save();	
			return response()->json(['status'=>'success', 'message' => 'Assistant Updated Successfully'], $this->successStatus);  
        } else {
			return Response::json(array('error'=>'Invalid Data! Please send valid parameters.'), 401);
		}
	}
	
	/***
	 * View Assistatnt List API
	*/
	public function assistantList(Request $request) {
		
		$validator = Validator::make($request->all(), [ 
            'doctor_id'	      => 'required', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
        $doctor_id = $request->input('doctor_id');
		$assistant = DoctorAssistant::with(array('user' => function($q){ 
			 $q->select('id','name','email', 'phone','added_by','request_recieve_per_day');
		}))->where('doctor_id', $doctor_id)->get()->toArray();
		
		$totalCapping = User::where('id', $doctor_id)->first(['request_recieve_per_day']);
		
		$totalcappingAval = $totalCapping->request_recieve_per_day;
			
		
		if($assistant){
			return response()->json(['status'=>'success', 'assistant' => $assistant, 'totalcappingAval'=>$totalcappingAval], $this->successStatus); 
		} else {
			return response()->json(['status'=>'success', 'assistant' => []], $this->successStatus); 			
		}
	}
	
	/***
	 * Resume and suspend Assistant
	**/
	public function suspendResumeAssistant(Request $request) {
		$validator = Validator::make($request->all(), [ 
            'suspended_by'	    	=> 'required', 
			'user_id'  			=> 'required',             
			'status'  			=> 'required',             
			'role'  			=> 'required',             
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
        }
        
        if($request->input('role') == 4)
        {
			if($request->input('status')=="suspend"){
				$market_manager = ManagerDetail::where('user_id',$request->input('user_id'))->get()->first();  
				if(!empty($market_manager)){			
					$market_manager->status = "0";
					$market_manager->save();	
					return response()->json(['status'=>true,'message'=>"Team member is Suspended sucessfully"], $this->successStatus);            
				}else{
					return response()->json(['status'=>false,'message'=>"No team member is available"], $this->errorStatus);            
				}
			}elseif($request->input('status')=="resume"){
				$market_manager = ManagerDetail::where('user_id',$request->input('user_id'))->get()->first();  			
				if(!empty($market_manager)){			
					$market_manager->status = "1";
					$market_manager->save();	
					return response()->json(['status'=>true,'message'=>"Team member is resumed sucessfully"], $this->successStatus);            
				}else{
					return response()->json(['status'=>false,'message'=>"No Assistant is available"], $this->errorStatus);            
				}
			}
		}
		else
		{
			if($request->input('status')=="suspend"){
				$Assistant 	= DoctorAssistant::where('user_id',$request->input('user_id'))->get()->first();  
				if(!empty($Assistant)){			
					$Assistant->status = "0";
					$Assistant->save();	
					return response()->json(['status'=>true,'message'=>"Assistant is Suspended sucessfully"], $this->successStatus);            
				}else{
					return response()->json(['status'=>false,'message'=>"No Assistant is available"], $this->errorStatus);            
				}
			}elseif($request->input('status')=="resume"){
				$Assistant 	= DoctorAssistant::where('user_id',$request->input('user_id'))->get()->first();  			
				if(!empty($Assistant)){			
					$Assistant->status = "1";
					$Assistant->save();	
					return response()->json(['status'=>true,'message'=>"Assistant is resumed sucessfully"], $this->successStatus);            
				}else{
					return response()->json(['status'=>false,'message'=>"No Assistant is available"], $this->errorStatus);            
				}
			}
		}
	}
	
	/***
	 * Get Doctor Appointment
	**/	
	/*public function doctorAppointments(Request $request) {
		$validator = Validator::make($request->all(), [ 
            'doctor_id'	  => 'required', 
            'max-results'	  => 'required', 
        ]);
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
        }
        
		$doctor_id     = $request->input('doctor_id');
		$total_records = $request->input('max-results');
		$checkappointments  = AppointmentList::where('doctor_id', $doctor_id)->where('status','1')->with(['user_detail'])->paginate(	$total_records);
		if($checkappointments){
			$appointments = $checkappointments->toArray();
		}
		$appointmentFinalDataArr = [];
		
		if(!empty($appointments)){
			foreach($appointments as $appKey => $appVal){
				if($appKey=="current_page"){
					$appointmentFinalDataArr[$appKey] = $appointments[$appKey];					
				}
				if($appKey=="data"){
					foreach($appointments[$appKey] as $subDataKey => $subDataVal){
						foreach($appointments[$appKey][$subDataKey] as $sbDataKey => $sbDataVal){
							if($appointments[$appKey][$subDataKey]['appointment_status']!="cancel"){
								
								if($sbDataKey=="user_detail"){
									$appointmentFinalDataArr[$appKey][$subDataKey]['doctor_id'] = $appointments[$appKey][$subDataKey]['doctor_id'];
									$appointmentFinalDataArr[$appKey][$subDataKey]['procedure_id'] = $appointments[$appKey][$subDataKey]['procedure_id'];
									
									
									$getProcedureDetails = [];
									if(!empty($appointments[$appKey][$subDataKey]['procedure_id'])){
										$checkProcedureDetails = Procedure::where('id',$appointments[$appKey][$subDataKey]['procedure_id'])->get()->first();
										if($checkProcedureDetails){
											$getProcedureDetails = $checkProcedureDetails->toArray();
										}
									}
									$appointmentFinalDataArr[$appKey][$subDataKey]['patient_id'] = $appointments[$appKey][$subDataKey][$sbDataKey]['id'];
									if($appointments[$appKey][$subDataKey][$sbDataKey]['customer_number']==''){
										$appointmentFinalDataArr[$appKey][$subDataKey]['customer_number'] = "";
									}else{
										$appointmentFinalDataArr[$appKey][$subDataKey]['customer_number'] = $appointments[$appKey][$subDataKey][$sbDataKey]['customer_number'];
									}
									$appointmentFinalDataArr[$appKey][$subDataKey]['patient_name'] = $appointments[$appKey][$subDataKey][$sbDataKey]['name'];
									
									
									$appointmentFinalDataArr[$appKey][$subDataKey]['patient_phone'] = $appointments[$appKey][$subDataKey][$sbDataKey]['phone'];
									$getPatientDetails = [];
									if(!empty($appointments[$appKey][$subDataKey][$sbDataKey]['id'])){
										$checkPatientDetails  = UserDetail::where('user_id', $appointments[$appKey][$subDataKey][$sbDataKey]['id'])->get()->first();
										if($checkPatientDetails){
											$getPatientDetails = $checkPatientDetails->toArray();
										}
									}
									if(!empty($getPatientDetails)){
										if(!empty($getPatientDetails['profile_picture'])){
											$appointmentFinalDataArr[$appKey][$subDataKey]['patient_profile_picture']=$getPatientDetails['profile_picture'];
										}else{
											$appointmentFinalDataArr[$appKey][$subDataKey]['patient_profile_picture']="";
										}
										
										if(!empty($getPatientDetails['age'])){
											$appointmentFinalDataArr[$appKey][$subDataKey]['patient_age'] = $getPatientDetails['age'];
										}else{
											$appointmentFinalDataArr[$appKey][$subDataKey]['patient_age'] = "";
										}
									}
									$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_id']=$appointments[$appKey][$subDataKey]['id'];
									$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_date']=date('Y-m-d',strtotime($appointments[$appKey][$subDataKey]['appointment_date']));
									$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_time']=date('H:i:s',strtotime($appointments[$appKey][$subDataKey]['appointment_date']));
									$appointmentFinalDataArr[$appKey][$subDataKey]['type']=NULL;
									if(!empty($getProcedureDetails)){
										$appointmentFinalDataArr[$appKey][$subDataKey]['type']=$getProcedureDetails['track_status'];									
									}
									$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status'] = "blue";
									if(!empty($getProcedureDetails)){
										if($getProcedureDetails['total_payment']==$getProcedureDetails['pending_payment']){
											$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="blue";
										}elseif($getProcedureDetails['pending_payment']>0){
											$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="red";
										}elseif($getProcedureDetails['pending_payment']==0){
											$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="green";
										}elseif(($getProcedureDetails['track_status']=="follow_up")||($getProcedureDetails['track_status']=="review")||($getProcedureDetails['track_status']=="completed")){
											$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="orange";
										}
										
										$getAnalysisReportDetails= [];
										if(!empty($getProcedureDetails['report_id'])){
											$checkAnalysisReportDetails = HairTransplantReport::where('id',$getProcedureDetails['report_id'])->get()->first();
											if($checkAnalysisReportDetails){
												$getAnalysisReportDetails = $checkAnalysisReportDetails->toArray();
											}
										}
										$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'] = NULL;
										if(!empty($getAnalysisReportDetails)){
											$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports']=$getAnalysisReportDetails;
											foreach($getAnalysisReportDetails as $ARkey => $ARval){
												if($ARkey=="medical_condition"){
													if(empty($getAnalysisReportDetails[$ARkey])){
														$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey] = "";
													}else{
														$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey] = $getAnalysisReportDetails[$ARkey];
													}
												}else{
													$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey]=$getAnalysisReportDetails[$ARkey];
												}
											}
										}
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['notes']="";
										if($appointments[$appKey][$subDataKey]['note']!=''){
											$appointmentFinalDataArr[$appKey][$subDataKey]['notes']=$appointments[$appKey][$subDataKey]['note'];
										}
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['total_payment']=0;
										if($getProcedureDetails['total_payment']!=''){
											$appointmentFinalDataArr[$appKey][$subDataKey]['total_payment']=$getProcedureDetails['total_payment'];
										}
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['advance_payment']=0;
										if($getProcedureDetails['advanced_payment']!=''){
											$appointmentFinalDataArr[$appKey][$subDataKey]['advance_payment']=$getProcedureDetails['advanced_payment'];
										}
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['pending_payment']=0;
										if($getProcedureDetails['pending_payment']!=''){
											$appointmentFinalDataArr[$appKey][$subDataKey]['pending_payment']=$getProcedureDetails['pending_payment'];
										}
										
										if(($appointments[$appKey][$subDataKey]['doctor_approved']==1)&&
										($appointments[$appKey][$subDataKey]['user_approved']==1)&&
										($appointments[$appKey][$subDataKey]['report_check']==1)){
											$appointmentFinalDataArr[$appKey][$subDataKey]['is_promote']=1;
										}else{
											$appointmentFinalDataArr[$appKey][$subDataKey]['is_promote']=0;
										}
									}
									$OperationList = OperationList::where('user_id',$appointmentFinalDataArr[$appKey][$subDataKey]['patient_id'])->where('doctor_id',$appointmentFinalDataArr[$appKey][$subDataKey]['doctor_id'])->where('appointment_id',$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_id'])->first();
									
									$oprationDatadate = '';
									$oprationDatatime = '';
									if($OperationList){
										$oprationDatadate = date('d M,Y',strtotime($OperationList->operation_date));
										$oprationDatatime = date('h:i:s',strtotime($OperationList->operation_date));
									}
									$appointmentFinalDataArr[$appKey][$subDataKey]['operation_date']=$oprationDatadate;
									$appointmentFinalDataArr[$appKey][$subDataKey]['operation_time']=$oprationDatatime;
									
									$checkDoctorClinicName = Doctors::select(['clinic_address'])->where('user_id',$request->input('doctor_id'))->get()->first();
									if($checkDoctorClinicName){
										$appointmentFinalDataArr[$appKey][$subDataKey]['clinic_address'] = $checkDoctorClinicName->clinic_address;
									}
									
									break;
								}									
							}
						}
					}
				}
				if(($appKey!="current_page")&&($appKey!="data")){
					$appointmentFinalDataArr[$appKey] = $appointments[$appKey];					
				}
				
			}
		}
		
		if($appointmentFinalDataArr){
			return response()->json(['status'=>true, 'appointments' => $appointmentFinalDataArr], $this->successStatus); 
		} else {
			return response()->json(['status'=>true, 'appointments' => []], $this->successStatus); 			
		}
    }
    */
    public function doctorAppointments(Request $request) {
		if($request->appointment_type != "history"){
			$validator = Validator::make($request->all(), [ 
            'doctor_id'	  => 'required', 
            'max-results' => 'required', 
			]);
			if ($validator->fails()) { 						
				foreach($validator->errors()->toArray() as $key=>$er) {
					$err[] = $er[0];
				}
				return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
			}
			$predate 	   = date('Y-m-d 00:00:00');
			$doctor_id     = $request->input('doctor_id');
			$total_records = $request->input('max-results');
			if($request->assistant_id != "0"){
				$checkappointments  = AppointmentList::where('assistant_ids', $request->assistant_id)->whereNotIn('appointment_status',['cancel'])->where('appointment_date','>=', $predate)->where('status','1')->with(['user_detail'])->with('serviceDetail')->orderBy('appointment_date', 'asc')->paginate($total_records);
			}else{
				$checkappointments  = AppointmentList::where('doctor_id', $doctor_id)->whereNotIn('appointment_status',['cancel'])->where('appointment_date','>=', $predate)->where('status','1')->with(['user_detail'])->with('serviceDetail')->orderBy('appointment_date', 'asc')->paginate($total_records);
			}
			if($checkappointments){
				$appointments = $checkappointments->toArray();
			}
			$appointmentFinalDataArr = [];
			$appointmentKeyArr = [];
			if(!empty($appointments)){
				$incrementID = array();
				foreach($appointments as $appKey => $appVal){
					if($appKey=="current_page"){
						$appointmentFinalDataArr[$appKey] = $appointments[$appKey];					
					}
					if($appKey=="data"){
						$i = 0;	
						$f = 0;	
						$intaArr = array();					
						foreach($appointments[$appKey] as $subDataKey => $subDataVal){
							if(!isset($intaArr[$appointments[$appKey][$subDataKey]['procedure_id']])){
								$intaArr[$appointments[$appKey][$subDataKey]['procedure_id']] = 1;
							}else{					
								$intaArr[$appointments[$appKey][$subDataKey]['procedure_id']]+=1;
							}
							if(isset($incrementID[$appointments[$appKey][$subDataKey]['user_detail']['id']]))
							{
								$incrementID[$appointments[$appKey][$subDataKey]['user_detail']['id']] += 1;
								$i++;
							}
							else
							{
								$incrementID[$appointments[$appKey][$subDataKey]['user_detail']['id']] = 1;
								$i=1;
							}
							$serviceName = 'N/A';
							if($subDataVal['service_detail']){
								$serviceName = $subDataVal['service_detail']['sub_name_en'];
							}
										
										
							foreach($appointments[$appKey][$subDataKey] as $sbDataKey => $sbDataVal){				
									$appointmentFinalDataArr[$appKey][$subDataKey]['appointmentStatus']= $appointments[$appKey][$subDataKey]['appointment_status'];
									if($sbDataKey=="user_detail"){
										$appointmentFinalDataArr[$appKey][$subDataKey]['doctor_id'] = $appointments[$appKey][$subDataKey]['doctor_id'];
										$appointmentFinalDataArr[$appKey][$subDataKey]['procedure_id'] = $appointments[$appKey][$subDataKey]['procedure_id'];
										$getProcedureDetails = [];
										if(!empty($appointments[$appKey][$subDataKey]['procedure_id'])){
											$checkProcedureDetails = Procedure::where('id',$appointments[$appKey][$subDataKey]['procedure_id'])->get()->first();
											if($checkProcedureDetails){
												$getProcedureDetails = $checkProcedureDetails->toArray();
											}
										}									
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['patient_id'] = $appointments[$appKey][$subDataKey][$sbDataKey]['id'];
										if($appointments[$appKey][$subDataKey][$sbDataKey]['customer_number']==''){
											$appointmentFinalDataArr[$appKey][$subDataKey]['customer_number'] = "";
										}else{
											$appointmentFinalDataArr[$appKey][$subDataKey]['customer_number'] = $appointments[$appKey][$subDataKey][$sbDataKey]['customer_number'];
										}
										$appointmentFinalDataArr[$appKey][$subDataKey]['patient_name'] = $appointments[$appKey][$subDataKey][$sbDataKey]['name'];
										$appointmentFinalDataArr[$appKey][$subDataKey]['patient_phone'] = $appointments[$appKey][$subDataKey][$sbDataKey]['phone'];
										$getPatientDetails = [];
										if(!empty($appointments[$appKey][$subDataKey][$sbDataKey]['id'])){
											$checkPatientDetails  = UserDetail::where('user_id', $appointments[$appKey][$subDataKey][$sbDataKey]['id'])->get()->first();
											if($checkPatientDetails){
												$getPatientDetails = $checkPatientDetails->toArray();
											}
										}
										if(!empty($getPatientDetails)){
											if(!empty($getPatientDetails['profile_picture'])){
												$appointmentFinalDataArr[$appKey][$subDataKey]['patient_profile_picture']=$getPatientDetails['profile_picture'];
											}else{
												$appointmentFinalDataArr[$appKey][$subDataKey]['patient_profile_picture']="";
											}
											
											if(!empty($getPatientDetails['age'])){
												$appointmentFinalDataArr[$appKey][$subDataKey]['patient_age'] = $getPatientDetails['age'];
											}else{
												$appointmentFinalDataArr[$appKey][$subDataKey]['patient_age'] = "";
											}
										}
										$assistant_name = "";
										if($appointments[$appKey][$subDataKey]['assistant_ids'] != ""){
											$getAssistant = User::find($appointments[$appKey][$subDataKey]['assistant_ids']);
											if($getAssistant){
												$assistant_name = $getAssistant->name;
											}
										}
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_id']=$appointments[$appKey][$subDataKey]['id']; 
										$appointmentFinalDataArr[$appKey][$subDataKey]['assistant_name']=$assistant_name; 
										$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_id_incremented']=$intaArr[$appointments[$appKey][$subDataKey]['procedure_id']]; // Auto Increamented id 
										$appointmentFinalDataArr[$appKey][$subDataKey]['is_visited']=$appointments[$appKey][$subDataKey]['is_visited'];
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['visit_first']=$appointments[$appKey][$subDataKey]['visit_first'];
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['call_status']=$appointments[$appKey][$subDataKey]['call_status'];
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['service_name']=$serviceName;
										$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_date']=date('Y-m-d',strtotime($appointments[$appKey][$subDataKey]['appointment_date']));
										$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_time']=date('H:i:s',strtotime($appointments[$appKey][$subDataKey]['appointment_date']));
										
										$fromAppointTIme = date('h:i A',strtotime($appointments[$appKey][$subDataKey]['appointment_date']));
										$toAppointTIme = date('h:i A',strtotime($appointments[$appKey][$subDataKey]['appointment_to_date']));
										$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_time_new']= $fromAppointTIme.' TO '.$toAppointTIme;
										$appointmentFinalDataArr[$appKey][$subDataKey]['type']="";
										$appointmentFinalDataArr[$appKey][$subDataKey]['p_offer_apply']="";
										if(!empty($getProcedureDetails)){
											$appointmentFinalDataArr[$appKey][$subDataKey]['type']=$getProcedureDetails['track_status'];									
											if(empty($getProcedureDetails['offer_apply'])){
												$appointmentFinalDataArr[$appKey][$subDataKey]['p_offer_apply']="";
											}else{
												$appointmentFinalDataArr[$appKey][$subDataKey]['p_offer_apply']=(string)$getProcedureDetails['offer_apply'];
											}		
											$procedure_stat = $getProcedureDetails['procedure_stat'];							
										}else{
											$procedure_stat = "fix";	
										}
										$appointmentFinalDataArr[$appKey][$subDataKey]['procedure_stat'] = $procedure_stat;
										$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status'] = "blue";
										$obj = [];
										$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'] =(object)$obj;
										$appointmentFinalDataArr[$appKey][$subDataKey]['notes']="Promote Procedure";
										$appointmentFinalDataArr[$appKey][$subDataKey]['total_payment']=0;
										$appointmentFinalDataArr[$appKey][$subDataKey]['advance_payment']=0;
										$appointmentFinalDataArr[$appKey][$subDataKey]['pending_payment']=0;
										if(!empty($getProcedureDetails)){
											$OperationList = OperationList::where('appointment_id',$appointments[$appKey][$subDataKey]['id'])->first();
											$flag = "0";
											$j = 0;
											if($OperationList){
												$j = 1;
												if($OperationList->doctor_approved = "1" && $OperationList->user_approved == "1"){
													$flag = "1";
												}
											}
											if($j == 0){
												$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="blue";
											}else if($getProcedureDetails['pending_payment']>0){
												$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="red";
											}else if($getProcedureDetails['pending_payment'] == 0 && $flag == "0"){
												$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="red";
											}elseif($getProcedureDetails['pending_payment']==0 && ($getProcedureDetails['track_status']=="follow_up"||$getProcedureDetails['track_status']=="review"||$getProcedureDetails['track_status'] != "completed" ) && $flag == "1"){
												$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="green";
											}elseif(($getProcedureDetails['track_status']=="follow_up")||($getProcedureDetails['track_status']=="review")||($getProcedureDetails['track_status']=="completed" && $flag == "1")){
												$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="orange";
											}
											
											/* Check if the same procedure appointments have done */
											if($getProcedureDetails['track_status'] == "completed" && $getProcedureDetails['complete_date'] != ""){
												$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="orange";
											}
											$getAnalysisReportDetails = [];
											if(!empty($getProcedureDetails['report_id'])){
												//if($getProcedureDetails['type'] == "offer"){
												//	$checkAnalysisReportDetails = HairTransplantReport::where('id',$getProcedureDetails['report_id'])->first();
												//}else{
												//	$checkAnalysisReportDetails = HairTransplantReport::where('id',$getProcedureDetails['preportid'])->first();
												//}
												$checkAnalysisReportDetails = HairTransplantReport::where('id',$getProcedureDetails['report_id'])->first();
												if($checkAnalysisReportDetails){
													$getAnalysisReportDetails = $checkAnalysisReportDetails->toArray();
												}
											}
											if(!empty($getAnalysisReportDetails)){
												$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports']=$getAnalysisReportDetails;
												foreach($getAnalysisReportDetails as $ARkey => $ARval){
													if($ARkey == "affected_gallery" && $ARval == ""){
														$ARval = "N/A";
													}
													
													$getAnalysisReportDetails[$ARkey] = $ARval;
													if($ARkey=="offer_apply"){
														if(empty($getAnalysisReportDetails[$ARkey])){
															$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey] = 0;
														}else{
															$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey] = $getAnalysisReportDetails[$ARkey];
														}
													}else if($ARkey=="medical_condition"){
														if(empty($getAnalysisReportDetails[$ARkey])){
															$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey] = "";
														}else{
															$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey] = $getAnalysisReportDetails[$ARkey];
														}
													}else{
														$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey]=$getAnalysisReportDetails[$ARkey];
													}
												}
											}
											
											if($appointments[$appKey][$subDataKey]['note']!=''){
												$appointmentFinalDataArr[$appKey][$subDataKey]['notes']=$appointments[$appKey][$subDataKey]['note'];
											}
											
											if($getProcedureDetails['total_payment']!=''){
												$appointmentFinalDataArr[$appKey][$subDataKey]['total_payment']=$getProcedureDetails['total_payment'];
											}
											
											if($getProcedureDetails['advanced_payment']!=''){
												$appointmentFinalDataArr[$appKey][$subDataKey]['advance_payment']=$getProcedureDetails['advanced_payment'];
											}
													
											if($getProcedureDetails['pending_payment']!=''){
												$appointmentFinalDataArr[$appKey][$subDataKey]['pending_payment']=$getProcedureDetails['pending_payment'];
											}
											
											if(($appointments[$appKey][$subDataKey]['doctor_approved']==1)&&
												($appointments[$appKey][$subDataKey]['user_approved']==1)&&
												($appointments[$appKey][$subDataKey]['report_check']==1)){
												$appointmentFinalDataArr[$appKey][$subDataKey]['is_promote']=1;
											}else{
												$appointmentFinalDataArr[$appKey][$subDataKey]['is_promote']=0;
											}
										}
										
										$OperationList = OperationList::where('user_id',$appointmentFinalDataArr[$appKey][$subDataKey]['patient_id'])->where('doctor_id',$appointmentFinalDataArr[$appKey][$subDataKey]['doctor_id'])->where('appointment_id',$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_id'])->first();
										
										$oprationDatadate = '';
										$oprationDatatime = '';
										if($OperationList){
											$oprationDatadate = date('d M,Y',strtotime($OperationList->operation_date));
											$oprationDatatime = date('h:i:s',strtotime($OperationList->operation_date));
										}else{
											$appointmentFinalDataArr[$appKey][$subDataKey]['is_promote'] = 2;
										}
										$appointmentFinalDataArr[$appKey][$subDataKey]['operation_date']=$oprationDatadate;
										$appointmentFinalDataArr[$appKey][$subDataKey]['operation_time']=$oprationDatatime;
											
										$checkDoctorClinicName = Doctors::select(['clinic_address'])->where('user_id',$appointmentFinalDataArr[$appKey][$subDataKey]['doctor_id'])->get()->first();
										if($checkDoctorClinicName){
											if($checkDoctorClinicName->clinic_address == ""){
												$checkDoctorClinicName->clinic_address = "No Address Found";
											}
											$appointmentFinalDataArr[$appKey][$subDataKey]['clinic_address'] = $checkDoctorClinicName->clinic_address;
										}
										break;
									}								
									
							}
							
						}
					}
					
					if(($appKey!="current_page")&&($appKey!="data")){
						$appointmentFinalDataArr[$appKey] = $appointments[$appKey];					
					}
				}
			}
		
			if($appointmentFinalDataArr){
				foreach($appointmentFinalDataArr as $k => $v){
					$appointmentKeyArr[] =$k; 
					if($k=="data"){
						foreach($appointmentFinalDataArr['data'] as $k => $v){
							foreach($appointmentFinalDataArr['data'][$k] as $sbk => $sbv){
								$appointmentFinalDatArr['data'][$k][$sbk]=$appointmentFinalDataArr['data'][$k][$sbk];
							}
						}
					}else{
						$appointmentFinalDatArr[$k]=$appointmentFinalDataArr[$k];
					}
				}
				if(in_array("data",$appointmentKeyArr)){
					return response()->json(['status'=>true, 'appointments' => $appointmentFinalDatArr], $this->successStatus); 
				}else{
					return response()->json(['status'=>false, 'message' => "No appointment is available"], $this->errorStatus); 
				}
			} else {
				return response()->json(['status'=>true, 'appointments' => []], $this->successStatus); 			
			}
		}
		else{
			$validator = Validator::make($request->all(), [ 
            'doctor_id'	  => 'required', 
            'max-results'	  => 'required', 
			]);
			if ($validator->fails()) { 						
				foreach($validator->errors()->toArray() as $key=>$er) {
					$err[] = $er[0];
				}
				return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
			} 
			
			$predate 	   = date('Y-m-d h:i:d');
			$doctor_id     = $request->input('doctor_id');
			$total_records = $request->input('max-results');
			if($request->assistant_id != "0"){
				//$checkappointments  = AppointmentList::where('assistant_ids', $request->assistant_id)->whereNotin('appointment_status',['cancel'])->where('doctor_approved','1')->where('user_approved','1')->where('report_check','1')->where('appointment_date','!=','')->where('status','1')->with(['user_detail'])->orderBy('appointment_date', 'asc')->paginate($total_records);
				
				/* new change to show all appointments after discussion */
				$checkappointments  = AppointmentList::where('assistant_ids', $request->assistant_id)->where('status','1')->where('appointment_date','!=','')->with(['user_detail'])->orderBy('appointment_date', 'asc')->paginate($total_records);
			}else{
				//$checkappointments  = AppointmentList::where('doctor_id', $doctor_id)->where('doctor_approved','1')->whereNotin('appointment_status',['cancel'])->where('user_approved','1')->where('report_check','1')->where('status','1')->where('appointment_date','!=','')->with(['user_detail'])->orderBy('appointment_date', 'asc')->paginate($total_records);
				/* new change to show all appointments after discussion */
				$checkappointments  = AppointmentList::where('doctor_id', $doctor_id)->where('status','1')->where('appointment_date','!=','')->with(['user_detail'])->orderBy('appointment_date', 'asc')->paginate($total_records);
			}
			if($checkappointments){
				$appointments = $checkappointments->toArray();
			}
			$appointmentFinalDataArr = [];
			$appointmentKeyArr = [];
			if(!empty($appointments)){
				$incrementID = array();
				foreach($appointments as $appKey => $appVal){
					if($appKey=="current_page"){
						$appointmentFinalDataArr[$appKey] = $appointments[$appKey];					
					}
					if($appKey=="data"){
						$i = 0;	
						$f = 0;	
						$intaArr = array();					
						foreach($appointments[$appKey] as $subDataKey => $subDataVal){
							if(!isset($intaArr[$appointments[$appKey][$subDataKey]['procedure_id']])){
								$intaArr[$appointments[$appKey][$subDataKey]['procedure_id']] = 1;
							}else{					
								$intaArr[$appointments[$appKey][$subDataKey]['procedure_id']]+=1;
							}
							if(isset($incrementID[$appointments[$appKey][$subDataKey]['user_detail']['id']]))
							{
								$incrementID[$appointments[$appKey][$subDataKey]['user_detail']['id']] += 1;
								$i++;
							}
							else
							{
								$incrementID[$appointments[$appKey][$subDataKey]['user_detail']['id']] = 1;
								$i=1;
							}
							foreach($appointments[$appKey][$subDataKey] as $sbDataKey => $sbDataVal){				
									$appointmentFinalDataArr[$appKey][$subDataKey]['appointmentStatus']= $appointments[$appKey][$subDataKey]['appointment_status'];
									if($sbDataKey=="user_detail"){
										$appointmentFinalDataArr[$appKey][$subDataKey]['doctor_id'] = $appointments[$appKey][$subDataKey]['doctor_id'];
										$appointmentFinalDataArr[$appKey][$subDataKey]['procedure_id'] = $appointments[$appKey][$subDataKey]['procedure_id'];
										$getProcedureDetails = [];
										if(!empty($appointments[$appKey][$subDataKey]['procedure_id'])){
											$checkProcedureDetails = Procedure::where('id',$appointments[$appKey][$subDataKey]['procedure_id'])->get()->first();
											if($checkProcedureDetails){
												$getProcedureDetails = $checkProcedureDetails->toArray();
											}
										}									
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['patient_id'] = $appointments[$appKey][$subDataKey][$sbDataKey]['id'];
										if($appointments[$appKey][$subDataKey][$sbDataKey]['customer_number']==''){
											$appointmentFinalDataArr[$appKey][$subDataKey]['customer_number'] = "";
										}else{
											$appointmentFinalDataArr[$appKey][$subDataKey]['customer_number'] = $appointments[$appKey][$subDataKey][$sbDataKey]['customer_number'];
										}
										$appointmentFinalDataArr[$appKey][$subDataKey]['patient_name'] = $appointments[$appKey][$subDataKey][$sbDataKey]['name'];
										$appointmentFinalDataArr[$appKey][$subDataKey]['patient_phone'] = $appointments[$appKey][$subDataKey][$sbDataKey]['phone'];
										$getPatientDetails = [];
										if(!empty($appointments[$appKey][$subDataKey][$sbDataKey]['id'])){
											$checkPatientDetails  = UserDetail::where('user_id', $appointments[$appKey][$subDataKey][$sbDataKey]['id'])->get()->first();
											if($checkPatientDetails){
												$getPatientDetails = $checkPatientDetails->toArray();
											}
										}
										if(!empty($getPatientDetails)){
											if(!empty($getPatientDetails['profile_picture'])){
												$appointmentFinalDataArr[$appKey][$subDataKey]['patient_profile_picture']=$getPatientDetails['profile_picture'];
											}else{
												$appointmentFinalDataArr[$appKey][$subDataKey]['patient_profile_picture']="";
											}
											
											if(!empty($getPatientDetails['age'])){
												$appointmentFinalDataArr[$appKey][$subDataKey]['patient_age'] = $getPatientDetails['age'];
											}else{
												$appointmentFinalDataArr[$appKey][$subDataKey]['patient_age'] = "";
											}
										}
										$assistant_name = "";
										if($appointments[$appKey][$subDataKey]['assistant_ids'] != ""){
											$getAssistant = User::find($appointments[$appKey][$subDataKey]['assistant_ids']);
											if($getAssistant){
												$assistant_name = $getAssistant->name;
											}
										}
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_id']=$appointments[$appKey][$subDataKey]['id']; 
										$appointmentFinalDataArr[$appKey][$subDataKey]['assistant_name']=$assistant_name; 
										$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_id_incremented']=$intaArr[$appointments[$appKey][$subDataKey]['procedure_id']]; // Auto Increamented id 
										$appointmentFinalDataArr[$appKey][$subDataKey]['is_visited']=$appointments[$appKey][$subDataKey]['is_visited'];
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['visit_first']=$appointments[$appKey][$subDataKey]['visit_first'];
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['call_status']=$appointments[$appKey][$subDataKey]['call_status'];
										
										$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_date']=date('Y-m-d',strtotime($appointments[$appKey][$subDataKey]['appointment_date']));
										$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_time']=date('H:i:s',strtotime($appointments[$appKey][$subDataKey]['appointment_date']));
										
										$fromAppointTIme = date('h:i A',strtotime($appointments[$appKey][$subDataKey]['appointment_date']));
										$toAppointTIme = date('h:i A',strtotime($appointments[$appKey][$subDataKey]['appointment_to_date']));
										$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_time_new']= $fromAppointTIme.' TO '.$toAppointTIme;
										$appointmentFinalDataArr[$appKey][$subDataKey]['type']="";
										$appointmentFinalDataArr[$appKey][$subDataKey]['p_offer_apply']="";
										if(!empty($getProcedureDetails)){
											$appointmentFinalDataArr[$appKey][$subDataKey]['type']=$getProcedureDetails['track_status'];									
											if(empty($getProcedureDetails['offer_apply'])){
												$appointmentFinalDataArr[$appKey][$subDataKey]['p_offer_apply']="";
											}else{
												$appointmentFinalDataArr[$appKey][$subDataKey]['p_offer_apply']=(string)$getProcedureDetails['offer_apply'];
											}		
											$procedure_stat = $getProcedureDetails['procedure_stat'];							
										}else{
											$procedure_stat = "fix";	
										}
										$appointmentFinalDataArr[$appKey][$subDataKey]['procedure_stat'] = $procedure_stat;
										$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status'] = "blue";
										$obj = [];
										$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'] =(object)$obj;
										$appointmentFinalDataArr[$appKey][$subDataKey]['notes']="Promote Procedure";
										$appointmentFinalDataArr[$appKey][$subDataKey]['total_payment']=0;
										$appointmentFinalDataArr[$appKey][$subDataKey]['advance_payment']=0;
										$appointmentFinalDataArr[$appKey][$subDataKey]['pending_payment']=0;
										if(!empty($getProcedureDetails)){
											$OperationList = OperationList::where('appointment_id',$appointments[$appKey][$subDataKey]['id'])->first();
											$flag = "0";
											$j = 0;
											if($OperationList){
												$j = 1;
												if($OperationList->doctor_approved = "1" && $OperationList->user_approved == "1"){
													$flag = "1";
												}
											}
											if($j == 0){
												$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="blue";
											}else if($getProcedureDetails['pending_payment']>0){
												$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="red";
											}else if($getProcedureDetails['pending_payment'] == 0 && $flag == "0"){
												$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="red";
											}elseif($getProcedureDetails['pending_payment']==0 && ($getProcedureDetails['track_status']=="follow_up"||$getProcedureDetails['track_status']=="review"||$getProcedureDetails['track_status'] != "completed" ) && $flag == "1"){
												$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="green";
											}elseif(($getProcedureDetails['track_status']=="follow_up")||($getProcedureDetails['track_status']=="review")||($getProcedureDetails['track_status']=="completed" && $flag == "1")){
												$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="orange";
											}
											
											/* Check if the same procedure appointments have done */
											if($getProcedureDetails['track_status'] == "completed" && $getProcedureDetails['complete_date'] != ""){
												$appointmentFinalDataArr[$appKey][$subDataKey]['promote_status']="orange";
											}
											$getAnalysisReportDetails = [];
											if(!empty($getProcedureDetails['report_id'])){
												//if($getProcedureDetails['type'] == "offer"){
												//	$checkAnalysisReportDetails = HairTransplantReport::where('id',$getProcedureDetails['report_id'])->first();
												//}else{
												//	$checkAnalysisReportDetails = HairTransplantReport::where('id',$getProcedureDetails['preportid'])->first();
												//}
												$checkAnalysisReportDetails = HairTransplantReport::where('id',$getProcedureDetails['report_id'])->first();
												if($checkAnalysisReportDetails){
													$getAnalysisReportDetails = $checkAnalysisReportDetails->toArray();
												}
											}
											if(!empty($getAnalysisReportDetails)){
												$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports']=$getAnalysisReportDetails;
												foreach($getAnalysisReportDetails as $ARkey => $ARval){
													if($ARkey == "affected_gallery" && $ARval == ""){
														$ARval = "N/A";
													}
													
													$getAnalysisReportDetails[$ARkey] = $ARval;
													if($ARkey=="offer_apply"){
														if(empty($getAnalysisReportDetails[$ARkey])){
															$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey] = 0;
														}else{
															$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey] = $getAnalysisReportDetails[$ARkey];
														}
													}else if($ARkey=="medical_condition"){
														if(empty($getAnalysisReportDetails[$ARkey])){
															$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey] = "";
														}else{
															$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey] = $getAnalysisReportDetails[$ARkey];
														}
													}else{
														$appointmentFinalDataArr[$appKey][$subDataKey]['analysis_reports'][$ARkey]=$getAnalysisReportDetails[$ARkey];
													}
												}
											}
											
											if($appointments[$appKey][$subDataKey]['note']!=''){
												$appointmentFinalDataArr[$appKey][$subDataKey]['notes']=$appointments[$appKey][$subDataKey]['note'];
											}
											
											if($getProcedureDetails['total_payment']!=''){
												$appointmentFinalDataArr[$appKey][$subDataKey]['total_payment']=$getProcedureDetails['total_payment'];
											}
											
											if($getProcedureDetails['advanced_payment']!=''){
												$appointmentFinalDataArr[$appKey][$subDataKey]['advance_payment']=$getProcedureDetails['advanced_payment'];
											}
													
											if($getProcedureDetails['pending_payment']!=''){
												$appointmentFinalDataArr[$appKey][$subDataKey]['pending_payment']=$getProcedureDetails['pending_payment'];
											}
											
											if(($appointments[$appKey][$subDataKey]['doctor_approved']==1)&&
												($appointments[$appKey][$subDataKey]['user_approved']==1)&&
												($appointments[$appKey][$subDataKey]['report_check']==1)){
												$appointmentFinalDataArr[$appKey][$subDataKey]['is_promote']=1;
											}else{
												$appointmentFinalDataArr[$appKey][$subDataKey]['is_promote']=0;
											}
										}
										
										$OperationList = OperationList::where('user_id',$appointmentFinalDataArr[$appKey][$subDataKey]['patient_id'])->where('doctor_id',$appointmentFinalDataArr[$appKey][$subDataKey]['doctor_id'])->where('appointment_id',$appointmentFinalDataArr[$appKey][$subDataKey]['appointment_id'])->first();
										
										$oprationDatadate = '';
										$oprationDatatime = '';
										if($OperationList){
											$oprationDatadate = date('d M,Y',strtotime($OperationList->operation_date));
											$oprationDatatime = date('h:i:s',strtotime($OperationList->operation_date));
										}else{
											$appointmentFinalDataArr[$appKey][$subDataKey]['is_promote'] = 2;
										}
										$appointmentFinalDataArr[$appKey][$subDataKey]['operation_date']=$oprationDatadate;
										$appointmentFinalDataArr[$appKey][$subDataKey]['operation_time']=$oprationDatatime;
											
										$checkDoctorClinicName = Doctors::select(['clinic_address'])->where('user_id',$appointmentFinalDataArr[$appKey][$subDataKey]['doctor_id'])->get()->first();
										if($checkDoctorClinicName){
											if($checkDoctorClinicName->clinic_address == ""){
												$checkDoctorClinicName->clinic_address = "No Address Found";
											}
											$appointmentFinalDataArr[$appKey][$subDataKey]['clinic_address'] = $checkDoctorClinicName->clinic_address;
										}
										break;
									}								
									
							}
							
						}
					}
					
					if(($appKey!="current_page")&&($appKey!="data")){
						$appointmentFinalDataArr[$appKey] = $appointments[$appKey];					
					}
				}
			}
		
			if($appointmentFinalDataArr){
				foreach($appointmentFinalDataArr as $k => $v){
					$appointmentKeyArr[] =$k; 
					if($k=="data"){
						foreach($appointmentFinalDataArr['data'] as $k => $v){
							foreach($appointmentFinalDataArr['data'][$k] as $sbk => $sbv){
								$appointmentFinalDatArr['data'][$k][$sbk]=$appointmentFinalDataArr['data'][$k][$sbk];
							}
						}
					}else{
						$appointmentFinalDatArr[$k]=$appointmentFinalDataArr[$k];
					}
				}
				if(in_array("data",$appointmentKeyArr)){
					return response()->json(['status'=>true, 'appointments' => $appointmentFinalDatArr], $this->successStatus); 
				}else{
					return response()->json(['status'=>false, 'message' => "No appointment is available"], $this->errorStatus); 
				}
			} else {
				return response()->json(['status'=>true, 'appointments' => []], $this->successStatus); 			
			}
			
		}
    }
   
	/***
	 * Get Doctor Operaton
	**/	
	public function doctorOperations(Request $request) {
		$validator = Validator::make($request->all(), [ 
            'doctor_id'	  => 'required', 
            'max-results'	  => 'required', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
        
	   $doctor_id     = $request->input('doctor_id');
	   $total_records = $request->input('max-results');
	   $operations  = OperationList::where('doctor_id', $doctor_id)->with(['user_detail'])->paginate($total_records)->toArray();
		if($operations){
			return response()->json(['status'=>'success', 'operations' => $operations], $this->successStatus); 
		} else {
			return response()->json(['status'=>'success', 'operations' => []], $this->successStatus); 			
		}
	 	
    }
    
    
    /*
	 * Book Operation
	*/
	public function bookOperation(Request $request) {
		$validator = Validator::make($request->all(), [ 
            'doctor_id'	  => 'required',
            'user_id'	  => 'required',
            'dateof'	  => 'required'
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
        $OperationList = new OperationList;
        $OperationList->doctor_id 	= $request->input('doctor_id');
        $OperationList->user_id 	= $request->input('user_id');
        $OperationList->date 		= $request->input('dateof');
        $OperationList->save();
        return response()->json(['status'=>'success', 'message' => 'Operation Booked Successfully'], $this->successStatus); 
	}
    
    
    /***
	 * Get Doctor Appointment
	**/	
	public function getAppointmentRequests(Request $request) {
		$total_records = $request->input('max-results');
		if($request->assistant_id != "0"){
			$getPreappointments = AppointmentList::where('assistant_ids', $request->assistant_id)->where('status','1')->with(['user_detail'])->paginate($total_records)->toArray();
		}else{
			$getPreappointments = AppointmentList::where('doctor_id', $request->doctor_id)->where('status','1')->with(['user_detail'])->paginate($total_records)->toArray();
		}
		
		$predataArrays = [];
		$dataArrays = [];
		if(!empty($getPreappointments)){
			foreach($getPreappointments['data'] as $appointment){
				$predataArray['appointment_id'] 	= $appointment['id'];
				$predataArray['appointment_date'] 	= $appointment['appointment_date'];
				$predataArray['appointment_time'] 	= date('H:i a',strtotime($appointment['appointment_date']));
				$predataArray['user_name'] 		= $appointment['user_detail']['name'];
				$predataArray['service'] 			= $this->getService($appointment['service_id']);
				$predataArray['description'] 	    = "You have new appointment request";
				$predataArray['request_type'] 	    = "confirmed";
				$predataArrays[]                   = $predataArray;
			}	
		}
		$appointments  = AppointmentList::where('doctor_id', '0')->where('status','0')->with(['user_detail'])->paginate($total_records)->toArray();
		if($appointments){
			foreach($appointments['data'] as $appointment){
				$dataArray['appointment_id'] 	= $appointment['id'];
				$dataArray['appointment_date'] 	= $appointment['appointment_date'];
				$dataArray['appointment_time'] 	= date('H:i a',strtotime($appointment['appointment_date']));
				$dataArray['user_name'] 		= $appointment['user_detail']['name'];
				$dataArray['service'] 			= $this->getService($appointment['service_id']);
				$dataArray['description'] 	    = "You have new appointment request";
				$dataArray['request_type'] 	    = "new";
				$dataArrays[]                   = $dataArray;
			}	
			
		}
		
		$finalArray = array_merge($dataArrays,$predataArrays);
		if(!empty($finalArray)){
			return response()->json(['status'=>'success', 'appointments' => $finalArray], $this->successStatus); 
		} else {
			return response()->json(['status'=>'success', 'appointments' => []], $this->successStatus); 			
		}
		
    }
    
    /*
	 * confirm/reject appointment request
	 * @return dataArray
	**/
	 
	public function confirmRequests(Request $request){
		$today 				  = date('Y-m-d');
		$today                = $today.' 00:00 '.
		$from 				  = date('Y-m-d' . ' 00:00:00', time()); 
		$to 				  = date('Y-m-d' . ' 24:00:00', time());
		$AppointmentListCountDoctor = 1;
		$AppointmentListCount = 0;
		if($request->input('assistant_id') != "0"){
			$AppointmentListCount = AppointmentList::where('assistant_ids',$request->input('assistant_id'))->where('status','1')->whereDate('created_at', date('Y-m-d'))->distinct('procedure_id')->count('procedure_id');
						
			$AppointmentListCountDoctor = AppointmentList::where('doctor_id',$request->input('doctor_id'))->where('status','1')->whereDate('created_at', date('Y-m-d'))->distinct('procedure_id')->count('procedure_id');
			
			$users 			= User::where('id',$request->assistant_id)->first();			
			
			//$procedure = Procedure::where('assistant_id',$request->input('assistant_id'))->count();
		}else{
			$AppointmentListCount = AppointmentList::where('doctor_id',$request->input('doctor_id'))->where('status','1')->whereDate('created_at', date('Y-m-d'))->distinct('procedure_id')->count('procedure_id');
			
			$users 			= User::where('id',$request->doctor_id)->first();
			//$procedure = Procedure::where('doctor_id',$request->input('doctor_id'))->count();
		}
				
		$doc 			= User::where('id',$request->doctor_id)->first();
		$assistant = DoctorAssistant::with(array('user' => function($q){ 
						 $q->select('id','name','email', 'phone','added_by','request_recieve_per_day','device_token');
					}))->where('doctor_id', $request->input('doctor_id'))->get();
					
		//print_r($assistant); die;
		
		
		$device_token = '';
		if($users){
			$device_token = $users->device_token;
		}
		
					
		if($users->request_recieve_per_day > $AppointmentListCount ){		
			
			
		$settings = Setting::all();
		//if($AppointmentListCount < $settings[0]->request_per_day){
			$AppointmentList = AppointmentList::where('id',$request->input('appointment_id'))->where('status','0')->first();
			if($AppointmentList){
				
					if($request->input('assistant_id') != "0" && $AppointmentListCountDoctor >= $doc->request_recieve_per_day)	 {
						return response()->json(['status'=>false, 'message' => 'Doctor Daily Appointment Accept Request Reached.  You can\'t accept this request.'], $this->successStatus);				
					}
			
				$AppointmentList->doctor_id = $request->input('doctor_id');
				if($request->input('assistant_id') != "0"){
					$AppointmentList->assistant_ids = $request->input('assistant_id');
					if($request->input('doctor_id') == "0" || $request->input('doctor_id') == ""){
						$DoctorAssistant = DoctorAssistant::where('user_id',$request->input('assistant_id'))->first();
						if($DoctorAssistant){
							$AppointmentList->doctor_id = $DoctorAssistant->doctor_id;
						}
					}
				}
				$AppointmentList->status 	= $request->input('status');
				$AppointmentList->save();
				$AppointmentRequest = AppointmentRequest::where('appointment_id',$request->input('appointment_id'))->where('doctor_id',$request->input('doctor_id'))->first();
				if($AppointmentRequest){
					$AppointmentRequest->status = $request->input('status');
					$AppointmentRequest->save();
				}
				$stat = 'Rejected';
				if($request->input('status') == 1){
					$stat = 'Confirmed';
				}
				$Procedure = Procedure::where('id',$AppointmentList->procedure_id)->first();
				if($Procedure){
					$Procedure->doctor_id 	 = $request->input('doctor_id');
					if($request->input('doctor_id') == "0" || $request->input('doctor_id') == ""){
						$DoctorAssistant = DoctorAssistant::where('user_id',$request->input('assistant_id'))->first();
						if($DoctorAssistant){
							$Procedure->doctor_id = $DoctorAssistant->doctor_id;
						}
					}
					
					$Procedure->track_status = 'visit_doc';
					$Procedure->save();
						// Add Referral points here...
					$user_id = $Procedure->user_id;
					$get_user_detail = User::where("id",$user_id)->first();
					$current_useremail = $get_user_detail->email;
				    $check_user_referred = ReferralData::where('ref_to_email',$current_useremail)->where('point_des','reffered to someone')->first();
					if(count($check_user_referred) != 0)
					{
						$ref_by_id = $check_user_referred->ref_from;
						$points_data = ReferralPointsData::all();
						$appointment_points	= $points_data[0]->appointment_points;
						$get_paid_amount = Procedure::where('id',$AppointmentList->procedure_id)->first();
						$check_point_exist = ReferralData::where('user_id',$ref_by_id)->where('point_des','appointment')->where('procedure_id',$AppointmentList->procedure_id)->first();
						if(count($check_point_exist) == 0)
						{
							$appointment_point = new ReferralData;
							$appointment_point->user_id = $ref_by_id;
							$appointment_point->ref_from = $ref_by_id;
							$appointment_point->ref_code = "";
							$appointment_point->ref_to_email = $current_useremail;
							$appointment_point->ref_to_phone = "";
							$appointment_point->status = "1";
							$appointment_point->ref_type = "appointment";
							$appointment_point->points = $appointment_points;
							$appointment_point->point_des = "appointment";
							$appointment_point->procedure_id = $AppointmentList->procedure_id;
							$appointment_point->save();
						}
					}
					
					
					$AppointmentListstatus = AppointmentList::where('procedure_id',$Procedure->id)->first(['status']);

					$MobileNotification 	= new MobileNotification();
					
					$MobileNotification->user_id = $user_id;
					$MobileNotification->procedure_id = $Procedure->id;
					$MobileNotification->report_id = $Procedure->report_id;
					$MobileNotification->track_status = $Procedure->track_status;
					$MobileNotification->notification_status = $AppointmentListstatus->status;
					$MobileNotification->type = $Procedure->type;
					$MobileNotification->notification_type = 'Request Confirm';
					$MobileNotification->save();	
					
					$mobileDetail = array('user_id'=>$MobileNotification->user_id,'procedure_id'=>$MobileNotification->procedure_id,'report_id'=>$MobileNotification->report_id,'track_status'=>$MobileNotification->track_status,'notification_status'=>$MobileNotification->notification_status,'type'=>$MobileNotification->type,'notification_type'=>$MobileNotification->notification_type);
					
					//print_r($MobileNotification); die;
						
				    $users = User::where('id',$user_id)->first();
				    $device_id = $users->device_id;
					if($device_id !=""){						
						$this->AppointmentChangeForWeb($device_id , $mobileDetail);
						
					}
					
				}							
					
				
				return response()->json(['status'=>true, 'message' => 'Request has been successfully '.$stat.'.'], $this->successStatus);
			}else{
				return response()->json(['status'=>false, 'message' => 'Request has been already confirmed by others.'], $this->successStatus);
			}
		/*}else{
			return response()->json(['status'=>false, 'message' => 'Your Request Limit Exceed. Please contact with admin.'], $this->successStatus);
		}*/
		
		
		}else{
		
		return response()->json(['status'=>false, 'message' => 'Your Daily Appointment Accept Request Reached Please contact Admin.'], $this->successStatus);
		}
		
		
	}
	
	
	public function asignAssistant(Request $request){
		$appointment_id   = $request->appointment_id;
		$procedure_id     = $request->procedure_id;
		$assistant_id 	  = $request->assistant_id;
		$AppointmentLists = AppointmentList::where('procedure_id',$procedure_id)->get();
		if(!$AppointmentLists->isEmpty()){
			foreach($AppointmentLists as $AppointmentList){
				$AppointmentList->assistant_ids = $assistant_id;
				$AppointmentList->save();
			}
			return response()->json(['status'=>true, 'message' => 'Assistant is successfully assigned to the patient.'], $this->successStatus);
		}else{
			return response()->json(['status'=>true, 'message' => 'Appointment is no longer.'], $this->successStatus);
		}
	}
    
    
    public function getService($id){
		$Service 		= Service::find($id);
		$serviceName 	= '';
		if($Service){
			$serviceName = $Service->service_name;
		}
		return $serviceName;
	}
	
	
	public function ChangeAppointmentNotification($token) 
	{
		$optionBuilder = new OptionsBuilder();
		
		$optionBuilder->setTimeToLive(60*20);
		
		$notificationBuilder = new PayloadNotificationBuilder('Kabera');
		$notificationBuilder->setBody('Doctor has accepted your request')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		
		//$message1 =  Response::json(array('success'=>false,'message'=>$message));	
		
		
		$dataBuilder->addData(['message' => 'Request Confirm']);
			
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();

		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();

		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();

		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();

		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
		
		
	}
	
	
	public function NotificatinAssistant($token) 
	{
		$optionBuilder = new OptionsBuilder();
		
		$optionBuilder->setTimeToLive(60*20);
		
		$notificationBuilder = new PayloadNotificationBuilder('Kabera');
		$notificationBuilder->setBody('Your appointment with the Assistant is confirmed. Tap to view the details.')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		
		$dataBuilder->addData(['message' => 'Request Confirm']);
			
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();

		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();

		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();

		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();

		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();		
	}	
	
	
	
	public function AppointmentChangeForWeb($token,$mobileDetail) 
	{
		$optionBuilder = new OptionsBuilder();
		
		$optionBuilder->setTimeToLive(60*20);
		
		$notificationBuilder = new PayloadNotificationBuilder('Kabera');
		$notificationBuilder->setBody('Your appointment with the doctor is confirmed. Tap to view the details.')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		
		$dataBuilder->addData(['message' => 'Request Confirm', 'mobileDetail'=>$mobileDetail]);
			
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();

		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();

		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();

		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();

		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();		
	}	
	
	/*
	 * Doctor Procedures List With Call Detail 	
	*/
	 public function doctorProceduresList(Request $request) {
		
			$validator = Validator::make($request->all(), [ 
            'doctor_id'	  => 'required', 
            'max-results' => 'required', 
			]);
			if ($validator->fails()) { 						
				foreach($validator->errors()->toArray() as $key=>$er) {
					$err[] = $er[0];
				}
				return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
			}
			
		   $doctor_id     = $request->input('doctor_id');
		   $total_records = $request->input('max-results');
			
		   $totalList = AppointmentList::where('status','1')->whereNotIn('appointment_status',['cancel'])->where('doctor_id',$doctor_id)->with('user_detail')->with('serviceDetail')->with('call_records')->with('procedure')->orderBy('appointment_date', 'asc')->get()->toArray();
			
			
			if($totalList){
				return response()->json(['status'=>true, 'data' => $totalList], $this->successStatus); 
			} else {
				return response()->json(['status'=>false, 'data' => []], $this->successStatus); 			
			}		
	}
	
	/*
	 * Update Doctor Call Follow Up  	
	*/
	 public function updateCallFollowUp(Request $request) {
		
			$validator = Validator::make($request->all(), [ 
            'date'	  => 'required', 
            'time'    => 'required',  
            'dial_id' => 'required', 
			]);
			if ($validator->fails()) { 						
				foreach($validator->errors()->toArray() as $key=>$er) {
					$err[] = $er[0];
				}
				return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
			}
			
		   $dialId     = $request->input('dial_id');
		   $Dial 	   = Dials::find($dialId);
		   if($Dial) {
			   $Dial->follow_date = $request->input('date');
			   $Dial->follow_time = $request->input('time');
			   $Dial->note = $request->input('note');
			   $Dial->save();
			   return response()->json(['status'=>true, 'message' => 'Follow Up Updated Successfully'], $this->successStatus); 
		   } else {
			   return response()->json(['status'=>false, 'message' => 'Id Not Exist!'], $this->errorStatus); 
			   
		   }
		   	
	}
}
