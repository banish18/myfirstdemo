<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use Session;
use Validator;
use App\SmsApi;
use App\User;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;
use File;
use App\AppointmentList;
use App\Procedure;
use App\HairTransplantReport;
use App\AssistantProcedureRecords;
use App\Mail\SendOtpMail;
use App\Mail\ReportByDoctorMail;

class ReportController extends Controller
{
	public $successStatus = 200;
	public $errorStatus = 401;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       // $this->middleware(['auth','verified']);
       $this->langArr =  ['en','fr'];
    }
	/**
	 *Function Name: reportByPatient
	 *Function Arguments: one argument
	 *Function Purpose: To send images uploaded by patient
	 *Function Return: Return images uploaded by patient
	 **/
	public function reportByPatient(Request $request){
		$validator = Validator::make($request->all(), [ 
			'doctor_id'	   		=> 'required', 
			'patient_id'    	=> 'required', 
			'procedure_id'	=> 'required', 
		]);
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
			return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
		}
		
		$doctor_id		=	$request->input('doctor_id');
		$patient_id		=	$request->input('patient_id');
		$procedure_id	=	$request->input('procedure_id');
		$procedures	   =  Procedure::find($procedure_id);
		if($procedures){
			$rimgs = [];
			if(!empty($procedures->report_id)){
				if($procedures->user_report_images != ""){
					if(!empty($procedures->user_report_images)){
						if (strpos($procedures->user_report_images, ',') !== false) {
							$images=explode(',',$procedures->user_report_images);
							foreach($images as $imgKey => $imgVal){
								$rimgs[$imgKey]['images_path']=$images[$imgKey];
							}								
						}else{
							$rimgs[]['images_path']=$procedures->user_report_images;
						}
					}
				}
				$imgs = [];
				$getaffectedImages	   =  HairTransplantReport::select('affected_gallery')->where('id',$procedures->report_id)->first();
				if($getaffectedImages){
					if(!empty($getaffectedImages->affected_gallery)){
						if (strpos($getaffectedImages->affected_gallery, ',') !== false) {
							$images=explode(',',$getaffectedImages->affected_gallery);
							foreach($images as $imgKey => $imgVal){
								$imgs[$imgKey]['images_path']=$images[$imgKey];
							}								
						}else{
							$imgs[]['images_path']=$getaffectedImages->affected_gallery;
						}
						
					}					
				}
			}
			$finalImagesArr = array_merge($rimgs,$imgs);
			if(empty($finalImagesArr)){
				return response()->json(['status'=>false,'message'=>"No image is found"], $this->errorStatus); 
			}else{
				return response()->json(['status'=>true,'data'=>$finalImagesArr], $this->successStatus); 
			}
		}else{
			return response()->json(['status'=>false,'message'=>"No appointment is available"], $this->errorStatus);
		}
	}
	/**
	 *Function Name: reportByDoctor
	 *Function Arguments: one argument
	 *Function Purpose: To send images uploaded by doctor
	 *Function Return: Return images uploaded by doctor
	 **/
	public function reportByDoctor(Request $request){
		$validator = Validator::make($request->all(), [ 
			'doctor_id'	   		=> 'required', 
			'patient_id'    	=> 'required', 
			'appointment_id'	=> 'required', 			
		]);
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
			return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
		}
		$doctor_id		=	$request->input('doctor_id');
		$patient_id		=	$request->input('patient_id');
		$appointment_id	=	$request->input('appointment_id');
		$AppointmentList   =  AppointmentList::where('id',$appointment_id)->where('user_id',$patient_id)->where('doctor_id',$doctor_id)->first();
		$checkPatientDetails = User::select(['name','email','phone','device_token'])->where('id',$patient_id)->get()->first();
		if($checkPatientDetails){
			$getPatientDetails = $checkPatientDetails->toArray();
		}
		if(!empty($AppointmentList)){
			if (strpos($request->input('report_by_doctors'), ",") !== false) {
				$images = explode(",",$request->input('report_by_doctors'));				
			}else{
				$images[]  = $request->input('report_by_doctors');
			}
			$imagesArr = [];
			$saveimagesArr = [];
			if(is_array($images) && !empty($images)){
				foreach($images as $image){
					$folder         = 'doctor/report_by_doctors/';
					$random_number 	= mt_rand(100000, 999999);
					$f		   = finfo_open();
					$imgdata   = base64_decode($image);
					
					$mime_type = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
					$mime_type = explode('/',$mime_type);
					
					if(($mime_type[1]!="x-empty")&&($mime_type[1]!="plain")&&($mime_type[1]!="octet-stream")){
						$imageName 		= $random_number.'.'.$mime_type[1]; 
						File::put(public_path().'/images/'.$folder. $imageName, base64_decode($image));   
						$imagesArr[]['image_path'] = $folder.$imageName;
						$saveimagesArr[] = $folder.$imageName;						
					}
				}
				
				if(!empty($saveimagesArr)){
					$saveimagesArr[]= $AppointmentList->report_by_doctors;
					$AppointmentList->report_by_doctors =implode(',',$saveimagesArr);
					$AppointmentList->save();
				}
				
				if($request->assitant_id != "0"){
					/* save entry in the assistant record table if assistant cancel the appointment*/
					$AssistantProcedureRecords 						= new AssistantProcedureRecords;
					$AssistantProcedureRecords->assistant_id 		= $request->assistant_id;
					$AssistantProcedureRecords->procedure_id 		= $AppointmentList->procedure_id;
					$AssistantProcedureRecords->appointment_id 		= $AppointmentList->id;
					$AssistantProcedureRecords->user_id 			= $AppointmentList->user_id;
					$AssistantProcedureRecords->action 				= "upload_report";
					$AssistantProcedureRecords->reports 			= implode(',',$saveimagesArr);
					$AssistantProcedureRecords->save();
				}
			}
			//echo $AppointmentList->report_by_doctors; die();
			$imgs = [];
			$attachments =[];
			if((!empty($request->input('report_by_doctors')))){
				$attachments =[];
				if(strpos($AppointmentList->report_by_doctors, ',') !== false) {
					$images=explode(',',$AppointmentList->report_by_doctors);
					foreach($images as $imgKey => $imgVal){
						if(!empty($images[$imgKey])){
							$attachments[] =$images[$imgKey];
							$imgs[$imgKey]['images_path']=$images[$imgKey];
						}						
					}								
				}else{
					$attachments[] =$AppointmentList->report_by_doctors;
					$imgs[]['images_path']=$AppointmentList->report_by_doctors;
				}
				//Email to Patient
				$mdata['user_role']     = "Patient";
				$mdata['email']     = $getPatientDetails['email'];
				$mdata['name']      = $getPatientDetails['name'];
				$mdata['message']   = "Please find the attachment";
				/*$mdata['message']   = "This mail is to inform you that there is a new cancellation request  for the appointment scheduled of Mr ".$getPatientDetails['name']." with Dr. ".$getDoctorDetails['name']." on ".$appointment_date." at ".$appointment_time." in ".$getDoctorClinicName['clinic_name']." has been cancelled. Any update regarding the appointment will be informed to you through the mail. ";*/
				$mdata['caption']   = "Regards";
				$mdata['signature'] = "Kabera";
				$mdata['attachments'] = $attachments;
				//Mail::to($mdata['email'])->send(new ReportByDoctorMail($mdata));	
				Mail::to($mdata['email'])->send(new ReportByDoctorMail($mdata));
			}
			$imgs = [];
			$attachments =[];
			$procedureAppointmentLists   =  AppointmentList::where('procedure_id',$request->input('procedure_id'))->where('user_id',$patient_id)->where('doctor_id',$doctor_id)->get();
			if(!$procedureAppointmentLists->isEmpty()){
				foreach($procedureAppointmentLists as $list){
					if (strpos($list->report_by_doctors, ',') !== false) {
						$images=explode(',',$list->report_by_doctors);
						foreach($images as $imgKey => $imgVal){
							if(!empty($images[$imgKey])){
								$imgs[$imgKey]['images_path']=$images[$imgKey];
								$attachments[] =$images[$imgKey];
							}
						}								
					}else{
						if(!empty($list->report_by_doctors)){
							$attachments[]			= $list->report_by_doctors;
							$imgs[]['images_path']	= $list->report_by_doctors;
						}
					}
				}	
				return response()->json(['status'=>true,'message'=>'Uploaded successfully','data'=>$imgs], $this->successStatus); 
			}else{
				return response()->json(['status'=>false,'message'=>"No appointment is available"], $this->errorStatus);
			}
			
		}else{
			return response()->json(['status'=>false,'message'=>"No appointment is available"], $this->errorStatus); 
		}
	}
}
