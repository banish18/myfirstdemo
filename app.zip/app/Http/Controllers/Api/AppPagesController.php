<?php
namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use App\User;
use Image;
use Storage;
use App\Role;
use App\RoleUser;
use App\Doctors;
use App\AssistantProcedureRecords;
use App\OperationList;
use App\Service;
use App\SubService;
use App\DoctorAssistant;
use App\AppointmentList;
use App\WelcomePage;
use App\AppData;
use App\Offer;
use App\Banner;
use App\Procedure;
use App\PaymentType;
use Auth;


class ApppagesController extends Controller
{
	public $successStatus = 200;
	public $errorStatus   = 401;
	
    /**
     * Create a new controller instance.
     * @return void
    */
    public function __construct() {
		 
		//$this->middleware(['auth','verified']);
		$this->langArr =  ['en','fr'];
	}
	
	/*
	 * App welcome page slides
	 * @return slides Array
	*/	
	public function getWelcomeIntro(Request $request){
		
		$validator = Validator::make($request->all(), [ 
            'lang'	      => 'required', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
        
		$lang 	= $request->input('lang');
		$welcomedata = WelcomePage::all()->toArray();
		if($welcomedata){
			foreach($welcomedata as $data){
				$imgae = public_path().'/images/'.$data['image_path'];
				$imageData =  getimagesize($imgae);					
				$welcome['image_path'] 		= $data['image_path'];
				$welcome['image_height'] 	= $imageData[1];
				$welcome['image_width'] 	= $imageData[0];
				$welcome['title'] 			= $data['title_'.$lang];
				$welcome['description'] 	= $data['description_'.$lang];
				$dataArray[] = $welcome;
			}
		} else {
			$dataArra = [];	
		}
		
		if($dataArray){
			return response()->json(['status'=>'success', 'welcome' => $dataArray], $this->successStatus); 	
		}else{
			return response()->json(['status'=>'success', 'welcome' => 'No Data Available'], $this->successStatus);
		}
	}	
	
	/*
	 * App Home page content
	 * @return response
	*/	
	public function getHomeContent(Request $request){
		$validator = Validator::make($request->all(), [ 
            'lang' => 'required', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
        
		$lang 		 =  $request->input('lang');
		$banners	 =	[];
		$firstImg	 =	[];
		$secondImg	 =	[];
		
		//banners				
		$homeBanners =  AppData::where('template','Home')->where('data_type','home-banners')->first();		
		$homeBanners =  $homeBanners !== null ? json_decode($homeBanners->content_en, true) : ['first_banner'=>'','second_banner'=>''];
		
		if(!empty($homeBanners['first_banner'])) {
			$dataArray	  		        = $homeBanners;
			$firstimgae 		        = public_path().'/images/'.$homeBanners['first_banner'];
			$firstimageData 	        = getimagesize($firstimgae);					
			$firstImg['image_path'] 	= $homeBanners['first_banner'];
			$firstImg['image_height'] 	= $firstimageData[1];
			$firstImg['image_width'] 	= $firstimageData[0];
		}
		if(!empty($homeBanners['second_banner'])) {
			$secondimgae 		        = public_path().'/images/'.$homeBanners['second_banner'];
			$secondimageData 	        = getimagesize($secondimgae);					
			$secondImg['image_path'] 	= $homeBanners['second_banner'];
			$secondImg['image_height'] 	= $secondimageData[1];
			$secondImg['image_width'] 	= $secondimageData[0];
		}
		//offers
		$homeOffers  =  AppData::where('template','Home')->where('data_type','home-offers')->get();
		foreach($homeOffers as $key=>$offer) {	
			
			 $offer_data = Banner::with('service')->where('id',json_decode($offer->content_en)->offer)->first();
			 if(count($offer_data) != 0)
			 {
				$banner   = Banner::with('service')->where('id',json_decode($offer->content_en)->offer)->first(['id','banner_name','mobile_image','service'])->toArray();
				$bannerArr['id'] = $banner['id'];
				$bannerArr['offer_name']   = $banner['banner_name'];
				$bannerArr['description']  = "";
				
				$bannerArr['banner_image'] = $banner['mobile_image'];
				$imgae 	=  public_path().'/images/'.$banner['mobile_image'];
				if(file_exists($imgae)){
					$imageData =  getimagesize($imgae);
					$bannerArr['image_height'] = $imageData[1];
					$bannerArr['image_width'] 	= $imageData[0];				
				}
				else {
					$imageData = "";
					$bannerArr['image_height'] = 0;
					$bannerArr['image_width'] 	= 0;			
				}
							
				$bannerArr['image_path'] 	= $banner['mobile_image'];
				$bannerArr['service'] 	    = $banner['service']['service_name'];
				
				$banners[] = $bannerArr;
		 }
	  }
		
		//services 
		$services = Service::all();
		foreach($services as $key=>$val) {
			$serviceData['id'] = $val->id;
			$serviceData['service_name'] = ($lang == 'fr') ? $val->service_name_fr : $val->service_name;			
			$serviceData['service_description'] = $val['service_description_'.$lang];
			$serviceData['service_icon'] = $val->service_icon;
			$serviceArr[] = $serviceData;
		}
				
		//final data
		$dataArray['first_banner']  = $firstImg;
		$dataArray['second_banner'] = $secondImg;
		$dataArray['services']  	= $serviceArr;
		$dataArray['home_offers']   = $banners;
		
		//echo "<pre>"; print_r($dataArray); die;
		if($dataArray){
			return response()->json(['status'=>'success', 'home' => $dataArray], $this->successStatus); 	
		}else{
			return response()->json(['status'=>'success', 'home' => 'No Data Available'], $this->successStatus);
		}
	}

	
	/*
	 * App Hair procedure content
	 * @return response
	*/	
	public function getHairprocedureContent(Request $request){
		
		$validator = Validator::make($request->all(), [ 
            'lang'	      => 'required', 
            'service_id'  => 'required', 
        ]);
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
        $lang 		 =  $request->input('lang');
        $service_id  =  $request->input('service_id');
        $service     = SubService::where('service_id',$service_id)->get();
        $servicedataArr   = [];
        if(count($service) != 0)
        {
			
			foreach($service as $key => $val)
			{
				
				$subname = 'sub_name_'.$lang;
				$sub_description = 'sub_description_'.$lang;
				$servicedataArr[$key]['id'] = $val->id;
				$servicedataArr[$key]['service_name'] 	= $val->$subname;
				$servicedataArr[$key]['sub_description'] = $val->$sub_description;
				$servicedataArr[$key]['service_image'] 	= $val->service_image;
				$simgae =  public_path().'/images/'.$val->service_image;
				if($val->service_image != ""){
					$simageData 				=  getimagesize($simgae);					
					$servicedataArr[$key]['service_image_path'] 	= $val->service_image;
					$servicedataArr[$key]['service_image_height'] = $simageData[1];
					$servicedataArr[$key]['service_image_width'] 	= $simageData[0];
				}else{            
					$servicedataArr[$key]['service_image_path'] = "";
					$servicedataArr[$key]['service_image_height'] = 0;
					$servicedataArr[$key]['service_image_width'] 	= 0;
				}
			}
			return response()->json(['status'=>true, 'data' => $servicedataArr], $this->successStatus);
		}
		else
		{
			return response()->json(['status'=>false, 'data' => []], $this->successStatus);
		}		
	}
	
	
	public function getProcedurePayment(Request $request){
		$Procedure = Procedure::where('user_id',$request->user_id)->where('doctor_id',$request->doctor_id)->where('id',$request->procedure_id)->first();
		if($Procedure){
			$PaymentType = PaymentType::where('procedure_id',$request->procedure_id)->get();
			$cash = 0;
			$online = 0;
			if($PaymentType){
				foreach($PaymentType as $pay){
					if($pay->payment_type == "cash"){
						$cash += $pay->amount;
					}else{
						$online += $pay->amount;	
					}
				}
			}
			$id = $request->appointment_id;
			$OperationList = OperationList::where('appointment_id',$id)->where('procedure_id',$request->procedure_id)->where('user_id',$request->user_id)->first();
			$date = 'N/A';
			$time = 'N/A';
			if($OperationList){
				$date = date('d M,Y',strtotime($OperationList->operation_date));
				$time = date('h:i:s A',strtotime($OperationList->operation_date));
			}
			$appointment = AppointmentList::find($id);
			$doctor_aaproved = '0';
			$user_approved = '0';
			$report_check = '0';
			if($appointment){
				$doctor_approved = $appointment->doctor_approved; 
				$user_approved 	 = $appointment->user_approved; 
				$report_check 	 = $appointment->report_check; 
			}
			$total_payment 	 =  $Procedure->total_payment;
			$advance_payment = $cash+$online;
			$pending_payment = $Procedure->pending_payment;
			$data = ['total_payment' => $total_payment,'advance_payment' => $advance_payment,'pending_payment' => $pending_payment,'cash' => $cash,'online' => $online,'balance' => $Procedure->pending_payment,'doctor_approved' => $doctor_approved,'user_approved' => $user_approved,'report_check' => $report_check,'date' => $date,'time' => $time];
			/*$data = ['cash' => $cash,'online' => $online,'balance' => $Procedure->pending_payment,'doctor_approved' => $doctor_approved,'user_approved' => $user_approved,'report_check' => $report_check,'date' => $date,'time' => $time];*/
			return response()->json(['status'=>true, 'message' => 'Payment records.', 'data' => $data], $this->successStatus); 
		}else{
			return response()->json(['status'=>false, 'message' => 'Something went wrong.'], $this->errorStatus); 
		}
	}
	
	/* payment at doctor end */
	
	public function procedurePayment(Request $request){
		$Procedure = Procedure::where('user_id',$request->user_id)->where('doctor_id',$request->doctor_id)->where('id',$request->procedure_id)->first();
		$paymentType = $request->payment_type;
		if($paymentType == "card"){
			$paymentType = "online";
		}
		if($Procedure){
			if($Procedure->pending_payment != 0 && $Procedure->pending_payment >= $request->amount){
				$amount 					 = $request->amount;
				$Procedure->advanced_payment = $Procedure->advanced_payment+$amount;
				$Procedure->pending_payment  = $Procedure->pending_payment-$amount;
				$Procedure->save();
				$data = ['Total' => strval($Procedure->total_payment),'advance' => strval($Procedure->advanced_payment),'balance' => strval($Procedure->pending_payment)];
				
				$PaymentType 				= new PaymentType;
				$PaymentType->user_id  	    = $request->user_id;
				$PaymentType->procedure_id  = $request->procedure_id;
				$PaymentType->doctor_id  	= $request->doctor_id;
				$PaymentType->amount 		= $request->amount;
				$PaymentType->payment_type  = $paymentType;
				$PaymentType->save();
				
				if($request->assitant_id != "0"){
					/* save entry in the assistant record table if assistant cancel the appointment*/
					$AssistantProcedureRecords 						= new AssistantProcedureRecords;
					$AssistantProcedureRecords->assistant_id 		= $request->assistant_id;
					$AssistantProcedureRecords->procedure_id 		= $Procedure->id;
					$AssistantProcedureRecords->appointment_id 		= $request->appointment_id;
					$AssistantProcedureRecords->user_id 			= $Procedure->user_id;
					$AssistantProcedureRecords->action_id 			= $PaymentType->id;
					$AssistantProcedureRecords->action 				= "accept_payment";
					$AssistantProcedureRecords->save();
				}
				return response()->json(['status'=>true, 'message' => 'Payment sussessfully saved.', 'data' => $data], $this->successStatus); 	
			}else{
				$data = ['Total' => $Procedure->total_payment,'advance' => $Procedure->advanced_payment,'balance' => $Procedure->pending_payment];
				return response()->json(['status'=>false, 'message' => 'Paid Payment is greater then pending payment.', 'data' => $data], $this->successStatus); 
			}
		}else{
			return response()->json(['status'=>false, 'message' => 'Procedure is no longer with the database.', 'data' => ''], $this->errorStatus); 
		}
	}
	
	
}
