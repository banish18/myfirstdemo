<?php
namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Doctors;
use App\Product;
use App\User;
use App\UserDetail;
use App\DoctorMsg;
use App\Mail\AdminDoctorToAdminMail;
use Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;
use File;
use Config;
use DB;
use Image;
use Validator;

class DoctorMsgController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
    
	public $successStatus = 200;
	public $errorStatus = 401;
	
	public function __Construct(REQUEST $request){
		$this->flag = 1;
		$this->languages = Config::get('app.languages');
		if(!in_array($request->lang,$this->languages)){
			$this->flag = 0;
		}
	}
	
	/*
	 * get Prescription
	 * @return Prescription
	 * */
	 
	public function getmessage(Request $request){
	
	}
	
	/*
	 * Save Message
	 * @return Prescription
	 **/
	 
	public function savemessage(Request $request){
		$validator = Validator::make($request->all(), [ 
			'doctor_id'	  => 'required',
			'message'	  => 'required',
		]);
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
        }
		
		$user 	 			= User::find($request->doctor_id);
		$uname 	 			= 'N/A';
		$uemail 	 	    = 'N/A';
		$super_admin_email  = "dotstudent203@gmail.com";

		if($user){
			$uname 	= $user->name;
			$uemail 	= $user->email;
		}
		
		
		$msg = new DoctorMsg;
		$msg->doctor_id  = $request->doctor_id;
		$msg->message 	 = $request->message;
		$msg->email 	 = $uemail;

		$msg->save();
		
		$data = array('subject' => "A New Message From Doctor",'from' => "support@kabera.com", 'name' => $uname, 'email' => $uemail, 'contactmessage' => $request->message);
		
		//Mail::to($email)->send(new ContactEmail($data));
		Mail::to($super_admin_email)->send(new AdminDoctorToAdminMail($data));
				
		return response()->json(['status'=>true,'message' => 'Message sent successfully.'],$this->successStatus);
				
	} 
	
}
