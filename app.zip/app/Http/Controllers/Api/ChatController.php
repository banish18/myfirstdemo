<?php
namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\User;
use App\MobileNotification;
use App\UserDetail;
use App\Doctors;
use App\Chat;
use Illuminate\Support\Facades\Input;
use App\SmsApi;
use App\Mail\DoctorProfileAdminApprovalEmail;
use Illuminate\Support\Facades\Mail;
use App\Mail\VerifyMail;
use DB;
use FCM;
use LaravelFCM\Message\Topics;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;

use Google\Cloud\Firestore\FirestoreClient;

class ChatController extends Controller
{
	
	public $successStatus = 200;
	public $errorStatus   = 402;
	public function index($token) 
	{
		$optionBuilder = new OptionsBuilder();
		$optionBuilder->setTimeToLive(60*20);
		$notificationBuilder = new PayloadNotificationBuilder('Kabera Global');
		$notificationBuilder->setBody('You have received a new message Notification From Doctor')
							->setSound('default');
		$dataBuilder = new PayloadDataBuilder();
		$dataBuilder->addData(['a_data' => 'my_data']);
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);
		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();
		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();
		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();
		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();
		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
		
	}
	
	public function doctorNotification(Request $request) 
	{
	   	$data['message']   		= $request->input('message');
	   	$data['doctor_id'] 		= $request->input('doctor_id');
	    $data['to'] 			= $request->input('to');
	    $data['from'] 			= $request->input('from');
		$data['user_id']   		= $request->input('user_id');
		$data['assistants_id']  = $request->input('assistant_id');
		$data['device_token'] 	= $request->input('device_token');	
	    $id						= Chat::insertGetId($data); 
	    $Chat  					= Chat::find($id);
        $created_at 			= $Chat->created_at;
        $date		 			= date('Y-m-d',strtotime($created_at));
        $time		 			= date('h:i',strtotime($created_at));
        /* Notification for app */
	  //  $this->index($data['device_token']);
	  
	  
		$users 		= User::where('id', $request->input('doctor_id'))->first();
		if($users){
			$device_token = $users->device_token;
			if($device_token != ""){
				/* Notification for web */
				$this->push_notification_android1($device_token);
			}
		}
		
		$users 		= User::where('id', $request->input('assistant_id'))->first();
		if($users){
			$device_token = $users->device_token;
			if($device_token != ""){
				/* Notification for web */
				$this->AssistantChatNotification($device_token);
			}
		}
		

			$MobileNotification 	= new MobileNotification();
			
			$MobileNotification->user_id = $request->input('user_id');
			$MobileNotification->type = 'chat';
			$MobileNotification->notification_type = 'Chatting';
			$MobileNotification->save();
			
			$mobileDetail = array('user_id'=>$MobileNotification->user_id,'procedure_id'=>'','report_id'=>'','track_status'=>'','notification_status'=>'','type'=>$MobileNotification->type,'notification_type'=>$MobileNotification->notification_type);
			
			//print_r($MobileNotification); die;
			
			
		
		$users 		= User::where('id', $request->input('user_id'))->first();
		if($users){
			$device_token = $users->device_id;
			if($device_token != ""){
				/* Notification for web */
				$this->UserChatNotification($device_token , $mobileDetail);
			}
		}
		
		
		
	    if($date){
		  return response()->json(['status'=>true,'date'=> $date,'time'=> $time], $this->successStatus); 
		}else{
		 return response()->json(['error'=>'Response Not Found', 'status'=>false, 'message'=>'Response Not Found'], $this->errorStatus);
		}
	}
	
	public function UserChatNotification($token , $mobileDetail)
	{
		// Notification for web sended by doctor
		$optionBuilder = new OptionsBuilder();
		$optionBuilder->setTimeToLive(60*20);
		$notificationBuilder = new PayloadNotificationBuilder('Kabera Global');
		$notificationBuilder->setBody('You have received a new message Please Check')
						->setSound('default');
		$dataBuilder = new PayloadDataBuilder();
		$dataBuilder->addData(['a_data' => 'my_data' , 'mobileDetail'=>$mobileDetail]);
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);
		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();
		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();
		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();
		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();
		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
	}
	
	
	
	public function AssistantChatNotification($token)
	{
		// Notification for web sended by doctor
		$optionBuilder = new OptionsBuilder();
		$optionBuilder->setTimeToLive(60*20);
		$notificationBuilder = new PayloadNotificationBuilder('Kabera Global');
		$notificationBuilder->setBody('You have received a new message from your Assistant')
						->setSound('default');
		$dataBuilder = new PayloadDataBuilder();
		$dataBuilder->addData(['a_data' => 'my_data']);
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);
		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();
		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();
		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();
		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();
		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
	}
	
	public function push_notification_android1($token)
	{
		// Notification for web sended by doctor
		$optionBuilder = new OptionsBuilder();
		$optionBuilder->setTimeToLive(60*20);
		$notificationBuilder = new PayloadNotificationBuilder('Kabera Global');
		$notificationBuilder->setBody('You have received a new message from your Doctor')
						->setSound('default');
		$dataBuilder = new PayloadDataBuilder();
		$dataBuilder->addData(['a_data' => 'my_data']);
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);
		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();
		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();
		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();
		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();
		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
	}
	
	/*
	 * Get doctor chat list
	 * 
	 * */
	public function getchatUserlist(Request $request){
		$chats = Chat::where('doctor_id',$request->input('doctor_id'))->with('user')->groupBy('user_id')->orderBy('id','desc')->get(['user_id','message','status','assistants_id','created_at'])->toArray();
		$userArrayData = [];
		if($chats){			
			foreach($chats as $user){
				$usersArray['id'] 		= $user['user_id'];
				$usersArray['message'] 	= $user['message'];
				$usersArray['time'] 	= date('h:i',strtotime($user['created_at']));
				$usersArray['status'] 	= $user['status'];
				if($user['user']){
					$usersArray['name'] = $user['user']['name'];
				}else{
					$usersArray['name'] = "N/A";
				}
				if($user['assistants_id'] != ""){
					$User = User::find($user['assistants_id']);
					if($User){
						$usersArray['name'] = $User->name;
					}
				}
				$userArrayData[] = $usersArray;
			}
		}	
		if($userArrayData){
		  return response()->json(['status'=>true,'userlist'=> $userArrayData,'message' => 'Records'], $this->successStatus); 
		}else{
		 return response()->json(['status'=>false, 'userlist'=> [],'message' => 'No Records'], $this->errorStatus);
		}
	}
	
	/*
	 * 
	 * Get doctor user chat
	 */
	 public function getuserChat(Request $request){
		
		/* if($request->assistant_id != "0"){
			  $chats = Chat::where('assistants_id',$request->input('assistant_id'))->where('user_id',$request->input('user_id'))->orderBy('id','asc')->get(['user_id','from','to','message','status','created_at','assistants_id'])->toArray();
		 }else{
			   $chats = Chat::where('doctor_id',$request->input('doctor_id'))->where('user_id',$request->input('user_id'))->orderBy('id','asc')->get(['user_id','from','to','message','status','created_at','assistants_id'])->toArray();	
		 }*/
		$chats = Chat::where('doctor_id',$request->input('doctor_id'))->where('user_id',$request->input('user_id'))->orderBy('id','asc')->get(['user_id','from','to','message','status','created_at','assistants_id'])->toArray();
		$chatArrayData = [];
		if($chats){			
			foreach($chats as $user){
				$chatArray['id'] 		= $user['user_id'];
				$chatArray['from'] 		= $user['from'];
				$chatArray['to'] 		= $user['to'];
				$chatArray['message'] 	= $user['message'];
				$chatArray['time'] 		= date('h:i',strtotime($user['created_at']));
				$chatArray['status'] 	= $user['status'];
				$chatArrayData[] = $chatArray;
			}
		}
		if($chatArrayData){
			
		  return response()->json(['status'=>true,'chatlist'=> $chatArrayData], $this->successStatus); 
		}else{
					 return response()->json(['status'=>false,  'message'=> 'No Records' ,'chatlist'=> []], $this->errorStatus);

	//	 return response()->json(['success'=>false, 'chatlist'=> []], $this->errorStatus, 'message'=> 'No Records' );
		}
	 }
	 
	 public function NotificationForChat($token) 
	{
		$optionBuilder = new OptionsBuilder();
		
		$optionBuilder->setTimeToLive(60*20);
		
		$notificationBuilder = new PayloadNotificationBuilder('Kabera Global');
		$notificationBuilder->setBody('You have new message from doctor')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		
		//$message1 =  Response::json(array('success'=>false,'message'=>$message));	
		
		
		$dataBuilder->addData(['message' => 'You have new message from doctor']);
			
		
			
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();

		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();

		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();

		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();

		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
		
		
	}
	 
}
