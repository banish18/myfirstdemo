<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\ReferralData;
use App\ReferralPoint;
use Auth;
use Session;
use Validator;
use App\Mail\ReferralEmail;
use App\Mail\ReferralAdminEmail;
use App\Mail\DirectReferralEmail;
use App\Mail\DirectReferralUserEmail;
use App\SmsApi;
use App\User;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;
use File;

class ReferralController extends Controller
{
	public $successStatus = 200;
	public $errorStatus = 401;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       // $this->middleware(['auth','verified']);
       $this->langArr =  ['en','fr'];
    }
	/**
	 *Function Name: refferalcode
	 *Function Arguments: one argument
	 *Function Purpose: Send referral code to someone or Direct refer with 250 points
	 **/
	public function refferalcode(Request $request){
		
        $referby_id = $request->input('user_id');
        $user = User::select('name')->orWhere('id',$referby_id)->first();
        $referby_name = !empty($user->name)?$user->name:'';
        $referto_email = $request->input('email');
        $referto_phone = $request->input('phone');
        $refer_type = 'ref_with_code';
        $point_des = $request->input('point_des');
        $referraCode = $this->random_strings(6);
		$encrypt_ref = encrypt($referraCode);
        if($point_des=="reffered to someone"){
			$validator = Validator::make($request->all(), [ 
				'user_id'	   => 'required', 
				'email'    => 'required|email|unique:users', 
				'phone'	   => 'required|min:9|numeric', 
				'point_des'	   => 'required',             
			]);
			if ($validator->fails()) { 						
				foreach($validator->errors()->toArray() as $key=>$er) {
					$err[] = $er[0];
				}
				return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
			}
			
			if(!empty($request->input('photo')))
			{
			$allowedfileExtension=['jpg','png','jpeg','gif'];
			
			$fileTypeError = '';
			$check = in_array($request->input('photo_type'), $allowedfileExtension); 
			if($check){
				$fileTypeError = 1;
			}else{
				return response()->json(['status'=>false,'message'=>"Sorry only upload images having extensions .png, .jpg,.gif"], $this->errorStatus); 
			}
			if($fileTypeError==1){
				if (strpos($request->input('photo'), ",") !== false) {
					$images = explode(",",$request->input('photo'));				
				}else{
					$images[]  = $request->input('photo');
				}
				$imagesArr = [];
				$size = [];
				if(is_array($images) && !empty($images)){
					foreach($images as $image){
						$folder         = 'referred_images/';
						$random_number 	= mt_rand(100000, 999999);
						$f		   = finfo_open();
						$imgdata   = base64_decode($image);
						
						$mime_type = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
						$mime_type = explode('/',$mime_type);
						$imageName 		= $random_number.'.'.$mime_type[1]; 
						$image_size = 2000000;
						File::put(public_path().'/images/referred_images/' . $imageName, base64_decode($image));   
						$size[] = filesize(public_path().'/images/referred_images/'.$imageName); 
						$total_size = array_sum($size);
						if($total_size > $image_size){
							return response()->json(['status'=>false,'message'=>"Images size must be less than 2 mb"], $this->errorStatus); 							
						}
						$imagesArr[] = $folder.$imageName;
					}
				}
			
				$ReferralImage = implode(',',$imagesArr);
			}
		}
		else
		{
			$ReferralImage = "";
			$imagesArr = [];
		}
			
			$check_ref_exist = ReferralData::where("ref_from",$referby_id)->where("ref_to_email",$referto_email)->first();
			if($check_ref_exist == null){
				$referralData = new ReferralData;
				$referralData->user_id = $referby_id;
				$referralData->ref_from = $referby_id;
				$referralData->ref_code = $referraCode;
				$referralData->ref_to_email = $referto_email;
				$referralData->ref_to_phone = $referto_phone;
				$referralData->status = 0;
				$referralData->ref_type = $refer_type;
				$referralData->ref_photo_path = $ReferralImage;
				$referralData->points = 0;
				$referralData->point_des = $point_des;
				$referralData->expire_date = "";
				$referralData->save();
			}else{
				ReferralData::where("ref_from",$referby_id)->where("ref_to_email",$referto_email)->update(['ref_code' => $referraCode,'ref_to_phone' => $referto_phone,'ref_photo_path' => $ReferralImage]);
			}
			
			$super_admin_email = env('KABERA_ADMIN_EMAIL');
			$referral_url = URL::to('/register?refferal='.$encrypt_ref.'&reffer_email='.$referto_email);
			
			$message  = 'You will get a 250 point by register using the refferal link or using refferal code on Kabera';
			$message .= 'Referral url :'.$referral_url;
			$message .= 'Referral code :'.$referraCode;
			$SmsApi 	 = new SmsApi();
			$send_message = $SmsApi->sendSMS($referto_phone, $message);
			$data = array('referral_url' => $referral_url,'referral_code' => $referraCode,'user_image' => $imagesArr);
			$adminData = array('Ref_by' => $referby_name,'ref_email' => $referto_email,'ref_phone' => $referto_phone,'user_image' => $imagesArr);
			Mail::to($referto_email)->send(new ReferralEmail($data));
			Mail::to($super_admin_email)->send(new ReferralAdminEmail($adminData));
			if($send_message['success'] == 1){
				$sms_response = "Successfully Referred !! Mail/SMS has been sent to their referred email address or phone number";
			}else{
				$sms_response = "Successfully Referred !! Mail has been sent and your phone number have ".$send_message['message']."error";
			}
			return response()->json(['status'=>true,'message'=>$sms_response,'referral_code'=>$referraCode], $this->successStatus); 
		}else if($point_des=="direct referred to someone"){
			$validator = Validator::make($request->all(), [ 
				'user_id'		=> 'required', 
				'name'			=> 'required', 
				'email' 		=> 'required|email|unique:users',
				'phone'			=> 'required|min:9|numeric', 
				'photo'			=> 'required', 
				'service_type'	=> 'required'       
			]);
			if ($validator->fails()) { 						
				foreach($validator->errors()->toArray() as $key=>$er) {
					$err[] = $er[0];
				}
				return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
			}
			
			$random_number	= mt_rand(100000, 999999);
			$referto_name = $request->input('name');
			$referto_email = $request->input('email');
			$referto_phone = $request->input('phone');
			$refer_type = 'ref_without_code';
			$referto_service = $request->input('service_type');
			
			$allowedfileExtension=['jpg','png','jpeg','gif'];
			
			$fileTypeError = '';
			$check = in_array($request->input('photo_type'), $allowedfileExtension); 
			if($check){
				$fileTypeError = 1;
			}else{
				return response()->json(['status'=>false,'message'=>"Sorry only upload images having extensions .png, .jpg,.gif"], $this->errorStatus); 
			}
			if($fileTypeError==1){
				if (strpos($request->input('photo'), ",") !== false) {
					$images = explode(",",$request->input('photo'));				
				}else{
					$images[]  = $request->input('photo');
				}
				$imagesArr = [];
				$size = [];
				if(is_array($images) && !empty($images)){
					foreach($images as $image){
						$folder         = 'referred_images/';
						$random_number 	= mt_rand(100000, 999999);
						$f		   = finfo_open();
						$imgdata   = base64_decode($image);
						
						$mime_type = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
						$mime_type = explode('/',$mime_type);
						$imageName 		= $random_number.'.'.$mime_type[1]; 
						$image_size = 2000000;
						File::put(public_path().'/images/referred_images/' . $imageName, base64_decode($image));   
						$size[] = filesize(public_path().'/images/referred_images/'.$imageName); 
						$total_size = array_sum($size);
						if($total_size > $image_size){
							return response()->json(['status'=>false,'message'=>"Images size must be less than 2 mb"], $this->errorStatus); 							
						}
						$imagesArr[] = $folder.$imageName;
					}
				}
			
				$ReferralImage = implode(',',$imagesArr);
			
				$referral_point = 250;
				$super_admin_email = env('KABERA_ADMIN_EMAIL');
				$user_image_path = $imagesArr;
				
				$check_user_already_referred =  ReferralData::where("ref_to_email",$referto_email)->first();
				
				if($check_user_already_referred == null){
					$referralData = new ReferralData;
					$referralData->user_id = $referby_id;
					$referralData->ref_from = $referby_id;
					$referralData->ref_code = "";
					$referralData->ref_to_email = $referto_email;
					$referralData->ref_to_phone = $referto_phone;
					$referralData->status = 1;
					$referralData->ref_type = $refer_type;
					$referralData->service_type = $referto_service;
					$referralData->ref_photo_path = $ReferralImage;
					$referralData->points = $referral_point;
					$referralData->point_des = "direct referred to someone";
					$referralData->expire_date = "";
					$referralData->save();
					
					$check_point_data = ReferralPoint::where("user_id",$referby_id)->first();
					/* insert total points of direct referred by user */
							
					$reffrom_user_points = ReferralData::where("user_id", $referby_id)->sum('points');
					$reffrom_pending_points='';
					if(isset($check_point_data->used_points)){
						$reffrom_used_points = $check_point_data->used_points;
						$reffrom_pending_points = $reffrom_user_points - $reffrom_used_points;
						ReferralPoint::where("user_id",$referby_id)->update(['total_points' => $reffrom_pending_points]);
					}	
					
					
					
					$data = array('name' => $referto_name,'email' => $referto_email, 'phone' => $referto_phone, 'user_image' => $user_image_path, 'service_type' => $referto_service);
					
					$user_message =  "You have reffered by ".$referby_name.", Kabera team contact to you soon !!";
					$udata = array('user_message' => $user_message);
					
					$SmsApi 	 = new SmsApi();
					$SmsApi->sendSMS($referto_phone, $user_message);
					
					Mail::to($referto_email)->send(new DirectReferralUserEmail($udata));
					Mail::to($super_admin_email)->send(new DirectReferralEmail($data));
					
					return response()->json(['status'=>true,'message'=>'Successfully submitted!! Our team will contact to Referred user as soon as possible','referral_point'=>$referral_point], $this->successStatus); 
					
				}else{
					return response()->json(['status'=>false,'message'=>'Sorry user already referred!!'], $this->errorStatus); 			
				}
			}
		}		
	}
	
	//
    function random_strings($length_of_string) { 
		// md5 the timestamps and returns substring 
		// of specified length 
		return substr(md5(time()), 0, $length_of_string); 
	}
   
    
    /* User Referal Points API
     * @return  response
    */    
    public function userReferalPoints(Request $request) {
		
		 $validator = Validator::make($request->all(), [             
            'user_id'    => 'required', 
         ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['status'=>false, 'error'=>$err], $this->successStatus);            
        }   
		
		$user_id = $request->user_id; 
	    $get_total_points = ReferralPoint::where("user_id",$user_id)->first();
	    if($get_total_points)
	    {
			$total_points = $get_total_points->total_points;
			$used_points = $get_total_points->used_points;
			
			$referred_data = ReferralData::where("user_id",$user_id)->get();
			$finalData = array();
			foreach($referred_data as $key=>$data) {
				$res['points_for']  = $data->point_des;
				$res['points_from'] = $data->ref_to_email;
				$res['points']		= $data->points;
				$res['detail'] 	    = $data->service_type;
				$finalData[] 		=  $res;
			}
			
			return response()->json(['status'=>true,'data'=>$finalData,'total_points'=>$total_points,'used_points'=>$used_points,'message'=>'Refer Points Sent Successfully'], $this->successStatus);
		
		} else {
			return response()->json(['status'=>false,'data'=>[], 'message'=>'No Refer Points Available'], $this->successStatus);
		} 		
	    
	}   

}
