<?php
namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Cart;
use App\CartItem;
use App\Product;
use Auth;
use Illuminate\Support\Facades\Input;
use File;
use Config;
use DB;

class CartController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
    
	public $successStatus = 200;
	
	public function __Construct(REQUEST $request){
		$this->flag = 1;
		$this->languages = Config::get('app.languages');
		if(!in_array($request->lang,$this->languages)){
			$this->flag = 0;
		}
	}
	
	/**
     * Function to get user cart list.
     * @return cart
    */
	public function getCartlist(Request $request)
	{
		if($this->flag == 1){
			$cart = Cart::select('products.id as product_id','products.product_image','products.product_price','products.actual_price','products.product_name_'.$request->lang,'cart_items.id','cart_items.quantity','cart_items.id as cart_id')->leftJoin('cart_items', function($join){
				$join->on('cart_items.cart_id', '=', 'carts.id');
			})->leftJoin('products', function($join) {
				$join->on('cart_items.product_id', '=', 'products.id');
				})->where('carts.user_id',$request->user_id)->get()->toArray();		
			$cartTotal = Cart::where('user_id',$request->user_id)->first(['user_id','quantity_total','raw_total','discount_total','grand_total']);
			$cartT = [];
			if($cartTotal){
				$cartT['total'] 			= $cartTotal->grand_total;
				$cartT['discount_total'] 	= $cartTotal->discount_total;
				$cartT['grand_total'] 		= $cartTotal->grand_total-$cartTotal->discount_total;
			}
			$dataArray = array('cart_items' => $cart,'cart' => $cartT);
			if(!empty($cartTotal)){
				return response()->json(['status'=>true, 'data' => $dataArray], $this->successStatus); 	
			}else{
				return response()->json(['status'=>false, 'data' => 'No Data Available'], $this->successStatus);
			}	
		}
	}
	
	/**
     * Function to update user cart product.
     * @return products
    */
	public function addupdateCart(Request $request)
	{
		$data				= $request->all();
		$product_id 		= $data['product_id'];
        $cart_quantity 		= $data['quantity'];
        $user_id 			= $data['user_id'];
        $is_type 			= $data['is_type'];
    	$product 			= Product::find($product_id);
		/* check if Product are found or not */
        if(!$product && $is_type == 'cart') {
            return response()->json(['status'=>false, 'message' => 'Product Not Found'], $this->successStatus);
        }
        $cart = Cart::where('user_id',$user_id)->first();
        if(!$cart){
            $cart = new Cart;
            $cart->user_id 			= $user_id;
            $cart->quantity_total 	= $cart_quantity;
            $cart->save();
            /*** Add cart items entry ***/   
            $CartItem = new CartItem;
            $CartItem->cart_id 			= $cart->id;
            $CartItem->product_id 		= $product_id;
            $CartItem->product_price 	= $product->product_price;
            $CartItem->discount 		= 0;
            $CartItem->total_price 		= $product->product_price*$cart_quantity;
            $CartItem->quantity 		= $cart_quantity;
            $CartItem->is_type 			= $is_type;
            $CartItem->save();
          
            /* Update Cart values */
            $cart = Cart::where('user_id',$user_id)->first();
            $cart->raw_total 	  		= $CartItem->total_price;
            $cart->discount_total 		= $CartItem->discount;
            $cart->grand_total    		= $CartItem->total_price;
            $cart->save();
            return response()->json(['status'=>true, 'message' => "Cart Successfully updated",'cart_quantity' => $cart->quantity_total], $this->successStatus); 	
        }else{
            $CartItem 	= CartItem::where('product_id',$product_id)->where('cart_id',$cart->id)->first();
            if(!$CartItem){
				if($product->stock < $cart_quantity && $is_type == 'cart'){
					return Response::json(array('success'=>false,'message'=>'No more products in stock'));
				}else{
					$CartItem = new CartItem;
					$CartItem->cart_id 			= $cart->id;
					$CartItem->product_id 		= $product_id;
					$CartItem->product_price 	= $product->product_price;
					$CartItem->discount 		= 0;
					$CartItem->total_price 		= $product->product_price*$cart_quantity;
					$CartItem->quantity 		= $cart_quantity;
					$CartItem->is_type 			= $is_type;
					$CartItem->save();
					/* Get the total sum of cart */
					$cartSome                   = CartItem::where('cart_id',$cart->id)->sum('total_price');
					$cartQtySum                 = CartItem::where('cart_id',$cart->id)->sum('quantity');
					$cartDicSum                 = CartItem::where('cart_id',$cart->id)->sum('discount');
					$cart->quantity_total 	  	= $cartQtySum;
					$cart->raw_total 	  		= $cartSome;
					$cart->discount_total 		= $cartDicSum;
					$cart->grand_total    		= $cartSome-$cartDicSum;
					$cart->save();
					return response()->json(['status'=>true, 'message' => "Cart Successfully updated",'cart_quantity' => $cart->quantity_total], $this->successStatus); 	
				}
			}else{
				if($product->stock < $CartItem->quantity+$cart_quantity && $is_type == 'cart'){
					return response()->json(['status'=>false, 'message' => "No more products in stock",'cart_quantity' => $cart->quantity_total], $this->successStatus); 	
				}else{
					$CartItem->quantity 		= $cart_quantity;
					$CartItem->total_price 		= $product->product_price*$cart_quantity;
					$CartItem->save();
					/* Get the total sum of cart */
					$cartSome                   = CartItem::where('cart_id',$cart->id)->sum('total_price');
					$cartQtySum                 = CartItem::where('cart_id',$cart->id)->sum('quantity');
					$cartDicSum                 = CartItem::where('cart_id',$cart->id)->sum('discount');
					$cart->quantity_total 	  	= $cartQtySum;
					$cart->raw_total 	  		= $cartSome;
					$cart->discount_total 		= $cartDicSum;
					$cart->grand_total    		= $cartSome-$cartDicSum;
					$cart->save();
					return response()->json(['status'=>true, 'message' => "Cart Successfully updated",'cart_quantity' => $cart->quantity_total], $this->successStatus); 	
				}
			}
        }
	}
	
	/**
     * Function to delete user cart product.
     * @return products
    */
	public function deleteCart(Request $request)
	{
		$cart 		= Cart::where('user_id',$request->user_id)->first();	
		$cartItem 	= CartItem::where('cart_id',$cart->id)->where('product_id',$request->product_id)->delete();
		$cartItem   = CartItem::where('cart_id',$cart->id)->first();
		if(!$cartItem){
			Cart::where('user_id',$request->user_id)->delete();	
		}
		if($cart){
			return response()->json(['status'=>true, 'message' => "Cart Product Successfully Deleted"], $this->successStatus); 	
		}else{
			return response()->json(['status'=>false, 'message' => 'Something went wrong'], $this->successStatus);
		}
	}
}
