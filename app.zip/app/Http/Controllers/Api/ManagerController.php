<?php
namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\AppointmentList;
use App\AppointmentRequest;
use App\CartItem;
use App\TeamStatusReports;
use App\ProcedureReview;
use App\Procedure;
use App\DoctorTimeslot;
use App\Doctors;
use App\NoteCommentData;
use App\OperationList;
use App\Product;
use App\Service;
use App\SubService;
use App\HairTransplantReport;
use App\User;
use App\ReferralData;
use App\ReferralPoint;
use App\DoctorAssistant;
use App\ReferralPointsData;
use Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;
use File;
use Config;
use DB;
use Image;
use Validator;
use App\SmsApi;
use App\AssistantProcedureRecords;
use App\Mail\SendOtpMail;
use DateTime;
use DateInterval;
use LaravelFCM\Message\Topics;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;
use FCM;
use App\Mail\AppointmentCancelMail;
use App\Mail\AppointmentRescheduleMail;

class ManagerController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
    
	public $successStatus = 200;
	public $errorStatus = 401;
	
	public function __Construct(REQUEST $request){
		$this->flag = 1;
		$this->languages = Config::get('app.languages');
		if(!in_array($request->lang,$this->languages)){
			$this->flag = 0;
		}
	}
	
	/*
	 * Add Manager Comment
	 * @return Comment
	 * */
	 
	public function addmanagerCommnt(Request $request){
		$validator = Validator::make($request->all(), [ 
			'from'	  		=> 'required', 
			'to'	  		=> 'required', 
			'comment'		=> 'required', 			
		]);
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
        }
        
        $addcomment = new TeamStatusReports;
		$addcomment->comment_from = $request->input('from');
		$addcomment->comment_to = $request->input('to');
		$addcomment->comment_des = $request->input('comment');
        
        if(!empty($request->input('image'))){
			$image   = $request->input('image');
			$folder         = 'manager/comment_images/';
			$random_number 	= mt_rand(100000, 999999);
			$f = finfo_open();
			$imgdata   = base64_decode($image);
			$mime_type = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
			$mime_type = explode('/',$mime_type);
			$imageName = $random_number.'.'.$mime_type[1];  
			if($mime_type[1]!="octet-stream"){
				File::put(public_path().'/images/manager/comment_images/' . $imageName, base64_decode($image));   
				$imagepAth = $folder.$imageName;
				$addcomment->image = $imagepAth;
			}
		}
        $addcomment->save();
		
		$id = $addcomment->id;
		$date = date("Y-m-d h:i:s");
		$comment = $addcomment->comment_des;
		$author_name = User::where('id',$request->input('from'))->first();
		$name = $author_name->name;
		$image =  $addcomment->image;
		$data = array('id' => $id,'comment' => $comment,'date' => $date,'author_name' => $name,'image' => $image);
		return response()->json(['status'=>true,'message'=>"Comment added successfully",'data' => $data], 200); 
		//
		//return response()->json(['status'=>false,'message'=>"No appointment is available"], $this->errorStatus); 
	}
	
	public function manageCommntoteam(Request $request){
			$validator = Validator::make($request->all(), [ 
				'from'	  		=> 'required', 
				'to'	  		=> 'required', 
			 ]);
			
			if ($validator->fails()) { 						
				foreach($validator->errors()->toArray() as $key=>$er) {
					$err[] = $er[0];
				}
				return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
			}
			$comment_array = [];
			
			$getDetails = TeamStatusReports::with('user_detail')->whereIn('comment_from',[$request->input('from'),$request->input('to')])->whereIn('comment_to',[$request->input('from'),$request->input('to')])->orderby('id','desc')->get();
			
			//echo "<pre>";
			//print_r($getDetails);
			//echo "</pre>";
			
			if(!empty($getDetails))
			{
				foreach($getDetails as $key => $val)
				{
					$comment_array[$key]['id'] 			= $val->id;
					$comment_array[$key]['name'] 	= $val['user_detail']->name;
					$comment_array[$key]['date'] 	= date_format($val->updated_at, 'Y-m-d H:i:s');
					$comment_array[$key]['message'] = $val->comment_des;
					$comment_array[$key]['image'] = $val->image;
				}
				return response()->json(['status'=>true, 'message'=>'success', 'data' => $comment_array], 200);
			}
			else
			{
				return response()->json(['status'=>false, 'message'=>'error', 'data' => $getDetails], 200);
			}
	}
		
}
