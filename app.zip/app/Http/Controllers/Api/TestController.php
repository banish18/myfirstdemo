<?php
namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\User;
use App\UserDetail;
use App\Doctors;
use App\AppointmentList;
use Illuminate\Support\Facades\Input;
use App\SmsApi;
use App\Mail\DoctorProfileAdminApprovalEmail;
use Illuminate\Support\Facades\Mail;
use App\Mail\VerifyMail;
use App\Mail\AppointmentNotifyMail;
use DB;
use FCM;
use LaravelFCM\Message\Topics;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;


class TestController extends Controller
{
	
	public $successStatus = 200;
	public $errorStatus   = 404;
	
	public function testNotification(){
$token = 'cz7rgbYupQYH9CuSahibIX:APA91bHkDdtvAlaKszGiy405Nq4_Krf4Epezmp_wL2nLU4YDGMF_gN9zopBTEact_CWA3KQZfrLsXVUF1DVqFOGJf0tSFI1B0MbgfJv3nMCUUj2R8CXAmhi4jABv4W5JfDHzFLxu2giE';
		$this->web_notification($token);
		die;
	}
	public function web_notification($token){
		//API URL of FCM
		$optionBuilder = new OptionsBuilder();
		
		$optionBuilder->setTimeToLive(60*20);
		
		$notificationBuilder = new PayloadNotificationBuilder('Kabera Glocal');
		$notificationBuilder->setBody('Tesrt New Notification appointment is succesfully added.')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		
		//$message1 =  Response::json(array('success'=>false,'message'=>$message));	
		
		
		$dataBuilder->addData(['message' => 'af New asdfa Notification appointment is succesfully added.']);
			
		
			
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();
		
		echo "<pre>";print_r($downstreamResponse);

		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();

		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();

		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();

		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
	}
	
	
}
