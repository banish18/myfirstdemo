<?php
namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\User;
use App\PaymentType;
use App\Procedure;
use App\Role;
use App\RoleUser;
use App\Doctors;
use App\Agent;
use App\ManagerDetail;
use App\DoctorAssistant;
use App\ForgotOtp;
use App\AssistantProcedureRecords;
use Auth;
use Validator;
use DateTime;
use DateInterval;
use App\SubService;
use App\Service;
use Illuminate\Support\Facades\Input;
use File;
use DB;
class ListingController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
    
    /***
	 * View Assistatnt List API
	*/
	public $successStatus = 200;
	
	public function AddedByList(Request $request) {
		
		$validator = Validator::make($request->all(), [ 
            'added_by_user'	      => 'required', 
            'role'	     		  => 'required', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
        
        $added_by = $request->input('added_by_user');
        $role 	  = $request->input('role');
        $from 	  = $request->input('from');
        $to 	  = $request->input('to');
        switch ($role) {
			case 2: //doctors
				 if(!empty($from) && !empty($to))
				 {
					$Doctors = User::with(['doctor'])->withCount('OperationList')->where('added_by', $added_by)->where('role', $role)->whereBetween('created_at', [$from, $to])->get(['id','name', 'email', 'phone', 'created_at'])->toArray();
					$count = count($Doctors);
				 }
				 else
				 {
					$Doctors = User::with(['doctor'])->withCount('OperationList')->where('added_by', $added_by)->where('role', $role)->get(['id','name', 'email', 'phone', 'created_at'])->toArray();
					$count = count($Doctors);
				 }
				 if($Doctors){
				 	return response()->json(['status'=>true, 'count' => $count,'Doctors' => $Doctors], $this->successStatus); 
				 } else {
				 	return response()->json(['status'=>false, 'count' => $count,'Doctors' => $Doctors], $this->successStatus); 			
				 }				
				break;
				
			case 4: //marketing manager
				 if(!empty($from) && !empty($to))
				 {
					$Marketing = User::with(['manager'])->where('added_by', $added_by)->where('role', $role)->whereBetween('created_at', [$from, $to])->get(['id','name', 'email', 'phone', 'created_at'])->toArray(); 
					$count = count($Marketing);
				 }
				 else
				 {
					$Marketing = User::with(['manager'])->where('added_by', $added_by)->where('role', $role)->get(['id','name', 'email', 'phone', 'created_at'])->toArray();
					$count = count($Marketing);
				 }
				 if($Marketing){
				 	return response()->json(['status'=>true,'count' => $count, 'marketing' => $Marketing], $this->successStatus); 
				 } else {
				 	return response()->json(['status'=>false,'count' => $count, 'marketing' => $Marketing], $this->successStatus); 			
				 }				
				break;
				
			case 5: //agent	
				if(!empty($from) && !empty($to))
				 {
					$Agent = User::with(['agent'])->where('added_by', $added_by)->where('role', $role)->whereBetween('created_at', [$from, $to])->get(['id','name', 'email', 'phone', 'created_at'])->toArray(); 
					$count = count($Agent);
				 }
				 else
				 {			
					$Agent = User::with(['agent'])->where('added_by', $added_by)->where('role', $role)->get(['id','name', 'email', 'phone', 'created_at'])->toArray();
					$count = count($Agent);
			     }
				 if($Agent){
				 	return response()->json(['status'=>true,'count' => $count, 'agents' => $Agent], $this->successStatus); 
				 } else {
				 	return response()->json(['status'=>false,'count' => $count, 'agents' => $Agent], $this->successStatus); 			
				 }				
				break;
				
			case 6: //assistant
				if(!empty($from) && !empty($to))
				 {
					$assistant = User::with(['assistant'])->where('added_by', $added_by)->where('role', $role)->whereBetween('created_at', [$from, $to])->get(['id','name', 'email', 'phone', 'created_at'])->toArray();
					$count = count($assistant);
				 }
				 else
				 {	
					$assistant = User::with(['assistant'])->where('added_by', $added_by)->where('role', $role)->get(['id','name', 'email', 'phone', 'created_at'])->toArray();
					$count = count($assistant);
				 }
				 if($assistant){
				 	return response()->json(['status'=>true,'count' => $count, 'assistants' => $assistant], $this->successStatus); 
				 } else {
				 	return response()->json(['status'=>false,'count' => $count, 'assistants' => $assistant], $this->successStatus); 			
				 }
				 
				break;
				
			default:
				return response()->json(['status'=>false, 'assistants' => 'Invalid Role'], 401); 
        }
       
	}
	
	
	public function orderPaymentDetail(Request $request) {
		
		$validator = Validator::make($request->all(), [ 
            'user_id'	      => 'required', 
            'procedure_id'	  => 'required', 
            'doctor_id'	  => 'required', 
        ]);
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], 401);            
        }
		$user_id = $request->input('user_id');
		$procedure_id 	  = $request->input('procedure_id');
		$PaymentType 	  = PaymentType::where('user_id',$user_id)->where('procedure_id',$procedure_id)->with('user')->with('user')->get();
		$counter = 1;
		$paymetArr = [];
		$paymetFinalArr = [];
		$allPayment = '0';
		foreach($PaymentType as $_payment)
		{
			$paymetArr['payment_type'] = $_payment->payment_type;
			$paymetArr['created_at'] = date('Y-m-d H:i:s',strtotime($_payment->created_at));
			$paymetArr['amount'] 	   = $_payment->amount;
			if($_payment->doctor_id){
				$paymetArr['name']  = $_payment->user['name'];
			}else{
				$paymetArr['name']  =  "Doctor";
			}
			
			/** 10 Dec */
			$AssistantProcedureRecords = AssistantProcedureRecords::where('action_id',$_payment->id)->where('action','accept_payment')->where('assistant_id','!=','0')->with('user')->first();
			if($AssistantProcedureRecords){
				$paymetArr['name'] = $AssistantProcedureRecords->user->name;
			}
			$allPayment += $_payment->amount;
			$paymetArr['Sr']  	   = $counter;	
			$counter++;
			$paymetFinalArr[] = $paymetArr;
		}
		$procedure = Procedure::find($procedure_id);
		$total_payment 	 = $procedure->total_payment;
		$advance_payment = $procedure->advanced_payment;
		$pending_payment = $procedure->pending_payment;
		if(!empty($paymetFinalArr)){
			return response()->json(['status'=>true,'total_payment' => $total_payment,'advance_payment' => $advance_payment,'pending_payment' => $pending_payment, 'PaymentType' => $paymetFinalArr ], $this->successStatus); 
		 } else {
			return response()->json(['status'=>true,'total_payment' => $total_payment,'advance_payment' => $advance_payment,'pending_payment' => $pending_payment, 'PaymentType' => $paymetFinalArr], $this->successStatus); 			
		 }	
	}
}
