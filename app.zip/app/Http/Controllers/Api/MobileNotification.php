<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MobileNotification extends Model
{
   protected $table = 'mobile_notifications';
 
}
