<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;

use App\User;
use App\Setting;
use App\UserDetail;
use App\Role;
use App\RoleUser;
use App\Doctors;
use App\Agent;
use App\ManagerDetail;
use App\DoctorAssistant;
use App\ForgotOtp;
use App\ReferralPoint;
use App\ReferralPointsData;
use App\ReferralData;
use App\SmsApi;
use App\Mail\SendOtpMail;
use App\SubService;
use App\Service;
use App\Mail\VerifyMail;
use App\Mail\DoctorProfileAdminApprovalEmail;

use Auth;
use Validator;
use DateTime;
use DateInterval;
use File;
use Image;
use DB;
use FCM;
use Session;

use LaravelFCM\Message\Topics;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;
use Firebase\Token\TokenException;
use Firebase\Token\TokenGenerator;


class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
    */
    public $successStatus = 200;
    public $errorStatus   = 401;

    /***
     * API For Login User 
     * @arguments
     * user_name, password, device_token, lat, lng, role
     ***/
 
     public function login(Request $request){
		$device_id = $request->input('device_id');
		if(empty($request->input('otp'))){
			if((!empty($request->get('username'))) && ((is_numeric($request->get('username'))))) {
				$user = User::select('role')->where('phone', $request->get('username'))->first();
				if($user == null) {
					return response()->json(['status'=>false,'message'=>'Your phone number not match in our system..!!'], $this->errorStatus);   
				} else {
					$userRole = !empty($user->role)?$user->role:'';
					switch($userRole){
						case 2: 
								$user = User::where('role', $userRole)->where('phone', $request->get('username'))->where('isVerified',1)->first();
								if($user == null) {
									return response()->json(['status'=>true,'isVerified'=>0,'message'=>"Your registration request is sent to Admin for Approval. Be patient! You'll be notified once done."], $this->successStatus);   
								} else {
									$OTP     =  mt_rand(100000, 999999);
									
									$time 	 = new DateTime(date('Y-m-d H:i:s'));
									$time->add(new DateInterval('PT5M'));
									$expTime = $time->format('Y-m-d H:i:s');													
									$message	 = $message	 = "<#>Dear, Welcome to Kabera Global. Please use this otp to login with us (".$OTP .") ".env('APP_MSG_CODE');
									$SmsApi 	 =  new SmsApi();
									$SmsApi->sendSMS($user->phone, $message);
									return response()->json(['status'=>true,'expired_at'=>$expTime,'isVerified'=>1,'message'=>'You will receive OTP on phone to login your account','otp'=>(string)$OTP]); 
								}
								break;
						case 4:
								$user = User::where('role', $userRole)->where('phone', $request->get('username'))->first();
								$manager = ManagerDetail::where('user_id', $user->id)->first();
							    if($manager->status == 0) { // for int data type
									return response()->json(['status'=>false,'message'=>'Sorry! Your account is suspended.'], $this->errorStatus);   
								}								
								$OTP     =  mt_rand(100000, 999999);								
								$time 	 = new DateTime(date('Y-m-d H:i:s'));
								$time->add(new DateInterval('PT5M'));
								$expTime = $time->format('Y-m-d H:i:s');
								
								$message	 = $message	 = "<#>Dear, Welcome to Kabera Global. Please use this otp to login with us (".$OTP .") ".env('APP_MSG_CODE');
								$SmsApi 	 =  new SmsApi();
								$SmsApi->sendSMS($user->phone, $message);
								return response()->json(['status'=>true,'expired_at'=>$expTime,'isVerified'=>1,'message'=>'You will receive OTP on phone to login your account','otp'=>(string)$OTP]);
								break;
						case 5:
								$user = User::where('role', $userRole)->where('phone', $request->get('username'))->first();
								$OTP     =  mt_rand(100000, 999999);
								
								$time 	 = new DateTime(date('Y-m-d H:i:s'));
								$time->add(new DateInterval('PT5M'));
								$expTime = $time->format('Y-m-d H:i:s');
								
								$message	 = "<#>Dear, Welcome to Kabera Global. Please use this otp to login with us (".$OTP .") ".env('APP_MSG_CODE');
								$SmsApi 	 =  new SmsApi();
								$SmsApi->sendSMS($user->phone, $message);
								return response()->json(['status'=>true,'expired_at'=>$expTime,'isVerified'=>1,'message'=>'You will receive OTP on phone to login your account','otp'=>(string)$OTP]);
								break;
						case 6:
								$user = User::where('role', $userRole)->where('phone', $request->get('username'))->first();
								$assistant = DoctorAssistant::where('user_id', $user->id)->first();
							    if($assistant->status == '0') { // for enum data type
									return response()->json(['status'=>false,'message'=>'Sorry! Your account is suspended.'], $this->errorStatus);   
								}
								
								
								$OTP     =  mt_rand(100000, 999999);								
								$time 	 = new DateTime(date('Y-m-d H:i:s'));
								$time->add(new DateInterval('PT5M'));
								$expTime = $time->format('Y-m-d H:i:s');
								
								$message	 = "<#>Dear, Welcome to Kabera Global. Please use this otp to login with us (".$OTP .") ".env('APP_MSG_CODE');
								$SmsApi 	 =  new SmsApi();
								$SmsApi->sendSMS($user->phone, $message);
								return response()->json(['status'=>true,'expired_at'=>$expTime,'isVerified'=>1,'message'=>'You will receive OTP on phone to login your account','otp'=>(string)$OTP]);
								break;
					}					 	
				}									
			} else if((!empty($request->get('username'))) && ((!is_numeric($request->get('username'))))) {
				$user = User::select('role')->where('email', $request->get('username'))->first();
				if($user == null) {
					return response()->json(['status'=>false,'message'=>'Your E-mail not match in our system..!!'], $this->errorStatus);  				
				} else {
					$userRole = !empty($user->role)?$user->role:'';
					switch($userRole){
						case 2: 
								$user = User::where('role', $userRole)->where('email', $request->get('username'))->where('isVerified',1)->first();
								if($user == null) {
									return response()->json(['status'=>true,'isVerified'=>0,'message'=>"Your registration request is sent to Admin for Approval. Be patient! You'll be notified once done."], $this->successStatus);  				
								} else {
									
									$OTP     =  mt_rand(100000, 999999);
									
									$time 	 = new DateTime(date('Y-m-d H:i:s'));
									$time->add(new DateInterval('PT5M'));
									$expTime = $time->format('Y-m-d H:i:s');	
									
									$mdata['email']     = $user->email;
									$mdata['name']      = $user->name;
									$mdata['otp']  		= $OTP;	
									Mail::to($user->email)->send(new SendOtpMail($mdata));
											
									return response()->json(['status'=>true,'expired_at'=>$expTime,'isVerified'=>1,'message'=>'You will receive OTP on email to login your account','otp'=>(string)$OTP]);  
								}
								break;
						case 4:
								$user = User::where('role', $userRole)->where('email', $request->get('username'))->first();
								$OTP     =  mt_rand(100000, 999999);
								
								$time 	 = new DateTime(date('Y-m-d H:i:s'));
								$time->add(new DateInterval('PT5M'));
								$expTime = $time->format('Y-m-d H:i:s');
								
								$mdata['email']     = $user->email;
								$mdata['name']      = $user->name;
								$mdata['otp']  		= $OTP;	
								Mail::to($user->email)->send(new SendOtpMail($mdata));
								return response()->json(['status'=>true,'expired_at'=>$expTime,'isVerified'=>1,'message'=>'You will receive OTP on email to login your account','otp'=>(string)$OTP]);  
								break;
						case 5:
								$user = User::where('role', $userRole)->where('email', $request->get('username'))->first();
								$OTP     =  mt_rand(100000, 999999);
								
								$time 	 = new DateTime(date('Y-m-d H:i:s'));
								$time->add(new DateInterval('PT5M'));
								$expTime = $time->format('Y-m-d H:i:s');
								
								$mdata['email']     = $user->email;
								$mdata['name']      = $user->name;
								$mdata['otp']  		= $OTP;	
								Mail::to($user->email)->send(new SendOtpMail($mdata));
								return response()->json(['status'=>true,'expired_at'=>$expTime,'isVerified'=>1,'message'=>'You will receive OTP on email to login your account','otp'=>(string)$OTP]);  
								break;
						case 6:
								$user = User::where('role', $userRole)->where('email', $request->get('username'))->first();
								$OTP     =  mt_rand(100000, 999999);
								
								$time 	 = new DateTime(date('Y-m-d H:i:s'));
								$time->add(new DateInterval('PT5M'));
								$expTime = $time->format('Y-m-d H:i:s');
								
								$mdata['email']     = $user->email;
								$mdata['name']      = $user->name;
								$mdata['otp']  		= $OTP;	
								Mail::to($user->email)->send(new SendOtpMail($mdata));
								return response()->json(['status'=>true,'expired_at'=>$expTime,'isVerified'=>1,'message'=>'You will receive OTP on email to login your account','otp'=>(string)$OTP]);  
								break;
					}									
				}
			} else {
				return response()->json(['status'=>false,'message'=>'Credential wrong ..!!'], $this->errorStatus);
			}
		}else{  
			$validator = Validator::make($request->all(), [ 
				'device_token'	    	=> 'required', 				        
			]);
			
			if ($validator->fails()) { 						
				foreach($validator->errors()->toArray() as $key=>$er) {
					$err[] = $er[0];
				}
				return response()->json(['error'=>$err], 401);            
			}
			$user = User::where('phone', $request->get('username'))->orWhere('email',$request->get('username'))->first();
			
			$userId = !empty($user->id)?$user->id:'';
			if($userId==''){
				return response()->json(['error'=>'Unauthorised', 'status'=>false, 'message'=>'Login credential is not correct'], $this->errorStatus); 
			}else{
				$user = User::with('role_detail')->find($userId);
				$user->device_token = $request->input('device_token');
				$user->customer_number = mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999);
				$user->lat          = $request->input('lat');
				$user->lng          = $request->input('lng');
				$user->device_id    = $request->input('device_id');
				$user->save();
				$role = $user->role;
				switch ($role) {
					case 2: //doctor
						$data = Doctors::with(['gallery'])->where('user_id', $user->id)->first();					
						break;
					case 3: //user
						$data = array();
						break;
					case 4: //manager
						$data = ManagerDetail::where('user_id', $user->id)->first();
						break;
					case 5: //agent
						$data = Agent::where('user_id', $user->id)->first();
						break;
					case 6: //assistant
						$data = DoctorAssistant::where('user_id', $user->id)->first();
						break;
					default:
					$data = array();	
				}
				
				if($role == '2') {			
					$skills		 = json_decode($data->skills);
					$sub_skills	 = json_decode($data->sub_skills);
					$allServ     = array();
					
					$services = Service::with(['subService'])->get()->toArray();
					$skillName = "";
					$subskillName = "";
					if(!empty($skills) && is_array($skills)){
						foreach($skills as $skill){
							if(!empty($sub_skills) && is_array($skills)){
								$sub_skillsd = [];
								foreach($sub_skills as $sub_skill){
									$parentServ  = !empty($this->getsubSkilldetail($sub_skill)->service_id)?$this->getsubSkilldetail($sub_skill)->service_id:'';
									$skillName   = ($this->getSkilldetail($skill) ? $this->getSkilldetail($skill)->service_name : "");
									$subskillName   = ($this->getsubSkilldetail($sub_skill) ? $this->getsubSkilldetail($sub_skill)->sub_name : "");
									
									
									if($skill == $parentServ){
										$sub_skillsd[] = array('id' => $sub_skill,'name' => $subskillName);
									}
								}
							}else{
								$sub_skillsd = [];
							}
							$allServ[] = array('id' => $skill,'name' => $skillName,'sub_service' => $sub_skillsd);
						}
					}
					
					$skillIdArr = [];
					$subskillIdArr = [];
					foreach($allServ as $key => $servic){
						$skillIdArr[] = $servic['id'];
						foreach($servic['sub_service'] as $key2 => $subser){
							$subskillIdArr[] = $subser['id'];
						}
					}
					foreach($services as $key => $servic){
						if(in_array($servic['id'],$skillIdArr)){
							$servic['ischeck'] = '1';
						}else{
							$servic['ischeck'] = '0';
						}
						if(isset($servic['sub_service']) && !empty($servic['sub_service'])){
							foreach($servic['sub_service'] as $key2 => $subser){
								if(in_array($subser['id'],$subskillIdArr)){
										$subser['ischeck'] = '1';
								}else{
									$subser['ischeck'] = '0';	
								}
								$servic['sub_service'][$key2] = $subser;
							}
						}
						$services[$key] = $servic;
					}			
					
					$data['skills']  = $services;
					//$data->skills  = $services;	
					$success['id']   	=  $user->id; 
					$success['token']   =  $user->api_token; 
					$success['name']    =  $user->name; 
					$success['email']   =  $user->email; 
					$success['phone']   =  $user->phone; 
					$success['role']    =  $user->role; 
					$success[$user->role_detail->name]   =  ($data != null) ? $data : [] ;
					$clinic= $profile= true;
					if($success[$user->role_detail->name]['clinic_address'] == ""){
						$success[$user->role_detail->name]['clinic_address'] = "No address Found";
					}
					if(!empty($data)){
						if((empty($data['clinic_name']))||(empty($data['clinic_address']))){
							$clinic = false;
						}
						
						if((empty($data['skills']))||(empty($data['sub_skills']))||(empty($data['description']))||(empty($data['education']))||(empty($data['experience']))||(empty($data['awards']))||(empty($data['speciality']))){
							$profile = false;
						}
					}
					return response()->json(['success' => $success, 'status'=>true, 'message'=>'You are successfully logged-in','clinic'=>$clinic,'profile'=>$profile], $this->successStatus);			
				}else{
					$success['id']   	=  $user->id; 
					$success['token']   =  $user->api_token; 
					$success['name']    =  $user->name; 
					$success['email']   =  $user->email; 
					$success['phone']   =  $user->phone; 
					$success['role']    =  $user->role; 
					$success[$user->role_detail->name]   =  ($data != null) ? $data : [];
					$clinic = "Not Found";
					if(!empty($data)){
						$doctorDetail = Doctors::find($data->doctor_id);
						if($doctorDetail){
							$clinic = $doctorDetail->clinic_name;
							$DoctorAssistant = DoctorAssistant::where('user_id',$data['user_id'])->first();
							if($DoctorAssistant){
								$data['address'] 	 = $DoctorAssistant->address;
								$data['description'] = $DoctorAssistant->description;
							}else{
								$data['address'] 	 = "";
								$data['description'] = "";
							}
							
						}
						//$data['doctor_id'] = $doctorDetail->doctor_id;
					}
					return response()->json(['success' => $success, 'status'=>true, 'message'=>'You are successfully logged In','clinic'=>$clinic], $this->successStatus); 
				}				
			}
			die("Troubleshooting is going please wait....");
			if(Auth::attempt(['email' => $request->get('username'), 'password' => $request->input('password')])){
				$user = User::with('role_detail')->find(Auth::user()->id);
				$user->device_token = $request->input('device_token');
				$user->customer_number = mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999);
				$user->lat          = $request->input('lat');
				$user->lng          = $request->input('lng');
				$user->save();
				$role = $user->role;
				switch ($role) {
					case 2: //doctor
						$data = Doctors::with(['gallery'])->where('user_id', $user->id)->first();					
						break;
					case 3: //user
						$data = array();
						break;
					case 4: //manager
						$data = ManagerDetail::where('user_id', $user->id)->first();
						break;
					case 5: //agent
						$data = Agent::where('user_id', $user->id)->first();
						break;
					case 6: //assistant
						$data = DoctorAssistant::where('user_id', $user->id)->first();
						break;
					default:
					$data = array();	
				}
				
				if($role == '2') {				
					$skills		 = json_decode($data->skills);
					$sub_skills	 = json_decode($data->sub_skills);
					$allServ     = array();
					
					$services = Service::with(['subService'])->get()->toArray();
					$skillName = "";
					$subskillName = "";
					if(!empty($skills) && is_array($skills)){
						foreach($skills as $skill){
							if(!empty($sub_skills) && is_array($skills)){
								$sub_skillsd = [];
								foreach($sub_skills as $sub_skill){
									$parentServ  = $this->getsubSkilldetail($sub_skill)->service_id;
									$skillName   = ($this->getSkilldetail($skill) ? $this->getSkilldetail($skill)->service_name : "");
									$subskillName   = ($this->getsubSkilldetail($sub_skill) ? $this->getsubSkilldetail($sub_skill)->sub_name : "");
									
									
									if($skill == $parentServ){
										$sub_skillsd[] = array('id' => $sub_skill,'name' => $subskillName);
									}
								}
							}else{
								$sub_skillsd = [];
							}
							$allServ[] = array('id' => $skill,'name' => $skillName,'sub_service' => $sub_skillsd);
						}
					}
					
					$skillIdArr = [];
					$subskillIdArr = [];
					foreach($allServ as $key => $servic){
						$skillIdArr[] = $servic['id'];
						foreach($servic['sub_service'] as $key2 => $subser){
							$subskillIdArr[] = $subser['id'];
						}
					}
					foreach($services as $key => $servic){
						if(in_array($servic['id'],$skillIdArr)){
							$servic['ischeck'] = '1';
						}else{
							$servic['ischeck'] = '0';
						}
						if(isset($servic['sub_service']) && !empty($servic['sub_service'])){
							foreach($servic['sub_service'] as $key2 => $subser){
								if(in_array($subser['id'],$subskillIdArr)){
										$subser['ischeck'] = '1';
								}else{
									$subser['ischeck'] = '0';	
								}
								$servic['sub_service'][$key2] = $subser;
							}
						}
						$services[$key] = $servic;
					}			
					$data->skills  = $services;				
				}
				
				$success['id']   	=  $user->id; 
				$success['token']   =  $user->api_token; 
				$success['name']    =  $user->name; 
				$success['email']   =  $user->email; 
				$success['phone']   =  $user->phone; 
				$success['role']    =  $user->role; 
				$success[$user->role_detail->name]   =  ($data != null) ? $data : [] ;
				
				return response()->json(['success' => $success, 'status'=>true, 'message'=>'You are successfully logged-in'], $this->successStatus); 
			} else if(Auth::attempt(['phone' => $request->input('user_name'), 'password' => $request->input('password')])){ 
				$user = User::with('role')->find(Auth::user()->id);
						   
				$user->device_token = $request->input('device_token');
				$user->lat = $request->input('lat');
				$user->lng = $request->input('lng');
				$user->save();
				
				$role = $user->role;
				switch ($role) {
					case 2: //doctor
						$data = Doctors::where('user_id', $user->id)->first();
						break;
					case 3: //user
						$data = array();
						break;
					case 4: //manager
						$data = ManagerDetail::where('user_id', $user->id)->first();
						break;
					case 5: //agent
						$data = Agent::where('user_id', $user->id)->first();
						break;
					case 6: //assistant
						$data = DoctorAssistant::where('user_id', $user->id)->first();
						break;
					default:
					$data = array();	
				}
				$skills		 = json_decode($data->skills);
				$sub_skills	 = json_decode($data->sub_skills);
				$allServ     = array();
				
				$services = Service::with(['subService'])->get()->toArray();
				
				if(!empty($skills) && is_array($skills)){
					foreach($skills as $skill){
						if(!empty($sub_skills) && is_array($skills)){
							$sub_skillsd = [];
							foreach($sub_skills as $sub_skill){
								$parentServ  = $this->getsubSkilldetail($sub_skill)->service_id;
								$skillName   = ($this->getSkilldetail($skill) ? $this->getSkilldetail($skill)->service_name : "");
								$subskillName   = ($this->getsubSkilldetail($sub_skill) ? $this->getsubSkilldetail($sub_skill)->sub_name : "");
								
								
								if($skill == $parentServ){
									$sub_skillsd[] = array('id' => $sub_skill,'name' => $subskillName);
								}
							}
						}else{
							$sub_skillsd = [];
						}
						$allServ[] = array('id' => $skill,'name' => $skillName,'sub_service' => $sub_skillsd);
					}
				}
				
				$skillIdArr = [];
				$subskillIdArr = [];
				foreach($allServ as $key => $servic){
					$skillIdArr[] = $servic['id'];
					foreach($servic['sub_service'] as $key2 => $subser){
						$subskillIdArr[] = $subser['id'];
					}
				}
				foreach($services as $key => $servic){
					if(in_array($servic['id'],$skillIdArr)){
						$servic['ischeck'] = '1';
					}else{
						$servic['ischeck'] = '0';
					}
					if(isset($servic['sub_service']) && !empty($servic['sub_service'])){
						foreach($servic['sub_service'] as $key2 => $subser){
							if(in_array($subser['id'],$subskillIdArr)){
									$subser['ischeck'] = '1';
							}else{
								$subser['ischeck'] = '0';	
							}
							$servic['sub_service'][$key2] = $subser;
						}
					}
					$services[$key] = $servic;
				}
				if($role == '2' || $role == '6')
					$data->skills  = $services;
					
				$success['id']  	=  $user->id; 
				$success['token']   =  $user->api_token; 
				$success['name']    =  $user->name; 
				$success['email']   =  $user->email; 
				$success['phone']   =  $user->phone; 
				$success['role']    =  $user->role; 
				$success[$user->role->name]    =  ($data != null) ? $data : [] ;
				return response()->json(['success' => $success, 'status'=>true, 'message'=>'You are successfully logged-in'], $this->successStatus); 			
			}
			else{ 
				return response()->json(['error'=>'Unauthorised', 'status'=>false, 'message'=>'Login credential is not correct'], $this->errorStatus); 
			} 
		}
	}
    
    public function skilltoArray($varss) {
        $vars = get_object_vars ( $varss );
        $array = array ();
        foreach ( $vars as $key => $value ) {
            $array [ltrim ( $key, '_' )] = $value;
        }
        return $array;
    }
    
    public function getSkilldetail($id){
		$SubService = Service::find($id);
		if($SubService !== null) {
			return $SubService;
		} else {
			return "";
		}
	}
	
	public function getsubSkilldetail($id){
		$SubService = SubService::find($id);
		if($SubService !== null) {
			return $SubService;
		} else {
			return "";
		}
	}
	
    
	/** 
     * Register api 
     * 
     * @return \Illuminate\Http\Response 
     */
    public function register(Request $request){
		if($request->license_number != ""){
				$validator = Validator::make($request->all(), [ 
				'name'	   => 'required', 
				'email'    => 'required|email|unique:users', 
				//'password' => 'required|min:6', 
				'phone'	   => 'required|min:9|unique:users', 
				'role'	   => 'required',
				'license_number'	   => 'required', 
			]);
		}else{
			$validator = Validator::make($request->all(), [ 
				'name'	   => 'required', 
				'email'    => 'required|email|unique:users', 
				//'password' => 'required|min:6', 
				'phone'	   => 'required|min:9|unique:users', 
				'role'	   => 'required', 
				'image'	   => 'required',
			]);
		}
		
		$setting = Setting::all();
		
        if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
        }
        $user = User::where('phone', $request->get('phone'))->orWhere('email',$request->get('email'))->first();
        
		/*if(empty($request->get('otp'))) {
			if($user == null) { 
				$OTP     =  mt_rand(100000, 999999);
				
				if(!empty($request->get('phone'))) {
					$message	 = "Dear ".$request->get('name').", Please use this otp to login (".$OTP .")";
					$SmsApi 	 =  new SmsApi();
					$SmsApi->sendSMS($request->get('phone'), $message);
				}
				if(!empty($request->get('name'))) {
					$mdata['email']     = $request->get('email');
					$mdata['name']      = $request->get('name');
					$mdata['otp']  		= $OTP;	
					Mail::to($request->get('email'))->send(new SendOtpMail($mdata));
				}
				return response()->json(['status'=>true,'message'=>'You will receive OTP on phone as well as email to login your account','otp'=>(string)$OTP]);  								
			}else{
				return response()->json(['status'=>false,'message'=>"User already exists."], $this->errorStatus);   
			}
		} else { */
			$input = $request->all();
			if($request->get('image')){
				$image	 = $request->get('image');
				$folder  		= 'doctor/';
				$random_number 	= mt_rand(100000, 999999);
				$f		        = finfo_open();
				$imgdata        = base64_decode($image);
				$mime_type      = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
				$mime_type      = explode('/',$mime_type);
				$imageName 		= $random_number.'.'.$mime_type[1];  
				File::put(public_path().'/images/'.$folder.$imageName, base64_decode($image)); 
			}else{
				$folder = '';
				$imageName = '';
			}
			//$input['password']  =  bcrypt($input['password']); 
			$input['api_token'] =  Str::random(60);
			$user  = User::create($input);         
			if($user->role == '3') {
				$user
			   ->roles()
			   ->attach(Role::where('name', 'user')->first());
			   
					$UserDetail = new UserDetail;
					$UserDetail->user_id =  $user->id;
					$UserDetail->save();
        
			} else if($user->role == '2') {
				$user
				->roles()
				->attach(Role::where('name', 'doctor')->first());				
				$user->request_recieve_per_day = $setting[0]->request_per_day;
						
				$Doctor = new Doctors;
				$Doctor->user_id =  $user->id;
				$Doctor->profile_picture =  '';
				$Doctor->license_picture =  $folder.$imageName;
				$Doctor->license_number =  $request->input('license_number');
				$unique_number = $user->id.mt_rand(100000,999999);
				$Doctor->unique_cnumber =  $unique_number;
				$Doctor->save();	
				$user->save();	
						
			} else if($user->role == '4') {
				$user
				->roles()
				->attach(Role::where('name', 'manager')->first());
				$Manager = new ManagerDetail;
				$Manager->user_id =  $user->id;
				$Manager->save();			
			} else if($user->role == '5') {
				$user
				->roles()
				->attach(Role::where('name', 'agent')->first());
				$Agent = new Agent;
				$Agent->user_id =  $user->id;
				$Agent->save();			
			} else if($user->role == '6') {
				$user
				->roles()
				->attach(Role::where('name', 'assistant')->first());
				$Assistant = new DoctorAssistant;
				$Assistant->user_id   =   $user->id;
				$Assistant->doctor_id =   $user->doctor_id;
				$Assistant->save();			
			} 
			/*$success['name']    =  $user->name;
			$success['email']   =  $user->email;
			$success['phone']   =  $user->phone;*/
			$getAdminUser = User::select('email')->where('role', 1)->first();
			$adminEmail = !empty($getAdminUser->email)?$getAdminUser->email:'';
			$adminEmail = 'test1dottechnologies@gmail.com';
			if(!empty($adminEmail)) {
				$mdata['name']      = $request->get('name');
				$mdata['email']     = $request->get('email');
				Mail::to($adminEmail)->send(new DoctorProfileAdminApprovalEmail($mdata));
			}
			return response()->json(['status'=>true,'message'=>"Thank you for Registering with Us! Your registration request is sent to Admin for Approval. Be patient! You'll be notified once done."]); 
		//}
        
    }
    /*public function register(Request $request) 
    {
        $validator = Validator::make($request->all(), [ 
            'name'	   => 'required', 
            'email'    => 'required|email|unique:users', 
            'password' => 'required|min:6', 
            'phone'	   => 'required|min:9|unique:users', 
            'role'	   => 'required', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], $this->errorStatus);            
        }
		$input = $request->all(); 
        $input['password']  =  bcrypt($input['password']); 
        $input['api_token'] =  Str::random(60);
        
        $user  = User::create($input); 
        if($user->role == '3') {
        $user
       ->roles()
       ->attach(Role::where('name', 'user')->first());
       
			$UserDetail = new UserDetail;
			$UserDetail->user_id =  $user->id;
			$UserDetail->save();
        
		} else if($user->role == '2') {
		$user
        ->roles()
        ->attach(Role::where('name', 'doctor')->first());
        $Doctor = new Doctors;
        $Doctor->user_id =  $user->id;
        $Doctor->save();			
		} else if($user->role == '4') {
		$user
        ->roles()
        ->attach(Role::where('name', 'manager')->first());
        $Manager = new ManagerDetail;
        $Manager->user_id =  $user->id;
        $Manager->save();			
		} else if($user->role == '5') {
		$user
        ->roles()
        ->attach(Role::where('name', 'agent')->first());
        $Agent = new Agent;
        $Agent->user_id =  $user->id;
        $Agent->save();			
		} else if($user->role == '6') {
		$user
        ->roles()
        ->attach(Role::where('name', 'assistant')->first());
        $Assistant = new DoctorAssistant;
        $Assistant->user_id   =   $user->id;
        $Assistant->doctor_id =   $user->doctor_id;
        $Assistant->save();			
		} 
        $success['name']    =  $user->name;
        $success['email']   =  $user->email;
        $success['phone']   =  $user->phone;
		return response()->json(['success'=>$success], $this->successStatus); 
    }    
    */
    /** 
     * Register by others api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function registerByothers(Request $request) 
    {
        $validator = Validator::make($request->all(), [ 
            'name'	   => 'required', 
            'email'    => 'required|email|unique:users',
            'phone'	   => 'required|min:9|unique:users', 
            'added_by' => 'required', 
            'role'	   => 'required', 
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], $this->errorStatus);            
        }
		$input = $request->all(); 
        $input['password']  =  Hash::make(Str::random(6)); 
        $input['api_token'] =  Str::random(60);
        if(!empty($request->input('address')))
        {
			$address = $request->input('address');
		}
		else
		{
			$address = "";
		}
        
        $user  = User::create($input);
        if($user->role == '3') {
        $user
       ->roles()
       ->attach(Role::where('name', 'user')->first());
		} else if($user->role == '2') {
		$user
        ->roles()
        ->attach(Role::where('name', 'doctor')->first());
        $Doctor = new Doctors;
        $Doctor->user_id =  $user->id;
        $Doctor->license_number =  $request->input('license_number');
        $unique_number 			= $user->id.mt_rand(100000,999999);
        $Doctor->unique_cnumber =  $unique_number;
        $Doctor->save();			
		} else if($user->role == '4') {
		$user
        ->roles()
        ->attach(Role::where('name', 'manager')->first());
        $Manager = new ManagerDetail;
        $Manager->user_id =  $user->id;
        $Manager->address =  $address;
        $Manager->save();			
		} else if($user->role == '5') {
		$user
        ->roles()
        ->attach(Role::where('name', 'agent')->first());
        $Agent = new Agent;
        $Agent->user_id =  $user->id;
        $Agent->address =  $address;
        $Agent->save();			
		} else if($user->role == '6') {
		$user
        ->roles()
        ->attach(Role::where('name', 'assistant')->first());
        $Assistant = new DoctorAssistant;
        $Assistant->user_id   =   $user->id;
        $Assistant->address   =   $address;
        $Assistant->doctor_id =   $user->doctor_id;
        $Assistant->save();			
		} else {
						
		}
		
		/*
		 * User credentials are sent to resigtered user by using email (Pending)
	    */
        $success['name']    =  $user->name;
        $success['email']   =  $user->email;
        $success['phone']   =  $user->phone;
		return response()->json(['success'=>$success], $this->successStatus); 
    }
    
    /** 
     * details api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function details(Request $request) 
    { 
        $user = User::find($request->input('user_id'))->toArray();        
        return response()->json(['success' => $user], $this->successStatus); 
    } 

    /** 
     * Update User API
     * 
     * @return \Illuminate\Http\Response 
    */ 
    public function UpdateUser(Request $request){

        $id       = $request->input('id');
        $name     = $request->input('user_name');
        $email    = $request->input('user_email');
        $phone    = $request->input('user_phone');
        $address  = $request->input('address');

        $User 		  = User::find($id);
        
        if($User !== null ) {
			$User->name   = $name;
			//$User->email  = $email;
			//$User->phone  = $phone;
			$User->save();
		   
			if(!empty($request->input('profile_image'))){
				$image   		= $request->input('profile_image');
				$random_number 	= mt_rand(100000, 999999);
				$f 				= finfo_open();
				$imgdata   		= base64_decode($image);
				$mime_type 		= finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
				$mime_type 		= explode('/',$mime_type);
				
				$imageName 		= $random_number.'.'.$mime_type[1];
			 }
			  
				$role 			= $User->role;
			switch ($role) {
				case 4: //manager
					$User['manager'] = ManagerDetail::where('user_id', $User->id)->first();
					if(!empty($request->input('profile_image'))){
						$folder         = 'manager/';
						File::put(public_path().'/images/manager/' . $imageName, base64_decode($image));  					
						$User['manager']->profile_pic = $folder.$imageName;
					}
					$User['manager']->address =  $address;
					$User['manager']->save();
					break;
				case 5: //agent
					$User['Agent'] = Agent::where('user_id', $User->id)->first();
					if(!empty($request->input('profile_image'))){
						$folder         	= 'agent/';
						File::put(public_path().'/images/agent/' . $imageName, base64_decode($image));   
						$User['Agent']->profile_pic = $folder.$imageName;
					}				
					$User['Agent']->address =  $address;
					$User['Agent']->save();
					break;
					
				case 6: //assistant
					$User['Assistant'] 	 = DoctorAssistant::where('user_id', $User->id)->first();
					if(!empty($request->input('profile_image'))){
						$folder         	= 'assistant/';
						File::put(public_path().'/images/assistant/'. $imageName, base64_decode($image));   
						$User['Assistant']->profile_pic = $folder.$imageName;
					}				
					$User['Assistant']->address 	= $address;
					$User['Assistant']->description = $request->input('description');
					$User['Assistant']->save();
					break;
				default:
				$data = array();	
					
			}
			return Response::json(array('success'=>true,'data'=>$User, 'message'=>'User updated successfully'));
		} else {			
			return Response::json(array('error'=>'Invalid Data! Please send valid parameters.'), $this->errorStatus);
		}
    }
	
    
    public function updatePassword(Request $request)
    { 
        if(User::find($request->input('user_id'))!==null) {
			$user = User::find($request->input('user_id'));
			if($user->id != 1) {
				$user->password = bcrypt($request->get('password'));
				$user->save();
				 return Response::json(array('success'=>true,'message'=>'Password Updated Successfully'));  
		   }else {
			   return response()->json(['error'=>'Unauthorised'], $this->errorStatus); 		   
		   }
       } else {
			   return response()->json(['error'=>'User Not Exist'], $this->errorStatus); 		   
		   }
    }
    
    /** 
     * Delete User API
     * 
     * @return \Illuminate\Http\Response 
    */ 
    public function DeleteUser(Request $request){		
        $id = $request->input('id');
        User::where('id',$id)->delete();
        RoleUser::where('user_id',$id)->delete();
        return Response::json(array('success'=>true,'message'=>'User Deleted successfully'));
    }	
    
    /** 
     * Forgot Password API
     * 
     * @return \Illuminate\Http\Response 
    */ 
    public function forgotPassword(Request $request) {
		$time = new DateTime(date('Y-m-d H:i:s'));
		$time->add(new DateInterval('PT5M'));
		$expTime = $time->format('Y-m-d H:i:s');

		if (User::where('email', '=', Input::get('user'))->first() != null) {
			$user = User::where('email', '=', Input::get('user'))->first();			 
		} else if(User::where('phone', '=', Input::get('user'))->first() != null) {
			$user = User::where('phone', '=', Input::get('user'))->first();
		}else {
			return response()->json(['error'=>'User Not Exist'], $this->errorStatus);   
		}
		
		 $forgotOtp = ForgotOtp::firstOrNew(array('user_id' => $user->id)); //insert or update
		 $forgotOtp->user_id    = $user->id;   
		 $forgotOtp->otp		= Str::random(4);   
		 $forgotOtp->expired_at = $expTime; 
		 $forgotOtp->save(); 
		 $resp['user_id']    = $forgotOtp->user_id;
		 $resp['otp']	     = $forgotOtp->otp;
		 $resp['expired_at'] = $forgotOtp->expired_at;
		 //mail();
		 return response()->json(['success'=>$resp], $this->successStatus); 	
	}
	
	/** Match Forgot OTP API
     * 
     * @return \Illuminate\Http\Response 
    */ 
	public function checkForgotOTP(Request $request) {
		$userID = Input::get('user_id');
		$otp    = Input::get('otp');
		$fOtp   = ForgotOtp::where('user_id',$userID)->first();
		if($fOtp !== null) {
			$d1 = new DateTime(date('Y-m-d H:i:s'));
			$d2 = new DateTime($fOtp->expired_at);
			
			if($fOtp->otp == $otp && $d1 <= $d2) {
			 return response()->json(['success'=>'otp match'], $this->successStatus);
			}else if($fOtp->otp == $otp && $d1 > $d2) {
				return response()->json(['error'=>'otp expired'], $this->errorStatus);			
			}else{
				return response()->json(['error'=>'not match'], $this->errorStatus); //otp not match
			}
		} else {			
			return Response::json(array('error'=>'Invalid Data! Please send valid parameters.'), $this->errorStatus);
		}
	} 
	
	public function index() 
	{				
		//$device_id = $_COOKIE['device_id'];
		//echo $device_id; die;
		
		$device_id = 'dkPqABWp4K2MGAxTDU9nqk:APA91bGB0zkC8pWPuIt9PXtsc70dtkO8xC5TyUQQo8ySY-utVRFZFk2vfnlXfuD_elROWCnysKHyHOW-q_cwOHXXIxvyxx0bMSR5JDjDWaI_KrkOmgVhHywPp61MBWfl9IjHPGh_0tG7';
	
	
		//$device_id = $device;
		//$message = $_POST['message'];
		
		//API URL of FCM
		$url = 'https://fcm.googleapis.com/fcm/send';

		/*api_key available in:
		Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key*/    $api_key = 'AAAAmvXY1N8:APA91bHZWMGHRadYCgzE354MdYf7nfqmMyfxO4XvjfMSYV6GNZ4m06fjMnwJdDQQmGCEvidU5HSU8Eb8jY3V71SJW1os-LTT0nrYZWkpNUNuHaBA9iv9BIvTz9n6Db9hf7a_GMv7Ud-i';
					
		$fields = array (
			'registration_ids' => array (
					$device_id
			),
			'data' => array (
					"message" => 'dfgdfg'
			)
		);

    	$api_key = 'AAAAn-F4NX4:APA91bGo1j7rqDpc1FtozZl7-2K4CdBGuZ5sIWX1uWisPCu-zRl_ynaYkslQxR6X7xjZygeAHIv_O-qInCZ5z_ZKrQfjrOJCVeAH8fg-AF_esgO6oemNPrdY_SqnzXerCmQcwxTE3TvK';	

		//header includes Content type and api key
		$headers = array(
			'Content-Type:application/json',
			'Authorization:key='.$api_key
		);
					
					
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
		$result = curl_exec($ch);
		if ($result === FALSE) {
			die('FCM Send Error: ' . curl_error($ch));
		}
		curl_close($ch);
		return $result;
		
	}
	
	
	
	public function push_notification_android($device_id)
	{
			
			//$device_id = $_COOKIE['device_id'];
			//echo $device_id; die;
			
			//$device_id = 'dkPqABWp4K2MGAxTDU9nqk:APA91bGB0zkC8pWPuIt9PXtsc70dtkO8xC5TyUQQo8ySY-utVRFZFk2vfnlXfuD_elROWCnysKHyHOW-q_cwOHXXIxvyxx0bMSR5JDjDWaI_KrkOmgVhHywPp61MBWfl9IjHPGh_0tG7';
		
		
			//$device_id = $device;
			//$message = $_POST['message'];


		
		//API URL of FCM
		$url = 'https://fcm.googleapis.com/fcm/send';

		/*api_key available in:
		Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key*/    $api_key = 'AAAAmvXY1N8:APA91bHZWMGHRadYCgzE354MdYf7nfqmMyfxO4XvjfMSYV6GNZ4m06fjMnwJdDQQmGCEvidU5HSU8Eb8jY3V71SJW1os-LTT0nrYZWkpNUNuHaBA9iv9BIvTz9n6Db9hf7a_GMv7Ud-i';
					
		$fields = array (
			'registration_ids' => array (
					$device_id
			),
			'data' => array (
					"message" => 'dfgdfg'
			)
		);

	    $api_key = 'AAAAn-F4NX4:APA91bGo1j7rqDpc1FtozZl7-2K4CdBGuZ5sIWX1uWisPCu-zRl_ynaYkslQxR6X7xjZygeAHIv_O-qInCZ5z_ZKrQfjrOJCVeAH8fg-AF_esgO6oemNPrdY_SqnzXerCmQcwxTE3TvK';	

		//header includes Content type and api key
		$headers = array(
			'Content-Type:application/json',
			'Authorization:key='.$api_key
		);
					
			
					
					
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
		$result = curl_exec($ch);
		if ($result === FALSE) {
			die('FCM Send Error: ' . curl_error($ch));
		}
		curl_close($ch);
		return $result;
	}

	
	
	function push($device_id = NULL,$message = NULL){
		
		
			//$device_id = $_POST['device_id'];
			//$message = $_POST['message'];
		$device_id	= ' fXJL03cBMVEEz1DJiQoB8J:APA91bEQsUi3XbkVHqCeiDikg8YTo6O6iqxzz7Mm3fQsM5jDN9DfOmJuXCElcizV6Qa--4So3GFxarOzzJKxETZepV7VwyH5E0geRDMm7mQi4cjSpm-PvC73olz3sR3fhPW5jg6YIaAi';
			$message = 'Nikhil';
		
		//API URL of FCM
		$url = 'https://fcm.googleapis.com/fcm/send';

		/*api_key available in:
		Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key*/    $api_key = 'AAAAmvXY1N8:APA91bHZWMGHRadYCgzE354MdYf7nfqmMyfxO4XvjfMSYV6GNZ4m06fjMnwJdDQQmGCEvidU5HSU8Eb8jY3V71SJW1os-LTT0nrYZWkpNUNuHaBA9iv9BIvTz9n6Db9hf7a_GMv7Ud-i';
					
		$fields = array (
			'registration_ids' => array (
					$device_id
			),
			'data' => array (
					"message" => $message
			)
		);


		$api_key = 'AAAAn-F4NX4:APA91bGo1j7rqDpc1FtozZl7-2K4CdBGuZ5sIWX1uWisPCu-zRl_ynaYkslQxR6X7xjZygeAHIv_O-qInCZ5z_ZKrQfjrOJCVeAH8fg-AF_esgO6oemNPrdY_SqnzXerCmQcwxTE3TvK';

		//header includes Content type and api key
		$headers = array(
			'Content-Type:application/json',
			'Authorization:key='.$api_key
		);
					
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
		$result = curl_exec($ch);
		if ($result === FALSE) {
			die('FCM Send Error: ' . curl_error($ch));
		}
		curl_close($ch);
		return $result;
	}
	
   
	
	public function doctorNotification(Request $request) 
	{
		//echo "xcvxc";die;
	   	$data['message']   = $request->input('message');
	   	$data['doctor_id'] = $request->input('doctor_id');
	    $data['to'] = $request->input('to');
	    $data['from'] = $request->input('from');
		$data['user_id']   = $request->input('user_id');
		$data['device_token'] = 'IZCk1UhFxKd8qUPPxrhuaHOxckxMBFLwP4zXeKMkdXOf2Vbp9wArS3yyNUeX';
		//print_r($request->input());die;
		
		//$success = DB::table('chat')->insert(['to' => $to, 'message' => $message,'user_id' => $user_id,'from' => $from, 'doctor_id' => $doctor_id, 'device_token' => $device_token])->lastInsertId();
	    
	   // $lastInsertedID = DB::table('chat')->insert( $data )->lastInsertId();
	    
	    $lastInsertedID= DB::table('chat')->insertGetId($data);
	             
        $date = DB::table('chat')->select('created_at')->where('id', $lastInsertedID)->get();
        
         $created_at = $date[0]->created_at;
         
        $time =  explode(" ",$created_at);
		
			$users 		= User::where('id',$request->doctor_id)->first();
		if($users){
			$device_token = $users->device_token;
		}
		
		
        	$this->push_notification_android($device_token);
	    
	    if($date){
			
	  return response()->json(['success'=>'Success Response','date'=> $time[0],'time'=> $time[1]], $this->successStatus); 
	}else{
		
	 return response()->json(['error'=>'Response Not Found', 'status'=>false, 'message'=>'Response Not Found'], $this->errorStatus); 

		}
	
	}
	
	
    public function registerByManager(Request $request) 
    {
        $validator = Validator::make($request->all(), [ 
            'name'	   => 'required', 
            'email'    => 'required|email|unique:users',
            'phone'	   => 'required|min:9|unique:users', 
            'added_by' => 'required', 
            'role'	   => 'required', 
        ]);
        
        
        $manager['aadhar_card_pic'] = $request->input('aadhar_card_pic');
		$manager['profile_pic'] = $request->input('profile_pic');
		$manager['manager_id'] = $request->input('manager_id');
		$manager['type'] = 'marketing manager';
		
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], $this->errorStatus);            
        }
		$input = $request->all(); 
        $input['password']  =  Hash::make(Str::random(6)); 
        $input['api_token'] =  Str::random(60);
        
        $user  = User::create($input);
        if($user->role == '3') {
        $user
       ->roles()
       ->attach(Role::where('name', 'user')->first());
		} else if($user->role == '2') {
		$user
        ->roles()
        ->attach(Role::where('name', 'doctor')->first());
        $Doctor = new Doctors;
        $Doctor->user_id =  $user->id;
        $Doctor->save();			
		} else if($user->role == '4') {
		$user
        ->roles()
        ->attach(Role::where('name', 'manager')->first());
        $Manager = new ManagerDetail;
        $Manager->user_id =  $user->id;
        $Manager->save();			
		} else if($user->role == '5') {
		$user
        ->roles()
        ->attach(Role::where('name', 'agent')->first());
        $Agent = new Agent;
        $Agent->user_id =  $user->id;
        $Agent->save();			
		} else if($user->role == '6') {
		$user
        ->roles()
        ->attach(Role::where('name', 'assistant')->first());
        $Assistant = new DoctorAssistant;
        $Assistant->user_id   =   $user->id;
        $Assistant->doctor_id =   $user->doctor_id;
        $Assistant->save();			
		} else if($user->role == '4') {
		DB::table('manager_details')->insert(
		['aadhar_card_pic' => $manager['aadhar_card_pic'], 'votes' => 0],
		['profile_pic' => $manager['profile_pic'], 'votes' => 0],
		['manager_id' => '0', 'votes' => 0],
		['type' => 'marketing manager', 'votes' => 0]
	);	
		} else {
						
		}
		
		/*
		 * User credentials are sent to resigtered user by using email (Pending)
	    */
        $success['name']    =  $user->name;
        $success['email']   =  $user->email;
        $success['phone']   =  $user->phone;
		return response()->json(['success'=>$success], $this->successStatus); 
    }
	
	public function DoctorLogout(Request $request)
		{
			//die('nikhil');
			$id = $request->input('id');
			$Users = User::where('id',$id)->first();
			if($Users){
				$Users->device_token = "";	
				$Users->save();
				return response()->json(['status'=>true,'message'=>'Logout Successfully'], $this->successStatus);  
			}else{
				return response()->json(['status'=>false,'message'=>'Something went wrong.'], $this->errorStatus);	
			}
				
		}
	
	/*
	 * 
	 * Validate doctor with unique number
	 * 
	 * */
	 public function validateDoctoerwithNumber(Request $request){
		 $Doctors = Doctors::where('unique_cnumber',$request->unique_cnumber)->where('unique_cnumber','!=','0')->with('user')->first();
		 $data = [];
		 if($Doctors){
			$data['user_id'] = $Doctors->user_id;
			if($Doctors->user){
				$data['name']  = $Doctors->user->name;
			}else{
				$data['name']  = "";
			}
			return response()->json(['status'=>true,'message'=>'Doctor is valid.','data' =>$data], $this->successStatus);  
		 }else{
			return response()->json(['status'=>false,'message'=>'This Doctor is not valid.','data' =>$data], $this->errorStatus);	
		 }
	 }
	 
	 
	// User Login API
	public function userLogin(Request $request)
    {	 
		$data['email'] = $request->input('email');
		$data['phone'] = $request->input('phone');
		$username = $request->input('username');
		$emailFlag = 0;
		if(preg_match('/^[A-z0-9_\-]+[@][A-z0-9_\-]+([.][A-z0-9_\-]+)+[A-z.]{2,4}$/', $username)){ 
			$emailFlag = 1;				
		}	
		
        if(!empty($request->input('username')) && $emailFlag==0 ) {			
			$user = User::where('phone', $request->get('username'))->first(['id','name','email','phone']);
			
				 if(empty($user->phone)) {
					return Response::json(array('status'=>false, 'message'=>'Phone No not Match')); 
				  } else {
					        $time 	 = new DateTime(date('Y-m-d H:i:s'));
							$time->add(new DateInterval('PT5M'));
							$expTime = $time->format('Y-m-d H:i:s');
							$OTP     =  mt_rand(100000, 999999);
							
							$forgotOtp  = ForgotOtp::firstOrNew(['user_id'=>$user->id,'type'=>'login']);
							$forgotOtp->user_id    =  $user->id;
							$forgotOtp->type   	   =  'login';
							$forgotOtp->otp 	   =  $OTP;
							$forgotOtp->expired_at = $expTime;							
							$forgotOtp->save();
								
							$message	 = "<#>Dear, Welcome to Kabera Global. Please use this otp to login with us (".$OTP .") ".env('APP_MSG_CODE');
							$SmsApi 	 =  new SmsApi();
							$SmsApi->sendSMS($user->phone, $message);
		
							if($user->phone){
								
							return Response::json(array('status'=>true, 'otp'=>$OTP, 'user_id'=>$forgotOtp->user_id , 'message'=>'OTP Send Successfully', 'data'=>$user)); 
							}else{
							return Response::json(array('status'=>false, 'message'=>'Phone No not Match')); 
							
							}
							
							}
					} else if (!empty($request->get('username')) && $emailFlag==1) {
						$user = User::where('email', $request->get('username'))->first(['id','name','email','phone']);
							 if(empty($user->email)) {
								return Response::json(array('status'=>false, 'message'=>'Email No not Match')); 
							  } else {
								  
										$time 	 = new DateTime(date('Y-m-d H:i:s'));
										$time->add(new DateInterval('PT5M'));
										$expTime = $time->format('Y-m-d H:i:s');
										$OTP     =  mt_rand(100000, 999999);
										
										$forgotOtp  = ForgotOtp::firstOrNew(['user_id'=>$user->id,'type'=>'login']);
										$forgotOtp->user_id    =  $user->id;
										$forgotOtp->type   	   =  'login';
										$forgotOtp->otp 	   =  $OTP;
										$forgotOtp->expired_at = $expTime;							
										$forgotOtp->save();
										
										$mdata['email']     = $user->email;
										$mdata['name']      = $user->name;
										$mdata['otp']  		= $OTP;	
										$mailotp = Mail::to($user->email)->send(new SendOtpMail($mdata));
										
										if($mdata['email']){
										return Response::json(array('status'=>true, 'otp'=>$OTP ,  'user_id'=>$forgotOtp->user_id , 'message'=>'OTP Send Successfully','data'=>$user)); 
										}else{
										return Response::json(array('status'=>false, 'message'=>'Email not Match')); 
										
										}
											
										
							  }
					} else {
						//return response()->json(['status'=>true, 'appointment_id' => $AppointmentList->id,'message' => 'Your request has been submitted. We will update you soon!'], $this->successStatus); 
						return Response::json(array('success'=>true, 'message'=>'Credential wrong ..!!')); 
					}        
	}
	
	//User login otp API
	public function UserLoginOTP(Request $request) {
		
		$validator = Validator::make($request->all(), [             
            'user_id'    => 'required',
            'otp'	     => 'required',  
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], $this->successStatus);            
        }    
        
		$user_id      = $request->input('user_id');
		$otp          = $request->input('otp');
        $verifyUser	  = forgotOtp::where('user_id', $user_id)->first();
        if(isset($verifyUser) ) {
			$user   = $verifyUser->user;
		
			$d1 = new DateTime(date('Y-m-d H:i:s'));
			$d2 = new DateTime($verifyUser->expired_at);
			
			if($verifyUser->otp == $request->input('otp') && $d1 <= $d2) {					
				Auth::loginUsingId($user->id);	
				return Response::json(array('status'=>true, 'message'=>'Login Successfully')); 									
			}else if($verifyUser->otp == $request->input('otp') && $d1 > $d2) {
				
				return Response::json(array('status'=>false, 'message'=>'Sorry! This OTP is expired. Please try again.')); 
					
			} else {
				
				return Response::json(array('status'=>false, 'message'=>'Sorry! OTP Not Match, Please Try Again'));
				
			}
                
        }else{			
				return Response::json(array('status'=>false, 'message'=>'Sorry! User Id Not Match, Please Try Again'));
			}			
			
	}
	
	 
	/** 
	 * User App Register API
	 * @return response
	**/
	public function userRegister(Request $request)
    {		
		 $validator = Validator::make($request->all(), [             
            'name'    => 'required',
            'email'    => 'required|email|unique:users',
            'phone'	   => 'required|min:9|unique:users',  
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], $this->successStatus);            
        }             
       
        $userdata['name']  = $request->input('name');
        $userdata['device_id']  = $request->input('device_id');	
        $userdata['email'] = $request->input('email');
        $userdata['phone'] = $request->input('phone');
        $userdata['api_token'] 		   = Str::random(60);
        $userdata['isVerified'] 	   =  1;
        $userdata['email_verified_at'] = date("Y-m-d h:i:s");
        $userdata['customer_number']   = mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999);
        
        /* referral code */        
        $refrrel_linkcode = $request->input('refrrel_linkcode');
        $ref_code = $request->input('refferal_code');
        $register_email   = $request->input('email');
        $register_phone   = $request->input('phone');
         $device_id  = $request->input('device_id');
        $direct_points = ReferralPointsData::all();
       
        $referra_bypoint = $direct_points[0]->ref_by_points;
	    $referra_topoint = $direct_points[0]->ref_to_points;
        $status = 0;
        $referra_by_status = "reffered by someone";
        $referra_to_status = "reffered to someone";
        
        $time 	 = new DateTime(date('Y-m-d H:i:s'));
		$time->add(new DateInterval('PT5M'));
		$expTime = $time->format('Y-m-d H:i:s');
        $OTP     =  mt_rand(100000, 999999);
        
        /* points base on refferal link */
        
        if(!empty($refrrel_linkcode))
        {
			$decrypt_ref = decrypt($refrrel_linkcode);
			$status = 0;
			
			/* check user is register to referal email id or not */
			
			$check_refcodelink = ReferralData::where("ref_code", $decrypt_ref)->where('status', $status)->where('ref_to_email',$register_email)->first();

			if($check_refcodelink !== null)
			{

				$referral_from = $check_refcodelink->user_id;
				$referto_email   = $check_refcodelink->ref_to_email;
				$referral_type   = $check_refcodelink->ref_type;
				
				$check_user_registered = User::where("email", $register_email)->first();
				   
					/* register user */
					$user = User::create($userdata);
					$user->roles()->attach(Role::where('name', 'user')->first());
					
					$UserDetail = new UserDetail;
					$UserDetail->user_id =  $user->id;
					$UserDetail->save();
					
					$message	 = "<#>Dear, Welcome to Kabera Global. Please use this otp to login with us (".$OTP .") ".env('APP_MSG_CODE');
					$SmsApi 	 = new SmsApi();
					$SmsApi->sendSMS($user->phone, $message);
					
					$forgotOtp   = forgotOtp::create([
						'user_id' => $user->id,
						'type'    => 'login',
						'otp'     => $OTP,
						'expired_at' => $expTime
					]);
					
					$register_user_id = $check_user_registered->id;
					
					/* update referred by user points */
					
					ReferralData::where("user_id",$referral_from)->where("ref_to_email",$referto_email)->update(['points' => $referra_bypoint,'point_des' => $referra_to_status,'status' => 1]);
					
					/* insert referred to user points */
					
					$new_registered_points = new ReferralData;
					$new_registered_points->user_id = $register_user_id;
					$new_registered_points->ref_from = $referral_from;
					$new_registered_points->ref_code = "";
					$new_registered_points->ref_to_email = $referto_email;
					$new_registered_points->ref_to_phone = $register_phone;
					$new_registered_points->status = 1;
					$new_registered_points->ref_type = $referral_type;
					$new_registered_points->points = $referra_topoint;
					$new_registered_points->point_des = $referra_by_status;
					$new_registered_points->save();
					
					/* insert total points of referred to user */
					$check_user_point_exist = 	ReferralPoint::where("user_id",$register_user_id)->first();
					
					if(empty($check_user_point_exist))
					{
						$total_user_points = ReferralData::where("user_id", $register_user_id)->sum('points');
						$used_points = 0;
						$points_data = new ReferralPoint;
						$points_data->user_id = $register_user_id;
						$points_data->total_points = $total_user_points;
						$points_data->used_points = $used_points;
						$points_data->save();
					}
					else
					{
						$total_user_points = ReferralData::where("user_id", $register_user_id)->sum('points');
						$used_points = $check_user_point_exist->used_points;
						$pending_points = $total_user_points - $used_points;
						ReferralPoint::where("user_id",$register_user_id)->update(['total_points' => $pending_points]);
						
					}
					
					/* insert total points of referred by user */
					
					$check_point_data = ReferralPoint::where("user_id",$referral_from)->first();
					
					if(empty($check_point_data))
					{
						$reffrom_user_points = ReferralData::where("user_id", $referral_from)->sum('points');
						$reffrom_used_points = 0;
						$points_data = new ReferralPoint;
						$points_data->user_id = $referral_from;
						$points_data->total_points = $reffrom_user_points;
						$points_data->used_points = $reffrom_used_points;
						$points_data->save();
					}
					else
					{
						$reffrom_user_points = ReferralData::where("user_id", $referral_from)->sum('points');
						$reffrom_used_points = $check_point_data->used_points;
						$reffrom_pending_points = $reffrom_user_points - $reffrom_used_points;
						ReferralPoint::where("user_id",$referral_from)->update(['total_points' => $reffrom_pending_points]);
						
					}					
				
					return Response::json(array('status'=>true, 'otp'=>$OTP, 'user_id'=>$user->id , 'message'=>'OTP Send Successfully', 'data'=>$user), $this->successStatus); 
				
				
			} else {			
				
				return Response::json(array('status'=>false, 'message'=>'Invalid Refer Code'), $this->successStatus); 
			}
			
		}
		/* points base on refferal code */
		else if($ref_code != null)
		{
			$check_refcode 		 =  ReferralData::where("ref_code", $ref_code)->first();
			$check_refcodestatus =  ReferralData::where("ref_code", $ref_code)->where('status', $status)->first();
			$check_refemail		 =  ReferralData::where("ref_code", $ref_code)->where('ref_to_email',$register_email)->first();
			if($check_refcode  != null)
			{
				if($check_refcodestatus == null)
				{
					return Response::json(array('status'=>false, 'message'=>'Referral code already used !!'), $this->successStatus); 
					
				}
				else if($check_refemail == null)
				{
					
					return Response::json(array('status'=>false, 'message'=>'Referral email address belong to referral code is different from the registered email address '), $this->successStatus); 
					
				}
				else
				{
				    $get_record = ReferralData::where("ref_code", $ref_code)->where('status', $status)->first();
					$referral_from = $get_record->ref_from;
					$referto_email = $get_record->ref_to_email;
					$referral_type   = $get_record->ref_type;
					
					/* register user */
					$user = User::create($userdata);
					$user->roles()->attach(Role::where('name', 'user')->first());
					
					$UserDetail = new UserDetail;
					$UserDetail->user_id  =  $user->id;
					$UserDetail->save();
		
					/* check user is registered or not */
					$check_user_registered = User::where("email", $register_email)->first();
				
					$message	 = "<#>Dear, Welcome to Kabera Global. Please use this otp to login with us (".$OTP .") ".env('APP_MSG_CODE');
					$SmsApi 	 = new SmsApi();
					$SmsApi->sendSMS($user->phone, $message);
					
					$forgotOtp   = forgotOtp::create([
						'user_id' => $user->id,
						'type'    => 'login',
						'otp'     => $OTP,
						'expired_at' => $expTime
					]);
				
				
					$register_user_id = $check_user_registered->id;
					
					/* update referred by user points */
					
					ReferralData::where("user_id",$referral_from)->where("ref_to_email",$referto_email)->update(['points' => $referra_bypoint,'point_des' => $referra_to_status,'status' => 1]);
					
					/* insert referred to user points */
					
					$new_registered_points = new ReferralData;
					$new_registered_points->user_id = $register_user_id;
					$new_registered_points->ref_from = $referral_from;
					$new_registered_points->ref_code = "";
					$new_registered_points->ref_to_email = $referto_email;
					$new_registered_points->ref_to_phone = $register_phone;
					$new_registered_points->status = 1;
					$new_registered_points->ref_type = $referral_type;
					$new_registered_points->points = $referra_topoint;
					$new_registered_points->point_des = $referra_by_status;
					$new_registered_points->save();
					
					/* insert total points of referred to user */
					$check_user_point_exist = 	ReferralPoint::where("user_id",$register_user_id)->first();
					
					if(empty($check_user_point_exist))
					{
						$total_user_points = ReferralData::where("user_id", $register_user_id)->sum('points');
						$used_points = 0;
						$points_data = new ReferralPoint;
						$points_data->user_id = $register_user_id;
						$points_data->total_points = $total_user_points;
						$points_data->used_points = $used_points;
						$points_data->save();
					}
					else
					{
						$total_user_points = ReferralData::where("user_id", $register_user_id)->sum('points');
						$used_points = $check_user_point_exist->used_points;
						$pending_points = $total_user_points - $used_points;
						ReferralPoint::where("user_id",$register_user_id)->update(['total_points' => $pending_points]);
						
					}
					
					/* insert total points of referred by user */
					
					$check_point_data = ReferralPoint::where("user_id",$referral_from)->first();
					
					if(empty($check_point_data))
					{
						$reffrom_user_points = ReferralData::where("user_id", $referral_from)->sum('points');
						$reffrom_used_points = 0;
						$points_data = new ReferralPoint;
						$points_data->user_id = $referral_from;
						$points_data->total_points = $reffrom_user_points;
						$points_data->used_points = $reffrom_used_points;
						$points_data->save();
					}
					else
					{
						$reffrom_user_points = ReferralData::where("user_id", $referral_from)->sum('points');
						$reffrom_used_points = $check_point_data->used_points;
						$reffrom_pending_points = $reffrom_user_points - $reffrom_used_points;
						ReferralPoint::where("user_id",$referral_from)->update(['total_points' => $reffrom_pending_points]);
						
					}
					
				    return Response::json(array('status'=>true, 'otp'=>$OTP, 'user_id'=>$user->id , 'message'=>'Registered Successfully', 'data'=>$user), $this->successStatus);						
					
					
				
				}
			} else {
				  return Response::json(array('status'=>false, 'message'=>'Referral code is wrong !!'), $this->successStatus);
			}
		} else { // Register user 
				
			    $user = User::create($userdata);
				$user->roles()->attach(Role::where('name', 'user')->first());
				
				$UserDetail = new UserDetail;
				$UserDetail->user_id  =  $user->id;
				$UserDetail->save();
		
			    /* check user is registered or not */
				$check_user_registered = User::where("email", $register_email)->first();
				
					$message	 = "<#>Dear, Welcome to Kabera Global. Please use this otp to login with us (".$OTP .") ".env('APP_MSG_CODE');
					$SmsApi 	 = new SmsApi();
					$SmsApi->sendSMS($user->phone, $message);
					
					$forgotOtp   = forgotOtp::create([
						'user_id' => $user->id,
						'type'    => 'login',
						'otp'     => $OTP,
						'expired_at' => $expTime
					]);
					
					$register_user_id = $check_user_registered->id;
					
					/* insert referred to user points */
					
					$new_registered_points = new ReferralData;
					$new_registered_points->user_id = $register_user_id;
					$new_registered_points->ref_from = "";
					$new_registered_points->ref_code = "";
					$new_registered_points->ref_to_email = "";
					$new_registered_points->ref_to_phone = $register_phone;
					$new_registered_points->status = 1;
					$new_registered_points->ref_type = "new user";
					$new_registered_points->points = $referra_topoint;
					$new_registered_points->point_des = "First Signup";
					$new_registered_points->save();
					
					/* insert total points of referred to user */
					
					$total_user_points = ReferralData::where("user_id", $register_user_id)->sum('points');
					$used_points = 0;
					$points_data = new ReferralPoint;
					$points_data->user_id = $register_user_id;
					$points_data->total_points = $total_user_points;
					$points_data->used_points = $used_points;
					$points_data->save();
					
					return Response::json(array('status'=>true, 'otp'=>$OTP, 'user_id'=>$user->id , 'message'=>'Registered Successfully', 'data'=>$user), $this->successStatus);	
				
		}
	}
	
}
