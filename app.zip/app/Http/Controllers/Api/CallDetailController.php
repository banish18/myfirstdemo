<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;

use App\SmsApi;
use App\User;
use App\Dials;
use App\AppointmentList;
use App\AppointmentRequest;
use App\Procedure;
use App\HairTransplantReport;
use App\AssistantProcedureRecords;
use App\Mail\SendOtpMail;
use App\Mail\ReportByDoctorMail;

use Auth;
use Session;
use Validator;
use Config;
use File;
use DB;
use FCM;
use LaravelFCM\Message\Topics;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;

//use Ixudra\Curl\Facades\Curl;

class CallDetailController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */   
    public $successStatus = 200;
    public function __construct()
    {
	   /*if(!Auth::check()){
		   die('Login');
	   }*/
      // $this->middleware(['verified']);
    }
    
	
	public function CallDetail(Request $request) 
	{
		$fpn = Config::get('app.fpn');
		$url = "http://click.paragalaxy.com/api/click2call.php?TID=db49cfd53c&CID=MzA1&BID=a2FiZXJhQzJD&FPN=".$fpn."&SPN=".$request->phone_number."&BST=";
		//$url = "http://click.paragalaxy.com/api/click2call.php?TID=64644dcd2c&CID=Mjc0&BID=Y29uZmVyZW5jZUFwaQ==&FPN=".$request->doctor_number."&SPN=".$request->phone_number."&BST=";
		
		//echo $url;
		 $ch = curl_init();
		 curl_setopt($ch, CURLOPT_URL, $url);
		 curl_setopt($ch, CURLOPT_POST, 0);
		 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		 $response 	= curl_exec ($ch);
		 $varable 	=  str_replace("API : Click To Call","", strip_tags($response));
		 $udid 		=  json_decode($varable);
		 if($udid && $udid->uid != ""){
			 $Dials = new Dials;
			 $Dials->uid 			= $udid->uid;
			 $Dials->user_id 		= $request->user_id;
			 $Dials->appointment_id = $request->appointment_id;
			 $Dials->doctor_call 	= $fpn;
			 $Dials->user_call 		= $request->phone_number;
			 $Dials->procedure_id 	= $request->procedure_id;
			 $Dials->save();	
			 return response()->json(['status'=>'success', 'data' => 'Your Call uid inserted successfully', 'uid'=> $Dials->uid], $this->successStatus); 
		 }else{
			 return response()->json(['status'=>'success', 'data' => 'No Data Available'], $this->successStatus);
		 }
	}
	
	/* Update calls Deatial Status */
	public function UpdateCallDetail(Request $request) 
	{
		$uid 					= $request->input('uid');
		$doctor_call_status 	= $request->input('doctor_call_status');
		$user_call_status		= $request->input('user_call_status');
		$recording 				= $request->input('recording');
		if(!empty($uid)){
			$detail = Dials::where('uid',$uid)->first();
			if($detail){
					$detail->doctor_call_status = $doctor_call_status;
					$detail->user_call_status 	= $user_call_status;
					$detail->recording 			= $recording;
					$detail->save();
					
					if($doctor_call_status == "ANSWERED") {  
						// update filed to get previous call time for appointment				
						$appList = AppointmentList::find($detail->appointment_id);
						$appList->updated_at = time();
						$appList->save();
					}
					return response()->json(['status'=>'success', 'data' => 'Successfully Updated'], $this->successStatus); 
				
			}else{
				return response()->json(['status'=>'success', 'data' => 'No Data Available'], $this->successStatus);
			}
		}else{
			return response()->json(['status'=>'success', 'data' => 'No Data Available'], $this->successStatus);
		}
	}
	
	/* Check Call Status */	
	public function checkCallStatus() {
		
		$appointments  = AppointmentList::where('doctor_id','!=',0)->where('status','1') ->where('appointment_status','new')->where('visit_first',0)->where('call_status',0)->with('call_records')->get();		
		
		foreach($appointments as $key=>$appointment) {
			
			$now		  = strtotime(date('Y-m-d H:i:s'));
			$apointDate   = strtotime($appointment->updated_at);
			
			
		   if(count($appointment->call_records)) {			   			   	   		
				$answeredCall = Dials::where('procedure_id',$appointment->id)->where('doctor_call_status','ANSWERED')->where('user_call_status','ANSWERED')->first();
				if($answeredCall) {
					AppointmentRequest::where('appointment_id',$appointment->id)->delete();
					$appList = AppointmentList::find($appointment->id);
					$appList->call_status = '1';
					$appList->save();
					echo "Lead Done For ". $appointment->id . "<br>";
					continue;
				} else {						
					$dateDiff = $now - $apointDate;
					if($dateDiff >= 172800) { // 172800 greater than 48 hours						
						$List = AppointmentList::find($appointment->id);
						$List->doctor_id = 0;
						$List->status    = '0';
						$List->save();
						
						$Procedure = Procedure::find($appointment->procedure_id);
						$Procedure->doctor_id = 0;
						$Procedure->save();
						
						AppointmentRequest::where('appointment_id',$appointment->id)->where('doctor_id',$appointment->doctor_id)->delete(); // remove this doctor form lead
						$this->resendAppRequest($appointment->id); // resend request to doctors 
						continue;
					}
				}
				
			} else { // if records not exist on click to dial 
				$dateDiff = $now - $apointDate;
				//echo date('Y-m-d H:i:s')  ." = ".	$appointment->updated_at . " id =" . $appointment->id. "<br>"; 
				//echo $dateDiff; die;	
				if($dateDiff >= 3600 ) { // greater than one hour 					
					$List = AppointmentList::find($appointment->id);
					$List->doctor_id = 0;
					$List->status    = '0';
					$List->save();
					
					$Procedure = Procedure::find($appointment->procedure_id);
					$Procedure->doctor_id = 0;
					$Procedure->save();
					
					AppointmentRequest::where('appointment_id',$appointment->id)->where('doctor_id',$appointment->doctor_id)->delete(); // remove this doctor form lead					 
					$this->resendAppRequest($appointment->id); // resend request to doctors 		
					continue;		
				}
				
				if($dateDiff <= 3600 && $dateDiff >= 1500) {
					
					//$this->callNotification($token, $username, $appointment->id)
					//send notification here;
					echo "notificatino sent for ". $appointment->id . "<br>";
					continue;
				}
			}
			
			echo "Nothing to do for  ". $appointment->id . " . Call Done But Not Picked By User<br>";
			
		}
	}
	
	/* Resend Appointment Request To Doctors */	
	function resendAppRequest($appId) {	
					
		$requests = AppointmentRequest::with(['appointment','subService'])->where('appointment_id',$appId)->get();
		
		if(count($requests)) {					
			 foreach($requests as $key=>$request) {				  
				$service_id  = $request->service_id;				
				$serviceName = 'N/A';
				$appointmentDate = date('Y-m-d',strtotime($request->appointment->appointment_date));					
				$timeSlot        = date('H:i a',strtotime($request->appointment->appointment_date));
								
				$user 			 = User::where('id',$request->doctor_id)->first();				
				if($user) {
					/* appointment request email to all doctors whoese under distance */
					$email = $user->email;
					$fromEmail = env('MAIL_FROM_ADDRESS');
					//$email = "dottechnologies123@gmail.com";
					$name  = $user->name;
					$link  = url('/').'/api/user/confirm-request/'.$appId;
					$data  = array(
							'name'		=> $name,
							'service' 	=> $serviceName,
							'date' 		=> $appointmentDate,
							'time' 		=> $timeSlot,
							'email' 	=> $email,
							'from'   	=> $fromEmail,
							'link' 		=> $link);					
					
					Mail::send('requestMail', $data, function($message) use ($data) {
						$message->to($data['email'], 'KABERA')->subject
						('Customer Appointment Request');
						$message->from($data['from'],'Kabera');
					});
					
					$device_token = $user->device_token;
					if($device_token != ""){
						app('App\Http\Controllers\Api\UserProcedureController')->AppointmentNotification($device_token);						
					}
					echo "Request Resend Successfully" . "<br>";
				}					
			 }
			
		} else {
			echo "No other doctors are available for this area". "<br>";
		}	
	}
	
	
	 public function callNotification($token, $username, $appId) 
	{
		
		$optionBuilder = new OptionsBuilder();
		
		$optionBuilder->setTimeToLive(60*20);
		
		$notificationBuilder = new PayloadNotificationBuilder('Kabera');
		$notificationBuilder->setBody('your have a call notification for user.')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		
		//$message1 =  Response::json(array('success'=>false,'message'=>$message));	
		
		
		$dataBuilder->addData(['message' => 'Appointment Notification']);
			
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();
		//print_r($downstreamResponse); die;
		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();

		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();

		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();

		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
		
	}	
	
	
	/*** auto generated call from doctor to users ***/	
	/*public function autoGeneratedCall() {
		
		$appointments  = AppointmentList::where('doctor_id','!=',0)->where('status','1') ->where('appointment_status','new')->where('visit_first',0)->where('call_status',0)->with(['clickToDials','user_detail','doc_detail'])->get();		
		
		foreach($appointments as $key=>$appointment) {
			
			$now		  = strtotime(date('Y-m-d H:i:s'));
			$apointDate   = strtotime($appointment->updated_at);
			
		   if(count($appointment->clickToDials)) {			   			   	   		
				$answeredCall = Dials::where('procedure_id',$appointment->id)->where('doctor_call_status','ANSWERED')->where('user_call_status','ANSWERED')->first();
				if($answeredCall) {
					AppointmentRequest::where('appointment_id',$appointment->id)->delete();
					$appList = AppointmentList::find($appointment->id);
					$appList->call_status = '1';
					$appList->save();
					echo "Lead Done For ". $appointment->id . "<br>";
				} else {
					
					$last = DB::table('items')->latest()->first();
					
					$postData = array(
					'phone_number'   => '',
					'doctor_number'  => '',
					'appointment_id' => '',
					'user_id' 		 => '',					
					'procedure_id'   => '1'
					);

					$url = url().'/api/user/call-detail';
					$ch  = curl_init();
					curl_setopt($ch, CURLOPT_URL, $url);
					curl_setopt($ch, CURLOPT_POST, true);
					curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					$response 	= curl_exec ($ch);
					var_dump($response); die;						
									
				}				
			}
		}
	}*/
		
}
