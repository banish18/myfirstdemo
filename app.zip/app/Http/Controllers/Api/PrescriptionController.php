<?php
namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\AppointmentList;
use App\AppointmentRequest;
use App\CartItem;
use App\ProcedureReview;
use App\Procedure;
use App\DoctorTimeslot;
use App\Doctors;
use App\Product;
use App\SubService;
use App\User;
use App\Orders;
use App\Offer;
use App\UserDetail;
use App\AssistantProcedureRecords;
use App\HairTransplantReport;
use Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;
use File;
use Config;
use DB;
use Image;
use Validator;
use LaravelFCM\Message\Topics;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;
use FCM;

class PrescriptionController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
    
	public $successStatus = 200;
	public $errorStatus = 401;
	
	public function __Construct(REQUEST $request){
		$this->flag = 1;
		$this->languages = Config::get('app.languages');
		if(!in_array($request->lang,$this->languages)){
			$this->flag = 0;
		}
	}
	
	/*
	 * get Prescription
	 * @return Prescription
	 * */
	 
	public function getPrescription(Request $request){
		$validator = Validator::make($request->all(), [ 
			'dr_id'	  			=> 'required', 
			'pt_id'	  		=> 'required', 
			'appointment_id'		=> 'required', 
		]);
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
        }
		$dr_id 			 =  $request->dr_id;
		$pt_id 			 =  $request->pt_id;
		$appointment_id	 =  $request->appointment_id;
		
		$AppointmentList =  AppointmentList::where('id',$appointment_id)->first();
		if($request->assistant_id != "0"){
			$note 			 =  AppointmentList::where('user_id',$pt_id)->where('assistant_ids',$request->assistant_id)->orderBy('updated_at', 'desc')->first();
		}else{
			$note 			 =  AppointmentList::where('user_id',$pt_id)->where('doctor_id',$dr_id)->orderBy('updated_at', 'desc')->first();	
		}
		$noteData = '';
		if($note){
			$noteData = $note->note;
		}
		
		$User 	 		 =  User::where('id',$AppointmentList->user_id)->first();
		$UserDetail 	 =  UserDetail::where('user_id',$AppointmentList->user_id)->first();
		$procedures 	 =  Procedure::where('id',$AppointmentList->procedure_id)->first();
		$offer = NULL;
		if($procedures->offer_apply){
			$offer = Offer::where('id',$procedures->offer_apply)->first();
			$offer = !empty($offer->offer_name_en)?$offer->offer_name_en:'';
		}
		
		$servName = $this->getService($procedures->service);
		
		$HairTransplantReport = HairTransplantReport::find($procedures->report_id);
		$hiaUserName = "";
		$haiAge = "";
		if($HairTransplantReport){
			$hiaUserName = $HairTransplantReport->username;
			$haiAge 	 = $HairTransplantReport->age;
		}
		
		$detail = array('pt_name' => $hiaUserName,'age' => $haiAge,'gender' => $UserDetail->gender, 'customer_number' => $User->customer_number, 'procedures_type' => $servName, 'grafts_required' =>$procedures->required_grafts, 'offer_applied' =>$offer, 'note'=> $noteData, 'medical_condition' => $procedures->medical_condition,'service_id' => $AppointmentList->service_id );
		//Added code to convert null values into empty string
			array_walk_recursive($detail,function(&$item){$item=strval($item);});
		//End
		if(!empty($detail)){
			return response()->json(['status'=>true, 'data' => $detail], $this->successStatus);
			
		}else{
			return response()->json(['status'=>false, 'data' => 'No Data Available'], $this->successStatus);
		}
	}
	 public function getService($id){
		$Service 		= SubService::find($id);
		$serviceName 	= 'N/A';
		if($Service){
			$serviceName = $Service->sub_name_en;
		}
		return $serviceName;
	}
	/*
	 * update Prescription
	 * @return Prescription
	 **/
	 
	public function updatePrescription(Request $request){
		
		$validator = Validator::make($request->all(), [ 
			'dr_id'	  			=> 'required', 
			'pt_id'	  			=> 'required', 
			'appointment_id'	=> 'required',
			'offer_id'			=> 'required', 
		]);
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
        }
		$dr_id 			   =  $request->dr_id;
		$pt_id 			   =  $request->pt_id;
		$appointment_id	   =  $request->appointment_id;
		$grafts_required   =  $request->grafts_required;
		$medical_condition =  $request->medical_condition;
		$offer_id 		   =  $request->offer_id;
		
		$AppointmentList   =  AppointmentList::where('id',$appointment_id)->where('user_id',$pt_id)->where('doctor_id',$dr_id)->first();
		
		$procedures 	   =  Procedure::where('id',$AppointmentList->procedure_id)->first();
		
		if($procedures){
			$order_id = $procedures['order_id'];
			
			$procedures->required_grafts    =  $grafts_required;
			$procedures->medical_condition  =  $medical_condition;
				
			//update offer
			if($procedures->offer_apply != $offer_id) {		
				
				$Package  	     =  Offer::find($offer_id);				
				$paidAmt 		 =  $procedures->advanced_payment;
				$optionDiscount  =  $procedures->option_discount;
				$packageAmt 	 =  $Package->package_price;
				$packageDiscount =  $Package->discount;
				$finalAmount 	 =  $packageAmt-$packageDiscount;
				$pending		 =  $finalAmount - $paidAmt - $optionDiscount;
				$gst_price       = $finalAmount*18/100;
				$procedures->type 			 = 'package';
				$procedures->offer_apply 	 = $offer_id;
				$procedures->required_grafts = $Package->offer_grafts;
				$procedures->gst_price 		 = round($gst_price);
				$procedures->total_payment	 = $finalAmount+round($gst_price);
				$procedures->discount		 = $packageDiscount;
				$procedures->pending_payment = $pending+round($gst_price);
				
				$orders = Orders::find($order_id);
				$orders->total          = $finalAmount+round($gst_price);
				$orders->grand_total    = $finalAmount+round($gst_price);
				$orders->pending_amount = $pending+round($gst_price);
				$orders->save();
					
				
				if($request->assitant_id != "0"){
					/* save entry in the assistant record table if assistant cancel the appointment*/
					$AssistantProcedureRecords 						= new AssistantProcedureRecords;
					$AssistantProcedureRecords->assistant_id 		= $request->assistant_id;
					$AssistantProcedureRecords->procedure_id 		= $AppointmentList->procedure_id;
					$AssistantProcedureRecords->appointment_id 		= $AppointmentList->id;
					$AssistantProcedureRecords->user_id 			= $AppointmentList->user_id;
					$AssistantProcedureRecords->action 				= "update_new_offer";
					$AssistantProcedureRecords->save();
				}		
				
			}else{
			    if($request->assitant_id != "0"){
					/* save entry in the assistant record table if assistant cancel the appointment*/
					$AssistantProcedureRecords 						= new AssistantProcedureRecords;
					$AssistantProcedureRecords->assistant_id 		= $request->assistant_id;
					$AssistantProcedureRecords->procedure_id 		= $AppointmentList->procedure_id;
					$AssistantProcedureRecords->appointment_id 		= $AppointmentList->id;
					$AssistantProcedureRecords->user_id 			= $AppointmentList->user_id;
					$AssistantProcedureRecords->action 				= "update_procedure_precription";
					$AssistantProcedureRecords->save();
				}		
				
			}
			
			$procedures->save();
			
			/* Send notification to the user and doctor */
			if($request->assitant_id != "0"){
				$user = User::find($request->assitant_id);
				if($user && $user->device_token != ""){
					$this->AppointmentNotification($user->device_token);
				}
			}
			if($dr_id != ""){
				$user = User::find($dr_id);
				if($user && $user->device_token != ""){
					//$this->AppointmentNotification($user->device_token);
				}	
			}
			//Added code to convert null values into empty string
				$procedures 	   =  Procedure::where('id',$AppointmentList->procedure_id)->first();
				$detail = array('grafts_required' =>$procedures->required_grafts, 'offer_applied' =>$procedures->offer_apply, 'medical_condition' => $procedures->medical_condition);
				array_walk_recursive($detail,function(&$item){$item=strval($item);});
			//End		
			return response()->json(['status'=>true,'message' => 'Prescription data updated successfully.','data'=>$detail],$this->successStatus);
			
		}else{
			return response()->json(['status'=>false,'message' => 'No data available'],$this->errorStatus);
		}		
	} 
	
	
	
	public function AppointmentNotification($token) 
	{
		$optionBuilder = new OptionsBuilder();
		$optionBuilder->setTimeToLive(60*20);
		$notificationBuilder = new PayloadNotificationBuilder('Kabera');
		$notificationBuilder->setBody('Notification Received')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		//$message1 =  Response::json(array('success'=>false,'message'=>$message));	
		$dataBuilder->addData(['message' => 'Appointment Offer Update Notification']);
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);
		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();
		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();
		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();
		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();
		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
	}
	
}
