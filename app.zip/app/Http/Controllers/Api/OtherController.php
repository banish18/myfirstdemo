<?php
namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use App\Offer;
use App\Contact;
use App\BecomeAPatner;
use App\TalkToExpert;
use Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;
use App\Mail\ContactEmail;
use App\Mail\AdmincontactEmail;
use App\Mail\AdminpartnerEmail;
use App\Mail\ExpertTalkEmail;

class OtherController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
    */
    public $successStatus = 200;
    public $errorStatus   = 401;
    
    /**
     * Create a new function to get offers city wise
     *
     * @return result array
    */
	public function cityOffers(Request $request){
		$CityOffer = Offer::where('is_type','2')->where('city',$request->city)->get()->toArray();
		$result    = array();
		if(!empty($CityOffer)){	
			return response()->json(['status'=>true,'data'=>$CityOffer], $this->successStatus);  
		}else{
			return response()->json(['status'=>false,'data'=>$result], $this->errorStatus);	
		}
	}
	
	/**
     * Create a new function to contact us
     *
     * @return result array
    */
	public function contactUs(Request $request){
		$validator = Validator::make($request->all(), [ 
			'name' 			=> 'required',
			'email' 		=> 'required|email',
			'phone'			=> 'required|min:9|unique:users', 
			'city' 			=> 'required',
			'message' 		=> 'required',
		]);
        if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
        }
		$name 				= $request->input('name');
		$email	 			= $request->input('email');
		$phone 				= $request->input('phone');
		$city 				= $request->input('city');
		$message 			= $request->input('message');
		$super_admin_email 	= env("KABERA_ADMIN_EMAIL");
		/* save data in the database */
		$contact = new Contact;
		$contact->name = $name;
		$contact->email = $email;
		$contact->phone = $phone;
		$contact->city = $city;
		$contact->message = $message;
		$contact->save();
		$data = array('subject' => "Contact us",'from' => env("MAIL_FROM_ADDRESS"), 'name' => $name, 'email' => $email, 'phone' => $phone, 'city' => $city, 'contactmessage' => $message);
		/* Email to user */
		Mail::to($email)->send(new ContactEmail($data));
		/* Email to Admin */
		Mail::to($super_admin_email)->send(new AdmincontactEmail($data));
		return response()->json(['status'=>true,'message'=>'Thank you for your message. It has been sent.'], $this->successStatus); 
	}
	/*
	 * 
	 * Become a member
	 * 
	 * */
	public function becomepatnerContact(Request $request) {
		$validator = Validator::make($request->all(), [ 
			'name' 				=> 'required',
			'email' 			=> 'required|email',
			'phone'				=> 'required|min:9|unique:users', 
			'clinic_address' 	=> 'required',
			'message' 			=> 'required',
		]);
        if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['status'=>false,'message'=>$err], $this->errorStatus);            
        }
		$name 				= $request->input('name');
		$email 				= $request->input('email');
		$phone 				= $request->input('phone');
		$clinic_address 	= $request->input('clinic_address');
		$message 			= $request->input('message');
		$super_admin_email 	= env("KABERA_ADMIN_EMAIL");
		/* save data in the database*/
		$BecomeAPatner 					= new BecomeAPatner;
		$BecomeAPatner->name 			= $name;
		$BecomeAPatner->email 			= $email;
		$BecomeAPatner->phone 			= $phone;
		$BecomeAPatner->clinic_address 	= $clinic_address;
		$BecomeAPatner->description 	= $message;
		$BecomeAPatner->save();
		$data = array('subject' => "Become a partner",'from' => env("MAIL_FROM_ADDRESS"), 'name' => $name, 'email' => $email, 'phone' => $phone, 'clinic_address' => $clinic_address, 'contactmessage' => $message);
		/* Email to partner */
		Mail::to($super_admin_email)->send(new AdminpartnerEmail($data));
		return response()->json(['status'=>true,'message'=>'Thank you for your message. It has been sent.'], $this->successStatus);
	} 
	/*
	 * Function to Talk To Expert
	 * @return redirect to url
	*/	
	public function talkToExpert(Request $request) {
	
		$user_id   			= $request->input('user_id');
		$service   			= $request->input('service');
		$calling_reason 	= $request->input('calling_reason');
		$call_time 			= $request->input('call_time');
		
		$super_admin_email  = env("KABERA_ADMIN_EMAIL");
		$get_user_detail 	= User::where('id', $user_id)->first();
		$username 		    = $get_user_detail->name;
		$useremail 		    = $get_user_detail->email;
		$userphone 		    = $get_user_detail->phone;
		
		$user_detail = array('username' => $username,'useremail' => $useremail,'userphone' => $userphone,'service' => 'hair','calling_reason' => $calling_reason,'call_time' => $call_time);
		
		Mail::to($super_admin_email)->send(new ExpertTalkEmail($user_detail));
		
		$talk_data 					= new TalkToExpert;
		$talk_data->user_id 		=  $user_id;
		$talk_data->service_id 		=  $service;
		$talk_data->reason  		=  $calling_reason;
		$talk_data->available_time 	=  $call_time;
		$talk_data->save();		
		return response()->json(['status'=>true,'message'=>'Thank you for your message. It has been sent.'], $this->successStatus);
	}
}
