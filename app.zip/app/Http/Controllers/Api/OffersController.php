<?php
namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\User;
use App\Role;
use App\RoleUser;
use App\Doctors;
use App\Agent;
use App\ManagerDetail;
use App\DoctorAssistant;
use App\ForgotOtp;
use Auth;
use Validator;
use DateTime;
use DateInterval;
use App\SubService;
use App\Service;
use Illuminate\Support\Facades\Input;
use File;
use App\Offer;
use App\BeforeAfterImage;
use Config;

class OffersController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */
    
    /***
	 * View Assistatnt List API
	*/
	public $successStatus = 200;
	
	public function __Construct(REQUEST $request){
		$this->flag = 1;
		$this->languages = Config::get('app.languages');
		if(!in_array($request->lang,$this->languages)){
			$this->flag = 0;
		}
	}
	
	/*
	 * 
	 * Get Offers list by using service ID
	 * 
	 * */
	
	public function getOfferslist(REQUEST $request) {
		if($this->flag == 1){
			$offersArr   	= []; 
			$alloffersArr   = []; 
			$alloffers 		= Offer::where('services',$request->service_id)->get(['id','offer_name_'.$request->lang.' as title','description_'.$request->lang.' as description','banner_image','expiry_date'])->toArray();
			if($alloffers){
				foreach($alloffers as $offer){
					$offer['grafts'] 	= 'NA';
					$alloffersArr[] 	= $offer; 
					$beforeafterImages 	= BeforeAfterImage::where('service_id',$request->service_id)->get(['before_image','after_image'])->toArray();
					$offer['before_after_images'] = array();
					$offer['discription_1'] = $offer['description']; 
					$offer['discription_2'] = $offer['description'];
					if($beforeafterImages){
						$offer['before_after_images'] = $beforeafterImages;
					}
					$offersArr[] 	    = $offer;
				}
			}
			$dataArray 			= ['offers' => $alloffersArr,'detailOffers' => $offersArr];
			if($dataArray){
				return response()->json(['status'=>true, 'data' => $dataArray], $this->successStatus); 	
			}else{
				return response()->json(['status'=>false, 'data' => 'No Data Available'], $this->successStatus);
			}
		}else{
			return response()->json(['status'=>false, 'data' => 'This Language is not supportable yet!'], $this->successStatus);	
		}
	}
}
