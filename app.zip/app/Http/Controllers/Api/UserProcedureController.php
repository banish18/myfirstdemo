<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;
use App\User;
use App\TempOrder;
use App\FollowUpReminder;
use App\AppoitmentTimeslot;
use App\OrdersDetail as OrderDetail;
use App\UserDetail;
use App\TalkToExpert;
use App\Banner;
use App\emptyCartDetail;
use App\Procedure;
use App\Countries;
use App\State;
use App\Orders as Order;
use App\NoteCommentData;
use App\Cities;
use App\CartItem;
use App\Role;
use App\ProcedureOption;
use App\AppointmentRequest;
use App\RoleUser;
use App\OperationList;
use App\Doctors;
use App\OptionProbability;
use App\Agent;
use App\Offer;
use App\CarryThing;
use App\BeforeAfterReview;
use App\ManagerDetail;
use App\ProcedureOtp;
use App\Page;
use App\Cart;
use App\AppointmentList;
use App\UploadreportData;
use App\DoctorAssistant;
use App\PaymentType;
use App\ForgotOtp;
use App\GraftRate;
use App\SmsApi;
use App\SubService;
use App\Service;
use App\BeforeAfterImage;
use App\ProcedureReview;
use App\GraftOption;
use App\Mail\WelcomeMail;
use App\HairTransplantReport;
use App\Mail\SendOtpMail;
use App\Mail\DoctorProfileAdminApprovalEmail;
use App\Mail\VerifyMail;
use App\Capping;

use Validator;
use Auth;
use DateInterval;
use DateTime;
use File;
use Image;
use DB;
use FCM;
use LaravelFCM\Message\Topics;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;
use Session;
use Firebase\Token\TokenException;
use Firebase\Token\TokenGenerator;


class UserProcedureController extends Controller
{
	
    /**
     * Create a new controller instance.
     *
     * @return void
    */
    public $successStatus = 200;
    public $errorStatus   = 401;

     /***
     * API Add Procedure Detail 
     * @arguments
     * @return response
     ***/ 
    public function addProcedureDetail(Request $request){
		$userId = $request->input('user_id');
		$device_id = $request->input('device_id');
		$data   = $request->all();
		if($userId) {
			// The user is logged in...
			$user   = User::find($userId);		
		} else {		
		$validator = Validator::make($request->all(), [ 
			'email' => 'required|email|unique:users',
			'phone'	=> 'required|min:9|unique:users', 
		]);
		
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['status'=>false,'message'=>$err],  $successStatus = 200 );            
        }
        
         	$password = Str::random(8);
			$user 	  = User::create([
				'customer_number'   => mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999)." ".mt_rand(1000, 9999),
				'name'        		=> $data['name'],
				'email'       		=> $data['email'],
				'phone'       		=> $data['phone'],
				//'password'    		=> Hash::make($password),
				'api_token'   		=> Str::random(60),
				'role'	      		=> '3',
				'isVerified'  		=>  1,
				'email_verified_at' => date("Y-m-d h:i:s")
			]);
			   $user->roles()->attach(Role::where('name', 'user')->first());
			   $UserDetail = new UserDetail;
			   $UserDetail->user_id =  $user->id;
			   $UserDetail->save();
			   $mdata['email']     = $data['email'];
			   $mdata['name']      = $data['name'];
			   Mail::to($data['email'])->send(new WelcomeMail($mdata));
			 		
			}		
		
		if($user) {	
		   $images = array();
		   $HairReport = HairTransplantReport::with(['user','applied_offer'])->where('user_id', $userId)->where('service_id', $data['service_id'])->where('appointment_status', 0 )->first(); 
		   if($HairReport == null) {   
				$HairReport = new HairTransplantReport;
		   } else {
			   if(!empty($HairReport->affected_gallery)) {
				   foreach(explode(",", $HairReport->affected_gallery) as $img) {					   					
						array_push($images , $img);
					}
			   }
		   }
		   
		   $hairPerGraft = 2; //hair per grafts
		   $rate         = env('FUE_GRAFT_RATE'); //default per graft rate
		   $grafts = array(1000,2000,1200,1500,2000,1500,700); //graft values define by kabera statically			 

		   $graftRate     = GraftRate::where('state',$data['state'])->where('city',$data['city'])->first(); 
		   if($graftRate !== null) {
			 $rate = $graftRate->graft_rate;
		   } 	
		   $totalGraft   = 0; 
		 
		   /* New graft calculation */
		   $procedure_stat = 'fix';
		   $graftArea =  preg_replace('/\s+/', '', $data['affected_ids']);
		   if($graftArea == "1,2,3,4"){
			   $totalGraft = "5500";
		   }elseif($graftArea == "1,2"){
			   $totalGraft = "3000";
		   }elseif($graftArea == "1,2,3"){
			   $totalGraft = "4500";
		   }elseif($graftArea == "1,2,3,4,6"){
			   $totalGraft = "5500";
		   }elseif($graftArea == "1,2,3,4,5,6"){
			   $totalGraft = "4000";
		   }elseif($graftArea == "1,2,3,4,5,6,7"){
			   $totalGraft = "2500";
		   }else{
			   $totalGraft = "0";
			   $procedure_stat = 'consult';
		   }
	
		   $sitting	 				      = ($totalGraft/5000 > 1) ? (int)($totalGraft/5000) +1 : 1; //get total sittings		   
		   $totalHair   				  = $totalGraft * $hairPerGraft; 
		   $HairReport->user_id		      = $user->id;
		   $HairReport->affected_ids	  = $graftArea;
		   $HairReport->username		  = $data['name'];
		   $HairReport->total_graft	      = $totalGraft;
		   $HairReport->service_id	      = $data['service_id'];
		   $HairReport->total_hair	      = $totalHair;
		   $HairReport->medical_condition = $data['medical_condition'];
		   $HairReport->age 			  = $data['age'];
		   $HairReport->country 		  = $data['country'];
		   $HairReport->state	 		  = $data['state'];
		   $HairReport->city	 		  = $data['city'];
		   $HairReport->cost_per_graft	  = $rate;
		   $HairReport->total_cost		  = $totalGraft*$rate;
		   $HairReport->sitting		  	  = $sitting;
		   $HairReport->transplant_type	  = 'fue';
		   $HairReport->procedure_stat	  = $procedure_stat;
		   
		   $username = User::find($user->id);
		      $username->device_id = $device_id;
		  // $username->name = $data['name'];
		   $username->save();
		   
		   if(!empty($request->input('affected_gallery'))){			   
				$folder           = 'transplant/';
				foreach(explode(",", $request->input('affected_gallery')) as $image)
				{	
					$random_number 	= mt_rand(100000, 999999);
					$f		        = finfo_open();
					$imgdata        = base64_decode($image);
					$mime_type      = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
					$mime_type      = explode('/',$mime_type);
					$name   		= $folder.'/'.$random_number.'.'.$mime_type[1];  
					$imagess = File::put(public_path().'/images/'.$name, base64_decode($image));       
					array_push($images , $name);
				}
			}			
			$HairReport->affected_gallery = implode(",",$images);			
			
			if($HairReport){
			
			$HairReport->save();	
			$time 	 = new DateTime(date('Y-m-d H:i:s'));
			$time->add(new DateInterval('PT5M'));
			$expTime = $time->format('Y-m-d H:i:s');
			$OTP     =  mt_rand(100000, 999999);
			
			$ProcedureOtp  = ProcedureOtp::firstOrNew(['phone'=>$user->phone]);
			$ProcedureOtp->phone  =  $user->phone;
			$ProcedureOtp->otp 	  =  $OTP;
			$ProcedureOtp->expired_at = $expTime;							
			$ProcedureOtp->save();
			$message	 = "<#> Welcome to Kabera Gloabal. Please use this otp to proceed your procedure. (".$OTP .")".env('APP_MSG_CODE');
			$phone = $user->phone;
			$SmsApi 	 =  new SmsApi();
			
			if($SmsApi->sendSMS($phone , $message)) {
				
				$loginData = array('email'=>$user->email,'phone'=>$user->phone,'name'=>$user->name);
				
				return Response::json(array('status'=>true,'otp'=>$OTP, 'user_id' =>$HairReport->user_id , 'phone'=> $ProcedureOtp->phone ,'report_id'=>$HairReport->id, 'message'=>'OTP Send Successfully','data'=>$loginData),$successStatus = 200 ); //remove otp key when site will be live
			} else {
				return Response::json(array('status'=>false,'message'=>'Error Occured'));			
			}
			
			}else{
			return Response::json(array('status'=>false,'message'=>'Some Error Occured'));	
			}
		
		}
		
	}
	
	
	public function userProdedureOtpMatch(Request $request) {
	
		$phone        = $request->input('phone');
		$type     	  = '3';
		$otp          = $request->input('otp');
        $verifyUser	  = ProcedureOtp::where('phone', $phone)->first();
        if(isset($verifyUser) ) {
			$user   = $verifyUser->user;
		
			$d1 = new DateTime(date('Y-m-d H:i:s'));
			$d2 = new DateTime($verifyUser->expired_at);
			
			if($verifyUser->otp == $request->input('otp') && $d1 <= $d2) {					
				//Auth:loginUsingId($user->id);	
				return Response::json(array('status'=>true, 'message'=>'Login Successfully')); 									
			}else if($verifyUser->otp == $request->input('otp') && $d1 > $d2) {
				
				return Response::json(array('status'=>false, 'message'=>'Sorry! This OTP is expired. Please try again.')); 
					
			} else {
				
				return Response::json(array('status'=>false, 'message'=>'Sorry! OTP Not Match, Please Try Again'));
				
			}
                
        }else{
			
				return Response::json(array('status'=>false, 'message'=>'Sorry! Phone number Not Match, Please Try Again'));
			}
	
		}
		
		
		
		public function CountryStateList(Request $request) 
		{
			
			$countries      = $request->input('name');
			$StateId      = $request->input('state');
			$CountriesId	  = Countries::where('name', $countries)->first();
			
			if(!empty($CountriesId) && empty($StateId) ){
			$state = DB::table('states')->select('*')->where('country_id', $CountriesId->id)->get();
			
			foreach($state as $stateList){
				
				$states = $state;
				
				}
			
				if(!empty($state)) {
					
					return Response::json(array('status'=>true, 'data'=> $states , $successStatus = 200 )); 
				} else {
					return Response::json(array('status'=>false,'message'=>'Error Occured'));			
				}
				
				
			}else if(!empty($StateId)  && !empty($CountriesId) ){
				$state = DB::table('states')->select('*')->where('country_id', $CountriesId->id)->where('name', $StateId)->get();	
				$state_id = $state[0]->id;
				$cities	  = Cities::where('state_id', $state_id)->get();
				
				foreach($cities as $cityList){
					$city = $cities;
					}
			
				if(!empty($city)) {
					return Response::json(array('status'=>true, 'data'=> $city , $successStatus = 200 )); 
					} else {
						return Response::json(array('status'=>false,'message'=>'Error Occured'));			
					}
			
			}
			
		}	
		
		/* API to get Offer list for Hair transplant
		 * @return response 
		*/
		public function ProcedureReportList(Request $request) 
		{
			$id = $request->input('user_id');
			//$service_id = $request->input('service_id');
			$report_id  = $request->input('report_id');
			$report     = HairTransplantReport::with(['user','applied_offer'])->find($report_id);			
			$breakDown  = '';
			if($report) {
				$services  = 2; // 2 is an id, for hair transplant
				if($report[0]['sitting'] >= 1) {			
					$endBreakDown = $report->total_graft - (5000 * ($report->sitting - 1));
					
					for($i=1; $i<=$report->sitting; $i++ ) {
						if($i == $report->sitting ) {
							$breakDown .= "Sitting ".$i." ".$endBreakDown;
						} else {
							$breakDown .= " Sitting ".$i." 5000 "; 	
						}		
					}
					
				}
			//print_r($report); 
			 $countZones = count(explode(",",$report->affected_ids));
				//	print_r($countZones); die;

			 $damage    = 14.2857 * $countZones;
			 $healthy   = 100 - $damage; 
			
			$region     = $report->city;				
			$offers     = Offer::where('services',$services)->get();
			$cityOffers = [];
				foreach($offers as $key=>$offer) {
				  if($offer->city) {
				
						if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) {	// get offers for city spceific					
							$cityOffers[] = $offer;
						}
					} else {
						$cityOffers[] = $offer;
						
					}
				}	
				
			$offers	   = $cityOffers;
			$images    = BeforeAfterImage::where('service_id',2)->get();
			
			$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
			$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
			$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
			
			$percentage = 0;
			if($count){
				$percentage 	   =  array();		
				for($i=1; $i<=5; $i++ ){
					$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
						$x = $rats;
						$total = $count;
						$percentage[$i] = ($x*100)/$total;
				}
			}	
			
			/* graft distribution data */
			$graftArea = $report->affected_ids;
			if($graftArea == "1,2,3,4"){
			   $graftOption = "option1";
			}elseif($graftArea == "1,2,3,4,6"){
			   $graftOption = "option2";
			}elseif($graftArea == "1,2,3,4,5,6"){
			   $graftOption = "option3";
			}elseif($graftArea == "1,2,3,4,5,6,7"){
			   $graftOption = "option4";
			}elseif($graftArea == "1,2"){
			   $graftOption = "option5";
			}elseif($graftArea == "1,2,3"){
			   $graftOption = "option6";
			}else{
				$graftOption = "";
			}
			
			$GraftOptions 		=  GraftOption::where('option_type',$graftOption)->get();
			
			/* get offer code start here.. */
			if(!$GraftOptions->isEmpty()){
				$required_graft = $GraftOptions[0]->grafts;
				$graft_array    = explode('-', $required_graft);
				$min_graft      = $graft_array[0];
				$max_graft      = $graft_array[1];
			}else{
				$required_graft = "0";	
				$min_graft = "0";
				$max_graft = "0";
			}
						
			$relevent_offer = Offer::where('services',$services)->whereBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->get();			
			$inrelevent_offer = Offer::where('services',$services)->whereNotBetween('offer_grafts', array($min_graft, $max_graft))->orderBy('offer_grafts', 'desc')->get();
						
			$OptionProbability  =  OptionProbability::where('option_type',$graftOption)->get();
			$mergeOffers        =  array();
			
			foreach($relevent_offer as $key=>$offer ) {
				$mergeOffers[] = $offer;				
			}
			
			foreach($inrelevent_offer as $key=>$offer ) {
				$mergeOffers[] = $offer;				
			}
					
			return Response::json(array('status'=>true, 'report'=>$report ,  'offers'=>$mergeOffers, 'images'=>$images ,  'breakDown'=>$breakDown ,  'reviews'=>$reviews , 'damage'=> $damage , 'healthy'=>$healthy , 'GraftOptions'=> $GraftOptions , 'OptionProbability'=> $OptionProbability , 'min_graft'=> $min_graft, 'max_graft'=> $max_graft ,  'avrage'=>$avrage ,  'percentage'=>$percentage , 'message'=>'success'), $this->successStatus); 
			} else {
				return Response::json(array('status'=>false, 'message'=>'No Data Available.'), $this->successStatus); 
			}
		
		}
		
		
		
	public function fixAppointmentProcedure(Request $request){
		
		$validator = Validator::make($request->all(), [             
				//'user_id'     => 'required',  
				'id' => 'required',  
				'procedure_id' => 'required',  
				'appointment_date' => 'required',  
				'appointment_time' => 'required',  
				'city' => 'required',  
			]);
			
			
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
			return response()->json(['error'=>$err], $this->successStatus);            
		} 
		
			
		 $user_id = $request->input('user_id');
		 $id = $request->input('id');
		 $procedureid = $request->input('procedure_id');
		 $appointment_date = $request->input('appointment_date');
		 $appointment_time = $request->input('appointment_time');
		 $currentcity = $request->input('city');
			 
		 $user = User::where('id', $id)->with('userDetail')->first();
		 $procedure = Procedure::where('id',$procedureid)->first();		
		 $appointmentDate 			= date('Y-m-d',strtotime($appointment_date));
		 $appointmentTime 			= explode("-",$appointment_time);
		 $appointmentFromDatetime 	= $appointmentDate.' '.$appointmentTime[0];
		 $appointmentToDatetime 	= $appointmentDate.' '.$appointmentTime[1];
		 $city 						= $currentcity;
		 $apiKey                    = env('GOOGLE_API_KEY');
		 $country                   = "India";
		
		
		//print_r($appointmentFromDatetime); die;
		if(isset($currentcity) && $currentcity == "1"){
			/*$user_ip 	= $_SERVER['REMOTE_ADDR'];
			$geo 		= unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=".$user_ip.".key=".$apiKey));
			$country 	= $geo["geoplugin_countryName"];*/
			$city 		= 'Mohali';
		}
		
		$url = "https://maps.google.com/maps/api/geocode/json?address=".preg_replace('/\s+/', '+', $city)."&sensor=false&region=".$country."&key=".$apiKey;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		$response = curl_exec($ch);
		
		curl_close($ch);		
		$response = json_decode($response);
		if(!empty($response->results)){
			$latitude  = $response->results[0]->geometry->location->lat;
			$longitude = $response->results[0]->geometry->location->lng;
		}else{
			return response()->json(['success'=>true, 'message' => 'Your location are not found!'], $this->successStatus);	
		}
		
		if(empty($user->id) ){
			return response()->json(['success'=>false,'message' => 'User not exist']); 					
		}
		
		$service_id 				= $procedure->service;
		$user_id 					= $user->id;
		$timeSlot               	= date('H:i a',strtotime($appointmentFromDatetime));
		/* Check if same user id,service_id and status=0 are exists or not */
		$AppointmentList 			= AppointmentList::where('user_id',$user_id)->where('service_id',$service_id)->where('status','0')->where('procedure_id',$request->procedure_id)->first();
		//~ if($AppointmentList){
			//~ return response()->json(['success'=>true, 'message' => 'Your request has been under doctor confirmation. We will update you soon!'], $this->successStatus);
		//~ }
		/* Get clinic details which comes under 5 km of user's current location */
		$clinicDetails        	= Doctors::select(DB::raw('id,user_id,clinic_name,clinic_address,clinic_name,clinic_name,clinic_name,sub_skills, ( 6367 * acos( cos( radians('.$latitude.') ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians('.$longitude.') ) + sin( radians('.$latitude.') ) * sin( radians( latitude ) ) ) ) AS distance'))
			->having('distance', '<', 100)
			->orderBy('distance')
			->with('user')
			->where('skills', 'like', '%1%')->get()->toArray();	
		if(!empty($clinicDetails)){
			$AppointmentList = new AppointmentList;
			$AppointmentList->user_id 			= $user->id;
			$AppointmentList->doctor_id 		= '0';
			$AppointmentList->service_id 		= $service_id;
			$AppointmentList->procedure_id 		= $request->procedure_id;
			$AppointmentList->appointment_status 	= "new";
			$AppointmentList->appointment_date 	= $appointmentFromDatetime;
			$AppointmentList->appointment_to_date 	= $appointmentToDatetime;
			$AppointmentList->save();
			
			
			foreach($clinicDetails as $clinicDetail){
				
			  $skills = ($clinicDetail['sub_skills']) ? json_decode($clinicDetail['sub_skills']) : array();
			    if($clinicDetail['user']['isVerified'] == 1  && in_array($service_id, $skills) ) {
					$AppointmentRequest 				= new AppointmentRequest;
					$AppointmentRequest->appointment_id = $AppointmentList->id;
					$AppointmentRequest->doctor_id 		= $clinicDetail['user_id'];
					$AppointmentRequest->service_id 	= $service_id;
					$AppointmentRequest->request_date 	= $appointmentFromDatetime;
					$AppointmentRequest->request_time 	= date('H:I A',strtotime($appointmentFromDatetime));
					$AppointmentRequest->save();
					$service = new Doctors;
					$serviceA = $service->service($service_id);
					$serviceName = 'N/A';
					if(!empty($serviceA)){
						$serviceName = $serviceA->service_name;
					}
					/* appointment request email to all doctors whoese under distance */
					$email = $clinicDetail['user']['email'];
					//$email = "dottechnologies123@gmail.com";
					$name  = $clinicDetail['user']['name'];
					$link  = url('/').'/api/user/confirm-request/'.$AppointmentRequest->id;
					$fromEmail = env('MAIL_FROM_ADDRESS');
					$data = array(
							'name'		=> $name,
							'service' 	=> $serviceName,
							'date' 		=> $appointmentDate,
							'time' 		=> $timeSlot,
							'email' 	=> $email,
							'from' 		=> $fromEmail,
							'link' 		=> $link
							);
					
					
					
					Mail::send('requestMail', $data, function($message) use ($data) {
							$message->to($data['email'], 'KABERA')->subject
							('Customer Appointment Request');
							$message->from($data['from'],'Kabera');
						});
					$users 		= User::where('id',$clinicDetail['user_id'])->first();
					if($users){
						$device_token = $users->device_token;
						if($device_token != ""){
							$this->AppointmentNotification($device_token);	
						}
						
					$assistantt = DoctorAssistant::with(array('user' => function($q){ 
						 $q->select('id','name','email', 'phone','added_by','request_recieve_per_day','device_token');
					}))->where('doctor_id', $clinicDetail['user_id'])->get();
						
							foreach($assistantt as $assistants){
								if($assistants->user->device_token != ''){								
									$device_token = $assistants->user->device_token;
									//print_r($device_token);  die;
									$this->AppointmentNotification($device_token);
								
								} 
						}
					}					
			    }		
			}
			
				//$this->AppointmentNotificationUserApp($device_id);	
				
			return response()->json(['success'=>true,'AppointmentList'=>$AppointmentList , 'message' => 'Your request has been submitted. We will update you soon!']); 					
		}else{
			return response()->json(['success'=>false, 'message' => 'No doctors are found on this location.'], $this->successStatus);
		}
	}
	
	
	public function AppointmentNotification($token) 
	{
		
		$optionBuilder = new OptionsBuilder();
		
		$optionBuilder->setTimeToLive(60*20);
		
		$notificationBuilder = new PayloadNotificationBuilder('Kabera');
		$notificationBuilder->setBody('You have received a new user Appointment Notification')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		
		//$message1 =  Response::json(array('success'=>false,'message'=>$message));	
		
		
		$dataBuilder->addData(['message' => 'Appointment Notification']);
			
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();
		//print_r($downstreamResponse); die;
		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();

		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();

		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();

		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
		
	}	
		
	public function Visitproceduredetail(Request $request){
		$id      = $request->input('id');
		$type    = $request->input('type');
		$user_id = $request->input('user_id');
		//$user_id = $request->input('id');
		
		$procedure = Procedure::with(['Offer','paymentOption'])->find($id); 
		$packages  = Offer::where('offer_type','package')->get();
		
		$Offers    = Offer::where('id',$procedure->offer_apply)->get();
		
		$procedureId 		= $id;
		$user               = User::find($user_id);
		if($procedure){
			$track_status = $procedure->track_status; 
			$paymentTypes  = PaymentType::where('procedure_id',$procedureId)->get();
			$cash_payment   = 0;
			$online_payment = 0;
			if(!$paymentTypes->isEmpty()){
				foreach($paymentTypes as $paymentType){
					if($paymentType->payment_type == "cash"){
						$cash_payment   += $paymentType->amount;
					}else{
						$online_payment += $paymentType->amount;
					}
				}	
			}
			
			if($type == 'visit'){
					$CarryThing 		= CarryThing::where('carry_type','visit_doctor')->where('sub_service_id',$procedure->service)->first();
					$AppointmentLists 	= AppointmentList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$procedureId)->with('serviceDetail')->with('doctorDetail')->orderBy('appointment_date', 'asc')->get();
					$comments_data  = [];
					$comments_data  = NoteCommentData::with('doc_detail','doc_image')->where('visible_to',1)->where('procedure_id',$procedureId)->where('type','note')->orderby('id','desc')->get();
					$OperationList  = OperationList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$id)->first();
					
			
				if(!empty($AppointmentLists)){
				return Response::json(array('status'=>true,'AppointmentLists'=>$AppointmentLists, 'procedureId' =>$procedureId, 'procedure'=> $procedure , 'CarryThing' =>$CarryThing , 'comments_data' =>$comments_data , 'OperationList' =>$OperationList ,$successStatus = 200 ));					
				}else{
					return response()->json(['success'=>false, 'message' => 'No doctors are found on this location.'], $this->successStatus);
				}
				
				
					
			}else if($type == "detail"){
				$CarryThing 		= CarryThing::where('carry_type','procedure')->where('sub_service_id',$procedure->service)->first();
				$AppointmentList 	= AppointmentList::where('user_id',$user->id)->where('status','1')->with('serviceDetail')->with('doctorDetail')->first();
				$OperationList 		= OperationList::where("user_id", $user->id)->where('procedure_id',$procedureId)->with('subserviceDetail')->with('doctorDetail')->first();	
				$getOperationdate   = OperationList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$procedureId)->first();
				
				$apt_detail = AppointmentList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$procedureId)->with('serviceDetail')->with('doctorDetail')->get();
				
				
				$comments_data  = NoteCommentData::with('doc_detail','doc_image')->where('user_id',$user->id)->where('visible_to',1)->where('procedure_id',$procedureId)->where('type','note')->orderby('id','desc')->get();
				//return return View('user.procedure/detail',compact(['AppointmentList','procedureId','CarryThing','OperationList','comments_data','apt_detail','procedure','getOperationdate']));
				if(!empty($AppointmentList)){
				return Response::json(array('status'=>true,'AppointmentList'=>$AppointmentList, 'procedureId' =>$procedureId, 'procedure'=> $procedure , 'CarryThing' =>$CarryThing , 'comments_data' =>$comments_data , 'OperationList' =>$OperationList , 'apt_detail' =>$apt_detail , 'procedure' => $procedure ,  'getOperationdate' =>$getOperationdate ,$successStatus = 200 ));					
				}else{
					return response()->json(['success'=>false, 'message' => 'somthing went wrong'], $this->successStatus);
				}
				
			}else if($type == "followup"){
				$AppointmentList = AppointmentList::where('user_id',$user->id)->where('status','1')->with('serviceDetail')->with('doctorDetail')->first();
				$OperationList   = OperationList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$id)->first();
				$current_user_id = $user->id;
			
				$user_opertion_record = OperationList::where('user_id', $current_user_id)->where('procedure_id',$procedureId)->where("status","1")->first();
		
				if(count($user_opertion_record) != 0)
				{
					$opr_date = $user_opertion_record->operation_date;
					$date = date('Y-m-d', strtotime($opr_date));
					
					$service_id = $user_opertion_record->service_id;
					$reminders_data =  FollowUpReminder::where('sub_service_id',$service_id)->get();
					
					if(count($reminders_data) != 0)
					{
						$reminders =  $reminders_data;
					}else{
						$reminders = [];
					}
				} else {
					$reminders = [];
					$date = "";
				}
				
				
				if(!empty($AppointmentList)){
				return Response::json(array('status'=>true,'AppointmentList'=>$AppointmentList, 'procedureId' =>$procedureId, 'date'=> $date , 'user_opertion_record' =>$user_opertion_record , 'reminders' =>$reminders , 'OperationList' =>$OperationList , 'procedureId' =>$procedureId , 'OperationList' => $OperationList ,$successStatus = 200 ));					
				}else{
					return response()->json(['success'=>false, 'message' => 'somthing went wrong'], $this->successStatus);
				}
				
			}else if($type == "payment"){
				$AppointmentList = AppointmentList::where('user_id',$user->id)->where('status','1')->with(['serviceDetail','doctorDetail'])->first();			
				//echo "<pre>"; print_r($AppointmentList); die;		
				$OperationList   = OperationList::where('user_id',$user->id)->where('status','1')->where('procedure_id',$id)->first();
				$service_id = $procedure['service'];
				$services_image   =  SubService::where('id', $service_id)->first();

				
				if(!empty($AppointmentList)){
				return Response::json(array('status'=>true,'AppointmentList'=>$AppointmentList, 'procedureId' =>$procedureId, 'procedure'=> $procedure , 'cash_payment' =>$cash_payment , 'online_payment' =>$online_payment , 'OperationList' =>$OperationList , 'procedureId' =>$procedureId , 'OperationList' => $OperationList , 'services_banner'=>$services_image , 'packages' => $packages ,$successStatus = 200 ));					
				}else{
					return response()->json(['success'=>false, 'message' => 'somthing went wrong'], $this->successStatus);
				}
				
			}			
			
		}else{
			
			return response()->json(['success'=>false, 'message' => 'Procedure are no longer with this user.'], $this->successStatus);
			
		}
	}
	
	
	
	
	public function updateAppointmentdate(Request $request){	       	
		$user_id             		= $request->input('user_id'); 	
		$appointment_id             = $request->input('appointment_id'); 		
		$appointment_date           = $request->input('appointment_date'); 			
		$appointment_time           = $request->input('appointment_time'); 			
		$appointmentDate 			= date('Y-m-d',strtotime($appointment_date));
		$appointmentTime 			= explode("-",$appointment_time);
		$appointmentFromDatetime 	= $appointmentDate.' '.$appointmentTime[0];
		$appointmentToDatetime 		= $appointmentDate.' '.$appointmentTime[1];
		$timeSlot               	= date('H:i a',strtotime($appointmentFromDatetime));
	
		if($appointment_id){
			$AppointmentList 			= AppointmentList::find($appointment_id);
			$AppointmentList->appointment_date 	= $appointmentFromDatetime;
			$AppointmentList->appointment_to_date 	= $appointmentToDatetime;
			$AppointmentList->save();			
			$users 		= User::where('id',$user_id)->first();
	
			$device_token = $users->device_id;
			
			if(!empty($device_token)){
				$this->AppointmentChangeUserApp($device_token);
			}	
				
			return response()->json(['success'=>true,'message' => 'Your Appointment updated succesfully ']); 					
		}else{
			return response()->json(['success'=>false, 'message' => 'Error in updation.'], $this->successStatus);
		}
	}
	
	
	public function skinProcedureDetail(Request $request) {
		$service_id   = $request->input('service_id');
		
		$countoffers  = Offer::where('services',$service_id)->count();
		//$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$offers     = Offer::where('services',$service_id)->paginate(4);
		
		$services   =  SubService::where('service_id', $service_id)->get();
		$procedure  =  Page::where('template','Skin Procedure')->where('data_type','skin-procdeure-data')->first();
		
		$data 		 =  array('banner_image'=>'', 'procedure_en'=>'', 'procedure_fr'=>'');
		if($procedure !== null) {
			$procedureData         = $procedure->content_en;
			$procedureDatafr       = $procedure->content_fr;
			$extraData             = json_decode($procedure->extras_en);
			$data['banner_image']  = $extraData->banner;
			$data['procedure_en']  = $procedureData;
			$data['procedure_fr']  = $procedureDatafr;	
			$data['first_offer']   = Banner::find(json_decode($procedureData)->first_banner);	
			$data['second_offer']  = Banner::find(json_decode($procedureData)->second_banner);		
		 }
		
		$images    = BeforeAfterImage::where('service_id',$service_id)->get();
		$bareviews = BeforeAfterReview::where('service_id',$service_id)->where('review_status','1')->get();
		$countoffers  = Offer::where('services',$service_id)->count();
		$reviews   = ProcedureReview::where('review_status','=','1')->where('service_id',1)->limit(5)->get();
		$count     = ProcedureReview::where('review_status','=','1')->where('service_id',1)->count();
		$avrage    = ProcedureReview::where('service_id',1)->avg('rating');
		
		$percentage = 0;
		if($count){
			$percentage 	   =  array();		
			for($i=1; $i<=5; $i++ ){
				$rats  = ProcedureReview::where('review_status','=','1')->where('service_id',1)->where('rating','=',$i)->count();
					$x = $rats;
					$total = $count;
					$percentage[$i] = ($x*100)/$total;
			}
		}		
		$countries = Countries::all();	
		
		$cityOffers = [];
		foreach($offers as $key=>$offer) {
		  if($offer->city) {
		
				if(($offer->is_type == '2')  && (in_array($region,explode(",", $offer->city)))) { // get offers for city spceific					
					$cityOffers[] = $offer;
				}
			} else {
				$cityOffers[] = $offer;
				
			}
		}	
		$offers	   = $cityOffers;
				
		$skip      = 4;
		if(!empty($procedure)){
				return Response::json(array('status'=>true,'services'=>$services, 'countoffers' =>$countoffers, 'service_id'=> $service_id , 'images' =>$images , 'data' =>$data , 'bareviews' =>$bareviews , 'reviews' =>$reviews , 'count' => $count , 'avrage' => $avrage , 'percentage' => $percentage , 'offers' => $offers , 'skip' => $skip ,$successStatus = 200 ));					
				}else{
					return response()->json(['success'=>false, 'message' => 'somthing went wrong'], $this->successStatus);
				}
		
	}
	
	
	
	
	
	
	public function PaymentPassbookDetail()
	{
		
		$var = PaymentType::with('userPayment')->get();
		
		if(!empty($var)){
		
			return Response::json(array('status'=>true,'paymentPassbook'=>$var ,$successStatus = 200 ));					
			}else{
				return response()->json(['success'=>false, 'message' => 'somthing went wrong'], $this->successStatus);
			}
		
		
	}
	
	public function updateProfileDetail(Request $request){
		$id = $request->input('user_id');
		$user = User::where('id', $id)->with('userDetail')->first();
		//echo $id; die;
        $user->name      	= $request->input('name');
        $user->email      	= $request->input('email');
        $user->phone      	= $request->input('phone');
		$user->save();
        $userDetail = UserDetail::where('user_id',$user->id)->first();
        if($userDetail){
			$userDetail->address   = $request->input('address');
			$userDetail->city      = $request->input('city');
			$userDetail->state     = $request->input('state');
			$userDetail->country   = $request->input('country');
			$userDetail->post_code = $request->input('post_code');  
			//die($request->input('age'));
			$userDetail->age = $request->input('age');
			$userDetail->gender = $request->input('gender');
			
			$image	 = $request->input('profile_picture');//"/var/www/html/kaberaUserController.php on line 960/public/images/pages/610246banner-image-2.png";
			$folder  		= 'patient/';
			$random_number 	= mt_rand(100000, 999999);
			$f		        = finfo_open();
			$imgdata        = base64_decode($image);
			$mime_type      = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
			$mime_type      = explode('/',$mime_type);
			$imgName	 	= $folder.$random_number.'.'.$mime_type[1];  
			$imagess 		= File::put(public_path().'/images/'.$imgName, base64_decode($image));   
			$userDetail->profile_picture = $imgName;			
			$userDetail->save();
		}
		
		if(!empty($userDetail)){
		
		return Response::json(array('status'=>true,'profile'=>'Update successfully' ),$successStatus = 200 );					
			}else{
				return response()->json(['success'=>false, 'message' => 'somthing went wrong'], $this->successStatus);
			}
	}
	
	
	
	public function getProfileDetail(Request $request){
		$id = $request->input('user_id');
		$user = User::where('id', $id)->with('userDetail')->first();
		
		if(!empty($user)){
		
		return Response::json(array('status'=>true,'profile'=>$user ),$successStatus = 200 );					
			}else{
				return response()->json(['success'=>false, 'message' => 'somthing went wrong'], $this->successStatus);
			}
		
	}
	
	
	
	public function userOrdersDetail(Request $request) {
		
		$id = $request->input('user_id');
		
		
		$orders = Order::where('user_id',$id)->with('user')->with('OrderDetails')->with('orderStatus')->orderBy('id','desc')->get();
		
		if(!empty($orders)){		
			return Response::json(array('status'=>true,'profile'=>$orders ),$successStatus = 200 );					
		}else{
			return response()->json(['success'=>false, 'message' => 'somthing went wrong'], $this->successStatus);
		}
	}
	
	
	
	public function viewOrderDetail(Request $request) {
		
		
		$id = $request->input('user_id');
		$order 			= Order::where('user_id',$id)->with('user')->with('OrderDetails')->with('orderComments')->with('orderStatus')->first();	
		
		$orderid = $order['id'];
			
		$orderProducts 		= OrderDetail::where('order_id',$orderid)->where('product_type','product')->with('productDetails')->get();
		$orderProcedure 	= OrderDetail::where('order_id',$orderid)->where('product_type','procedure')->with('procedureDetails')->get();
			
		if(!empty($orderProcedure) ){
		return Response::json(array('status'=>true,'order'=>$order , 'orderProducts'=> $orderProducts , 'orderProcedure'=>$orderProcedure ,$successStatus = 200 ));					
			}else{
				return response()->json(['success'=>false, 'message' => 'somthing went wrong'], $this->successStatus);
			}
			
		
	}
	
	/** Add To Cart API
	 * @return response
	*/
	public function addToCartPackage(Request $request)
    {	
		$user_id 		    = $request->input('user_id');	
		$data				= $request->all();
		
		$offer_id	 		= $data['offer_id'];
		$user_id 			= $user_id;
		$is_type 			= 'package';
		$Option				= ProcedureOption::find($data['option']);
		$Offer 				= Offer::with('subService')->find($offer_id);
		$gst_rate           = env('GST_RATE');
		
		if($Offer) {
			
			$packagePrice		= $Offer->package_price;
			$afterdiscountPrice = $Offer->package_price - $Offer->discount;
			$totaldiscount		= $Offer->discount;		
			$gstPrice			= floor(($afterdiscountPrice * $gst_rate)/100);
			$totalCost		   	= floor($afterdiscountPrice + ($afterdiscountPrice * $gst_rate)/100) ;
			$finalcost		   	= $totalCost;
			
			if($Option->discount_type == 'p') {
				$finalcost      =  ($finalcost * $Option->total_coast)/100;
				$optionDiscount	=  ($totalCost * $Option->discount)/100;
			 } else {				 
				$finalcost      =  $Option->total_coast;
				$optionDiscount	=  $Option->discount;
			 }		 
			$balance			= $totalCost - $finalcost;		
									
			$cart = Cart::where('user_id',$user_id)->first();        
			if(!$cart) {
				$cart = new Cart;
				$cart->user_id 			= $user_id;
				$cart->quantity_total 	= 1;
				$cart->save();
				/*** Add cart items entry ***/   
				$CartItem = new CartItem;
				$CartItem->cart_id 			= $cart->id;
				$CartItem->product_id 		= $offer_id;
				$CartItem->report_id 		= $request->report_id;
				$CartItem->product_price 	= $Offer->package_price;
				$CartItem->discount 		= 0;
				$CartItem->offer_discount 	= $totaldiscount;
				$CartItem->option_discount 	= $optionDiscount;
				$CartItem->total_price 		= $finalcost;
				$CartItem->gst_price 		= $gstPrice;
				$CartItem->quantity 		= 1;
				$CartItem->note 			= $data['note'];
				$CartItem->is_type 			= $is_type;
				$CartItem->payment_option   = $data['option'];
				
				// print_r($CartItem); 
				
				$CartItem->save();
			  
				/* Update Cart values */
				$cart = Cart::where('user_id',$user_id)->first();
				$cart->raw_total 	  		= $CartItem->total_price;
				$cart->discount_total 		= $CartItem->discount;
				$cart->grand_total    		= $CartItem->total_price;
				$cart->save();
				
				$payment['procedure_cost'] = $Offer->package_price;
				$payment['gst'] 	       = $gstPrice;
				$payment['total_cost']     = $totalCost;
				$payment['balance']        = $balance;
				$payment['payment']        = $finalcost;
						
				return Response::json(array('status'=>true,'message'=>'Procedure added to cart successfully','cart_quantity' => $cart->quantity_total, 'payment'=>$payment));
			} else {
				
				//echo $cart->id; die;
				
				$CartItem 	= CartItem::where('product_id',$offer_id)->where('cart_id',$cart->id)->first();
				if(!$CartItem){
					
						$CartItem = new CartItem;
						$CartItem->cart_id 			= $cart->id;
						$CartItem->product_id 		= $offer_id;
						$CartItem->report_id 		= $request->report_id;
						$CartItem->product_price 	= $Offer->package_price;
						$CartItem->discount 		= 0;
						$CartItem->offer_discount 	= $totaldiscount;
						$CartItem->option_discount 	= $optionDiscount;
						$CartItem->total_price 		= $finalcost;
						$CartItem->gst_price 		= $gstPrice;
						$CartItem->quantity 		= 1;
						$CartItem->is_type 			= $is_type;
					 	$CartItem->note 			= $data['note'];
						$CartItem->payment_option   = $data['option'];
						$CartItem->save();
						/* Update Cart values */
						$cartSum                    = CartItem::where('cart_id',$cart->id)->sum('total_price');
						$cartQtySum                 = CartItem::where('cart_id',$cart->id)->sum('quantity');
						$cartDicSum                 = CartItem::where('cart_id',$cart->id)->sum('discount');
						$cart->quantity_total 	  	= $cartQtySum;
						$cart->raw_total 	  		= $cartSum;
						$cart->discount_total 		= $cartDicSum;
						$cart->grand_total    		= $cartSum-$cartDicSum;					
						$cart->save();
						
						$payment['procedure_cost'] = $Offer->package_price;
						$payment['gst'] 	       = $gstPrice;
						$payment['total_cost']     = $totalCost;
						$payment['balance']        = $balance;
						$payment['payment']        = $finalcost;
												
						return Response::json(array('status'=>true,'message'=>'Procedure added to cart successfully','cart_quantity' => $cart->quantity_total,'payment'=>$payment));	
					
				}else{
						return Response::json(array('status'=>false,'message'=>'Procedure already added in cart'));			
				}
			  }
        } else {			
			return Response::json(array('status'=>false,'message'=>'Offer Id Invalid'));	
		}
    }
    
     /*
     * Function to change option price on package 
     * @return response
    */
    
    public function changeOptionPrice(Request $request) {
		
		$optionId 		    =  $request->option_id;
		$offer_id 		    =  $request->offer_id;
		$is_type 			=  $request->is_type;
		$gst_rate			=  env('GST_RATE');
		
		$Option				= ProcedureOption::find($optionId);
		if($Option == null) {
			return Response::json(array('status'=>false,'message'=>'Invalid Option'));
		}
		$Offer 				= Offer::with('subService')->find($offer_id);
		if($Offer) {
			if($is_type == 'package') {
				$packagePrice		= $Offer->package_price;
				$afterdiscountPrice = $Offer->package_price - $Offer->discount;
				$totaldiscount		= $Offer->discount;		
				$totalCost		   	= floor($afterdiscountPrice + ($afterdiscountPrice * $gst_rate)/100) ;
				$finalcost		   	= $totalCost;
				$gstPrice			= floor(($afterdiscountPrice * $gst_rate)/100);
				
				if($Option->discount_type == 'p') {
					$finalcost      =  ($finalcost * $Option->total_coast)/100;
					$optionDiscount	=  ($totalCost * $Option->discount)/100;
				 } else {				 
					$finalcost      =  $Option->total_coast;
					$optionDiscount	=  $Option->discount;
				 }			 
				 $balance			= $totalCost - $finalcost;			 
			} else {
				$report_id = $request->report_id;
				$payment   = app('App\Http\Controllers\ShopController')->appontmentPayment($report_id);		
				$OfferPrice			= $payment['totalcost'];
				$totaldiscount		= $payment['totaldiscount'];		
				$totalCost		   	= $payment['balance'];
				$finalcost		   	= $totalCost;
				
				$afterdiscountPrice = $OfferPrice - $totaldiscount;
				$gstPrice			= floor(($afterdiscountPrice * $gst_rate)/100);
				
				if($Option->discount_type == 'p') {
					$finalcost      =  ($finalcost * $Option->total_coast)/100;
					$optionDiscount	=  ($totalCost * $Option->discount)/100;
				 } else {				 
					$finalcost      =  $Option->total_coast;
					$optionDiscount	=  $Option->discount;
				 }			 
				$balance			= $totalCost - $finalcost;			
			}
		
			$payment['procedure_cost'] = $Offer->package_price;
			$payment['gst'] 	       = $gstPrice;
			$payment['total_cost']     = $totalCost;
			$payment['balance']        = $balance;
			$payment['payment']        = $finalcost;
		
			return Response::json(array('status'=>true,'message'=>'Procedure Report Data','payment'=>$payment));
		} else {
			return Response::json(array('status'=>false,'message'=>'Offer Id Invalid'));	
		}						
		
	}
    
    
    public function getCartDetail(Request $request)
    {
		
		$user_id 		    = $request->input('user_id');
		//echo $user_id; die;
		$cartTotal    = 0;
		$cartTotal   = array();
        $cart		  = Cart::where('user_id',$user_id)->first();
        
        //print_r( $cart); die;
        if($cart){
			$cartTotal    = $cart->grand_total;				
			$package   = CartItem::where('cart_id',$cart->id)->where('is_type','package')->with('offerDetail')->get()->toArray();
		
			return Response::json(array('status'=>true, 'package' => $package , 'cartTotal'=>$cartTotal ),$this->successStatus);				 
			}else{				
			return Response::json(array('status'=>false,'message'=>'No data Found'),$this->successStatus);
					
		}
            
    }
    
   
   public function userProcedureDetail(Request $request) {
			 
		   $user_id 		    = $request->input('user_id');
		   
			$reports = HairTransplantReport::where('user_id', $user_id)->get();
			$OperationList 	= OperationList::where('user_id', $user_id)->get(['operation_date']);
			$procedures = Procedure::where('report_id',$reports[0]->id)->get();
			$services	    =  SubService::where('id', 2)->get();	

			$AppointmentList = AppointmentList::where('procedure_id',$procedures[0]->id)->where('report_by_doctors','!=' ,'')->get();		
			$result = array();
					foreach ($reports as $key => $report)
					{
						$result = $report;
						$result['procedures'] = $procedures;
						$result['AppointmentList'] = $AppointmentList;
						$result['services'] = $services;
						$result['OperationList'] = $OperationList;
					}
			
		
			if($reports){
			return Response::json(array('status'=>true,'reports' => $result) ,$successStatus = 200);				 
				}else{
				return Response::json(array('status'=>false,'message'=>'error'));
						
				}
		}
	
	
	
	public function emptyCartDetail(Request $request) {
			$user_id = $request->input('user_id');			
			$cartItemId = $request->input('id');
			
			$cart 		= Cart::where('user_id', $user_id)->first();				
			if($cart){
				
				$Item    = CartItem::where('id', $cartItemId)->first();
				$type    = $Item->is_type;
				 
					//print_r($Item); die;				
				if($type == 'procedure' || $type == 'package') {					
					$HairTransplantReport = HairTransplantReport::find($Item->report_id)->delete();				
									
				}
				$Item->delete();
				$cartSome                   = CartItem::where('cart_id',$cart->id)->sum('total_price');
				$cartQtySum                 = CartItem::where('cart_id',$cart->id)->sum('quantity');
				$cartDicSum                 = CartItem::where('cart_id',$cart->id)->sum('discount');
				$cart->quantity_total 	  	= $cartQtySum;
				$cart->raw_total 	  		= $cartSome;
				$cart->discount_total 		= $cartDicSum;
				$cart->grand_total    		= $cartSome-$cartDicSum;
				$cart->save();
				$cartItem 	= CartItem::where('cart_id',$cart->id)->first();
				if(!$cartItem){
					Cart::where('user_id', $user_id)->delete();
				}
			return Response::json(array('status'=>true,'response' => 'Deleted Successfully' ) ,$successStatus = 200);				 
			}else{
			return Response::json(array('status'=>false,'message'=>'error'));
					
			}
			
	}
            
        
	
		
    public function getallcities()
	{		
		$cities	  = Cities::where('country_id', 1)->get(['name']);
		if($cities){
		    return Response::json(array('status'=>true,'cities' => $cities ) ,$successStatus = 200);				 
		}else{
			return Response::json(array('status'=>false,'message'=>'error'));					
		}

	}
	
	public function scheduleAnAppointment(Request $request) {
			///	die('nikhil');
		$id = $request->input('id');
		$user_id = $request->input('user_id');
			
		 $appointment_id = $id;
		 $HairReport     = HairTransplantReport::with(['user','applied_offer'])->find($appointment_id);		
		 if($HairReport !== null) {
			 $HairReport->appointment_status = 1;
			 $HairReport->save();	
			 
			$gst_price = $HairReport->total_cost*18/100;
			
			$User  = UserDetail::where('user_id', $user_id)->first();
			
			$HairReport->total_cost 	 = $HairReport->total_cost+$gst_price;
			$HairReport->pending_payment = $HairReport->total_cost+$gst_price;
			
			$TempOrder  = new TempOrder;
		   	$TempOrder->status 		= 0;
			$TempOrder->save();
			        
			$Order 	   				= new Order;		
			$Order->id 				= $TempOrder->id;
			$Order->user_id 		= $user_id;
			$Order->address 		= (isset($User->address)) ? $User->address : '';
			$Order->country 		= ($User->country) ? $User->country : '';
			$Order->state 			= ($User->state) ? $User->state : '';
			$Order->zip 			= ($User->post_code) ? $User->post_code : '';
			$Order->city 			= ($User->city) ? $User->city : '';
			$Order->billing_address = ($User->address) ? $User->address : '';
			$Order->billing_city 	= ($User->city) ? $User->city : '';
			$Order->billing_state 	= ($User->state) ? $User->state : '';
			$Order->billing_country = ($User->country) ? $User->country : '';
			$Order->billing_zip 	= ($User->post_code) ? $User->post_code : '';
			$Order->total 			= $HairReport->total_cost;
			$Order->grand_total 	= $HairReport->total_cost;
			$Order->status 			= 0;
			$Order->payment_status 	= 'Pending';
			$Order->save();
			
			$Procedure 				  	   = new Procedure;
			$Procedure->user_id 		   = $user_id;
			$Procedure->order_id 		   = $Order->id;
			$Procedure->report_id 	  	   = $HairReport->id;
			$Procedure->service     	   = $HairReport->service_id; //fixed for hair transplant custom
			$Procedure->type     	  	   = 'offer';
			//$Procedure->offer_apply      = '';
			//$Procedure->offer_name       = '';
			$Procedure->total_payment      = floor($HairReport->total_cost);
			$Procedure->advanced_payment   = 0;
			$Procedure->pending_payment    = floor($HairReport->total_cost);
			$Procedure->gst_price    	   = floor($gst_price);
			//$Procedure->payment_type     = '';
			$Procedure->procedure_stat     = $HairReport->procedure_stat;
			$Procedure->save();
			
						
			$OrderDetail 				   = new OrderDetail;
			$OrderDetail->order_id 		   = $Order->id;
			$OrderDetail->user_id 		   = $Order->user_id;
			$OrderDetail->product_id 	   = $Procedure->id;
			$OrderDetail->product_price    = $HairReport->total_cost;
			$OrderDetail->product_type     = 'procedure';
			$OrderDetail->product_quantity = 1;
			$OrderDetail->save();
			
			TempOrder::where('id',$TempOrder->id)->delete();						  
			return Response::json(array('success'=>true,'procedure_id'=>$Procedure->id, 'message'=>'Appointment Scheduled Successfully'));
		} else {			
			return Response::json(array('success'=>false, 'message'=>'Appointment Scheduled Error'));
		} 
	}
	
	
	
	public function savereview(Request $request)
	{
			
		$validator = Validator::make($request->all(), [             
            'message'    => 'required',
            'rate'       => 'required',
        ]);
        
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
            return response()->json(['error'=>$err], $this->successStatus);            
        }    
        
		$user_id = $request->input('userid');
		$user_name = $request->input('username');
		$user_email = $request->input('useremail');
		$user_img = $request->input('userimage');
		$subservice = $request->input('subservice');
		$review = $request->input('message');
		$ratings = $request->input('rate');
		$procedure_id = $request->input('procedure_id');
				
		$images = array();
		 if($request->hasfile('review_images')) 
			{
				$allowedfileExtension=['jpg','png','jpeg','gif'];
				
				$size = [];
				foreach($request->file('review_images') as $image)
				{	
					$folder           = 'reviews/';
					$random_number 	  = mt_rand(100000, 999999);
					$img_name = str_replace(' ', '', $image->getClientOriginalName());
					
					$name = $random_number.$img_name; 
				    $extension = $image->getClientOriginalExtension();
				    $extension = strtolower($extension);
				   
					$size[] = $image->getSize();  
					
					$check = in_array($extension , $allowedfileExtension); 
					  if($check)
					  {
						$image_size = 2000000;
						$total_size = array_sum($size);
						if($total_size > $image_size)
						{
						
						return Response::json(array('success'=>false,'message'=>'Images size must be less than 2 mb'));
						
						}
						else
						{
					  	$image->move(public_path().'/images/reviews/', $name);                  
					  	array_push($images , $folder.$name);
						}
					  }
					  else
					  {
						  
						return Response::json(array('success'=>false,'message'=>'Sorry Only Upload png , jpg , gif images'));
						 
					  }
					}
				
			}			
			
			$ProcedureReview = new ProcedureReview;
			$ProcedureReview->service_id = $subservice;
			$ProcedureReview->user_id = $user_id;
			$ProcedureReview->rating = $ratings;
			$ProcedureReview->review = $review;
			$ProcedureReview->review_image	 = $user_img;
			$ProcedureReview->reviewer_name = $user_name;
			$ProcedureReview->reviewer_email = $user_email;
			$ProcedureReview->review_status = '0';
			$ProcedureReview->one_year_images = implode(",",$images);
			$ProcedureReview->procedure_id = $procedure_id;
			$ProcedureReview->save();
			
			return Response::json(array('success'=>true, 'message'=>'Review successfully submitted !!'));
	}
	
	/*
     * Function to user report date.
     * @return view
    */
	public function reportData(Request $request) {
		
		$procedureid = $request->input('id');
		
		$get_uploaded_report = Procedure::find($procedureid);
		$convert_report_to_arr = [];
		$date = "";
		if(!empty($get_uploaded_report))
		{
			$report = $get_uploaded_report->user_report_images;
			
			//print_r($report); die;
			if(!empty($report))
			{
				$convert_report_to_arrs = explode("," , $report);
			}
			
			$convert_report_to_arr = implode(", ",$convert_report_to_arrs);

			
			$date = $get_uploaded_report->updated_at;
		
		
			return Response::json(array('status'=>true, 'convert_report_to_arr'=> $convert_report_to_arr ));
		
		}else{
			
			return Response::json(array('status'=>false,'message'=>'Report Not Available'));

		}
	}
	/*
     * Function to doctor report data.
     * @return view
    */
	public function doctorReportData(Request $request) {
		
		$procedureid        = $request->input('id');		
		$doctor_ass_report  = AppointmentList::where('procedure_id',$procedureid)->get();
		$doc_ass_report_arr = [];
		
		$arrr = array();
		if(count($doctor_ass_report) != 0)
		{
			foreach($doctor_ass_report as $doctor_report)
			{
				if(!empty($doctor_report->report_by_doctors))
				{
					$id = $doctor_report->id;
					$date = $doctor_report->updated_at;
					
					$doc_ass_report_arr = array_filter(explode(",",$doctor_report->report_by_doctors));
					//$doc_ass_report_arr[] = 
					//$doc_ass_report_arr[$id]['date'] = $date;
					
				}
			}
			
			return Response::json(array('success'=>true, 'doc_ass_report_arr'=> $doc_ass_report_arr ));
		
		} else{			
			return Response::json(array('success'=>false,'message'=>'Report Not Available'));

		}
	}
	
	/* Function To upload user report
	 * @return response 
	*/
	public function uploadeUserreport(Request $request)
	{
		 
		$validator = Validator::make($request->all(), [ 
				'id'				 => 'required',
				'user_report_images' => 'required'
			]);
			
		if ($validator->fails()) { 						
			foreach($validator->errors()->toArray() as $key=>$er) {
				$err[] = $er[0];
			}
			return response()->json(['status'=>false,'message'=>$err],  $this->errorStatus );            
		}
			
		$procedure_id = $request->input('id');
		$image = $request->input('user_report_images');
		
		$images = array();
		if($image) 
			{
				$allowedfileExtension=['jpg','png','jpeg','gif'];
				
				$size = [];
				
					//echo '<pre>'; print_r($image); echo '</pre>';
					$folder           = 'report/';
					$random_number 	  = mt_rand(100000, 999999);
					$f		        = finfo_open();
					$imgdata        = base64_decode($image);
					$mime_type      = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
					$mime_type      = explode('/',$mime_type);	
					$imageName 		= $random_number.'.'.$mime_type[1]; 
					File::put(public_path().'/images/'.$folder.$imageName, base64_decode($image));   
			
					$name = $random_number.$imageName; 
				    //$extension = $image->getClientOriginalExtension();
				    $extension = strtolower($name);
				   
				   
				   //print_r($imageName); die;
				   
					$check_image_exist = Procedure::where('id',$procedure_id)->first(['user_report_images']);
				
				       //echo  $check_image_exist['user_report_images']; die;
						$user_report = $check_image_exist['user_report_images'];
						if($user_report){							
							$image = $user_report .',report/'.$imageName;							
							} else {								
								$image = 'report/'.$imageName;
							}
							$procedure = Procedure::find($procedure_id);
							$procedure->user_report_images = $image;
							$procedure->save();
						
					
						return Response::json(array('success'=>true, 'message'=>'report uploaded successfully !!'));
		
			} else {
				return Response::json(array('success'=>false,'message'=>'no report uploaded !!'));
			}
	}
	
	
	public function UploadreportData(Request $request) 
	{
		
	$procedure_id = $request->input('id');
	 
	 
		$images = array();
		
	//	 print_r($request->uploadreport); die;
		
		if($procedure_id) 
			{
				
				$image	 = $request->get('user_report_images');//"/var/www/html/kaberaUserController.php on line 960/public/images/pages/610246banner-image-2.png";
				$folder  		= 'report/';
				$random_number 	= mt_rand(100000, 999999);
				$f		        = finfo_open();
				$imgdata        = base64_decode($image);
				$mime_type      = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
				$mime_type      = explode('/',$mime_type);
				$imageName 		= $random_number.'.'.$mime_type[1];  
				File::put(public_path().'/images/'.$folder.$imageName, base64_decode($image));   
			
					
					$check_image_exist = Procedure::where('id',$procedure_id)->first();
					
					
					if(!empty($check_image_exist))
					{
						//print_r($check_image_exist); die;
						$user_report = 'report/'.$imageName;
						
						//print_r($user_report); die;
						if(!empty($user_report))
						{
							$procedure = Procedure::find($procedure_id);
							$procedure['user_report_images'] = $user_report.','.implode(",",$images);
							$procedure->save();
						}
						else
						{
							$procedure = Procedure::find($procedure_id);
							$procedure['user_report_images'] = implode(",",$images);
							$procedure->save();
						}
						
						return response()->json(['success'=>true, 'message' => 'report uploaded successfully !!' , 'procedure'=> $check_image_exist], $this->successStatus);
						
					}
			}
			else
			{
				 return response()->json(['success'=>false, 'message' => 'no report uploaded !!'], $this->successStatus);
			}
		
	}
	
	function changeProcedureOffer(Request $request) {
		$id 	   = $request->input('id');
		$offer_id  = $request->input('offer_apply');
		$Procedure = Procedure::find($id);
		$Package   = Offer::find($offer_id);
				
		$paidAmt 		 =  $Procedure->advanced_payment;
		$optionDiscount  =  $Procedure->option_discount;
		$packageAmt 	 =  $Package['package_price'];
		$packageDiscount =  $Package['discount'];
	
		$finalAmount 	 =  $packageAmt-$packageDiscount;
		$pending		 =  $finalAmount - $paidAmt - $optionDiscount;
		if($offer_id != $Procedure->offer_apply) {
			$Procedure->type 			 = 'package';
			$Procedure->offer_apply 	 = $offer_id;
			$Procedure->required_grafts  = $Package['offer_grafts'];
			$Procedure->total_payment	 = $finalAmount;
			$Procedure->discount		 = $packageDiscount;
			$Procedure->pending_payment	 = $pending;
			$Procedure->save();
			
			return response()->json(['success'=>true, 'message' => 'Offer Changed Successfully' , 'package'=> $Package ], $this->successStatus);
						
		} else {
				 return response()->json(['success'=>false, 'message' => 'Offer Already Exist !!'], $this->successStatus);
		}				
	}
	
	function fixappointmentimeslot(Request $request) {
	   $selected_date = $request->input('appointment_date');
		
		$selected_date_str = strtotime($selected_date);
		$current_date = date("m/d/Y");
		
		$current_date_str = strtotime($current_date);
		
		$time_array = [];
		if($current_date == $selected_date)
		{			
			$get_appoitment_timeslot = AppoitmentTimeslot::get();
			$current_time = date("G:i");
			$current_time_strtime =  strtotime($current_time);
			if(count($get_appoitment_timeslot) != 0)
			 {
			 foreach($get_appoitment_timeslot as $timeslot)
				{
					$endtime = $timeslot->end_time;
					$starttime = $timeslot->start_time;
					$convertend_to_24hours = date("G:i", strtotime($endtime));
					$convertstart_to_24hours = date("G:i", strtotime($starttime));
					$endtime_strtime = strtotime($convertend_to_24hours);
					$starttime_strtime = strtotime($convertstart_to_24hours);
					if($current_time_strtime < $endtime_strtime)
					{
						$time_array[] = $convertstart_to_24hours.'-'.$convertend_to_24hours;
					}
				}
				
			}
		} else {
			
				$get_appoitment_timeslot = AppoitmentTimeslot::get();
				$current_time = date("G:i");
				 $current_time_strtime =  strtotime($current_time);
				 if(count($get_appoitment_timeslot) != 0)
				 {
					foreach($get_appoitment_timeslot as $timeslot)
					{
						$endtime = $timeslot->end_time;
						$starttime = $timeslot->start_time;
						$convertend_to_24hours = date("G:i", strtotime($endtime));
						$convertstart_to_24hours = date("G:i", strtotime($starttime));
						$endtime_strtime = strtotime($convertend_to_24hours);
						$starttime_strtime = strtotime($convertstart_to_24hours);
						$time_array[] = $convertstart_to_24hours.'-'.$convertend_to_24hours;
						
					}
				 }
			
		}
		if($time_array){			
		    return response()->json(['success'=>true, 'time_array'=> $time_array ], $this->successStatus);
		}else{
			return response()->json(['success'=>false, 'message' => 'Error !!'], $this->successStatus);
		}
	}	
			
		
	/* API for user procedures listing
	 * @return response
	*/	 
	public function userProcedureListing(Request $request) {
			$validator = Validator::make($request->all(), [ 
				'user_id' => 'required'
			]);
			
			if ($validator->fails()) { 						
				foreach($validator->errors()->toArray() as $key=>$er) {
					$err[] = $er[0];
				}
				return response()->json(['status'=>false,'message'=>$err],  $this->errorStatus );            
			}
			$data           = array();
		    $user_id 	    = $request->input('user_id');			
			$procedures 	= Procedure::with('serviceDetail')->with(array('Offer' => function($q){ 
						 $q->select('id','offer_name_en','description_en', 'app_banner_image');
					}))->where('user_id',$user_id)->get();	
			if($procedures) {			
				foreach($procedures as $key=>$procedure ) {					
					 $appointment = AppointmentList::with('doctorDetail')->where('user_id',$user_id)->where('procedure_id',$procedure->id)->first();	
					 if($appointment) {
						 $procedure['appointment'] = $appointment;
					 } else {
						$procedure['appointment']  = null; 
					 }
					 $data[] = $procedure;
				}			
				return response()->json(['success'=>true, 'data'=> $data ], $this->successStatus);
			} else {				
				return response()->json(['success'=>false, 'message' => 'Error !!'], $this->successStatus);
			}			 
	    }				
			
	/* API for user procedures report
	 * @return response
	*/	 
	public function userProcedureReport(Request $request) {
			$validator = Validator::make($request->all(), [ 
				'report_id' => 'required'
			]);
			
			if ($validator->fails()) { 						
				foreach($validator->errors()->toArray() as $key=>$er) {
					$err[] = $er[0];
				}
				return response()->json(['status'=>false,'message'=>$err],  $this->errorStatus );            
			}
		 
		    $report_id 	= $request->input('report_id');			
			$report 	= HairTransplantReport::find($report_id);			
			if($report) {
				return response()->json(['success'=>true, 'data'=> $report ], $this->successStatus);
			} else {				
				return response()->json(['success'=>false, 'message' => 'Sorry! No report available for this procedure.'], $this->successStatus);
			}			 
	    }	
	 
	/* API for get all comment notes
	 * @return response
	*/   
	public function AllCommentsNotes(Request $request) {	
		$user_id = $request->input('user_id');
		$User         = [];
		$comment_data = array();
		$total        = [];
		if($user_id){
			$User = User::where('id',$user_id)->with('userDetail')->first();
			$comment_data  = NoteCommentData::with('doc_detail','doc_image')->where('user_id',$user_id)->where('visible_to',1)->orderby('id','desc')->get();
			
			$appoitment_data  = AppointmentList::where('user_id',$user_id)->orderby('id','desc')->get();
			
			$total = count($comment_data);
			
			return response()->json(['success'=>true, 'comment_data'=> $comment_data , 'appoitment_data'=> $appoitment_data ], $this->successStatus);
			
			}else{
		 return response()->json(['success'=>false, 'message' => 'Error !!'], $this->successStatus);

			}
		
	}	
	
	/* API for get offers by sub service ID
	 * @return response
	*/
	public function serviceOffers(Request $request) 
		{
			
			$service_id = $request->input('sub_service_id');		   	
			$city       = $request->input('city');		
				
			$offers     = Offer::where('services',$service_id)->get();
			
			$cityOffers = [];
			if($offers) {	
				foreach($offers as $key=>$offer) {
				  if($offer->city) {
				
						if(($offer->is_type == '2')  && (in_array($city,explode(",", $offer->city)))) {	// get offers for city spceific					
							$cityOffers[] = $offer;
						}
					} else {
						$cityOffers[] = $offer;
						
					}
				}
				$offers	   = $cityOffers;
			
				return Response::json(array('status'=>true, 'offers'=>$offers,  'message'=>'Services Offers'), $this->successStatus); 
			} else {
				return Response::json(array('status'=>false, 'message'=>'Offer Not Available.'), $this->successStatus); 
			}
		
		}	
			/*order listing */
		public function userOrdersList(Request $request) {
		
		$id = $request->input('user_id');
		$orders = Order::where('user_id', $id)->with('user')->with('OrderDetails')->with('orderStatus')->orderBy('id','desc')->get();
		$service = array();
		$order_id = array();
		$services_name = array();
		
		foreach($orders as $order){
			$order_id = $order->id; 
			$procedures = Procedure::where('order_id',$order_id)->first();
			$service_id = $procedures->service;
			$order['get_service_name']   =  SubService::where('id', $service_id)->first();
		}
		
		if($orders){
			return response()->json(['success'=>true, 'orders'=> $orders ,'services_name'=> $services_name], $this->successStatus);
		}else{
			return response()->json(['success'=>false, 'message' => 'No Order found'], $this->successStatus);
		}
	}	
	
	/* user app notification for appointment */
	public function AppointmentNotificationUserApp($token) 
	{
		
		$optionBuilder = new OptionsBuilder();
		
		$optionBuilder->setTimeToLive(60*20);
		
		$notificationBuilder = new PayloadNotificationBuilder('Kabera');
		$notificationBuilder->setBody('You have received a new user Appointment Notification')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		
		//$message1 =  Response::json(array('success'=>false,'message'=>$message));	
		
		
		$dataBuilder->addData(['message' => 'Appointment Notification']);
			
		
			
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();
		//print_r($downstreamResponse); die;
		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();

		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();

		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();

		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
		
	}	
	/* notification for update appoitment in user app */
	public function AppointmentChangeUserApp($token) 
	{
		//echo $token; 
		$optionBuilder = new OptionsBuilder();
		
		$optionBuilder->setTimeToLive(60*20);
		
		$notificationBuilder = new PayloadNotificationBuilder('Kabera');
		$notificationBuilder->setBody('Appoinment Change Successfully')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		
		//$message1 =  Response::json(array('success'=>false,'message'=>$message));	
		
		
		$dataBuilder->addData(['message' => 'Appoinment Change Successfully']);
			
		
			
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();
			//print_r($downstreamResponse); die;
		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();

		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();

		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();

		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
		
	}
	
	
	public function UpdateNoteComment(Request $request) 
	{
		
		$id = $request->input('id');
		$user_id = $request->input('user_id');
		$appointment_id = $request->input('appointment_id');
		$doctor_id = $request->input('doctor_id');
		$assistant_id = $request->input('assistant_id');
		$comments_notes = $request->input('comments_notes');
		
	//	print_r($request->input()); die;
		$NoteCommentData 			= NoteCommentData::find($id);
		$NoteCommentData->comments_notes = $comments_notes;
		$NoteCommentData->save();
		
		if($NoteCommentData){
			return response()->json(['success'=>true, 'message'=> 'comment updated successfully' ], $this->successStatus);
		}else{
			return response()->json(['success'=>false, 'message' => 'Somthing went wrong'], $this->successStatus);
		}
		
	}
	
	public function DeleteNoteComment(Request $request) 
	{
		
		$id = $request->input('id');
		$appointment_id = $request->input('appointment_id');
		
		$NoteCommentDelete = NoteCommentData::where('appointment_id', $appointment_id)->where('id', $id)->delete();
		if($NoteCommentDelete){
			return response()->json(['success'=>true, 'message'=> 'Comment Delete Successfully' ], $this->successStatus);
		}else{
			return response()->json(['success'=>false, 'message' => 'Somthing went wrong'], $this->successStatus);
		}
		
	}
		
	
    public function doctorCappingToAssistant(Request $request)
	{
		$doctor_id = $request->input('doctor_id');
		$assistant_id = $request->input('assistant_id');
		$request_limit = $request->input('request_limit');
		
		$Assistant = User::find($assistant_id);
		if($Assistant){
			$Assistant->request_recieve_per_day = $request_limit;
			$Assistant->save();
			return response()->json(['success'=>true, 'capping'=> 'Capping request Updated successfully'], $this->successStatus);
			
		}else{			
			return response()->json(['success'=>false, 'capping'=> 'Sorry! Assistant not exist'], $this->successStatus);
		}		
	}
	
	/** 
	 * Resend Procedure OTP 
	*/
	public function resendProcedureOTP(Request $request) {
		
			$validator = Validator::make($request->all(), [             
				'phone'     => 'required',  
				'report_id' => 'required',  
			]);
			
			
			if ($validator->fails()) { 						
				foreach($validator->errors()->toArray() as $key=>$er) {
					$err[] = $er[0];
				}
				return response()->json(['error'=>$err], $this->successStatus);            
			} 
			
			$HairReport = HairTransplantReport::find($request->report_id);
			$time 	 = new DateTime(date('Y-m-d H:i:s'));
			$time->add(new DateInterval('PT5M'));
			$expTime = $time->format('Y-m-d H:i:s');
			$OTP     =  mt_rand(100000, 999999);
			
			$ProcedureOtp  = ProcedureOtp::firstOrNew(['phone'=>$request->phone]);
			$ProcedureOtp->phone  =  $request->phone;
			$ProcedureOtp->otp 	  =  $OTP;
			$ProcedureOtp->expired_at = $expTime;							
			$ProcedureOtp->save();
			$message	 = "<#> Welcome to Kabera Gloabal. Please use this otp to proceed your procedure. (".$OTP .")".env('APP_MSG_CODE');
			$phone 	     = $request->phone;
			$SmsApi 	 =  new SmsApi();
			
			if($SmsApi->sendSMS($phone , $message)) {
				
				return Response::json(array('status'=>true,'otp'=>$OTP, 'user_id' =>$HairReport->user_id , 'phone'=> $ProcedureOtp->phone ,'report_id'=>$HairReport->id, 'message'=>'OTP Send Successfully'),$successStatus = 200 ); //remove otp key when site will be live
			} else {
				return Response::json(array('status'=>false,'message'=>'Error Occured'));			
			}
		
	}
}
	

?>
