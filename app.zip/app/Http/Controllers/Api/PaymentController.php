<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\User;
use Config;
use Session;
use App\TempOrder;
use App\Cart;
use App\CartItem;
use App\Procedure;
use App\PaymentType;
use App\Offer;
use App\ProcedureOption;
use App\HairTransplantReport;
use App\Order;
use App\OrderDetail;
use App\Mail\OrderEmail;
use App\Providers\IcicipaymentServiceProvider;


class PaymentController extends Controller
{
    /**
     * Create a new controller instance.
     * @return void
    */   
    public $successStatus 	= 200;
	public $errorStatus 	= 401;
	
	/**
     * Function to checkout payment.
     * @return Response
    */
    public function procedurePayment(Request $request)
    {
		$Procedure      = Procedure::find($request->procedure_id);
		$user 		 	= User::find($request->user_id);
		if($user && $Procedure){
			if($request->amount != ""){
				$amount = $request->amount;
			}else{
				$amount = $Procedure->pending_payment;
			}
			if($amount < 0){
				 return response()->json(['status'=>true,'message'=>"Thank You! You have already done your payment process."], $this->successStatus); 
			}
			if($amount > $Procedure->pending_payment ){
				 return response()->json(['status'=>false,'message'=>"Paid amount is greater then pending amount."], $this->errorStatus); 
			}
			$responseSuccessURL 	 = url('/').'/api/user/procedure/payment/success';
			$responseFailURL 	 	 = url('/').'/api/user/procedure/payment/cancel';
			$storeId         		 = env('ICICI_STORE_ID');
			$sharedSecret            = env('ICICI_SECRET');
			$currency            	 = '356';
			$UserEmail       		 = $user->email;
			$userId          		 = env('ICICI_USERID');
			$parameters = ['responseSuccessURL' => $responseSuccessURL,'responseFailURL' => $responseFailURL,'storeId' => $storeId,'userId' => $userId,'UserEmail' => $UserEmail,'amount' => $request->amount,'sharedSecret' => $sharedSecret,'currency' => $currency,'extra_param' => $request->procedure_id];
			return IcicipaymentServiceProvider::process($parameters);
		}else{
			return response()->json(['status'=>false,'message'=>"User not exists"], $this->errorStatus); 
		}
    }
    
    /**
     * Function to check payment response.
     * @return Response
    */
    public function paymentResponse(Request $request)
    {
		$encResponse 	= $request->input();
        if($encResponse){
			$email     = env('KABERA_ADMIN_EMAIL'); //user admin email to testing
			if($encResponse['status'] == "APPROVED"){
				$message = "Thank You! Your payment has been successfully Completed.";
				$id 			= $encResponse['extra_param'];
				$Procedure      = Procedure::find($id);
				if($Procedure){
					$pending_pmt = $Procedure->pending_payment - $encResponse['chargetotal'];
					$Procedure->track_status      = 'payment'; 
					$Procedure->total_payment     = $Procedure->total_payment; 
					$Procedure->pending_payment   = $Procedure->pending_payment-$encResponse['chargetotal']; 
					$Procedure->advanced_payment   = $Procedure->advanced_payment+$encResponse['chargetotal']; 
					$Procedure->save();
					$PaymentType 				= new PaymentType;
					$PaymentType->user_id  	    = $Procedure->user_id;
					$PaymentType->procedure_id  = $Procedure->id;
					$PaymentType->amount 		= $encResponse['chargetotal'];
					$PaymentType->payment_type  = 'online';
					$PaymentType->save();
					
					$orders = Order::find($Procedure->order_id);
					$orders->total          = $Procedure->total_payment;
					$orders->grand_total    = $Procedure->total_payment;
					$orders->pending_amount = $pending_pmt;
					$orders->payment_status = "Success";
					$orders->save();
				}
				return redirect(url('/api/user/payment-response?status=true'));	
				//return response()->json(['status'=>true,'message'=>$message], $this->successStatus); 
			}else{
				$message = "Your payment has been declined due to your card problem. Please contact to admin support.";
				//return response()->json(['status'=>true,'message'=>$message], $this->errorStatus); 
				return redirect(url('/api/user/payment-response?status=false'));	
			}
		}	
		
	}
	
	/**public function checkoutIciciResponse(Request $request)
    
     * Function to return checkout cancel page.
     * @return Response
    */
	public function paymentCancel(Request $request)
    {
		//return response()->json(['status'=>false,'message'=>$request->input('fail_reason')], $this->errorStatus); 
	}
	
	
	/*
	* Function to checkout procedure
	* @return Response
	*/	
	public function procedureCheckoutPayment(Request $request){
		
		$user_id 		   = $request->user_id;
		$cart_contents     = Cart::where('user_id',$user_id)->first();  		
		
		if($cart_contents) {
		$product_gst	   = CartItem::where('cart_id',$cart_contents->id)->where('is_type','product')->sum('gst_price');  
        $user 		 	   = User::find($request->user_id);
        $TempOrder 		   = TempOrder::where('user_id',$user_id)->delete();
        $TempOrder 		   = new TempOrder;
        
        $TempOrder->user_id 		= $user_id;
        $TempOrder->cart_id 		= $cart_contents->id;
        $TempOrder->address 		= $request->last_name.' '.$request->last_name.','.$user->email.','.$request->address;
        $TempOrder->country 		= $request->country;
        $TempOrder->state 			= $request->state;
        $TempOrder->zip 			= $request->zip;
        $TempOrder->city 			= $request->city;
        $TempOrder->billing_address = $request->address;
        $TempOrder->billing_city 	= $request->city;
        $TempOrder->billing_state 	= $request->state;
        $TempOrder->billing_country = $request->country;
        $TempOrder->billing_zip 	= $request->zip;
        $TempOrder->payment_method 	= "";
        $TempOrder->total 			= $cart_contents->raw_total;
        $TempOrder->grand_total 	= $cart_contents->grand_total + $product_gst ;
        $TempOrder->status 			= 0;
        $TempOrder->save();
        $orderdata = ['order_id' => $TempOrder->id, 'cart_id' => $TempOrder->cart_id,'amount' =>$TempOrder->grand_total,'billing_name' => $request->first_name.' '.$request->last_name,'shipping_name' => $request->firstName.' '.$request->lastName];        
       // Session::put('orderdata', $orderdata);       
            
		$responseSuccessURL 	 = url('/').'/api/user/procedurecheckout/payment/success';
		$responseFailURL 	 	 = url('/').'/api/user/procedurecheckout/payment/cancel';
		
		$storeId         		 = env('ICICI_STORE_ID');
		$sharedSecret            = env('ICICI_SECRET');
		$currency            	 = '356';
		$UserEmail       		 = $user->email;
		$userId          		 = env('ICICI_USERID');
			
		$parameters = ['responseSuccessURL' => $responseSuccessURL,'responseFailURL' => $responseFailURL,'storeId' => $storeId,'userId' => $userId,'UserEmail' => $UserEmail,'extra_param' => '1','amount' => $orderdata['amount'],'sharedSecret' => $sharedSecret,'currency' => $currency,'session_param'=>json_encode($orderdata)];
		return IcicipaymentServiceProvider::process($parameters);
	  } else {
		  return response()->json(['status'=>true,'message'=>"Sorry! Your Cart Is Empty"], $this->errorStatus);
	  }
	}
	
	
	/**
     * Function to check payment icici response.
     * @return Response
    */
    public function paymentCheckoutResponse(Request $request)
    {
		$response 		= $request->input();
		$orderdata 		= json_decode($response['session_param'], true);
		
        if($response['status'] == "APPROVED"){
			$TempOrder = TempOrder::where('id',$orderdata['order_id'])->first();
			$Order 	   = new Order;
			$Order->id 				= $TempOrder->id;
			$Order->user_id 		= $TempOrder->user_id;
			$Order->address 		= $TempOrder->address;
			$Order->country 		= $TempOrder->country;
			$Order->state 			= $TempOrder->state;
			$Order->zip 			= $TempOrder->zip;
			$Order->city 			= $TempOrder->city;
			$Order->billing_address = $TempOrder->address;
			$Order->billing_city 	= $TempOrder->billing_city;
			$Order->billing_state 	= $TempOrder->state;
			$Order->billing_country = $TempOrder->country;
			$Order->billing_zip 	= $TempOrder->zip;
			$Order->payment_method 	= $response['paymentMethod'];
			$Order->total 			= $TempOrder->total;
			$Order->grand_total 	= $TempOrder->grand_total;
			$Order->status 			= 0;
			$Order->payment_status 	= $response['status'];
			$Order->response_code 	= $response['ccbin'];
			$Order->save();
			$TempOrderDetails 	    = CartItem::where('cart_id',$orderdata['cart_id'])->get();
			
			if($TempOrderDetails){
				foreach ($TempOrderDetails as $key => $value) {
					if($value->is_type == "product") {
						$OrderDetail 				   = new OrderDetail;
						$OrderDetail->order_id 		   = $Order->id;
						$OrderDetail->user_id 		   = $Order->user_id;
						$OrderDetail->product_id 	   = $value->product_id;
						$OrderDetail->product_price    = $value->product_price;
						$OrderDetail->product_quantity = $value->quantity;
						$OrderDetail->gst_price 	   = $value->gst_price;
						$OrderDetail->save();
					} else if($value->is_type == "procedure") { //procedure with offer
						$Report = HairTransplantReport::with(['user','applied_offer'])->find($value->report_id); 
						if($Report !== null) {
							 $Report->appointment_status = 1;
							 $Report->save();
						   }
						$Procedure 				  	   = new Procedure;
						$totalCoast		   	           = $Report->total_payment;
						$finalcost		   	           = $value->total_price;						 
						$balance		               = $totalCoast - $finalcost - $value->option_discount;
						$Procedure->order_id 		   = $Order->id;
						$Procedure->user_id 		   = $Order->user_id;
						$Procedure->report_id 	  	   = $value->report_id;
						$Procedure->service     	   = ($Report->applied_offer ? $Report->applied_offer->services:"");
						$Procedure->type     	  	   = 'offer';
						$Procedure->offer_apply        = $Report->offer_apply;
						$Procedure->offer_name         = $Report->applied_offer->offer_name_en;
						$Procedure->discount           = $Report->discount;
						$Procedure->option_discount    = $value->option_discount;
						$Procedure->total_payment      = $totalCoast;
						$Procedure->gst_price     	   = $value->gst_price;
						$Procedure->advanced_payment   = $finalcost;
						$Procedure->pending_payment    = $balance;
						$Procedure->required_grafts    = $Report->total_graft;
						$Procedure->payment_option     = $value->payment_option;
						$Procedure->note         	   = $value->note;
						$Procedure->preportid          = $value->report_id;
						$Procedure->save();
						
						$OrderDetail 				   = new OrderDetail;
						$OrderDetail->order_id 		   = $Order->id;
						$OrderDetail->user_id 		   = $Order->user_id;
						$OrderDetail->product_id 	   = $Procedure->id;
						$OrderDetail->product_price    = $totalCoast;
						$OrderDetail->product_quantity = 1;
						$OrderDetail->product_type     = 'procedure';
						$OrderDetail->save();
						
						$PaymentType 				= new PaymentType;
						$PaymentType->user_id  	    = $Order->user_id;
						$PaymentType->procedure_id  = $Procedure->id;
						$PaymentType->amount 		= $finalcost;
						$PaymentType->payment_type  = 'online';
						$PaymentType->save();
						
					} else { //package
						$offer  = Offer::find($value->product_id);
						$Option = ProcedureOption::find($value->payment_option);
						
						$Report = HairTransplantReport::with(['user','applied_offer'])->find($value->report_id); 
						if($Report !== null) {
							 $Report->appointment_status = 1;
							 $Report->save();
						   }
						
						$packagePrice		         = $offer->package_price+$value->gst_price;
						$totaldiscount		         = $value->offer_discount;		
						$totalCoast		   	         = $packagePrice - $totaldiscount;
						$finalcost		   	         = $value->total_price;											 
						$balance		             = $totalCoast - $finalcost - $value->option_discount;	
							 
						$Procedure 				  	 = new Procedure;
						$Procedure->order_id 		 = $Order->id;
						$Procedure->user_id 		 = $Order->user_id;
						$Procedure->report_id 	  	 = $value->report_id;
						$Procedure->service     	 = $offer->services;
						$Procedure->type     	  	 = 'package';
						$Procedure->offer_apply      = $value->product_id;
						$Procedure->offer_name       = $offer->offer_name_en;
						$Procedure->discount         = $offer->discount;
						$Procedure->option_discount  = $value->option_discount;
						$Procedure->total_payment    = $totalCoast;
						$Procedure->gst_price     	 = $value->gst_price;
						$Procedure->advanced_payment = $value->total_price;
						$Procedure->pending_payment  = $balance;
						$Procedure->required_grafts  = $offer->offer_grafts;
						$Procedure->payment_option   = $value->payment_option;
						$Procedure->note         	 = $value->note;
						$Procedure->preportid        = $value->report_id;
						$Procedure->save();
						
						$OrderDetail 				   = new OrderDetail;
						$OrderDetail->order_id 		   = $Order->id;
						$OrderDetail->user_id 		   = $Order->user_id;
						$OrderDetail->product_id 	   = $Procedure->id;
						$OrderDetail->product_price    = $totalCoast;
						$OrderDetail->product_quantity = 1;
						
						
						$OrderDetail->product_type     = 'procedure';
						$OrderDetail->save();
						
						$PaymentType 				= new PaymentType;
						$PaymentType->user_id  	    = $Order->user_id;
						$PaymentType->procedure_id  = $Procedure->id;
						$PaymentType->amount 		= $value->total_price;
						$PaymentType->payment_type  = 'online';
						$PaymentType->save();
					}				
				}
			}
			//$email = Auth::user()->email;
			$user_id   = $TempOrder->user_id;
			$email     = env('KABERA_ADMIN_EMAIL'); //user admin email to testing
			$TempOrder = TempOrder::where('id',$orderdata['order_id'])->delete();
			if($response['status'] == "APPROVED"){
				$message = "Thank You! Your order has been successfully Completed.";
			}else{
				$message = "Thank You! Your order has been declined due to payment issue. Please contact to admin support.";
			}
			$data = array('order_id' => $Order->id,'message' => $message);
			Mail::send('emails.orderconfirmation', $data, function($messaged)use($email){
			  $messaged->from(env('KABERA_SUPPORT_EMAIL'));
			  $messaged->to($email);
			  $messaged->subject('Order Confirmation');
			});
		
		
		$cart_contents = Cart::where('user_id',$user_id)->first();
		Cart::where('user_id',$user_id)->delete();
		CartItem::where('cart_id',$cart_contents->id)->delete();
		$message = "Thank You! Your payment has been successfully Completed.";
		
		//return response()->json(['status'=>true,'message'=>$message], $this->successStatus); 	
		return redirect(url('/api/user/payment-response?status=true'));	
		
	  } else {
		  return redirect(url('/api/user/payment-response?status=false'));	
		 //return response()->json(['status'=>true,'message'=>"Payment Error"], $this->errorStatus);
	  }
	}
	
	/**
     * Function to return checkout icici cancel page.
     * @return Response
    */
	public function paymentCheckoutCancel(Request $request)
    {
		//return redirect()->route('Checkout')->with('message',$request->input('fail_reason'));
	}
	
	/**
     * Function to return payment response form icici.
     * @return Response
    */
	public function procedurePaymentResponse(Request $request)
    {
		
	}
	
}
