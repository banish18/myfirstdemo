<?php
namespace App\Http\Controllers\Api;

use Illuminate\Support\Facades\Response;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Validator;
use App\User;
use Image;
use Storage;
use App\Role;
use App\RoleUser;
use App\Doctors;
use App\Service;
use App\SubService;
use App\DoctorAssistant;
use App\HairTransplantReport;
use App\WelcomePage;
use App\AppData;
use App\Procedure;
use App\Offer;
use Auth;
use Mail;
use File;

class ProcedureController extends Controller
{
	public $successStatus = 200;
	
    /**
     * Create a new controller instance.
     * @return void
    */
    public function __construct() {
		$this->langArr =  ['en','fr'];
	}
	
	/* 
	 * Function to Save Hair Procedire Data and Register User 
	*/	
	public function saveHairReport(Request $request) {
		
		$data  = $request->all();
		/* Check if user login or not */
		$isLoginCHeck = $data['is_login'];
		if($isLoginCHeck == 1){
		   $HairReport = new HairTransplantReport;
		   $HairReport->user_id		      = $data['user_id'];
		   $HairReport->affected_ids	  = $data['area'];
		   $HairReport->total_graft	      = $data['total_graft'];
		   $HairReport->total_hair	      = $data['total_hair'];
		   $HairReport->medical_condition = $data['medical'];
		   $HairReport->total_cost		  = $data['total_graft']*20;
		   $images						  = $data['images'];
		   if(is_array($images) && !empty($images)){
			foreach($images as $image){
				$folder         = 'hair-procedure/';
				$random_number 	= mt_rand(100000, 999999);
				$f		   = finfo_open();
				$imgdata   = base64_decode($image);
				$mime_type = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
				$mime_type = explode('/',$mime_type);
				$imageName 		= $random_number.'.'.$mime_type[1];  
				File::put(public_path().'/images/app/hair-procedure/' . $imageName, base64_decode($image));   
				$imagesArr[] = $folder.$imageName;
			}	
			$dataArray = $data;
			$HairReport->affected_gallery = implode(",",$imagesArr);			
			$HairReport->save();	
			if($dataArray){
				return response()->json(['status'=>'success', 'data' => $dataArray], $this->successStatus); 	
			}else{
				return response()->json(['status'=>'success', 'data' => 'No Data Available'], $this->successStatus);
			}
		}else{
			/* Check if user exists or not */
			$user = User::where('email',$data['email'])->orWhere('phone',$data['phone'])->first();		
			if ($user) {
				return response()->json(['status'=>'success', 'data' => "You are already Registered with us. Please login"], $this->successStatus); 	
			} else {
				$offerApplied = null;
				if($data['offer_id']) {
					$offerApplied = $data['offer_id'];
				}
				$password = Str::random(8);
				$user 	  = User::create([
					'name'        		=> $data['name'],
					'email'       		=> $data['email'],
					'phone'       		=> $data['phone'],
					'password'    		=> Hash::make($password),
					'api_token'   		=> Str::random(60),
					'role'	      		=> '3',
					'isVerified'  		=>  1,
					'offer_apply'  		=>  $offerApplied,
					'email_verified_at' => date("Y-m-d h:i:s")
				]);
				$user
			   ->roles()
			   ->attach(Role::where('name', 'user')->first());
			   $mdata['email']     = $data['email'];
			   $mdata['name']      = $data['name'];
			   $mdata['password']  = $password;
			   Mail::to($data['email'])->send(new WelcomeMail($mdata));
			   $data['id'] = $user->id;
				if($user){		   
				   $HairReport = new HairTransplantReport;
				   $HairReport->user_id		      = $user->id;
				   $HairReport->affected_ids	  = $data['area'];
				   $HairReport->total_graft	      = $data['total_graft'];
				   $HairReport->total_hair	      = $data['total_hair'];
				   $HairReport->medical_condition = $data['medical'];
				   $HairReport->total_cost		  = $data['total_graft']*20;
				   $images						  = $data['images'];
				   if(is_array($images) && !empty($images)){
						foreach($images as $image){
							$folder         = 'hair-procedure/';
							$random_number 	= mt_rand(100000, 999999);
							$f		   = finfo_open();
							$imgdata   = base64_decode($image);
							$mime_type = finfo_buffer($f, $imgdata, FILEINFO_MIME_TYPE);
							$mime_type = explode('/',$mime_type);
							$imageName 		= $random_number.'.'.$mime_type[1];  
							File::put(public_path().'/images/app/hair-procedure/' . $imageName, base64_decode($image));   
							$imagesArr[] = $folder.$imageName;
					}	
					$dataArray = $data;
					$HairReport->affected_gallery = implode(",",$imagesArr);			
					$HairReport->save();	
					if($dataArray){
						return response()->json(['status'=>'success', 'data' => $dataArray], $this->successStatus); 	
					}else{
						return response()->json(['status'=>'success', 'data' => 'No Data Available'], $this->successStatus);
							}
						}	
					}
				}
			}
		}

	}
	
	
	/* 
	 *Function to get offers for user panel
	 * @return Response
	*/	
	public function getpackages(Request $request) {
		$packages  = Offer::where('offer_type','package')->where('services',$request->service_id)->get()->toArray();
		array_walk_recursive($packages,function(&$item){$item=strval($item);});
		return response()->json(['status'=>'success', 'data' => $packages], $this->successStatus);		
	}
	
	
}
