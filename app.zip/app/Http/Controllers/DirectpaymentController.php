<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Auth;
use Session;
use Validator;
use App\Mail\AdminpartnerEmail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Response;
use App\Countries;
use App\DirectPaymentRecord;
use DB;
use Config;
use App\Providers\IcicipaymentServiceProvider;
class DirectpaymentController extends Controller
{
	public function payment()
	{
		$countries = DB::table("countries")->pluck("name","id");
		return view('payment',compact('countries'));
	}
	public function getStateList(Request $request)
	{
		$states = DB::table("states")
		->where("country_id",$request->country_id)
		->pluck("name","id");
		return response()->json($states);
	}
	public function getCityList(Request $request)
	{
		$cities = DB::table("cities")
		->where("state_id",$request->state_id)
		->pluck("name","id");
		return response()->json($cities);
	}
	public function paymentsave(Request $request) {
		$DirectPaymentRecord 	   			= new DirectPaymentRecord;
		$DirectPaymentRecord->name 			= $request->name;
		$DirectPaymentRecord->email 		= $request->email;
		$DirectPaymentRecord->phone_number 	= $request->phone;
		$DirectPaymentRecord->address 		= $request->address;
		$DirectPaymentRecord->country 		= $request->country;
		$DirectPaymentRecord->state 		= $request->state;
		$DirectPaymentRecord->city 			= $request->city;
		$DirectPaymentRecord->amount 		= $request->amount;
		$DirectPaymentRecord->save();
		
		$responseSuccessURL 	 = url('/').'/direct/payment/success';
		$responseFailURL 	 	 = url('/').'/direct/payment/cancel';
		$storeId         		 = Config::get('icicipay.icici.storeid');
		$sharedSecret            = Config::get('icicipay.icici.sharedsecret');
		$currency            	 = Config::get('icicipay.icici.currency');
		$order 					 = Session::get('orderdata');
		$UserEmail       		 = $DirectPaymentRecord->email;
		$userId          		 = Config::get('icicipay.icici.userid');
		$parameters = ['responseSuccessURL' => $responseSuccessURL,'responseFailURL' => $responseFailURL,'storeId' => $storeId,'userId' => $userId,'UserEmail' => $UserEmail,'amount' => $DirectPaymentRecord->amount,'sharedSecret' => $sharedSecret,'currency' => $currency,'extra_param' => $DirectPaymentRecord->id];
		return IcicipaymentServiceProvider::process($parameters);
	}
	/**
     * Function to check payment response.
     * @return Response
    */
    public function directpaymentResponse(Request $request)
    {
		$encResponse 	= $request->input();
        if($encResponse){
			$email     = env('KABERA_ADMIN_EMAIL'); //user admin email to testing
			if($encResponse['status'] == "APPROVED"){
				$message = "Thank You! Your payment has been successfully Completed.";
				$id 			= $encResponse['extra_param'];
				$DirectPaymentRecord = DirectPaymentRecord::find($id);
				$DirectPaymentRecord->payment_status = $encResponse['status'];
				$DirectPaymentRecord->save();
			}else{
				$message = "Your payment has been declined due to your card problem. Please contact to admin support.";
			}
		}	
		return Redirect()->route('payment')->with('message', $message);
	}
	
	/**
     * Function to return checkout cancel page.
     * @return Response
    */
	public function directpaymentCancel(Request $request)
    {
		$id 			= $request->input('extra_param');
		$DirectPaymentRecord = DirectPaymentRecord::find($id);
		$DirectPaymentRecord->payment_status = "Failed";
		$DirectPaymentRecord->save();
		return Redirect()->route('payment', ['id' => $request->input('extra_param')])->with('message',$request->input('fail_reason'));
	}
   
}
