<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Contact;
use Auth;
use Session;
use Validator;
use App\Mail\ContactEmail;
use App\AppointmentList;
use App\Chat;
use App\User;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Response;
use LaravelFCM\Message\Topics;
use LaravelFCM\Message\OptionsBuilder;
use LaravelFCM\Message\PayloadDataBuilder;
use LaravelFCM\Message\PayloadNotificationBuilder;
use FCM;
use DB;
use Google\Cloud\Firestore\FirestoreClient;

class NotificationController extends Controller
{
	
    /**
     * Create a new Function to save contact us data.
     *
     * @return slides, offers
    */
	public function index($token , $message) 
	{
		//die('svsdfs');
		
		//echo $message; die;
		
		//Android Token
		//$token = 'epweoOXplKw:APA91bG_pxWZBE5w4KEK6pFoU9Fgzn8JVpkrbqwV-MawLlaOkAdVMKMOQptYwUyyZ0CcpH825l0pJUptUKopL2mnmLVNZTdFcyOe1Wvq__t4Djcz0j_mtdcpCX4kRrv_tBN_e_3SilK0';

		
		$optionBuilder = new OptionsBuilder();
		
		$optionBuilder->setTimeToLive(60*20);
		
		$notificationBuilder = new PayloadNotificationBuilder('Kabera Global');
		$notificationBuilder->setBody('You have received a new message Notification Please check')
							->setSound('default');					
		$dataBuilder = new PayloadDataBuilder();
		
		//$message1 =  Response::json(array('success'=>false,'message'=>$message));	
		
		
		$dataBuilder->addData(['message' => $message]);
			
		
			
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);

		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();

		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();

		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();

		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();

		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
		
		
	}
   
   
    public function notificationView()
   {
	   $users['users']  = [];
	   $users['doctor'] = DB::table('doctor_detail')->select('*')->get();	
		return view('notification',$users);   
	   
	}
	
   
   public function addNotification(Request $request)
   {
	    $user =  Auth::user();
	   	$message   	= $request->input('message');
	   	$doctor_id 	= $request->input('doctor_id');
	   	$assistants_id = $request->input('user_id');
		$users 		= User::where('id',$request->doctor_id)->first();
		if($users){
			$device_token = $users->device_token;
			if($device_token != ""){
				$this->index($device_token , $message);	
			}
		}
		$user_id   = $user->id;
		DB::table('chats')->insert(['to' => $doctor_id, 'assistants_id' => $assistants_id, 'message' => $message,'user_id' => $user_id,'from' => $user_id, 'doctor_id' => $doctor_id , 'device_token' => $device_token]);
	    $messageHtml = '<div class="incoming_msg"><div class="incoming_msg_img"><img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"></div> <div class="received_msg"><div class="received_withd_msg"><p class="results_id">'.$message.'</p></div></div></div>';
	    
		return Response::json(array('success'=>false,'message'=>$messageHtml));	
		
		
	}
	
	public function updatedChat(Request $request)
	{
		$user 		=  Auth::user();
		$doctor_id 	= $request->input('doctor_id');
		$user_id   	= $user->id;
		$Chat       = Chat::where('to',$user_id)->where('from', $doctor_id)->orderby('id','desc')->first();
		if($Chat && $Chat->id != $request->input('last_id')){
			$messageHtml = '<div class="outgoing_msg"><div class="sent_msg"><p>'.$Chat->message.'</p><input type="hidden" id="last_id" value="'.$Chat->id.'"/></div></div>';
			return Response::json(array('success'=>true,'message'=>$messageHtml));	
		}else{
			return Response::json(array('success'=>false,'message'=> ''));	
		}
		
	}

   
    public function addDoctorId($doctor_id)
    {
		$user 		 = Auth::user();
	   	$to			 = $doctor_id;
		$user_id 	 = $user->id;
		$users 		 = DB::table('chats')->where('user_id',$user_id)->where('doctor_id', $doctor_id)->get();
		$AppointmentList = AppointmentList::where('user_id',$user_id)->where('doctor_id', '!=' ,'0')->where('status','1')->with('doctorDetail')->groupBy('doctor_id')->get();
		
			$userss 	= User::where('id', $doctor_id)->first();
			
			if($userss){
				$device_token = $users->device_token;
				if($device_token != ""){
					/* Notification for web */
					$this->AssistantChatNotification($device_token);
				}
		}
		
		
		return view('notification',compact(['users', 'AppointmentList', 'doctor_id'])); 
	    
	}
	
	
public function AssistantChatNotification($token)
	{
		// Notification for web sended by doctor
		$optionBuilder = new OptionsBuilder();
		$optionBuilder->setTimeToLive(60*20);
		$notificationBuilder = new PayloadNotificationBuilder('Kabera Global');
		$notificationBuilder->setBody('You have received a new message from your User')
						->setSound('default');
		$dataBuilder = new PayloadDataBuilder();
		$dataBuilder->addData(['a_data' => 'my_data']);
		$option = $optionBuilder->build();
		$notification = $notificationBuilder->build();
		$data = $dataBuilder->build();
		$downstreamResponse = FCM::sendTo($token, $option, $notification, $data);
		$downstreamResponse->numberSuccess();
		$downstreamResponse->numberFailure();
		$downstreamResponse->numberModification();
		// return Array - you must remove all this tokens in your database
		$downstreamResponse->tokensToDelete();
		// return Array (key : oldToken, value : new token - you must change the token in your database)
		$downstreamResponse->tokensToModify();
		// return Array - you should try to resend the message to the tokens in the array
		$downstreamResponse->tokensToRetry();
		// return Array (key:token, value:error) - in production you should remove from your database the tokens
		$downstreamResponse->tokensWithError();
	}
		
		
		
	 public function doctorNotification()
   {
	    $user =  Auth::user();
	   	$message   = $request->input('message');
	   	$doctor_id = $request->input('doctor_id');
		$user_id   = $user->id;
		$users 		= User::where('id',$request->doctor_id)->first();
		if($users){
			$device_token = $users->device_token;
		}
		$var = DB::table('chats')->insert(['to' => $doctor_id, 'message' => $message,'user_id' => $user_id,'from' => $user_id, 'doctor_id' => $doctor_id]);
	    $this->index($device_token , $message);
	   
		
	}	
		
	
}
