<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Contracts\Auth\Guard;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use App\Exceptions\UnAuthorizedRequestException;
use Config;
use DB; 
use App\User;
class ApicheckMiddleware
{
	//use APIResponse;
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
   public function handle($request, Closure $next)
	{
		
		$access_token = $request->header('Authorization');
		$access_token = str_replace("Bearer ", "", $access_token);
		
		
		if($access_token) {
			$user = User::where('api_token', $access_token)->first();
			if($user) {
				$request->merge(array("user" => $user));
				   return $next($request)
						->header('Access-Control-Allow-Methods','GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS')
					   ->header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
				//return $next($request);
			}
		}
		
		return response()->json(['error'=>'Unauthorized Token'], 401)->header('Content-Type', 'application/json');   


	}
}
 
