<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProcedureOption extends Model
{
	  
}
