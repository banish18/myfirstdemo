<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OptionProbability extends Model
{
	protected $table = 'option_probabilities';
}

?>
