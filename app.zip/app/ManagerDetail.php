<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Laravel\Passport\HasApiTokens;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Role;

class ManagerDetail extends Model
{
	  
	  
	  protected $fillable = [
        'type', 'age', 'address', 'profile_pic', 'aadhar_card_pic', 'region', '	manager_permission', 'manager_id'
    ];
	  
	  
}
