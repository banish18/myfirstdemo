<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dials extends Model
{
	protected $table = 'click_to_detail_response';
	
	
	  protected $fillable = [
	  
        'uid'
    ];
	
}
