<?php

namespace App;
use App\Service;

use Illuminate\Database\Eloquent\Model;

class Doctors extends Model
{
	protected $table = 'doctor_detail';
	 
	public function gallery() {
		
		return $this->hasMany('App\ClinicGallery','doctor_id');
	}
	
	public function user()
	{  
	  return $this->belongsTo(User::class,'user_id' );
	}
    
    public function service($id)
	{  
		$service = Service::find($id);
		if(!$service){
			$service = [];
		}
	  return $service;
	}
}
