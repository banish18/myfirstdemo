<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Capping extends Model
{
   protected $table = 'request_capping';
 
}
