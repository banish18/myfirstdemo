<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
   const UPDATED_AT = null;
   const CREATED_AT = null;
   protected $table = 'contact_us';
   protected $fillable = ['name','phone','emails','city','message'];
}
