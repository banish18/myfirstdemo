<?php

namespace App\Providers;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Config;

class IcicipaymentServiceProvider extends ServiceProvider
{
    /**
     * Register any events for your application.
     *
     * @return void
     */
    public static function process($parameters = array())
    {
		// Please change the store Id to your individual Store ID
		$dateTime	  = date('Y:m:d-H:i:s');
		// NOTE: Please DO NOT hardcode the secret in that script. For example read it from a database.
		$stringToHash = $parameters['storeId']. $dateTime . $parameters['amount'] . $parameters['currency'] . $parameters['sharedSecret'];
		$ascii 		  = bin2hex($stringToHash);
		$hasPwd  	  = sha1($ascii);
        return View::make('shop.icici-pay')->with('parameters',$parameters)->with('hasPwd',$hasPwd);
    }
}
