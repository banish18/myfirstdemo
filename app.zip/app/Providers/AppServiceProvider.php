<?php

namespace App\Providers;

use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

use Illuminate\Auth\Notifications\VerifyEmail;
use Illuminate\Notifications\Messages\MailMessage;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
       // Schema::defaultStringLength(192);
         
         VerifyEmail::toMailUsing(function ($notifiable,$url){
			$user = $notifiable;
			//echo "<pre>"; print_r($user); die;
            $mail = new MailMessage;
            $mail->subject('Welcome!');
            $mail->markdown('emails.verifyUser', ['url' => $url,'user' =>$user]);
            return $mail;
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
