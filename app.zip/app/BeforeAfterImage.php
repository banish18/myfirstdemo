<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BeforeAfterImage extends Model
{
	//
}
