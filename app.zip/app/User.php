<?php

namespace App;

use Laravel\Passport\HasApiTokens;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Role;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasApiTokens, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'customer_number', 'email', 'password', 'role', 'phone', 'api_token', 'added_by', 'isVerified', 'email_verified_at'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

     /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    
    public function roles()
	{  
	  return $this->belongsToMany(Role::class);
	}
	
	
    public function role_detail()
	{
	  return $this->belongsTo(Role::class, 'role');
	}
	
	public function userDetail(){
		return $this->belongsTo(UserDetail::class, 'id', 'user_id');
	}
	
	/**
	* @param string|array $roles
	*/
	public function authorizeRoles($roles)
	{		
	  if (is_array($roles)) {
		 // var_dump($this->hasAnyRole($roles)); die;
		  return $this->hasAnyRole($roles) || 
				 abort(401, 'This action is unauthorized.');
	  } else {
		  return $this->hasRole($roles) || 
				 abort(401, 'This action is unauthorized.');
	  }
	}
	
	/**
	* Check multiple roles
	* @param array $roles
	*/
	public function hasAnyRole($roles)
	{
	  return null !== $this->roles()->whereIn('name', $roles)->first();
	}
	
	/**
	* Check one role
	* @param string $role
	*/
	public function hasRole($role)
	{		 
	  return null !== $this->roles()->where('name', $role)->first();
	}
	
	public function isAdmin() //check if role admin
	{
		if($this->role == 1)
			return true;
		else
			return false;
	}
	
	public function isDoctor() //Check If Role Doctor
	{
		if($this->role == 2)
			return true;
		else
			return false;
	}
	
	public function isNormalUser() //Check If Role User
	{
		if($this->role == 3)
			return true;
		else
			return false;
	}	
	
	public function isManager() //Check If Role Manager
	{
		if($this->role == 4)
			return true;
		else
			return false;
	}	
	
	public function isAgent() //Check If Role Agent
	{
		if($this->role == 5)
			return true;
		else
			return false;
	}	
	
	public function isAsistant() //Check If Role Asistant
	{
		if($this->role == 6)
			return true;
		else
			return false;
	}	
	
	public function notVerified() //Check If user verified or Not
	{
		if($this->isVerified != 1)
			return true;
		else
			return false;
	}	
	
	public function verifyUser()
    {
        return $this->hasOne('App\VerifyUser');
    }
    
    
	public function doctor()
	{  
	  return $this->belongsTo(Doctors::class,'id','user_id' );
	}
    
	public function manager()
	{  
	  return $this->belongsTo(ManagerDetail::class,'id','user_id' );
	}
	
	public function agent()
	{  
	  return $this->belongsTo(Agent::class,'id','user_id' );
	}
	
	public function assistant()
	{  
	  return $this->belongsTo(DoctorAssistant::class,'id','user_id' );
	}
	public function OperationList()
	{ 
		return $this->belongsTo(OperationList::class, 'id','doctor_id');
	}
}
