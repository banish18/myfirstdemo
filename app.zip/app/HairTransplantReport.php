<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HairTransplantReport extends Model
{
   // get user detail by user id
   public function user() {	   
	   return $this->belongsTo('App\User','user_id');
   }
   
   // get offer detail by offer id
   public function applied_offer() {	   
	   return $this->belongsTo('App\Offer','offer_apply');
   }
   
}
