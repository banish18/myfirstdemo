<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GraftRate extends Model
{    
	
}
