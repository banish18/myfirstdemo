<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TalkToExpert extends Model
{
   protected $table = 'talk_to_expert';
   protected $fillable = ['user_id','service_id','reason','available_time'];
   
   public function talkexpert()
	{
	  return $this->belongsTo('App\User','user_id');
	}

}
