<?php
namespace app;

/**
* class SmsApi to send SMS on Mobile Numbers.
* @author Naveen Dogra
*/
class SmsApi {
	
	private $TOKEN         = '9cd90a135caa8417e256b13145e52b85';
    private $SENDER_ID     = "KABERA";
    private $ROUTE_NO      = 'O';
    private $RESPONSE_TYPE = 'json';


    function __construct() {

    }

   
    /* Create Send SMS Function 
     * @return response
    */
    public function sendSMS($mobileNumber, $message){
        $isError = 0;
        $errorMessage = true;

        //Preparing post parameters
        $postData = array(
            'token'    => $this->TOKEN,
            'To' 	   => $mobileNumber,
            'Text'     => $message,
            'sender'   => $this->SENDER_ID,
            'route'    => $this->ROUTE_NO,
            'response' => $this->RESPONSE_TYPE
        );
     
        $url = "http://sms.paragalaxy.com/smpp_api/sms";
     
        $ch  = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData
        ));
     
     
        //Ignore SSL certificate verification
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
     
     
        //get response
        $output = curl_exec($ch);
     
        //Print error if any
        if (curl_errno($ch)) {
            $isError = true;
            $errorMessage = curl_error($ch);
        }
        curl_close($ch);
        if($isError){
            return array('success' => false , 'message' => $errorMessage);
        }else{
            return array('success' => true, 'message' => 'Message Sent Successfully' );
        }
    }
}
?>
