<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BeforeAfterReview extends Model
{
	//
}
