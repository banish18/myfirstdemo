<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
	
  protected $fillabe=[
				  'template', 'data_type', 'title', 'content_en', 'extras_en', 'extras_hn'
				  ];
				  
	
  
}
