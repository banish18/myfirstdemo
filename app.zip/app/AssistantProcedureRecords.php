<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssistantProcedureRecords extends Model
{
	public function user(){
		return $this->belongsTo('App\User','assistant_id');
	}
}
