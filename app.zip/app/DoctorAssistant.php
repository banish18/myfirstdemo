<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class DoctorAssistant extends Model
{
	public function user()
	{  
	  return $this->belongsTo(User::class, 'user_id');
	}  
	
	public function capping()
	{  
	  return $this->belongsTo(Capping::class,'user_id','assistant_id');

	}  
	
	
}
