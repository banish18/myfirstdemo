<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
    */
    protected $fillable = [
        'cat_id',
        'product_name_en',
        'product_name_fr',
        'product_description_en',
        'product_description_fr',
        'product_price',
        'actual_price',
        'product_image',
        'product_image_original',
        'stock',
        'status',
        'discount_avl',
        'discount_type',
        'discount_rate'
    ];
    
    public function service()
	{
	   return $this->hasOne('App\Service' , 'id', 'cat_id');
	}
	
	public function gallery() 
	{
		return $this->hasMany('App\ProductGallery');
	}
}
