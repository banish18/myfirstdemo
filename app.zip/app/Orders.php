<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Orders extends Model
{
	protected $table = 'orders';
	public function OrderDetails()
	{
		return $this->hasOne('App\OrderDetail','order_id');
	}
	public function user()
	{
		return $this->belongsTo('App\User','user_id');
	}	
	
	public function userDetails()
	{
		return $this->hasOne('App\UserDetail','user_id','user_id');
	}	
	
	public function orderComments()
	{
		return $this->hasMany('App\OrderComment','order_id','id');
	}	
		
	public function orderStatus()
	{
		return $this->hasOne('App\OrderStatus','id','status');
	}
}
