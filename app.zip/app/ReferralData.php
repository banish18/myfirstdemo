<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReferralData extends Model
{
   protected $table = 'referral_data';
   protected $fillable = ['user_id','ref_from','ref_code','ref_to_email','ref_to_phone','status','ref_type','point_des','service_type','point_des','service_type'];



	public function user()
	{
	  return $this->belongsTo('App\User','user_id');
	}
	public function ref_data()
	{
	  return $this->belongsTo('App\User','ref_from');
	}
}
