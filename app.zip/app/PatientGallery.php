<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PatientGallery extends Model
{
     protected $table = 'patient_gallery';
    
}
