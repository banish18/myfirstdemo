import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EmptyObservable } from 'rxjs/observable/EmptyObservable';
import 'rxjs/add/operator/map';
import { LoadingController } from 'ionic-angular';
import Utils from './Utils';

@Injectable()

export class Api {
  baseURL: string = localStorage.getItem('BaseURL');
  constructor(public http: HttpClient,
    public loadingCtrl: LoadingController) { }
  get(endpoint: string, params?: any, reqOpts?: any) {

    let header = new HttpHeaders({
      'Content-Type': 'application/json;charset=UTF-8',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'DELETE, HEAD, GET, OPTIONS, POST, PUT',
      'Access-Control-Allow-Headers': 'Content-Type, Content-Range, Content-Disposition, Content-Description',
      'Accept': '*/*'
    });
    return this.http.get(Utils.CMS_WEBAPI_DOMAIN + '/' + endpoint, { params: params, observe: 'response', headers: header }).map((res: any) => {
      if (res.status == 200) {
        return res.body;
      }
      else {
        return new EmptyObservable();
      }
    }, err => {
      console.error('ERROR', err);
      return null;
    });
  }

  post(endpoint: string, body: any, reqOpts?: any) {
    let header = new HttpHeaders({
      'Content-Type': 'application/json;charset=UTF-8',
      'client-id': 'iOS'
    });
    return this.http.post(Utils.CMS_WEBAPI_DOMAIN + '/' + endpoint, body, { params: reqOpts, observe: 'response', headers: header }).map((res: any) => {
      if (res.status == 200) {
        return res.body;
      }
      else {
        console.log(res);
        return new EmptyObservable();
      }
    }, err => {
      console.log('POST ERROR CHECK:::');
      console.error('ERROR', err);
      return null;
    });
  }

  put(endpoint: string, body: any, reqOpts?: any) {
    return this.http.put(Utils.CMS_WEBAPI_DOMAIN  + '/' + endpoint, body, { params: reqOpts, observe: 'response' }).map((res: any) => {
      if (res.status == 200) {
        return res.body;
      }
      else {
        return new EmptyObservable();
      }
    }, err => {
      console.error('ERROR', err);
      return null;
    });
  }

  delete(endpoint: string, reqOpts?: any) {
    return this.http.delete(Utils.CMS_WEBAPI_DOMAIN  + '/' + endpoint, { params: reqOpts, observe: 'response' }).map((res: any) => {
      if (res.status == 200) {
        return res.body;
      }
      else {
        return new EmptyObservable();
      }
    }, err => {
      console.error('ERROR', err);
      return null;
    });
  }

  patch(endpoint: string, body: any, reqOpts?: any) {
    return this.http.patch(Utils.CMS_WEBAPI_DOMAIN  + '/' + endpoint, body, { params: reqOpts, observe: 'response' }).map((res: any) => {
      if (res.status == 200) {
        return res.body;
      }
      else {
        return new EmptyObservable();
      }
    }, err => {
      console.error('ERROR', err);
      return null;
    });
  }

}
