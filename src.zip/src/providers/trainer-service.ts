import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { INSTRUCTORS } from '../mocks/mock-countries';
/*
  Generated class for the CountryServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class TrainerServiceProvider {

  instructorList: any[];

  constructor(public http: HttpClient) {
    console.log('Hello NewsServiceProvider Provider');
    this.instructorList = INSTRUCTORS;
    console.log("newList " + this.instructorList);
  }

  getInstructorList() {
    return this.instructorList;
  }

  getInstructor(id) {
    let newsObj = {};
    for (let i = 0; i < this.instructorList.length; i++) {
      if (id == this.instructorList[i].id) {
        newsObj = this.instructorList[i];
        break;
      }
    }
    return newsObj;
  }

  filterItems(searchTerm) {

    return this.instructorList.filter((item) => {
      return (item.Name.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1) || (item.language.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1);
    });

  }

}
