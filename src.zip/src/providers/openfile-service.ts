import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import Utils from './Utils';
/*
  Generated class for the CountryServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class OpenFileServiceProvider {

  faqsList: any;

  constructor(public http: Http) {
    console.log('Hello FaqsServiceProvider Provider');

  }

  getRegestrationFees(courseType) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers.append('Something', "");
      this.http.get(Utils.MOCKY + "/5c8bfd2f3600006c4d8f83c1&" + courseType, { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  getQuestionair(student_PID) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers.append('Something', "");
      this.http.get("http://www.mocky.io/v2/5c5ed9ee320000210140b425/?student_PID" + student_PID, { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  postQuestionair(postObject = {}) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers.append('Something', "");
      this.http.post("http://www.mocky.io/v2/5c5ed9ee320000210140b425/", postObject, { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

}

export class questionairModelPost {
  student_PID: number;
  q1: string;
  q2: string;
  q3: string;
  q4: string;
  q5: string;
  q6: string;
  q7: string;
  q8: string;
  q9: string;
  q10: string;
  q11: string;
  q12: string;
  q13: string;
  q14: string;
  q15: string;
}


