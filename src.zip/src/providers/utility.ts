﻿import { Injectable } from '@angular/core';
import { LoadingController, Loading } from 'ionic-angular';
/*
  Generated class for the CountryServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class Utility {

  loader: Loading;

  constructor(private myLoader: LoadingController) {
      this.loader = this.myLoader.create({  
                
          content: "Please wait...",
    });
  }

  public showLoader() {
    this.loader = this.myLoader.create({
        content: "Please wait...",
    });
    this.loader.present();
  }


  public dismissLoader() {
    this.loader.dismiss();
  }

  public getUserId() {
    return localStorage.getItem("student_PID");
  }

  public isEmpty(obj) {
    for (var key in obj) {
      if (obj.hasOwnProperty(key))
        return false;
    }
    return true;
  }
  public truncate(elem, limit, after) {

    // Make sure an element and number of items to truncate is provided
    if (!elem || !limit) return;

    // Get the inner content of the element
    var content = elem.textContent.trim();

    // Convert the content into an array of words
    // Remove any words above the limit
    content = content.split(' ').slice(0, limit);

    // Convert the array of words back into a string
    // If there's content to add after it, add it
    content = content.join(' ') + (after ? after : '');

    // Inject the content back into the DOM
    elem.textContent = content;

  }

}
