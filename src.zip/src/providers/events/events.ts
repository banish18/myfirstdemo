import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import Utils from '../Utils';
/*
  Generated class for the EventsProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class EventsProvider {

  constructor(private http: Http) {
    console.log('Hello EventsProvider Provider');
  }

  getEvents() {
    return new Promise((resolve, reject) => {

      let headers = new Headers();
      headers.append('Something', "");
      this.http.get("/api/mobileapp/wp-json/wp/v2/posts?tags=8", { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  getAboutUs() {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      headers.append('Content-Type', "application/json; charset=UTF-8");
      this.http.get(Utils.MOCKY + "5c8b78f3360000e30c8f80f2", { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  getPolicy() {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      headers.append('Content-Type', "application/json; charset=UTF-8");
      this.http.get(Utils.MOCKY + "5c8b81693600004d0b8f8114", { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  getMockTest(fileNo = "FP317") {
    let language = localStorage.getItem("lang") || "en";
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      headers.append("Content-Type", "application/json");
      this.http.get(Utils.AA_WEBAPI_DOMAIN_3 + "api/ExamType?FileNo=" + fileNo + "&language=" + language, { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  getMockQuestionById(mockID = "FP317") {
    let language = localStorage.getItem("lang") || "en";
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      headers.append("Content-Type", "application/json");
      this.http.get(Utils.AA_WEBAPI_DOMAIN_3 + "api/MockTest?examid=" + mockID, { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

}
