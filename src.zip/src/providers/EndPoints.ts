export class AppConfig {
    readonly serviceURL =
        {
            "SEARCHRTACONTENT": {
                "ENDPOINT": "api/user/rta/content/search"
            },
            "REGISTERUSER": {
                "ENDPOINT": "api/user/register"
            },
            "GETDOCUMENTS": {
                "ENDPOINT": "api/user/documents/list"
            },
            "GETPROMOTIONS": {
                "ENDPOINT": "api/user/promotions"
            },
            "COURSEINFO": {
                "ENDPOINT": "api/user/course/info"
            },
            "GETOFFERS": {
                "ENDPOINT": "api/user/offers"
            },
            "USERFEEDBACK": {
                "ENDPOINT": "api/user/app/feedback"
            },
            "SUBMITQUESTIONAIRELIVE": {
                "ENDPOINT": "api/user/questionnaire/submit"
            },
            "CONTACTUS": {
                "ENDPOINT": "api/user/contact_us"
            },
            "SUBMITDOCUMENTS": {
                "ENDPOINT": "api/user/documents/upload"
            },
            "RTACONTENT": {
                "ENDPOINT": "api/user/rta/content"
            },
            "TRAINERSINFO": {
                "ENDPOINT": "api/user/trainers/info"
            },
            "SUBMITQUESTIONAIRE": {
                "ENDPOINT": "api/user/questionnaire/submit"
            },
            "GETQUESTIONAIRE": {
                "ENDPOINT": "api/user/questionnaire"
            },
            "NEWS": {
                "ENDPOINT": "api/user/news"
            }
        }
}
