import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import { signupModel } from '../pages/signup/signupModel';
import Utils from './Utils';
/*
  Generated class for the CountryServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class LoginServiceProvider {

  registeredUser: any[] = [];

  constructor(public http: Http) {
    console.log('Hello CountryServiceProvider Provider');
    // this.registeredUser = USERS;
  }

  getUsers() {
    return this.registeredUser;
  }

  Registration(obj: signupModel) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      headers.append("Content-Type", "application/json");
      this.http.post(Utils.AA_WEBAPI_DOMAIN + "/Security/Registration", obj, { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  login(model) {
    let body = new URLSearchParams();
    body.set('username', model.username);
    body.set('password', model.password);
    body.set('grant_type', "password");

    return new Promise((resolve, reject) => {
      let headers = new Headers();
      headers.append("Content-Type", "application/x-www-form-urlencoded");

      console.log(Utils.AA_WEBAPI_DOMAIN + "/token", body.toString())

      this.http.post(Utils.AA_WEBAPI_DOMAIN + "/token", body.toString(), { headers: headers })
        // this.http.post("http://www.mocky.io/v2/5c714b0b3500006300e9e7fc", body.toString(), { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  sendOtp(Student_PID) {

    let language = localStorage.getItem("language");
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers.append('Something', "");
      this.http.get(Utils.AA_WEBAPI_DOMAIN + "/Security/SendOTP?Student_PId=" + Student_PID + "&lang=" + language, { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  verifyOtp(Student_PID, otp) {
    let language = localStorage.getItem("language");
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      this.http.post(Utils.AA_WEBAPI_DOMAIN + "/Security/VerifyOTP?Student_PId=" + Student_PID + "&lang=" + language + "&otp=" + otp, { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  setPassword(Student_PID, Password) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      this.http.post(Utils.AA_WEBAPI_DOMAIN + "/Security/SetPassword?Password=" + Password + "&Student_PId=" + Student_PID, { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  userExist(mobileNumber: string) {
    let userObject = {};
    for (let i = 0; i < this.registeredUser.length; i++) {
      if (this.registeredUser[i].mobile == parseInt(mobileNumber)) {
        userObject = this.registeredUser[i];
      }
    }

    return userObject;
  }


  forgotPassword(mobileNumber) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      let lang = localStorage.getItem("lang") || "en";
      this.http.get(Utils.AA_WEBAPI_DOMAIN + "/Security/ForgetPassword?mobileno=" + mobileNumber + "&lang=" + lang, { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }


}

export class RegistrationResponseModel {

  status: true;
  response: {
    id: number;
    first_name: string;
    last_name: string;
    email: string;
    access_token: string;
  };
  error: {
    custom_code: string;
    message: any;
  };

}

export class MenuOption {
  method: string;
  iconName: string;
  title: string;
  status: boolean;

  constructor(title: string, method: string, iconName: string, status: boolean) {
    this.method = method;
    this.iconName = iconName;
    this.title = title;
    this.status = status;
  }
}
