import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FAQS } from '../mocks/mock-faqs';
/*
  Generated class for the CountryServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class FaqsServiceProvider {

  faqsList: any;

  constructor(public http: HttpClient) {
    console.log('Hello FaqsServiceProvider Provider');
    this.faqsList = FAQS;
    console.log("faqlist "+this.faqsList);
  }

  getFaqsList() {
    return this.faqsList;
  }

  getFaqs(id) {
    let faqsObj = {};
    for (let i = 0; i < this.faqsList.length; i++) {
      if (id == this.faqsList[i].id) {
        faqsObj = this.faqsList[i];
        break;
      }
    }
    return faqsObj;
  }

}
