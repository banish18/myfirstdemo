import 'rxjs/add/operator/toPromise';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { HttpClient } from '@angular/common/http';
import { Api } from '../providers/api';
import 'rxjs/add/operator/share';
import 'rxjs/add/operator/share'



@Injectable()

export class FacadeService {
    student_Pid = localStorage.getItem('student_PID');
    readonly serviceURL =
        {
            "SEARCHRTACONTENT": {
                "ENDPOINT": "api/user/rta/content/search"
            },
            "REGISTERUSER": {
                "ENDPOINT": "api/user/register"
            },
            "GETDOCUMENTS": {
                "ENDPOINT": "api/user/documents/list"
            },
            "GETPROMOTIONS": {
                "ENDPOINT": "api/user/promotions"
            },
            "COURSEINFO": {
                "ENDPOINT": "api/user/course/info"
            },
            "GETOFFERS": {
                "ENDPOINT": "api/user/offers"
            },
            "USERFEEDBACK": {
                "ENDPOINT": "api/user/app/feedback"
            },
            "SUBMITQUESTIONAIRELIVE": {
                "ENDPOINT": "api/user/questionnaire/submit"
            },
            "CONTACTUS": {
                "ENDPOINT": "api/user/contact_us"
            },
            "SUBMITDOCUMENTS": {
                "ENDPOINT": "api/user/documents/upload"
            },
            "RTACONTENT": {
                "ENDPOINT": "api/user/rta/content"
            },
            "TRAINERSINFO": {
                "ENDPOINT": "api/user/trainers/info"
            },
            "SUBMITQUESTIONAIRE": {
                "ENDPOINT": "api/user/questionnaire/submit"
            },
            "GETQUESTIONAIRE": {
                "ENDPOINT": "api/user/questionnaire"
            },
            "NEWS": {
                "ENDPOINT": "api/user/news"
            },
            "FAQ": {
                "ENDPOINT": "api/user/faqs"
            },
            "DOCUMENT_HISTORY": {
                "ENDPOINT": "api/user/documents/history"
            },
            "GETSCHEDULE": {
                "ENDPOINT": "http://www.mocky.io/v2/5c7455a92f00002a00964154"
            },
            "GETPRACTICALSCHEDULE": {
                "ENDPOINT": "http://www.mocky.io/v2/5c74543e2f00002c0096414e"
            },
            "EXAMQUESTIONS": {
                "ENDPOINT": "http://www.mocky.io/v2/5c470c3531000048008a1bfa"
            },
            "GETEXAMLISTIDS": {
                "ENDPOINT": "http://www.mocky.io/v2/5c470b1a31000079008a1bf7"
            },            
            "ADD_REVIEW": {
                "ENDPOINT": "api/user/review"
            },
            "TRAINERSBYID": {
                "ENDPOINT": "api/user/get/trainer"
            },
            "TRAINERS_SWAP": {
                "ENDPOINT": "api/user/trainers/info"
            },
            "CHANGE_TRAINER": {
                "ENDPOINT": "api/user/change/trainer"
            },            
            "GET_BRANCH": {
                "ENDPOINT": "api/user/get/branches"
            },
            "SEARCH_TRAINER": {
                "ENDPOINT": "api/user/search/trainer"                
            }             

        }
    constructor(public http: HttpClient, public api: Api) {
        console.log('Hello FacadeService Provider');
    }

    getExamQuestionsID(body: any) {
        var examListBody = {
            FileNo: body.FileNo,
            language: body.language
        }
        let seq = this.http.post(this.serviceURL["GETEXAMLISTIDS"].ENDPOINT, examListBody).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    getExamQuestions(ExamId) {
        var scheduleBody = {
            ExamId: ExamId
        }
        let seq = this.http.post(this.serviceURL["EXAMQUESTIONS"].ENDPOINT, scheduleBody).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    getSchedule(body: any) {
        var scheduleBody = {
            file_no: body.file_no,
            dateTime: body.dateTime,
            filterLanguage: body.filterLanguage,
            branchID: body.branchID,
            Type: body.Type,
            _comment: body._comment,
            sessionID: body.sessionID

        }
        let seq = this.http.post(this.serviceURL["GETSCHEDULE"].ENDPOINT, scheduleBody).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    getPracticalSchedule(body: any) {
        var scheduleBody = {
            file_no: body.file_no,
            dateTime: body.dateTime,
            filterLanguage: body.filterLanguage,
            branchID: body.branchID,
            Type: body.Type,
            _comment: body._comment,
            sessionID: body.sessionID

        }
        let seq = this.http.post(this.serviceURL["GETPRACTICALSCHEDULE"].ENDPOINT, scheduleBody).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    faq(language: string, tag: string) {
        let params = {
            lang: language,
            tag: tag
        }
        let seq = this.api.get(this.serviceURL["FAQ"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    getQuestions() {
        let params = {
            lang: localStorage.getItem("lang") || "en"
        }
        let seq = this.api.get(this.serviceURL["GETQUESTIONAIRE"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    getToPayList() {
        let seq = this.http.get("http://www.mocky.io/v2/5c4711733100000f008a1c15").share();
        return seq.map((res: any) => {
            return res;
        });
    }

    getDocumentHistory(userId) {

        let params = {
            user_id: userId
        }

        let seq = this.api.get(this.serviceURL["DOCUMENT_HISTORY"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    searchRTAContent(language: string, search: string) {
        let params = {
            lang: language,
            search: search
        }
        let seq = this.api.get(this.serviceURL["SEARCHRTACONTENT"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    // Register User is for internal use

    // registerUser() {
    //     let seq = this.api.get(this.serviceURL["REGISTERUSER"].ENDPOINT).share();
    //     return seq.map((res: any) => {
    //         return res;
    //     });
    // }

    getDocuments() {
        let seq = this.api.get(this.serviceURL["GETDOCUMENTS"].ENDPOINT).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    getPromotions(language: string) {
        let params = {
            lang: language
        }
        let seq = this.api.get(this.serviceURL["GETPROMOTIONS"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    courseInfo(language: string) {
        let params = {
            lang: language
        }
        let seq = this.api.get(this.serviceURL["COURSEINFO"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    getOffers(language: string) {
        let params = {
            lang: language
        }
        let seq = this.api.get(this.serviceURL["GETOFFERS"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    userFeedback(feedbackBody: any) {
        let body = {
            user_id: feedbackBody.user_id,
            booking_id: feedbackBody.booking_id,
            assigned_to: feedbackBody.assigned_to,
            feedback: feedbackBody.feedback,
            rating: feedbackBody.rating
        }
        let seq = this.api.post(this.serviceURL["USERFEEDBACK"].ENDPOINT, body).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    submitQuestionaireLive(QuestionaireBody) {
        let body = {
            user_id: QuestionaireBody.user_id,
            response: QuestionaireBody.response
        }
        let seq = this.api.post(this.serviceURL["SUBMITQUESTIONAIRELIVE"].ENDPOINT, body).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    contactus(contactusBody: any) {
        let body = {
            mobile_number: contactusBody.mobile_number,
            name: contactusBody.name,
            message: contactusBody.message
        }
        let seq = this.api.post(this.serviceURL["CONTACTUS"].ENDPOINT, body).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    submitDocuments(submitDocumentsBody: any) {
        let body = {
            user_id: submitDocumentsBody.user_id,
            doc_name: submitDocumentsBody.doc_name,
            file_path: submitDocumentsBody.file_path,
            doc_id: submitDocumentsBody.doc_id
        }
        let seq = this.api.post(this.serviceURL["SUBMITDOCUMENTS"].ENDPOINT, body).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    rtaContent(language: any) {
        let params = {
            lang: language
        }
        let seq = this.api.get(this.serviceURL["RTACONTENT"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    trainersInfo(language: any) {
        let params = {
            lang: language
        }
        let seq = this.api.get(this.serviceURL["TRAINERSINFO"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }
    trainersByUserID(body: any) {
        let params = {
            user_id: body.user_id,
            lang:body.lang
        }
        console.log(params)
        let seq = this.api.get(this.serviceURL["TRAINERSBYID"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            console.log(res)
            return res;
        });
    }

    submitQuestionaire(submitQuestionaireBody: any) {
        let body = {
            user_id: submitQuestionaireBody.user_id,
            response: submitQuestionaireBody.response
        }
        let seq = this.api.post(this.serviceURL["SUBMITQUESTIONAIRE"].ENDPOINT, body).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    getQuestionaire(language: any) {
        let params = {
            lang: language
        }
        let seq = this.api.get(this.serviceURL["GETQUESTIONAIRE"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    getnews(language: any) {
        let params = {
            lang: language
        }
        let seq = this.api.get(this.serviceURL["NEWS"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    showToast(msg) {
        //this.toast.show(msg, '2000', 'center');
    }

    addReview(body: any) {      
        let params = {
            user_id: body.user_id,
            driver_id: body.driver_id,
            review: body.review,
            rating: body.rating
        }
        let seq = this.api.post(this.serviceURL["ADD_REVIEW"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    trainers(params: any) {       
        let seq = this.api.get(this.serviceURL["TRAINERS_SWAP"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }


    changeTrainer(params: any) {
        let seq = this.api.post(this.serviceURL["CHANGE_TRAINER"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    getBranches(language: any) {
        let params = {
            lang: language
        }
        let seq = this.api.get(this.serviceURL["GET_BRANCH"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });
    }

    searchTrainer(params: any) {
        let seq = this.api.get(this.serviceURL["SEARCH_TRAINER"].ENDPOINT, params).share();
        return seq.map((res: any) => {
            return res;
        });        
    }

}