import { Http, Headers, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import Utils from './Utils';
/*
  Generated class for the CountryServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class NewsServiceProvider {

  newsList: any;
  options: any;
  constructor(public http: Http) {
    console.log('Hello NewsServiceProvider Provider');
  }

  computeHeaders() {
    let headers = new Headers({ 'Content-Type': 'application/json', 'Authorization': 'Basic YWhsYW0tYXBwLWlvczo1Nzk3ZTY2Mi0wYzQ0LTRjYWYtOGU1OS01OGUwNzVjOWI3NGI=}]', 'client-id': 'ios' });
    this.options = new RequestOptions({ headers: headers });
  }

  getNewsList(lang) {

    this.computeHeaders();
    return new Promise((resolve, reject) => {
      return this.http.get(Utils.WEBAPI_DOMAIN + "news?lang=" + lang, this.options)
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        },
          err => {
            console.log("getNewsList " + err);
          });
    });
  }
  getPromotionsList(lang) {

    this.computeHeaders();
    return new Promise((resolve, reject) => {
      return this.http.get(Utils.WEBAPI_DOMAIN + "promotions?lang=" + lang, this.options)
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        },
          err => {
            console.log("getNewsList " + err);
          });
    });
  }
  geOffersList(lang) {

    this.computeHeaders();
    return new Promise((resolve, reject) => {
      return this.http.get(Utils.WEBAPI_DOMAIN + "offers?lang=" + lang, this.options)
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        },
          err => {
            console.log("getNewsList " + err);
          });
    });
  }

  getBaseUrl() {
    return Utils.BASEURL;
  }
}
