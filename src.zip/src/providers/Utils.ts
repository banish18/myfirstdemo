export default class Utils {

  /** turn off below lines when building app for production or live */

  static CMS_WEBAPI_DOMAIN = "/api";
  static AA_WEBAPI_DOMAIN = "/ahliapi";
  static AA_WEBAPI_DOMAIN_2 = "/ahliapi2";
  static AA_WEBAPI_DOMAIN_3 = "/ahliapi3/";
  static WEBAPI_DOMAIN = "/api/";
  static VINKLIN_DOMAIN = "/vinklin";
  static BASEURL = "/api/";
  static MOCKY = "/mocky";

  /** turn on below lines when building app for production or live */
  
  // static CMS_WEBAPI_DOMAIN = "http://alahli.vinklin.club/";
  //// static AA_WEBAPI_DOMAIN = "http://151.253.172.11:8089";
  //// static AA_WEBAPI_DOMAIN_2 = "http://151.253.172.11:8096/";
  //// static AA_WEBAPI_DOMAIN_3 = "http://151.253.172.11:8091/";
  //// static WEBAPI_DOMAIN = "http://alahli.vinklin.club/";
  //// static VINKLIN_DOMAIN = "http://payaadc.vinklin.club";
  //// static BASEURL = "http://alahli.vinklin.club/storage/";
  //// static MOCKY = "http://www.mocky.io/v2/";


   // static CMS_WEBAPI_DOMAIN = "http://3.18.90.105/aadc_app/public/";
   //static AA_WEBAPI_DOMAIN = "http://151.253.172.11:8089";
   //static AA_WEBAPI_DOMAIN_2 = "http://151.253.172.11:8096/";
   //static AA_WEBAPI_DOMAIN_3 = "http://151.253.172.11:8091/";
   //static WEBAPI_DOMAIN = "http://3.18.90.105/aadc_app/public/";
   //static VINKLIN_DOMAIN = "http://payaadc.vinklin.club";
   //static BASEURL = "http://3.18.90.105/aadc_app/public/storage/";
   //static MOCKY = "http://www.mocky.io/v2/";

  static updateLocalStorage(secretInfo) {
    localStorage.setItem('secretToken', secretInfo);
  }

}