import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import Utils from './Utils';
/*
  Generated class for the CountryServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class StudentServiceProvider {

  faqsList: any;

  constructor(public http: Http) {
    console.log('Hello FaqsServiceProvider Provider');

  }

  getQuestionair(student_PID) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      // headers.append('Something'; "");
      this.http.get("http://www.mocky.io/v2/5c5ed9ee320000210140b425/?student_PID" + student_PID, { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }
  getStudentJourney(student_PID) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();

      let url = Utils.VINKLIN_DOMAIN + "/studentjourney/practical.json";
      //let url = Utils.AA_WEBAPI_DOMAIN_2 + "/api/studentjourney_info?studentid=" + student_PID;// + student_pid;

      this.http.get(url, { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  getRTAContent(lang) {
      console.log(lang);
    return new Promise((resolve, reject) => {
        let headers = new Headers();
        let url = Utils.CMS_WEBAPI_DOMAIN + "/api/user/rta/content?lang=" + lang + "&course_type=HB";
      this.http.get(url, { headers: headers })  
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }

  submitDocument(fd) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      headers.append("Content-Type", "application/json");
      headers.append("Authorization", "Bearer 5c5eeae47b19f");
      headers.append("client-id", "ios");

      this.http.post(Utils.AA_WEBAPI_DOMAIN + "/token", fd.toString(), { headers: headers })
        // this.http.post("http://www.mocky.io/v2/5c714b0b3500006300e9e7fc", body.toString(), { headers: headers })
        .map(res => res.json())
        .subscribe(data => {
          resolve(data);
        }, (err) => {
          reject(err);
        });
    });
  }
}

export class RTAContent {
  status: boolean;
  response: RTAResponse
}

export class RTAResponse {
  title: string;
  description: string;
  error: any;
}
export class OpenFile {
  status: number;
  StaticMessage: string;
}

export class MockTest {
  status: number;
  testId: any;
  Testname: string;
  Time: string;
  coursetype: string;
  Result: string;
  score: string;
  language: string;
  staticmessage: string; F
}

export class Practicle {
  status: number;
  TotalTrainings: string;
  extratraining: any;
  Attented_Training: string;
  Practicledet: {
    bookingId: any;
    Name: string;
    From_Time: string;
    To_time: string;
    Assigned_trainer: string;
    Assigned_trainerId: string;
    CourseType: string;
    Status: string;
  }
}

export class Thoery {
  status: number;
  TotalLectures: number;
  AttendedLectures: number;
  ExtraLectures: number;
  Attendance: Array<Attendance>;
  staticMessage: string;
}

export class Attendance {
  bookingID: string;
  Id: number;
  LectureName: string;
  FromTime: string;
  ToTime: string;
  CheckIn: string;
  CheckOut: string;
  Status: number;
  assignedTrainer: string;
  assignedTrainerId: number;
  courseType: string;
  Language: string;
  feedback: number;
  feedbackMessage: string;
}
export class Attempt {
  bookingID: string;
  id: number;
  LectureName: string;
  FromTime: string;
  ToTime: string;
  CheckIn: string;
  CheckOut: string;
  Status: number;
  assignedTrainer: string;
  assignedTraninerId: number;
  courseType: string;
  Language: string;
  feedback: number;
  feedbackMessage: string;
}
export class RTAKnowledgeTest {
  assignedTrainer: string;
  assignedTraninerId: number;
  courseType: string;
  Language: string;
  feedback: number;
  feedbackMessage: string;
  attempts: Array<Attempt>;
  staticMessage: string;
  status: number;
}
export class StudentJourneyResponse {

  OpenFile: OpenFile;
  Thoery: Thoery;
  MockTest: MockTest;
  RTAKnowledgeTest: RTAKnowledgeTest;
  PracticalSessions: PracticalSessions;
  SmartYardAssessmentTest: SmartYardAssessmentTest;
  SmartYardTest: SmartYardTest;
  PostPracticalSessions: PostPracticalSessions;
  RoadAssessmentTest: RoadAssessmentTest;
  RTARoadTest: RTARoadTest;
  RequestForLicence: RequestForLicence;
  // Practicle: 
}

export interface Session {
  BookingID: string;
  ID: number;
  Name: string;
  FromTime: string;
  ToTime: string;
  CheckIn: string;
  CheckOut: string;
  Status: number;
  assignedTrainer: string;
  assignedTrainerId: number;
  courseType: string;
  Language: string;
  feedback: number;
  feedbackMessage: string;
}

export interface PracticalSessions {
  status: number;
  TotalTrainings: number;
  ExtraTraining: number;
  AttendedTrainings: number;
  Sessions: Session[];
  staticMessage: string;
}

export interface SmartYardAssessmentTest {
  BookingID: string;
  status: number;
  TestID: number;
  TestName: string;
  Time: string;
  courseType: string;
  Result: number;
  Score: number;
  Language: string;
  staticMessage: string;
  attempts: Array<Attempt>;
}

export interface SmartYardTest {
  BookingID: string;
  status: number;
  TestID: number;
  TestName: string;
  Time: string;
  courseType: string;
  Result: number;
  Score: number;
  Language: string;
  staticMessage: string;
  attempts: Array<Attempt>;
}

export interface Session {
  BookingID: string;
  ID: number;
  Name: string;
  FromTime: string;
  ToTime: string;
  CheckIn: string;
  CheckOut: string;
  Status: number;
  assignedTrainer: string;
  assignedTrainerId: number;
  courseType: string;
  Language: string;
  feedback: number;
  feedbackMessage: string;
}

export interface PostPracticalSessions {
  status: number;
  TotalTrainings: number;
  ExtraTraining: number;
  AttendedTrainings: number;
  Sessions: Session[];
  staticMessage: string;
}

export interface RoadAssessmentTest {
  BookingID: string;
  status: number;
  TestID: number;
  TestName: string;
  Time: string;
  courseType: string;
  Result: number;
  Score: number;
  Language: string;
  staticMessage: string;
  feedback: number;
  feedbackMessage: string;
  attempts: Array<Attempt>;
}

export interface RTARoadTest {
  BookingID: string;
  status: number;
  TestID: number;
  TestName: string;
  Time: string;
  courseType: string;
  Result: any;
  Score: any;
  staticMessage: string;
  attempts: Array<Attempt>;
}

export interface RequestForLicence {
  file_no: string;
  status: number;
  courseType: string;
  learning_permit_no: number;
  staticMessage: string;
}

export interface RootObject {
  PostPracticalSessions: PostPracticalSessions;
  RoadAssessmentTest: RoadAssessmentTest;
  RTARoadTest: RTARoadTest[];
  RequestForLicence: RequestForLicence;
}


