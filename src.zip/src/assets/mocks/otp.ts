export let otp_response = {
  "status": 0,
  "staticMessage": "OTP Sent",
  "code": 9254

}
