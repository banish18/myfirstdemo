export let registrer_response = {
  "student_PID": 4,
  "status": 0,
  "message": "Welcome in Alahli driving center"
}
