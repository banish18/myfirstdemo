export let selected_exam_response = {
  "qstnanwer": [{
    "QuestionId": 442,
    "Question": "Why is it important to scan the road scene when you drive",
    "Audiopath": "rec0315-165140 -Q.mp3",
    "answer": [{
      "Answers": "You will develop good vehicle control.",
      "AnswersID": "1326"
    },
    {
      "Answers": "It will help you stay awake.",
      "AnswersID": "1325"
    },
    {
      "Answers": "You are more likely to anticipate potential     hazards.",
      "AnswersID": "1324"
    }
    ],
    "answerimg": [{
      "AnswerImgs": "noimage.png"
    },
    {
      "AnswerImgs": "noimage.png"
    },
    {
      "AnswerImgs": "noimage.png"
    }
    ],
    "answeraud": [{
      "AnswerAudios": "rec0315-165309.mp3"
    },
    {
      "AnswerAudios": "rec0315-165244.mp3"
    },
    {
      "AnswerAudios": "rec0315-165257 -CA.mp3"
    }
    ]
  },
  {
    "QuestionId": 82,
    "Question": "Looking at the diagram, if\r\nvehicle A stops now,\r\nvehicle B may crash into it.\r\nHow could the risk of a\r\ncrash like this be avoided?",
    "Audiopath": "rec0314-165534 -Q.mp3",
    "answer": [{
      "Answers": "Vehicle B overtakes vehicle A before the intersection.",
      "AnswersID": "246"
    },
    {
      "Answers": "Vehicle A speeds up to cross the intersection on the orange light.",
      "AnswersID": "245"
    },
    {
      "Answers": "Both vehicles need to travel at a speed   that will allow them to stop safely at an intersection",
      "AnswersID": "244"
    }
    ],
    "answerimg": [{
      "AnswerImgs": "noimage.png"
    },
    {
      "AnswerImgs": "noimage.png"
    },
    {
      "AnswerImgs": "noimage.png"
    }
    ],
    "answeraud": [{
      "AnswerAudios": "rec0314-165700.mp3"
    },
    {
      "AnswerAudios": "rec0314-165643.mp3"
    },
    {
      "AnswerAudios": "rec0314-165608 CA.mp3"
    }
    ]
  }
  ]
}
