export let upload_img_response = {
  "status": 1,
  "is_verfied": 1,
  "staticMessage": "Image Uploaded Successfully."
}
