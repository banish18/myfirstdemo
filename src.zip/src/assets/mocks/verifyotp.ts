export let verify_otp_response = {
  "status": 0,
  "staticMessage": "OTP is verifired",
  "is_verified": 1
}
