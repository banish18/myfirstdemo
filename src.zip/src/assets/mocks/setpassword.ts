export let setpassword_response = {
  "status": 1,
  "staticMessage": "Password set successfully",
  "is_verified": 1
}
