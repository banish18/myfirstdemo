export let response = {
  "GetExamTypes": [{
    "ExamId": "12",
    "Examtypename": "LMV-1 english"
  },
  {
    "ExamId": "20",
    "Examtypename": "LMV -2 english"
  },
  {
    "ExamId": "21",
    "Examtypename": "LMV -3 english"
  },
  {
    "ExamId": "22",
    "Examtypename": "LMV -4 english"
  },
  {
    "ExamId": "31",
    "Examtypename": "LMV-5 english"
  }
  ]
}
