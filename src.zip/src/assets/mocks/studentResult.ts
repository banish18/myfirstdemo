export let student_res_response = {
  "FileNo": "Fp317",
  "ExamId": "12",
  "Answer": [{
    "questionId": "32",
    "anserid": "94"
  }, {
    "questionId": "33",
    "anserid": "97"
  }, {
    "questionId": "34",
    "anserid": "100"
  }, {
    "questionId": "35",
    "anserid": "103"
  }, {
    "questionId": "36",
    "anserid": "106"
  }, {
    "questionId": "37",
    "anserid": "109"
  }, {
    "questionId": "38",
    "anserid": "112"
  }, {
    "questionId": "39",
    "anserid": "115"
  }, {
    "questionId": "40",
    "anserid": "118"
  }, {
    "questionId": "41",
    "anserid": "121"
  }, {
    "questionId": "42",
    "anserid": "124"
  }]
}
