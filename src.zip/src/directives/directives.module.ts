import { NgModule } from '@angular/core';
import { ParallaxHeaderDirective } from './parallax-header/parallax-header';
import { HideHeaderDirective } from './hide-header/hide-header';
import { SwipeSegmentDirective } from './swipe-segment/swipe-segment';
@NgModule({
	declarations: [ParallaxHeaderDirective,
    HideHeaderDirective,
    SwipeSegmentDirective],
	imports: [],
	exports: [ParallaxHeaderDirective,
    HideHeaderDirective,
    SwipeSegmentDirective]
})
export class DirectivesModule {}
