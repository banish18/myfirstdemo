import { Directive, Input, ElementRef, Renderer } from '@angular/core';
/**
 * Generated class for the HideHeaderDirective directive.
 *
 * See https://angular.io/api/core/Directive for more info on Angular
 * Directives.
 */
@Directive({
  selector: '[hide-header]', // Attribute selector
  host: {
    '(ionScroll)': 'onContentScroll($event)'
  }
})
export class HideHeaderDirective {

  @Input("header") header: HTMLElement;
  headerHeight;
  scrollContent;
  slideContent;
  headerBgImage;
  ticking: any;

  constructor(public element: ElementRef, public renderer: Renderer) {

    console.log('Hello HideHeaderDirective Directive');
  }

  ngOnInit() {
    this.ticking = false;
    this.headerHeight = this.header.clientHeight;
    console.log(this.headerHeight);
    this.renderer.setElementStyle(this.header, 'webkitTransition', 'top 700ms');
    this.scrollContent = this.element.nativeElement.getElementsByClassName("toolbar-content")[0];
    this.renderer.setElementStyle(this.scrollContent, 'webkitTransition', 'margin-top 700ms');
    this.renderer.setElementStyle(this.scrollContent, 'height', '100px');
    this.slideContent = this.element.nativeElement.getElementsByClassName("contentToScroll");   
    this.ticking = true;

  }

  onContentScroll(event) {
    console.log("this.onContentScroll "+event.scrollTop);
    if (event.scrollTop > 56) {
      this.renderer.setElementStyle(this.header, "top", "0px")
      this.renderer.setElementStyle(this.scrollContent, "margin-top", "0px")
      // this.renderer.setElementStyle(this.)
    } else {
      this.renderer.setElementStyle(this.header, "top", "0px");
      this.renderer.setElementStyle(this.scrollContent, "margin-top", "0px")
    }
  }

}
