export let QUESTIONS = {
  "file_no": "MB123321",
  "questions": [
    {
      "type": "switch",
      "questionid": 1,
      "question": "Do you have a driving license?",
      "options": [
        {
          "true": [
            {
              "answer": true
            },
            {
              "type": "textbox",
              "questionid": 2,
              "question": "Which country?",
              "anwer": ""
            },
            {
              "type": "textbox",
              "questionid": 3,
              "question": "How long have you been holding it(years)?",
              "answer": ""
            },
            {
              "type": "textbox",
              "questionid": 3,
              "question": "Which Category?",
              "answer": ""
            }
          ],
          "false": [
            {
              "answer": false
            }
          ]
        }
      ]
    },
    {
      "type": "switch",
      "questionid": 4,
      "question": "Do you have Residence Visa Dubai?",
      "options": [
        {
          "true": [
            {
              "answer": false
            }
          ],
          "false": [
            {
              "answer": true
            },
            {
              "type": "textbox",
              "questionid": 5,
              "question": "If No Specify other Emirates Residence that you have",
              "answer": "Sharjah"
            }
          ]
        }
      ]
    },
    {
      "type": "combo box",
      "answer": "",
      "questionid": 6,
      "question": "What kid of category you want to apply?",
      "options": [
        "LMV(a)",
        "LMV",
        "HT",
        "LB"
      ]
    }
  ]
};
