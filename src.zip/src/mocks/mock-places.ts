export let NEWS = [
    {
        id: 1,
        title: "AWARDS",
        desc: "Al Ahli Driving Center has been achieved several awards and certificates in recognition of its unique success in Driving Licensing services, We have achieved Awards / Certificates in Partner’s Performance Management System, Quality, Health & Safety, Environment, Energy, Road Traffic Safety & information security Management system and now RTA’s Partner Relationship Management Stars creativity, innovation and excellence. This “Window” has been launched to include outstanding international awards and certificates achieved to ADC",
        image: "https://alahlidubai.ae/assets/images/sample8.jpg"
    },
    {
        id: 2,
        title: "SERVICE PERFORMANCE AWARD",
        desc: "Al Ahli Driving Center has been achieved several awards and certificates in recognition of its unique success in Driving Licensing services, We have achieved Awards / Certificates in Partner’s Performance Management System, Quality, Health & Safety, Environment, Energy, Road Traffic Safety & information security Management system and now RTA’s Partner Relationship Management Stars creativity, innovation and excellence. This “Window” has been launched to include outstanding international awards and certificates achieved to ADC",
        image: "https://alahlidubai.ae/assets/images/collage2.JPG"
    },
    {
        id: 3,
        title: "RTA AWARDS",
        desc: "Al Ahli Driving Center has been achieved several awards and certificates in recognition of its unique success in Driving Licensing services, We have achieved Awards / Certificates in Partner’s Performance Management System, Quality, Health & Safety, Environment, Energy, Road Traffic Safety & information security Management system and now RTA’s Partner Relationship Management Stars creativity, innovation and excellence. This “Window” has been launched to include outstanding international awards and certificates achieved to ADC",
        image: "https://alahlidubai.ae/assets/images/sample9.jpg"
    },
    {
        id: 4,
        title: "ABCD AWARDS",
        desc: "Al Ahli Driving Center has been achieved several awards and certificates in recognition of its unique success in Driving Licensing services, We have achieved Awards / Certificates in Partner’s Performance Management System, Quality, Health & Safety, Environment, Energy, Road Traffic Safety & information security Management system and now RTA’s Partner Relationship Management Stars creativity, innovation and excellence. This “Window” has been launched to include outstanding international awards and certificates achieved to ADC",
        image: "https://alahlidubai.ae/assets/images/3.JPG"
    },
    {
        id: 5,
        title: "DED AWARDS",
        desc: "Al Ahli Driving Center has been achieved several awards and certificates in recognition of its unique success in Driving Licensing services, We have achieved Awards / Certificates in Partner’s Performance Management System, Quality, Health & Safety, Environment, Energy, Road Traffic Safety & information security Management system and now RTA’s Partner Relationship Management Stars creativity, innovation and excellence. This “Window” has been launched to include outstanding international awards and certificates achieved to ADC",
        image: "https://alahlidubai.ae/assets/images/sample8.jpg"
    },
    {
        id: 6,
        title: "DRIVING AWARDS",
        desc: "Al Ahli Driving Center has been achieved several awards and certificates in recognition of its unique success in Driving Licensing services, We have achieved Awards / Certificates in Partner’s Performance Management System, Quality, Health & Safety, Environment, Energy, Road Traffic Safety & information security Management system and now RTA’s Partner Relationship Management Stars creativity, innovation and excellence. This “Window” has been launched to include outstanding international awards and certificates achieved to ADC",
        image: "https://alahlidubai.ae/assets/images/collage2.JPG"
    }
]


