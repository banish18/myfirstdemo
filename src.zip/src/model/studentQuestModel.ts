export class StudentQuestModel {

    StudentQuestModel() { }
    q1: string;
    q2: string = "";
    q3: number = 0;
    q4: string;
    q5: string;
    q6: string;
    q7: string;
    q8: string;
    q9: string;
    q10: string;
    q11: string;
    q12: string;
    q13: string;
    q14: string;
    q15: string;
}

export class QuestionairResponseModel {
    questions: Array<StudentQuestResponseModel>;
}

export class StudentQuestResponseModel {

    StudentQuestResponseModel() { }

    type: string;
    questionid: string;
    question: string;
    options: any[];
    answer: string;
}