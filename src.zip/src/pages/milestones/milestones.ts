import { Component, ViewChild } from '@angular/core';
import { NavController, Content } from 'ionic-angular';

@Component({
  selector: 'page-milestones',
  templateUrl: 'milestones.html'
})
export class MilestonesPage {
  @ViewChild(Content) content: Content;

  items = [
    {
      title: 'Courgette daikon',
      content: 'Parsley amaranth tigernut silver beet maize fennel spinach. Ricebean black-eyed pea maize scallion green bean spinach cabbage jícama bell pepper carrot onion corn plantain garbanzo. Sierra leone bologi komatsuna celery peanut swiss chard silver beet squash dandelion maize chicory burdock tatsoi dulse radish wakame beetroot.',
      icon: 'calendar',
      time: {subtitle: '4/16/2013', title: '21:30'},
      status: "nonActive"
    },
    {
      title: 'RTA Theory TEST',
      content: 'Congratulations!! Omer Raza <br> You have passed this test.',
      icon: 'md-car',
      time: {title: 'Short Text', subtitle: '9, Sept 2018'},
      status: "Active"
    },
    {
      title: 'Courgette daikon',
      content: 'Parsley amaranth tigernut silver beet maize fennel spinach. Ricebean black-eyed pea maize scallion green bean spinach cabbage jícama bell pepper carrot onion corn plantain garbanzo. Sierra leone bologi komatsuna celery peanut swiss chard silver beet squash dandelion maize chicory burdock tatsoi dulse radish wakame beetroot.',
      icon: 'calendar',
      time: {title: 'Short Text'},
      status: "nonActive"
    },
    {
      title: 'Courgette daikon',
      content: 'Parsley amaranth tigernut silver beet maize fennel spinach. Ricebean black-eyed pea maize scallion green bean spinach cabbage jícama bell pepper carrot onion corn plantain garbanzo. Sierra leone bologi komatsuna celery peanut swiss chard silver beet squash dandelion maize chicory burdock tatsoi dulse radish wakame beetroot.',
      icon: 'calendar',
      time: {title: 'Short Text'},
      status: "nonActive"
    },
    {
      title: 'Courgette daikon',
      content: 'Parsley amaranth tigernut silver beet maize fennel spinach. Ricebean black-eyed pea maize scallion green bean spinach cabbage jícama bell pepper carrot onion corn plantain garbanzo. Sierra leone bologi komatsuna celery peanut swiss chard silver beet squash dandelion maize chicory burdock tatsoi dulse radish wakame beetroot.',
      icon: 'calendar',
      time: {title: 'Short Text'},
      status: "nonActive"
    },
    {
      title: 'Assesesment Test',
      content: 'Al Ahli Assesmetn Test..',
      icon: 'calendar',
      time: {title: 'Internal Assessment'},
      status: "nonActive"
    },
    {
      title: 'RTA FINAL TEST',
      content: 'Roads and Transport Authority (RTA) provides a number of services that can be booked To find an appointment that suites your schedule, please complete the following steps. Also note that the following Terms and Conditions must be agreed to before any booking can be made. .',
      icon: 'ios-car',
      time: {title: 'RTA Road Test'},
      status: "nonActive"
    }
  ]
  constructor(public navCtrl: NavController) {
  }
  ionViewDidEnter() {
    this.content.scrollToBottom();
    setTimeout( () => {
      this.scrollTo("Active");
    }, 2000); 
  }

  scrollTo(element:string) {
    let yOffset = document.getElementById(element).offsetTop;
    this.content.scrollTo(0, yOffset, 4000)
  }
}
