import { Component, ViewChild } from '@angular/core';
import { NavController, Slides, Content, MenuController, Platform, ToastController } from 'ionic-angular';
import { CategoryModel } from './categorymodel';
import { DrawerState } from '../../../node_modules/ion-bottom-drawer';
import { BookingPage } from '../booking/booking';
import { StudentServiceProvider, StudentJourneyResponse } from '../../providers/student-service';
import { MockTestQuestionairePage } from '../mock-test-questionaire/mock-test-questionaire';
import { ContactusPage } from '../contactus/contactus';

/**
 * Generated class for the DashboardPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-dashboard',
  templateUrl: 'dashboard.html',
})


export class DashboardPage {
  @ViewChild(Slides) slides: Slides;
  @ViewChild(Content) content: Content;
  @ViewChild('scroll') scroll: any;

  PASS = 9;
  FAIL = 10;
  COMPLETE = 16;

  public selectedCategory: any;
  public category: CategoryModel;
  public showLeftButton: boolean;
  public showRightButton: boolean;

  shouldBounce = true;
  disableDrag = true;
  currentSlider = 0;
  dockedHeight = 100;
  bounceThreshold = 500;
  activeCategoryId: any;
  distanceTop = 56;
  drawerState = DrawerState.Docked;
  states = DrawerState;
  minimumHeight = 200;
  // theoryStatus = 16;
  mockStatus: any;
  // footerState: IonPullUpFooterState;
  upcomingEvents = [];
  section: string = 'two';
  somethings: any = new Array;
  stagesArray: any = [];
  student_PID: number;

  TheoryAttendanceArray: any[] = [];
  RTAKnowledgeTestAttemptsArray: any[] = [];
  PracticalSessionsArray: any[] = [];

  studentJourneyResponse: StudentJourneyResponse = new StudentJourneyResponse();

  constructor(public navCtrl: NavController, public toastCtrl: ToastController,
    public menuCtrl: MenuController, public platform: Platform,
    public service: StudentServiceProvider) {
    // this.footerState = IonPullUpFooterState.Collapsed;
    // this.menuCtrl.enable(true, "ahlimenu");
    this.menuCtrl.enable(true, "ahlimenu");
    this.menuCtrl.swipeEnable(true, "ahlimenu");
    this.dockedHeight = platform.height() / 3;
    this.student_PID = parseInt(localStorage.getItem('student_PID'));
    // this.student_PID = 2;
    if (this.student_PID !== null && this.student_PID !== 0) {
      
      this.service.getStudentJourney(this.student_PID).then(response => {
        console.log("getStudentJourney");
        this.studentJourneyResponse = Object.assign(this.studentJourneyResponse, response);
        //       this.studentJourneyResponse.PracticalSessions.status = 16;
        //  this.studentJourneyResponse.Thoery.status = 14;
        // this.studentJourneyResponse.RTAKnowledgeTest.status = 14;
        if (this.studentJourneyResponse.RTAKnowledgeTest.status == 14) {
          this.upcomingEvents = [];
        }

        // this.theoryStatus = 14;
        // this.studentJourneyResponse.MockTest.status = 14;
        // this.studentJourneyResponse.PracticalSessions.status = 16;

        console.log(this.studentJourneyResponse);

        this.loadSteps();
      });
    }
  }


  private initializeCategories(): void {
    // Select it by defaut
    this.selectedCategory = this.stagesArray[0];

    // Check which arrows should be shown
    this.showLeftButton = false;
    if (this.stagesArray.length > 3) {
      this.showRightButton = true;
    } else {
      this.showRightButton = false;
    }
  }

  // Method executed when the slides are changed
  public slideChanged(): void {
    // let currentIndex = this.slides.getActiveIndex();
    // this.showLeftButton = currentIndex !== 0;
    // this.showRightButton = currentIndex !== Math.ceil(this.slides.length() / 3);
  }

  // Method that shows the next slide
  public slideNext(): void {
    this.slides.slideNext();
  }

  // Method that shows the previous slide
  public slidePrev(): void {
    this.slides.slidePrev();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DashboardPage');
    //  this.slides.slideTo(2, 2000);
  }
  ngAfterViewInit() {
    this.initializeCategories();

  }
  moveToMockTest() {
    this.navCtrl.push(MockTestQuestionairePage);
  }

  ionViewDidEnter() {
    // this.slides.update();
    // this.slides.slideTo(6);
  }

  loadSteps() {
      
    this.stagesArray = [
      {
        id: 0,
        title: "Theory Test",
        passedicon: "custom-flag",
        icon: "custom-theory-test",
        active: this.getStatus(this.studentJourneyResponse.Thoery.status, 0),
        // isHide: this.studentJourneyResponse.Thoery.
      },
      {
        id: 1,
        title: "Mock Test",
        passedicon: "custom-flag",
        icon: "custom-theory-test",
        active: this.getStatus(this.studentJourneyResponse.MockTest.status, 1)
      },
      {
        id: 2,
        title: "RTA Knowledge Test",
        passedicon: "custom-flag",
        icon: "custom-sterring",
        active: this.getStatus(this.studentJourneyResponse.RTAKnowledgeTest.status, 2)
      },
      {
        id: 3,
        title: "Practical Sessions",
        passedicon: "custom-flag",
        icon: "custom-parking-sign",
        active: this.getStatus(this.studentJourneyResponse.PracticalSessions.status, 3)
      },
      {
        id: 4,
        title: "Smart Yard Assesment Test",
        passedicon: "custom-flag",
        icon: "custom-car",
        active: this.getStatus(this.studentJourneyResponse.SmartYardAssessmentTest.status, 4)
      },
      {
        id: 5,
        title: "Smart Yard Test",
        passedicon: "custom-flag",
        icon: "custom-sterring",
        active: this.getStatus(this.studentJourneyResponse.SmartYardTest.status, 5)
      },
      {
        id: 6,
        title: "Post Practical Sessions",
        passedicon: "custom-flag",
        icon: "custom-sterring",
        active: this.getStatus(this.studentJourneyResponse.PostPracticalSessions.status, 6)
      },
      {
        id: 7,
        title: "Road Assesment Test",
        passedicon: "custom-flag",
        icon: "custom-sterring",
        active: this.getStatus(this.studentJourneyResponse.RoadAssessmentTest.status, 7)
      },
      {
        id: 8,
        title: "RTA Road Test",
        passedicon: "custom-flag",
        icon: "custom-sterring",
        active: this.getStatus(this.studentJourneyResponse.RTARoadTest.status, 8)
      }
    ];

    this.TheoryAttendanceArray = this.studentJourneyResponse.Thoery.Attendance;
    this.RTAKnowledgeTestAttemptsArray = this.studentJourneyResponse.RTAKnowledgeTest.attempts;
    this.PracticalSessionsArray = this.studentJourneyResponse.PostPracticalSessions.Sessions;

    // let mainStages = Object.keys(this.studentJourneyResponse);

    let index = 0;
    for (let i = 0; i < this.stagesArray.length; i++) {
      if (this.stagesArray[i].active == "active-slide") {
        index = i;
        break;
      }
    }
    setTimeout(() => {
      this.slides.slideTo(index, 500);
    }, 500);
    if (this.content) {
      console.log("Footer height: " + this.content.contentBottom);
    }
  }

  ionViewWillEnter() {
    console.log("Active Slide " + this.slides.getActiveIndex());

  }



  getStatus(statusCode: number, slide) {
    let response = "";
    switch (statusCode) {
      case 14:
        this.activeCategoryId = slide;
        this.filterData(slide, true);
        response = "active-slide";
        break;
      case 16:
        response = "completed";
        break;
      case 17:
        response = "hide";
      default:
        response = "";
        break;
    }
    return response;
  }
  notficatoins() {

  }
  scrollRight() {
    this.scroll.scrollElement.scrollLeft = 500;
  }

  footerExpanded() {
    this.somethings = new Array(10);
    console.log('Footer expanded!');
  }

  footerCollapsed() {
    console.log('Footer collapsed!');
    this.somethings = new Array();
    this.somethings = new Array(1);
  }

  booking() {
      console.log(this.currentSlider)
    if (this.currentSlider == 0) {
      this.navCtrl.push(BookingPage, {
        type: 0
      });
    }
    if (this.currentSlider == 2) {
      this.navCtrl.push(BookingPage, {
        type: 2
      });
    }
    if (this.currentSlider == 3) {
      this.navCtrl.push(BookingPage, {
        type: 3
      });
    }
    if (this.currentSlider == 4) {
      this.navCtrl.push(BookingPage, {
        type: 4
      });
    }
    if (this.currentSlider == 5) {
      this.navCtrl.push(BookingPage, {
        type: 5
      });
    }
    if (this.currentSlider == 6) {
      this.navCtrl.push(BookingPage, {
        type: 6
      });
    }
    if (this.currentSlider == 7) {
      this.navCtrl.push(BookingPage, {
        type: 7
      });
    }
    if (this.currentSlider == 8) {
      this.navCtrl.push(BookingPage, {
        type: 8
      });
    }
  }

  public filterData(categoryId: number, isActive): void {
    if (categoryId <= this.activeCategoryId) {
      this.currentSlider = categoryId;
      this.mockStatus = 16;
      // let currentIndex = this.slides.getActiveIndex();
      console.log("filterData " + categoryId);
      if (categoryId == 0) {
        this.upcomingEvents = this.studentJourneyResponse.Thoery.Attendance;
      }
      if (categoryId == 1) {
        this.upcomingEvents = [];
        this.mockStatus = 14;
      }
      if (categoryId == 2) {
        this.upcomingEvents = this.studentJourneyResponse.RTAKnowledgeTest.attempts;
      }
      if (categoryId == 3) {
        this.upcomingEvents = this.studentJourneyResponse.PracticalSessions.Sessions;
      }
      if (categoryId == 4) {
        this.upcomingEvents = this.studentJourneyResponse.SmartYardAssessmentTest.attempts;
      }
      if (categoryId == 5) {
        this.upcomingEvents = this.studentJourneyResponse.SmartYardTest.attempts;
      }
      if (categoryId == 6) {
        this.upcomingEvents = this.studentJourneyResponse.PostPracticalSessions.Sessions;

      }
      if (categoryId == 6) {
        this.upcomingEvents = this.studentJourneyResponse.PostPracticalSessions.Sessions;
      }
      if (categoryId == 7) {
        this.upcomingEvents = this.studentJourneyResponse.RoadAssessmentTest.attempts;
      }
      if (categoryId == 8) {
        this.upcomingEvents = this.studentJourneyResponse.RTARoadTest.attempts;
      }
    }
    else {
      this.presentToast("This Event is Locked.");
    }
  }

  presentToast(msg) {
    let toast = this.toastCtrl.create({
      message: msg,
      duration: 3000,
      position: 'bottom'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }

  toggleFooter() {
    this.drawerState = ((this.drawerState == 2) ? 1 : 2);
    if (this.drawerState == 1) {
      this.footerCollapsed();
    } else {
      this.footerExpanded();
    }
  }

  getMaximumHeight() {
    return window.innerHeight / 2.5;
  }

  contactUs() {
      this.navCtrl.push(ContactusPage);
  }

}
