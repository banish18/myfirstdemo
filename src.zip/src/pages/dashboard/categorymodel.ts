
export class CategoryModel {
    public id: number;
    public name:any;
  
    constructor(){

    }
  }