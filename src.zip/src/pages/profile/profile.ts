import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { HomePage } from '../home/home';
import { SignupPage } from '../signup/signup';
import { LoginPage } from '../login/login';
import { ScheduleRoadAssessmentTestPage } from '../schedule-road-assessment-test/schedule-road-assessment-test';
import { ScheduleRTARoadTestPage } from '../schedule-rtaroad-test/schedule-rtaroad-test';
import { ScheduleYardAssessmentTestPage } from '../schedule-yard-assessment-test/schedule-yard-assessment-test';
import { ScheduleRTAYardTestPage } from '../schedule-rtayard-test/schedule-rtayard-test';
import { MilestonesPage } from '../milestones/milestones';

@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html'
})
export class ProfilePage {

  constructor(public navCtrl: NavController) {
  }
  goToHome(params){
    if (!params) params = {};
    this.navCtrl.push(HomePage);
  }goToSignup(params){
    if (!params) params = {};
    this.navCtrl.push(SignupPage);
  }goToLogin(params){
    if (!params) params = {};
    this.navCtrl.push(LoginPage);
  }goToScheduleRoadAssessmentTest(params){
    if (!params) params = {};
    this.navCtrl.push(ScheduleRoadAssessmentTestPage);
  }goToScheduleRTARoadTest(params){
    if (!params) params = {};
    this.navCtrl.push(ScheduleRTARoadTestPage);
  }goToScheduleYardAssessmentTest(params){
    if (!params) params = {};
    this.navCtrl.push(ScheduleYardAssessmentTestPage);
  }goToScheduleRTAYardTest(params){
    if (!params) params = {};
    this.navCtrl.push(ScheduleRTAYardTestPage);
  }goToMilestones(params){
    if (!params) params = {};
    this.navCtrl.push(MilestonesPage);
  }goToProfile(params){
    if (!params) params = {};
    this.navCtrl.push(ProfilePage);
  }
}
