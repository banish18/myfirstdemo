import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FacadeService } from '../../providers/FacadeService';
import { Utility } from '../../providers/utility';
import { YourTrainerPage } from '../your-trainer/your-trainer';
/**
 * Generated class for the TrainersPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-trainers',
  templateUrl: 'trainers.html',
})
export class TrainersPage {
    trainersList = [];
    baseUrl: string = '';
  constructor(public navCtrl: NavController,
    private utility: Utility,
    public navParams: NavParams, public facadeService: FacadeService) {
      this.baseUrl = localStorage.getItem("BaseURL");
      this.utility.showLoader();
      //this.facadeService.trainersInfo("en").subscribe(
      //    res => {
      //        this.utility.dismissLoader();
      //        this.trainersList = res.response;
      //    },
      //    err => {
      //        this.utility.dismissLoader();
      //    }
      //);

      let body = {
          'user_id': localStorage.getItem("student_PID"),
          'lang': localStorage.getItem("lang")
      };
      console.log(body)
      this.facadeService.trainersByUserID(body).subscribe(
          res => {
              console.log(res.response)
        this.utility.dismissLoader();
        this.trainersList = res.response;
      },
      err => {
        this.utility.dismissLoader();
      }
    );
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TrainersPage');
  }

  trainerInfo(trainer) {   
      console.log(trainer)   
      this.navCtrl.push(YourTrainerPage, { trainer: trainer });
  }

}
