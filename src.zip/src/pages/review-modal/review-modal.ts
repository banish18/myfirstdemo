import { Component } from '@angular/core';
import { NavController, Events, ModalController, ViewController, AlertController, NavParams } from 'ionic-angular';
import { FacadeService } from '../../providers/FacadeService';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Utility } from '../../providers/utility';

/**
 * Generated class for the ReviewModalPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-review-modal',
  templateUrl: 'review-modal.html',
})
export class ReviewModalPage {
    reviewForm: FormGroup;
    reviewMessage: string;
    userID: string;
    trainerID: string;
    rating: string;
  constructor(public navCtrl: NavController,
    public events: Events,
    public modalCtrl: ModalController, public fb: FormBuilder,
    public viewCtrl: ViewController, public service: FacadeService, private utility: Utility, public alertCtrl: AlertController, public navParams: NavParams) {
      events.subscribe('star-rating:changed', (starRating) => {
          console.log(starRating)
          this.rating = starRating;
      });   
      this.trainerID = this.navParams.get('trainerID');    
      this.reviewForm = this.fb.group({
          reviewMessage: new FormControl('', Validators.required)     
    });
  }
  cancel() {
    this.viewCtrl.dismiss();
  }

  submitReview() {
      if (!this.reviewForm.valid) {
          this.errorAlert("Please complete the form.");
          return;
      }
      let body = {
          user_id: localStorage.getItem("student_PID"),
          driver_id: this.trainerID,
          review: this.reviewForm.controls.reviewMessage.value,
          rating: this.rating
      }
      console.log(body)
      this.utility.showLoader();
      this.service.addReview(body).subscribe(
          res => {
              this.utility.dismissLoader();
              console.log(res);
              if (res.status == true) {
                  this.presentAlert("Your review has been submitted successfully.");
              }            
          },
          err => {
              this.utility.dismissLoader();
          }
      );
    this.viewCtrl.dismiss();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ReviewModalPage');
  }


  presentAlert(msg) {
      let alert = this.alertCtrl.create({
          title: 'Information Successfully Sent',
          subTitle: msg,
          buttons: [{
              text: 'OK',
              handler: () => {
              }
          }]
      });
      alert.present();
  }

  errorAlert(msg) {
      let alert = this.alertCtrl.create({
          title: 'Error',
          subTitle: msg,
          buttons: [{
              text: 'OK',
              handler: () => {
              }
          }]
      });
      alert.present();
  }
}
