import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChatareaPage } from './chatarea';

@NgModule({
  declarations: [
    ChatareaPage,
  ],
  imports: [
    IonicPageModule.forChild(ChatareaPage),
  ],
})
export class ChatareaPageModule {}
