import { Component } from '@angular/core';
import { TrainerServiceProvider } from '../../providers/trainer-service';
import { FacadeService } from '../../providers/FacadeService';
import { NavController, NavParams, ModalController, AlertController } from 'ionic-angular';
import { EventModalPage } from '../event-modal/event-modal';
/**
 * Generated class for the ChangeTrainerPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-change-trainer',
  templateUrl: 'change-trainer.html',
})
export class ChangeTrainerPage {
    trainerInfo: any = {};
    trainerList: any[];    
    searchTerm: string = '';
    baseUrl: string = '';
    userID: string = '';
    public ver = false;
  constructor(public navCtrl: NavController, public navParams: NavParams,
    public service: TrainerServiceProvider, public modalCtrl: ModalController,
    public alertCtrl: AlertController, public facadeService: FacadeService) {
      this.baseUrl = localStorage.getItem("BaseURL");
      this.userID = localStorage.getItem("student_PID");
      let data = this.navParams.get('trainer');           
      this.trainerInfo = data;
      let actionType = localStorage.getItem("search");
      if (actionType == "true") {
          console.log("search")
          localStorage.removeItem("search");
          let body = {
              'trainer_id': data.instructor_id,
              'language': data.lang,
              'branch_id': data.branch_id,
              'lang': localStorage.getItem("lang")             
          };
          console.log(body)
          this.facadeService.searchTrainer(body).subscribe(
              res => {
                  console.log(res.response)
                  this.trainerList = res.response;
                  if (res.response.length == 0) {
                      this.ver = true;
                  }
                  else {
                      this.ver = false;
                  }
              },
              err => {
              }
          );
      }
      else {
          console.log("normal")
          let body = {
              'trainer_id': data.instructor_id,
              'lang': localStorage.getItem("lang")
          };
          console.log(body)
          this.facadeService.trainers(body).subscribe(
              res => {
                  console.log(res.response)
                  this.trainerList = res.response;
              },
              err => {
              }
          );
      } 
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ChangeTrainerPage');
  }

  setFilteredItems() {
      if (this.searchTerm != "") {
          this.filterItems(this.searchTerm);
      }
      else {
          let data = this.navParams.get('trainer');      
          let body = {};
          if (data.branch_id != undefined) {
              body = {
                  'trainer_id': data.instructor_id,
                  'language': data.lang,
                  'branch_id': data.branch_id,
                  'lang': localStorage.getItem("lang")
              };
              this.facadeService.searchTrainer(body).subscribe(
                  res => {
                      console.log(res.response)
                      this.trainerList = res.response;
                      if (res.response.length == 0) {
                          this.ver = true;
                      }
                      else {
                          this.ver = false;
                      }
                  },
                  err => {
                  }
              );        
          }
          else {
              body = {
                  'trainer_id': data.instructor_id,
                  'lang': localStorage.getItem("lang")
              };
          }          
          console.log(body)
          this.facadeService.trainers(body).subscribe(
              res => {
                  console.log(res.response)
                  this.trainerList = res.response;
                  if (res.response.length == 0) {
                      this.ver = true;
                  }
                  else {
                      this.ver = false;
                  }
              },
              err => {
              }
          );
      }
  }

  clearSearch() {
      this.searchTerm = "";
  }

  filterItems(searchTerm) {
      this.trainerList = this.trainerList.filter((item) => {
          return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
      });
  }

  //setFilteredItems() {
  //    this.trainerList = this.service.filterItems(this.searchTerm);
  //    return this.trainerList.filter((item) => {
  //        return (item.Name.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1) || (item.language.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1);
  //    });
  //}

  openFilter() {
      let modal = this.modalCtrl.create(EventModalPage, {
      // selectedDay: this.selectedDay 
          trainer: this.trainerInfo
    });
    modal.present();
    modal.onDidDismiss(data => {
      if (data) {
      }
    });
  }

  confirmTrainer(oldTrainer, newTrainer) {   
    let alert = this.alertCtrl.create({
      title: 'CHANGE TRAINER',
      message: 'Are you sure you want to change your trainer \'"' + oldTrainer.title + '"\' to ' + newTrainer.title + ' ?',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          handler: () => {
              console.log('Cancel clicked');             
          }
        },
        {
          text: 'Confirm',
          handler: () => {
              console.log('Buy clicked');
              let userID = localStorage.getItem("student_PID");
              let newTrainerID = newTrainer.id;
              let newTrainerName = newTrainer.title;
              let body = {  
                  'user_id': userID,
                  'instructor_id': newTrainerID,
                  'instructor_name': newTrainerName
              };          

              console.log(body)                 
              this.facadeService.changeTrainer(body).subscribe(
                  res => {
                      console.log(res.response)
                      if (res.status == true) {
                          this.presentAlert("Your request have been sent successfully.");
                      }
                      else {
                          this.errorAlert(res.response);
                      }
                  },
                  err => {
                  }
              );   
          }
        }
      ]
    });
    alert.present();
  }

  presentAlert(msg) {
      let alert = this.alertCtrl.create({
          title: 'Information Successfully Sent',
          subTitle: msg,
          buttons: [{
              text: 'OK',
              handler: () => {
              }
          }]
      });
      alert.present();
  }

  errorAlert(msg) {
      let alert = this.alertCtrl.create({
          title: 'Error',
          subTitle: msg,
          buttons: [{
              text: 'OK',
              handler: () => {
              }
          }]
      });
      alert.present();
  }
 }
