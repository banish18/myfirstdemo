import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { NewsServiceProvider } from '../../providers/news-service';
import { NewsDetailPage } from '../news-detail/news-detail';
import { FacadeService } from '../../providers/FacadeService';
import { Utility } from '../../providers/utility';

/**
 * Generated class for the TabPageNewsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-tab-page-news',
  templateUrl: 'tab-page-news.html',
})
export class TabPageNews {

  newsList = [];

  constructor(public navCtrl: NavController, public facadeService: FacadeService,
    private utility: Utility,
    public navParams: NavParams, public service: NewsServiceProvider) {

    this.utility.showLoader();
    this.facadeService.getnews(localStorage.getItem("lang")).subscribe((res: any) => {
      console.log(res);
      this.utility.dismissLoader();
      this.newsList = res.response;
    }, err => {
      this.utility.dismissLoader();
      console.error('ERROR', err);
    });

    //  this.newsList =  this.service.getNewsList();
    console.log(this.newsList);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TabPageNewsPage');
  }

  newsDetail(news) {
    this.navCtrl.parent.parent.push(NewsDetailPage, { news: news });
  }
}
