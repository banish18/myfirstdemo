import { Component } from '@angular/core';
import { NavController, AlertController, ModalController, NavParams, ToastController } from 'ionic-angular';
import * as moment from 'moment';
import { EventModalPage } from '../event-modal/event-modal';
import { FacadeService } from '../../providers/FacadeService';
// import { EventModalPage } from '../event-modal/event-modal';
/**
 * Generated class for the BookingPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-booking',
  templateUrl: 'booking.html',
})
export class BookingPage {
  eventSource = [];
  viewTitle: string;
  selectedDay = new Date();
  timeArr: any[] = [];
  currenttype: any;
  selectedBranch: string;
  time: string = "08:00";
  availableBranches: any[] = [];
  schedules = [];
  calendar = {
    mode: 'month',
    currentDate: new Date()
  };

  minutes: any;



  constructor(public navCtrl: NavController, private alertCtrl: AlertController,
    private modalCtrl: ModalController, public navParams: NavParams,public toastCtrl: ToastController,
    public facadeService: FacadeService) {
    this.availableTimeSlot();
    localStorage.setItem('lang', 'en');
    this.availableBranch();
    this.currenttype = this.navParams.get('type');

    // this.eventSource.push({
    //   title: 'test',
    //   startTime: new Date(2019, 1, 1).toISOString(),
    //   endTime: new Date(2019, 2, 1).toISOString(),
    //   allDay: true
    // });

    // this.eventSource.push({
    //   title: 'test',
    //   startTime: new Date(2019, 3, 1).toISOString(),
    //   endTime: new Date(2019, 4, 1).toISOString(),
    //   allDay: true
    // });
    this.selectedBranch = "B01";

    //   this.eventSource = [
    //     {
    //       year: 2019,
    //       month: 1,
    //       date: 5
    //     },
    //     {
    //       year: 2019,
    //       month: 1,
    //       date: 13
    //     }];
  }

  bookNow() {
    let alert = this.alertCtrl.create({
      title: 'Confirm Booking',
      message: 'Are you Sure You want to Confirm Booking?',
      buttons: [

        {
          text: 'Book Now',
          handler: () => {
            this.presentToast("Booking is successful")
            this.navCtrl.pop();
          }
        },
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    alert.present();
  }

  selectTime(val) {
    console.log("selectTime " + val.time);
    this.time = val.time;
 //   this.getScheduledList();
  }

  selectBranch(val) {
    console.log("selectTime " + val.time);
  //  this.getScheduledList();
  }

  onMonthSelect(event) {
    console.log("onMonthSelect " + JSON.stringify(event));
  }
  onDaySelect(event) {
    console.log("onDaySelect " + JSON.stringify(event));
  }
  addEvent() {

    let modal = this.modalCtrl.create(EventModalPage, { selectedDay: this.selectedDay });
    modal.present();
    modal.onDidDismiss(data => {
      if (data) {
        let eventData = data;

        eventData.startTime = new Date(data.startTime);
        eventData.endTime = new Date(data.endTime);

        let events = this.eventSource;
        events.push(eventData);

        setTimeout(() => {
          this.eventSource = events;
        });
      }
    });
  }

  getScheduledList() {
    this.presentToast("We have recieved your request");
    let language = 'en';
    let branch = '45'
    console.log("Event Booked");
    let times = this.time.toString().split(':');
    console.log(this.time);
    console.log(this.selectedDay);
    this.selectedDay.setHours(parseInt(times[0]));
    this.selectedDay.setMinutes(parseInt(times[1]));
    this.selectedDay.setSeconds(0);
    console.log(this.selectedDay);
    if (localStorage.getItem('language') !== undefined || localStorage.getItem('language') !== null) {
      language = localStorage.getItem('language');
    }
    else {
      language = 'en';
    }
    if (localStorage.getItem('branch') !== undefined || localStorage.getItem('branch') !== null) {
      branch = '45';
    }
    let body = {
      file_no: '2',
      dateTime: this.selectedDay,
      filterLanguage: language,
      branchID: branch,
      Type: this.currenttype,
      _comment: "Type is mock etc. one month onwards",
      sessionID: "IWE($JVE(J$(J"
    }
    if (this.currenttype == 0) {
      this.facadeService.getSchedule(body).subscribe(
        res => {
          console.log(res);
          this.schedules = res.Details;
        }
      );
    }
    else if (this.currenttype == 3 || this.currenttype == 6) {
      let body = {
        file_no: '2',
        dateTime: this.selectedDay,
        filterLanguage: language,
        branchID: branch,
        Type: this.currenttype,
        assignedTrainerID: '2382813',
        _comment: "Type is mock etc. one month onwards",
        sessionID: "IWE($JVE(J$(J"
      }
      this.facadeService.getPracticalSchedule(body).subscribe(
        res => {
          console.log(res);
          this.schedules = res.Details;
        }
      );
    }

    // var date = moment(this.selectedDay).format("")
  }

  onViewTitleChanged(title) {

    this.viewTitle = title;
  }
  markDisabled = (date: Date) => {
    var current = new Date();
    return date < current;
  };

  onEventSelected(event) {
    let start = moment(event.startTime).format('LLLL');
    let end = moment(event.endTime).format('LLLL');

    let alert = this.alertCtrl.create({
      title: '' + event.title,
      subTitle: 'From: ' + start + '<br>To: ' + end,
      buttons: ['OK']
    })
    alert.present();
  }

  onTimeSelected(ev) {
    this.selectedDay = ev.selectedTime;
//    this.getScheduledList();
    console.log(this.selectedDay);
  }

  availableBranch() {
    this.availableBranches = [];
    this.availableBranches.push(
      { "branch": "Al Qouz", "code": "B01" },
      { "branch": "Jebel ali", "code": "B02" }
    );

  }
  presentToast(msg) {
    let toast = this.toastCtrl.create({
      message: msg,
      duration: 3000,
      position: 'bottom'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }
  availableTimeSlot() {
    this.timeArr = [];

    // debugger;
    let d = new Date(); //get a date object
    d.setHours(8, 0, 0, 0); //reassign it to today's midnight
    let hours: any;
    let minute: any;

    var date = d.getDate();
    while (date == d.getDate()) {
      hours = d.getHours();
      this.minutes = d.getMinutes();
      hours = hours == 0 ? 12 : hours; //if it is 0, then make it 12
      let ampm = "am";
      ampm = hours > 12 ? "pm" : "am";
      hours = hours > 12 ? hours - 12 : hours; //if more than 12, reduce 12 and set am/pm flag
      hours = ("0" + hours).slice(-2); //pad with 0
      minute = ("0" + d.getMinutes()).slice(-2); //pad with 0
      // if (hours >= 20)
      //   return;
      // let obj = { time: "" + hours + ":" + minute + " " + ampm }
      //console.log("hous " + hours);
      if (hours === "08" && ampm === "pm") {
        return this.timeArr;
      }
      this.timeArr.push({ time: "" + hours + ":" + minute });

      d.setMinutes(d.getMinutes() + 30); //increment by 5 minutes
    }

  }
}
