import { Component } from '@angular/core';
import { NavController, MenuController, LoadingController, Events } from 'ionic-angular';
import { SignupPage } from '../signup/signup';

import { DrawerState } from '../../../node_modules/ion-bottom-drawer';
import { StatusBar } from '../../../node_modules/@ionic-native/status-bar';
import { ForgotpasswordPage } from '../forgotpassword/forgotpassword';
import { DashboardOnePage } from '../dashboard-one/dashboard-one';
import { VerifyotpPage } from '../verifyotp/verifyotp';
import { LoginServiceProvider } from '../../providers/login-service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { StudentServiceProvider, StudentJourneyResponse } from '../../providers/student-service';
import { TranslateService } from '@ngx-translate/core';
import { FacadeService } from '../../providers/FacadeService';
// import swal from 'sweetalert';

@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  public submitted: boolean = false;
  PURE_EMAIL_REGEXP = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  // Passwords should be at least 8 characters long and should contain one number, one character and one special character.
  PASSWORD_REGEXP = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;

  public santaState: any = 'in';

  shouldBounce = true;
  dockedHeight = 300;
  bounceThreshold = 500;
  distanceTop = 56;
  drawerState = DrawerState.Docked;
  states = DrawerState;
  minimumHeight = 300;

  mobileNumber: string;
  password: string;
  loggedUser: {};
  public loading: any;
  loginForm: FormGroup;
  submitAttempt: boolean = false;

  public navOptions = {
    animation: 'slide-transition'
  };
  constructor(public fb: FormBuilder, public navCtrl: NavController, private statusBar: StatusBar,
    public menuCtrl: MenuController, public service: LoginServiceProvider,
    public loadingController: LoadingController, public events: Events, public facadeService: FacadeService,
    public studentService: StudentServiceProvider, public translate: TranslateService) {
    this.menuCtrl.enable(false, "ahlimenu");
    this.menuCtrl.swipeEnable(false, "ahlimenu");

    this.mobileNumber = "0504230145";

    this.statusBar.overlaysWebView(false);
    this.statusBar.styleLightContent();
    this.statusBar.backgroundColorByHexString('#fff');

    this.loginForm = this.fb.group({
      mobileNumber: new FormControl({ value: '507158310', disabled: false }, [Validators.required, Validators.pattern("^(?:\\0)?(?:50|52|54|55|56|58|59|2|3|4|6|7|9)\\d{7}$")]),
      password: new FormControl({ value: 'aitzaz123', disabled: false }, [Validators.required])
    });
  }

  /**
   * @param {boolean} disable  Show/Hide the vertical scrollbar
   *
   * @example
   * this.setDisableScroll(true);
   *
   * @returns {void}
   */
  // private setDisableScroll(disable: boolean) : void {

  //   let scroll = this.content.getScrollElement();
  //   scroll.style.overflowY = disable ? 'hidden' : 'scroll';
  // }
  toggleFooter() {
    // this.footerState = this.footerState == IonPullUpFooterState.Collapsed ? IonPullUpFooterState.Expanded : IonPullUpFooterState.Collapsed;
    this.drawerState = ((this.drawerState == 2) ? 1 : 2);
  }


  submitForm() {
    this.showLoader();
    this.submitAttempt = true;
    for (let c in this.loginForm.controls) {
      this.loginForm.controls[c].markAsTouched();
    }

    if (!this.loginForm.valid) {
      this.loading.dismiss();
      return;
    }

    let model = {
      username: "971" + this.loginForm.controls.mobileNumber.value,
      password: this.loginForm.controls.password.value,
      grant_type: "password",
    }

    console.log("before service call " + model);
    this.service.login(model).then((data) => {
      this.loading.dismiss();
      localStorage.setItem("student_PID", data['Student_PId']);

      this.events.publish('student_PID', data['Student_PId']);

      this.facadeService.student_Pid = localStorage.getItem('student_PID');
      localStorage.setItem("mobile_number", model.username);
      localStorage.setItem("userName", data['userName']);
      localStorage.setItem("access_token", data['access_token']);
      localStorage.setItem("token_type", data['token_type']);
      localStorage.setItem("expires", data['.expires']);

      let studentJourneyResponse: StudentJourneyResponse = new StudentJourneyResponse();
      // debugger;
      this.studentService.getStudentJourney(data['Student_PId']).then(response => {
        console.log("getStudentJourney");
        localStorage.setItem("StudentJourney", JSON.stringify(response));
        console.log(response);
        studentJourneyResponse = Object.assign(studentJourneyResponse, response);
        console.log("student Journey Response")
        console.log(studentJourneyResponse)
        this.events.publish('StudentJourneyResponse', studentJourneyResponse);
      });

      // if (localStorage.getItem("questionairs") === null) {
      this.navCtrl.setRoot(DashboardOnePage, null, this.navOptions);
      // } else {
      //   this.navCtrl.setRoot(DashboardPage, null, this.navOptions);
      // }
    }, (err) => {
      this.loading.dismiss();
      if (err.status == 400) {
        alert('wrong username and password');
      }
      // alert(err['error'])
      // if (err['status'] == 404) {
      //   swal("Warning", err['_body']['message'], "error");
      //   console.log("something went wrong " + err);
      // }
    });
  }

  showLoader() {
    this.loading = this.loadingController.create({ content: "Loading, please wait..." });
    this.loading.present();
  }


  navigateToVerifyOtp() {
    this.navCtrl.setRoot(VerifyotpPage);
  }

  navigateToDashboard() {
    this.navCtrl.setRoot(DashboardOnePage);
  }

  navigateToRegister() {
    this.navCtrl.setRoot(SignupPage);
  }
  navigateToForgotPassword() {
    this.navCtrl.push(ForgotpasswordPage);
  }

  isEmpty(obj) {
    for (var key in obj) {
      if (obj.hasOwnProperty(key))
        return false;
    }
    return true;
  }

}
