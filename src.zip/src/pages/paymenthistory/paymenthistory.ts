import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { FacadeService } from '../../providers/FacadeService';
import { Utility } from '../../providers/utility';

/**
 * Generated class for the PaymenthistoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-paymenthistory',
  templateUrl: 'paymenthistory.html',
})
export class PaymenthistoryPage {
  pay_model: string = "paylist";

  items = [
    {
      name: 'Opening File',
      price: 1500
    },
    {
      name: 'Learning Permit',
      price: 240
    },
    {
      name: 'Drivers Handbook',
      price: 247
    },
    {
      name: 'Signal Test',
      price: 200
    },
    {
      name: 'Road Test',
      price: 540
    },
    {
      name: 'Renew Learning Permit',
      price: 100
    },
    {
      name: 'Eye Test',
      price: 240
    }
  ];

  public toPayList;

  constructor(
    private myService: FacadeService,
    public navCtrl: NavController,
    private utility: Utility,
    public navParams: NavParams) {
    console.log("CONSTRUCTOR")
  }

  itemSelected(item: string) {
    console.log("Selected Item", item);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PaymenthistoryPage');
    this.getToPayList();
  }

  ionViewWillEnter() {
    console.log("WILL ENTER")
  }

  getToPayList() {
    this.utility.showLoader();
    this.myService.getToPayList().subscribe(
      (res) => {
        this.utility.dismissLoader();
        
        if (res && res.res_PaymentHistory && res.res_PaymentHistory[0])
          this.toPayList = res.res_PaymentHistory[0].payment_det;
      },
      (err) => {
        this.utility.dismissLoader();
      }
    )
  }

}
