import { Component } from '@angular/core';
import { NavController, NavParams, MenuController, LoadingController, Events } from 'ionic-angular';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { LoginServiceProvider } from '../../providers/login-service';
import { StatusBar } from '@ionic-native/status-bar';
import { TranslateService } from '@ngx-translate/core';
import { StudentServiceProvider, StudentJourneyResponse } from '../../providers/student-service';
import { DashboardOnePage } from '../dashboard-one/dashboard-one';
import { VerifyotpPage } from '../verifyotp/verifyotp';
import { SignupPage } from '../signup/signup';
// import swal from 'sweetalert';
/**
 * Generated class for the ForgotpasswordPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-forgotpassword',
  templateUrl: 'forgotpassword.html',
})
export class ForgotpasswordPage {
  shouldBounce = true;
  dockedHeight = 300;
  bounceThreshold = 500;
  distanceTop = 56;
  minimumHeight = 300;

  mobileNumber: string;
  password: string;
  loggedUser: {};
  public loading: any;
  forgotPasswordFrom: FormGroup;
  submitAttempt: boolean = false;

  public navOptions = {
    animation: 'slide-transition'
  };
  constructor(public fb: FormBuilder, public navCtrl: NavController, private statusBar: StatusBar,
    public menuCtrl: MenuController, public service: LoginServiceProvider,
    public loadingController: LoadingController, public events: Events,
    public studentService: StudentServiceProvider, public translate: TranslateService) {
    this.menuCtrl.enable(false, "ahlimenu");
    this.menuCtrl.swipeEnable(false, "ahlimenu");

    this.mobileNumber = "504230145";

    this.statusBar.overlaysWebView(false);
    this.statusBar.styleLightContent();
    this.statusBar.backgroundColorByHexString('#fff');

    this.forgotPasswordFrom = this.fb.group({
      mobileNumber: new FormControl('504230145', [Validators.required, Validators.pattern("^(?:\\0)?(?:50|52|54|55|56|58|59|2|3|4|6|7|9)\\d{7}$")])
    });
  }

  /**
   * @param {boolean} disable  Show/Hide the vertical scrollbar
   *
   * @example
   * this.setDisableScroll(true);
   *
   * @returns {void}
   */
  // private setDisableScroll(disable: boolean) : void {



  submitForm() {
    this.showLoader();
    this.submitAttempt = true;
    for (let c in this.forgotPasswordFrom.controls) {
      this.forgotPasswordFrom.controls[c].markAsTouched();
    }

    if (!this.forgotPasswordFrom.valid) {
      this.loading.dismiss();
      return;

    }

    let model = {
      mobileno: "971" + this.forgotPasswordFrom.controls.mobileNumber.value,
      lang: "en"
    }
    console.log("before service call " + model);
    this.service.forgotPassword(model.mobileno).then((data) => {
      this.loading.dismiss();
      localStorage.setItem('student_PID', data['student_PID']);
      // this.events.publish('student_PID', data['student_PID']);
      if (data['status'] == 1) {
        alert("Otp Sent your mobile number ");
        this.navCtrl.setRoot(VerifyotpPage);
      }

    }, (err) => {
      this.loading.dismiss();
      if (err['status'] == 404) {
        // swal("Warning", err['_body']['message'], "error");
        // swal("Warning", JSON.parse(err['_body']).message, "error");
        alert(JSON.parse(err['_body']).message);
        console.log("something went wrong " + err);
      }
    })
  }



  showLoader() {
    this.loading = this.loadingController.create({ content: "Loading, please wait..." });
    this.loading.present();
  }


  navigateToVerifyOtp() {
    this.navCtrl.setRoot(VerifyotpPage);
  }

  navigateToDashboard() {
    this.navCtrl.setRoot(DashboardOnePage);
  }

  navigateToRegister() {
    this.navCtrl.setRoot(SignupPage);
  }
  navigateToForgotPassword() {
    this.navCtrl.push(ForgotpasswordPage);
  }

  isEmpty(obj) {
    for (var key in obj) {
      if (obj.hasOwnProperty(key))
        return false;
    }
    return true;
  }

}
