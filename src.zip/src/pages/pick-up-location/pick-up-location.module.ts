import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PickUpLocationPage } from './pick-up-location';

@NgModule({
  declarations: [
    PickUpLocationPage,
  ],
  imports: [
    IonicPageModule.forChild(PickUpLocationPage),
  ],
})
export class PickUpLocationPageModule {}
