import { Component, ViewChild } from '@angular/core';
import { NavController, MenuController } from 'ionic-angular';
import { TranslateService } from '@ngx-translate/core';
import { Slides } from 'ionic-angular';
import { SplashPage } from '../splash/splash';
import { LoginPage } from '../login/login';
/**
 * Generated class for the SelectlangPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-selectlang',
  templateUrl: 'selectlang.html',
})
export class SelectlangPage {
  @ViewChild(Slides) slides: Slides;
  constructor(public navCtrl: NavController, public translate: TranslateService, public menuCtrl: MenuController) {
    this.menuCtrl.enable(false, "ahlimenu");
    this.menuCtrl.swipeEnable(false, "ahlimenu");
  }

  slideChanged() {
    let currentIndex = this.slides.getActiveIndex();
    console.log('Current index is', currentIndex);
    let lang = localStorage.getItem("lang");
    if (lang != null) {
      if (currentIndex == 1 || currentIndex == 4) {
        lang = "ur";
      } else if (currentIndex == 2) {
        lang = "en";
      } else if (currentIndex == 0  || currentIndex == 3) {
        lang = "ar";
      }
      console.log("selected language " + lang);
      this.translate.use(lang);
      this.translate.setDefaultLang(lang);
      localStorage.setItem("lang", lang);
    }
  }
  setLanguage(lang = "ar") {
    let currentIndex = this.slides.getActiveIndex();
    console.log('setLanguage Current index is', currentIndex);
    if (currentIndex == 1 || currentIndex == 4) {
      lang = "ur";
    } else if (currentIndex == 2) {
      lang = "en";
    } else if (currentIndex == 0 || currentIndex == 3) {
      lang = "ar";
    }
    console.log("selected language " + lang);
    this.translate.use(lang);
    this.translate.setDefaultLang(lang);
    localStorage.setItem("lang", lang);
    let index = this.navCtrl.getActive().index;
    this.navCtrl.push(LoginPage).then(() => {
      this.navCtrl.remove(index);
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SelectlangPage');
  }

}
