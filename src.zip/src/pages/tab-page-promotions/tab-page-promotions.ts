import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FacadeService } from '../../providers/FacadeService';
import { Utility } from '../../providers/utility';


/**
 * Generated class for the TabPagePromotionsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-tab-page-promotions',
  templateUrl: 'tab-page-promotions.html',
})
export class TabPagePromotionsPage {

  promotionsList = [];
  constructor(public navCtrl: NavController, private utility: Utility, public navParams: NavParams, public facadeService: FacadeService) {

    this.utility.showLoader();
    this.facadeService.getPromotions(localStorage.getItem("lang")).subscribe(
      (res) => {
        this.utility.dismissLoader();
        this.promotionsList = res.response;
      },
      (err) => {
        this.utility.dismissLoader();
      }
    );
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TabPagePromotionsPage');
  }

}
