import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TabPagePromotionsPage } from './tab-page-promotions';

@NgModule({
  declarations: [
    TabPagePromotionsPage,
  ],
  imports: [
    IonicPageModule.forChild(TabPagePromotionsPage),
  ],
})
export class TabPagePromotionsPageModule {}
