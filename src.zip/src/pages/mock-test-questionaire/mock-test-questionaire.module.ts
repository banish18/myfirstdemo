import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MockTestQuestionairePage } from './mock-test-questionaire';

@NgModule({
  declarations: [
    MockTestQuestionairePage,
  ],
  imports: [
    IonicPageModule.forChild(MockTestQuestionairePage),
  ],
})
export class MockTestQuestionairePageModule {}
