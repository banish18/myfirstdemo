import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { FacadeService } from '../../providers/FacadeService';

/**
 * Generated class for the MockTestQuestionairePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-mock-test-questionaire',
  templateUrl: 'mock-test-questionaire.html',
})
export class MockTestQuestionairePage {
  questForm: FormGroup;
  questionIds: any;
  questions  =  [] ;
  q1 = new FormControl({ value: false, disabled: false });
  q2 = new FormControl({ value: '', disabled: true }, Validators.required);
  q3 = new FormControl({ value: '', disabled: true }, Validators.required);
  q4 = new FormControl({ value: '', disabled: true }, Validators.required);
  q5 = new FormControl({ value: '', disabled: false }, Validators.required);
  q6 = new FormControl({ value: '', disabled: false }, Validators.required);
  q7 = new FormControl({ value: '', disabled: false }, Validators.required);
  q8 = new FormControl({ value: '', disabled: false }, Validators.required);
  q9 = new FormControl({ value: '', disabled: false }, Validators.required);
  q10 = new FormControl({ value: '', disabled: false }, Validators.required);
  q11 = new FormControl({ value: '', disabled: false }, Validators.required);
  q12 = new FormControl({ value: '', disabled: false }, Validators.required);
  q13 = new FormControl({ value: '', disabled: false }, Validators.required);
  q14 = new FormControl({ value: '', disabled: false }, Validators.required);
  q15 = new FormControl({ value: '', disabled: false }, Validators.required);


  constructor(public navCtrl: NavController, public navParams: NavParams, 
    public facadeService: FacadeService,public fb: FormBuilder) {
      let body = {
        FileNo:"FP317",
        language:"en"
      }
      this.facadeService.getExamQuestionsID(body).subscribe(
        res=>{
          this.questionIds =  res.GetExamTypes;
          this.facadeService.getExamQuestions(this.questionIds[0]).subscribe(
            res=>{
              this.questions = res.qstnanwer;
            }
          )
        }
      )
    this.questForm = this.fb.group({
      q1: this.q1,
      q2: this.q2,
      q3: this.q3,
      q4: this.q4,
      q5: this.q5,
      q6: this.q6,
      q7: this.q7,
      q8: this.q8,
      q9: this.q9,
      q10: this.q10,
      q11: this.q11,
      q12: this.q12,
      q13: this.q13,
      q14: this.q14,
      q15: this.q15,
    });

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MockTestQuestionairePage');
  }

}
