import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Home_2Page } from './home-2';

@NgModule({
  declarations: [
    Home_2Page,
  ],
  imports: [
    IonicPageModule.forChild(Home_2Page),
  ],
})
export class Home_2PageModule {} 
