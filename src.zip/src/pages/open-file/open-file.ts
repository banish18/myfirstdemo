import { Component, ViewChild } from '@angular/core';
import { NavController, Slides, Segment, LoadingController, ToastController, Platform, AlertController, Content, NavParams, ViewController, ModalController } from 'ionic-angular';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { CountryServiceProvider } from '../../providers/country-service';
import { FileTransfer, FileUploadOptions, FileTransferObject } from '@ionic-native/file-transfer';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { FilePath } from '@ionic-native/file-path';
import { DashboardPage } from '../dashboard/dashboard';
import { FacadeService } from '../../providers/FacadeService';
import { Utility } from '../../providers/utility';
import { Api } from '../../providers/api';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { Http, Headers } from '@angular/http';
import Utils from '../../providers/Utils';
import { TranslateService } from '@ngx-translate/core';
import { OpenFileServiceProvider } from '../../providers/openfile-service';

/**
 * Generated class for the OpenFilePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
class ResponseData {
  public result: boolean = false;
  public image_url: String = "";
}

@Component({
  selector: 'page-open-file',
  templateUrl: 'open-file.html',
  providers: [InAppBrowser]
})
export class OpenFilePage {
  @ViewChild('signupSlider') signupSlider: any;
  @ViewChild(Slides) slides: Slides;
  @ViewChild('pageTop') pageTop: Content;
  slideOneForm: FormGroup;
  slideTwoForm: FormGroup;
  slideThreeForm: FormGroup;

  showHideMainBtn: boolean = true;
  firstBtn: boolean = true;
  secondBtn: boolean = false;
  thirdBtn: boolean = false;

  mainForm: FormGroup;
  submitAttempt: boolean = false;
  haveLicense: boolean = false;
  numberOfYears: number = 0;
  maxYears: any[] = Array(10);

  attachIcon_1: string = "attach";
  attachIcon_2: string = "attach";
  attachIcon_3: string = "attach";
  attachIcon_4: string = "attach";
  attachIcon_5: string = "attach";
  attachIcon_6: string = "attach";
  attachIcon_7: string = "attach";
  amountToPay = '2500';

  model: ResponseData = new ResponseData();
  registerationFee: RegisterationFee = new RegisterationFee();

  coursesFeeList: Array<Fee> = new Array<Fee>();
  countries: any;
  emirates: any;
  student_PID: string = "";
  @ViewChild('mySegment') segment: Segment;
  selectedSegment: String;

  imageURI: any;
  imageFileName: any;
  questions = [];
  docList = [];

  // PAY FEE
  cardNum;
  cardHolderName;
  edm;
  edy;
  cvc;

  q1 = new FormControl({ value: false, disabled: false });
  q2 = new FormControl({ value: '', disabled: false });
  q3 = new FormControl({ value: '', disabled: false });
  q4 = new FormControl({ value: '', disabled: false }, [Validators.required]);
  q5 = new FormControl({ value: false, disabled: false }, [Validators.required]);
  q6 = new FormControl({ value: '', disabled: false });
  q7 = new FormControl({ value: false, disabled: false });
  q8 = new FormControl({ value: false, disabled: false });
  q9 = new FormControl({ value: '', disabled: false });
  q10 = new FormControl({ value: false, disabled: false });
  q11 = new FormControl({ value: '', disabled: false });
  q12 = new FormControl({ value: false, disabled: false });
  q13 = new FormControl({ value: '', disabled: false });
  q14 = new FormControl({ value: false, disabled: false });
  q15 = new FormControl({ value: '', disabled: false }, [Validators.required]);
  q16 = new FormControl({ value: '', disabled: false }, [Validators.required]);

  get f1() { return this.slideOneForm.controls; }
  get f2() { return this.slideTwoForm.controls; }
  get f3() { return this.slideThreeForm.controls; }

  constructor(public navCtrl: NavController, public formBuilder: FormBuilder,
    public service: CountryServiceProvider, public transfer: FileTransfer,
    public camera: Camera, public loadingCtrl: LoadingController,
    public toastCtrl: ToastController, public plt: Platform,
    public mySerivce: FacadeService, public api: Api,
    public utility: Utility, public http: Http, public modalCtrl: ModalController,
    public iab: InAppBrowser, public translate: TranslateService,
    public filePath: FilePath, public alertCtrl: AlertController,
    public openFileService: OpenFileServiceProvider) {    
    console.log(this.plt.platforms());
    this.student_PID = localStorage.getItem('student_PID');
    this.selectedSegment = "one";
    this.countries = service.getCountries();
    this.emirates = service.getEmirates();

    this.slideOneForm = formBuilder.group({
      q1: this.q1,
      q2: this.q2,
      q3: this.q3,
      q4: this.q4,
      q5: this.q5,
      q6: this.q6,
      q7: this.q7,
      q8: this.q8,
      q9: this.q9,
      q10: this.q10,
      q11: this.q11,
      q12: this.q12,
      q13: this.q13,
      q14: this.q14,
      q15: this.q15,
      q16: this.q16
    });

    this.slideOneForm.controls.q1.valueChanges.subscribe(value => {

      if (value == true) {
        this.slideOneForm.controls.q2.setValidators(Validators.required);
        this.slideOneForm.controls.q2.updateValueAndValidity();

        this.slideOneForm.controls.q3.setValidators(Validators.required);
        this.slideOneForm.controls.q3.updateValueAndValidity();
      } else {
        this.slideOneForm.controls.q2.clearValidators();
        this.slideOneForm.controls.q2.updateValueAndValidity();
        this.slideOneForm.controls.q3.clearValidators();
        this.slideOneForm.controls.q3.updateValueAndValidity();
      }
    });

    this.slideOneForm.controls.q5.valueChanges.subscribe(value => {
      if (value == false) {
        this.slideOneForm.controls.q6.setValidators(Validators.required);
        this.slideOneForm.controls.q6.updateValueAndValidity();
      } else {
        this.slideOneForm.controls.q6.clearValidators();
        this.slideOneForm.controls.q6.updateValueAndValidity();

      }
    });
    this.slideOneForm.controls.q8.valueChanges.subscribe(value => {
      if (value == true) {
        this.slideOneForm.controls.q9.setValidators(Validators.required);
        this.slideOneForm.controls.q9.updateValueAndValidity();
      } else {
        this.slideOneForm.controls.q9.clearValidators();
        this.slideOneForm.controls.q9.updateValueAndValidity();
      }
    });

    this.slideOneForm.controls.q10.valueChanges.subscribe(value => {
      if (value == true) {
        this.slideOneForm.controls.q11.setValidators(Validators.required);
        this.slideOneForm.controls.q11.updateValueAndValidity();
      } else {
        this.slideOneForm.controls.q11.clearValidators();
        this.slideOneForm.controls.q11.updateValueAndValidity();
      }
    });

    this.slideTwoForm = formBuilder.group({
      noc: ['./assets/imgs/user.png', [Validators.required]],
      emiratesID: ['./assets/imgs/credit-card.png', [Validators.required]],
      passport: ['./assets/imgs/internet.png', [Validators.required]],
      visa: ['./assets/imgs/airplane.png', [Validators.required]],
      drivingLicenese: ['./assets/imgs/noc.png', [Validators.required]],
      license: ['./assets/imgs/noc.png', []],
      eyeTest: ['./assets/imgs/noc.png', []]
    });

    this.slideThreeForm = formBuilder.group({
      //this.slideOneForm;
    });


    this.getQuestions();

  }

  getQuestions() {
    this.utility.showLoader();
    this.mySerivce.getQuestions().subscribe(
      (res) => {
          this.utility.dismissLoader();
          console.log(res.response);
        this.questions = res.response;
      },
      (err) => {
        this.utility.dismissLoader();
      }
    )
  }


  payOption(payPercentage) {
    this.amountToPay = payPercentage;
  }

  attachFile(docId) {
    let options = {
      quality: 100,
      destinationType: this.camera.DestinationType.FILE_URI,
      sourceType: this.camera.PictureSourceType.CAMERA,
      mediaType: this.camera.MediaType.PICTURE,
      encodingType: this.camera.EncodingType.JPEG,
      targetWidth: 500,
      targetHeight: 500
    };

    let self = this;

    this.camera.getPicture(options).then(function (imageData) {
      // this.imageURI = imageData;
      let filName = "";
      let loader = self.loadingCtrl.create({
        content: "Uploading..."
      });

      loader.present();

      switch (docId) {
        case 1:
          self.attachIcon_1 = "custom-loading";
          filName = "Noc";
          break;
        case 2:
          self.attachIcon_2 = "custom-loading";
          filName = "EmiratesID";
          break;
        case 3:
          self.attachIcon_3 = "custom-loading";
          filName = "EyeTest";
          break;
        case 4:
          self.attachIcon_4 = "custom-loading";
          filName = "NOC2";
          break;
        case 5:
          self.attachIcon_5 = "custom-loading";
          filName = "DriverLicense";
          break;
        case 6:
          self.attachIcon_6 = "custom-loading";
          filName = "Passport";
          break;
        case 7:
          self.attachIcon_7 = "custom-loading";
          filName = "Visa";
          break;

      }

      let params = {
        user_id: "",
        doc_name: "",
        doc_id: ""
      };
      params.user_id = self.student_PID;
      params.doc_name = filName;
      params.doc_id = docId;

      let fileTransfer = self.transfer.create();


      let options = {
        fileKey: 'file_path',
        fileName: filName + '.jpg',
        chunkedMode: false,
        mimeType: "image/jpeg",
        params,
        headers: {
          "Authorization": "Bearer 5c5eeae47b19f",
          "client-id": "ios"
        }
      };
      fileTransfer.upload(imageData, Utils.CMS_WEBAPI_DOMAIN + "/api/user/documents/upload", options)
        .then(function (data) {
          console.log(JSON.stringify(data));
          console.log(data + " Uploaded Successfully");
          let file = JSON.parse(data.response).response.file;
          self.imageFileName = "ionicfile.jpg";
          document.getElementById('doc_' + docId).setAttribute('src', file);

          self.attachIcon_1 = "attach";
          self.attachIcon_2 = "attach";
          self.attachIcon_3 = "attach";
          self.attachIcon_4 = "attach";
          self.attachIcon_5 = "attach";
          self.attachIcon_6 = "attach";
          self.attachIcon_7 = "attach";

          loader.dismiss();
          self.presentToast("Image uploaded successfully");
        }, function (err) {
          console.log(err);
          loader.dismiss();
          self.presentToast(err);
        });
    }, function (err) {
      console.log(err);
      self.presentToast(err);
    });
  }

  presentToast(msg) {
    if (this.plt.is("ios") || this.plt.is("iphone") || this.plt.is("android")) {

      let toast = this.toastCtrl.create({
        message: msg,
        duration: 3000,
        position: 'bottom'
      });

      toast.onDidDismiss(() => {
        console.log('Dismissed toast');
      });

      toast.present();

    } else {
      alert(msg);
    }


  }

  ngAfterViewInit() {
    // child is set

    this.slides.lockSwipes(true);
  }
  next() {


    if (this.selectedSegment === 'one') {
      this.selectedSegment = 'two';
    } else if (this.selectedSegment === 'two') {
      this.selectedSegment = 'three';
    }
    this.slides.lockSwipes(false);
    this.slides.slideNext();
    this.pageTop.scrollToTop();
    this.slides.lockSwipes(true);
  }

  prev() {
    if (this.selectedSegment === 'two') {
      this.selectedSegment = 'one';
    } else if (this.selectedSegment === 'three') {
      this.selectedSegment = 'two';
    }
    this.segment.focusNext;
    this.slides.lockSwipes(false);
    this.slides.slidePrev();
    this.slides.lockSwipes(true);
  }

  payFee() {
    let user_id = this.student_PID;
    let lang = 'en';
    let amount = this.amountToPay;
    let web = "http://151.253.172.13:8181/payaadc/mypay.php?user_id=" + user_id + "&lang=" + lang + "&amount=" + amount;
    const browser = this.iab.create(web);
    // this.mySerivce.payFee().subs

    // this.presentAlert();
  }

  postQuestion() {

    let temp = this.slideOneForm.value;

    var resArr = [];
    for (var property in temp) {
      if (temp.hasOwnProperty(property)) {
        let obj = {};
        obj["question_id"] = property;
        obj["answer"] = temp[property];
        resArr.push(obj);
      }
    }

    let payload = {
      user_id: localStorage.getItem('student_PID'),
      response: resArr
    }

    this.utility.showLoader();
    this.mySerivce.submitQuestionaire(payload).subscribe(
      (res) => {
        this.utility.dismissLoader();
        console.log(res)
      },
      (err) => {
        this.utility.dismissLoader();
      }
    );

  }

  getImage(imgId) {
    let imgUrl = "";
    if (imgId == 1) {
      imgUrl = "./assets/imgs/noc.png";
    } else if (imgId == 2) {
      imgUrl = "./assets/imgs/user.png";
    } else if (imgId == 3) {
      imgUrl = "./assets/imgs/internet.png";
    } else if (imgId == 4) {
      imgUrl = "./assets/imgs/airplane.png";
    } else if (imgId == 5) {
      imgUrl = "./assets/imgs/airplane.png";
    }

    return imgUrl;
  }

  getDocList() {
    this.mySerivce.getDocuments().subscribe(
      (res) => {
        this.docList = res.response;
      }
    )
  }

  clearValue(questionNo, myslideOneForm) {
    if (questionNo == 1) {
      myslideOneForm.controls[2].value = "";
      myslideOneForm.controls[3].value = "";
      myslideOneForm.controls[4].value = "";
    }
    if (questionNo == 5) {
      myslideOneForm.controls[6].value = "";
    }
    if (questionNo == 8) {
      myslideOneForm.controls[9].value = "";
    }
    if (questionNo == 10) {
      myslideOneForm.controls[11].value = "";
    }
    if (questionNo == 12) {
      myslideOneForm.controls[13].value = "";
    }

    //  this.slideOneForm.controls[9].value = "";
  }

  saveAttachments() {
    let flag = false;
    for (let i = 0; i < this.docList.length; i++) {
      if (this.docList[i].id !== 3 && this.docList[i].id !== 5) {
        var data = document.getElementById('doc_' + this.docList[i].id).getAttribute('src');
        if (data) {
          if (data.indexOf('assets') == -1) {
            flag = true;
          }
        }
      }
    }

    // if (!flag) {
    //   this.presentToast("All required must be attached to proceed..");
    // }else{
    this.selectedSegment = 'three';
    this.getCourseRegistratoinFee("LMV");
    this.slides.lockSwipes(false);
    this.slides.slideNext();
    this.pageTop.scrollToTop();
    this.slides.lockSwipes(true);
    // }
  }

  save(myslideOneForm) {

    if (this.slides.getActiveIndex() == 1 && this.slideTwoForm.valid) {
      if (this.selectedSegment === 'one') {
        this.selectedSegment = 'two';
      } else if (this.selectedSegment === 'two') {
        this.showHideMainBtn = false;
        this.selectedSegment = 'three';
      }
      this.slides.lockSwipes(false);
      this.slides.slideNext();
      this.pageTop.scrollToTop();
      this.slides.lockSwipes(true);
    }
    else {
      console.log("success!")
      console.log(this.slideOneForm.value);
      console.log(this.slideTwoForm.value);
    }

  }

  presentAlert() {
    let alert = this.alertCtrl.create({
      title: 'Payment Successful',
      subTitle: 'Your payment recieved!!',
      buttons: [{
        text: 'OK',
        handler: () => {
          console.log('Buy clicked');
          this.navCtrl.setRoot(DashboardPage);
        }
      }]
    });
    alert.present();
  }

  submitForm() {
    if (this.slides.getActiveIndex() == 0) {

      for (let c in this.slideOneForm.controls) {
        this.slideOneForm.controls[c].markAsTouched();
      }

      if (!this.slideOneForm.valid) {
        console.log('Valid!');
        this.scrollIfFormHasErrors(this.slideOneForm).then(() => {
        });
        return;
      }
      this.utility.showLoader();
      let temp = this.slideOneForm.value;

      var resArr = [];
      for (var property in temp) {
        if (temp.hasOwnProperty(property)) {
          let obj = {};
          obj["question_id"] = property;
          obj["answer"] = temp[property];
          resArr.push(obj);
        }
      }

      let payload = {
        user_id: localStorage.getItem('student_PID'),
        response: resArr
      }

      this.mySerivce.submitQuestionaire(payload).subscribe(
        (res) => {
          this.utility.dismissLoader();
          console.log(res)

          this.selectedSegment = 'two';

          this.getDocList();

          this.slides.lockSwipes(false);
          this.slides.slideNext();
          this.pageTop.scrollToTop();
          this.slides.lockSwipes(true);
        },
        (err) => {
          this.utility.dismissLoader();
          alert(this.translate.instant('LABEL_GENERAL_ERROR'));

          this.selectedSegment = 'two';

          this.getDocList();

          this.slides.lockSwipes(false);
          this.slides.slideNext();
          this.pageTop.scrollToTop();
          this.slides.lockSwipes(true);

        }
      );

    } else if (this.slides.getActiveIndex() == 1) {

      if (!this.slideTwoForm.valid) {
        console.log('Valid!');
        this.scrollIfFormHasErrors(this.slideTwoForm).then(() => {
        });
        return;
      }

      this.selectedSegment = 'three';

      this.slides.lockSwipes(false);
      this.slides.slideNext();
      this.pageTop.scrollToTop();
      this.slides.lockSwipes(true);

    } else if (this.slides.getActiveIndex() == 2) {

      if (!this.slideThreeForm.valid) {
        console.log('Valid!');
        this.scrollIfFormHasErrors(this.slideThreeForm).then(() => {
        });
        return;
      }

    }

  }

  async scrollIfFormHasErrors(form: FormGroup): Promise<any> {
    await form.invalid;
    const el = document.querySelector('.text-danger');

    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  }

  getCourseRegistratoinFee(courseType) {
    this.utility.showLoader();
    this.openFileService.getRegestrationFees(courseType).then(res => {
      this.utility.dismissLoader();
      console.log(res)
      // this.selectedCourseFees = res;
      this.registerationFee = Object.assign(res['registerationFee'][0], this.registerationFee);
      this.coursesFeeList = this.registerationFee.Fees;
      console.log(res)
    },
      (err) => {
        this.utility.dismissLoader();
      }
    );
  }

  openModal(characterNum) {

    let modal = this.modalCtrl.create(ModalContentPage, characterNum);
    modal.present();
  }
}
@Component({
  template: `
<ion-header>
  <ion-toolbar>
    <ion-title>
      Description
    </ion-title>
    <ion-buttons start>
      <button ion-button (click)="dismiss()">
        <span ion-text color="primary" showWhen="ios">Cancel</span>
        <ion-icon name="md-close" showWhen="android, windows"></ion-icon>
      </button>
    </ion-buttons>
  </ion-toolbar>
</ion-header>
<ion-content>
  <ion-list>
      <ion-item>
        <ion-avatar item-start>
          <img src="{{character.image}}">
        </ion-avatar>
        <h2>{{character.name}}</h2>
        <p>{{character.quote}}</p>
      </ion-item>
      <ion-item *ngFor="let item of character['items']">
        {{item.title}}
        <ion-note item-end>
          {{item.note}}
        </ion-note>
      </ion-item>
  </ion-list>
</ion-content>`
})
export class ModalContentPage {
  character;

  constructor(
    public platform: Platform,
    public params: NavParams,
    public viewCtrl: ViewController
  ) {
    var characters = [
      {
        name: 'Gollum',
        quote: 'Sneaky little hobbitses!',
        image: 'assets/img/avatar-gollum.jpg',
        items: [
          { title: 'Race', note: 'Hobbit' },
          { title: 'Culture', note: 'River Folk' },
          { title: 'Alter Ego', note: 'Smeagol' }
        ]
      },
      {
        name: 'Frodo',
        quote: 'Go back, Sam! I\'m going to Mordor alone!',
        image: 'assets/img/avatar-frodo.jpg',
        items: [
          { title: 'Race', note: 'Hobbit' },
          { title: 'Culture', note: 'Shire Folk' },
          { title: 'Weapon', note: 'Sting' }
        ]
      },
      {
        name: 'Samwise Gamgee',
        quote: 'What we need is a few good taters.',
        image: 'assets/img/avatar-samwise.jpg',
        items: [
          { title: 'Race', note: 'Hobbit' },
          { title: 'Culture', note: 'Shire Folk' },
          { title: 'Nickname', note: 'Sam' }
        ]
      }
    ];
    this.character = characters[this.params.get('charNum')];
  }

  dismiss() {
    this.viewCtrl.dismiss();
  }
}
export class Fee {
  title: string;
  fee: string;
  id: string;
  optional: boolean;
}

export class RegisterationFee {
  CourseType: string;
  courseID: string;
  Fees: Fee[];
}

export interface RootObject {
  registerationFee: RegisterationFee[];
}