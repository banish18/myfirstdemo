import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { FacadeService } from '../../providers/FacadeService';
import { Utility } from '../../providers/utility';
import { OfferDetailPage } from '../offer-detail/offer-detail';

/**
 * Generated class for the TabPageOfferPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-tab-page-offer',
  templateUrl: 'tab-page-offer.html',
})
export class TabPageOffer {
  offerList = [];
  constructor(public navCtrl: NavController,
    private utility: Utility,
    public navParams: NavParams, public facadeService: FacadeService) {

    this.utility.showLoader();
    this.facadeService.getOffers(localStorage.getItem("lang")).subscribe(
      res => {
        this.utility.dismissLoader();
        this.offerList = res.response;
      },
      err => {
        this.utility.dismissLoader();
      }
      );
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TabPageOffer');
  }


  offerDetail(offer) {
    this.navCtrl.parent.parent.push(OfferDetailPage, { offer: offer });
  }

}
