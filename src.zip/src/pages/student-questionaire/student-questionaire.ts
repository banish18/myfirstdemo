import { Component } from '@angular/core';
import { NavController, LoadingController } from 'ionic-angular';
import { HomePage } from '../home/home';
import { SignupPage } from '../signup/signup';
import { LoginPage } from '../login/login';
import { ScheduleRoadAssessmentTestPage } from '../schedule-road-assessment-test/schedule-road-assessment-test';
import { ScheduleRTARoadTestPage } from '../schedule-rtaroad-test/schedule-rtaroad-test';
import { ScheduleYardAssessmentTestPage } from '../schedule-yard-assessment-test/schedule-yard-assessment-test';
import { ScheduleRTAYardTestPage } from '../schedule-rtayard-test/schedule-rtayard-test';
import { MilestonesPage } from '../milestones/milestones';
import { ProfilePage } from '../profile/profile';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { StudentQuestModel, QuestionairResponseModel } from '../../model/studentQuestModel';
import { StudentServiceProvider } from '../../providers/student-service';

@Component({
  selector: 'page-student-questionaire',
  templateUrl: 'student-questionaire.html'
})
export class StudentQuestionairePage {

  questForm: FormGroup;
  submitted = false;
  public loading: any;
  responseModel: QuestionairResponseModel = new QuestionairResponseModel();
  student_PID: number;

  q1 = new FormControl({ value: false, disabled: false });
  q2 = new FormControl({ value: '', disabled: true }, Validators.required);
  q3 = new FormControl({ value: '', disabled: true }, Validators.required);
  q4 = new FormControl({ value: '', disabled: true }, Validators.required);
  q5 = new FormControl({ value: '', disabled: false }, Validators.required);
  q6 = new FormControl({ value: '', disabled: false }, Validators.required);
  q7 = new FormControl({ value: '', disabled: false }, Validators.required);
  q8 = new FormControl({ value: '', disabled: false }, Validators.required);
  q9 = new FormControl({ value: '', disabled: false }, Validators.required);
  q10 = new FormControl({ value: '', disabled: false }, Validators.required);
  q11 = new FormControl({ value: '', disabled: false }, Validators.required);
  q12 = new FormControl({ value: '', disabled: false }, Validators.required);
  q13 = new FormControl({ value: '', disabled: false }, Validators.required);
  q14 = new FormControl({ value: '', disabled: false }, Validators.required);
  q15 = new FormControl({ value: '', disabled: false }, Validators.required);

  model: StudentQuestModel = new StudentQuestModel();

  constructor(public navCtrl: NavController, public fb: FormBuilder,
    public translate: TranslateService, public service: StudentServiceProvider,
    public loadingController: LoadingController) {
    this.student_PID = parseInt(localStorage.getItem('student_PID'));


    this.questForm = this.fb.group({
      q1: this.q1,
      q2: this.q2,
      q3: this.q3,
      q4: this.q4,
      q5: this.q5,
      q6: this.q6,
      q7: this.q7,
      q8: this.q8,
      q9: this.q9,
      q10: this.q10,
      q11: this.q11,
      q12: this.q12,
      q13: this.q13,
      q14: this.q14,
      q15: this.q15,
    });

    this.questForm.controls.q2.disable();
    this.questForm.controls.q3.disable();
    this.questForm.controls.q4.disable();

    this.q1.valueChanges.subscribe(value => {
      if (value) {
        this.questForm.controls.q2.enable();
        this.questForm.controls.q2.setValidators(Validators.required);
        this.questForm.controls.q2.updateValueAndValidity();

        this.questForm.controls.q3.enable();
        this.questForm.controls.q3.setValidators(Validators.required);
        this.questForm.controls.q3.updateValueAndValidity();

        this.questForm.controls.q4.enable();
        this.questForm.controls.q4.setValidators(Validators.required);
        this.questForm.controls.q4.updateValueAndValidity();

      } else {
        this.questForm.controls.q2.disable();
        this.questForm.controls.q2.clearValidators();
        this.questForm.controls.q2.updateValueAndValidity();

        this.questForm.controls.q3.disable();
        this.questForm.controls.q3.clearValidators();
        this.questForm.controls.q3.updateValueAndValidity();

        this.questForm.controls.q4.disable();
        this.questForm.controls.q4.clearValidators();
        this.questForm.controls.q4.updateValueAndValidity();
      }
    });

    this.init();
  }

  setFormValues(responseModel: QuestionairResponseModel) {

    let questions = responseModel.questions;
    for (let i = 0; i < questions.length; i++) {
      this.questForm.controls[questions[i].questionid].setValue(questions[i].answer);
    }
  }
  init() {
    this.showLoader();
    this.service.getQuestionair(this.student_PID).then((data) => {
      // this.responseModel = data;
      this.responseModel = Object.assign(this.responseModel, data);
      console.log("getQuestionair " + JSON.stringify(this.responseModel));

      this.loading.dismiss();

      this.setFormValues(this.responseModel);
    }, (err) => {
      console.log("something went wrong " + err);
    });
  }
  async scrollIfFormHasErrors(form: FormGroup): Promise<any> {
    await form.invalid;
    const el = document.querySelector('.text-danger');

    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  }
  submitForm() {

    this.submitted = true;
    for (let c in this.questForm.controls) {
      this.questForm.controls[c].markAsTouched();
    }
    if (!this.questForm.valid) {

      this.scrollIfFormHasErrors(this.questForm).then(() => {
        // Run any additional functionality if you need to. 
      });
      return;
    }

    this.model = Object.assign(this.model, this.questForm.value);
    console.log(JSON.stringify(this.model));
  }

  get f() { return this.questForm.controls; }

  showLoader() {
    this.loading = this.loadingController.create({ content: "Loading, please wait..." });
    this.loading.present();
  }
}
