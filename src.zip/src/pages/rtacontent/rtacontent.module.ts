import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RtacontentPage } from './rtacontent';

@NgModule({
  declarations: [
    RtacontentPage,
  ],
  imports: [
    IonicPageModule.forChild(RtacontentPage),
  ],
})
export class RtacontentPageModule {}
