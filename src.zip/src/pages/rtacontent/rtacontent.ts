import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { StudentServiceProvider, RTAContent } from '../../providers/student-service';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser/ngx';
import { PdfviewPage } from '../pdfview/pdfview';
import { PdfViewerProvider } from '../../providers/pdf-viewer/pdf-viewer';

/**
 * Generated class for the RtacontentPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
    selector: 'page-rtacontent',
    templateUrl: 'rtacontent.html',
})

export class RtacontentPage {
    rtaContentResponse: RTAContent = new RTAContent();
    tableOfContents: any[] = [];
    pageTitle: string;
    searchTerm: string = '';
    options: InAppBrowserOptions = {
        location: 'yes',//Or 'no' 
        hidden: 'no', //Or  'yes'
        clearcache: 'yes',
        clearsessioncache: 'yes',
        zoom: 'yes',//Android only ,shows browser zoom controls 
        hardwareback: 'yes',
        mediaPlaybackRequiresUserAction: 'no',
        shouldPauseOnSuspend: 'no', //Android only 
        closebuttoncaption: 'Close', //iOS only
        disallowoverscroll: 'no', //iOS only 
        toolbar: 'yes', //iOS only 
        enableViewportScale: 'no', //iOS only 
        allowInlineMediaPlayback: 'no',//iOS only 
        presentationstyle: 'pagesheet',//iOS only 
        fullscreen: 'yes',//Windows only    
    };
    constructor(public navCtrl: NavController, public navParams: NavParams,

        public studentService: StudentServiceProvider, public iab: InAppBrowser, public pdfViewer: PdfViewerProvider) {

        this.studentService.getRTAContent(localStorage.getItem("lang")).then(response => {
            console.log("getRTAContent");          
            this.rtaContentResponse = Object.assign(this.rtaContentResponse, response);
            // alert(this.rtaContentResponse.response.title);
            this.pageTitle = this.rtaContentResponse.response.title;
            console.log(this.rtaContentResponse.response.description);
            let tempArr = this.rtaContentResponse.response.description.split("<br />");
            this.tableOfContents = [];

            for (let i = 0; i < tempArr.length; i++) {
                let tableOfContent: TableOfContent = new TableOfContent();
                let str = tempArr[i];
                let text = str.slice(0, str.indexOf("http"));
                let link = str.slice(str.indexOf("http"), str.indexOf("#"));
                let PageNo = str.slice((str.indexOf("=") + 1), str.length)
                tableOfContent.title = text;
                tableOfContent.link = link;
                tableOfContent.pageNo = PageNo;
                this.tableOfContents.push(tableOfContent);
            }
            console.log(this.tableOfContents)
        });
    }

    ionViewDidLoad() {
        console.log('ionViewDidLoad RtacontentPage');
    }

    openLink(link, pageNo) {
        console.log(link)
        console.log(pageNo)
        //localStorage.setItem("pdfUrl", link);
        //localStorage.setItem("pageno", pageNo);
        this.pdfViewer.openDocument(link + "#page=" + pageNo);
        //this.navCtrl.push(PdfviewPage); 
    }

    setFilteredItems() {
        if (this.searchTerm != "") {
            this.filterItems(this.searchTerm);
        }
        else {
            this.studentService.getRTAContent(localStorage.getItem("lang")).then(response => {
                console.log("getRTAContent");
                this.rtaContentResponse = Object.assign(this.rtaContentResponse, response);
                // alert(this.rtaContentResponse.response.title);
                this.pageTitle = this.rtaContentResponse.response.title;
                console.log(this.rtaContentResponse.response.description);
                let tempArr = this.rtaContentResponse.response.description.split("<br />");
                this.tableOfContents = [];

                for (let i = 0; i < tempArr.length; i++) {
                    let tableOfContent: TableOfContent = new TableOfContent();
                    let str = tempArr[i];
                    let text = str.slice(0, str.indexOf("http"));
                    let link = str.slice(str.indexOf("http"), str.indexOf("#"));
                    let PageNo = str.slice((str.indexOf("=") + 1), str.length)
                    tableOfContent.title = text;
                    tableOfContent.link = link;
                    tableOfContent.pageNo = PageNo;
                    this.tableOfContents.push(tableOfContent);
                }
                console.log(this.tableOfContents)
            });
            //this.faqs1 = this.totalfaqs1;
            //this.faqs2 = this.totalfaqs2;
            //this.faqs3 = this.totalfaqs3;
            //this.faqs4 = this.totalfaqs4;
        }
    }

    clearSearch() {
        this.searchTerm = "";
    }

    filterItems(searchTerm) {
        this.tableOfContents = this.tableOfContents.filter((item) => {         
            return item.title.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
        });        
    }
}

export class TableOfContent {
    title: string;
    link: string;
    pageNo: string;

    constructor() { }
};