import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { EventsProvider } from '../../providers/events/events';

/**
 * Generated class for the AboutUsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-about-us',
  templateUrl: 'about-us.html',
})
export class AboutUsPage {
  aboutusList: any;
  constructor(public navCtrl: NavController,
    public navParams: NavParams, public service: EventsProvider) {

    this.service.getAboutUs().then(response => {
      console.log(JSON.stringify(response));

      let lang = localStorage.getItem("lang");
      if (lang == "en") {
        this.aboutusList = response['en'];
      } else {
        this.aboutusList = response['ar'];
      }

    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AboutUsPage');
  }

}
