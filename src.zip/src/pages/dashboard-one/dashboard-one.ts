import { Component } from '@angular/core';
import { NavController, NavParams, MenuController, Events, AlertController } from 'ionic-angular';
import { TabPageCourses } from '../tab-page-courses/tab-page-courses';
import { TabPageOffer } from '../tab-page-offer/tab-page-offer';
import { OpenFilePage } from '../open-file/open-file';
import { TabPageNews } from '../tab-page-news/tab-page-news';
import { TabPagePricing } from '../tab-page-pricing/tab-page-pricing';
import { StudentServiceProvider, StudentJourneyResponse } from '../../providers/student-service';
import { ContactusPage } from '../contactus/contactus';
import { TabPagePromotionsPage } from '../tab-page-promotions/tab-page-promotions';
import { LoginPage } from '../login/login';


/**
 * Generated class for the DashboardOnePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-dashboard-one',
  templateUrl: 'dashboard-one.html',
})
export class DashboardOnePage {
  tab1 = TabPageCourses;
  tab2 = TabPageOffer;
  tab3 = TabPagePricing;
  tab4 = TabPageNews;
  tab5 = TabPagePromotionsPage;

  studentJourneyResponse: StudentJourneyResponse = new StudentJourneyResponse();
  student_PID: number;

  selectedTabIndex = 1;

  constructor(public navCtrl: NavController, public navParams: NavParams,
    public menuCtrl: MenuController, public service: StudentServiceProvider,
    public events: Events, public alert: AlertController) {
    this.menuCtrl.enable(true, "ahlimenu");

    this.student_PID = parseInt(localStorage.getItem('student_PID')) || 0;

    this.events.subscribe('StudentJourneyResponse', (StudentJourneyResponse) => {
      // user and time are the same arguments passed in `events.publish(user, time)`
      console.log('inside dashboard one ', StudentJourneyResponse);

    });

    if (this.student_PID !== null && this.student_PID !== 0) {
      // debugger;
      this.service.getStudentJourney(this.student_PID).then(response => {
        console.log("getStudentJourney");
        localStorage.setItem("StudentJourney", JSON.stringify(response));
        console.log(response);
        this.studentJourneyResponse = Object.assign(this.studentJourneyResponse, response);

        this.events.publish('StudentJourneyResponse', this.studentJourneyResponse);
      });
    }

    // this.tab1 = tabPageCourses.tabPagecourses(navCtrl);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DashboardOnePage');
  }
  openFile() {
      if (localStorage.getItem('student_PID') != null && localStorage.getItem('student_PID') != undefined) {
        alert()
      this.navCtrl.push(OpenFilePage);
    }
    else {
        let alert = this.alert.create({
        title: 'Sign In Required',
        message: 'Sign In is Required to Perform this Action',
        buttons: [
          {
            text: 'Sign In',
            handler: () => {
              this.navCtrl.setRoot(LoginPage);
            }
          },
          {
            text: 'Cancel',
            role: 'cancel',
            handler: () => {
              console.log('Cancel clicked');
            }
          }
        ]
      });
      alert.present();
    }
  }

  contactUs() {
    this.navCtrl.push(ContactusPage);
  }

  notficatoins() {
    // this.navCtrl.push(ContactusPage);
  }
}
