import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MockTestWizardPage } from './mock-test-wizard';

@NgModule({
  declarations: [
    MockTestWizardPage,
  ],
  imports: [
    IonicPageModule.forChild(MockTestWizardPage),
  ],
})
export class MockTestWizardPageModule {}
