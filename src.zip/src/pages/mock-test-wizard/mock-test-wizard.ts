import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { EventsProvider } from '../../providers/events/events';
import { Utility } from '../../providers/utility';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '@angular/forms';

/**
 * Generated class for the MockTestWizardPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-mock-test-wizard',
  templateUrl: 'mock-test-wizard.html',
})
export class MockTestWizardPage {

  param: any;
  pageTitle: string;
  examTypeId: string;

  mockTestObject: MockTestObject = new MockTestObject();
  public mockTestForm: FormGroup;
  private questionCount: number = 1;

  constructor(public navCtrl: NavController,
    public navParams: NavParams, public fb: FormBuilder,
    public eventService: EventsProvider, private utility: Utility) {

    this.param = JSON.parse(navParams.data.examObj);
    this.pageTitle = this.param.Examtypename;
    this.examTypeId = this.param.ExamId;
    console.log("MockTestWizardPage navParams " + this.param.ExamId);

    this.mockTestForm = fb.group({
      examId: [this.examTypeId],
      type: this.fb.group({
        questions: this.fb.array([]) // create empty form array   
      })
    });

    this.utility.showLoader();

    this.eventService.getMockQuestionById(this.examTypeId).then((data) => {
      console.log("sendOtp");
      console.log(data);
      this.mockTestObject = Object.assign(this.mockTestObject, data);
      console.log(this.mockTestObject);
      this.utility.dismissLoader();
      const control = <FormArray>this.mockTestForm.get('type.questions');

      this.mockTestObject.qstnanwer.forEach(x => {

        control.push(this.fb.group({
          questionId: x.QuestionId,
          question: x.Question,
          answers: this.setAnswers(x)
        }))
        // x.answer.forEach(y => {
        //   control.push(this.patchValues(y.Answers, y.AnswersID))
        // });
      });

      console.log(this.mockTestForm);

    }, (err) => {
      this.utility.dismissLoader();
      console.log("something went wrong " + err);
    });

  }

  setAnswers(x: Qstnanwer) {
    let arr = new FormArray([])
    x.answer.forEach(y => {
      arr.push(this.fb.group({
        title: y.Answers,
        answerID: y.AnswersID
      }))
    })
    return arr;
  }
  patchValues(label, value) {
    return this.fb.group({
      label: [label],
      value: [value]
    })
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad MockTestWizardPage');
  }

  submit(formvalue){
    console.log(formvalue)
  }
}

export interface Answer {
  Answers: string;
  AnswersID: string;
}

export interface Answerimg {
  AnswerImgs: string;
}

export interface Answeraud {
  AnswerAudios: string;
}

export interface Qstnanwer {
  QuestionId: number;
  Question: string;
  Audiopath: string;
  answer: Answer[];
  answerimg: Answerimg[];
  answeraud: Answeraud[];
}

export class MockTestObject {
  qstnanwer: Qstnanwer[];
}
