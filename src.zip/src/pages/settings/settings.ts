import { Component } from '@angular/core';
import { NavController, NavParams, Platform } from 'ionic-angular';
import { SplashPage } from '../splash/splash';
import { DashboardOnePage } from '../dashboard-one/dashboard-one';
import { TranslateService } from '@ngx-translate/core';
import { AboutUsPage } from '../about-us/about-us';
import { PoliciesPage } from '../policies/policies';

/**
 * Generated class for the SettingsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-settings',
  templateUrl: 'settings.html',
})
export class SettingsPage {

  language: any;
  constructor(public navCtrl: NavController,
    public navParams: NavParams, public platform: Platform,
    public translate: TranslateService) {

    this.language = localStorage.getItem("lang");
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SettingsPage');
  }

  changeLanguage(val) {

    this.translate.setDefaultLang(val);
    this.translate.use(val);
    localStorage.setItem("lang", val);

    // 

    if (val == "ar" || val == "ur") {
      this.platform.setDir('rtl', true);
      this.platform.setDir('ltr', false);
    } else {
      this.platform.setDir('ltr', true);
      this.platform.setDir('rtl', false);
    }
    this.navCtrl.setRoot(this.navCtrl.getActive().component);
    this.navCtrl.setRoot(DashboardOnePage);
  }

  policy() {
    this.navCtrl.push(PoliciesPage)
  }

  aboutUs() {
    this.navCtrl.push(AboutUsPage)
  }
}
