import { Component, ViewChild } from '@angular/core';
import { NavController, Slides, Segment } from 'ionic-angular';



@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
    // @ViewChild(Slides) slides: Slides;
    @ViewChild('mySlider') slider: Slides;
    @ViewChild('mySegment') segment: Segment;
    selectedSegment: string;
    slides: any;


    constructor(public navCtrl: NavController) {
      this.selectedSegment = 'first';
      this.slides = [
        {
          id: "first",
          title: "First Slide"
        },
        {
          id: "second",
          title: "Second Slide"
        },
        {
          id: "third",
          title: "Third Slide"
        },
        {
          id: "forth",
          title: "Forth Slide"
        },
        {
          id: "fifth",
          title: "Fifth Slide"
        }
      ];
    }

    myFunction(e){
      console.log("myFunction "+e.target.scrollTop);
    }
    onSegmentChanged(segmentButton) {
      console.log("Segment changed to", segmentButton.value);
      if(segmentButton.value == "forth"){
        this.segment.focusNext;
      }
      const selectedIndex = this.slides.findIndex((slide) => {

        return slide.id === segmentButton.value;
      });
      this.slider.slideTo(selectedIndex);
    }
  
    onSlideChanged(slider) {
      console.log('Slide changed');
      const currentSlide = this.slides[slider.getActiveIndex()];
      this.selectedSegment = currentSlide.id;
    }

    /*
    gotoStudenQuestionaire(params) {
      if (!params) params = {};
      this.navCtrl.push(StudentQuestionairePage);
    }
    goToScheduleRoadAssessmentTest(params) {
      if (!params) params = {};
      this.navCtrl.push(ScheduleRoadAssessmentTestPage);
    } goToScheduleRTARoadTest(params) {
      if (!params) params = {};
      this.navCtrl.push(ScheduleRTARoadTestPage);
    } goToScheduleYardAssessmentTest(params) {
      if (!params) params = {};
      this.navCtrl.push(ScheduleYardAssessmentTestPage);
    } goToScheduleRTAYardTest(params) {
      if (!params) params = {};
      this.navCtrl.push(ScheduleRTAYardTestPage);
    } goToMilestones(params) {
      if (!params) params = {};
      this.navCtrl.push(MilestonesPage);
    } goToProfile(params) {
      if (!params) params = {};
      this.navCtrl.push(ProfilePage);
    }*/
}
