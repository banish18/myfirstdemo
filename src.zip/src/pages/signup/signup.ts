import { Component } from '@angular/core';
import { NavController, MenuController, LoadingController } from 'ionic-angular';
import { HomePage } from '../home/home';
import { LoginPage } from '../login/login';
import { ScheduleRoadAssessmentTestPage } from '../schedule-road-assessment-test/schedule-road-assessment-test';
import { ScheduleRTARoadTestPage } from '../schedule-rtaroad-test/schedule-rtaroad-test';
import { ScheduleYardAssessmentTestPage } from '../schedule-yard-assessment-test/schedule-yard-assessment-test';
import { ScheduleRTAYardTestPage } from '../schedule-rtayard-test/schedule-rtayard-test';
import { MilestonesPage } from '../milestones/milestones';
import { ProfilePage } from '../profile/profile';
import { DashboardPage } from '../dashboard/dashboard';
import { VerifyotpPage } from '../verifyotp/verifyotp';
import { DashboardOnePage } from '../dashboard-one/dashboard-one';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { signupModel, signUpResponse } from './signupModel';
import { LoginServiceProvider } from '../../providers/login-service';
// import swal from 'sweetalert';

@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html'
})
export class SignupPage {
  public mask: Array<string | RegExp>;
  signupForm: FormGroup;
  model: signupModel = new signupModel();
  submitAttempt: boolean = false;
  public loading: any;

  constructor(public fb: FormBuilder, public navCtrl: NavController,
    public menuCtrl: MenuController, private translate: TranslateService,
    private loginService: LoginServiceProvider,
    public loadingController: LoadingController) {
    this.menuCtrl.enable(false, "ahlimenu");
    this.menuCtrl.swipeEnable(false, "ahlimenu");
    this.mask = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];



    this.signupForm = this.fb.group({
      First_Name: new FormControl('Muhammad', Validators.required),
      Last_Name: new FormControl('Saifuddin', Validators.required),
      Mobile_Number: new FormControl('504230145', [Validators.required, Validators.pattern("^(?:\\|0)?(?:50|52|54|55|56|58|59|2|3|4|6|7|9)\\d{7}$")]),
      Email: new FormControl('muhammad.saifuddin@outlook.com', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ]))
    });
  }

  submitForm() {

    this.showLoader();
    this.submitAttempt = true;
    for (let c in this.signupForm.controls) {
      this.signupForm.controls[c].markAsTouched();
    }

    if (!this.signupForm.valid) {
      this.loading.dismiss();
      return;

    }

    console.log("this.signupForm.value: ");
    console.log(this.signupForm.value);
    this.model.Language = localStorage.getItem("lang") || "en";

    this.model = Object.assign(this.model, this.signupForm.value);
    this.model.Mobile_Number = "971" + this.signupForm.controls.Mobile_Number.value;
    this.loginService.Registration(this.model).then((data) => {
      // console.log("Registration " + JSON.stringify(data));
      this.loading.dismiss();


      localStorage.setItem("student_PID", data['student_PID']);
      localStorage.setItem("mobile_number", "" + this.model.Mobile_Number);
      this.navCtrl.push(VerifyotpPage);
      // }
    }, (err) => {
      console.log("Registration " + err);
      this.loading.dismiss();
      console.log("something went wrong " + err);

      let errorResponse = JSON.parse(err['_body']);
      if (errorResponse['securityModel.Mobile_Number']) {
        // swal("Oops!", errorResponse['securityModel.Mobile_Number']['errors'][0]['errorMessage'], "error");
        alert()
      }

      if (errorResponse.message) {
        alert(errorResponse.message);
        // swal("Oops!", errorResponse['message'], "error");
        // swal({
        //   title: "Warning",
        //   text: errorResponse['message'],
        //   icon: "warning",
        //   dangerMode: true,
        // })
        //   .then(willDelete => {
        //     if (willDelete) {
        //       if (localStorage.getItem("student_PID")) {
        //         this.navCtrl.push(VerifyotpPage);
        //       }
        //       // swal("Deleted!", "Your imaginary file has been deleted!", "success");
        //     }
        //   });
      }

    });

  }

  goToHome(params) {
    if (!params) params = {};
    this.navCtrl.push(HomePage);
  }

  goToSignup(params) {
    if (!params) params = {};
    this.navCtrl.push(SignupPage);
  }
  goToLogin(params) {
    if (!params) params = {};
    this.navCtrl.push(LoginPage);
  }
  goToScheduleRoadAssessmentTest(params) {
    if (!params) params = {};
    this.navCtrl.push(ScheduleRoadAssessmentTestPage);
  }
  goToScheduleRTARoadTest(params) {
    if (!params) params = {};
    this.navCtrl.push(ScheduleRTARoadTestPage);
  }
  goToScheduleYardAssessmentTest(params) {
    if (!params) params = {};
    this.navCtrl.push(ScheduleYardAssessmentTestPage);
  }
  goToScheduleRTAYardTest(params) {
    if (!params) params = {};
    this.navCtrl.push(ScheduleRTAYardTestPage);
  }
  goToMilestones(params) {
    if (!params) params = {};
    this.navCtrl.push(MilestonesPage);
  }
  goToProfile(params) {
    if (!params) params = {};
    this.navCtrl.push(ProfilePage);
  }
  navigateTo(page) {

    if (page === 'verifyOtp') {
      this.navCtrl.push(VerifyotpPage);
    } else if (page === 'login') {
      this.navCtrl.push(LoginPage);
    } else if (page === 'guestUser') {
      this.navCtrl.setRoot(DashboardOnePage);
    }
  }
  navigateToDashboard() {
    this.navCtrl.setRoot(DashboardPage);
  }

  showLoader() {
    this.loading = this.loadingController.create({ content: "Loading, please wait..." });
    this.loading.present();
  }

}
