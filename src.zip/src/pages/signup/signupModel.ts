export class signupModel {

  public Mobile_Number: String;
  public First_Name: String;
  public Last_Name: String;
  public Email: String;
  public Language: String;

  signupModel() { }
}
export class signUpResponse {
  student_PID: number;
  status: number;
  message: string;
  constructor(values: Object = {}) {
    Object.assign(this, values);
  }
}

export class verifyOtpModel {
  fileno: number;
  mobile_number: number;
  otp: number;
  lang: String;
}