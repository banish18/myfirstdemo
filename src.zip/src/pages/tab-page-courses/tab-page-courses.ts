import { Component } from '@angular/core';
import { NavController, NavParams, ModalController, LoadingController } from 'ionic-angular';
import { CourseDetailPage } from '../course-detail/course-detail';
import { FacadeService } from '../../providers/FacadeService';
import { NewsDetailPage } from '../news-detail/news-detail';
import { Utility } from '../../providers/utility';
// declare var carousel: any;


/**
 * Generated class for the TabPageCoursesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-tab-page-courses',
  templateUrl: 'tab-page-courses.html',
})
export class TabPageCourses {

  images: any[];
  cards: Array<any>;
  recentCard: string = '';
  parentCtrl: NavController;
  private data: any;
  private slides: any = [];
  private start: number = 0;
  private end: number = 6;
  courses: any = [];
  // public tabPagecourses(navCtrl:NavController){
  //   this.parentCtrl = navCtrl..parent;
  //   return this;
  // }
  // carousel = carousel;
  constructor(public navCtrl: NavController, public navParams: NavParams, public facadeService: FacadeService,
    public modalCtrl: ModalController, public loadingCtrl: LoadingController,
    public utility: Utility,
  ) {
    this.parentCtrl = navCtrl.getActiveChildNav();
    console.log(navCtrl.parent);
    // navCtrl.getActiveChildNav()
    this.data = [
      {
        id: 1,
        title: 'Light Motor Vehicle 1',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'http://oxygennacdn3.oxygenna.com/wp-content/uploads/2015/11/18.jpg',
        outstanding: true
      },
      {
        id: 2,
        title: 'Light Motor Vehicle 2',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'https://s-media-cache-ak0.pinimg.com/originals/d2/7b/4f/d27b4fa995194a0c77b8871a326a7c0b.jpg'
      },
      {
        id: 3,
        title: 'Light Motor Vehicle 3',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        outstanding: true,
        backgroundImgUrl: 'https://i.imgur.com/AMf9X7E.jpg'
      },
      {
        id: 4,
        title: 'Light Motor Vehicle 4',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'http://oxygennacdn2.oxygenna.com/wp-content/uploads/2015/06/small.jpg'
      },
      {
        id: 5,
        title: 'Light Motor Vehicle 5',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'https://newevolutiondesigns.com/images/freebies/google-material-design-wallpaper-1.jpg'
      },
      {
        id: 6,
        title: 'Light Motor Vehicle 6',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'https://i.ytimg.com/vi/GpTrOahC6jI/maxresdefault.jpg'
      },
      {
        id: 7,
        title: 'Light Motor Vehicle 7',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'http://www.templatemonsterblog.es/wp-content/uploads/2016/04/1-9-2.jpg'
      },
      {
        id: 8,
        title: 'Light Motor Vehicle 8',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'https://cms-assets.tutsplus.com/uploads/users/41/posts/25951/image/material-design-3.jpg'
      },
      {
        id: 9,
        title: 'Light Motor Vehicle 9',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'https://cms-assets.tutsplus.com/uploads/users/41/posts/25951/image/material-design-background-1.jpg'
      },
      {
        id: 10,
        title: 'Light Motor Vehicle 10',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'http://www.vactualpapers.com/web/wallpapers/1-pattern-35-color-schemes-material-design-wallpaper-series-image11/2560x1440.jpg'
      },
      {
        id: 11,
        title: 'Light Motor Vehicle 11',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'https://www.smashingmagazine.com/wp-content/uploads/2015/07/Ultimate-Material-Lollipop-Collection1.png'
      },
      {
        id: 12,
        title: 'Light Motor Vehicle 12',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'https://s-media-cache-ak0.pinimg.com/736x/c2/bd/3a/c2bd3ae483f9617e6f71bc2a74b60b5a.jpg'
      },
      {
        id: 13,
        title: 'Light Motor Vehicle 13',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'https://s-media-cache-ak0.pinimg.com/736x/c2/bd/3a/c2bd3ae483f9617e6f71bc2a74b60b5a.jpg'
      },
      {
        id: 14,
        title: 'Light Motor Vehicle 14',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'https://s-media-cache-ak0.pinimg.com/736x/c2/bd/3a/c2bd3ae483f9617e6f71bc2a74b60b5a.jpg'
      },
      {
        id: 15,
        title: 'Light Motor Vehicle',
        cost: 'From AED 2,500',
        description: 'Light Motor includes motorcars, jeep, taxis and pickup trucks',
        country: 'Spain',
        color: '#fff',
        isSelected: false,
        imgUrl: '../assets/imgs/car.svg',
        backgroundImgUrl: 'https://s-media-cache-ak0.pinimg.com/736x/c2/bd/3a/c2bd3ae483f9617e6f71bc2a74b60b5a.jpg'
      }
    ];


  }


  ionViewDidLoad() {
    this.getCurrentSlides();
  }

  swipe(event) {
    if (event.direction === 2) {
      console.log("swipe left");
      // this.navCtrl.parent.select(2);
    }
    if (event.direction === 4) {
      console.log("swipe right");
      //this.navCtrl.parent.select(0);
    }
  }

  ngAfterViewInit() {



    var Conclave = (function () {
      var buArr = [], arlen;
      return {
        init: function () {
          this.addCN(); this.clickReg(); this.swipe();
        },
        addCN: function () {
          var buarr = ["holder_bu_awayL4", "holder_bu_awayL3", "holder_bu_awayL2", "holder_bu_awayL1", "holder_bu_center", "holder_bu_awayR1", "holder_bu_awayR2", "holder_bu_awayR3", "holder_bu_awayR4"];
          for (var i = 1; i <= buarr.length; ++i) {
            $("#bu" + i).removeClass().addClass(buarr[i - 1] + " holder_bu");
          }
        },
        swipe: function () {

          $(".holder_bu").each(function () {
            buArr.push($(this).attr('class'))
          });
          arlen = buArr.length;
          for (var i = 0; i < arlen; ++i) {
            buArr[i] = buArr[i].replace(" holder_bu", "")
          };

          document.addEventListener('touchstart', handleTouchStart, false);
          document.addEventListener('touchmove', handleTouchMove, false);

          var xDown = null;
          var yDown = null;

          function getTouches(evt) {
            return evt.touches ||             // browser API
              evt.originalEvent.touches; // jQuery
          }

          function handleTouchStart(evt) {
            const firstTouch = getTouches(evt)[0];
            xDown = firstTouch.clientX;
            yDown = firstTouch.clientY;
          };

          function handleTouchMove(evt) {
            if (!xDown || !yDown) {
              return;
            }

            var xUp = evt.touches[0].clientX;
            var yUp = evt.touches[0].clientY;

            var xDiff = xDown - xUp;
            var yDiff = yDown - yUp;

            if (Math.abs(xDiff) > Math.abs(yDiff)) {/*most significant*/
              if (xDiff > 0) {
                /* left swipe */
                console.log("left swipe");
                for (let i = 1; i <= 1; ++i) {
                  $(".holder_bu").delay(4000).trigger('click', "bu" + i).delay(4000);
                  console.log("called");
                }

              } else {
                /* right swipe */
                console.log("right swipe");
              }
            } else {
              if (yDiff > 0) {
                /* up swipe */
              } else {
                /* down swipe */
              }
            }
            /* reset values */
            xDown = null;
            yDown = null;
          };
        },
        clickReg: function () {
          $(".holder_bu").each(function () {
            buArr.push($(this).attr('class'))
          });
          arlen = buArr.length;
          for (var i = 0; i < arlen; ++i) {
            buArr[i] = buArr[i].replace(" holder_bu", "")
          };
          $(".holder_bu").click(function (buid) {
            console.log(buid);
            var me = this, id = this.id || buid, joId = $("#" + id), joCN = joId.attr("class").replace(" holder_bu", "");
            var cpos = buArr.indexOf(joCN), mpos = buArr.indexOf("holder_bu_center");
            if (cpos != mpos) {
              var tomove = cpos > mpos ? arlen - cpos + mpos : mpos - cpos;
              while (tomove) {
                var t = buArr.shift();
                buArr.push(t);
                for (var i = 1; i <= arlen; ++i) {
                 
                  $("#bu" + i).removeClass().addClass(buArr[i - 1] + " holder_bu");
                }
                --tomove;
              }
            }
          });

        },
        auto: function () {
          for (let i = 1; i <= 1; ++i) {
            $(".holder_bu").delay(4000).trigger('click', "bu" + i).delay(4000);
            console.log("called");
          }
        }
      };
    })();

    // $(document).ready(function () {
    //   window['conclave'] = Conclave;
    //   Conclave.init();
    // });
    this.utility.showLoader();
    this.facadeService.courseInfo(localStorage.getItem("lang")).subscribe(
      res => {
        let self = this;
        document.getElementById("wrapper_bu").setAttribute("display", "none");
        this.courses = res.response;
        setTimeout(() => {
          window['conclave'] = Conclave;
          Conclave.init();
          let elements = document.querySelectorAll('.truncate');
          // elements.forEach(function (elem) {
          for (let i = 0; i < elements.length; i++) {
            let elem = elements[i];
            let limit = 50;
            let after = "...";
            let content;

            if (!elem || !limit) return;

            // Get the inner content of the element
            content = elem.textContent.trim();
            // Convert the content into an array of words
            // Remove any words above the limit
            content = content.split(' ').slice(0, limit);

            // Convert the array of words back into a string
            // If there's content to add after it, add it
            content = content.join(' ') + (after ? after : '');

            // Inject the content back into the DOM
            elem.textContent = content;
          }

          self.utility.dismissLoader();
          document.getElementById("wrapper_bu").setAttribute("display", "block");
        }, 1200);



      },
      err => {
        this.utility.dismissLoader();
      }
    );

  }

  truncate(elem, limit, after) {

    // Make sure an element and number of items to truncate is provided
    if (!elem || !limit) return;

    // Get the inner content of the element
    var content = elem.textContent.trim();

    // Convert the content into an array of words
    // Remove any words above the limit
    content = content.split(' ').slice(0, limit);

    // Convert the array of words back into a string
    // If there's content to add after it, add it
    content = content.join(' ') + (after ? after : '');

    // Inject the content back into the DOM
    elem.textContent = content;

  }
  getCurrentSlides() {

    let loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });

    loading.present();

    if (this.start == this.data.length) {
      this.start = 0;
      this.end = 6;
    }
    this.slides = [];
    for (var i = this.start; i <= this.end; i++) {
      this.slides.push(this.data[i]);
    }

    loading.dismiss();

    this.start = this.end + 1;
    if ((this.start + this.end) < this.data.length) this.end = this.start + this.end;
    else this.end = this.data.length - 1;
  }

  selectItem(item) {
    this.navCtrl.parent.parent.push(NewsDetailPage, { news: item });
  }
  // ionViewDidLoad() {
  //   console.log('ionViewDidLoad TabPageCoursesPage');


  // }

  courseDetail(course) {
    this.navCtrl.parent.parent.push(CourseDetailPage);
  }



}
