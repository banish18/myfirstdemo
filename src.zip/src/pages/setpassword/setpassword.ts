import { Component } from '@angular/core';
import { DashboardOnePage } from '../dashboard-one/dashboard-one';
import { FormBuilder, FormGroup, FormControl, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { LoginServiceProvider } from '../../providers/login-service';
import { NavParams, AlertController, MenuController, NavController, LoadingController } from 'ionic-angular';
import { LoginPage } from '../login/login';

/**
 * Generated class for the SetpasswordPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-setpassword',
  templateUrl: 'setpassword.html',
})
export class SetpasswordPage {
  student_PID = 0;
  mobile_number = 0;
  public loading: any;
  setPasswordForm: FormGroup;
  submitAttempt: boolean = false;



  constructor(public fb: FormBuilder, public navCtrl: NavController,
    public navParams: NavParams, public menuCtrl: MenuController,
    public alertCtrl: AlertController, public loadingController: LoadingController,
    public service: LoginServiceProvider,
    public translate: TranslateService) {

    this.menuCtrl.enable(false, "ahlimenu");

    this.setPasswordForm = this.fb.group({
      password: new FormControl('', Validators.compose([Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{7,}')])),
      password_confirmation: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(15), this.equalto('password')])
    });

    this.student_PID = parseInt(localStorage.getItem('student_PID'));
    this.mobile_number = parseInt(localStorage.getItem('mobile_number'));
  }

  equalto(field_name): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      let input = control.value;
      let isValid = control.root.value[field_name] == input;
      if (!isValid)
        return { 'equalTo': { isValid } };
      else
        return null;
    };
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SetpasswordPage');
  }

  setpassword() {
    this.presentAlert();
  }


  navigateToLogin() {
    this.navCtrl.setRoot(LoginPage);
  }

  navigateToDashboard() {
    this.navCtrl.setRoot(DashboardOnePage);
  }

  presentAlert() {
    let alert = this.alertCtrl.create({
      title: 'Low battery',
      subTitle: '10% of battery remaining',
      buttons: [{
        text: 'OK',
        handler: () => {
          console.log('Buy clicked');
          this.navCtrl.setRoot(DashboardOnePage);
        }
      }]
    });
    alert.present();
  }

  showLoader() {
    this.loading = this.loadingController.create({ content: "Loading, please wait..." });
    this.loading.present();
  }

  submitForm() {

    this.loading = this.loadingController.create({ content: "Loading, please wait..." });
    this.loading.present();
    this.submitAttempt = true;
    for (let c in this.setPasswordForm.controls) {
      this.setPasswordForm.controls[c].markAsTouched();
    }

    if (!this.setPasswordForm.valid) {
      this.loading.dismiss();
      return;

    }
    let model = {
      file_no: this.student_PID,
      password: this.setPasswordForm.controls.password.value
    };
    console.log("this.setPasswordForm.value: ");
    console.log(this.setPasswordForm.value);
    model.file_no = this.student_PID;
    model.password = this.setPasswordForm.value.password;

    this.service.setPassword(this.student_PID, this.setPasswordForm.value.password).then((data) => {
      this.loading.dismiss();
      let alert = this.alertCtrl.create({
        title: 'Successful',
        subTitle: data['staticMessage'],
        buttons: [{
          text: 'OK',
          handler: () => {
            console.log('Buy clicked');
            if (data['is_verified']) {
              this.navCtrl.setRoot(LoginPage);
            }
          }
        }]
      });
      alert.present();

    }, (err) => {
      this.loading.dismiss();
      console.log("something went wrong " + err);
    });

  }
}
