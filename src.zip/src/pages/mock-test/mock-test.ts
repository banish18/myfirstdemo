import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { EventsProvider } from '../../providers/events/events';
import { Utility } from '../../providers/utility';
import { MockTestWizardPage } from '../mock-test-wizard/mock-test-wizard';

/**
 * Generated class for the MockTestPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-mock-test',
  templateUrl: 'mock-test.html',
})
export class MockTestPage {

  getExamTypesResponse: getExamTypeResponse = new getExamTypeResponse();

  constructor(public navCtrl: NavController, public navParams: NavParams,
    public eventService: EventsProvider, private utility: Utility) {
    this.utility.showLoader();

    this.eventService.getMockTest("FP317").then((data) => {
      console.log("sendOtp");
      console.log(data);
      this.getExamTypesResponse = Object.assign(this.getExamTypesResponse, data);
      console.log(this.getExamTypesResponse);
      this.utility.dismissLoader();

    }, (err) => {
      this.utility.dismissLoader();
      console.log("something went wrong " + err);
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MockTestPage');
  }
  goToExamType(obj: GetExamTypes) {
    this.navCtrl.push(MockTestWizardPage, { 'examObj': JSON.stringify(obj) });
  }

}

export class getExamTypeResponse {
  getExamTypes: Array<GetExamTypes>;
}
export class GetExamTypes {
  ExamId: string;
  Examtypename: string;
}