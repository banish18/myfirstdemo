import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { FacadeService } from '../../providers/FacadeService';
import { Utility } from '../../providers/utility';

/**
 * Generated class for the FaqPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
    selector: 'page-faq',
    templateUrl: 'faq.html',
})

export class FaqPage {
    faqs_model1: string = "aboutus";
    faqs_model2: string = "openfile";
    faqs_model3: string = "documents";
    faqs_model4: string = "payments";
    faqs1: any = [];
    faqs2: any = [];
    faqs3: any = [];
    faqs4: any = [];
    totalfaqs1: any = [];
    totalfaqs2: any = [];
    totalfaqs3: any = [];
    totalfaqs4: any = [];
    searchList: any = [];
    itemExpandHeight: number = 100;
    searchItems;
    searchTerm: string = '';



    constructor(public navCtrl: NavController,
        private utility: Utility,
        public facadeService: FacadeService,
        public navParams: NavParams) {

        // let faqsid = this.navParams.get('faqsid');

        // this.faqs = this.service.getFaqs('faqsid');

        // console.log(this.faqs);

        this.searchableItems();
        this.utility.showLoader();
        this.facadeService.faq('en', 'about').subscribe(
            res => {
                this.faqs1 = res.response;
                this.totalfaqs1 = res.response;
                this.utility.dismissLoader();
            },
            err => {
                this.utility.dismissLoader();
            }
        );
        
        this.facadeService.faq('en', 'openfile').subscribe(res => {
            this.faqs2 = res.response;
            this.totalfaqs2 = res.response;
        });
        this.facadeService.faq('en', 'documents').subscribe(res => {
            this.faqs3 = res.response;
            this.totalfaqs3 = res.response;
        });
        this.facadeService.faq('en', 'payments').subscribe(res => {
            this.faqs4 = res.response;
            this.totalfaqs4 = res.response;
        });
    }

    setFilteredItems() {
        if (this.searchTerm != "") {
            this.filterItems(this.searchTerm);
        }
        else {
            this.faqs1 = this.totalfaqs1;
            this.faqs2 = this.totalfaqs2;
            this.faqs3 = this.totalfaqs3;
            this.faqs4 = this.totalfaqs4;
        }
    }

    clearSearch() {
        this.searchTerm = "";
    }

    filterItems(searchTerm) {

        if (this.faqs_model1 == 'aboutus') {
            this.faqs1 = this.totalfaqs1;
            this.faqs1 = this.faqs1.filter((item) => {
                return item.question.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
            });
        }
        if (this.faqs_model1 == 'openfile') {
            this.faqs2 = this.totalfaqs2;

            this.faqs2 = this.faqs2.filter((item) => {
                return item.question.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
            });
        }
        if (this.faqs_model1 == 'documents') {
            this.faqs3 = this.totalfaqs3;

            this.faqs3 = this.faqs3.filter((item) => {
                return item.question.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
            });
        }
        if (this.faqs_model1 == 'payments') {
            this.faqs4 = this.totalfaqs4;

            this.faqs4 = this.faqs4.filter((item) => {
                return item.question.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
            });
        }

    }

    ionViewDidLoad() {
        console.log('ionViewDidLoad FaqPage');
    }

    searchableItems() {
        this.searchItems = [this.faqs1];
    }
    expandItem(item) {

        this.faqs1.map((listItem) => {

            if (item == listItem) {
                listItem.expanded = !listItem.expanded;
            } else {
                listItem.expanded = false;
            }

            return listItem;

        });
        this.faqs2.map((listItem) => {

            if (item == listItem) {
                listItem.expanded = !listItem.expanded;
            } else {
                listItem.expanded = false;
            }

            return listItem;

        });
        this.faqs3.map((listItem) => {

            if (item == listItem) {
                listItem.expanded = !listItem.expanded;
            } else {
                listItem.expanded = false;
            }

            return listItem;

        });
        this.faqs4.map((listItem) => {

            if (item == listItem) {
                listItem.expanded = !listItem.expanded;
            } else {
                listItem.expanded = false;
            }

            return listItem;

        });
    }
    // getItems(ev) {
    //     // Reset items back to all of the items
    //     this.searchableItems();

    //     // set val to the value of the ev target
    //     var val = ev.target.value;

    //     // if the value is an empty string don't filter the items
    //     //return this.searchItems;
    //     // if (val && val.trim() != '') {
    //     //   this.searchItems = this.searchItems.filter((searchItems) => {
    //     //     return (searchItems.toLowerCase().indexOf(val.toLowerCase()) > -1);
    //     //   })
    //     // }
    //   }

}
