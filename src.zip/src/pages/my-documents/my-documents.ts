import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { FacadeService } from '../../providers/FacadeService';
import { LoadingController } from 'ionic-angular';
import { Utility } from '../../providers/utility';
import { LoginPage } from '../login/login';
import { DashboardOnePage } from '../dashboard-one/dashboard-one';

import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';  
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
/**
 * Generated class for the MyDocumentsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-my-documents',
  templateUrl: 'my-documents.html',
})
export class MyDocumentsPage {
    myDocList: any[];  
    public ver = false;
    private fileTransfer: FileTransferObject;    
    constructor(
    private myService: FacadeService,
    public navCtrl: NavController,
    private utility: Utility,public alert: AlertController,
    public navParams: NavParams, private transfer: FileTransfer, private file: File, private androidPermissions: AndroidPermissions) {
  }

  getDocumentList(userId) {
    this.utility.showLoader();
    this.myService.getDocumentHistory(userId).subscribe(
        (res) => {
        console.log(userId)
        this.utility.dismissLoader();
        this.myDocList = res.response;      
        if(res.response.length == 0){
          this.ver = true;
        }
        else{
          this.ver = false;
        }
        console.log(this.myDocList);
      },
      (err) => {
        this.utility.dismissLoader();
      }
    )
  }

  download(fileName, filePath) {
      let ext = filePath.split('.').pop();
      console.log(ext)
      //this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.CAMERA).then(
      //    result => console.log('Has permission?', result.hasPermission),
      //    err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.CAMERA)
      //);
      
      //here encoding path as encodeURI() format.  
      let url = encodeURI(filePath);
      //here initializing object.  
      this.fileTransfer = this.transfer.create();
      // here iam mentioned this line this.file.externalRootDirectory is a native pre-defined file path storage. You can change a file path whatever pre-defined method. 
   
      this.fileTransfer.download(url, this.file.externalRootDirectory + fileName + "." + ext, true).then((entry) => {
          //here logging our success downloaded file path in mobile.  
          this.presentAlert("Your file have been downloaded successfully.");
          console.log('download completed: ' + entry.toURL());
      }, (error) => {
          this.presentAlert('download failed: ' + error);
          //here logging our error its easier to find out what type of error occured.  
          console.log('download failed: ' + error);
      });
  }     


  ionViewDidLoad() {
    if (localStorage.getItem('student_PID') != null || localStorage.getItem('student_PID') != undefined) {
      this.getDocumentList(this.utility.getUserId());
      console.log('ionViewDidLoad MyDocumentsPage');  
    }else{
      let alert = this.alert.create({
        title: 'Sign In Required',
        message: 'Sign In is Required to Perform this Action',
        buttons: [
  
          {
            text: 'Sign In',
            handler: () => {
              this.navCtrl.setRoot(LoginPage);
            }
          },
          {
            text: 'Cancel',
            role: 'cancel',
            handler: () => {
              console.log('Cancel clicked');
              this.navCtrl.setRoot(DashboardOnePage);
            }
          }
        ]
      });
      alert.present();
    }    
  }

  presentAlert(msg) {
      let alert = this.alert.create({
          title: 'Information',
          subTitle: msg,
          buttons: [{
              text: 'OK',
              handler: () => {
              }
          }]
      });
      alert.present();
  }

  errorAlert(msg) {
      let alert = this.alert.create({
          title: 'Error',
          subTitle: msg,
          buttons: [{
              text: 'OK',
              handler: () => {
              }
          }]
      });
      alert.present();
  }
}
