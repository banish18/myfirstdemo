import { Component} from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';

import { PaymenthistoryPage } from '../paymenthistory/paymenthistory';
/**
 * Generated class for the PermitRenewalPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-permit-renewal',
  templateUrl: 'permit-renewal.html',
})
export class PermitRenewalPage {

  submitAttempt: boolean = false;

  constructor(public navCtrl: NavController, public navParams: NavParams,
    private alertCtrl: AlertController) {
  }

  payOption(payPercentage) {  
    return payPercentage;
  }

  payFee(){
    this.presentAlert();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PermitRenewalPage');
  }

  save() {
    this.submitAttempt = true;  
  }

  paymentDetail(option) {
    this.navCtrl.setRoot(PaymenthistoryPage);
  }
  presentAlert() {
    let alert = this.alertCtrl.create({
      title: 'Payment Successful',
      subTitle: 'Your payment recieved!!',
      buttons: [{
        text: 'OK',
        handler: () => {
          console.log('Buy clicked');
          //this.navCtrl.setRoot(DashboardPage);
        }
      }]
    });
    alert.present();
  }

}
