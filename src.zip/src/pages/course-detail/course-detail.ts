import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the CourseDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-course-detail',
  templateUrl: 'course-detail.html',
})
export class CourseDetailPage {
  tabs: any;
  constructor(public navCtrl: NavController, public navParams: NavParams) {

    // this.tabs = [
    //   { title: "Schedule", root: SchedulePage, icon: "calendar" },
    //   { title: "Speakers", root: SpeakerListPage, icon: "contacts" },
    //   { title: "Map", root: MapPage, icon: "map" },
    //   { title: "About", root: AboutPage, icon: "information-circle" },
    // ];

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CourseDetailPage');
  }

}
