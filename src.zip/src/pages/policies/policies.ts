import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { EventsProvider } from '../../providers/events/events';

/**
 * Generated class for the PoliciesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-policies',
  templateUrl: 'policies.html',
})
export class PoliciesPage {
  policyList: any;
  constructor(public navCtrl: NavController,
    public navParams: NavParams, public service: EventsProvider) {
    this.service.getPolicy().then(response => {
      console.log(JSON.stringify(response));

      let lang = localStorage.getItem("lang");
      if (lang == "en") {
        this.policyList = response['en'];
      } else {
        this.policyList = response['ar'];
      }

    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PoliciesPage');
  }

}
