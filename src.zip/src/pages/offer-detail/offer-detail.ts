import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { NewsServiceProvider } from '../../providers/news-service';

/**
 * Generated class for the NewsDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'offer-news-detail',
  templateUrl: 'offer-detail.html',
})
export class OfferDetailPage {

  offerDetail: any = {};
  constructor(public navCtrl: NavController, public navParams: NavParams, public service: NewsServiceProvider) {
    let newsDescription = this.navParams.get('offer');
    this.offerDetail = newsDescription;
    console.log(this.offerDetail);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewsDetailPage');
  }

}
