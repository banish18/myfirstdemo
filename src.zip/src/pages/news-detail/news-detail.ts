import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { NewsServiceProvider } from '../../providers/news-service';

/**
 * Generated class for the NewsDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-news-detail',
  templateUrl: 'news-detail.html',
})
export class NewsDetailPage {

  newsDetail: any = {};
  coursePrices: any[] = [];
  constructor(public navCtrl: NavController, public navParams: NavParams, public service: NewsServiceProvider) {
    let newsDescription = this.navParams.get('news');
    this.newsDetail = newsDescription;

    console.log(this.newsDetail);

    if (this.newsDetail.hasOwnProperty('prices')) {
      if (this.newsDetail.prices[0].length > 0) {
        console.log("course Price" + JSON.stringify(this.newsDetail.prices[0]));
        this.coursePrices = this.newsDetail.prices[0]; 
      }
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad NewsDetailPage');
  }

}
