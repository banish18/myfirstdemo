import { Component } from '@angular/core';
import { NavController, NavParams, ModalController } from 'ionic-angular';
import { ReviewModalPage } from '../review-modal/review-modal';
import { ChangeTrainerPage } from '../change-trainer/change-trainer';

/**
 * Generated class for the YourTrainerPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
    selector: 'page-your-trainer',
    templateUrl: 'your-trainer.html',
})
export class YourTrainerPage {
    baseUrl: string = '';
    trainerDetail: any = {};
    constructor(public navCtrl: NavController, public navParams: NavParams,
        public modalCtrl: ModalController) {
        //let data = this.navParams.get('trainer');
        this.baseUrl = localStorage.getItem("BaseURL");
        this.trainerDetail = this.navParams.get('trainer');
        console.log(this.trainerDetail)
    }

    ionViewDidLoad() {
        console.log('ionViewDidLoad YourTrainerPage');
    }
    openReviewModal(trainer) {
        console.log(trainer)
        let modal = this.modalCtrl.create(ReviewModalPage, { "trainerID": trainer.id});
        modal.present();
    }

    changeTrainer(trainer) {
        console.log(trainer)
        this.navCtrl.push(ChangeTrainerPage, { trainer: trainer});      
    }

    /*showRatingAlert() {
      let alert = this.alertCtrl.create({
        title: 'ADD REVIEW',
        cssClass: 'alertstar',
        enableBackdropDismiss: false,
        inputs: [
          {
            name: 'feedback',
            placeholder: 'Please give your valuable feedback'
          },
        ],
        buttons: [
          { text: '1', handler: data => { return false; }, cssClass: 'rate-icon-button' },
          { text: '2', handler: data => { return false; }, cssClass: 'rate-icon-button' },
          { text: '3', handler: data => { return false; }, cssClass: 'rate-icon-button' },
          { text: '4', handler: data => { return false; }, cssClass: 'rate-icon-button' },
          { text: '5', handler: data => { return false; }, cssClass: 'rate-icon-button' },
          { text: 'Later', handler: data => { }, cssClass: 'rate-action-button rate-later' },
          { text: 'Submit', handler: data => { }, cssClass: 'rate-action-button rate-now' },
        ]
      });
      // add event listener for icon buttons in ask rating alert popup
      setTimeout(() => {
        const buttonElms: NodeList = document.querySelectorAll('.alertstar .alert-button-group .rate-icon-button');
  
        for (let index = 0; index < buttonElms.length; index++) {
          buttonElms[index].addEventListener('click', this.selectedRatingHandler);
        }
      }, 500);
  
      alert.present();
    }*/
    resolveRec(rating: number) {
        console.log("current rated " + rating);
    }

    selectedRatingHandler = (event: MouseEvent) => {
        // handler for clicked rating icon button
        let target: any = event.target; // target element
        let siblings: HTMLCollection = target.parentElement.children; // list of all siblings

        for (let index = 0; index < siblings.length; index++) {
            siblings[index].classList.remove('selected-rating'); // remove selected class from all siblings
        }
        target.classList.add('selected-rating'); // add selected class to currently selected item

        let selectedIndex = parseInt(target.textContent);

        for (let index = (selectedIndex - 1); index >= 0; index--) {
            siblings[index].classList.add('selected-rating'); // remove selected class from all siblings
        }
    };
}
