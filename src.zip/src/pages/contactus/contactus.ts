import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { FacadeService } from '../../providers/FacadeService';
import { Utility } from '../../providers/utility';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
/**
 * Generated class for the ContactusPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
    selector: 'page-contactus',
    templateUrl: 'contactus.html',
})
export class ContactusPage {
    contactusForm: FormGroup;
    submitAttempt: boolean = false;
    username: string;
    emailAddress: string;
    phoneNumber: string;
    chatmessage: string;
    constructor(public fb: FormBuilder, public navCtrl: NavController,
        private utility: Utility, public alertCtrl: AlertController,
        public facadeService: FacadeService,
        public navParams: NavParams) {
        this.contactusForm = this.fb.group({
            username: new FormControl('', Validators.required),
            phoneNumber: new FormControl('', Validators.required),
            chatmessage: new FormControl('', Validators.required)
        });
    }

    ionViewDidLoad() {
        console.log('ionViewDidLoad ContactusPage');
    }

    submit() {
        if (!this.contactusForm.valid) {
            this.errorAlert("Please complete the form.");
            return;
        }
        let body = {
            name: this.username,
            mobile_number: this.phoneNumber,
            message: this.chatmessage
        }
        console.log(body)        
        this.utility.showLoader();
        this.facadeService.contactus(body).subscribe(
            res => {
                this.utility.dismissLoader();
                console.log(res);
                this.username = '';
                this.phoneNumber = '';
                this.chatmessage = '';
                this.presentAlert(res.response);
            },
            err => {
                this.utility.dismissLoader();
            }
        );
    }

    presentAlert(msg) {
        let alert = this.alertCtrl.create({
            title: 'Information Successfully Sent',
            subTitle: msg,
            buttons: [{
                text: 'OK',
                handler: () => {
                }
            }]
        });
        alert.present();
    }

    errorAlert(msg) {
        let alert = this.alertCtrl.create({
            title: 'Error',
            subTitle: msg,
            buttons: [{
                text: 'OK',
                handler: () => {
                }
            }]
        });
        alert.present();
    }
}
