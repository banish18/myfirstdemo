import { Component } from '@angular/core';
import { NavController, NavParams, MenuController, LoadingController } from 'ionic-angular';
import { SetpasswordPage } from '../setpassword/setpassword';
import { DashboardOnePage } from '../dashboard-one/dashboard-one';
import { LoginPage } from '../login/login';
import { LoginServiceProvider } from '../../providers/login-service';
import { TranslateService } from '@ngx-translate/core';
import { FormBuilder, FormControl, Validators, FormGroup } from '@angular/forms';
import { verifyOtpModel } from '../signup/signupModel';
// import swal from 'sweetalert';
/**
 * Generated class for the VerifyotpPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-verifyotp',
  templateUrl: 'verifyotp.html',
})
export class VerifyotpPage {

  student_PID = 0;
  mobile_number = 0;
  otpResponse = {};
  verifOtpForm: FormGroup;
  submitAttempt: boolean = false;
  model: verifyOtpModel = new verifyOtpModel();
  public loading: any;
  fiveMinutes = 60 * 5;
  timespan: any;

  constructor(public fb: FormBuilder, public navCtrl: NavController, public navParams: NavParams,
    public menuCtrl: MenuController, private loginService: LoginServiceProvider,
    private translate: TranslateService,
    public loadingController: LoadingController) {



    this.menuCtrl.enable(false, "ahlimenu");
    this.menuCtrl.swipeEnable(false, "ahlimenu");

    this.verifOtpForm = this.fb.group({
      digit1: new FormControl('', Validators.required),
      digit2: new FormControl('', Validators.required),
      digit3: new FormControl('', Validators.required),
      digit4: new FormControl('', Validators.required)
    });
  }

  ionViewDidLoad() {


    this.timespan = document.querySelector('#time');

    this.student_PID = parseInt(localStorage.getItem('student_PID'));
    this.mobile_number = parseInt(localStorage.getItem('mobile_number'));
    console.log('ionViewDidLoad VerifyotpPage');
    this.sendOtpRequest();
  }

  sendOtpRequest() {
    this.showLoader();
    let reqObj = {
      id: this.student_PID,
      lang: this.translate.defaultLang
    };
    this.loginService.sendOtp(this.student_PID).then((data) => {
      console.log("sendOtp");
      this.startTimer(this.fiveMinutes, this.timespan);
      console.log(data);
      this.loading.dismiss();
      this.otpResponse = data;
    }, (err) => {
      this.loading.dismiss();
      console.log("something went wrong " + err);
    });
  }
  submitForm() {
    this.showLoader();
    this.submitAttempt = true;
    for (let c in this.verifOtpForm.controls) {
      this.verifOtpForm.controls[c].markAsTouched();
    }

    if (!this.verifOtpForm.valid) {
      this.loading.dismiss();
      return;
    }

    console.log("this.signupForm.value: ");
    console.log(this.verifOtpForm.value);
    let receiveCode = parseInt(this.verifOtpForm.value.digit1 + this.verifOtpForm.value.digit2 + this.verifOtpForm.value.digit3 + this.verifOtpForm.value.digit4);
    console.log(this.otpResponse);

    // if (receiveCode === this.otpResponse['code']) {
    this.model.lang = this.translate.defaultLang;
    this.model.fileno = this.student_PID;
    this.model.mobile_number = this.mobile_number;
    this.model.otp = receiveCode;
    // this.model = Object.assign(this.model, this.signupForm.value);

    this.loginService.verifyOtp(this.student_PID, receiveCode).then((data) => {
      console.log("verifyOtp " + JSON.stringify(data));
      this.loading.dismiss();
      alert(data['staticMessage']);
      if (data['is_verified'] == 1)
        this.navCtrl.push(SetpasswordPage);
    }, (err) => {
      // swal("Warning", "Wrong Code Found, Please try again.", "error");
      console.log("something went wrong " + err);
    });
  }
  // else {
  //   this.loading.dismiss();
  //   alert("wrong code entered");
  // }



  verifyOTP() {
    this.navCtrl.push(SetpasswordPage)
  }

  navigateToLogin() {
    this.navCtrl.setRoot(LoginPage);
  }
  navigateToDashboard() {
    this.navCtrl.setRoot(DashboardOnePage);
  }
  moveFocus(nextElement) {
    nextElement.setFocus();
  }

  showLoader() {
    this.loading = this.loadingController.create({ content: "Loading, please wait..." });
    this.loading.present();
  }

  startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    setInterval(function () {
      minutes = parseInt("" + timer / 60, 10);
      seconds = parseInt("" + timer % 60, 10);

      minutes = minutes < 10 ? "0" + minutes : minutes;
      seconds = seconds < 10 ? "0" + seconds : seconds;

      display.textContent = minutes + ":" + seconds;

      if (--timer < 0) {
        timer = duration;
        return;
      }
    }, 1000);
  }

}
