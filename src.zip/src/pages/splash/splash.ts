import { Component, ViewChild, ChangeDetectorRef} from '@angular/core';
import { NavController, Slides, MenuController } from 'ionic-angular';
import { TranslateService } from '@ngx-translate/core';
import { DashboardPage } from '../dashboard/dashboard';
import { LoginPage } from '../login/login';
import { SignupPage } from '../signup/signup';

/**
 * Generated class for the SplashPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-splash',
  templateUrl: 'splash.html',
})
export class SplashPage {
  @ViewChild(Slides) slides: Slides;
  skipMsg: string = "Skip";
  state: string = 'x';
  public cssClass: string;

  constructor(public navCtrl: NavController, translate: TranslateService, 
    public cd: ChangeDetectorRef, public menuCtrl: MenuController) {
    this.menuCtrl.enable(false, "ahlimenu");
    this.menuCtrl.swipeEnable(false, "ahlimenu");
    console.log(translate.defaultLang);
    this.cssClass = "animated fadeInDownBig";
  }

  skip() {

    this.navCtrl.setRoot(DashboardPage);
    // let index = this.navCtrl.getActive().index;
    // this.navCtrl.push(HomePage).then(() => {
    //   this.navCtrl.remove(index);
    // });
    
  }
  viewDidEnter(){
    
  }

  // nextSlide(){
    
  // }
  slideChanged() {
    this.slides.slideNext();
    if (this.slides.isEnd()){
      this.skipMsg = "Alright, I got it";
    }
    this.cssClass = "animated fadeInDown";
    this.cd.detectChanges();
  }

  slideMoved() {

    setTimeout( () => {
      try
      {
        if (this.slides.getActiveIndex() >= this.slides.getPreviousIndex())
        {
          this.state = 'rightSwipe';
          this.cssClass = "animated fadeInDownBig";
        }else{
          this.state = 'leftSwipe';
          this.cssClass = "animated fadeInDownBig";
        }
        
      }catch(e){
       console.log(e); 
      }
    }, 2000);
   
  }
  navigateTo(page){

    if(page === 'register'){
      this.navCtrl.push(SignupPage);
    }else if(page === 'login'){
      this.navCtrl.setRoot(LoginPage);
    }
  }

  animationDone() {
    this.state = 'x';
  }

}
