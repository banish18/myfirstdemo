import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-cloud',
  templateUrl: 'cloud.html'
})
export class CloudPage {

  constructor(public navCtrl: NavController) {
  }
  
}
