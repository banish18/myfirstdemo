import { Component } from '@angular/core';
import { NavController, NavParams, ViewController } from 'ionic-angular';
import * as moment from 'moment';
import { FacadeService } from '../../providers/FacadeService';
import { Utility } from '../../providers/utility';
import { ChangeTrainerPage } from '../change-trainer/change-trainer';

/**
 * Generated class for the EventModalPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-event-modal',
  templateUrl: 'event-modal.html',
})
export class EventModalPage {

  event = { startTime: new Date().toISOString(), endTime: new Date().toISOString(), title: "Book Session" };
  minDate = new Date().toISOString();
  timeArr: any[] = [];
  public category: string = '';
  public language: String;
  public branch: String;
  minutes: any;
  branches: any[] = [];
  trainerInfo: any = {};   
  constructor(public navCtrl: NavController, private navParams: NavParams,
      public viewCtrl: ViewController, private utility: Utility, public facadeService: FacadeService) {
      this.utility.showLoader();
      this.language = "English";
      this.branch = "1";
    let preselectedDate = moment(this.navParams.get('selectedDay')).format();
    this.event.startTime = preselectedDate;
    this.event.endTime = preselectedDate;
    this.calculateTime();
    let data = this.navParams.get('trainer');
    console.log(data)
    this.trainerInfo = data;
    facadeService.getBranches(localStorage.getItem("lang")).subscribe(
        res => {
            this.utility.dismissLoader();
            this.branches = res.response;
            console.log(res.response);
        },
        err => {
            this.utility.dismissLoader();
        });
    //console.log(this.timeArr);
  }

  onTabChanged(tabName) {
    this.category = tabName;
  }

  cancel() {
    this.viewCtrl.dismiss();
  }

  save() {
      console.log("save :" + this.language + " " + this.branch);      
      let body = {
          'icon': this.trainerInfo.icon,
          'title': this.trainerInfo.title,
          'lang': this.language,
          'branch_id': this.branch,
          'instructor_id': this.trainerInfo.instructor_id          
      };
      console.log(body)
      localStorage.setItem("search", "true");
      this.navCtrl.push(ChangeTrainerPage, { trainer: body });
      //this.facadeService.searchTrainer(body).subscribe(
      //    res => {
      //        console.log(res.response)            
      //    },
      //    err => {
      //    }
      //);   

    //if (this.language !== undefined) {
    //  localStorage.setItem('lang', this.language.toString());
    //}
    //if (this.branch !== undefined) {
    //  localStorage.setItem('Branch', this.branch.toString());
    //}
    //this.viewCtrl.dismiss(this.event);
  }

  calculateTime() {
    this.timeArr = [];

    // debugger;
    let d = new Date(); //get a date object
    d.setHours(8, 0, 0, 0); //reassign it to today's midnight
    let hours: any;
    let minute: any;

    var date = d.getDate();
    while (date == d.getDate()) {
      hours = d.getHours();
      this.minutes = d.getMinutes();
      hours = hours == 0 ? 12 : hours; //if it is 0, then make it 12
      let ampm = "am";
      ampm = hours > 12 ? "pm" : "am";
      hours = hours > 12 ? hours - 12 : hours; //if more than 12, reduce 12 and set am/pm flag
      hours = ("0" + hours).slice(-2); //pad with 0
      minute = ("0" + d.getMinutes()).slice(-2); //pad with 0
      // if (hours >= 20)
      //   return;
      // let obj = { time: "" + hours + ":" + minute + " " + ampm }
      //console.log("hous " + hours);
      if (hours === "08" && ampm === "pm") {
        return this.timeArr;
      }
      this.timeArr.push({ time: "" + hours + ":" + minute });

      d.setMinutes(d.getMinutes() + 30); //increment by 5 minutes
    }

  }


  selectTime(val) {
    console.log("selectTime " + val.time);
  }
}
