import { Component, Sanitizer } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { SafePipe } from '../../pipes/safe/safe';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { DocumentViewer, DocumentViewerOptions } from '@ionic-native/document-viewer/ngx';
import { PdfViewerProvider } from '../../providers/pdf-viewer/pdf-viewer';

/**
 * Generated class for the PdfviewPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
    selector: 'page-pdfview',
    templateUrl: 'pdfview.html',
})
export class PdfviewPage {

    pdfURL: SafeResourceUrl;
    domainName: string = '';
    baseUrl: string = '';
    pathname: string = '';
    constructor(public navCtrl: NavController, public navParams: NavParams,
        public safe: SafePipe, public sanitizer: DomSanitizer, private document: DocumentViewer, public pdfViewer: PdfViewerProvider) {       
        //this.pdfURL = this.sanitizer.bypassSecurityTrustResourceUrl(this.baseUrl + pathname + "#page=" + localStorage.getItem("pageno"));
        //this.pdfURL = "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf";  
        //this.pdfViewer.openDocument('https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf');
        //this.document.viewDocument('https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf', 'application/pdf', options)

    }
    getPDFURL() {    
        this.baseUrl = localStorage.getItem("BaseURL");
        this.pathname = new URL(localStorage.getItem("pdfUrl")).pathname;
        console.log(this.baseUrl + this.pathname + "#page=" + localStorage.getItem("pageno"));
        return this.pdfViewer.openDocument(this.baseUrl + this.pathname + "#page=" + localStorage.getItem("pageno"));
        //return this.document.viewDocument(this.baseUrl + this.pathname + "#page=" + localStorage.getItem("pageno"), 'application/pdf', options)
        //return this.pdfURL;
    }
    ionViewDidLoad() {
        console.log('ionViewDidLoad PdfviewPage');
    }

}
