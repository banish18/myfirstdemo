import { NgModule } from '@angular/core';
import { ExpendableHeaderComponent } from './expendable-header/expendable-header';
import { TimelineComponent } from './timeline/timeline';
import { ShrinkingSegmentHeaderComponent } from './shrinking-segment-header/shrinking-segment-header';
import { ScrollableTabs } from './scrollable-tabs/scrollable-tabs';
import { AccordionComponent } from './accordion/accordion';
import { CarouselComponent } from './carousel/carousel';
@NgModule({
    declarations: [ExpendableHeaderComponent,
        TimelineComponent,
        ShrinkingSegmentHeaderComponent,
        ScrollableTabs,
    AccordionComponent,
    CarouselComponent],
    imports: [],
    exports: [ExpendableHeaderComponent,
        TimelineComponent,
        ShrinkingSegmentHeaderComponent,
        ScrollableTabs,
    AccordionComponent,
    CarouselComponent]
})
export class ComponentsModule { }
