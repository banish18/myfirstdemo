import { Component, Input, ElementRef, Renderer } from '@angular/core';

/**
 * Generated class for the ExpendableHeaderComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'expendable-header',
  templateUrl: 'expendable-header.html'
})
export class ExpendableHeaderComponent {

  @Input('scrollArea') scrollArea: any;
  @Input('currentheading') currentheading: any;
  headerHeight: any;
  newHeaderHeight: any;
  selectedSegment: any;

  constructor(public element: ElementRef, public renderer: Renderer) {
    console.log('Hello ExpendableHeaderComponent Component');
    this.headerHeight = 150;
    this.renderer.setElementStyle(this.element.nativeElement, 'height', this.headerHeight + 'px');
    this.selectedSegment = "2";

  }

  ngOnInit() {
    console.log(this.scrollArea);
    this.scrollArea.ionScroll.subscribe((ev) => {
      console.log(ev)
      this.resizeHeader(ev);
    });
    this.currentheading.ionScroll.subscribe((ev) => {
      // console.log("currentHeading "+ev)
      // this.resizeHeader(ev);
      var el = document.getElementById("customheading");
      console.log("currentHeading " + this.getOffset(el).top);
    });

  }
  getOffset(el) {
    const rect = el.getBoundingClientRect();
    return {
      left: rect.left + window.scrollX,
      top: rect.top + window.scrollY
    };
  }

  resizeSegment(){
    
  }
  resizeHeader(ev) {
    ev.domWrite(() => {
      console.log(ev.scrollTop);
      this.newHeaderHeight = this.headerHeight - ev.scrollTop;
      if (this.newHeaderHeight < 0) {
        document.getElementById("menuBtn").style.display = "block";
        this.newHeaderHeight = 0;
      } else {
        document.getElementById("menuBtn").style.display = "none";
        
      }
      this.renderer.setElementStyle(this.element.nativeElement, 'height', this.newHeaderHeight + 'px');
    });
  }

}
