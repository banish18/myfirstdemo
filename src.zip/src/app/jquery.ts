
import * as $ from 'jquery';
window['jQuery'] = window['$'] = $;
