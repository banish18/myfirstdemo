import { Component, ViewChild } from '@angular/core';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { TranslateService } from '@ngx-translate/core';

import { Network } from '@ionic-native/network';

import { SignupPage } from '../pages/signup/signup';
import { LoginPage } from '../pages/login/login';
import { ScheduleRoadAssessmentTestPage } from '../pages/schedule-road-assessment-test/schedule-road-assessment-test';
import { ScheduleRTARoadTestPage } from '../pages/schedule-rtaroad-test/schedule-rtaroad-test';
import { ScheduleYardAssessmentTestPage } from '../pages/schedule-yard-assessment-test/schedule-yard-assessment-test';
import { ScheduleRTAYardTestPage } from '../pages/schedule-rtayard-test/schedule-rtayard-test';
import { MilestonesPage } from '../pages/milestones/milestones';
import { ProfilePage } from '../pages/profile/profile';


import { HomePage } from '../pages/home/home';
import { SelectlangPage } from '../pages/selectlang/selectlang';
import { SettingsPage } from '../pages/settings/settings';
import { ChangeTrainerPage } from '../pages/change-trainer/change-trainer';
import { ContactusPage } from '../pages/contactus/contactus';
import { ChatareaPage } from '../pages/chatarea/chatarea';
import { MyDocumentsPage } from '../pages/my-documents/my-documents';
import { MenuController, Nav, Platform, Events } from 'ionic-angular';
import { DashboardPage } from '../pages/dashboard/dashboard';
import { YourTrainerPage } from '../pages/your-trainer/your-trainer';
import { FaqPage } from '../pages/faq/faq';
import { PermitRenewalPage } from '../pages/permit-renewal/permit-renewal';
import { DocumentsPage } from '../pages/documents/documents';
import { PickUpLocationPage } from '../pages/pick-up-location/pick-up-location';
import { Home_2Page } from '../pages/home-2/home-2';
import { PaymenthistoryPage } from '../pages/paymenthistory/paymenthistory';
import { NetworkProvider } from '../providers/network/network';
import { MenuOption } from '../providers/login-service';
import { StudentJourneyResponse, StudentServiceProvider } from '../providers/student-service';
import { DashboardOnePage } from '../pages/dashboard-one/dashboard-one';
import { TrainersPage } from '../pages/trainers/trainers';
import { PricePage } from '../pages/price/price';
import { RtacontentPage } from '../pages/rtacontent/rtacontent';
import { MockTestPage } from '../pages/mock-test/mock-test';
import { FacadeService } from '../providers/FacadeService';
import { Utility } from '../providers/utility';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) navCtrl: Nav;
  rootPage: any = null;
  student_PID = null;
  menuOptions: Array<MenuOption> = new Array<MenuOption>();
  studentJourneyResponse: StudentJourneyResponse = new StudentJourneyResponse();
  username: string;

  constructor(public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen,
    translate: TranslateService, public menuCtrl: MenuController, public facadeService: FacadeService,
    public events: Events, public network: Network, public networkProvider: NetworkProvider,
    public service: StudentServiceProvider, public utitlity: Utility, public androidPermissions: AndroidPermissions) {
    localStorage.clear();
    localStorage.setItem('lang', 'ar');
    translate.setDefaultLang('ar');
    translate.use('ar');
    //localStorage.setItem("BaseURL", "http://alahli.vinklin.club/");
    localStorage.setItem("BaseURL", "http://3.18.90.105/aadc_app/public/");
    console.log("platform " + platform);

    this.username = localStorage.getItem("userName");
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.networkProvider.initializeNetworkEvents();

      // Offline event
      this.events.subscribe('network:offline', () => {
        alert('network:offline ==> ' + this.network.type);
      });

      // Online event
      this.events.subscribe('network:online', () => {
        alert('network:online ==> ' + this.network.type);
      });

      statusBar.styleDefault();
      splashScreen.hide();
      statusBar.overlaysWebView(false);
      statusBar.backgroundColorByHexString('#30415f');
      if (platform.is('android')) {
        statusBar.overlaysWebView(false);
        statusBar.backgroundColorByHexString('#000000');
      }
      // this.splashScreen.hide();
      this.hideSplashScreen();

      //            statusBar.styleLightContent();
      //            statusBar.styleBlackTranslucent();

      this.init();


    });

    const skipIntro = localStorage.getItem('dashboard');
    console.log("dashboard " + skipIntro);
    if (skipIntro) {
      this.rootPage = LoginPage;
    } else {
      this.rootPage = SelectlangPage;
      localStorage.setItem('dashboard', 'true');
    }
  }

  hideSplashScreen() {
    if (this.splashScreen) {
      setTimeout(() => {
        this.splashScreen.hide();
      }, 100);
    }
  }
  init() {
    this.populateMenu();
    // (listen for student_PID after function is called)
    this.events.subscribe('student_PID', (data) => {
      console.log("event:subscribe ");
      console.log(data);
      this.username = localStorage.getItem("userName");
      if (data > 0) {
        this.service.getStudentJourney(data).then(response => {
          console.log("getStudentJourney");
          localStorage.setItem("StudentJourney", JSON.stringify(response));
          console.log(response);
          this.studentJourneyResponse = Object.assign(this.studentJourneyResponse, response);
        });
      }

    });

    // (listen for student_PID after function is called)

    this.events.subscribe('StudentJourneyResponse', (StudentJourneyResponse) => {
      // user and time are the same arguments passed in `events.publish(user, time)`
      console.log('app component', StudentJourneyResponse);
    });

    this.student_PID = parseInt(localStorage.getItem('student_PID')) | 0;

    this.events.publish('student_PID', this.student_PID);


    console.log('User created!')
    this.events.publish('user:created', StudentJourneyResponse);
  }

  isGuestUser() {
    this.student_PID = localStorage.getItem('student_PID');
    if (this.student_PID == null || this.student_PID == 0) {
      return true;
    }
    return false;
  }

  isTemRegisteredUser() {
    this.student_PID = localStorage.getItem('student_PID');
    if (this.student_PID !== null && this.student_PID !== 0) {
      if (!this.utitlity.isEmpty(this.studentJourneyResponse)) {
        return true;
      }
    }
  }

  isUserFileOpen() {
    if (!this.isGuestUser()) {
      if (!this.utitlity.isEmpty(this.studentJourneyResponse)) {
        if (this.studentJourneyResponse.OpenFile.status !== null) {
          return true;
        }
      }
      return false;
    } else {
      return false;
    }
  }

  populateMenu() {

    this.menuOptions = new Array<MenuOption>();
    this.menuOptions.push(new MenuOption("Payment Counter",
      "custom-driving-license-white",
      "paymentCounter()",
      true));

    this.menuOptions.push(new MenuOption("My Trainer",
      "custom-instructor",
      "myInstructor()",
      true));

    this.menuOptions.push(new MenuOption("FAQs",
      "custom-faq",
      "faq()",
      true));

    this.menuOptions.push(new MenuOption("Permit Renewal",
      "custom-learning-permit",
      "permitRenewal()",
      true));

    this.menuOptions.push(new MenuOption("Documents",
      "custom-documents",
      "myDocuments()",
      true));

    this.menuOptions.push(new MenuOption("Settings",
      "custom-settings",
      "appSettings()",
      true));

    this.menuOptions.push(new MenuOption("Contact Us",
      "custom-documents",
      "contactUs()",
      true));

    this.menuOptions.push(new MenuOption("Log out",
      "custom-logout",
      "logOut()",
      false));
  }

  home() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(DashboardOnePage);
  }

  paymentCounter() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(PaymenthistoryPage);
  }

  myInstructor() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(TrainersPage);
  }
  changeInstructor() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(ChangeTrainerPage);
  }
  gotoHome() {
    this.menuCtrl.close();
    if (!this.isGuestUser()) {
      if (this.isUserFileOpen()) {
        this.navCtrl.setRoot(DashboardPage);
      }
    } else {
      this.navCtrl.setRoot(LoginPage);
    }

  }
  myDocuments() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(DocumentsPage);
  }

  permitRenewal() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(PermitRenewalPage);
  }

  faq() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(FaqPage);
  }

  contactUs() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(ContactusPage);
  }
  chatArea() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(ChatareaPage);
  }


  pickUpLocation() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(PickUpLocationPage);
  }

  myDocumentNew() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(MyDocumentsPage);
  }

  home_2Screen() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(Home_2Page);
  }


  appSettings() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(SettingsPage);
  }
  goToHome(params) {
    if (!params) params = {};
    this.navCtrl.setRoot(HomePage);
  }

  goToSignup(params) {
    if (!params) params = {};
    this.navCtrl.setRoot(SignupPage);
  }

  goToLogin(params) {
    if (!params) params = {};
    this.navCtrl.setRoot(LoginPage);
  }
  goToScheduleRoadAssessmentTest(params) {

    if (!params) params = {};
    this.navCtrl.setRoot(ScheduleRoadAssessmentTestPage);
  }

  goToScheduleRTARoadTest(params) {
    if (!params) params = {};
    this.navCtrl.setRoot(ScheduleRTARoadTestPage);
  }

  goToScheduleYardAssessmentTest(params) {
    if (!params) params = {};
    this.navCtrl.setRoot(ScheduleYardAssessmentTestPage);
  }

  goToScheduleRTAYardTest(params) {
    if (!params) params = {};
    this.navCtrl.setRoot(ScheduleRTAYardTestPage);
  }

  goToMilestones(params) {
    if (!params) params = {};
    this.navCtrl.setRoot(MilestonesPage);
  }

  goToProfile(params) {
    if (!params) params = {};
    this.navCtrl.setRoot(ProfilePage);
  }

  price() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(PricePage);
  }

  rtaContent() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(RtacontentPage)
  }

  dashboard() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(DashboardPage);
  }


  mockTest() {
    this.menuCtrl.close();
    this.navCtrl.setRoot(MockTestPage);
  }

  logOut() {
    this.menuCtrl.close();
    localStorage.clear();
    localStorage.setItem('lang', 'en');
    this.facadeService.student_Pid = null;
    localStorage.setItem("BaseURL", "http://alahli.vinklin.club/");
    this.navCtrl.setRoot(LoginPage);
  }
}
