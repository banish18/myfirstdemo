import { FormsModule } from '@angular/forms';
import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { CartPage } from '../pages/cart/cart';
import { CloudPage } from '../pages/cloud/cloud';
import { SignupPage } from '../pages/signup/signup';
import { LoginPage } from '../pages/login/login';
import { ScheduleRTAYardTestPage } from '../pages/schedule-rtayard-test/schedule-rtayard-test';
import { ScheduleYardAssessmentTestPage } from '../pages/schedule-yard-assessment-test/schedule-yard-assessment-test';
import { ScheduleRoadAssessmentTestPage } from '../pages/schedule-road-assessment-test/schedule-road-assessment-test';
import { ScheduleRTARoadTestPage } from '../pages/schedule-rtaroad-test/schedule-rtaroad-test';
import { MilestonesPage } from '../pages/milestones/milestones';
import { ProfilePage } from '../pages/profile/profile';
import { StudentQuestionairePage } from '../pages/student-questionaire/student-questionaire';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core'
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { ParallaxHeaderDirective } from '../directives/parallax-header/parallax-header';
import { HideHeaderDirective } from '../directives/hide-header/hide-header';
import { ExpendableHeaderComponent } from '../components/expendable-header/expendable-header';
import { SwipeSegmentDirective } from '../directives/swipe-segment/swipe-segment';
import { SplashPage } from '../pages/splash/splash';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SelectlangPage } from '../pages/selectlang/selectlang';

import { TimelineComponent } from '../components/timeline/timeline';
import { TimelineTimeComponent } from '../components/timeline/timeline';
import { TimelineItemComponent } from '../components/timeline/timeline';
import { ShrinkingSegmentHeaderComponent } from '../components/shrinking-segment-header/shrinking-segment-header';
import { DashboardPage } from '../pages/dashboard/dashboard';


import { IonBottomDrawerModule } from 'ion-bottom-drawer';
import { VerifyotpPage } from '../pages/verifyotp/verifyotp';
import { SetpasswordPage } from '../pages/setpassword/setpassword';
import { ForgotpasswordPage } from '../pages/forgotpassword/forgotpassword';
import { TabPageCourses } from '../pages/tab-page-courses/tab-page-courses';
import { TabPageOffer } from '../pages/tab-page-offer/tab-page-offer';
import { DashboardOnePage } from '../pages/dashboard-one/dashboard-one';
import { CourseDetailPage } from '../pages/course-detail/course-detail';
import { OpenFilePage } from '../pages/open-file/open-file';
import { CountryServiceProvider } from '../providers/country-service';

import { FileTransfer } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';
import { Camera } from '@ionic-native/camera';
import { FilePath } from '@ionic-native/file-path';
import { TabPageNews } from '../pages/tab-page-news/tab-page-news';
import { NewsDetailPage } from '../pages/news-detail/news-detail';
import { TabPagePricing } from '../pages/tab-page-pricing/tab-page-pricing';
import { NewsServiceProvider } from '../providers/news-service';
import { SettingsPage } from '../pages/settings/settings';
import { FaqPage } from '../pages/faq/faq';
import { ChangeTrainerPage } from '../pages/change-trainer/change-trainer';
import { ContactusPage } from '../pages/contactus/contactus';
import { MyDocumentsPage } from '../pages/my-documents/my-documents';
import { PickUpLocationPage } from '../pages/pick-up-location/pick-up-location';
import { Home_2Page } from '../pages/home-2/home-2';
import { TrainerServiceProvider } from '../providers/trainer-service';
import { ScrollableTabs } from '../components/scrollable-tabs/scrollable-tabs';

import { BookingPage } from '../pages/booking/booking';
import { EventModalPage } from '../pages/event-modal/event-modal';
import { LoginServiceProvider } from '../providers/login-service';
import { YourTrainerPage } from '../pages/your-trainer/your-trainer';
import { DocumentsPage } from '../pages/documents/documents';
import { PermitRenewalPage } from '../pages/permit-renewal/permit-renewal';
import { PaymenthistoryPage } from '../pages/paymenthistory/paymenthistory';
import { StarRatingModule } from 'ionic3-star-rating';
import { ReviewModalPage } from '../pages/review-modal/review-modal';
import { CarouselComponent } from '../components/carousel/carousel';
import { ExpandableComponent } from '../components/expandable/expandable';
import { EventsProvider } from '../providers/events/events';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { enableProdMode } from '@angular/core';
import { NgCalendarModule } from 'ionic2-calendar';
import { NetworkProvider } from '../providers/network/network';
import { Network } from '@ionic-native/network';
import { StudentServiceProvider } from '../providers/student-service';
import { OpenFileServiceProvider } from '../providers/openfile-service';
import { ChatareaPage } from '../pages/chatarea/chatarea';
import { FacadeService } from '../providers/FacadeService';
import { Api } from '../providers/api';
import { Utility } from '../providers/utility';
import { DocumentViewer } from '@ionic-native/document-viewer/ngx';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';



//import { Toast } from '@ionic-native/toast/ngx';
import { TabPagePromotionsPage } from '../pages/tab-page-promotions/tab-page-promotions';
import { TrainersPage } from '../pages/trainers/trainers';
import { PricePage } from '../pages/price/price';
import { MockTestQuestionairePage } from '../pages/mock-test-questionaire/mock-test-questionaire';
import { RtacontentPage } from '../pages/rtacontent/rtacontent';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { PdfviewPage } from '../pages/pdfview/pdfview';
import { SafePipe } from '../pipes/safe/safe';
import { MockTestPage } from '../pages/mock-test/mock-test';
import { MockTestWizardPage } from '../pages/mock-test-wizard/mock-test-wizard';
import { OfferDetailPage } from '../pages/offer-detail/offer-detail';
import { AboutUsPage } from '../pages/about-us/about-us';
import { PoliciesPage } from '../pages/policies/policies';
import { PdfViewerProvider } from '../providers/pdf-viewer/pdf-viewer';

enableProdMode();

export function setTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    MyApp,
    TrainersPage,
    TabPagePromotionsPage,
    SelectlangPage,
    SplashPage,
    ShrinkingSegmentHeaderComponent,
    HomePage,
    CartPage,
    CloudPage,
    SignupPage,
    VerifyotpPage,
    SetpasswordPage,
    ForgotpasswordPage,
    LoginPage,
    DashboardPage,
    ScheduleRTAYardTestPage,
    ScheduleYardAssessmentTestPage,
    ScheduleRoadAssessmentTestPage,
    ScheduleRTARoadTestPage,
    MilestonesPage,
    ProfilePage,
    StudentQuestionairePage,
    ParallaxHeaderDirective,
    HideHeaderDirective,
    ExpendableHeaderComponent,
    SwipeSegmentDirective,
    TimelineComponent,
    TimelineItemComponent,
    TimelineTimeComponent,
    DashboardOnePage,
    TabPageCourses,
    TabPageOffer,
    TabPagePricing,
    NewsDetailPage,
    OfferDetailPage,
    TabPageNews,
    CourseDetailPage,
    OpenFilePage,
    SettingsPage,
    FaqPage,
    ChangeTrainerPage,
    ContactusPage,
    ChatareaPage,
    MyDocumentsPage,
    PickUpLocationPage,
    Home_2Page,
    ScrollableTabs,
    BookingPage,
    EventModalPage,
    YourTrainerPage,
    DocumentsPage,
    PermitRenewalPage,
    PaymenthistoryPage,
    ReviewModalPage,
    CarouselComponent,
    ExpandableComponent,
    ChatareaPage,
    MockTestQuestionairePage,
    PricePage,
    RtacontentPage,
    PdfviewPage,
    SafePipe,
    MockTestPage,
    MockTestWizardPage,
    AboutUsPage,
    PoliciesPage
  ],
  imports: [
    FormsModule,
    BrowserModule,
    StarRatingModule,
    HttpModule,
    NgCalendarModule,
    IonicModule.forRoot(MyApp, {
      backButtonText: '',
      iconMode: 'ios',
      modalEnter: 'modal-slide-in',
      modalLeave: 'modal-slide-out',
      tabsPlacement: 'bottom',
      pageTransition: 'ios'
    }),
    HttpClientModule,
    IonBottomDrawerModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (setTranslateLoader),
        deps: [HttpClient]
      }
    }),
    BrowserAnimationsModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    TrainersPage,
    TabPagePromotionsPage,
    DashboardPage,
    SelectlangPage,
    SplashPage,
    HomePage,
    CartPage,
    CloudPage,
    MockTestQuestionairePage,
    SignupPage,
    VerifyotpPage,
    SetpasswordPage,
    ForgotpasswordPage,
    LoginPage,
    ScheduleRTAYardTestPage,
    ScheduleYardAssessmentTestPage,
    ScheduleRoadAssessmentTestPage,
    ScheduleRTARoadTestPage,
    MilestonesPage,
    ProfilePage,
    StudentQuestionairePage,
    DashboardOnePage,
    TabPageCourses,
    TabPageOffer,
    TabPagePricing,
    TabPageNews,
    NewsDetailPage,
    OfferDetailPage,
    CourseDetailPage,
    OpenFilePage,
    SettingsPage,
    ChangeTrainerPage,
    ContactusPage,
    ChatareaPage,
    MyDocumentsPage,
    PickUpLocationPage,
    Home_2Page,
    BookingPage,
    EventModalPage,
    YourTrainerPage,
    DocumentsPage,
    FaqPage,
    PermitRenewalPage,
    PaymenthistoryPage,
    ReviewModalPage,
    ExpandableComponent,
    ChatareaPage,
    PricePage,
    RtacontentPage,
    PdfviewPage,
    MockTestPage,
    MockTestWizardPage,
    AboutUsPage,
    PoliciesPage
  ],
  providers: [
    FacadeService,
    Api,
    StatusBar,
    //    Toast,
    SplashScreen,
    { provide: ErrorHandler, useClass: IonicErrorHandler },
    CountryServiceProvider,
    LoginServiceProvider,
    NewsServiceProvider,
    TrainerServiceProvider,
    FileTransfer,
    File,
    Camera,
    FilePath,
    Network,
    EventsProvider,
    NetworkProvider,
    StudentServiceProvider,
    OpenFileServiceProvider,
    Utility,
    InAppBrowser,
    SafePipe,
    DocumentViewer,
    PdfViewerProvider,
    AndroidPermissions
  ]
})
export class AppModule { }