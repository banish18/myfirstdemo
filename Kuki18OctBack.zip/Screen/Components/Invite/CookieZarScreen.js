// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';
import { Checkbox } from 'react-native-paper';

import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  Pressable,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Loader from '../../Components/Loader';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';
import axios from 'axios';
import Api from '../../Constants/Api.js';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import { FontAwesome } from '@expo/vector-icons';

class CookieZarScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      RedeemedCokie:'0',
      DonateCokie:'0',
      cookieData:[],
      loading:false,
      paymentChecked:false,
      paymentGChecked:false,
      DonateNumber:''
    };
    AsyncStorage.setItem('activeClass', 'FactiveClass');
  
  }

 async getKukiData(){
    let udata = JSON.parse(await AsyncStorage.getItem('userData'));
    this.setState({loading:true});
      let data = JSON.stringify({
        user_id: udata.id
      });
      let headers = {
        headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
        }
      }
      axios.post(Api.apiUrl+'/get-user-cookie', data, headers)
      .then(res => {
        
        this.setState({loading:false});
        if(res.data.status == 'true'){
          //console.log(res.data); 
          this.setState({cookieData:res.data});
        
        }else{
          console.log(error); this.state.loading = false; 
        }
      }).catch(error => {
        if(error.toJSON().message === 'Network Error'){
          alert('no internet connection');
          this.setState({loading:false}); 
        }else{
          alert(error); this.setState({loading:false});
        }
      });
  }
  backScreen(){
    this.props.navigation.navigate('ListCookiesScreen');
  }

  componentDidMount() {
    this.getKukiData();
    this.focusListener = this.props.navigation.addListener('focus', () => {
       this.getKukiData();
      //Put your Data loading function here instead of my this.loadData()
    });
  }


  setpaymentChecked(val){
    this.setState({paymentChecked:val});
  }


  

  render (){

    const { checked,DonateCokie,RedeemedCokie,cookieData,loading,DonateNumber,paymentChecked,paymentGChecked} = this.state;

    let cookitQuant = '';
    
    if(cookieData.cookies > 0){
      cookitQuant = cookieData.cookies;
    }
    
    const redeedRequest = async () =>{

      if(this.state.paymentChecked == false && this.state.paymentGChecked == false){
        alert('Please select your payment method!');
        return;
      }
     
      if(RedeemedCokie == '0' || RedeemedCokie > cookitQuant){
        alert('Please enter valid quanity. You have only '+cookitQuant+' cookies in your account');
        return;
      }
      let payMethod = '';
      if(this.state.paymentChecked == false && this.state.paymentGChecked == true){
        payMethod = 'GPay';
      }else{
        payMethod = 'Paytm';
      }

     
      let udata = JSON.parse(await AsyncStorage.getItem('userData'));
      this.setState({loading:true});
      let data = JSON.stringify({
        user_id: udata.id,
        quanity:RedeemedCokie,
        payMethod:payMethod
      });
      let headers = {
        headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
        }
      }
      axios.post(Api.apiUrl+'/redeem-cookie-request', data, headers)
      .then(res => {
        
        this.setState({loading:false});
        if(res.data.status == 'true'){
          alert(res.data.message);
          this.setState({RedeemedCokie:'0'});
          this.state.paymentChecked == false;
          this.state.paymentGChecked == false;
        }else{
          console.log(error); this.state.loading = false; 
        }
      }).catch(error => {
        if(error.toJSON().message === 'Network Error'){
          alert('no internet connection');
          this.setState({loading:false}); 
        }else{
          alert(error); this.setState({loading:false});
        }
      });

    };
    const donateRequest = async () =>{

      if(DonateNumber == ''){
        alert('Please enter mobile number!');
        return;
      }
      if(DonateCokie == '0' || DonateCokie > cookitQuant){
        alert('Please enter valid quanity. You have only '+cookitQuant+' cookies in your account');
        return;
      }
      let udata = JSON.parse(await AsyncStorage.getItem('userData'));
      this.setState({loading:true});
      let data = JSON.stringify({
        user_id: udata.id,
        quantity:DonateCokie,
        phone_number:DonateNumber
      });
      console.log(data);
      let headers = {
        headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
        }
      }
      axios.post(Api.apiUrl+'/donate-cookie-request', data, headers)
      .then(res => {
        
        this.setState({loading:false});
        if(res.data.status == 'true'){
           alert(res.data.message);
          this.getKukiData();
          this.setState({DonateCokie:'0'});
          this.setState({DonateNumber:''});
        }else{
          alert(res.data.message);
        }
      }).catch(error => {
      if(error.toJSON().message === 'Network Error'){
          alert('no internet connection');
          this.setState({loading:false}); 
        }else{
          alert(error); this.setState({loading:false});
        }
         });

    };
    const handleSubmitPress = () => {

    }
    return <View style={{flex:1,height:'100%',backgroundColor:'#fff'}}><ScrollView><Loader loading={loading} /><View style={styles.mainBody}>

            <View style={styles.topheadSection}>
             <TouchableOpacity onPress={() =>
            this.backScreen()} activeOpacity={0.7}>
            
            <LinearGradient
        // Button Linear Gradient
        colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
        style={styles.backIconsCont}>

                <FontAwesome 
                  name={'angle-left'}
                  size={24} 
                  color={AppStyle.fontColor}
                  
                   
                />
               </LinearGradient>
            
         </TouchableOpacity>
              <Text style={styles.SectionHeadStyle}>Kuki Jar</Text>
              </View>
              <View style={styles.mainStection}>

               <View style={styles.jarMainSection}>
               <View style={styles.jarStection}>
                   {cookitQuant == '' &&    <Image
                      source={require('../../../assets/images/eptzar.jpg')}
                       style={[{
                       resizeMode: 'contain',
                        width:87,
                        height:103
                       
                      },styles.imgIcon]}

                      
                    /> }
                   {cookitQuant != '' &&  <Image
                      source={require('../../../assets/images/kuki_jar_final.jpg')}
                       style={[{
                       resizeMode: 'contain',
                        width:87,
                        height:103
                       
                      },styles.imgIcon]}
                    />
                  }
                </View>
                {cookitQuant == '' &&  <View style={styles.jarContentStection}>
                    <Text style={[styles.jarMainSectionCont]}>Your <Text style={styles.jarMainSectionCont}>Kuki</Text> Jar  is Empty</Text>

                    
                     
                     
                  </View>
                }
                {cookitQuant != '' &&  <View style={styles.jarContentStection}>
                    <Text style={[styles.jarMainSectionCont]}>Your <Text style={styles.jarMainSectionCont}>Kuki</Text> Jar Has : {cookitQuant} Kuki</Text>
                    
                     
                  </View>
                }

              </View> 
              <View style={styles.OuterBoxSec}>


              <View style={styles.bannerStection}>
               
             
              <Text style={styles.inviteCont}>Redeem cash against your cookies through Paytm or GPay</Text>
              
             
              </View>

               <View style={styles.pyamentCheckSec}>
               <View style={styles.pyamentCheckSecLeft}>
               <Text style={styles.pyamentCheckText}>Paytm</Text>
                  <Checkbox
                  status={paymentChecked ? 'checked' : 'unchecked'}
                  onPress={() => {
                    this.setState({paymentChecked:!paymentChecked});
                    this.setState({paymentGChecked:false});
                    //setpaymentChecked(!paymentChecked);
                  }}
                />
               </View>

               <View style={styles.pyamentCheckSecRight}>
               <Text style={styles.pyamentCheckText}>GPay</Text>
                  <Checkbox
                  status={paymentGChecked ? 'checked' : 'unchecked'}
                 
                  onPress={() => {
                    this.setState({paymentGChecked:!paymentGChecked});
                     this.setState({paymentChecked:false});
                    //setpaymentChecked(!paymentChecked);
                  }}
                />
               </View>
            
            </View>


           <View style={styles.numbrsareSec}>

           <View style={styles.BottonSection}>
                <View style={
                  styles.buttonEarnStyleOuterSec}
              >
               <Image
                source={require('../../../assets/images/icons/graycookie.png')}
                 style={[{
                 resizeMode: 'contain',
                  width:20,
                  height:20
                 
                }]}

                
              />
              <TextInput
                      style={styles.inputStyle}
                      onChangeText={(Kuki) =>
                        this.setState({RedeemedCokie:Kuki})
                      }
                      value={RedeemedCokie} //dummy@abc.com
                      placeholderTextColor="#ADAFBB"
                      autoCapitalize="none"
                     maxLength={10}
                      returnKeyType="next"
                      keyboardType='number-pad'
          
                    />
            </View>

           

             
             <TouchableOpacity
             style={styles.buttonnumberOuterStyleFirst}
               
              activeOpacity={0.8}
              onPress={redeedRequest}>
<LinearGradient
        // Button Linear Gradient
        colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
        style={styles.buttonnumberStyle}>
              <Text style={styles.buttonTextStyle}>Redeem </Text>
              <FontAwesome 
                  name={'angle-right'}
                  size={20} 
                  color={AppStyle.fontColor}
                  
                   
                />
              </LinearGradient>
            </TouchableOpacity>
              
              
            
             
              

             
              </View>


               

               </View> 
                </View> 
                <View style={styles.OuterBoxSec}>
<View style={styles.numbrsareSec}>
              <Text style={styles.donteContent}>Gift Kukies to a Loved one</Text>


              <View style={styles.BottonSection}>
                <View style={
                  styles.buttonEarnStyleOuterSec}
              >
               <Image
                source={require('../../../assets/images/icons/graycookie.png')}
                 style={[{
                 resizeMode: 'contain',
                  width:20,
                  height:20
                 
                }]}

                
              />
              <TextInput
                style={styles.inputStyle}
                onChangeText={(Kuki) =>
                  this.setState({DonateCokie:Kuki})
                }
                value={DonateCokie} //dummy@abc.com
                placeholderTextColor="#ADAFBB"
                autoCapitalize="none"
               maxLength={10}
                returnKeyType="next"
                keyboardType='number-pad'
    
              />
            </View>

              <View
             
               style={styles.buttonnumberOuterStyle}>
              <TextInput
                style={styles.inputdStyle}
                onChangeText={(Kuki) =>
                  this.setState({DonateNumber:Kuki})
                }
                placeholder="Phone Number" //dummy@abc.com
                value={DonateNumber} //dummy@abc.com
                placeholderTextColor="#000"
                autoCapitalize="none"
                maxLength={10}
                returnKeyType="next"
                keyboardType='number-pad'
    
              />
              
              
            </View>
             
              

             
              </View>
              </View>
               <View style={styles.donatebtn}>
            <TouchableOpacity
              
              activeOpacity={0.8}
              onPress={donateRequest}>
              <LinearGradient
        // Button Linear Gradient
        colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
        style={styles.buttonStyle}>
                  
              <Text style={styles.buttonTextStyleSec}>Gift</Text> 
              <View style={styles.buttonGiftStyleSec}>
              {/*<Feather 
                  name={'gift'}
                  size={20} 
                  color='red'
                   
                />*/}

                <Image
                      source={require('../../../assets/images/gift.png')}
                       style={[{
                       resizeMode: 'contain',
                        width:23,
                        height:23
                       
                      },styles.imgIcon]}

                      
                    />


              </View>
              
                </LinearGradient>
            </TouchableOpacity>
          </View>
              </View>

             
            
              </View>
              
          </View>
          </ScrollView>
          <CookieNavigationScreen navigation={this.props.navigation}/>
          </View>
          
           
        
      
  }
};
export default CookieZarScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex:1,
    backgroundColor: AppStyle.appColor,
    paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
     paddingBottom: AppStyle.appInnerBottomPadding,
     paddingTop: AppStyle.appInnerTopPadding,
    height:'100%'
  },
  topheadSection:{
    display:'flex',
    justifyContent:'flex-start',
    alignItems:'center',
    flexDirection:'row',
    marginBottom:15
  },
  backIconsCont:{
  borderWidth:1,
  borderColor:'#E8E6EA',
  borderRadius:15,
  paddingTop:12,
  paddingBottom:12,
  paddingLeft:20,
  paddingRight:20
  },
  mainStection:{
    width:'100%',
    marginTop:5,
    justifyContent:'center',
    
  },
  SectionHeadStyle: {
    fontSize:27,
    fontFamily: 'GlorySemiBold',
    fontWeight: '400',
    color:AppStyle.fontColor,
    marginLeft:20
  },
  bannerStection:{
    alignItems:'center',
    flexDirection:'row',
    justifyContent:'center',
  },
  OuterBoxSec:{
    borderWidth:1,
  borderRadius:15,
  borderColor: AppStyle.appIconColor,
  paddingLeft: 10,
  paddingRight: 10,
  paddingTop: 15,
  paddingBottom: 15,
  marginTop:10
  },
  jarStection:{
    
    width:'20%'
  },
  jarMainSection:{
    flexDirection:'row',
    alignItems:'center'
  },
  jarMainSectionCont:{
    fontSize:18,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:AppStyle.fontColor,
    paddingLeft:30,
    lineHeight:24
  },
  jarMainColorSectionCont:{
    fontSize:19,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:AppStyle.appIconColor
  },
  jarContentStection:{
    width:'80%',
    justifyContent:'flex-start',
  },
  inviteCont:{
    fontSize:18,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'#000',
    
    width:'90%',
    
    textAlign:'center',
    lineHeight:23
  },
  inviteDownCont:{
    fontSize:15,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:AppStyle.fontColor,
    marginTop:15,
    paddingLeft:10,
    paddingRight:10,
    textAlign:'center'
  },
  numbrsareSec:{
    flex:1,
    width:'100%',
    
  },
  sharenumbCont:{
    fontSize:15,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'rgba(253, 139, 48, 0.69)',
    marginTop:15,
    paddingLeft:12,
    paddingRight:12,
    textAlign:'center'
  },
  BottonSection:{
    flexDirection:'row',
    justifyContent:'space-between',
    marginTop:15,
    
  },
  buttonEarnStyleOuter:{
  backgroundColor:'#F3F3F3',
  paddingLeft:25,
    paddingRight:25,
  
    flexDirection:'row',
    borderRadius:15,
     width:'48%',
     alignItems:'center'
},
  buttonnumberStyle:{
    paddingTop:AppStyle.buttonTBPadding,
    paddingLeft:25,
    paddingRight:25,
    paddingBottom:AppStyle.buttonTBPadding,
    flexDirection:'row',
    borderRadius:15,
     width:'100%',
     alignItems:'center',
      justifyContent:'center',

  },
  buttonnumberOuterStyleFirst:{
    
    flexDirection:'row',
    borderRadius:15,
     width:'60%',
     alignItems:'center',
     justifyContent:'center',
     textAlign:'center'


  },
  buttonnumberOuterStyle:{
    paddingTop:12,
    paddingLeft:15,
    paddingRight:15,
    paddingBottom:12,
    flexDirection:'row',
    borderRadius:15,
    width:'60%',
    alignItems:'center',
    backgroundColor:'#F3F3F3',


  },
  buttonEarnStyleOuterSec:{
    paddingBottom:10,
    paddingTop:10,
    paddingLeft:15,
    paddingRight:15,
    flexDirection:'row',
    borderRadius:15,
    width:'38%',
    alignItems:'center',
    backgroundColor:'#F3F3F3',
    justifyContent:'center'
  },
  buttonEarnStyle:{
    paddingLeft:25,
    paddingRight:25,
    paddingTop:15,
    paddingBottom:15,
    borderRadius:15,
    flexDirection:'row',
    width:'48%',
    
    justifyContent:'space-around'
  },
  inputStyle:{

    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
    width:'70%',
    paddingRight: 15,
    borderTopRightRadius:10,
    borderBottomRightRadius:10,
    fontFamily: 'Abel',
    fontSize:19
  },
  inputdStyle:{
    color: AppStyle.inputBlackcolorText,
    width:'100%',
    fontSize:19,
    borderTopRightRadius:10,
    borderBottomRightRadius:10,
    fontFamily: 'Abel'
  },
  buttonTextStyle:{
    fontSize:18,
    fontFamily: 'GlorySemiBold',
    fontWeight: '400',
    color:AppStyle.fontButtonColor,
    marginRight:8
  },buttonGiftStyleSec:{
    marginTop:-5
  },
  buttonTextStyleSec:{
    fontSize:18,
    fontFamily: 'GlorySemiBold',
    fontWeight: '400',
    color:AppStyle.fontButtonColor,
    marginRight:8
  },
  donteContent:{
    fontSize:18,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'#000',
    textAlign:'center',
  },
  donatebtn:{
    marginTop:15
  },
  buttonStyle: {
    borderWidth: 0,
    color: '#FFFFFF',
    borderColor: '#dadae8',
    alignItems: 'center',
    borderRadius: 15,
    flexDirection:'row',
    paddingTop:AppStyle.buttonTBPadding,
    paddingBottom:AppStyle.buttonTBPadding,
    textAlign:'center',
    width:'100%',
    alignItems:'center',
    justifyContent:'center'
  },
  pyamentCheckSec:{
    flexDirection:'row',
    justifyContent:'space-around',
    alignItems:'center',
    marginTop:10
  },
  pyamentCheckSecLeft:{
    flexDirection:'row',
    justifyContent:'space-between',
    alignItems:'center'
  },
  pyamentCheckSecRight:{
    flexDirection:'row',
    justifyContent:'space-between',
    alignItems:'center'
  },
  pyamentCheckText:{
    fontSize:18,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:AppStyle.fontColor,
  }

});