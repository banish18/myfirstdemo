// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';


import {
  StyleSheet,
  TextInput,
  View,
  Share,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  Pressable,
  TouchableHighlight,
  KeyboardAvoidingView,
  Linking
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Loader from '../../Components/Loader';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import { FontAwesome5 } from '@expo/vector-icons';




class InviteEarnScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      checked:'male',
      inviteNumber:'',
      loading:false,
    };
    AsyncStorage.setItem('activeClass', 'FactiveClass');
  
  }

 createAlert = (FirstName) =>
  Alert.alert(
    "Required",
    FirstName,
    [
     
      { text: "OK", onPress: () => console.log("OK Pressed") }
    ]
  );
  backScreen(){
    
    this.props.navigation.navigate('UserstatusScreen');
  }
  nextScreen(){
    
    this.props.navigation.navigate('UserstatusScreen');
  }

  sendLink(){
    Linking.openURL(`whatsapp://send?text=dowanload app uisng this link`)
  }

  render (){

    const { checked,inviteNumber,loading} = this.state;
   
    let message = 'Download and install the app using this url : https://google.com';
    const postOnFacebook = () => {
          let sharingUrl = 'google.com';
      Linking.openURL(`fb-messenger://share?link=${sharingUrl}&title='Download'`);

    };
    const postOnWhatsapp = () => {
     Linking.openURL('whatsapp://send?text=dowanload app uisng this link');
    };
    const postOnNmber = () => {
      if(inviteNumber == ''){
        alert('Please enter number to earn!');
        return;
      }
          Linking.openURL('sms:'+inviteNumber+'?body='+message);

    }; 
    const postOnInstagram = () => {
     alert('coming soon!');

    };
   const postOnTwitter = () => {
       alert('coming soon!');

      };

     const  onShare = async () => {
       this.setState({loading:true});
    try {
      const result = await Share.share({
        message:
          message,
          url:'https://google.com'
      });

      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
           this.setState({loading:false});
        } else {
          this.setState({loading:false});
        }
      } else if (result.action === Share.dismissedAction) {
        this.setState({loading:false});
      }
    } catch (error) {
      alert(error.message);
      this.setState({loading:false});
    }
  };

    const handleEarnPress = () =>{
      this.props.navigation.navigate('CookieZarScreen');
    };
    const handleSubmitPress = () =>{
      alert('Working');
    };
    let phone = '7889282154';
     let phoneNumber = phone;
  if (Platform.OS !== 'android') {
    phoneNumber = `telprompt:${phone}`;
  }
  else  {
    phoneNumber = `tel:${phone}`;
  }

    return <View style={{flex:1,height:'100%'}}><ScrollView><Loader loading={loading} /><View style={styles.mainBody}>

            <View style={styles.outermainSection}>
            <View style={styles.topheadSection}>
              <Text style={styles.SectionHeadStyle}>Invite and Earn</Text>

             
              </View>
              <View style={styles.mainStection}>
              <View style={styles.bannerStection}>
               <Image
                source={require('../../../assets/images/Refer-Earn.png')}
                 style={[{
                 resizeMode: 'contain',
                  width:'90%',
                  height:220,
                 marginTop:10
                },styles.imgIcon]}

                
              />
              <Text style={styles.inviteCont}>Invite your contact to downloand this app and you both earn 10 cookies each for FREE. Simply share the download link with you contacts</Text>

              </View>
              </View>
              
              <View style={styles.bannerStection}>

              
             
              </View>



              <View style={styles.numbrsareSec}>
                <View style={styles.SocialIcons}>

               <TouchableOpacity onPress={onShare} activeOpacity={0.7}>
              <LinearGradient
                // Button Linear Gradient
                colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
                style={styles.SocialIconBg}>
                 <FontAwesome5 
                  name={'whatsapp'}
                  size={20} 
                  color={AppStyle.fontColor}
                   
                />
                </LinearGradient>
                </TouchableOpacity>

                 
                   <TouchableOpacity onPress={onShare} activeOpacity={0.7}>
              <LinearGradient
                // Button Linear Gradient
                colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
                style={styles.SocialIconBg}>
                 <Feather 
                  name={'facebook'}
                  size={20} 
                  color={AppStyle.fontColor}
                   
                />
                </LinearGradient>
                </TouchableOpacity>
                  <TouchableOpacity onPress={onShare} activeOpacity={0.7}>
              <LinearGradient
                // Button Linear Gradient
                colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
                style={styles.SocialIconBg}>
                 <FontAwesome5 
                  name={'instagram'}
                  size={20} 
                  color={AppStyle.fontColor}
                   
                />
                </LinearGradient>
                </TouchableOpacity>
                 <TouchableOpacity onPress={onShare} activeOpacity={0.7}>
              <LinearGradient
                // Button Linear Gradient
                colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
                style={styles.SocialIconBg}>
                 <Feather 
                  name={'twitter'}
                  size={20} 
                  color={AppStyle.fontColor}
                   
                />
                </LinearGradient>
                </TouchableOpacity>
              </View>
              </View>
              </View>
              <View style={styles.outermainSection}>
              <View style={styles.mainStection}>
               <Text style={styles.sharenumbCont}>Shere the mobile number of your contact who referred this app to you and both earn 10 cookies each for FREE</Text>
              
              </View>

              <View style={styles.OuterStyle}>
              <View style={styles.buttonnumberOuterStyle}>
              <TextInput
                style={styles.inputdStyle}
                onChangeText={(numberU) =>
                  this.setState({inviteNumber:numberU})
                }
                placeholder="Phone Number" //dummy@abc.com
                value={inviteNumber} //dummy@abc.com
                placeholderTextColor={AppStyle.fontButtonColor}
                autoCapitalize="none"
                maxLength={10}
                returnKeyType="next"
                keyboardType='number-pad'
    
              />
              </View>
              <View style={styles.buttonnumberRightOuterStyle}>

               <TouchableOpacity onPress={postOnNmber} activeOpacity={0.7}>
              <LinearGradient
                // Button Linear Gradient
                colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
                style={styles.buttonEarnStyle}>
                 <Image
                source={require('../../../assets/images/icons/graycookie.png')}
                 style={[{
                 resizeMode: 'contain',
                  width:20,
                  height:20,
                  marginRight:10
                 
                }]}

                
              />
              <Text style={styles.buttonTextStyle}>


              Earn</Text>
                </LinearGradient>
                </TouchableOpacity>


            
              </View>
              </View>
             
              </View>
              
              
          </View>
          </ScrollView><CookieNavigationScreen navigation={this.props.navigation}/></View>
          
          
           
        
      
  }
};
export default InviteEarnScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex:1,
    backgroundColor: AppStyle.appColor,
    paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
     paddingBottom: AppStyle.appInnerBottomPadding,
     paddingTop: AppStyle.appInnerTopPadding,
    height:'100%'
  },
  outermainSection:{
     paddingLeft:10,
    paddingRight:10,
    paddingTop:25, 
    paddingBottom:25, 
    borderWidth:1,
    borderColor: AppStyle.appIconColor,
    width:'100%',
    borderRadius:15,
    marginBottom:20
  },
  topheadSection:{
    display:'flex',
    justifyContent:'space-between',
    alignItems:'center',
    flexDirection:'row'
  },
  mainStection:{
    width:'100%',
   
    justifyContent:'center',
    
  },
  SectionHeadStyle: {
    fontSize:27,
    fontFamily: 'GlorySemiBold',
    color: AppStyle.fontColor,
  },
  bannerStection:{
    alignItems:'center',
    justifyContent:'center',

  },
  inviteCont:{
    fontSize:15,
    fontFamily: 'Abel',
    lineHeight: 22,
    color:AppStyle.fontColor,
    marginTop:15,
    paddingLeft:10,
    paddingRight:10,
    textAlign:'center',

  },
  inviteDownCont:{
    fontSize:17,
    fontFamily: 'GlorySemiBold',
    lineHeight: 22,
    color: AppStyle.fontColor,
    marginTop:15,
    marginBottom:15,
    paddingLeft:10,
    paddingRight:10,
    textAlign:'center'
  },
  numbrsareSec:{
    width:'100%'
  },
  OuterStyle:{
    flexDirection:'row',
    justifyContent:'space-between',
    marginTop:20
  },
  buttonnumberOuterStyle:{
    paddingLeft:25,
    paddingRight:25,
   
    flexDirection:'row',
    borderRadius:15,
     width:'60%',
     alignItems:'center',
     backgroundColor:AppStyle.btnbackgroundColor

  },
  inputdStyle:{

    color: AppStyle.fontButtonColor,
    
    width:'100%',
    
    fontSize:AppStyle.inputFontsize,
    borderTopRightRadius:10,
    borderBottomRightRadius:10,
    fontFamily: 'Abel'
  },

  sharenumbCont:{
    fontSize:15,
    fontFamily: 'Abel',
    lineHeight: 22,
    color:AppStyle.fontColor,
    marginTop:-17,
    paddingLeft:12,
    paddingRight:12,
    textAlign:'center'
  },
  buttonTextStyle:{
    color: AppStyle.inputBlackcolorText,
    fontSize:AppStyle.inputFontsize,
    borderTopRightRadius:10,
    borderBottomRightRadius:10,
    fontFamily: 'Abel'
  },
  buttonEarnStyle:{
    paddingLeft:25,
    paddingRight:25,
    paddingTop:AppStyle.buttonTBPadding,
    paddingBottom:AppStyle.buttonTBPadding,
    borderRadius:15,
    flexDirection:'row',
    justifyContent:'space-around'
  },
  SocialIcons:{
  flexDirection:'row',
  marginTop:10,
  justifyContent:'space-evenly'
  },
  SocialIconBg:{
  borderRadius:15,
  flexDirection:'row',
  alignItems:'center',
  
  paddingLeft:20,
  paddingRight:20,
  paddingTop:18,
  paddingBottom:18
  }

});