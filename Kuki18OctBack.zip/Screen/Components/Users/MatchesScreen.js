// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';


import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Loader from '../../Components/Loader';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';

class MatchesScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      checked:'male'
    };
    AsyncStorage.setItem('activeClass', 'FactiveClass');
  
  }

 createAlert = (FirstName) =>
  Alert.alert(
    "Required",
    FirstName,
    [
     
      { text: "OK", onPress: () => console.log("OK Pressed") }
    ]
  );
  backScreen(){
    
    this.props.navigation.navigate('UserstatusScreen');
  }
  nextScreen(){
    
    this.props.navigation.navigate('UserstatusScreen');
  }

  

  render (){

    const { checked} = this.state;


    return <View style={{ flex: 1 }}><ScrollView><View style={styles.mainBody}>
            <View style={styles.topheadSection}>
              <Text style={styles.SectionHeadStyle}>Matches</Text>
              <TouchableOpacity
                  style={styles.fillterBtnSection}
                  activeOpacity={0.5}
                  onPress={this.backScreen.bind(this,'x')}>
                     <Image
                        source={require('../../../assets/images/icons/sort-two.png')}
                        style={{
                         resizeMode: 'contain',
                          height:16,
                         
                        }}
                      />
                  </TouchableOpacity>  
             
              </View>
              <View><Text style={styles.contSection}>This is a list of people who have liked you and your matches.</Text></View>
              <View style={styles.filterTopsection}>
                <View style={styles.filterTopsectionLeft}></View>
                <Text style={styles.filterTopsectionCenter}>Today</Text>
                <View style={styles.filterTopsectionRight}></View>
              </View>
              <View style={styles.gallerySection}>
                <View ><Image
                        source={require('../../../assets/images/favphotoone.png')}
                        style={{
                         resizeMode: 'contain',
                          width:140,
                          height:200,
                         
                        }}
                      />
                      <View style={styles.imgIconsection}>
                       <TouchableOpacity
                                           style={styles.imgIconsectionInner}
                                            activeOpacity={0.5}
                                            onPress={this.backScreen.bind(this,'x')}>

                           
                                                 <Image
                                                  source={require('../../../assets/images/icons/cancelw.png')}
                                                   style={[{
                                                   resizeMode: 'contain',
                                                    width:10
                                                   
                                                  },styles.imgIcon]}
                                                />
                         
                     
                      </TouchableOpacity>
                        <TouchableOpacity
                                           style={styles.imgIconsectionInner}
                                            activeOpacity={0.5}
                                            onPress={this.backScreen.bind(this,'x')}>

                           
                                                 <Image
                                                  source={require('../../../assets/images/icons/fav.png')}
                                                   style={[{
                                                   resizeMode: 'contain',
                                                    width:10
                                                   
                                                  },styles.imgIcon]}
                                                />
                         
                     
                      </TouchableOpacity>
                      </View>
                     
                      </View>

                     <View ><Image
                        source={require('../../../assets/images/favphototwo.png')}
                        style={{
                         resizeMode: 'contain',
                          width:140,
                          height:200,
                         
                        }}
                      />
                      <View style={styles.imgIconsection}>
                      <TouchableOpacity
                                           style={styles.imgIconsectionInner}
                                            activeOpacity={0.5}
                                            onPress={this.backScreen.bind(this,'x')}>

                           
                                                 <Image
                                                  source={require('../../../assets/images/icons/cancelw.png')}
                                                   style={[{
                                                   resizeMode: 'contain',
                                                    width:10
                                                   
                                                  },styles.imgIcon]}
                                                />
                         
                     
                      </TouchableOpacity>
                       <TouchableOpacity
                                           style={styles.imgIconsectionInner}
                                            activeOpacity={0.5}
                                            onPress={this.backScreen.bind(this,'x')}>

                           
                                                 <Image
                                                  source={require('../../../assets/images/icons/fav.png')}
                                                   style={[{
                                                   resizeMode: 'contain',
                                                    width:10
                                                   
                                                  },styles.imgIcon]}
                                                />
                         
                     
                      </TouchableOpacity>
                      </View>
                     
                      </View>

              </View>
              <View style={styles.gallerySection}>
                <View ><Image
                        source={require('../../../assets/images/favphotothr.png')}
                        style={{
                         resizeMode: 'contain',
                          width:140,
                          height:200,
                         
                        }}
                      />
                      <View style={styles.imgIconsection}>
                       <TouchableOpacity
                                           style={styles.imgIconsectionInner}
                                            activeOpacity={0.5}
                                            onPress={this.backScreen.bind(this,'x')}>

                           
                                                 <Image
                                                  source={require('../../../assets/images/icons/cancelw.png')}
                                                   style={[{
                                                   resizeMode: 'contain',
                                                    width:10
                                                   
                                                  },styles.imgIcon]}
                                                />
                         
                     
                      </TouchableOpacity>
                        <TouchableOpacity
                                           style={styles.imgIconsectionInner}
                                            activeOpacity={0.5}
                                            onPress={this.backScreen.bind(this,'x')}>

                           
                                                 <Image
                                                  source={require('../../../assets/images/icons/fav.png')}
                                                   style={[{
                                                   resizeMode: 'contain',
                                                    width:10
                                                   
                                                  },styles.imgIcon]}
                                                />
                         
                     
                      </TouchableOpacity>
                      </View>
                     
                      </View>

                     <View ><Image
                        source={require('../../../assets/images/favphotofor.png')}
                        style={{
                         resizeMode: 'contain',
                          width:140,
                          height:200,
                         
                        }}
                      />
                      <View style={styles.imgIconsection}>
                      <TouchableOpacity
                                           style={styles.imgIconsectionInner}
                                            activeOpacity={0.5}
                                            onPress={this.backScreen.bind(this,'x')}>

                           
                                                 <Image
                                                  source={require('../../../assets/images/icons/cancelw.png')}
                                                   style={[{
                                                   resizeMode: 'contain',
                                                    width:10
                                                   
                                                  },styles.imgIcon]}
                                                />
                         
                     
                      </TouchableOpacity>
                       <TouchableOpacity
                                           style={styles.imgIconsectionInner}
                                            activeOpacity={0.5}
                                            onPress={this.backScreen.bind(this,'x')}>

                           
                                                 <Image
                                                  source={require('../../../assets/images/icons/fav.png')}
                                                   style={[{
                                                   resizeMode: 'contain',
                                                    width:10
                                                   
                                                  },styles.imgIcon]}
                                                />
                         
                     
                      </TouchableOpacity>
                      </View>
                     
                      </View>

              </View>


              
          </View>
          </ScrollView>
          <CookieNavigationScreen navigation={this.props.navigation}/>
          </View>
           
        
      
  }
};
export default MatchesScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex:1,
    backgroundColor: AppStyle.appColor,
    paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
    paddingBottom: 35,
    paddingTop: 40,
    height:'100%'
  },
  topheadSection:{
    display:'flex',
    justifyContent:'space-between',
    alignItems:'center',
    flexDirection:'row',
    marginBottom:15
  },
  mainStection:{
    width:'100%',
  },
  SectionHeadStyle: {
    fontSize:34,
    fontFamily: 'Abel',
    fontWeight: '400',
  },
  fillterBtnSection:{
    borderWidth:1,
    borderColor:'#E8E6EA',
    borderRadius:15,
    paddingTop:15,
    paddingBottom:15,
    paddingLeft:20,
    paddingRight:20
  },
  contSection:{
    fontSize:16,
    fontFamily: 'Abel',
    fontWeight: '400',
    lineHeight: 24,
     marginBottom:15
  },
  filterTopsection:{
    flexDirection:'row',
    justifyContent:'space-between',
    alignItems:'center',
    padding:12

  },
  filterTopsectionLeft:{
    borderBottomWidth:1,
    width:'40%',
    borderColor:'#E8E6EA'
  },
  filterTopsectionRight:{
    borderBottomWidth:1,
    borderColor:'#E8E6EA',
     width:'40%',
  },
  filterTopsectionCenter:{
    fontSize:12,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'rgba(0, 0, 0, 0.7)',
  },
  gallerySection:{
    flexDirection:'row',
    justifyContent:'space-between',
    paddingLeft:10,
    paddingRight:10,
    marginBottom:12
  },
  imgIconsection:{
    flexDirection:'row',
    justifyContent:'space-between',
    backgroundColor:'rgba(0,0,0,0.7)',
    position:'absolute',
    bottom:0,
    width:'100%',
   
    borderBottomLeftRadius:14,
    borderBottomRightRadius:14
  },
  imgIconsectionInner:{
    paddingLeft:25,
    paddingRight:25,
    borderRightWidth:1,
    borderColor:'#fff',
    width:'50%',
    paddingTop:2,
    paddingBottom:2,
     alignItems:'center',
     justifyContent:'center'
  }

});