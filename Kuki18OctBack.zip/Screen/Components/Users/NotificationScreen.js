// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';


import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import MultiSelect from 'react-native-multiple-select';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';
import Loader from '../../Components/Loader'; 
import axios from 'axios';
import Api from '../../Constants/Api.js'; 
import { FontAwesome } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

class NotificationScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      notificationsData:[],
      loading:false
    };

  
  }

  getNotifications = async () => {
    let udata = JSON.parse(await AsyncStorage.getItem('userData'));
    let data = JSON.stringify({
    user_id: udata
    });
     this.setState({loading:true});
    const token = await AsyncStorage.getItem('fcmtoken');
    // console.log(token);
    let headers = {
      headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authentication': `Bearer ${token}`
      }
    }
    axios.post(Api.apiUrl+'/get-notifications', data, headers)
    .then(res => {
    // console.log(res.data);
    this.setState({notificationsData:res.data.data}); 
     this.setState({loading:false});
    })
    .catch(error => {
      if(error.toJSON().message === 'Network Error'){
          alert('no internet connection');
          this.setState({loading:false}); 
        }else{
          alert(error); this.setState({loading:false});
        }
    });
  }

  backScreen(){
    this.props.navigation.goBack();
  }

  deleteNotification(id){

     Alert.alert(
      'Delete Notification',
      'Do you want to delete this notification ? ', // <- this part is optional, you can pass an empty string
      [
        {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
        {text: 'Delete', onPress: () => this.deleteNoti(id,'one')},
      ],
      {cancelable: false},
    );

  }

  async deleteNoti(id,isDel){
    let udata = JSON.parse(await AsyncStorage.getItem('userData'));
    let data = JSON.stringify({
    user_id: udata,
    id:id,
    isDel:isDel
    });
     this.setState({loading:true});
    const token = await AsyncStorage.getItem('fcmtoken');
    // console.log(token);
    let headers = {
      headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authentication': `Bearer ${token}`
      }
    }
    axios.post(Api.apiUrl+'/delete-notifications', data, headers)
    .then(res => {
      alert(res.data.message);
      this.getNotifications();
       this.setState({loading:false});
    })
    .catch(error => {alert(error);  this.setState({loading:false}); });
  }

  clearNotifications(){
     Alert.alert(
      'Delete Notifications',
      'Do you want to delete all the notifications ? ', // <- this part is optional, you can pass an empty string
      [
        {text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
        {text: 'Delete', onPress: () => this.deleteNoti(id,'all')},
      ],
      {cancelable: false},
    );

  }
  nextScreen(){
    this.props.navigation.navigate('UserstatusScreen');
  }

  

  goBack(){
    this.props.navigation.navigate('HomeCookiesScreen');
  }

  componentDidMount(){
    this.getNotifications();
  }

  render (){

    const { notificationsData,loading } = this.state;

    const handleSubmitPress = () => {
    if(!this.state.setChecked){
      this.createAlert('Selected');
      return;
    }
    this.props.navigation.navigate('UserstatusScreen');
    }
    const notficationContent = [];
    if(notificationsData.length > 0){

      for (var i = 0; i < notificationsData.length; i++) {
        let notId = notificationsData[i].id;
         notficationContent.push(<View style={styles.subinnerContent} key={i}>
              <View style={styles.suninnerContent}>
                <Text style={styles.notificationTextStyle}>{notificationsData[i].notification_content}</Text>
                <TouchableOpacity
                  style={styles.buttonStyle}
                  activeOpacity={0.5}
                   onPress={() => {
                  this.deleteNotification(notId);
                }}>
                  <Text style={styles.buttonTextStyle}>X</Text>
                </TouchableOpacity>
              </View>
              <Text style={styles.notificationTimeStyle}>{notificationsData[i].notification_time} ago</Text>
            </View>)
      }
    }else{
      notficationContent.push(<Text key="noti" style={styles.notificationTextStyle}>No Records</Text>)
    }
    
    return <View style={{flex:1,height:'100%'}}><Loader loading={loading} /><View style={styles.mainBody}>
              <View style={styles.backSection}>
                <View style={styles.topheadSectionLeft}>
                  <TouchableOpacity onPress={() =>
            this.goBack()} activeOpacity={0.7}>
            
            <LinearGradient
        // Button Linear Gradient
        colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
        style={styles.backIconsCont}>

                <FontAwesome 
                  name={'angle-left'}
                  size={24} 
                  color={AppStyle.fontColor}
                  
                   
                />
               </LinearGradient>
            
         </TouchableOpacity>
                  <Text style={styles.ContentHeadStyle}>Notifications</Text>
                </View>
                <View style={styles.topheadSection}>
                   <TouchableOpacity onPress={() => this.clearNotifications()}>
                   <Text style={styles.headingText}>Clear All</Text>
                </TouchableOpacity>
                </View>
              </View>
           
            <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollViewsec}><View style={styles.innerContent}>
              {notficationContent}
            </View></ScrollView>
          </View>
          <CookieNavigationScreen navigation={this.props.navigation}/>
          </View>
           
        
      
  }
};
export default NotificationScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex:1,
    backgroundColor: AppStyle.appColor,
    paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
   
    paddingTop: 35,
    height:'100%'
  },
  backIconsCont:{
  borderWidth:1,
  borderColor:'#E8E6EA',
  borderRadius:15,
  paddingTop:12,
  paddingBottom:12,
  paddingLeft:20,
  paddingRight:20
  },
  backSection:{
    flexDirection:'row',
    marginBottom:15,
    alignItems:'center',
    justifyContent:'space-between'
  },
  ContentHeadStyle:{
    color:AppStyle.fontColor,
    fontFamily: 'GlorySemiBold',
    fontSize:27,
    marginLeft:20
  },
  topheadSectionLeft:{
    flexDirection:'row',
    width:'80%',
    alignItems:"center"
  },
  topheadSection:{
    flexDirection:'row',
    width:'20%'
  },
  suninnerContent:{
    flexDirection:'row',
    paddingTop:18,
    
  },
  headingText:{
    color: AppStyle.appIconColor,
    fontSize:16,
    fontFamily: 'Abel',
    marginLeft:5
  },
  subinnerContent:{
    borderBottomWidth:1,
    paddingBottom:10,
    borderColor:'#E8E6EA'
  },
  notificationTextStyle: {
    color: '#000',
    fontSize:16,
    fontFamily: 'Abel',
    marginLeft:5,
    width:'85%'
  },
  notificationTimeStyle: {
    color: '#573353',
    fontSize:14,
    fontFamily: 'Abel',
    marginLeft:5
  },
  buttonTextStyle: {
    color: AppStyle.appIconColor,
    fontSize:16,
    fontSize: AppStyle.buttonFontsize,
    fontFamily: 'Abel',
    marginLeft:10
  },
  scrollViewsec:{
    padding:1
  }
});