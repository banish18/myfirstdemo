// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component,useEffect} from 'react';
import {View, Text, Alert, StyleSheet,Image,SafeAreaView} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import AppStyle from '../Constants/AppStyle.js';
import {
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItem,
} from '@react-navigation/drawer';

const CustomLoggedInSidebarMenu = (props) => {
 

  return (
    <LinearGradient
        // Button Linear Gradient
        colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
        ><View style={stylesSidebar.sideMenuContainer}>
      
      <View style={stylesSidebar.profileHeader}>
        <View style={stylesSidebar.profileHeaderPicCircle}>
          <Image
                    source={require('../../assets/icon.png')}
                     style={[{
                     resizeMode: 'contain',
                      width:30
                     
                    }]}
                    />
        </View>
        <Text style={stylesSidebar.profileHeaderText}>
          Kuki
        </Text>
        </View>
      
      
        <DrawerContentScrollView style={stylesSidebar.pDF} {...props}>
        
        <DrawerItem
          label={({color}) => 
            <View style={stylesSidebar.menuOuterSecc}>
            <Feather 
                  name={'home'}
                  size={25} 
                  color={AppStyle.appIconColor} 
                   
                />
              <Text style={{color:AppStyle.fontColor,width:'100%',fontFamily:'Abel',marginLeft:10,fontSize:17}}>
              Home
            </Text>
            </View>
            
          }
          onPress={() => {
            props.navigation.navigate('HomeCookiesScreen');
           
          }}
        />
        <DrawerItem
          label={({color}) => 
            <View style={stylesSidebar.menuOuterSecc}>
            <Feather 
                  name={'user'}
                  size={25} 
                  color={AppStyle.appIconColor} 
                   
                />
              <Text style={{color:AppStyle.fontColor,width:'100%',fontFamily:'Abel',marginLeft:10,fontSize:17}}>
              Profile
            </Text>
            </View>
          }
          onPress={() => {
            props.navigation.closeDrawer();
            props.navigation.push('EditUserDetailScreen');
           
          }}
        />
        <DrawerItem
          label={({color}) => 
            
            <View style={stylesSidebar.menuOuterSecc}>
             <Feather 
                  name={'settings'}
                  size={25} 
                  color={AppStyle.appIconColor} 
                   
                /> 
              <Text style={{color:AppStyle.fontColor,width:'100%',fontFamily:'Abel',marginLeft:10,fontSize:17}}>
              Setting
            </Text>
            </View>
          }
          onPress={() => {
            props.navigation.navigate('SettingScreen');
           
          }}
        />
        <DrawerItem
          label={({color}) => 
            
            <View style={stylesSidebar.menuOuterSecc}>
             <Feather 
                  name={'dollar-sign'}
                  size={25} 
                  color={AppStyle.appIconColor} 
                   
                /> 
              <Text style={{color:AppStyle.fontColor,width:'100%',fontFamily:'Abel',marginLeft:10,fontSize:17}}>
              Invite & Earn
            </Text>
            </View>
          }
          onPress={() => {
            props.navigation.navigate('InviteEarnScreen');
           
          }}
        />

        {/*} <DrawerItem
          label={({color}) => 
            
            <View style={stylesSidebar.menuOuterSecc}>
             <Feather 
                  name={'database'}
                  size={25} 
                  color={AppStyle.appIconColor} 
                   
                /> 
              <Text style={{color:AppStyle.fontColor,width:'100%',fontFamily:'Abel',marginLeft:10,fontSize:17}}>
              Kuki Jar
            </Text>
            </View>
          }
          onPress={() => {
            props.navigation.navigate('CookieZarScreen');
           
          }}
        />
         <DrawerItem
          label={({color}) => 
            
            <View style={stylesSidebar.menuOuterSecc}>
             <Feather 
                  name={'key'}
                  size={25} 
                  color={AppStyle.appIconColor} 
                   
                /> 
              <Text style={{color:AppStyle.fontColor,width:'100%',fontFamily:'Abel',marginLeft:10,fontSize:17}}>
              Change Password
            </Text>
            </View>
          }
          onPress={() => {
            props.navigation.navigate('UpdatePasswordScreen');
           
          }}
        />*/}
        <DrawerItem
          label={({color}) => 
            <View style={stylesSidebar.menuOuterSecc}>
            <Feather 
                  name={'log-out'}
                  size={25} 
                  color={AppStyle.appIconColor} 
                   
                />
              <Text style={{color:AppStyle.fontColor,width:'100%',fontFamily:'Abel',marginLeft:10,fontSize:17}}>
              Logout
            </Text>
            </View>
          }
          onPress={() => {
            props.navigation.toggleDrawer();
            Alert.alert(
              'Logout',
              'Are you sure? You want to logout?',
              [
                {
                  text: 'Cancel',
                  onPress: () => {
                    return null;
                  },
                },
                {
                  text: 'Confirm',
                  onPress: () => {
                    AsyncStorage.clear();
                   props.navigation.replace('LoginNavigationStack');
              
                  },
                },
              ],
              {cancelable: false},
            );
          }}
        />
      </DrawerContentScrollView>
      
    </View></LinearGradient>
  );
};

export default CustomLoggedInSidebarMenu;

const stylesSidebar = StyleSheet.create({
  menuOuterSecc:{
   flexDirection:'row',
   alignItems:'center'
  },
  sideMenuContainer: {
    width: '100%',
    height: '100%',
    
    paddingTop: 0,
    color: 'white',
    marginTop:30,

  },
pDF:{
  backgroundColor:'#fff'
},
  profileHeader: {
    flexDirection: 'row',
    padding: 15,
    textAlign: 'center',
  },
  profileHeaderPicCircle: {
    width: 60,
    height: 60,
    borderRadius: 60 / 2,
    color: 'white',
    backgroundColor: '#ffffff',
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileHeaderText: {
    color: AppStyle.fontColor,
    alignSelf: 'center',
    paddingHorizontal: 10,
    fontFamily: 'GlorySemiBold',
    fontSize:20
  },
  profileHeaderLine: {
    height: 1,
    marginHorizontal: 20,
    

  },
});