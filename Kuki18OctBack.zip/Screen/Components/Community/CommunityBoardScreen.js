// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';
import {Picker} from '@react-native-picker/picker';

import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  Modal,
  Pressable,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation, NavigationContainer } from '@react-navigation/native';
import axios from 'axios';
import Api from '../../Constants/Api.js';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';
import { useRoute } from '@react-navigation/native';
import Loader from '../../Components/Loader';
import SectionedMultiSelect from 'react-native-sectioned-multi-select';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { Linking } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';

class CommunityBoardScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
     itemsData: [],
     grouppostsData: {},
     userDetail:{},
      userData:{},
      stateData:{},
      cityData:{},
      countryData:{},
    selectedCommunityValue:'',
    selectedStateValue:'',
    selectedCityValue:'' ,
    grpHeading:'Social',
    loading:false,
    selectedItems: [],
    selectedProfestionValue: [],
    cityId:'',
    modalVisible:false,
     SselectedItems: [],
    CselectedItems: [],
    CityitemsData:[],
    StateitemsData:[]
    };



    }
     setModalVisible(){
    this.setState({modalVisible:false});
  }

   onSSelectedItemsChange = (selectedItems,val) => {
this.setState({ SselectedItems:selectedItems });
this.getCityList(selectedItems);
};
onCSelectedItemsChange = (selectedItems,val) => {
this.setState({ CselectedItems:selectedItems });
};

getStateList = async (country_id) => {
    this.state.loading = true;
    let data = JSON.stringify({
    country_id: country_id
    });
    const token = await AsyncStorage.getItem('fcmtoken');
    // console.log(token);
    let headers = {
      headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authentication': `Bearer ${token}`
      }
    }
    axios.post(Api.apiUrl+'/get-states', data, headers)
    .then(res => {
    this.state.loading = false;
    this.setState({StateitemsData:res.data.data}); 
    })
    .catch(error => {
      if(error.toJSON().message === 'Network Error'){
          alert('no internet connection');
          this.setState({loading:false}); 
        }else{
          alert(error); this.setState({loading:false});
        }
    });
  }

  getCityList = async (state_id) => {
    this.state.loading = true;
    let data = JSON.stringify({
    state_id: state_id
    });
    const token = await AsyncStorage.getItem('fcmtoken');
    // console.log(token);
    let headers = {
      headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authentication': `Bearer ${token}`
      }
    }
    axios.post(Api.apiUrl+'/get-cities', data, headers)
    .then(res => {
    this.state.loading = false;
    this.setState({CityitemsData:res.data.data}); 
    })
    .catch(error => {console.log(error);this.state.loading = false;});
  }

     async getUserData(isType = null){
      
    let udata = JSON.parse(await AsyncStorage.getItem('userData'));
    let postState = await AsyncStorage.getItem('postState');
    let postCity = await AsyncStorage.getItem('postCity');
    this.setState({loading:true});
      let data = JSON.stringify({
        user_id: udata.id
      });
      let headers = {
        headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
        }
      }
      axios.post(Api.apiUrl+'/get-user-detail', data, headers)
      .then(res => {
        
        this.setState({loading:false});
        if(res.data.status == 'true'){
          //console.log(res.data.user_detail); 
          this.setState({userDetail:res.data.data.user_detail});
          this.setState({userData:res.data.data.user_detail.user});
          this.setState({countryData:res.data.data.user_detail.country_data});
          this.setState({stateData:res.data.data.user_detail.state_data});
          this.setState({cityData:res.data.data.user_detail.city_data});

          if(postState === null){
            //alert(postState);
            AsyncStorage.setItem('postCity',JSON.stringify(res.data.data.user_detail.city_data));

          }else{
            this.setState({stateData:JSON.parse(postState)});
            this.setState({cityData:JSON.parse(postCity)});
          }
          if(isType != null){
            this.getGroupposts();
          }
        }else{
          console.log(error); this.state.loading = false; 
        }
      }).catch(error => {console.log(error); this.state.loading = false; });
  }
   createAlert = (FirstName) =>
    Alert.alert(
      "Required",
      FirstName,
      [
       
        { text: "OK", onPress: () => console.log("OK Pressed") }
      ]
    );


  setSelectedValue(itmVal,type){
   if(type == 'community'){
      this.setState({selectedCommunityValue: itmVal });
    }else if(type == 'State'){
      this.setState({selectedStateValue: itmVal });
    }else if(type == 'city'){
      this.setState({selectedCityValue: itmVal });
    }
  }

  getPrfessionalList = async () => {
this.setState({loading:true});
    
  const cat_data  =  this.props.route.params.category_id;
      let data = JSON.stringify({
        category_id: cat_data
      });
     
      const token = await AsyncStorage.getItem('fcmtoken');
      let headers = {
          headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              'Authentication': `Bearer ${token}`
          }
      }
      axios.post(Api.apiUrl+'/get-community', data, headers)
      .then(res => {
       this.setState({loading:false});
        this.setState({itemsData:res.data.data}); 
      })
      .catch(error => {console.log(error); this.setState({loading:false});});
    }

    getGroupposts = async (gid = null) => {
      if(gid == null && this.state.selectedProfestionValue != ''){
        gid = this.state.selectedProfestionValue;
      }
     
    this.setState({loading:true});
    const cat_data  =  this.props.route.params.category_id;

    let postCity = JSON.parse(await AsyncStorage.getItem('postCity'));
    console.log(this.state.userDetail);
    let citytID = this.state.userDetail.city;
    
    if(postCity === null){
      
    }else{
      citytID = postCity.id;
    }

    
   
      let data = JSON.stringify({
        group_id: gid,
        city_id:citytID,
        group_category_id:cat_data
      });


     
      const token = await AsyncStorage.getItem('fcmtoken');
      let headers = {
          headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              'Authentication': `Bearer ${token}`
          }
      }
      console.log(data);
      axios.post(Api.apiUrl+'/get-group-posts', data, headers)
      .then(res => {
       this.setState({loading:false});
       console.log(res.data.data.city_data);
        this.setState({grouppostsData:res.data.data}); 
      })
      .catch(error => {alert(error); this.setState({loading:false});});
    }
    onSelectedItemsChange = selectedItems => {
    this.setState({ selectedProfestionValue:selectedItems });
    this.getGroupposts(selectedItems.toString());
  };

    async componentDidMount(){
      
      this.getPrfessionalList();
    
    let postCity = JSON.parse(await AsyncStorage.getItem('postCity'));

    if(postCity === null){
      this.getUserData('1');
    }else{
      this.getUserData();
      this.getGroupposts();
    }
     //console.log(this.state.userDetail);
      
      const cat_data  =  this.props.route.params.category_id;
      if(cat_data == '1'){
        this.setState({grpHeading:'Professional'});
      }

      this.focusListener = this.props.navigation.addListener('focus', () => {
          this.getGroupposts();
        //Put your Data loading function here instead of my this.loadData()
      });

      this.setState({loading:false});
    }

    getpostDetail = (id,uid,fid) => {
     const cat_data  =  this.props.route.params.category_id;
      this.props.navigation.navigate('DiscussionDetailScreen',{
        post_id: id,user_id: uid,category_id: cat_data
      });
    }
    addpostData = (i) => {
      const cat_data  =  this.props.route.params.category_id;
      this.props.navigation.navigate('CommunityPostScreen',{
        isReturnscreen: 'CommunityBoardScreen',category_id:cat_data
      });
    }

    getuserDetail = (i) => {
      //this.props.navigation.push('CookiesDetail',{user_id:i,isReturnscreen: 'CommunityBoardScreen'});
      this.props.navigation.push('CookiesDetail',{user_id:i,isReturnscreen: 'CommunityBoardScreen',isFrom:2});

      
    }
    openpstUrl(url){
    this.setState({loading:true});
    Linking.openURL(url);
    this.setState({loading:false});
  }
  


  render (){

    const {itemsData,grpHeading,loading,grouppostsData,selectedItems,selectedProfestionValue,stateData
    ,cityData,modalVisible,StateitemsData,CityitemsData,userDetail,SselectedItems,CselectedItems } = this.state;

    let pickerItem = [];
   for (var i = 0; i < itemsData.length; i++) {
      pickerItem.push(<Picker.Item  fontFamily="abel" label={itemsData[i].name} value={itemsData[i].id} key={i} />);
    }


     const saveLocation = async () => {
      this.setState({modalVisible:false});

      this.state.loading = true;
      let data = JSON.stringify({
      state_id: SselectedItems,
      city_id: CselectedItems,
      });
      const token = await AsyncStorage.getItem('fcmtoken');
      // console.log(token);
      let headers = {
        headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authentication': `Bearer ${token}`
        }
      }
      axios.post(Api.apiUrl+'/get-locations-name', data, headers)
      .then(res => {
      this.state.loading = false;
      this.setState({cityData:res.data.city_data}); 
      this.setState({stateData:res.data.state_data}); 
      AsyncStorage.setItem('postState',JSON.stringify(res.data.state_data));
      AsyncStorage.setItem('postCity',JSON.stringify(res.data.city_data));
      this.getGroupposts();
      })
      .catch(error => {console.log(error);this.state.loading = false;});
     }

     const openLocation =() =>{
      this.getStateList(userDetail.country);
      this.getCityList(userDetail.city);

      this.setState({modalVisible:true});
     }

      const handleSubmitPress = () => {
    
    if(!this.state.selectedCommunityValue){
      this.createAlert('Please Select Your Community');
      
      return;
    }else if(!this.state.selectedStateValue){
      this.createAlert('Please Select Your State');
      
      return;
    }else if(!this.state.selectedCityValue){
      this.createAlert('Please Select Your City');
      
      return;
    }
this.props.navigation.navigate('CommunityPostScreen');
  };



  const postData = grouppostsData;    
  let receiverContentData = [];
  if(postData.length == 0){
    receiverContentData.push( <Text key="norecords" style={styles.searchContentText}>No Records
</Text>);
  }else{
  
  for(let i =0; i<postData.length;i++){
    let pstUrl = postData[i].post_urls;
    if(pstUrl == null){
      pstUrl = '';
    }
    let userImg = [];
    if(postData[i].user_detail.user_profile_image != null){
userImg.push(<View key={i} style={styles.outerImgSection}><Image
      
                  source={{ uri: `${postData[i].user_detail.user_profile_image}` }} 
                  style={styles.imagetopCont}
                /></View>);
      
    }else{
      userImg.push(<View key={i} style={styles.outerImgSection}><Image
     
                  source={require('../../../assets/images/uphoto.png')}
                  style={styles.imagetopCont}
                /></View>);
    }


    
     let postImg = [];
    if(postData[i].post_image != null){
      postImg.push(<Image
      key={i}
                  source={{ uri: `${postData[i].post_image.file_name}` }} 
                  style={styles.imagepostCont}
                />);
      
    }

  
 

  
    let timeData = postData[i].post_time;

    

    receiverContentData.push(
              <View style={[i == 0 ? styles.textinvalid : styles.mainInnersectiond]}  key={i}>
              
              <View style={styles.mainInnersection} >
                <TouchableOpacity
              
              activeOpacity={0.5}
              onPress={this.getuserDetail.bind(this,postData[i].user_id)} >
              {userImg}
                 </TouchableOpacity>
                <View style={styles.searchMainContentsection} >
                  <View style={styles.searchContentsection}>
                    <Text style={styles.titleContentText}>{postData[i].user_data.first_name} {postData[i].user_data.last_name}, <Feather 
                  name={'star'}
                  size={16} 
                  color={AppStyle.appIconColor}
                   
                /> {postData[i].user_rating} , <Feather 
                  name={'clock'}
                  size={15} 
                  color='rgba(0, 0, 0, 0.4)'
                   
                /> {timeData} ago</Text>
                    <Text style={styles.timContentText}>{postData[i].user_detail.gender} , {postData[i].user_detail.age_group} , {postData[i].city_detail.name}</Text>
                    <Text style={styles.timContentText}>{postData[i].user_community.name}</Text>
                  </View>
                </View> 

                </View>
                <TouchableOpacity
              style={styles.buttonStylve}
              activeOpacity={0.5}
              onPress={this.getpostDetail.bind(this,postData[i].id,postData[i].user_id)} >
                <View style={styles.searchMainContentsectdion} >
                  <View style={styles.searchContentsection}>
                  {/*<Text style={styles.searchContenttitleText}>{postData[i].title}
</Text>*/}
                   <Text style={styles.searchContentText}>{postData[i].description}
</Text>

{pstUrl!= '' && <Text style={styles.cmtCountLink} onPress={() => this.openpstUrl.bind(this,pstUrl)}>{pstUrl}</Text> }
<View style={styles.imgOuterSec}>{postImg}</View>
                  </View>
                </View>
                </TouchableOpacity>
                </View>);
  }
}


    return <View style={{flex:1,height:'100%',backgroundColor:'#fff'}}><Loader loading={loading} /><ScrollView showsVerticalScrollIndicator={false}><View style={styles.mainBody}>
          
             <View style={styles.innermainlayutSection}>
                
                    
                    <Text style={styles.textSubheading}>
                    {stateData.name}, {cityData.name}
                    </Text> 
               
               
                 <TouchableOpacity
              style={styles.addbuttonsStylve}
              activeOpacity={0.5}
              onPress={ openLocation} ><Feather 
                  name={'edit'}
                  size={18} 
                  color={AppStyle.appIconColor}
                   
                /></TouchableOpacity>    
                
              </View>
            <View style={styles.SectionHeadStyle}>
              <Text style={styles.SectionHedText}>{grpHeading} Discussions</Text>
              <TouchableOpacity onPress={this.addpostData.bind(this,i)} activeOpacity={0.7}>
              <LinearGradient
                // Button Linear Gradient
                colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
                style={styles.addbuttonStylve}>
                <Feather 
                  name={'plus'}
                  size={24} 
                  color={AppStyle.fontColor}
                   
                />
                </LinearGradient>
                </TouchableOpacity>
               
               
            </View>

            
            
            <View style={styles.mainStection}>
            

              <View style={styles.selectboxContainer}>
                 <SectionedMultiSelect
            items={itemsData}
            IconRenderer={Icon}
            uniqueKey="id"
            subKey="children"
            selectText="Select Your Group..."
            showDropDowns={true}
            single={true}
            onSelectedItemsChange={this.onSelectedItemsChange}
            selectedItems={this.state.selectedProfestionValue}
            subItemFontFamily={{fontFamily:'Abel'}}
            itemFontFamily={{fontFamily:'Abel'}}
            searchTextFontFamily={{fontFamily:'Abel'}}
            confirmFontFamily={{fontFamily:'Abel'}}
            searchPlaceholderText='Search Professional Group'
            colors={{primary:'background: linear-gradient(90deg, rgba(253, 139, 48, 0.69) 0%, rgba(253, 139, 48, 0.69) 114.92%)'}}
            showCancelButton={true}
            hideConfirm={true}
             styles={{
                
                cancelButton:{
                  backgroundColor:'rgba(253, 139, 48, 0.69)',
                  width:'100%',
                  minWidth:'100%'

                } ,
                selectToggleText: {
                 fontFamily:'Abel'
                 },
                 itemText: {
                 fontSize:16,
                 marginLeft:15
                 },
                item: {
                 marginTop:10,
                 textAlign:'center',
                 marginBottom:10,
                },
                selectToggle:{
                  marginTop:15
                },
                container:{
                  flex:0,
                  top:'10%',
                  width:'auto',
                  height:450,
                  paddingTop:10,
                  overflow:'scroll',                   
                  paddingBottom:0,                     
                } 
              }}
            
          />
                <Text style={styles.SectionLabel}>Select Discussion Groups</Text>
              </View>
              <View style={styles.postListSection}>
                <Text style={styles.SectionOntgText}>Latest Disuccsions
                </Text>
              </View>
            </View>
              <View>
        {receiverContentData}

        <Modal
          animationType="slide"
          transparent={false}
          visible={modalVisible}
           
          onRequestClose={() => {
            //Alert.alert("Modal has been closed.");
            this.setModalVisible(!modalVisible);
          }}
        >
                 <View style={styles.changecitySection}>
                 <Text style={styles.changeHeadtext}>Change Location</Text>
                    <View style={styles.selectboxNwContainer}>
                         <SectionedMultiSelect
                        items={StateitemsData}
                        IconRenderer={Icon}
                        uniqueKey="id"
                        subKey="children"
                        selectText="Your State..."
                        showDropDowns={true}
                        single={true}
                        onSelectedItemsChange={this.onSSelectedItemsChange}
                        selectedItems={this.state.SselectedItems}
                        subItemFontFamily={{fontFamily:'Abel'}}
                        itemFontFamily={{fontFamily:'Abel'}}
                        searchTextFontFamily={{fontFamily:'Abel'}}
                        confirmFontFamily={{fontFamily:'Abel'}}
                        searchPlaceholderText='Search State'
                        colors={{primary:'background: linear-gradient(90deg, rgba(253, 139, 48, 0.69) 0%, rgba(253, 139, 48, 0.69) 114.92%)'}}
                        showCancelButton={true}
                        hideConfirm={true}
                        styles={{
                            
                            selectToggleText: {
                             fontFamily:'Abel'
                             },
                             itemText: {
                             fontSize:20,
                             marginLeft:15
                             },
                            item: {
                             marginTop:25,
                             textAlign:'center'
                            },
                            selectToggle:{
                              marginTop:15
                            },
			                cancelButton:{
			                  backgroundColor:'rgba(253, 139, 48, 0.69)',
			                  width:'100%',
			                  minWidth:'100%',
			                  marginTop:-35
			                } 
                          }}
                      />
                        <Text style={styles.SectionVSmallLabel}>State</Text>
                     </View>
                     <View style={styles.selectboxNwContainer}>
                         <SectionedMultiSelect
                        items={CityitemsData}
                        IconRenderer={Icon}
                        uniqueKey="id"
                        subKey="children"
                        selectText="Your City..."
                        showDropDowns={true}
                        single={true}
                        onSelectedItemsChange={this.onCSelectedItemsChange}
                        selectedItems={this.state.CselectedItems}
                        subItemFontFamily={{fontFamily:'Abel'}}
                        itemFontFamily={{fontFamily:'Abel'}}
                        searchTextFontFamily={{fontFamily:'Abel'}}
                        confirmFontFamily={{fontFamily:'Abel'}}
                        searchPlaceholderText='Search City'
                        colors={{primary:'background: linear-gradient(90deg, rgba(253, 139, 48, 0.69) 0%, rgba(253, 139, 48, 0.69) 114.92%)'}}
                        hideConfirm={true}
                       showCancelButton={true}
                         styles={{
                            
                            selectToggleText: {
                             fontFamily:'Abel'
                             },
                             itemText: {
                             fontSize:20,
                             marginLeft:15
                             },
                            item: {
                             marginTop:25,
                             textAlign:'center'
                            },
                            selectToggle:{
                              marginTop:15
                            },
			                cancelButton:{
			                  backgroundColor:'rgba(253, 139, 48, 0.69)',
			                  width:'100%',
			                  minWidth:'100%',
			                  marginTop:-35
			                } 
                          }}
                        
                      />
                        <Text style={styles.SectionVSmallLabel}>City</Text>

                     </View>

                     <View style={styles.urlbtnSection}>
                  <TouchableOpacity
                onPress={() => {
                  this.setModalVisible();
                }}
                activeOpacity={0.8}
                style={styles.wrapperdOuterCustom}>
                <View
        
        style={styles.wrapperdDCustom}>
            <Text style={styles.urlcloseButton}>Close</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity
                onPress={saveLocation}
                activeOpacity={0.8}
                style={styles.wrapperdOuterCustom}>
            <LinearGradient
        // Button Linear Gradient
        colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
        style={styles.wrapperdCustom}>
              <Text style={styles.urladdButton}>Save</Text>
              </LinearGradient>
          
          </TouchableOpacity>
                  </View>

                    

                     
            
                  </View>

                  </Modal>

        </View>
        </View>

</ScrollView>
          <CookieNavigationScreen navigation={this.props.navigation}/>
          </View>
      
  }
};
export default CommunityBoardScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex: 1,
    backgroundColor: AppStyle.appColor,
    alignContent: 'center',
     paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
     paddingBottom: AppStyle.appInnerBottomPadding,
     paddingTop: AppStyle.appInnerTopPadding,
     backgroundColor:'#fff',
     height:'100%'
  },postListSection:{
    marginBottom:10
  },
  SectionHeadStyle: {
    flexDirection: 'row',
    paddingBottom: 6,
    justifyContent:'space-between',
    alignItems:'center',
    marginTop:-12
  },
  inputboxContainer:{
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
    borderColor:'#E8E6EA',
    borderWidth:1,
    borderRadius:16,
    height:58,
  },
  selectboxContainer:{
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
    fontFamily: 'Abel',
    borderWidth:1,
    borderColor:'#E8E6EA',
    borderRadius:16,
    height:58,
    marginBottom:22,
    marginTop:10,   
  },
  SectionLabel:{
    position: 'absolute', top: -10, left: 20, right: 0, bottom: 0,
    backgroundColor:'#fff',
    paddingLeft:10,
    paddingRight:10,
    width:180,
    height:25,
    textAlign:'center',
    fontFamily: 'Abel',
    color:'rgba(0, 0, 0, 0.4)',
    fontSize:16
  },
  SectionSmallLabel:{
    position: 'absolute', top: -10, left: 20, right: 0, bottom: 0,
    backgroundColor:'#fff',
    alignSelf: 'flex-start',
    paddingLeft:10,
    paddingRight:10,
    width:70,
    height:25,
    textAlign:'center',
    color:'rgba(0, 0, 0, 0.4)',
    fontFamily: 'Abel'
  },
  SectionVSmallLabel:{
    position: 'absolute', top: -10, left: 20, right: 0, bottom: 0,
    backgroundColor:'#fff',
    alignSelf: 'flex-start',
    paddingLeft:10,
    paddingRight:10,
    width:65,
    height:25,
    textAlign:'center',
    fontFamily: 'Abel',
    color:'rgba(0, 0, 0, 0.4)',
    fontSize:18
  },
  SectionHedText:{
    fontSize:27,
    fontFamily: 'GlorySemiBold',
    color:AppStyle.fontColor,
  },
  SectionOntgText:{
    fontSize: 20,
    position:'relative',
    zIndex: 1, // works on io,
    fontFamily: 'GlorySemiBold',
    marginBottom: 14,
    lineHeight:26,
    color:AppStyle.fontColor,
  },
  buttonStyle: AppStyle.AppbuttonStyle,
  buttoncloseStyle:{
  	width:'40%',
  	backgroundColor:"red"
  },
  buttonOuterStyle:{
    width:'40%'
  },
  outerButtonSection:{
  	flexDirection:'row',
  	justifyContent:'space-between'
  },
  buttonTextStyle: {
    color: AppStyle.fontButtonColor,
    fontSize:18,
    fontSize: AppStyle.buttonFontsize,
    fontFamily: 'GlorySemiBold',
    textTransform:'uppercase'
  },
  inputStyle: {
    height:58,
    color: AppStyle.inputBlackcolorText,
    fontSize: 16,
    position:'relative',
    zIndex: 1, // works on io,
    fontFamily: 'Abel'

  },
  selectStyle: {
     height:58,
     width:158,
    color: AppStyle.inputBlackcolorText,
    fontWeight: 'bold',
    fontSize: 14,
    width:'100%',
    fontFamily: 'Abel'
  },

  errorTextStyle: {
    color: 'red',
    textAlign: 'center',
    fontSize: 14,
  },
  innermainlayutSection:{
    flexDirection:'row',
    width:'100%',
    justifyContent: 'flex-start',
    
    alignItems:'center'
  },
  locContetsec:{
    marginTop:10
  },
  textHeading:{
    color:AppStyle.fontColor,
    fontSize: 25,
    fontFamily: 'GlorySemiBold',
    marginBottom:10,
  },
  textSubheading:{
     fontFamily: 'Abel',
    color:'rgba(0, 0, 0, 0.4)',
    fontSize:16
  },
  topLocsec:{
    flexDirection:'row',
    justifyContent:'space-between',
    marginTop: 10,
  },
  addpostIcon:{
    flexDirection:'row',
    marginTop: 10,
    backgroundColor:'#F9F1EB',
    padding:10,
    borderRadius:50,
    width:'100%',
    alignItems:'center',
    justifyContent:'center',
    height:50

  },
  locationIcon:{
    flexDirection:'row',
    marginTop: 10,
    backgroundColor:'#F9F1EB',
    padding:10,
    borderRadius:50,
    width:'48%',
    alignItems:'center',
    justifyContent:'center',
    height:50

  },
  locaitonDirectionText:{
    color:AppStyle.fontColor,
    fontSize: 14,
    fontFamily: 'Abel',
    marginLeft:5

  },mainInnersectiond:{
    paddingTop:10,
    paddingBottom:10,
    borderTopWidth:0.6,
    borderColor:AppStyle.gradientColorTwo,
  },
  mainInnersection: {
    flexDirection:'row',
    flex:1,
    alignItems:'center',
    justifyContent: 'space-between',
   
    
  },
  searchMainContentsection:{
    flexDirection:'row',
    flex:1,
    alignItems:'center',
    justifyContent: 'space-between',
    paddingBottom:5,
  },
  searchContentsection:{
    padding:4,
  },
  titleContentText:{
    fontSize:16,
    fontFamily:'GlorySemiBold',
    color:AppStyle.fontColor
  },
  searchContenttitleText:{
    fontSize:16,
    fontFamily:'GlorySemiBold',
    fontWeight:'400',
    textTransform:'capitalize',
    lineHeight:22,
    color:AppStyle.fontColor,
  },
  searchContentText:{
    fontSize:15,
   
    fontFamily:'Abel',
    textTransform:'capitalize',
    lineHeight:24,
  },
  timContentText:{
     color: '#AAA6B9',
    fontSize:14,
    fontWeight:'400',
    fontFamily: 'Abel'
  },
  ratingMainSection:{
    flexDirection:'row'
  },
  ratingSection:{
    flexDirection:'row',
    alignItems:'center'
  },
  outerImgSection:{
   
    flexDirection:'row',
    width:64,
    height:65,
    borderRadius:120,
    borderWidth:2,
    borderColor:AppStyle.appIconColor,
    padding:3,
    marginRight:10,
    marginBottom:5,
    textAlign:'center',
  
  },
  imagetopCont:{
    width:54,
    height:54,
    borderRadius:108,
    marginTop: 0.8,
  },
   imagepostCont:{
    
    height:150,
    width:'100%',
    borderWidth:1,
    borderColor:AppStyle.appIconColor,
    borderRadius:10,
  },
  imgOuterSec:{
   
    marginBottom:10,
    marginTop:5,
   
  },
  changecitySection:{
    paddingLeft:20,
    paddingRight:20,
    justifyContent:'center',
    flex: 1,
    alignItems:'center'
  },
  selectboxNwContainer:{
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
    fontFamily: 'Abel',
    borderWidth:1,
    borderColor:'#E8E6EA',
    borderRadius:16,
    height:60,
    marginBottom:22,
    width:'100%'
  },
  changeHeadtext:{
    fontSize:26,
    fontFamily:'GlorySemiBold',
    color:AppStyle.fontColor,
    marginBottom:25
  },
  addbuttonStylve:{
  	borderWidth:1,
    borderRadius:15,
    padding:12,
    borderColor:AppStyle.gradientColorOne,
    backgroundColor:AppStyle.gradientColorOne
  },
  addbuttonsStylve:{
    marginLeft:5,
    padding:8,
    
  },
  cmtCountLink:{
    color: 'blue',
    fontSize:14,
    fontWeight:'400',
    fontFamily: 'Abel'
  },
  urlbtnSection:{
    flexDirection:'row',
    marginTop:15
  },
  urlcloseButton:{
    color:AppStyle.fontColor,
    fontSize:16,
    fontWeight:'400',
    fontFamily: 'GlorySemiBold',
    padding:15
  },
  urladdButton:{
    color: AppStyle.fontButtonColor,
    fontSize:16,
    fontWeight:'400',
    fontFamily: 'GlorySemiBold',
    padding:15
  },
  wrapperdOuterCustom:{
  	width:'48%',
  	padding:10,
  },
  wrapperdCustom:{
   	
    width:'100%',
    alignItems:'center',
    justifyContent:'center',
  	borderRadius:10,
  	borderWidth:0
  },
  wrapperdDCustom:{
    backgroundColor:AppStyle.btnbackgroundColor,
    width:'100%',
    alignItems:'center',
    justifyContent:'center',
    borderRadius:10,
    borderWidth:0
  }
});