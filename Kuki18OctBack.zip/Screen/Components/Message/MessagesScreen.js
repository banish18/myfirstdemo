// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';


import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Loader from '../../Components/Loader';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';
import axios from 'axios';
import Api from '../../Constants/Api.js';
import { Feather } from '@expo/vector-icons';


class MessagesScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      loading:false,
      messagesList:[],
      userDetail:[],
      loggediuser:''
    };
    AsyncStorage.setItem('activeClass', 'MactiveClass');
  }

 createAlert = (FirstName) =>
  Alert.alert(
    "Required",
    FirstName,
    [
      { text: "OK", onPress: () => console.log("OK Pressed") }
    ]
  );
  backScreen(){
    this.props.navigation.navigate('UserstatusScreen');
  }
  getChat(id){
    this.props.navigation.push('SingleChatScreen', {
            from_user_id: id
          });
  }

  async getMessages(val){
    let udata = JSON.parse(await AsyncStorage.getItem('userData'));
    if(val == 0){
    	this.setState({loading:true});
    }
    //alert(val);
      let data = JSON.stringify({
        user_id: udata.id
      });
      let headers = {
        headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
        }
      }
      axios.post(Api.apiUrl+'/get-chat-list', data, headers)
      .then(res => {
        
        this.setState({loading:false});
        if(res.data.status == 'true'){
          console.log(res.data.data);
          ////////debugger;
            this.setState({messagesList:res.data.data});          
         
        }else{
         this.setState({loading:false}); 
        }
      }).catch(error => {
        if(error.toJSON().message === 'Network Error'){
          alert('no internet connection');
          this.setState({loading:false}); 
        }else{
          alert(error); this.setState({loading:false});
        }
      });
  }
  async componentDidMount(){
    this.getMessages(0);
    let udata = JSON.parse(await AsyncStorage.getItem('userData'));
    this.setState({loggediuser:udata.id});
    let intId = setInterval(async() => await this.getMessages(1), 5000)
    this.props.navigation.addListener('blur', () => {
        clearInterval(intId);
    });

    this.focusListener = this.props.navigation.addListener('focus', () => {
       this.getMessages(0);
    });
  }

  

  render (){

    const { loading,messagesList,userDetail,loggediuser } = this.state;
    const userListArr = [];
    if(messagesList.length > 0 ){
    for (var i = 0; i < messagesList.length; i++) {
      let imgaeData = messagesList[i].user_profile_image;
      let message_content = '';
      let message_time = '';
      let msgContent = messagesList[i].messageData;
      console.log(msgContent.message_content);
      if(msgContent.message_content != undefined && msgContent.is_deleted != loggediuser){
      	message_content = messagesList[i].messageData.message_content;
      	message_time = messagesList[i].messageData.message_time;
      }
       

      userListArr.push(
        <TouchableOpacity
        key={i}
              style={styles.MessageList}
              activeOpacity={0.5}
              onPress={this.getChat.bind(this,messagesList[i].userId)} >
                <View style={styles.messageImgSec}>
                  {imgaeData != null && <Image source={{ uri: imgaeData }}  style={styles.imagetopCont} />}
                  {imgaeData == null && <Image

                  source={require('../../../assets/images/uphoto.png')}
                  style={styles.imagetopCont}
                />}
                </View>

                <View style={styles.innerMainMessagesSec}>
                  <View style={styles.innerMessagesSec}>
                    
                     <Text style={styles.titleContentText}>{messagesList[i].first_name} {messagesList[i].last_name}, <Feather 
                  name={'star'}
                  size={16} 
                  color={AppStyle.appIconColor}
                   
                /> {messagesList[i].user_rating} , <Feather 
                  name={'clock'}
                  size={15} 
                  color='rgba(0, 0, 0, 0.4)'
                   
                /> {message_time}</Text>
                    <Text style={styles.timContentText}>{messagesList[i].user_detail.gender} , {messagesList[i].user_detail.age_group} , {messagesList[i].city_detail.name}</Text>
                    <Text style={styles.timContentText}>{messagesList[i].user_community.name}</Text>


                    <Text style={styles.innerMessageext}>{message_content.substr(0, 40)}....</Text>
                  </View>
                  <View style={styles.messageCountSec}><Text style={styles.messageCountText}>{messagesList[i].count_messages_count}</Text>
                  </View>
                </View>
                
                
                
                </TouchableOpacity>);
    }
}else{
  userListArr.push(<Text key="no_records" style={styles.emptyContentText}>No message found</Text>);
}

    return <View style={{ flex: 1 }}><Loader loading={loading} /><View style={styles.mainBody}>
            <View style={styles.topheadSection}>
              <Text style={styles.SectionHeadStyle}>Messages</Text>
              </View>
               {userListArr}
          </View>
          <CookieNavigationScreen navigation={this.props.navigation}/>
          </View>
           
        
      
  }
};
export default MessagesScreen;

const styles = StyleSheet.create({
  mainBody: {
   flex:1,
    
    backgroundColor: AppStyle.appColor,
     paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
      paddingBottom: AppStyle.appInnerBottomPadding,
     paddingTop: AppStyle.appInnerTopPadding,
     height:'100%'
  
  },
  titleContentText:{
    fontSize:16,
    fontFamily:'GlorySemiBold',
    color:AppStyle.fontColor
  },
  topheadSection:{
    display:'flex',
    justifyContent:'space-between',
    alignItems:'center',
    flexDirection:'row',
    marginBottom:15
  },
  MessageList:{
    flexDirection:'row',
    alignItems:'center', 
    marginBottom:20, 
  },
  SectionHeadStyle: {
    fontSize:27,
    fontFamily: 'GlorySemiBold',
    marginBottom:15,
    color:AppStyle.fontColor

  },
  timContentText:{
     color: '#AAA6B9',
    fontSize:14,
    fontWeight:'400',
    fontFamily: 'Abel'
  },
  emptyContentText:{
     color: '#AAA6B9',
    fontSize:18,
    fontWeight:'400',
    fontFamily: 'Abel'
  },
  innerContentTitile:{
     color: '#000000',
    fontSize:14,
    fontWeight:'700',
    fontFamily: 'Abel'
  },
  innerHeadMessageext:{
    color:AppStyle.fontColor,
    fontSize:16,
    fontWeight:'400',
    fontFamily: 'GlorySemiBold'
  },
  innerMessageext:{
     color: '#AAA6B9',
    fontSize:14,
    fontWeight:'400',
    fontFamily: 'Abel',
    marginTop:10
  },
  messageCountSec:{
    alignItems:'center',
    marginTop:30
  },
  innerMainMessagesSec:{
    flexDirection:'row',
    justifyContent:'space-between',
    width:'75%',
    borderBottomWidth:1,
    borderColor:AppStyle.appIconColor,
    paddingBottom: 15,
  },
  innerMessagesSec:{
   
    marginTop:5,
  },
  messageCountText:{
    backgroundColor: AppStyle.appIconColor,
    fontSize:14,
    fontWeight:'400',
    fontFamily: 'Abel',
    textAlign:'center',
    borderRadius:100,
    height:28,
    width:28,
    lineHeight: 28,
    color:AppStyle.fontColor,
  },
  messageImgSec:{
    flexDirection:'row',
     width:'20%',
     height:65,
         borderRadius:120,
     borderWidth:2,
    borderColor:AppStyle.appIconColor,
    padding:3,
    marginRight:10,
        textAlign:'center',
  },
  imagetopCont:{
    width:54,
    height:54,
    borderRadius:108,
    marginTop: 1,
  }
});