// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component,useCallback} from 'react';
import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  Pressable,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import axios from 'axios';
import Api from '../../Constants/Api.js';
import Loader from '../Loader';
import { LinearGradient } from 'expo-linear-gradient';
import { FontAwesome } from '@expo/vector-icons';
import { Feather } from '@expo/vector-icons';

class SearchResultScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      loading:false,
      searchData:[]
    };
  }

 createAlert = (FirstName) =>
  Alert.alert(
    "Required",
    FirstName,
    [
     
      { text: "OK", onPress: () => console.log("OK Pressed") }
    ]
  );


  getuserDetail = (i,isSend) => {

    this.props.navigation.push('CookiesDetail',{user_id:i,isFrom:1,isSend:isSend});
  }

   sendCookie = async (val,isSe,i,isNewcookieStat) => {
    if(isSe == 0){
      alert('You had already sent kuki to this user. Please wait for receiver end to open your kuki or wait for 24 hours');
      return;
    }
    let udata = JSON.parse(await AsyncStorage.getItem('userData'));
    this.setState({loading:true});
      let data = JSON.stringify({
        from_user_id: udata.id,
        to_user_id: val
      });
      let headers = {
        headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
        }
      }
      //this.setState({loading:false});
      //return;
      axios.post(Api.apiUrl+'/send-cookie', data, headers)
      .then(res => {
        this.setState({loading:false});
        if(res.data.status == 'true'){
          alert(res.data.message);
          let search_data = this.state.searchData;
          if(isNewcookieStat == 1){
             search_data[i].isCookieStat = 0;
          }
         
          this.setState({searchData:search_data});
          //this.props.navigation.push('SentCookiesScreen');
        }else{
          alert(res.data.message);
        }
      }).catch(error => {
      if(error.toJSON().message === 'Network Error'){
          alert('no internet connection');
          this.setState({loading:false}); 
        }else{
          alert(error); this.setState({loading:false});
        }
         });
  }

  backScreen(){
    this.props.navigation.goBack();
  }
  
  swithScreen(val){
    alert(val);
    this.props.navigation.navigate(val);
  }

  componentDidMount(){
     let sData = this.props.route.params.searchRecords;
    let searchD_data = JSON.parse(sData);
    this.setState({searchData:searchD_data});
    console.log(searchD_data);
  }
  render (){

    const { checked,loading} = this.state;
  const {navigation} = this.props;
  
 
  let search_data = this.state.searchData;

 
    let searchContentData = [];
    if(search_data.length > 0){

    
  for(let i =0; i<search_data.length;i++){

    let userImg = [];
    if(search_data[i].user_profile_image != null){

      userImg.push(<View style={styles.outerImgSection} key={search_data[i].id+'_img'}><Image
      
                  source={{ uri: `${search_data[i].user_profile_image}` }} 
                  style={styles.imagetopCont}
                /></View>);
    }else{
      userImg.push(<View style={styles.outerImgSection} key={'1_imgg'}><Image
      
                  source={require('../../../assets/images/uphoto.png')}
                  style={styles.imagetopCont}
                /></View>);
    }


   let  userRating = search_data[i].rating;
   let uRate = Math.round((parseFloat(userRating) + Number.EPSILON) * 100) / 100;
 
uRate = uRate.toFixed(2)
   if(userRating == null){
    uRate = '0.0';
   }


    let ratingData = [];
    console.log(userRating);
    for (var l = 0; l < userRating; l++) {
      
        ratingData.push(<Image
            key={l}
                            source={require('../../../assets/images/icons/star.png')}
                            style={{
                              width: 18,
                              resizeMode: 'contain'
                            }}
                          />);
      
    }
    let ratingNoData = [];
    for (var k = 0; k < 5-userRating; k++) {
     
        ratingNoData.push(<Image
            key={k}
                            source={require('../../../assets/images/icons/starn.png')}
                            style={{
                              width: 18,
                              resizeMode: 'contain'
                            }}
                          />);
      
    }
    let ckImg = [];
    if(search_data[i].isCookieStat == '1'){
      ckImg.push(<TouchableOpacity
                  onPress={this.sendCookie.bind(this,search_data[i].user_id,1,i,search_data[i].isNewcookieStat)} 
                
                style={styles.innerSection}><Image
                  source={require('../../../assets/images/icons/yellowcookie.png')}
                  style={{
                    width: 25,
                    height: 25,
                    resizeMode: 'contain'
                  }}
                />
              </TouchableOpacity>);
    }else{
      ckImg.push(<TouchableOpacity
                  onPress={this.sendCookie.bind(this,search_data[i].user_id,0,i)} 
                
                style={styles.innerSection}><Image
                  source={require('../../../assets/images/icons/graycookie.png')}
                  style={{
                    width: 25,
                    height: 25,
                    resizeMode: 'contain'
                  }}
                />
              </TouchableOpacity>);
    }
    searchContentData.push(
              <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity={0.6}
              style={styles.mainInnersection} key={i}
              onPress={this.getuserDetail.bind(this,search_data[i].user_id,1)} >{userImg}
                <View style={styles.searchMainContentsection} >
                  <View style={styles.searchContentsection}>


                    <Text style={styles.searchContentTextBold}>{search_data[i].first_name} {search_data[i].last_name}, <Feather 
                  name={'star'}
                  size={16} 
                  color={AppStyle.appIconColor}
                   
                /> {uRate}</Text>
                    <Text style={styles.searchContentText}>{search_data[i].gender}, {search_data[i].age_group}, {search_data[i].city_data.name}</Text>
                    <Text style={styles.searchContentText}>{search_data[i].community_data.name}</Text>



                  
                  </View>
                  {ckImg}
               
                 
                </View></TouchableOpacity>);

  }
}else{
  searchContentData.push(<Text style={styles.SectionNoRecordStyle} key='5'>No search records found!</Text>);
}
    return <View style={{ flex: 1 }}><Loader loading={loading} /><ScrollView style={{ backgroundColor: '#fff' }}>
            <View style={styles.mainBody}>
              <View style={styles.topheadSection}>
                <TouchableOpacity onPress={() =>
            this.backScreen()} activeOpacity={0.7}>
            
            <LinearGradient
        // Button Linear Gradient
        colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
        style={styles.backIconsCont}>

                <FontAwesome 
                  name={'angle-left'}
                  size={24} 
                  color={AppStyle.fontColor}
                  
                   
                />
               </LinearGradient>
            
         </TouchableOpacity>
                
                <Text style={styles.SectionHeadStyle}>Serach Results</Text>
              </View>
              {searchContentData}
              
            </View>
          </ScrollView>
         <CookieNavigationScreen navigation={this.props.navigation}/>
            </View>
  }
};
export default SearchResultScreen;

const styles = StyleSheet.create({
  mainBody: {
   flex:1,
    backgroundColor: AppStyle.appColor,
    paddingLeft: 15,
    paddingRight: 15,
     paddingBottom: AppStyle.appInnerBottomPadding,
     paddingTop: AppStyle.appInnerTopPadding,
  },
  topheadSection:{
    display:'flex',
    justifyContent:'flex-start',
    alignItems:'center',
    flexDirection:'row',
    marginBottom:25
  },
  backIconsCont:{
  borderWidth:1,
  borderColor:'#E8E6EA',
  borderRadius:15,
  paddingTop:12,
  paddingBottom:12,
  paddingLeft:20,
  paddingRight:20
  },
  SectionHeadStyle: {
    fontSize:27,
    fontFamily: 'GlorySemiBold',
    fontWeight:'400',
    color:AppStyle.fontColor,
    marginLeft:20
  },
  cookeSecright:{
    flexDirection:'row'
  },
  cookieCount:{
    fontSize:12,
    fontFamily: 'Abel',
    fontWeight:'400',
    color:'rgba(253, 139, 48, 0.69)',
    marginTop:-8,
    marginLeft:3
  },
  cookiegCount:{
    fontSize:12,
    fontFamily: 'Abel',
    fontWeight:'400',
    color:'#808080',
    marginTop:-8,
    marginLeft:3
  },
  SectionsubHeadStyle:{
    fontSize:16,
    fontFamily: 'Abel',
    fontWeight:'400',
    color:'rgba(253, 139, 48, 0.69)',
    marginTop:5
  },
  mainInnersection: {
    flexDirection:'row',
    flex:1,
    alignItems:'center',
    justifyContent: 'space-between',
    marginBottom:10
  },
  searchMainContentsection:{
    flexDirection:'row',
    flex:1,
    alignItems:'center',
    justifyContent: 'space-between',
    borderColor:'#E8E6EA',
    borderBottomWidth:1,
    paddingBottom:10,
  },
  searchContentsection:{
    paddingLeft:0,
    width:'80%'
  },
  searchContentTextBold:{
    fontSize:16,
    fontFamily:'GlorySemiBold',
    color:AppStyle.fontColor
  },
  searchContentText:{
     color: '#AAA6B9',
    fontSize:14,
    fontWeight:'400',
    fontFamily: 'Abel'
  },
  SectionNoRecordStyle:{
    fontSize:13,
    lineHeight:22,
    fontFamily:'Abel'
  },
  ratingMainSection:{
    flexDirection:'row'
  },
  ratingSection:{
    flexDirection:'row',
    alignItems:'center'
  },
  imagetopCont:{
    width:54,
    height:54,
    borderRadius:108,
    marginTop: 0.8,
  },outerImgSection:{
   
    flexDirection:'row',
    width:64,
    height:65,
    borderRadius:120,
    borderWidth:2,
    borderColor:AppStyle.appIconColor,
    padding:3,
    marginRight:10,
    textAlign:'center',
  
  }
});