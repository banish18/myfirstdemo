// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/
// Import React and Component
import React, {useState, createRef,useEffect} from 'react';
import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  Image,
  Keyboard,
  TouchableOpacity,
  KeyboardAvoidingView
} from 'react-native';

import { LinearGradient } from 'expo-linear-gradient';
import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CountryPicker from "react-native-country-codes-picker";
import CommanClass from '../Common/CommanClass';
import Loader from '../Loader';
import * as Notifications from 'expo-notifications';
//import saveTokenData from '../shared/APIKit';
import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import 'react-native-get-random-values';
import { v4 as uuidv4 } from 'uuid';
import Api from '../../Constants/Api.js';
import AlertMessages from '../../Constants/AlertMessages.js';
import UseAlertModal from '../Common/UseAlertModal';

async function GetFCMToken(){

  let fcmtoken = await AsyncStorage.getItem('fcmtoken');
   
  if(fcmtoken === null){
   try{
     
      const fcmtoken = (await Notifications.getDevicePushTokenAsync()).data;

      if(fcmtoken){
       
        console.log(fcmtoken);
        AsyncStorage.setItem('fcmtoken',fcmtoken);
      }else{

      }
    } catch (error){
      console.log(error,'error in fcm token');
    }
  
  }else{
    console.log(fcmtoken);
  }

}



const LoginScreen = ({navigation}) => {
  const [userPhone, setUserPhone] = useState('');
  const [userPassword, setUserPassword] = useState('');
  const [errMsg,SetErr] = useState('ErrorMsg');
  const [loading, setLoading] = useState(false);
  const [errortext, setErrortext] = useState('');
  const [show, setShow] = useState(false);
  const [ishowMOdal,ishowMOdalFuc] = useState(false);
  const [countryCode, setCountryCode] = useState('+91');
  const passwordInputRef = createRef();
   const [fontsLoaded] = useState('false');


  
 const loginUser = async () =>{
    navigation.navigate('UserLoginScreen');
  }


  const handleSubmitPress = async () => {
    setErrortext('');
    if (!userPhone) {

      SetErr(AlertMessages.phoneNumberErr);
      ishowMOdalFuc(true);
      return;
    }
    
    const fcmtoken = (await Notifications.getDevicePushTokenAsync()).data;
    AsyncStorage.setItem('fcmtoken',fcmtoken);

    console.log(fcmtoken);

   setLoading(true);
    let data = JSON.stringify({
    phone_number: userPhone
    });
    let headers = {
      headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
      }
    }
    axios.post(Api.apiUrl+'/check-phonenumber', data, headers)
    .then(res => {
      setLoading(false);
       if(res.data.is_registered == 1){
          
          alert(res.data.message);
          navigation.replace('LoginNavigationStack');
       }else{
          
          let userData = {
              device_token:fcmtoken,
              phone_number:userPhone,
              country_code:countryCode
          }
          AsyncStorage.setItem('userSignupData',JSON.stringify(userData));
          setLoading(false);
          navigation.navigate('Otpscreen');
       }
    })
    .catch(error => {
    	if(error.toJSON().message === 'Network Error'){
	        alert('no internet connection');
	        setLoading(false); 
	    }
    	console.log(error); setLoading(false); 
    });
  };

 const handleCallback = (childData) =>{
     
      ishowMOdalFuc(childData);
  }


  return (
    <View style={styles.container}><ScrollView style={{backgroundColor:'#fff'}} contentContainerStyle={{
          flexGrow: 1,
          justifyContent: 'center'
        }}>
<KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : ""}
          style={styles.container}>
        <View style={styles.mainBody}>
      <Loader loading={loading} />
      {ishowMOdal && <UseAlertModal message={errMsg} parentCallback = {handleCallback} /> }
        
          
            <View style={{alignItems: 'center',justifyContent: 'center'}}>

              <Image
                source={require('../../../assets/images/logo/logo-svg.png')}
                style={{
                  maxWidth: 270,
                  
                  resizeMode: 'contain',
                  marginBottom: 20,
                }}
              />
            </View>
            <View style={styles.SectionStyle}>
              <Text style={styles.SectionHedText}>My Mobile</Text>
            
            </View>
            <View style={styles.SectionStyleContent}>
             
            <Text style={styles.SectionContText}>Please enter your valid phone number. We will send you a 4-digit code to verify your account. </Text>  
            </View>
            <View style={styles.mainStection}>
            <View style={styles.Nubcontainer}>
            <TouchableOpacity
                           onPress={() => setShow(true)}
                          style={styles.CountryBox}
                        >
                          <Text style={styles.CountryText}>
                              ({countryCode})
                          </Text>
                        </TouchableOpacity>
                        <CountryPicker
                          show={show}
                          style={styles.CountryBoxdrop}
                          // when picker button press you will get the country object with dial code
                          pickerButtonOnPress={(item) => {
                            setCountryCode(item.dial_code);
                            setShow(false);
                          }}
                        />
              

              <TextInput
                style={styles.inputStyle}
                onChangeText={(UserEmail) =>
                  setUserPhone(UserEmail)
                }
                placeholder="987654321" //dummy@abc.com
                placeholderTextColor="#ADAFBB"
                onSubmitEditing={Keyboard.dismiss}
               maxLength={10}
                returnKeyType="done"
                keyboardType='number-pad'
                
                underlineColorAndroid="#f000"
                blurOnSubmit={false}
              />
              </View>
              </View>
              <View style={styles.loginbtn}>
             
            <TouchableOpacity
              
              activeOpacity={0.8}
              onPress={handleSubmitPress} style={styles.buttonOuter}>
               <LinearGradient
        // Button Linear Gradient
        colors={[AppStyle.gradientColorOne, AppStyle.gradientColorTwo]}
         //start={{ x: 0.5, y: 0.5 }}
        //end={{ x: 0.5, y: 0.65 }}
        style={styles.buttonStyle}>
              <Text style={styles.buttonTextStyle}>Continue</Text>
              </LinearGradient>
            </TouchableOpacity>
            <View style={styles.regection}>
                <TouchableOpacity
                    style={styles.backBtnSection}
                    activeOpacity={0.5}
                    onPress={loginUser}>
                      <Text style={styles.pswContectSec}>Login</Text>
                    </TouchableOpacity>   
              </View>
          </View>
        
      
    </View></KeyboardAvoidingView></ScrollView></View>
  );
};
export default LoginScreen;

const styles = StyleSheet.create({
   container: {
         flex: 1,
         justifyContent:'center'
      },
  mainContainer : {
flex : 1,
height:700
 },
  mainBody: {
    backgroundColor: AppStyle.appColor,
    paddingLeft:35,
    paddingRight:35,
    paddingTop: 45,
    paddingBottom: 45,
    paddingBottom: AppStyle.appBottomPadding,
    fontFamily: 'Abel',
  },
  CountryBox:{
  width: '30%',
  height: 60,
 borderTopWidth:1,
    borderLeftWidth:1,
    borderBottomWidth:1,
    borderColor:'#999999',
    position:'relative',
  padding: 10,
  borderTopLeftRadius:10,
  borderBottomLeftRadius:10
                          
  },

  SectionStyle: {
    flexDirection: 'row',
   
  },

  SectionStyleContent: {
    flexDirection: 'row',
   marginTop:10,
    marginBottom: 25,
    
  },
  mainStection:{
    
  },
  Nubcontainer:{
    flexDirection: 'row',
   
    
  },
  CountryBoxdrop:{

  },
  SectionHedText:{
    fontSize:27,
     fontFamily: 'GlorySemiBold',
     color: AppStyle.fontColor,
  },
  SectionContText:{
  	fontSize:AppStyle.contenyFontsize,
    fontFamily: 'Abel',
    lineHeight:AppStyle.contentlineHeight,
    color: AppStyle.fontColor,
  },
  loginbtn:{
    marginTop:20
  },
  buttonStyle: AppStyle.AppbuttonStyle,
  buttonTextStyle: {
    color: AppStyle.fontButtonColor,
   
    fontFamily: 'GlorySemiBold',
    fontSize: AppStyle.buttonFontsize,

  },
  CountryText:{
      color: AppStyle.inputBlackcolorText,
      fontSize: AppStyle.inputFontsize,
      paddingVertical:9,
      fontFamily: 'Abel'
  },
  pswContectSec: {
    color: AppStyle.fontColor,
    fontSize: 15,
    alignSelf: 'center',
    paddingLeft: 10,
    paddingRight: 10,
    fontFamily:'GlorySemiBold',
  },
  inputStyle: {
    borderTopWidth:1,
    borderRightWidth:1,
    borderBottomWidth:1,
    borderColor:'#999999',
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
    width:'70%',
    paddingRight: 15,
    fontSize:AppStyle.inputFontsize,
    borderTopRightRadius:10,
  	borderBottomRightRadius:10,
    fontFamily: 'Abel'
  },
  registerTextStyle: {
    color: '#FFFFFF',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 14,
    alignSelf: 'center',
    padding: 10,
  },
  regection: {
    flexDirection:'row',
    justifyContent:'flex-end'
  },
  errorTextStyle: {
    color: 'red',
    textAlign: 'center',
    fontSize: 14,
  }
});