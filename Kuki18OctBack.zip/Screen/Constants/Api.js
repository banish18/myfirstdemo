export default  {
	apiUrl:'http://18.221.17.130/kuki-backend/public/api'
}