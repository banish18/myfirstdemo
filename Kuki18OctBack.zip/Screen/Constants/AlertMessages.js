
export default  {
  /* Login Screens */
  noInternetErr     : 'Seems like you do not have internet connection!',
  phoneNumberErr    : 'Please fill your mobile number!',
  passwordErr       : 'Please fill your password!!',
  otpErr            : 'Please fill OTP!',
  /* Register Screens */
  firstNameErr      : 'Please fill your first name!',
  lastNameErr       : 'Please fill your last name!',
  genderErr         : 'Please select your gender!',
  ageErr         	: 'Please select your age!',
  religoinErr       : 'Please select your religion!',
  countryErr        : 'Please select your country!',
  stateErr         	: 'Please select your state!',
  cityErr         	: 'Please select your city!',
  /* Professional Group Screen */
  professionalErr   : 'Please select your professional group!',
  /* Language Screen */
  maxlanguageErr   	: 'You cannot select more then 5!',
  languageErr       : 'Please select languages you known!',
  /* Traits Screen */
  traitsErr   	    : 'Choose upto 5 personality traits!',
  maxtraitsErr      : 'You cannot select more then 5!',
  /* User Image Screen */
  userImageErr   	  : 'Take a picture or upload From File!',
}; 
