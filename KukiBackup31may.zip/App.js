import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
// Import Navigators from React Navigation
import {NavigationContainer,withNavigation, DrawerActions} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import 'react-native-gesture-handler';
import DrawerNavigationRoutes from './Screen/DrawerNavigationRoutes';
import React, { useState } from 'react';
// Import Screens
import SplashScreen from './Screen/SplashScreen';
import UserdetailScreen from './Screen/DrawerScreens/UserdetailScreen';
import CommunitiesScreen from './Screen/Components/Users/CommunitiesScreen';
import PersonalityTraits from './Screen/Components/Users/PersonalityTraits';
import UserstatusScreen from './Screen/Components/Users/UserstatusScreen';
import MatchesScreen from './Screen/Components/Users/MatchesScreen';
import MessagesScreen from './Screen/Components/Users/MessagesScreen';
import SearchScreen from './Screen/Components/Search/SearchScreen';
import SearchResultScreen from './Screen/Components/Search/SearchResultScreen';
import SearchResultUserDetailScreen from './Screen/Components/Search/SearchResultUserDetailScreen';
import HomeCookiesScreen from './Screen/Components/Home/HomeCookiesScreen';
import ListCookiesScreen from './Screen/Components/Cookie/ListCookiesScreen';
import SentCookiesScreen from './Screen/Components/Cookie/SentCookiesScreen';
import ReceivedCookiesScreen from './Screen/Components/Cookie/ReceivedCookiesScreen';
import BlockedCookiesScreen from './Screen/Components/Cookie/BlockedCookiesScreen';
import CookeiUserDetailScreen from './Screen/Components/Cookie/CookeiUserDetailScreen';
import CommunityBoardScreen from './Screen/Components/Community/CommunityBoardScreen';
import CommunityPostScreen from './Screen/Components/Community/CommunityPostScreen';
import CommunityPostsListScreen from './Screen/Components/Community/CommunityPostsListScreen';
import InviteEarnScreen from './Screen/Components/Invite/InviteEarnScreen';
import CookieZarScreen from './Screen/Components/Invite/CookieZarScreen';
import UserListScreen from './Screen/Components/Message/UserListScreen';
import SettingScreen from './Screen/Components/Setting/SettingScreen';
import UpdatePasswordScreen from './Screen/Components/Setting/UpdatePasswordScreen';
import LoginScreen from './Screen/LoginScreen';
import Otpscreen from './Screen/Components/Auth/Otpscreen';
import Headright from './Screen/Components/Common/Headright';
import CookieNavigationScreen from './Screen/Components/Common/CookieNavigationScreen';
import ListIcon from './Screen/Components/Common/ListIcon';
import * as Font from 'expo-font';
import AppLoading from 'expo-app-loading';
import AppStyle from './Screen/Constants/AppStyle.js';
import {createDrawerNavigator} from '@react-navigation/drawer';
import { getHeaderTitle } from '@react-navigation/elements';
import CustomSidebarMenu from './Screen/Components/CustomSidebarMenu';
import AsyncStorage from '@react-native-async-storage/async-storage';
const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();


const PublicStack = () => (
  <Stack.Navigator initialRouteName="LoginScreen">
    <Stack.Screen
        name="LoginScreen"
        component={LoginScreen}
        options={{headerShown: false}}
      />
       <Stack.Screen
        name="Otpscreen"
        component={Otpscreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="UserdetailScreen"
        component={UserdetailScreen}
        options={{headerShown: false}}
      />
       <Stack.Screen
        name="CommunitiesScreen"
        component={CommunitiesScreen}
        options={{headerShown: false}}
      />
        <Stack.Screen
        name="PersonalityTraits"
        component={PersonalityTraits}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="UserstatusScreen"
        component={UserstatusScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="HomeCookiesScreen"
        component={HomeCookiesScreen}
        options={{headerShown: false}}
      />
      <Stack.Screen
              name="SearchScreen"
              component={SearchScreen}
              options={{headerShown: false}}
            />
            <Stack.Screen
              name="SearchResultScreen"
              component={SearchResultScreen}
              options={{headerShown: false}}
            />
            <Stack.Screen
              name="SearchResultUserDetailScreen"
              component={SearchResultUserDetailScreen}
              options={{headerShown: false}}
            />
            <Stack.Screen
              name="CookeiUserDetailScreen"
              component={CookeiUserDetailScreen}
              options={{headerShown: false}}
            />
             <Stack.Screen
              name="SentCookiesScreen"
              component={SentCookiesScreen}
              options={{headerShown: false}}
            />
            <Stack.Screen
              name="ReceivedCookiesScreen"
              component={ReceivedCookiesScreen}
              options={{headerShown: false}}
            /> 
            <Stack.Screen
              name="BlockedCookiesScreen"
              component={BlockedCookiesScreen}
              options={{headerShown: false}}
            />
            <Stack.Screen
              name="CookieNavigationScreen"
              component={CookieNavigationScreen}
              options={{headerShown: false}}
            />
            <Stack.Screen
              name="ListCookiesScreen"
              component={ListCookiesScreen}
              options={{headerShown: false}}
            /> 
            <Stack.Screen
              name="MatchesScreen"
              component={MatchesScreen}
              options={{headerShown: false}}
            />
             <Stack.Screen
              name="MessagesScreen"
              component={MessagesScreen}
              options={{headerShown: false}}
            />
             <Stack.Screen
              name="CommunityBoardScreen"
              component={CommunityBoardScreen}
              options={{headerShown: false}}
            />
            <Stack.Screen
              name="CommunityPostScreen"
              component={CommunityPostScreen}
              options={{headerShown: false}}
            />
            <Stack.Screen
              name="CommunityPostsListScreen"
              component={CommunityPostsListScreen}
              options={{headerShown: false}}
            />
            <Stack.Screen
              name="InviteEarnScreen"
              component={InviteEarnScreen}
              options={{headerShown: false}}
            />
            <Stack.Screen
              name="CookieZarScreen"
              component={CookieZarScreen}
              options={{headerShown: false}}
            />
            <Stack.Screen
              name="UserListScreen"
              component={UserListScreen}
              options={{headerShown: false}}
            />
            <Stack.Screen
              name="SettingScreen"
              component={SettingScreen}
              options={{headerShown: false}}
            /> 
            <Stack.Screen
              name="UpdatePasswordScreen"
              component={UpdatePasswordScreen}
              options={{headerShown: false}}
            />

  </Stack.Navigator>
);

const ProtectedStack = () => (
  <Stack.Navigator initialRouteName="ListCookiesScreen">
   <Stack.Screen
              name="UpdatePasswordScreen"
              component={UpdatePasswordScreen}
              options={{headerShown: false}}
            />
  </Stack.Navigator>
);

let customFonts = {
 Abel: require('./assets/fonts/Abel-Regular.ttf'),
 Aclonica: require('./assets/fonts/Aclonica-Regular.ttf'),
};
export default class App extends React.Component {



 state = {
    fontsLoaded: false,
    isLoggedInUser: false,
  };

  async _loadFontsAsync() {
    //AsyncStorage.setItem('isLoggedIn', '0');
    await Font.loadAsync(customFonts);
    this.setState({ fontsLoaded: true });
     

  }

  async getData() {
      await AsyncStorage.getItem("isLoggedIn").then((value) => {
          this.setState({isLoggedInUser:value})

      })
      .then(res => {
        
      });
  }

  componentDidMount() {
    this._loadFontsAsync();
    this.getData();
  }
render() {
     if (!this.state.fontsLoaded) {
      return <AppLoading />;
    }


  const isLoggedIn = this.state.isLoggedInUser;
 

  return (
    <NavigationContainer>
      <Drawer.Navigator
        screenOptions={{
          drawerStyle: {
            backgroundColor: "white",
            zIndex: 100,
          },
          drawerPosition: "left",
        }}
        drawerContent={CustomSidebarMenu}
      >
        {isLoggedIn == '1' ? (
          <Drawer.Screen
            name="ProtectedStack"
            component={ProtectedStack}
             options={({ navigation }) => ({
            title: '',
           
            headerLeft: () => (
             
            <ListIcon/>
              
            ),headerRight: () => {
              return (
                <Headright iconColor={AppStyle.iconColorblack}/>
                
              );
            },
          })}
          />
        ) : (
          <Drawer.Screen
            name="PublicStack"
            component={PublicStack}
             options={({ navigation }) => ({
            title: '',
             headerStyle: {
    backgroundColor: "#fff",
    height:60,
    elevation: 0, // remove shadow on Android
          shadowOpacity: 0, // remove shadow on iOS
  },
            headerLeft: () => (
             
            <ListIcon/>
              
            ),headerRight: () => {
              return (
                <Headright iconColor={AppStyle.iconColorblack}/>
                
              );
            }
          })}
          />
        )}

        {/* This screen can be accessible even if when user is not authenticated */}

       
      </Drawer.Navigator>
    </NavigationContainer>
  );
}
}
