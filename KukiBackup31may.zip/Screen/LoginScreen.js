// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/
// Import React and Component
import React, {useState, createRef} from 'react';
import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  Image,
  Keyboard,
  TouchableOpacity,
  KeyboardAvoidingView
} from 'react-native';


import AppStyle from './Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CountryPicker from "react-native-country-codes-picker";

import Loader from './Components/Loader';

const LoginScreen = ({navigation}) => {
  const [userPhone, setUserPhone] = useState('');
  const [userPassword, setUserPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errortext, setErrortext] = useState('');
  const [show, setShow] = useState(false);
  const [countryCode, setCountryCode] = useState('+1');
  const passwordInputRef = createRef();
   const [fontsLoaded] = useState('false');
  const handleSubmitPress = () => {
    setErrortext('');
    if (!userPhone) {
      alert('Please fill your mobile numer');
      return;
    }

   


  navigation.navigate('Otpscreen');
   /* setLoading(true);
  
    AsyncStorage.setItem('user_id', 'bani@gmail.com');
          navigation.replace('DrawerNavigationRoutes');

          setLoading(false);     
    let dataToSend = {email: userPhone, password: userPassword};
    let formBody = [];
    for (let key in dataToSend) {
      let encodedKey = encodeURIComponent(key);
      let encodedValue = encodeURIComponent(dataToSend[key]);
      formBody.push(encodedKey + '=' + encodedValue);
    }
    formBody = formBody.join('&');

    fetch('http://localhost:3000/api/user/login', {
      method: 'POST',
      body: formBody,
      headers: {
        //Header Defination
        'Content-Type':
        'application/x-www-form-urlencoded;charset=UTF-8',
      },
    })
      .then((response) => response.json())
      .then((responseJson) => {
        //Hide Loader
        setLoading(false);
        console.log(responseJson);
        // If server response message same as Data Matched
        if (responseJson.status === 'success') {
          AsyncStorage.setItem('user_id', responseJson.data.email);
          console.log(responseJson.data.email);
          navigation.replace('DrawerNavigationRoutes');
        } else {
          setErrortext(responseJson.msg);
          console.log('Please check your email id or password');
        }
      })
      .catch((error) => {
        //Hide Loader
        setLoading(false);
        console.error(error);
      });*/
  };

  return (
    <View style={styles.mainBody}>
      <Loader loading={loading} />
      
        <View>
          
            <View style={{alignItems: 'center'}}>

              <Image
                source={require('../assets/images/logo/logo-svg.png')}
                style={{
                  width: 250,
                 
                  resizeMode: 'contain',
                  marginBottom: 20,
                }}
              />
            </View>
            <View style={styles.SectionStyle}>
              <Text style={styles.SectionHedText}>My mobile</Text>
            
            </View>
            <View style={styles.SectionStyleContent}>
             
            <Text style={styles.SectionContText}>Please enter your valid phone number. We will send you a 4-digit code to verify your account. </Text>  
            </View>
            <View style={styles.mainStection}>
            <View style={styles.Nubcontainer}>
            <TouchableOpacity
                          onPress={() => setShow(true)}
                          style={styles.CountryBox}
                        >
                          <Text style={styles.CountryText}>
                              ({countryCode})
                          </Text>
                        </TouchableOpacity>
                        <CountryPicker
                          show={show}
                          style={styles.CountryBoxdrop}
                          // when picker button press you will get the country object with dial code
                          pickerButtonOnPress={(item) => {
                            setCountryCode(item.dial_code);
                            setShow(false);
                          }}
                        />
              

              <TextInput
                style={styles.inputStyle}
                onChangeText={(UserEmail) =>
                  setUserPhone(UserEmail)
                }
                placeholder="987654321" //dummy@abc.com
                placeholderTextColor="#ADAFBB"
                autoCapitalize="none"
               maxLength={10}
                returnKeyType="next"
                keyboardType='number-pad'
                onSubmitEditing={() =>
                  passwordInputRef.current &&
                  passwordInputRef.current.focus()
                }
                underlineColorAndroid="#f000"
                blurOnSubmit={false}
              />
              </View>
              </View>
              <View style={styles.loginbtn}>
            <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity={0.5}
              onPress={handleSubmitPress}>
              <Text style={styles.buttonTextStyle}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      
    </View>
  );
};
export default LoginScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: AppStyle.appColor,
    alignContent: 'center',
    paddingLeft:35,
    paddingRight:35,
     fontFamily: 'Abel',
  },
  CountryBox:{
  width: '30%',
  height: 60,
 borderTopWidth:1,
    borderLeftWidth:1,
    borderBottomWidth:1,
    borderColor:'#999999',
    position:'relative',
  padding: 10,
  borderTopLeftRadius:10,
  borderBottomLeftRadius:10
                          
  },

  SectionStyle: {
    flexDirection: 'row',
   
  },

  SectionStyleContent: {
    flexDirection: 'row',
   marginTop:10,
    marginBottom: 25,
    
  },
  mainStection:{
    
  },
  Nubcontainer:{
    flexDirection: 'row',
   
    
  },
  CountryBoxdrop:{

  },
  SectionHedText:{
    fontSize:AppStyle.headingFontsize,
     fontFamily: 'Abel'
  },
  SectionContText:{
  	fontSize:AppStyle.contenyFontsize,
    fontFamily: 'Abel'
  },
  loginbtn:{
    marginTop:20
  },
  buttonStyle: AppStyle.AppbuttonStyle,
  buttonTextStyle: {
    color: '#FFFFFF',
    fontFamily: 'Abel',
    fontSize: AppStyle.buttonFontsize

  },
  CountryText:{
      color: AppStyle.inputBlackcolorText,
      fontSize: AppStyle.inputFontsize,
      paddingVertical:9,
      fontFamily: 'Abel'
  },
  inputStyle: {
    borderTopWidth:1,
    borderRightWidth:1,
    borderBottomWidth:1,
    borderColor:'#999999',
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
    width:'70%',
    paddingRight: 15,
    fontSize:AppStyle.inputFontsize,
    borderTopRightRadius:10,
  	borderBottomRightRadius:10,
    fontFamily: 'Abel'
  },
  registerTextStyle: {
    color: '#FFFFFF',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 14,
    alignSelf: 'center',
    padding: 10,
  },
  errorTextStyle: {
    color: 'red',
    textAlign: 'center',
    fontSize: 14,
  },
});