// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React
import React from 'react';

// Import Navigators from React Navigation
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';

// Import Screens
import CookeiUserDetailScreen from './Components/Cookie/CookeiUserDetailScreen';
import SettingsScreen from './DrawerScreens/SettingsScreen';
import CustomSidebarMenu from './Components/CustomSidebarMenu';
import NavigationDrawerHeader from './Components/NavigationDrawerHeader';
import DrawerItems from './Constants/DrawerItems';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Feather } from '@expo/vector-icons';
import { FontAwesome5 } from '@expo/vector-icons';
import { getHeaderTitle } from '@react-navigation/elements';
import ListCookiesScreen from './Components/Cookie/ListCookiesScreen';
import SettingScreen from './Components/Setting/SettingScreen';
import InviteEarnScreen from './Components/Invite/InviteEarnScreen';
import {
  Text
} from 'react-native';


const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

const Header = (screen) => {
  return <Text>{screen.title}</Text>;
};


const DrawerNavigatorRoutes = (props) => {
  return (
    <Drawer.Navigator 
    drawerType="front"
    initialRouteName="UserdetailScreen"
    screenOptions={{
      activeTintColor: '#e91e63',
      backgroundColor:'red',
      itemStyle: { marginVertical: 1 },
    }}
    screenOptions={{headerShown: false}}
    drawerContent={CustomSidebarMenu}
   
  >
    {
      DrawerItems.map(drawer=>
      <Drawer.Screen 
        key={drawer.name}
        name={drawer.name} 
        options={{
        drawerIcon:({focused})=>
         drawer.iconType==='Material' ? 
          <MaterialCommunityIcons 
              name={drawer.iconName}
              size={24} 
              color={focused ? "#e91e63" : "black"} 
          />
        :
        drawer.iconType==='Feather' ?
          <Feather 
            name={drawer.iconName}
            size={24} 
            color={focused ? "#e91e63" : "black"} 
          /> 
        :
          <FontAwesome5 
            name={drawer.iconName}
            size={24} 
            color={focused ? "#e91e63" : "black"} 
          />
        ,
            headerShown:false,
            header: ({ navigation, route, options }) => {
              const title = getHeaderTitle(options, route.name);
            
              return <Header title={title} style={options.headerStyle} />;
            }
        }} 
        component={
          drawer.name==='Home' ? ListCookiesScreen :
              drawer.name==='Profile' ? CookeiUserDetailScreen :
              drawer.name==='Settings' ? SettingScreen :
              drawer.name==='Invite a Friend!' ? InviteEarnScreen: 
                     ListCookiesScreen
        } 
      />)
    }
    
  </Drawer.Navigator>


  );
};

export default DrawerNavigatorRoutes;