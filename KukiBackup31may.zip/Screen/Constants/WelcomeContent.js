export default  {
    welcomeTitleSlide1: 'Welcome to Grocery!!!',
    welcomeTitleSlide2: 'Welcome Slide 2',
    welcomeTitleSlide3: 'Welcome Slide 3',

    welcomeDescSlide1: 'Description.\nSay something cool',
    welcomeDescSlide2: 'Shop and save with our Free Shipping promotions.',
    welcomeDescSlide3: 'I\'m already out of descriptions\nLorem ipsum bla bla bla',

    welcomeBackgroundSlide1: '#111100',
    welcomeBackgroundSlide2: '#febe29',
    welcomeBackgroundSlide3: '#22bcb5'
  };