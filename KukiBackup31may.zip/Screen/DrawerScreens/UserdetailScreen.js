// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';
import {Picker} from '@react-native-picker/picker';

import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CountryPicker from "react-native-country-codes-picker";
import { useNavigation, NavigationContainer } from '@react-navigation/native';
import Loader from '../Components/Loader';

class UserdetailScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      FirstName: '',
    selectedGenderValue:'',
    selectedAgeValue:'',
    selectedReligionValue:'',
    selectedStateValue:'',
    selectedCityValue:''
    };

      this.state.genderoptions = [
  { value: 'chocolate', label: 'Chocolate' },
  { value: 'strawberry', label: 'Strawberry' },
  { value: 'vanilla', label: 'Vanilla' }
]
  }

   createAlert = (FirstName) =>
    Alert.alert(
      "Required",
      FirstName,
      [
       
        { text: "OK", onPress: () => console.log("OK Pressed") }
      ]
    );


  setSelectedValue(itmVal,type){
    if(type == 'FirstName'){
      
      this.setState({FirstName: itmVal });

    }else if(type == 'LastName'){
      
      this.setState({LastName: itmVal });

    }else  if(type == 'gender'){
      //alert(itmVal);
      this.setState({selectedGenderValue: itmVal });
    }if(type == 'age'){
      this.setState({selectedAgeValue: itmVal });
    }else if(type == 'religion'){
      this.setState({selectedReligionValue: itmVal });
    }else if(type == 'State'){
      this.setState({selectedStateValue: itmVal });
    }else if(type == 'city'){
      this.setState({selectedCityValue: itmVal });
    }
  }



  render (){

    const { FirstName,LastName,genderoptions,selectedValue,selectedAgeValue,selectedGenderValue,selectedReligionValue,selectedStateValue,selectedCityValue } = this.state;

     const handleSubmitPress = () => {
    
    if (!this.state.FirstName) {
      
      this.createAlert('Please Fill First Name');
      
      return;
    }else if(!this.state.LastName){
      this.createAlert('Please Fill Last Name');
      
      return;
    }else if(!this.state.selectedGenderValue){
      this.createAlert('Please Select Your Gender');
      
      return;
    }else if(!this.state.selectedAgeValue){
      this.createAlert('Please Select Your Age');
      
      return;
    }else if(!this.state.selectedStateValue){
      this.createAlert('Please Select Your State');
      
      return;
    }else if(!this.state.selectedCityValue){
      this.createAlert('Please Select Your City');
      
      return;
    }
this.props.navigation.navigate('CommunitiesScreen');
  };
    return <ScrollView>
         <SafeAreaView style={styles.mainBody}>
          
            
            <View style={styles.SectionHeadStyle}>
              <Text style={styles.SectionHedText}>User Personal Details</Text>
            
            </View>
            
            <View style={styles.mainStection}>
            <View style={styles.inputboxContainer}>
            

              <TextInput
                style={styles.inputStyle}
                onChangeText={(FirstName) =>
                  this.setSelectedValue(FirstName,'FirstName')
                }
                placeholder="First Name" 
                placeholderTextColor="#000"
                autoCapitalize="none"
                
              />
              
                  <Text style={styles.SectionLabel}>First Name</Text>
              
             
              </View>
              <View style={styles.inputboxContainer}>
            

              <TextInput
                style={styles.inputStyle}
                onChangeText={(LastName) =>
                  this.setSelectedValue(LastName,'LastName')
                }
                placeholder="Last Name" 
                placeholderTextColor="#000"

                autoCapitalize="none"
                returnKeyType="next"
              />
              <Text style={styles.SectionLabel}>Last Name</Text>
              </View>
              <View style={styles.selectboxContainer}>
            

               <Picker
               style={styles.selectStyle}
              fontFamily="abel"
        selectedValue={selectedGenderValue}
        
        onValueChange={(itemmValue, itemIndex) => this.setSelectedValue(itemmValue,'gender')}
      >
        <Picker.Item  fontFamily="abel" label="Plese select your gender" value="" />
        <Picker.Item label="male" value="maile" />
        <Picker.Item label="female" value="female" />
        <Picker.Item label="other" value="other" />
      </Picker>
      <Text style={styles.SectionSmallLabel}>Gender</Text>

              </View>
              <View style={styles.selectboxContainer}>
            

              <Picker
        selectedValue={selectedAgeValue}
        style={styles.selectStyle}
        onValueChange={(itemValue, itemIndex) => this.setSelectedValue(itemValue,'age')}
      >
        <Picker.Item label="Plese select your age" value="" />
        <Picker.Item label="25" value="25" />
        <Picker.Item label="30" value="30" />
        <Picker.Item label="35" value="35" />
      </Picker>
      <Text style={styles.SectionLabel}>Age Group</Text>
              </View>
               <View style={styles.selectboxContainer}>
            

              <Picker
        selectedValue={selectedReligionValue}
        style={styles.selectStyle}
        onValueChange={(itemValue, itemIndex) => this.setSelectedValue(itemValue,'religion')}
      >
        <Picker.Item label="Plese select your age" value="" />
        <Picker.Item label="Hindu" value="Hindu" />
        <Picker.Item label="Muslim" value="Muslim" />
        <Picker.Item label="Other" value="Other" />
      </Picker>
      <Text style={styles.SectionSmallLabel}>Religion</Text>
              </View>
                 <View style={styles.selectboxContainer}>
            

              <Picker
        selectedValue={selectedStateValue}
        style={styles.selectStyle}
        onValueChange={(itemValue, itemIndex) => this.setSelectedValue(itemValue,'State')}
      >
        <Picker.Item label="Plese select your state" value="" />
        <Picker.Item label="Punjab" value="Punjab" />
        <Picker.Item label="Himachal" value="Himachal" />
        <Picker.Item label="Haryana" value="Haryana" />
      </Picker>
      <Text style={styles.SectionVSmallLabel}>State</Text>
              </View>
                 <View style={styles.selectboxContainer}>
            

              <Picker
        selectedValue={selectedCityValue}
        style={styles.selectStyle}
        onValueChange={(itemValue, itemIndex) => this.setSelectedValue(itemValue,'city')}
      >
        <Picker.Item label="Plese select your city" value="" />
        <Picker.Item label="Shimla" value="Shimla" />
        <Picker.Item label="Karnal" value="Karnal" />
        <Picker.Item label="Mohali" value="Mohali" />
      </Picker>
      <Text style={styles.SectionVSmallLabel}>City</Text>
              </View>


              </View>
            <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity={0.5}
              onPress={handleSubmitPress}>
              <Text style={styles.buttonTextStyle}>Next</Text>
            </TouchableOpacity>
          
        </SafeAreaView>
      </ScrollView>
  }
};
export default UserdetailScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: AppStyle.appColor,
    alignContent: 'center',
     paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
     paddingBottom: AppStyle.appBottomPadding,
     paddingTop: AppStyle.appTopPadding,
  },
  SectionHeadStyle: {
    flexDirection: 'row',
    paddingBottom: 25,
   
   
    
  },
  inputboxContainer:{
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
    borderColor:'#E8E6EA',
    borderWidth:1,
    borderRadius:16,
    height:58,
    marginBottom:22,
  },
  selectboxContainer:{
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
   fontFamily: 'Abel',
    borderWidth:1,
    borderColor:'#E8E6EA',
    borderRadius:16,
    height:58,
    marginBottom:22
  },
  SectionLabel:{
    position: 'absolute', top: -10, left: 20, right: 0, bottom: 0,
    backgroundColor:'#fff',
    paddingLeft:10,
    paddingRight:10,
    width:92,
    height:25,
    textAlign:'center',
    fontFamily: 'Abel',
    color:'rgba(0, 0, 0, 0.4)',
  },
  SectionSmallLabel:{
    position: 'absolute', top: -10, left: 20, right: 0, bottom: 0,
    backgroundColor:'#fff',
    alignSelf: 'flex-start',
    paddingLeft:10,
    paddingRight:10,
    width:70,
    height:25,
    textAlign:'center',
    color:'rgba(0, 0, 0, 0.4)',
    fontFamily: 'Abel'
  },
  SectionVSmallLabel:{
    position: 'absolute', top: -10, left: 20, right: 0, bottom: 0,
    backgroundColor:'#fff',
    alignSelf: 'flex-start',
    paddingLeft:10,
    paddingRight:10,
    width:55,
    height:25,
    textAlign:'center',
    fontFamily: 'Abel',
    color:'rgba(0, 0, 0, 0.4)',
  },
  SectionHedText:{
    fontSize:AppStyle.headingFontMediumsize,
    fontWeight:AppStyle.headingFontweight,
    fontFamily: 'Abel'
  },
  buttonStyle: AppStyle.AppbuttonStyle,
  buttonTextStyle: {
    color: '#FFFFFF',
    fontSize:16,
    fontSize: AppStyle.buttonFontsize,
    fontFamily: 'Abel'
  },
  inputStyle: {
    height:58,
    color: AppStyle.inputBlackcolorText,
    fontSize: 16,
    position:'relative',
    zIndex: 1, // works on io,
    fontFamily: 'Abel'

  },
  selectStyle: {
     height:58,
     width:158,
    color: AppStyle.inputBlackcolorText,
    fontWeight: 'bold',
    fontSize: 14,
    width:'100%',
    fontFamily: 'Abel'
  },

  errorTextStyle: {
    color: 'red',
    textAlign: 'center',
    fontSize: 14,
  },
});