// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';


import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  Pressable,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Loader from '../../Components/Loader';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';

class InviteEarnScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      checked:'male'
    };
    AsyncStorage.setItem('activeClass', 'FactiveClass');
  
  }

 createAlert = (FirstName) =>
  Alert.alert(
    "Required",
    FirstName,
    [
     
      { text: "OK", onPress: () => console.log("OK Pressed") }
    ]
  );
  backScreen(){
    
    this.props.navigation.navigate('UserstatusScreen');
  }
  nextScreen(){
    
    this.props.navigation.navigate('UserstatusScreen');
  }

  

  render (){

    const { checked} = this.state;

    const handleEarnPress = () =>{
      this.props.navigation.navigate('CookieZarScreen');
    };
    const handleSubmitPress = () =>{
      alert('Working');
    };
    return <ScrollView><View style={styles.mainBody}>
            <View style={styles.topheadSection}>
              <Text style={styles.SectionHeadStyle}>Invite and Earn</Text>

             
              </View>
              <View style={styles.mainStection}>
              <View style={styles.bannerStection}>
               <Image
                source={require('../../../assets/images/undraw_transfer_money.png')}
                 style={[{
                 resizeMode: 'contain',
                  width:296,
                  height:215
                 
                },styles.imgIcon]}

                
              />
              <Text style={styles.inviteCont}>Invite your contact to downloand this app and you both earn 10 cookies each for FREE. Simply share the download link with you contacts</Text>
              
              <Text style={styles.inviteDownCont}>Share the download link via </Text>
              </View>

              <View style={styles.numbrsareSec}>
              <Image
                source={require('../../../assets/images/icons/socialIcons.png')}
                 style={[{
                 resizeMode: 'contain',
                  width:'100%',
                  height:86
                 
                }]}

                
              />
               <Text style={styles.sharenumbCont}>Shere the mobile number of your contact who referred this app to you and both earn 10 cookies each for FREE</Text>
              </View>

              <View style={styles.BottonSection}>
              <Pressable
             
               style={({ pressed }) => [
                  {
                    backgroundColor: pressed
                      ? 'rgba(253, 139, 48, 0.31)'
                      :  'background: linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'
                  },
                  styles.buttonnumberStyle
                ]}
              activeOpacity={0.5}
              onPress={handleSubmitPress}>
              <Text style={styles.buttonTextStyle}>9812312345</Text>
            </Pressable>

             <Pressable
              
              style={({ pressed }) => [
                  {
                    backgroundColor: pressed
                      ? 'background: linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'
                      : 'rgba(253, 139, 48, 0.31)'
                  },
                  styles.buttonEarnStyle
                ]}
              onPress={handleEarnPress}>
               <Image
                source={require('../../../assets/images/icons/cookieblack.png')}
                 style={[{
                 resizeMode: 'contain',
                  width:20,
                  height:20
                 
                }]}

                
              />
              <Text style={styles.buttonTextStyle}>


              EARN</Text>
            </Pressable>
              </View>
             
              </View>
              
          </View>
          </ScrollView>
          
          
           
        
      
  }
};
export default InviteEarnScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex:1,
    backgroundColor: AppStyle.appColor,
    paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
    paddingBottom: 35,
    paddingTop: 40,
    height:'100%'
  },
  topheadSection:{
    display:'flex',
    justifyContent:'space-between',
    alignItems:'center',
    flexDirection:'row',
    marginBottom:15
  },
  mainStection:{
    width:'100%',
    marginTop:15,
    justifyContent:'center',
    
  },
  SectionHeadStyle: {
    fontSize:34,
    fontFamily: 'Abel',
    fontWeight: '400',
  },
  bannerStection:{
    alignItems:'center'
  },
  inviteCont:{
    fontSize:15,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'#FD6F01',
    marginTop:15,
    paddingLeft:10,
    paddingRight:10,
    textAlign:'center'
  },
  inviteDownCont:{
    fontSize:15,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'#000',
    marginTop:15,
    paddingLeft:10,
    paddingRight:10,
    textAlign:'center'
  },
  numbrsareSec:{
    width:'100%'
  },
  sharenumbCont:{
    fontSize:15,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'#FD6F01',
    marginTop:15,
    paddingLeft:12,
    paddingRight:12,
    textAlign:'center'
  },
  BottonSection:{
    flexDirection:'row',
    justifyContent:'space-between',
    marginTop:15,
    marginBottom:20
  },
  buttonnumberStyle:{
    paddingLeft:25,
    paddingRight:25,
    paddingTop:15,
    paddingBottom:15,
   
    borderRadius:15,
     width:'48%'
  },
  buttonEarnStyle:{
    paddingLeft:25,
    paddingRight:25,
    paddingTop:15,
    paddingBottom:15,
   
    borderRadius:15,
    flexDirection:'row',
    width:'48%',
    
    justifyContent:'space-around'
  }

});