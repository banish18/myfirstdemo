// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';


import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  Pressable,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Loader from '../../Components/Loader';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';

class CookieZarScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      RedeemedCokie:'100',
      Cookie:'100'
    };
    AsyncStorage.setItem('activeClass', 'FactiveClass');
  
  }

 createAlert = (FirstName) =>
  Alert.alert(
    "Required",
    FirstName,
    [
     
      { text: "OK", onPress: () => console.log("OK Pressed") }
    ]
  );
  backScreen(){
    
    this.props.navigation.navigate('UserstatusScreen');
  }
  nextScreen(){
    
    this.props.navigation.navigate('UserstatusScreen');
  }

  

  render (){

    const { checked,Cookie,RedeemedCokie} = this.state;

    const handleSubmitPress = () =>{
      alert('Working');
    };
    return <ScrollView><View style={styles.mainBody}>
            <View style={styles.topheadSection}>
              <Text style={styles.SectionHeadStyle}>My Cookie Jar</Text>
              </View>
              <View style={styles.mainStection}>

               <View style={styles.jarMainSection}>
               <View style={styles.jarStection}>
                      <Image
                      source={require('../../../assets/images/eptzar.png')}
                       style={[{
                       resizeMode: 'contain',
                        width:67,
                        height:67
                       
                      },styles.imgIcon]}

                      
                    />
                    <Image
                      source={require('../../../assets/images/cookiezar.png')}
                       style={[{
                       resizeMode: 'contain',
                        width:67,
                        height:67
                       
                      },styles.imgIcon]}
                    />
                </View>
                <View style={styles.jarContentStection}>
                  <Text style={[styles.jarMainSectionCont]}>Your <Text style={styles.jarMainColorSectionCont}>Cookie</Text> Jar  </Text>
                  <Text style={[styles.jarMainSectionCont]}>is Empty</Text>
                   <Text style={[styles.jarMainSectionCont]}>OR </Text>
                   <Text style={[styles.jarMainSectionCont]}>Has 25 Cookies</Text>
                </View>
              </View>  
              <View style={styles.bannerStection}>
               
             
              <Text style={styles.inviteCont}>Redeem cash against your cookies through Paytm or GPay</Text>
              
             
              </View>

              <View style={styles.numbrsareSec}>
               <View style={styles.BottonSection}>
               <Pressable
              
              style={({ pressed }) => [
                  {
                    backgroundColor: pressed
                      ? 'background: linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'
                      : 'rgba(253, 139, 48, 0.31)'
                  },
                  styles.buttonEarnStyle
                ]}
              onPress={handleSubmitPress}>
               <Image
                source={require('../../../assets/images/icons/cookieblack.png')}
                 style={[{
                 resizeMode: 'contain',
                  width:20,
                  height:20
                 
                }]}

                
              />
              <TextInput
                style={styles.inputStyle}
                onChangeText={(Cookie) =>
                  this.setState({RedeemedCokie:Cookie})
                }
                value="100" //dummy@abc.com
                placeholderTextColor="#ADAFBB"
                autoCapitalize="none"
               maxLength={10}
                returnKeyType="next"
                keyboardType='number-pad'
    
              />
            </Pressable>
              <Pressable
             
               style={({ pressed }) => [
                  {
                    backgroundColor: pressed
                      ? 'rgba(253, 139, 48, 0.31)'
                      :  'background: linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'
                  },
                  styles.buttonnumberStyle
                ]}
              activeOpacity={0.5}
              onPress={handleSubmitPress}>
              <Text style={styles.buttonTextStyle}>REDEEM </Text>
              <Image
                source={require('../../../assets/images/icons/iconright.png')}
                 style={[{
                 resizeMode: 'contain',
                  width:8,
                  height:14,
                  marginLeft:20
                 
                }]}

                
              />
              
            </Pressable>

             
              </View>

              <Text style={styles.donteContent}>Donate Cookies to a Loved one</Text>


              <View style={styles.BottonSection}>

              <Pressable
             
               style={({ pressed }) => [
                  {
                    backgroundColor: pressed
                      ? 'rgba(253, 139, 48, 0.31)'
                      :  'background: linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'
                  },
                  styles.buttonnumberStyle
                ]}
              activeOpacity={0.5}
              onPress={handleSubmitPress}>
              <Text style={styles.buttonTextStyle}>9812312345 </Text>
              
              
            </Pressable>
               <Pressable
              
              style={({ pressed }) => [
                  {
                    backgroundColor: pressed
                      ? 'background: linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'
                      : 'rgba(253, 139, 48, 0.31)'
                  },
                  styles.buttonEarnStyle
                ]}
              onPress={handleSubmitPress}>
               <Image
                source={require('../../../assets/images/icons/cookieblack.png')}
                 style={[{
                 resizeMode: 'contain',
                  width:20,
                  height:20
                 
                }]}

                
              />
              <TextInput
                style={styles.inputStyle}
                onChangeText={(Cookie) =>
                  this.setState({RedeemedCokie:Cookie})
                }
                value="25" //dummy@abc.com
                placeholderTextColor="#ADAFBB"
                autoCapitalize="none"
               maxLength={10}
                returnKeyType="next"
                keyboardType='number-pad'
    
              />
            </Pressable>
              

             
              </View>
              </View>

             
             <View style={styles.donatebtn}>
            <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity={0.5}
              onPress={handleSubmitPress}>
              <Text style={styles.buttonTextStyle}>DONATE</Text> 
              <Image
                source={require('../../../assets/images/icons/lovewhite.png')}
                 style={[{
                 resizeMode: 'contain',
                  width:26,
                  height:22,
                  marginLeft:20
                 
                }]}
                />
            </TouchableOpacity>
          </View>
              </View>
              
          </View>
          </ScrollView>
          
          
           
        
      
  }
};
export default CookieZarScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex:1,
    backgroundColor: AppStyle.appColor,
    paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
    paddingBottom: 35,
    paddingTop: 40,
    height:'100%'
  },
  topheadSection:{
    display:'flex',
    justifyContent:'space-between',
    alignItems:'center',
    flexDirection:'row',
    marginBottom:15
  },
  mainStection:{
    width:'100%',
    marginTop:15,
    justifyContent:'center',
    
  },
  SectionHeadStyle: {
    fontSize:34,
    fontFamily: 'Abel',
    fontWeight: '400',
  },
  bannerStection:{
    alignItems:'center'
  },
  jarStection:{
    flexDirection:'row',
    justifyContent:'space-around',
    width:'50%',
    alignItems:'center'
  },
  jarMainSection:{
    flexDirection:'row',
  },
  jarMainSectionCont:{
    fontSize:14,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'#000',
    paddingLeft:30
  },
  jarMainColorSectionCont:{
    fontSize:14,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'#FD6F01'
  },
  jarContentStection:{
    width:'50%',
    justifyContent:'flex-end',
  },
  inviteCont:{
    fontSize:18,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'#FD6F01',
    marginTop:25,
    paddingLeft:10,
    paddingRight:10,
    textAlign:'center'
  },
  inviteDownCont:{
    fontSize:15,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'#000',
    marginTop:15,
    paddingLeft:10,
    paddingRight:10,
    textAlign:'center'
  },
  numbrsareSec:{
    width:'100%',
    marginTop:15,
  },
  sharenumbCont:{
    fontSize:15,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'#FD6F01',
    marginTop:15,
    paddingLeft:12,
    paddingRight:12,
    textAlign:'center'
  },
  BottonSection:{
    flexDirection:'row',
    justifyContent:'space-between',
    marginTop:15,
    marginBottom:20
  },
  buttonnumberStyle:{
    paddingLeft:25,
    paddingRight:25,
    paddingTop:15,
    paddingBottom:15,
    flexDirection:'row',
    borderRadius:15,
     width:'48%',
     alignItems:'center'

  },
  buttonEarnStyle:{
    paddingLeft:25,
    paddingRight:25,
    paddingTop:15,
    paddingBottom:15,
    borderRadius:15,
    flexDirection:'row',
    width:'48%',
    
    justifyContent:'space-around'
  },
  inputStyle:{

    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
    width:'70%',
    paddingRight: 15,
    fontSize:AppStyle.inputFontsize,
    borderTopRightRadius:10,
    borderBottomRightRadius:10,
    fontFamily: 'Abel'
  },
  buttonTextStyle:{
    fontSize:20,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'#FFF'
  },
  donteContent:{
    fontSize:18,
    fontFamily: 'Abel',
    fontWeight: '400',
    color:'#FD6F01',
    textAlign:'center'
  },
  donatebtn:{
    marginTop:20
  },
  buttonStyle: {
    backgroundColor: 'background: linear-gradient(90deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 114.92%)',
    borderWidth: 0,
    color: '#FFFFFF',
    borderColor: '#dadae8',
    alignItems: 'center',
    borderRadius: 15,
    flexDirection:'row',
    paddingTop:18,
    paddingBottom:18,
    textAlign:'center',
    marginBottom: 25,
     width:'100%',
     alignItems:'center',
     justifyContent:'center'
  },

});