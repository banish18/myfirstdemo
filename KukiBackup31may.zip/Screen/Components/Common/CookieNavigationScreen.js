// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component,useCallback} from 'react';
import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { FontAwesome5 } from '@expo/vector-icons';
import { MaterialCommunityIcons } from '@expo/vector-icons';

class CookieNavigationScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      activeClass:'nm'
    };
    this.getData();
  }


  async getData() {
      await AsyncStorage.getItem("activeClass").then((value) => {
          this.setState({activeClass: value});

      })
      .then(res => {
        
      });
  }
  swithScreen(val,iStat){
    this.props.navigation.push(val,{
      isReturnscreen: 'ListCookiesScreen'
    });
  }

  render (){
    const {activeClass,CactiveClass,FactiveClass,MactiveClass,UactiveClass} = this.props;
    return  <View style={styles.ftmenuSection}>

                <TouchableOpacity
                  style={[(this.state.activeClass == 'CactiveClass' ? styles.CactiveClass : '')]}
                  activeOpacity={0.5}
                  onPress={this.swithScreen.bind(this,'HomeCookiesScreen','CactiveClass')}
                  > 
                   <MaterialCommunityIcons 
                  name={'home'}
                  size={24} 
                  color={"linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)"} 
              />
                </TouchableOpacity>
                 <TouchableOpacity
                  style={[(this.state.activeClass == 'FactiveClass' ? styles.FactiveClass : '')]}
                  activeOpacity={0.5}
                  onPress={this.swithScreen.bind(this,'ListCookiesScreen')}>
                   <MaterialCommunityIcons 
                  name={'heart'}
                  size={24} 
                  color={"linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)"} 
              />
                  </TouchableOpacity>
                <TouchableOpacity
                  style={[(this.state.activeClass == 'COactiveClass' ? styles.COactiveClass : '')]}
                  activeOpacity={0.5}
                  onPress={this.swithScreen.bind(this,'CommunityPostsListScreen','COactiveClass')}
                  > 
                  <FontAwesome5 name="users" size={22} 
                  color={"linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)"}  />
                 
                </TouchableOpacity> 
                
                  <TouchableOpacity
                  style={[(this.state.activeClass == 'UactiveClass' ? styles.UactiveClass : '')]}
                  activeOpacity={0.5}
                  onPress={this.swithScreen.bind(this,'SearchScreen')}>
                  <FontAwesome5 name="search" size={22} color={"linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)"} />
                  
                  </TouchableOpacity> 
                  <TouchableOpacity
                  style={[(this.state.activeClass == 'MactiveClass' ? styles.MactiveClass : '')]}
                  activeOpacity={0.5}
                  onPress={this.swithScreen.bind(this,'MessagesScreen')}>
                   <MaterialCommunityIcons 
                  name={'message-bulleted'}
                  size={24} 
                  color={"linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)"} 
              />
                  </TouchableOpacity>                     
            </View>
  }
};
export default CookieNavigationScreen;

const styles = StyleSheet.create({
  topheadSection:{
   
  },
  ftmenuSection:{
    backgroundColor: AppStyle.appColor,
    paddingLeft: 35,
    paddingRight: 35,
    paddingBottom: 10,
    paddingTop: 10,
    flexDirection:'row',
    justifyContent:'space-between'
  },
  CactiveClass:{
    borderBottomWidth:2,
    paddingBottom: 5,
    borderColor:'linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'
  },
  FactiveClass:{
    borderBottomWidth:2,
    paddingBottom: 5,
    borderColor:'linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'
  },
  MactiveClass:{
    borderBottomWidth:2,
    paddingBottom: 5,
    borderColor:'linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'
  },
  UactiveClass:{
    borderBottomWidth:2,
    paddingBottom: 5,
    borderColor:'linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'
  },
  COactiveClass:{
    borderBottomWidth:2,
    paddingBottom: 5,
    borderColor:'linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'
  }
});