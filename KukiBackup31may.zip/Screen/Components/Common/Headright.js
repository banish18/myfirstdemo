import React, { Component } from 'react';
import AppStyle from '../../Constants/AppStyle.js';
import { useNavigation, NavigationContainer } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';
import {
  View,
  Image,
  Text,
  TouchableOpacity,
} from 'react-native';

const state = {};

class Headright extends Component {
  
   constructor(props: Object) {
    super(props);
}

searchFunction = (text) => {
  const updatedData = this.arrayholder.filter((item) => {
    const item_data = `${item.title.toUpperCase()})`;
    const text_data = text.toUpperCase();
    return item_data.indexOf(text_data) > -1;
  });
   
  this.setState({ data: updatedData, searchValue: text });
};


  render (){
    const { navigation } = this.props;

   
    return (
        
        <View style={styles.container}>
          <View style={styles.iconsRow}>
          <TouchableOpacity
                        style={styles.iconsSec}
                        onPress={() =>   console.log()}>
                         <Image
                    source={require('../../../assets/images/icons/notification.png')}
                    style={{
                  
                      width: 21,
                      resizeMode: 'contain',
                     
                    }}
                  />
                      </TouchableOpacity> 

          </View>
                   
        </View>
                        
        );
  }
}


const styles = {  
  container: {
   
  },
  iconsRow: {
    flexDirection: 'row'
  },
  iconsSec: {
   borderWidth:1,
   borderColor:'#E8E6EA',
    padding: 12,
    borderRadius:15,
    orverflow:'hidden',
    marginRight:10,
    marginTop:20
  },
};
// Wrap and export
export default function(props) {
  const navigation = useNavigation();
  return <Headright {...props} navigation={navigation} />;
}
