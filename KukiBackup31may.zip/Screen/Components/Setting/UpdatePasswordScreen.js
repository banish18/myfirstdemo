// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';
import { NativeEventEmitter } from 'react-native';

import {
  StyleSheet,
  View,
  Text,
  Alert,
  TouchableOpacity,
  Image,
  Switch,
  Pressable,
  TextInput
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';


class UpdatePasswordScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      isSwitchOn:false
    };
  }

  
  goBack(){
    this.props.navigation.goBack();
  }

  goPassword(){
    this.props.navigation.navigate('PasswordScreen');
  }

  logOut(){
    this.props.navigation.navigate('PasswordScreen');
  }

  render (){
        const {isEnabled } = this.state;
        const showCalculation = () => {
            if (this.state.isSwitchOn) {
              // do something
            } else {
              // do something else
            }
          }
          const handleSubmitPress =() => {

          }
        const toggleSwitch = () => setIsEnabled(previousState => !previousState);
     return <View style={styles.mainBody}>
              <View style={styles.backSection}>
                <TouchableOpacity onPress={() => this.goBack()}>
                    <Image
                    source={require('../../../assets/images/icons/Arrow-Left.png')}
                     style={[{
                     resizeMode: 'contain',
                      width:18
                     
                    }]}
                    />
                </TouchableOpacity>
                <View style={styles.topheadSection}>
                  <Text style={styles.headingText}>Update Password</Text>
                </View>

                <View style={styles.mainStection}>
                  <Text style={styles.Lable}>Old Password</Text>
                  <View style={styles.FieldSection}>
                    <TextInput
                      style={styles.inputStyle}
                      value="123456789" //dummy@abc.com
                      placeholderTextColor="#000"
                      autoCapitalize="none"
                      
                      returnKeyType="next"
                      secureTextEntry={true}
                    />

                    <Image
                    source={require('../../../assets/images/icons/closeeye.png')}
                     style={[{
                     resizeMode: 'contain',
                      width:24
                     
                    },styles.imgIcon]}
                    />
                  </View>
                </View>
                <View style={styles.mainStection}>
                  <Text style={styles.Lable}>New Password</Text>
                  <View style={styles.FieldSection}>
                    <TextInput
                      style={styles.inputStyle}
                      value="123456789" //dummy@abc.com
                      placeholderTextColor="#000"
                      autoCapitalize="none"
                      
                      returnKeyType="next"
                      secureTextEntry={true}
                    />

                    <Image
                    source={require('../../../assets/images/icons/closeeye.png')}
                     style={[{
                     resizeMode: 'contain',
                      width:24
                     
                    },styles.imgIcon]}
                    />
                  </View>
                </View>

                <View style={styles.mainStection}>
                  <Text style={styles.Lable}>Confirm Password</Text>
                  <View style={styles.FieldSection}>
                    <TextInput
                      style={styles.inputStyle}
                      value="123456789" //dummy@abc.com
                      placeholderTextColor="#000"
                      autoCapitalize="none"
                      
                      returnKeyType="next"
                      secureTextEntry={true}
                    />

                    <Image
                    source={require('../../../assets/images/icons/closeeye.png')}
                     style={[{
                     resizeMode: 'contain',
                      width:24
                     
                    },styles.imgIcon]}
                    />
                  </View>
                </View>
                
              </View>
              <View style={styles.btnCont}>
                     <TouchableOpacity
                    style={styles.buttonStyle}
                    activeOpacity={0.5}
                    onPress={handleSubmitPress}>
                    <Text style={styles.buttonTextStyle}>UPDATE</Text>
                  </TouchableOpacity>
              </View>
     </View>
            
  }
};
export default UpdatePasswordScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex:1,
    backgroundColor: AppStyle.appColor,
    paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
    paddingBottom: 35,
    paddingTop: 40,
    height:'100%',
    backgroundColor:'#E5E5E5'
  },
  backSection:{
    textAlign:'left',
    justifyContent:'flex-start'
  },
  topheadSection:{
    flexDirection:'row',
     marginTop:35,
  },
  headingText:{
    color: '#FF9228',
    fontSize:24,
    fontWeight:'400',
    fontFamily: 'Abel',
  },
  mainStection:{
    marginTop:20,
  },
  inputStyle:{
    padding:15,
    borderWidth:1,
    borderColor:'#E8E6EA',
    width:'100%',
    borderRadius:15,
    fontFamily: 'Abel',
    backgroundColor:'#fff'
  },
  btnCont:{
    position:'absolute',
    bottom:20,
    width:'100%',

    paddingLeft:30
  },
  buttonStyle: {
   backgroundColor: 'background: linear-gradient(90deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 114.92%)',
    borderWidth: 0,
    color: '#FFFFFF',
    borderColor: '#dadae8',
    alignItems: 'center',
    borderRadius: 15,
    
    paddingTop:22,
    paddingBottom:22,
    
    
     width:'100%'

  },
  buttonTextStyle: {
    color: '#FFFFFF',
    fontSize:16,
    fontSize: AppStyle.buttonFontsize,
    fontFamily: 'Abel'
  },
  Lable:{
    color: '#000',
    fontSize:12,
    fontSize: AppStyle.buttonFontsize,
    fontFamily: 'Abel',
    marginBottom:10
  },
  FieldSection:{
    flexDirection:'row',
    justifyContent:'space-between',
    alignItems:'center'
  },
  imgIcon:{
    position:'absolute',
    right:15
  }

});