// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';
import { NativeEventEmitter } from 'react-native';

import {
  StyleSheet,
  View,
  Text,
  Alert,
  TouchableOpacity,
  Image,
  Switch,
  Pressable,
  ScrollView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';


class SettingScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      isSwitchOn:false
    };
     
  }

  
  goBack(){
    this.props.navigation.goBack();
  }

  goPassword(){
    this.props.navigation.navigate('UpdatePasswordScreen');
  }

  logout(){
    this.props.navigation.navigate('SettingScreen');
  }

  render (){
        const {isEnabled } = this.state;
        const showCalculation = () => {
            if (this.state.isSwitchOn) {
              // do something
            } else {
              // do something else
            }
          }
          const handleSubmitPress =() => {

          }
        const toggleSwitch = () => setIsEnabled(previousState => !previousState);

        let logOutOptins = <View style={styles.logoutOptionMain}>
            <Image
                    source={require('../../../assets/images/icons/devi.png')}
                     style={[{
                     resizeMode: 'contain',
                      width:30
                     
                    },styles.imgIcon]}
                    />
          <Text style={styles.logoutOptionText}>Log out</Text>
          <Text style={styles.logoutOptionTextCont}>Are you sure you want to leave?</Text>
           <TouchableOpacity
                    style={styles.buttonStyle}
                    activeOpacity={0.5}
                    onPress={handleSubmitPress}>
                    <Text style={styles.buttonTextStyle}>Yes</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={styles.cancelbuttonStyle}
                    activeOpacity={0.5}
                    onPress={handleSubmitPress}>
                    <Text style={styles.buttonTextStyle}>Cancel</Text>
                  </TouchableOpacity>
          </View>
        
     return <ScrollView style={{backgroundColor:'#E5E5E5'}}><View style={styles.mainBody}>
              <View style={styles.backSection}>
                <TouchableOpacity onPress={() => this.goBack()}>
                    <Image
                    source={require('../../../assets/images/icons/Arrow-Left.png')}
                     style={[{
                     resizeMode: 'contain',
                      width:18
                     
                    },styles.imgIcon]}
                    />
                </TouchableOpacity>
                <View style={styles.topheadSection}>
                  <Text style={styles.headingText}>Settings</Text>
                </View>

                <Pressable onPress={() => this.goBack()} style={styles.mainStection}>
                  <View style={styles.leftNotiSection}>
                     <Image
                    source={require('../../../assets/images/icons/notification.png')}
                     style={[{
                     resizeMode: 'contain',
                      width:18
                     
                    },styles.imgIcon]}
                    />

                    <Text>Notification</Text>



                    
                  </View>
                  <View style={styles.rightNotiSection}>
                    <Switch 
                      onValueChange={isSwitchOn => this.setState({isSwitchOn})}
                      value={this.state.isSwitchOn} 
                       trackColor={{ false: "#FD6F01", true: "#56CD54" }}
                      thumbColor={isEnabled ? "#f5dd4b" : "#f4f3f4"}
                      ios_backgroundColor="#3e3e3e"
                    />
                  </View>
                </Pressable>

                <Pressable onPress={() => this.goPassword()} style={styles.mainSubStection}>
                  <View style={styles.leftNotiSection}>
                     <Image
                    source={require('../../../assets/images/icons/breif.png')}
                     style={[{
                     resizeMode: 'contain',
                      width:18
                     
                    },styles.imgIcon]}
                    />

                    <Text>Password</Text>



                    
                  </View>
                  <View style={styles.rightNotiSection}>
                    
                    <Image
                    source={require('../../../assets/images/icons/righta.png')}
                     style={[{
                     resizeMode: 'contain',
                      width:18
                     
                    },styles.imgIcon]}
                    />
                  </View>
                </Pressable>

                
                <Pressable onPress={() => this.logout()} style={styles.mainSubStection}>
                  <View style={styles.leftNotiSection}>
                     <Image
                    source={require('../../../assets/images/icons/logout.png')}
                     style={[{
                     resizeMode: 'contain',
                      width:18
                     
                    },styles.imgIcon]}
                    />

                    <Text>Logout</Text>



                    
                  </View>
                  <View style={styles.rightNotiSection}>
                    
                    <Image
                    source={require('../../../assets/images/icons/righta.png')}
                     style={[{
                     resizeMode: 'contain',
                      width:18
                     
                    },styles.imgIcon]}
                    />
                    
                  </View>
                  </Pressable>
                
                
              </View>
              
              <View style={styles.btnCont}>


                     <TouchableOpacity
                    style={styles.buttonStyle}
                    activeOpacity={0.5}
                    onPress={handleSubmitPress}>
                    <Text style={styles.buttonTextStyle}>SAVE</Text>
                  </TouchableOpacity>
              </View>
     </View>
     </ScrollView>
            
  }
};
export default SettingScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex:1,
    backgroundColor: AppStyle.appColor,
    paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
    paddingBottom: 35,
    paddingTop: 40,
    height:'100%',
    backgroundColor:'#E5E5E5'
  },
  topheadSection:{
    flexDirection:'row',
     marginTop:35,
  },
  headingText:{
    color: '#FF9228',
    fontSize:24,
    fontWeight:'400',
    fontFamily: 'Abel',
  },
  mainStection:{
    flexDirection:'row',
    paddingLeft:15,
    paddingRight:15,
    paddingTop:10,
    paddingBottom:10,
    borderWidth:1,
    borderRadius:10,
    borderColor:'#fff',
    marginTop:20,
    backgroundColor:'#fff'
  },
  mainSubStection:{
    flexDirection:'row',
    paddingLeft:15,
    paddingRight:15,
    paddingTop:22,
    paddingBottom:22,
    borderWidth:1,
    borderRadius:10,
    borderColor:'#fff',
    marginTop:20,
    backgroundColor:'#fff'
  },
  leftNotiSection:{
    flexDirection:'row',
    justifyContent:'space-between',
    width:'35%',
    alignItems:'center'
  },
  rightNotiSection:{
    flexDirection:'row',
    justifyContent:'flex-end',
    width:'65%',
    alignItems:'center'
  },
  btnCont:{
    
    marginTop:40,
    width:'100%',

   
  },
  buttonStyle: {
   backgroundColor: 'background: linear-gradient(90deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 114.92%)',
    borderWidth: 0,
    color: '#FFFFFF',
    borderColor: '#dadae8',
    alignItems: 'center',
    borderRadius: 15,
    
    paddingTop:22,
    paddingBottom:22,
    
    
     width:'100%'

  },
  cancelbuttonStyle:{
  backgroundColor: ' rgba(253, 139, 48, 0.31)',
    borderWidth: 0,
    color: '#000000',
    borderColor: '#dadae8',
    alignItems: 'center',
    borderRadius: 15,
    
    paddingTop:22,
    paddingBottom:22,
    
    
     width:'100%'

  },
  buttonTextStyle: {
    color: '#FFFFFF',
    fontSize:16,
    fontSize: AppStyle.buttonFontsize,
    fontFamily: 'Abel'
  },
  logoutOptionMain:{
    alignItems:'center',
    marginTop:10
  },
  logoutOptionText:{
    color: '#000000',
    fontSize:16,
    fontWeight:'700',
    fontFamily: 'Abel',
    marginTop:40
  },
  logoutOptionTextCont:{
    color: '#FD6F01',
    fontSize:12,
    fontWeight:'400',
    fontFamily: 'Abel',
    marginTop:10
  }

});