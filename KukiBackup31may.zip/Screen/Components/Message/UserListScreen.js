// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';
import { NativeEventEmitter } from 'react-native';

import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  Pressable,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Loader from '../../Components/Loader';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';
//import QB from 'quickblox-react-native-sdk';

class UserListScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      RedeemedCokie:'100',
      Cookie:'100',
      QBD:QB
    };
  }

  
  

  render (){
    
    const appSettings = {
      appId: '96738',
      authKey: 'pSb4NsHCam2MOOG',
      authSecret: 'DWQywFpAZfcJU96',
      accountKey: 'u1TH93-SfnzJUbzyQgBq',
      apiEndpoint: '', // optional
      chatEndpoint: '' // optional
    };

  /*  this.state.QBD.settings
    .init(appSettings)
    .then(function () {
      // SDK initialized successfully
    })
    .catch(function (e) {
      // Some error occured, look at the exception message for more details
    });*/
    

  }
};
export default UserListScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex:1,
    backgroundColor: AppStyle.appColor,
    paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
    paddingBottom: 35,
    paddingTop: 40,
    height:'100%'
  },
  topheadSection:{
    display:'flex',
    justifyContent:'space-between',
    alignItems:'center',
    flexDirection:'row',
    marginBottom:15
  },
  mainStection:{
    width:'100%',
    marginTop:15,
    justifyContent:'center', 
  }

});