// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';
import { StyleSheet, Button, Text, View, TouchableOpacity, ScrollView, Image, ActivityIndicator, TextInput, Alert } from 'react-native';
import AppStyle from '../../Constants/AppStyle.js';
import { useNavigation, NavigationContainer } from '@react-navigation/native';

class Otpscreen extends Component {

  constructor(props) {
    super(props);
    this.state = {
      one: '',
      two: '',
      three: '',
      oneFocus: false,
      twoFocus: false,
      threeFocus: false,
      fourFocus: false,
      second:0
    };

    this.onStart()
  }

  componentDidMount() {
    this.refs.one.focus();
  }

    handleChangeTextOne = (text) => {
      this.setState({ one: text }, () => { if (this.state.one) this.refs.two.focus(); });
    }
  handleChangeTextTwo = (text) => {
    this.setState({ two: text }, () => { if (this.state.two) this.refs.three.focus(); });
  }
  handleChangeTextThree = (text) => {
    this.setState({ three: text }, () => { if (this.state.three) this.refs.four.focus(); });
  }
  handleChangeTextFour = (text) => {
    this.setState({ four: text });
  }


    backspace = (id) => {
      if (id === 'two') {
        if (this.state.two) { this.setState({ two: '' }); } else if (this.state.one) { this.setState({ one: '' }); this.refs.one.focus(); }
      } else if (id === 'three') {
        if (this.state.three) { this.setState({ three: '' }); } else if (this.state.two) { this.setState({ two: '' }); this.refs.two.focus(); }
      }
      else if (id === 'four') {
        if (this.state.four) { this.setState({ four: '' }); } else if (this.state.three) { this.setState({ three: '' }); this.refs.three.focus(); }
      }
    }
	onStart = () => {
     this._interval = setInterval(() => {
      this.setState({
        second: this.state.second + 1,
     })
      if(this.state.second == 60){
        this.state.second = 0;
        clearInterval(this._interval);
      }
  }, 1000);
}

handleSendagainPress = () => {
 //alert('Otp sent again!');
 this.props.navigation.navigate('UserdetailScreen');
  //navigation.navigate('Otpscreen');
}
	
    render() {
const { oneFocus, twoFocus, threeFocus,fourFocus } = this.state;
      
        return <View style={styles.container}>

        <View style={styles.headSection}>
          <Text style={styles.timerHeadText}>0:{this.state.second}</Text>
          <Text style={styles.timerText}>Type the varification code</Text>
          <Text style={styles.timerText}>We've sent you</Text>
          </View>
          <View style={styles.inputcontainer}>
            <TextInput
              ref='one'
              autoFocus
              style={[styles.textInput, (oneFocus == true ? styles.seltedtextInput : null)]}
              autoCorrect={false}
              autoCapitalize='none'
              keyboardType='number-pad'
              caretHidden
             
              onFocus={() => this.setState({ oneFocus: true })}
              onBlur={() => this.setState({ oneFocus: false })}
              maxLength={1}
              onChangeText={(text) => { this.handleChangeTextOne(text); }}
              value={this.state.one}
            />
            <TextInput
              ref='two'
              onKeyPress={({ nativeEvent }) => (
                nativeEvent.key === 'Backspace' ? this.backspace('two') : null
              )}
              style={[styles.textInput, (twoFocus == true ? styles.seltedtextInput : null)]}
              autoCorrect={false}
              autoCapitalize='none'
              maxLength={1}
              onFocus={() => this.setState({ twoFocus: true })}
              onBlur={() => this.setState({ twoFocus: false })}
              caretHidden
              keyboardType='number-pad'
              onChangeText={(text) => { this.handleChangeTextTwo(text); }}
              value={this.state.two}
            />
            <TextInput
              ref='three'
              onKeyPress={({ nativeEvent }) => (
                nativeEvent.key === 'Backspace' ? this.backspace('three') : null
              )}
              style={[styles.textInput, (threeFocus == true ? styles.seltedtextInput : null)]}
              autoCorrect={false}
              autoCapitalize='none'
              onFocus={() => this.setState({ threeFocus: true })}
              onBlur={() => this.setState({ threeFocus: false })}
              maxLength={1}
              caretHidden
              keyboardType='number-pad'
              onChangeText={(text) => { this.handleChangeTextThree(text); }}
              value={this.state.three}
            />
             <TextInput
              ref='four'
              onKeyPress={({ nativeEvent }) => (
                nativeEvent.key === 'Backspace' ? this.backspace('four') : null
              )}
              style={[styles.textInput, (fourFocus == true ? styles.seltedtextInput : null)]}
              autoCorrect={false}
              autoCapitalize='none'
              onFocus={() => this.setState({ fourFocus: true })}
              onBlur={() => this.setState({ fourFocus: false })}
              maxLength={1}
              caretHidden
              keyboardType='number-pad'
              onChangeText={(text) => { this.handleChangeTextFour(text); }}
              value={this.state.four}
            />
            
          </View>
           <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity={0.5}
              onPress={({ nativeEvent }) => (
                nativeEvent.key === 'Backspace' ? this.handleSendagainPress() : this.handleSendagainPress()
              )}
              >
              <Text style={styles.buttonTextStyle}>Send Again</Text>
            </TouchableOpacity>
            </View>

      }
       
      
      onClose = () => {
        // maybe navigate to other screen here?
      }
};


export default Otpscreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
     paddingBottom: AppStyle.appBottomPadding,
     paddingTop: AppStyle.appTopPadding,
  },
  timerText:{
    fontSize:18,
    fontFamily: 'Abel'
  },
  timerHeadText:{
    fontSize:34,
    fontFamily: 'Abel'
  },
    buttonStyle: AppStyle.AppbuttonStyle,
  
  
  headSection:{
    paddingVertical:50,
    alignItems: 'center'
  },
  buttonTextStyle: {
    color: '#FFFFFF',
    
    fontSize: 16,
  },
  inputcontainer: {
    
    flexDirection: 'row',
    justifyContent:'center',
    alignItems: 'center',
    paddingBottom:15
  }, 
  textInput: {
    borderColor:  'linear-gradient(180deg, #FD6F01 0%, rgba(253, 111, 1, 0.39) 100%)',
        borderWidth: 1,
        width:65,
        marginRight:5,
        height:65,
        color:'#000',
        borderRadius:15,
        fontSize:34,
        textAlign:'center',
        fontFamily: 'Abel'
  },
  seltedtextInput: {
    backgroundColor:'linear-gradient(180deg, #FD6F01 0%, rgba(253, 111, 1, 0.39) 100%)'
  }
});