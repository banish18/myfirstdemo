// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';
import {Picker} from '@react-native-picker/picker';

import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Pressable,
  Alert,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CountryPicker from "react-native-country-codes-picker";
import { useNavigation, NavigationContainer } from '@react-navigation/native';


class CommunityPostScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
  
    selectedCommunityValue:'',
    selectedStateValue:'',
    selectedCityValue:''
    };

    }
   createAlert = (FirstName) =>
    Alert.alert(
      "Required",
      FirstName,
      [
       
        { text: "OK", onPress: () => console.log("OK Pressed") }
      ]
    );


  setSelectedValue(itmVal,type){
   if(type == 'community'){
      this.setState({selectedCommunityValue: itmVal });
    }else if(type == 'State'){
      this.setState({selectedStateValue: itmVal });
    }else if(type == 'city'){
      this.setState({selectedCityValue: itmVal });
    }
  }

  savePost(){
    
    this.props.navigation.navigate('CommunityPostsListScreen');
  }

  addHashtag(){

  }

  backScreen(){
    this.props.navigation.navigate('CommunityBoardScreen');
  }

  render (){

    const {selectedCommunityValue,selectedStateValue,selectedCityValue } = this.state;

      const setTopic = (val) => {

  };

   const setDescription = (val) => {
    
  };
     const handleSubmitPress = () => {
    
    if(!this.state.selectedAgeValue){
      this.createAlert('Please Select Your Age');
      
      return;
    }else if(!this.state.selectedStateValue){
      this.createAlert('Please Select Your State');
      
      return;
    }else if(!this.state.selectedCityValue){
      this.createAlert('Please Select Your City');
      
      return;
    }
this.props.navigation.navigate('CommunityPostScreen');
  };
    return <View style={styles.mainBody}>
          <View style={styles.topHeadsection}>
            <View>
              <Pressable
                onPress={() => {
                  this.backScreen();
                }}
                style={({ pressed }) => [
                  {
                    color: pressed
                      ? 'rgb(210, 230, 255)'
                      : 'white'
                  },
                  styles.wrapperCustom
                ]}><Image
                source={require('../../../assets/images/icons/Arrow-Left.png')}
                 style={[{
                 resizeMode: 'contain',
                  width:18
                 
                },styles.imgIcon]}
              />
              </Pressable>
            </View>
            <View>
              <Pressable
                onPress={() => {
                  this.savePost();
                }}
                style={({ pressed }) => [
                  {
                    color: pressed
                      ? 'rgb(210, 230, 255)'
                      : 'white'
                  },
                  styles.wrapperCustom
                ]}>
            <Text style={styles.topheadHeading}>Post</Text>
          </Pressable>
            </View>
          </View>

          <View style={styles.mainContentsection}>
            <Text style={styles.innerHeading}>discussion</Text>

            <View style={styles.innserSecBio}>
              <Image
                  source={require('../../../assets/images/photodummy.png')}
                   style={[{
                   resizeMode: 'contain',
                    width:58
                   
                  },styles.imgIcon]}
                />
                <View style={styles.userSecBio}>
                <Text style={styles.userheadSecBio}>Orlando Diggs</Text>
                <Text style={styles.usercontSecBio}>California, USA</Text>
                </View>
                
            </View>

            <View style={styles.innerFormSec}>
                <Text style={styles.userinnercontSecBio}>Topic</Text>
                <TextInput
                style={styles.inputStyle}
                onChangeText={(Topic) =>
                  setUserPhone(UserEmail)
                }
                placeholder="Write the title of your post here" 
                placeholderTextColor="#ADAFBB"
                autoCapitalize="none"
              />
              </View>
              <View style={styles.innerFormSec}>
              <Text style={styles.userinnercontSecBio}>Description</Text>
                <TextInput
                style={styles.inputDescStyle}
                onChangeText={(Description) =>
                  setDescription(Description)
                }
                placeholder="Write or paste a url here...." //dummy@abc.com
                placeholderTextColor="#ADAFBB"
                autoCapitalize="none"
                returnKeyType="next"
                onSubmitEditing={() =>
                  passwordInputRef.current &&
                  passwordInputRef.current.focus()
                }
                blurOnSubmit={true}
              />
            </View>

            <View style={styles.mediaSection}>
            <View style={styles.leftMediaSection}>
               <TouchableOpacity
                                           style={styles.imgIconsectionInner}
                                            activeOpacity={0.5}
                                            onPress={this.addHashtag.bind(this,'x')}><Image
                  source={require('../../../assets/images/icons/Icon-Camera.png')}
                   style={[{
                   resizeMode: 'contain',
                    width:18
                   
                  },styles.imgIcon]}
                />
                </TouchableOpacity>
                <TouchableOpacity
                                           style={styles.imgIconsectionInner}
                                            activeOpacity={0.5}
                                            onPress={this.addHashtag.bind(this,'x')}>
                                            <Image
                  source={require('../../../assets/images/icons/icon-picture.png')}
                   style={[{
                   resizeMode: 'contain',
                    width:18
                   
                  },styles.imgIcon]}
                />
                </TouchableOpacity>
                <TouchableOpacity
                                           style={styles.imgIconsectionInner}
                                            activeOpacity={0.5}
                                            onPress={this.addHashtag.bind(this,'x')}>
                <Image
                  source={require('../../../assets/images/icons/attachment.png')}
                   style={[{
                   resizeMode: 'contain',
                    width:18
                   
                  },styles.imgIcon]}
                />
                 </TouchableOpacity>
                </View>
                 <View style={styles.rightMediaSection}>

                 <TouchableOpacity
                                           style={styles.imgIconsectionInner}
                                            activeOpacity={0.5}
                                            onPress={this.addHashtag.bind(this,'x')}>

                           
                                                 <Text style={styles.hashTagsec}>Add hashtag</Text>
                         
                     
                      </TouchableOpacity>
                       </View>
            </View>
          </View>
        </View>
      
  }
};
export default CommunityPostScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex: 1,
    backgroundColor: AppStyle.appColor,
     paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
     paddingBottom: 40,
     paddingTop: 55,
     backgroundColor:'#fff',
     height:'100%'
  },
  topHeadsection:{
    flexDirection:'row',
    justifyContent:'space-between'
  },
  topheadHeading:{
    color: '#FF9228',
    fontSize:17,
    fontWeight:'700',
    fontFamily: 'Abel',
  },
  mainContentsection:{
    marginTop:15
  },
  innerHeading:{
    color: '#FF9228',
    fontSize:24,
    fontWeight:'400',
    fontFamily: 'Abel',
  },
  innserSecBio:{
    flexDirection:'row',
    alignItems:'center',
    marginTop:20
  },
  userSecBio:{
    marginLeft:10,
    
  },
  userheadSecBio:{
     color: '#000000',
    fontSize:14,
    fontWeight:'400',
    fontFamily: 'Abel',
  },
  usercontSecBio:{
     color: '#524B6B',
    fontSize:12,
    fontWeight:'400',
    fontFamily: 'Abel',
  },
  userinnercontSecBio:{
    color: '#524B6B',
    fontSize:12,
    fontWeight:'400',
    fontFamily: 'Abel',
    marginBottom:5
  },
  innerFormSec:{
    backgroundColor:'#fff',
    marginTop:15
  },
  inputStyle: {
    borderWidth:1,
    borderColor:'#E8E6EA',
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
    width:'100%',
    paddingTop: 15,
    paddingBottom: 15,
    paddingRight: 15,
    fontSize:AppStyle.inputFontsize,
    borderRadius:15,
    fontFamily: 'Abel'
  },
  inputDescStyle:{
    borderWidth:1,
    borderColor:'#E8E6EA',
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
    width:'100%',
    paddingTop: 45,
    paddingBottom: 45,
    paddingRight: 15,
    fontSize:AppStyle.inputFontsize,
    borderRadius:15,
    fontFamily: 'Abel'
  },
  mediaSection:{
    flexDirection:'row',
    marginTop:15
  },
  hashTagsec:{
    color: '#FF9228',
    fontSize:12,
    fontWeight:'400',
    fontFamily: 'Abel',
  },
  leftMediaSection:{
    flexDirection:'row',
    width:'50%',
    justifyContent:'space-around'
  },
  rightMediaSection:{
    flexDirection:'row',
    width:'50%',
    justifyContent:'flex-end',
    paddingRight:15
  }
});