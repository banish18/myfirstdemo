// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';
import {Picker} from '@react-native-picker/picker';

import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CountryPicker from "react-native-country-codes-picker";
import { useNavigation, NavigationContainer } from '@react-navigation/native';


class CommunityBoardScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
  
    selectedCommunityValue:'',
    selectedStateValue:'',
    selectedCityValue:''
    };

    }
   createAlert = (FirstName) =>
    Alert.alert(
      "Required",
      FirstName,
      [
       
        { text: "OK", onPress: () => console.log("OK Pressed") }
      ]
    );


  setSelectedValue(itmVal,type){
   if(type == 'community'){
      this.setState({selectedCommunityValue: itmVal });
    }else if(type == 'State'){
      this.setState({selectedStateValue: itmVal });
    }else if(type == 'city'){
      this.setState({selectedCityValue: itmVal });
    }
  }



  render (){

    const {selectedCommunityValue,selectedStateValue,selectedCityValue } = this.state;

     const handleSubmitPress = () => {
    
    if(!this.state.selectedCommunityValue){
      this.createAlert('Please Select Your Community');
      
      return;
    }else if(!this.state.selectedStateValue){
      this.createAlert('Please Select Your State');
      
      return;
    }else if(!this.state.selectedCityValue){
      this.createAlert('Please Select Your City');
      
      return;
    }
this.props.navigation.navigate('CommunityPostScreen');
  };
    return <View style={styles.mainBody}>
          
            
            <View style={styles.SectionHeadStyle}>
              <Text style={styles.SectionHedText}>Community Board</Text>
             
            
            </View>
             <Text style={styles.SectionOntgText}>Select a community in a city or suggest a community.
To suggest a community a simple email
 can be sent to admin.
</Text>
            
            <View style={styles.mainStection}>
            
              
               <View style={styles.selectboxContainer}>
            

              <Picker
        selectedValue={selectedCommunityValue}
        style={styles.selectStyle}
        onValueChange={(itemValue, itemIndex) => this.setSelectedValue(itemValue,'community')}
      >
        
        <Picker.Item label="Business and Entrepreneurship" value="Business and Entrepreneurship" />
        <Picker.Item label="Business and Entrepreneurship" value="Business and Entrepreneurship" />
        <Picker.Item label="Business and Entrepreneurship" value="Business and Entrepreneurship" />
      </Picker>
      <Text style={styles.SectionLabel}>Select Community</Text>
              </View>
                 <View style={styles.selectboxContainer}>
            

              <Picker
        selectedValue={selectedStateValue}
        style={styles.selectStyle}
        onValueChange={(itemValue, itemIndex) => this.setSelectedValue(itemValue,'State')}
      >
        <Picker.Item label="Plese select your state" value="" />
        <Picker.Item label="Punjab" value="Punjab" />
        <Picker.Item label="Himachal" value="Himachal" />
        <Picker.Item label="Haryana" value="Haryana" />
      </Picker>
      <Text style={styles.SectionVSmallLabel}>State</Text>
              </View>
                 <View style={styles.selectboxContainer}>
            

              <Picker
        selectedValue={selectedCityValue}
        style={styles.selectStyle}
        onValueChange={(itemValue, itemIndex) => this.setSelectedValue(itemValue,'city')}
      >
        <Picker.Item label="Plese select your city" value="" />
        <Picker.Item label="Shimla" value="Shimla" />
        <Picker.Item label="Karnal" value="Karnal" />
        <Picker.Item label="Mohali" value="Mohali" />
      </Picker>
      <Text style={styles.SectionVSmallLabel}>City</Text>
              </View>


              </View>
            <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity={0.5}
              onPress={handleSubmitPress}>
              <Text style={styles.buttonTextStyle}>Go</Text>
            </TouchableOpacity>
          
        </View>
      
  }
};
export default CommunityBoardScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: AppStyle.appColor,
    alignContent: 'center',
     paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
     paddingBottom: 40,
     paddingTop: 15,
     backgroundColor:'#fff',
     height:'100%'
  },
  SectionHeadStyle: {
    flexDirection: 'row',
    paddingBottom: 14,
   
   
    
  },
  inputboxContainer:{
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
    borderColor:'#E8E6EA',
    borderWidth:1,
    borderRadius:16,
    height:58,
    marginBottom:22,
  },
  selectboxContainer:{
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
   fontFamily: 'Abel',
    borderWidth:1,
    borderColor:'#E8E6EA',
    borderRadius:16,
    height:58,
    marginBottom:22
  },
  SectionLabel:{
    position: 'absolute', top: -10, left: 20, right: 0, bottom: 0,
    backgroundColor:'#fff',
    paddingLeft:10,
    paddingRight:10,
    width:130,
    height:25,
    textAlign:'center',
    fontFamily: 'Abel',
    color:'rgba(0, 0, 0, 0.4)',
  },
  SectionSmallLabel:{
    position: 'absolute', top: -10, left: 20, right: 0, bottom: 0,
    backgroundColor:'#fff',
    alignSelf: 'flex-start',
    paddingLeft:10,
    paddingRight:10,
    width:70,
    height:25,
    textAlign:'center',
    color:'rgba(0, 0, 0, 0.4)',
    fontFamily: 'Abel'
  },
  SectionVSmallLabel:{
    position: 'absolute', top: -10, left: 20, right: 0, bottom: 0,
    backgroundColor:'#fff',
    alignSelf: 'flex-start',
    paddingLeft:10,
    paddingRight:10,
    width:55,
    height:25,
    textAlign:'center',
    fontFamily: 'Abel',
    color:'rgba(0, 0, 0, 0.4)',
  },
  SectionHedText:{
    fontSize:AppStyle.headingFontMediumsize,
    fontWeight:AppStyle.headingFontweight,
    fontFamily: 'Abel'
  },
  SectionOntgText:{
    fontSize: 14,
    position:'relative',
    zIndex: 1, // works on io,
    fontFamily: 'Abel',
    paddingBottom: 34,
  },
  buttonStyle: AppStyle.AppbuttonStyle,
  buttonTextStyle: {
    color: '#FFFFFF',
    fontSize:16,
    fontSize: AppStyle.buttonFontsize,
    fontFamily: 'Abel'
  },
  inputStyle: {
    height:58,
    color: AppStyle.inputBlackcolorText,
    fontSize: 16,
    position:'relative',
    zIndex: 1, // works on io,
    fontFamily: 'Abel'

  },
  selectStyle: {
     height:58,
     width:158,
    color: AppStyle.inputBlackcolorText,
    fontWeight: 'bold',
    fontSize: 14,
    width:'100%',
    fontFamily: 'Abel'
  },

  errorTextStyle: {
    color: 'red',
    textAlign: 'center',
    fontSize: 14,
  },
});