// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';
import {Picker} from '@react-native-picker/picker';

import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import MultiSelect from 'react-native-multiple-select';

import Loader from '../../Components/Loader';

const pesodata=[  
                        {key: 'Artist',icon:require('../../../assets/images/icons/camera.png'),isSelect:false,selectedClass:'flatMainsection'},{key: 'Creative',icon:require('../../../assets/images/icons/weixin-market.png'),isSelect:false,selectedClass:'flatMainsection'}, {key: 'Simple',icon:require('../../../assets/images/icons/voice.png'),isSelect:false,selectedClass:'flatMainsection'},{key: 'Foodie',icon:require('../../../assets/images/icons/viencharts.png'),isSelect:false,selectedClass:'flatMainsection'},  
                        {key: 'Cooking Freak',icon:require('../../../assets/images/icons/noodles.png'),selectedClass:'flatMainsection'},{key: 'Day dreamer',icon:require('../../../assets/images/icons/tennis.png'),selectedClass:'flatMainsection'},{key: 'Fitness Freak',icon:require('../../../assets/images/icons/sport.png'),selectedClass:'flatMainsection'},  
                        {key: 'Swimming',icon:require('../../../assets/images/icons/ripple.png'),selectedClass:'flatMainsection'},{key: 'Art',icon:require('../../../assets/images/icons/Art.png'),selectedClass:'flatMainsection'}, {key: 'Traveling',icon:require('../../../assets/images/icons/outdoor.png'),selectedClass:'flatMainsection'},  
                        {key: 'Extreme',icon:require('../../../assets/images/icons/parachute.png'),selectedClass:'flatMainsection'},{key: 'Music',icon:require('../../../assets/images/icons/music.png'),selectedClass:'flatMainsection'},{key: 'Drink',icon:require('../../../assets/images/icons/goblet-full.png'),selectedClass:'flatMainsection'},  
                        {key: 'Video games',icon:require('../../../assets/images/icons/game-handle.png'),selectedClass:'flatMainsection'} 
                    ];  

class PersonalityTraits extends Component {

 constructor(props) {
    super(props);
    this.state = {
     
    selectedCommValue:'Business and Entrepreneurship',
   selectedItems : [],
   selectedLetter:[],
    dataSource: pesodata
    };

  
  }

   createAlert = (FirstName) =>
    Alert.alert(
      "Required",
      FirstName,
      [
       
        { text: "OK", onPress: () => console.log("OK Pressed") }
      ]
    );

onSelectedItemsChange = selectedItems => {
  if ( selectedItems.length <= 3 ) {
            this.setState({ selectedItems });
        }else{
          this.createAlert('You can Select Your Max 3 Communities');
        }

    
  };

   getListViewItem = (item) => {  
        /*Alert.alert(item.key);*/

        item.isSelect = !item.isSelect;
         item.selectedClass = item.isSelect?
            styles.selecttedFlatitem: styles.flatMainsection;
        
      
       this.setState({
         dataSource: this.state.dataSource
       });

console.log('Hello');
console.log(this.state.dataSource);
        this.setState({selectedLetter: item.key });  
    }  



checkIndexIsEven (n) {
    return n % 2 == 0;
}
backScreen(){
  
  this.props.navigation.navigate('CommunitiesScreen');
}
nextScreen(){
  
  this.props.navigation.navigate('UserstatusScreen');
}
  render (){

    const { selectedItems,selectedLetter} = this.state;

     const handleSubmitPress = () => {
   if(!this.state.selectedItems){
      this.createAlert('Please Select Your Community');
      
      return;
    }
this.props.navigation.navigate('UserstatusScreen');
  };
    return <ScrollView >
          <View style={styles.mainBody}>
            <View style={styles.topheadSection}>

<TouchableOpacity onPress={() => this.backScreen()}>
<View style={styles.backIconsCont}>
 <Image
                source={require('../../../assets/images/back-icon.png')}
                style={{
                 resizeMode: 'contain',
                  height:16
                }}
 

              />
              </View>
               </TouchableOpacity>
              
              <TouchableOpacity onPress={() => this.nextScreen()}>
                    <Text style={styles.skipSection} >Skip</Text>

            </TouchableOpacity>
            </View>
            <View style={styles.SectionHeadStyle}>
              <Text style={styles.SectionHedText}>Personality Traits</Text>
            
            </View>
             <View style={styles.ContentHeadStyle}>
              <Text style={styles.SectionContText}>Choose 5 (Min and Max) personality traits</Text>
            
            </View>
             
            <View style={styles.mainStection}>
        
               
              <FlatList  
                    data={this.state.dataSource}
                    numColumns={2}
                    
                    renderItem={({item, index, separators }) =>  
                        <TouchableOpacity
      style={[item.selectedClass == 'flatMainsection' ? styles.flatMainsection : item.selectedClass,{marginBottom:10,marginRight:this.checkIndexIsEven(index) ? 10 : 5}]}
      onPress={() => this.getListViewItem(item)}
      >
      
                         <Image
                source={item.icon}
                style={{
                 resizeMode: 'contain',
                  height:16,
                 
                }}
              />
             
              <Text style={styles.flatItems}  
                              >{item.key}</Text></TouchableOpacity>}  
                    ItemSeparatorComponent={this.renderSeparator}  
                />  
               


              </View>

              <View style={styles.btnCont}>
               <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity={0.5}
              onPress={handleSubmitPress}>
              <Text style={styles.buttonTextStyle}>Next</Text>
            </TouchableOpacity>
              </View>
          
          </View>
           
        </ScrollView>
      
  }
};
export default PersonalityTraits;

const styles = StyleSheet.create({
  mainBody: {
   flex:1,
    justifyContent: 'center',
    backgroundColor: AppStyle.appColor,
    
     paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
     paddingBottom: 35,
     paddingTop: 55,
  
  },
  ContentHeadStyle:{
    marginBottom:20
  },
  skipSection:{
    color:'#FD6F01',
    fontSize:16
  },
  topheadSection:{
    
    display:'flex',
    justifyContent:'space-between',
  alignItems:'center',
    flexDirection:'row',
    marginBottom:15
  },
  backIconsCont:{
     borderWidth:1,
                  borderColor:'#E8E6EA',
                  borderRadius:15,
                  paddingTop:15,
                  paddingBottom:15,
                  paddingLeft:20,
                  paddingRight:20
  },
  SectionHeadStyle: {
    flexDirection: 'row',
    paddingBottom: 10,

  },
  mainStection:{
    paddingTop: 25,
    width:'100%',
   
   
  },
flatMainsection:{
   width:'48%',
    flexDirection:'row',
    paddingLeft:10,
    paddingRight:10,
    height:45,
    borderWidth:1,
    borderColor:'#E8E6EA',
    borderRadius:15,
    alignItems:'center',
    display:'flex'
},

  selecttedFlatitem:{
    backgroundColor:'linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)',
     width:'48%',
    flexDirection:'row',
    paddingLeft:10,
    paddingRight:10,
    height:45,
 
    borderRadius:15,
    alignItems:'center',
    display:'flex'
  },
  flatItems:{
   paddingLeft:10
  },
  SectionContText:{
    fontSize:20,
    fontFamily: 'Abel'
  },
  SectionHedText:{
    fontSize:AppStyle.headingFontsize,
    fontWeight:AppStyle.headingFontweight,
    fontFamily: 'Abel'
  },
  btnCont:{
   
    width:'100%'
  },
  buttonStyle: AppStyle.AppbuttonStyle,
  buttonTextStyle: {
    color: '#FFFFFF',
    fontSize:16,
    fontSize: AppStyle.buttonFontsize,
    fontFamily: 'Abel'
  },

  errorTextStyle: {
    color: 'red',
    textAlign: 'center',
    fontSize: 14,
  },
});