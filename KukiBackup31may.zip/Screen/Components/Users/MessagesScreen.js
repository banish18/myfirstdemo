// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';


import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Loader from '../../Components/Loader';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';

class MessagesScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      checked:'male'
    };
    AsyncStorage.setItem('activeClass', 'MactiveClass');
  
  }

 createAlert = (FirstName) =>
  Alert.alert(
    "Required",
    FirstName,
    [
     
      { text: "OK", onPress: () => console.log("OK Pressed") }
    ]
  );
  backScreen(){
    
    this.props.navigation.navigate('UserstatusScreen');
  }
  nextScreen(){
    
    this.props.navigation.navigate('UserstatusScreen');
  }

  

  render (){

    const { checked} = this.state;


    return <View style={{ flex: 1 }}><View style={styles.mainBody}>
            <View style={styles.topheadSection}>
              <Text style="styles.SectionHeadStyle">Message Records</Text>
              </View>
          </View>
          <CookieNavigationScreen navigation={this.props.navigation}/>
          </View>
           
        
      
  }
};
export default MessagesScreen;

const styles = StyleSheet.create({
  mainBody: {
   flex:1,
    
    backgroundColor: AppStyle.appColor,
     paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
     paddingBottom: 35,
     paddingTop: 40,
     height:'100%'
  
  },
  topheadSection:{
    
    display:'flex',
    justifyContent:'space-between',
    alignItems:'center',
    flexDirection:'row',
    marginBottom:15
  },
  mainStection:{
    paddingTop: 25,
    width:'100%',
  },
  SectionHeadStyle: {
    fontSize:34,
    fontFamily: 'Abel',
    marginBottom:35
  }
});