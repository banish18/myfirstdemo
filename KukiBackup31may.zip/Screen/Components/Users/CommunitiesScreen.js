// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';
import {Picker} from '@react-native-picker/picker';

import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import MultiSelect from 'react-native-multiple-select';
import Icon from 'react-native-vector-icons/MaterialIcons';
import SectionedMultiSelect from 'react-native-sectioned-multi-select';
import Loader from '../../Components/Loader';


const items = [
  // this is the parent or 'item'
  {
    name: 'Property and Construction',
    id: 0,
    // these are the children or 'sub items'
    children: [
      {
        name: 'Architects and Designers',
        id: 10,
      },
      {
        name: 'Builders and Contractors',
        id: 11,
      },
      {
        name: 'Home Makers and Decorators',
        id: 12,
      },
      {
        name: 'Renting and Leasing',
        id: 13,
      },
      {
        name: 'Electrician, Carpenter, Painter, Plumber',
        id: 14,
      },
      {
        name: 'Agents and Consultants',
        id: 15,
      },
    ],
  },
  {
    name: 'Health and Fitness',
    id: 1,
    // these are the children or 'sub items'
    children: [
      {
        name: 'Yoga and Meditation',
        id: 16,
      },
      {
        name: 'Indoor Sports and Recreation',
        id: 17,
      },
      {
        name: 'Outdoor Sports and Recreation',
        id: 18,
      },
      {
        name: 'Dieting and Weight Loss',
        id: 19,
      },
      {
        name: 'Nutrition and Supplements',
        id: 20,
      },
      {
        name: 'Beauty and Wellness',
        id: 21,
      },
      {
        name: 'Senior Citizens Recreation',
        id: 22,
      },
      {
        name: 'Exercising and Gyming',
        id: 23,
      },
    ],
   
  },
  {
    name: 'Arts and Culture',
    id: 2,
    // these are the children or 'sub items'
    children: [
      {
        name: 'Book Authors and Reviewers',
        id: 24,
      },
      {
        name: 'Film Critics and Reviewers',
        id: 25,
      },
      {
        name: 'Creative and Visual Arts',
        id: 26,
      },
      {
        name: 'Performing Arts',
        id: 27,
      },
      {
        name: 'Film and Photography',
        id: 28,
      },
      {
        name: 'Literature and Poetry',
        id: 29,
      },
      {
        name: 'Art Fairs and Festivals',
        id: 30,
      },
      {
        name: 'Singing and Music',
        id: 31,
      },
      {
        name: 'Artisan and Handicraft',
        id: 32,
      },
    ],
   
  },
  {
    name: 'Business and Services',
    id: 3,
    // these are the children or 'sub items'
    children: [
      {
        name: 'Banking Services',
        id: 33,
      },
      {
        name: 'Insurance Services',
        id: 34,
      },
      {
        name: 'Finance Services',
        id: 35,
      },
      {
        name: 'Legal Services',
        id: 36,
      },
      {
        name: 'Business Mentoring',
        id: 37,
      },
      {
        name: 'Manufacturing and Trading',
        id: 38,
      },
      {
        name: 'Buying and Reselling',
        id: 39,
      },
      {
        name: 'Supply Chain and Logistics ',
        id: 40,
      },
    ],
   
  },{
    name: 'Education and Training',
    id: 4,
    // these are the children or 'sub items'
    children: [
      {
        name: 'School Parent Grievances ',
        id: 41,
      },
      {
        name: 'Parenting and Early Childhood',
        id: 42,
      },
      {
        name: 'Coaching and Mentoring',
        id: 43,
      },
      {
        name: 'Competitive Exam Aspirants',
        id: 44,
      },
      {
        name: 'Skill Development and Training',
        id: 45,
      },
    ],
   
  },{
    name: 'Medical and Healthcare',
    id: 5,
    // these are the children or 'sub items'
    children: [
      {
        name: 'Alternative Medicines and Therapies',
        id: 46,
      },
      {
        name: 'Hearing Impaired Adults and Children',
        id: 47,
      },
      {
        name: 'Mentally and Physically Challenged',
        id: 48,
      },
      {
        name: 'Old Age Homes',
        id: 49,
      },
      {
        name: 'Nursing Homes',
        id: 50,
      },
      {
        name: 'Multi-Specialty Hospitals ',
        id: 51,
      },
      {
        name: 'Chemists and Drug Stores',
        id: 52,
      },
      {
        name: 'Emergency Blood Donors',
        id: 53,
      },
    ],
   
  },{
    name: 'Personal and Social Welfare',
    id: 6,
    // these are the children or 'sub items'
    children: [
      {
        name: 'Relationship Counseling',
        id: 54,
      },
      {
        name: 'Unemployed and Under-Employed',
        id: 55,
      },
      {
        name: 'Human Rights NGOs',
        id: 56,
      },
      {
        name: 'Social Welfare Clubs',
        id: 57,
      },
      {
        name: 'Free Food Distribution',
        id: 58,
      },
      {
        name: 'Local Bodies and Administration',
        id: 59,
      },
      {
        name: 'Public Amenities Maintenance',
        id: 60,
      },
      {
        name: 'Political Affiliation and Liaison',
        id: 61,
      },
    ],
   
  },{
    name: 'Daily Life',
    id: 7,
    // these are the children or 'sub items'
    children: [
      {
        name: 'Cooking and Recipes',
        id: 62,
      },
      {
        name: 'Dairy and Grocery Stores',
        id: 63,
      },
      {
        name: 'Auto Repairs Workshops',
        id: 64,
      },
      {
        name: 'Café and Food Joints',
        id: 65,
      },
      {
        name: 'Car Pooling',
        id: 66,
      },
      {
        name: 'News and Current Affairs',
        id: 67,
      },
      {
        name: 'Event Planners',
        id: 68,
      },
    ],
   
  },
];

class CommunitiesScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
     
     selectedItems: [],
    };

  
  }

   createAlert = (FirstName) =>
    Alert.alert(
      "Required",
      FirstName,
      [
       
        { text: "OK", onPress: () => console.log("OK Pressed") }
      ]
    );



onSelectedItemsChange = selectedItems => {
  if ( selectedItems.length <= 3 ) {
            this.setState({ selectedItems });
        }else{
          this.createAlert('You can Select Your Max 3 Communities');
        }

    
  };
  render (){

    const { selectedItems} = this.state;

     const handleSubmitPress = () => {
   if(this.state.selectedItems.length == 0){
      this.createAlert('Please Select Your Community');
      
      return;
    }
    
this.props.navigation.navigate('PersonalityTraits');
  };


    return <View style={styles.mainBody}>
          <View style={styles.mainInnerBody}>
            
            <View style={styles.SectionHeadStyle}>
              <Text style={styles.SectionHedText}>Select Communities</Text>
            
            </View>
             <View style={styles.ContentHeadStyle}>
              <Text style={styles.SectionContText}>Select maximum 3 Communities </Text>
              <Text style={styles.SectionContText}>you belong to</Text>
            
            </View>
            
            <View style={styles.mainStection}>
          
              
              <View >
            
<SectionedMultiSelect
          items={items}
          IconRenderer={Icon}
          uniqueKey="id"
          subKey="children"
          selectText="Choose some things..."
          showDropDowns={true}
          readOnlyHeadings={true}
          onSelectedItemsChange={this.onSelectedItemsChange}
          selectedItems={this.state.selectedItems}
          subItemFontFamily={{fontFamily:'Abel'}}
          itemFontFamily={{fontFamily:'Abel'}}
          searchTextFontFamily={{fontFamily:'Abel'}}
          confirmFontFamily={{fontFamily:'Abel'}}
    
          colors={{primary:'background: linear-gradient(90deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 114.92%)'}}
          
        />
      

              </View>
              


              </View>
              <View style={styles.btnCont}>
               <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity={0.5}
              onPress={handleSubmitPress}>
              <Text style={styles.buttonTextStyle}>Next</Text>
            </TouchableOpacity>
              </View>
          
          </View>
           
        </View>
      
  }
};
export default CommunitiesScreen;

const styles = StyleSheet.create({
  mainBody: {
   flex:1,
    justifyContent: 'center',
    backgroundColor: AppStyle.appColor,
    
     paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
     paddingBottom: 35,
     paddingTop: 55,
  
  },
  mainInnerBody:{
flex:1,
alignContent:'space-between',
  },
  SectionHeadStyle: {
    flexDirection: 'row',
    paddingBottom: 25,

  },
  mainStection:{
    paddingTop: 25,
  },
  selectboxOuterStyle:{
    borderWidth:0,
    width:'100%',
    borderStyle: "solid",
    backgroundColor:'#fff'
 
  },
  selectboxContainer:{
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
   
    borderWidth:1,
    borderRadius:16,
    
    marginBottom:22
  },
  SectionLabel:{
    position: 'absolute', top: -10, left: 20, right: 0, bottom: 0,
    backgroundColor:'#fff',
    paddingLeft:10,
    paddingRight:10,
    width:120,
    height:25,
    textAlign:'center',
    fontFamily: 'Abel'
  },
  SectionContText:{
    fontSize:20,
    fontFamily: 'Abel'
  },
  SectionHedText:{
    fontSize:AppStyle.headingFontsize,
    fontWeight:AppStyle.headingFontweight,
    fontFamily: 'Abel'
  },
  btnCont:{
    position:'absolute',
    bottom:0,
    width:'100%'
  },
  buttonStyle: AppStyle.AppbuttonStyle,
  buttonTextStyle: {
    color: '#FFFFFF',
    fontSize:16,
    fontSize: AppStyle.buttonFontsize,
    fontFamily: 'Abel'
  },
  selectStyle: {
     height:58,
     width:158,
    color: AppStyle.inputBlackcolorText,
    fontWeight: 'bold',
    fontSize: 14,
    width:'100%',
    fontFamily: 'Abel'
  },

  errorTextStyle: {
    color: 'red',
    textAlign: 'center',
    fontSize: 14,
  },
});