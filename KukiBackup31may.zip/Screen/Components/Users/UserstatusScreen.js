// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';
import {Picker} from '@react-native-picker/picker';

import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import MultiSelect from 'react-native-multiple-select';

import Loader from '../../Components/Loader';

 

class UserstatusScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
     
    };

  
  }
  nextScreen(){
    
  }

   createAlert = (FirstName) =>
    Alert.alert(
      "Required",
      FirstName,
      [
       
        { text: "OK", onPress: () => console.log("OK Pressed") }
      ]
    );
  render (){
    const handleSubmitPress = () => {
       AsyncStorage.setItem('isLoggedIn', '0');
     this.props.navigation.navigate('HomeCookiesScreen');
    };
    return <ScrollView>
          <View style={styles.mainBody}>
            <View style={styles.topheadSection}>
              <View style={styles.imagetopCont}>
                <TouchableOpacity onPress={() => this.backScreen()}>
                 <Image
                    source={require('../../../assets/images/photodummy.png')}
                    style={{
                     resizeMode: 'contain',
                      height:75
                    }}
                  />
                </TouchableOpacity>
              </View>
              <View style={styles.conttentRight}>
                <Text style={styles.ContnetSection}>Take a Picture or upload From File</Text>
                <TouchableOpacity onPress={() => this.nextScreen()}>
                    <Text style={styles.buttonSection} >Upload</Text>
                </TouchableOpacity>
              </View>
            </View>
            <View style={styles.mainContentSection}>
              <Text style={styles.contentLeft} >Gallery</Text>
              <TouchableOpacity onPress={() => this.nextScreen()}>
                <Text style={styles.contentRight}>See all</Text> 
              </TouchableOpacity>
            </View>

            <View style={styles.galleryContentSection}>
              <View style={styles.galleryTopgallrysec}>
                 <Image
                      source={require('../../../assets/images/photoone.png')}
                      style={{
                       resizeMode: 'cover',
                        
                      }}
                    />
                <Image
                    source={require('../../../assets/images/phototow.png')}
                    style={{
                     resizeMode: 'cover',
                      
                    }}
                  />   

              </View>

              <View style={styles.gallerybottomgallrysec}>
                 <Image
                      source={require('../../../assets/images/photothree.png')}
                      style={{
                       resizeMode: 'cover',
                        
                      }}
                    />
                <Image
                    source={require('../../../assets/images/photofour.png')}
                    style={{
                     resizeMode: 'cover',
                      
                    }}
                  />   
                  <Image
                    source={require('../../../assets/images/photofive.png')}
                    style={{
                     resizeMode: 'cover',
                      
                    }}
                  />  

              </View>
              
            </View>

            <View style={styles.bottomContentSection}>
              <TextInput
                style={styles.inputStyle}
                placeholder="e. g. off to mumbai to 3 days" //dummy@abc.com
                placeholderTextColor="#000"
                autoCapitalize="none"
               maxLength={10}
                returnKeyType="next"
                onSubmitEditing={() =>
                  passwordInputRef.current &&
                  passwordInputRef.current.focus()
                }
                underlineColorAndroid="#f000"
                blurOnSubmit={false}
              />
              <Text style={styles.Label}>What are you up to</Text>

               <View style={styles.btnCont}>
                <TouchableOpacity
                  style={styles.buttonStyle}
                  activeOpacity={0.5}
                  onPress={handleSubmitPress}>
                  <Text style={styles.buttonTextStyle}>Finish</Text>
                </TouchableOpacity>
              </View>
            </View>


          </View>
        </ScrollView>
  }
};
export default UserstatusScreen;

const styles = StyleSheet.create({
  mainBody: {
    flex:1,
    justifyContent: 'center',
    backgroundColor: AppStyle.appColor,
    paddingLeft: 15,
    paddingRight:15,
     paddingBottom: 35,
     paddingTop: 55,
    
  },
  topheadSection:{
    display:'flex',
    justifyContent:'space-between',
    alignItems:'center',
    flexDirection:'row',
    marginBottom:15
  },
  ContnetSection:{
    fontSize: 16,
    color:'#000000',
    lineHeight:24,
    textAlign:'center',
    fontFamily: 'Abel'
  },
  imagetopCont:{
    borderWidth:2,
    borderColor:'#F27121',
    borderRadius:100,
    padding:3
  },
  conttentRight:{
     flex:1,
    paddingLeft:10,
     paddingRight:10,
     width:'100%',
  },
  buttonSection:{
    textAlign:'center',
    backgroundColor:'linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)',
    paddingTop:10,
    paddingBottom:10,
    paddingLeft:15,
    paddingRight:15,
    width:96,
    marginLeft:'auto',
    marginRight:'auto',
    borderRadius:10,
    marginTop:10,
    color:'#fff',
    fontFamily: 'Abel',
    fontSize:16
  },
  mainContentSection:{
    display:'flex',
    justifyContent:'space-between',
    alignItems:'center',
    flexDirection:'row',
    marginTop:25,
    paddingLeft:10,
    paddingRight:10,
  },
  contentLeft:{
    fontSize:16,
    fontFamily: 'Abel',
  },
  contentRight:{
    fontSize:14,
    color:'#FD6F01',
    fontFamily: 'Abel',
  },
  galleryContentSection:{
    paddingLeft:10,
    paddingRight:10,
    marginTop:10
  },
  galleryTopgallrysec:{
    flexDirection:'row',
    justifyContent:'space-between',
  },
  gallerybottomgallrysec:{
    flexDirection:'row',
    justifyContent:'space-between',
    marginTop:20
  },
  bottomContentSection:{
    marginTop:30,
    paddingLeft:10,
    paddingRight:10
  },
  inputStyle:{
    padding:15,
    borderWidth:1,
    borderColor:'#E8E6EA',
    width:'100%',
    borderRadius:15,
    fontFamily: 'Abel'
  },
  Label:{
    position:'absolute',
    fontSize:12,
    left:30,
    top:-7,
    paddingRight:5,
    paddingLeft:5,
    fontFamily: 'Abel',
    backgroundColor:'#fff'
  },
  btnCont:{
    marginTop:20
  },
  buttonStyle: AppStyle.AppbuttonStyle,
  buttonTextStyle:{
    color:'#fff',
    fontFamily: 'Abel',
    fontSize:16
  }
});


