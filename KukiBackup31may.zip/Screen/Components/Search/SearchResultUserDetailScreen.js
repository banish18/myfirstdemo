// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component,useCallback} from 'react';
import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';

class SearchResultUserDetailScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      
    };
  }

 createAlert = (FirstName) =>
  Alert.alert(
    "Required",
    FirstName,
    [
      { text: "OK", onPress: () => console.log("OK Pressed") }
    ]
  );
  backScreen(){
      this.props.navigation.navigate('SearchResultScreen');
    }

  setFav(val){
    alert('fav set');
  }  

  sentCookie(val){
    alert('Cookie sent');
  }

  readMore(val){

  }

  render (){

    //const { checked} = this.state;

 

    return <ScrollView>
          <View style={styles.topheadSection}>
                 <View>
                   <Image
                            source={require('../../../assets/images/users/photomains.png')}
                            style={{
                              width: '100%',
                              resizeMode: 'contain',

                            }}
                          />  
                 </View> 
                 
                 <TouchableOpacity
                  style={styles.backBtnSection}
                  activeOpacity={0.5}
                  onPress={this.backScreen.bind(this,'x')}>
                    <Image
                        source={require('../../../assets/images/back-icon.png')}
                        style={{
                          width: 18,
                          resizeMode: 'contain',

                        }}
                      />
                  </TouchableOpacity>    
                       
              </View>
            <View style={styles.innerBody}>
              <View style={styles.innerHeadSection}>
                <TouchableOpacity
                  style={styles.innerSection}
                  activeOpacity={0.5}
                  onPress={this.backScreen.bind(this,'x')}>
                <Image
                        source={require('../../../assets/images/icons/cancel.png')}
                        style={{
                          width: 15,
                          resizeMode: 'contain',

                        }}
                      />
                </TouchableOpacity>  
                <TouchableOpacity
                  style={[styles.innerSection,styles.innerfavSection]}
                  activeOpacity={0.5}
                  onPress={this.setFav.bind(this,'x')}>
                <Image
                        source={require('../../../assets/images/icons/fav.png')}
                        style={{
                          width: 42,
                          resizeMode: 'contain',

                        }}
                      />
                </TouchableOpacity>  
                <TouchableOpacity
                  style={styles.innerSection}
                  activeOpacity={0.5}
                  onPress={this.sentCookie.bind(this,'x')}>
                <Image
                        source={require('../../../assets/images/cookie.png')}
                        style={{
                          width: 23,
                          resizeMode: 'contain',

                        }}
                      />
                </TouchableOpacity> 
              </View>
              <View style={styles.innermainlayutSection}>
                <View>
                    <Text style={styles.textHeading}>
                    Jessica Parker, 23
                    </Text>
                    <Text style={styles.textSubheading}>
                    Proffesional model
                    </Text>
                    <View style={styles.ratingSection}>
                     <Image
                            source={require('../../../assets/images/icons/star.png')}
                            style={{
                              width: 18,
                              resizeMode: 'contain',

                            }}
                          />
                           <Image
                            source={require('../../../assets/images/icons/star.png')}
                            style={{
                              width: 18,
                              resizeMode: 'contain',

                            }}
                          />
                    </View>      
                
                </View>

                <View style={styles.directionIcon}>
                   <TouchableOpacity
                  style={styles.aboutReadmore}
                  activeOpacity={0.5}
                  onPress={this.readMore.bind(this,'x')}><Image
                          source={require('../../../assets/images/icons/direcction.png')}
                          style={{
                            width: 18,
                            resizeMode: 'contain',

                          }}
                        /></TouchableOpacity> 
                </View>
              </View>

              <View style={styles.innermainlayutSection}>
                <View>
                    <Text style={styles.textHeading}>
                    Location
                    </Text>
                    <Text style={styles.textSubheading}>
                    Punjab, Amritsar...
                    </Text> 
                </View>
                <View style={styles.locationIcon}>
                 <Image
                          source={require('../../../assets/images/icons/location_iconnnn.png')}
                          style={{
                            width: 10,
                            resizeMode: 'contain',
                          }}
                        />
                  <Text style={styles.locaitonDirectionText}>1 km</Text>      
                </View>
              </View>

              {/*  About section start */}

              <View style={styles.aboutSection}>
              <Text style={styles.aboutHeadSection}>About</Text>
              <Text style={styles.aboutContentSection}>My name is Jessica Parker and I enjoy meeting new people and finding ways to help them have an uplifting experience. I enjoy reading..</Text>
               <TouchableOpacity
                  style={styles.aboutReadmore}
                  activeOpacity={0.5}
                  onPress={this.readMore.bind(this,'x')}>
                <Text style={styles.aboutreadMoreection}>Read More</Text>
                </TouchableOpacity> 
              </View>

              {/* About section end */}

               {/*  Community section start */}

              <View style={styles.commSection}>
                <Text style={styles.comHeadSection}>Community</Text>
                
                <View style={styles.commContent}>
                  <View style={styles.commBox}><Text style={styles.commcontSection}>Banking</Text></View>
                  <View style={styles.commBox}><Text style={styles.commcontSection}>Arts and Entertainment</Text></View>
                  
                </View>
                
              </View>

              {/* Community section end */}

            {/* Gallery Section Start*/}

            <View style={styles.galleryContentSection}>
               <View style={styles.galleryTopHeadSection}>
                  <Text style={styles.galleryHeadSection}>Gallery</Text>
                  <TouchableOpacity
                  style={styles.aboutReadmore}
                  activeOpacity={0.5}
                  onPress={this.readMore.bind(this,'x')}>
                    <Text style={styles.galleryseeSection}>See all</Text>
                  </TouchableOpacity> 
                </View>
              <View style={styles.galleryTopgallrysec}>
                 <Image
                      source={require('../../../assets/images/users/photomaino.png')}
                      style={{
                       resizeMode: 'cover',
                        
                      }}
                    />
                <Image
                    source={require('../../../assets/images/users/photomainfi.png')}
                    style={{
                     resizeMode: 'cover',
                      
                    }}
                  />   

              </View>

              <View style={styles.gallerybottomgallrysec}>
                 <Image
                      source={require('../../../assets/images/users/photomainf.png')}
                      style={{
                       resizeMode: 'cover',
                        
                      }}
                    />
                <Image
                    source={require('../../../assets/images/users/phppop.png')}
                    style={{
                     resizeMode: 'cover',
                      
                    }}
                  />   
                  <Image
                    source={require('../../../assets/images/users/photomainth.png')}
                    style={{
                     resizeMode: 'cover',
                      
                    }}
                  />  

              </View>
              
            </View>
            {/* Gallery Section End*/}
            </View>
          </ScrollView>
  }
};
export default SearchResultUserDetailScreen;

const styles = StyleSheet.create({
  topheadSection:{
   
  },
  backBtnSection:{
    position:'absolute',
    top:80,
    left:15,
    borderWidth:1,
    borderColor:'#E8E6EA',
    borderRadius:15,
    paddingTop:15,
    paddingBottom:15,
    paddingLeft:20,
    paddingRight:20
  },
  innerBody: {
    borderTopLeftRadius:20,
    borderTopRightRadius:20,
    backgroundColor:'#ffffff',
    paddingLeft:20,
    paddingRight:20,
    marginTop: -40,
    marginLeft: 10,
    marginRight: 10,
  },
  innerHeadSection:{
    flexDirection:'row',
    justifyContent: 'space-between',
    marginTop: -40,
  },
  innerfavSection:{
    backgroundColor:'#FD6F01',
    width:99,
    height:99,
  },
  innerSection:{
    height:78,
    width:78,
    backgroundColor:'#fff',
    borderRadius:100,
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center'
  },
  ratingSection:{
    flexDirection:'row',
    marginTop:10,
  },
  innermainlayutSection:{
    flexDirection:'row',
    width:'100%',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  directionIcon:{
    height:52,
    width:52,
    backgroundColor:'#fff',
    borderRadius:15,
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
    borderWidth: 1,
    borderColor: '#E8E6EA',
  },
  textHeading:{
    color: '#000000',
    fontSize: 24,
    fontFamily: 'Abel',
  },
  textSubheading:{
    color: 'rgba(0, 0, 0, 0.7)',
    fontSize: 14,
    fontFamily: 'Abel',
  },
  locationIcon:{
    flexDirection:'row',
  },
  locaitonDirectionText:{
    color:'#FD6F01',
    fontSize: 12,
    fontFamily: 'Abel',
    marginLeft:5
  },
  aboutSection:{
    paddingTop:15
  },
  aboutHeadSection:{
    color: '#000000',
    fontSize: 16,
    fontFamily: 'Abel',
  },
  aboutContentSection:{
    color: 'rgba(0, 0, 0, 0.7)',
    fontSize: 14,
    fontFamily: 'Abel',
  },
  aboutreadMoreection:{
    color:'#FD6F01',
    fontSize: 14,
    fontFamily: 'Abel'
  },
  commSection:{
    paddingTop:15
  },
  comHeadSection:{
    color: '#000000',
    fontSize: 16,
    fontFamily: 'Abel',
  },
  commContent:{
    flexDirection:'row',
    justifyContent:'space-between',
    paddingTop:15
  },
  commBox:{
    paddingTop:10,
    paddingLeft:20,
    paddingBottom:10,
    paddingRight:20,
    borderWidth:1,
    borderColor:'#FD6F01',
    borderRadius:5
  },
  commcontSection:{
    color:'#FD6F01',
    fontSize: 14,
    fontFamily: 'Abel'
  },
  galleryContentSection:{
    marginTop:15,
    marginBottom:25
  },
  galleryTopgallrysec:{
    flexDirection:'row',
    justifyContent:'space-between',
  },
  gallerybottomgallrysec:{
    flexDirection:'row',
    justifyContent:'space-between',
    marginTop:20
  },
  galleryHeadSection:{
    color: '#000000',
    fontSize: 16,
    fontFamily: 'Abel',
    marginBottom:15
  },
  galleryTopHeadSection:{
    flexDirection:'row',
    justifyContent:'space-between'
  },
  galleryseeSection:{
    color:'#FD6F01',
    fontSize: 14,
    fontFamily: 'Abel'
  }
});