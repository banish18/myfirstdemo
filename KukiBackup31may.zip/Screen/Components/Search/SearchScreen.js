// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component,useCallback} from 'react';
import {Picker} from '@react-native-picker/picker';
import MultiSlider from '@ptomasroos/react-native-multi-slider';
import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';

import Loader from '../../Components/Loader';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';
class SearchScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      selectedDValCont:'selectdVal',
      selectedCValCont:'',
      selectedGenderValue:'',
      selectedCommValue:'',
      agestartRange:'18-28',
      distanceRange:10,
       selectedStateValue:'',
    selectedCityValue:'',
    searchWise:'Distance',
    ageStartVal:18,
    ageEndVal:28
    };

  AsyncStorage.setItem('activeClass', 'UactiveClass');
  
  }

 createAlert = (FirstName) =>
  Alert.alert(
    "Required",
    FirstName,
    [
     
      { text: "OK", onPress: () => console.log("OK Pressed") }
    ]
  );
  backScreen(){
    
    this.props.navigation.navigate('UserstatusScreen');
  }
  nextScreen(){
    
    this.props.navigation.navigate('UserstatusScreen');
  }

    setSelectedValue(itmVal,type){
   if(type == 'gender'){
      //alert(itmVal);
      this.setState({selectedGenderValue: itmVal });
    }if(type == 'comm'){
      this.setState({selectedCommValue: itmVal });
    }else if(type == 'State'){
      this.setState({selectedStateValue: itmVal });
    }else if(type == 'city'){
      this.setState({selectedCityValue: itmVal });
    }
  }

checkVal(val){
    
    this.setState({checked:val});
    if(val == 'd'){
      this.setState({
         selectedDValCont: 'selectdVal'
       });
      this.setState({
         selectedCValCont: ''
       });
      this.setState({searchWise:'Distance'});
    }else if(val == 'c'){
       this.setState({
         selectedCValCont: 'selectdVal'
       });
        this.setState({
         selectedDValCont: ''
       });
      this.setState({searchWise:'City'});
     }
   
    
  }

  componentDidMount() {
    //const renderThumb = useCallback(() => <Thumb/>, []);
  }

  

  clearRecords(){

  
    this.setState({selectedDValCont:'selectdVal'});
    this.setState({selectedCValCont:''});
    this.setState({selectedGenderValue:''});
    this.setState({selectedCommValue:''});
    this.setState({agestartRange:'18-28'});
    this.setState({distanceRange:10});
    this.setState({selectedStateValue:''});
    this.setState({selectedCityValue:''});
    this.setState({searchWise:'Distance'});
    this.setState({ageStartVal:18});
    this.setState({ageEndVal:28});
  }

  

  render (){

     const { checked,selectedDValCont,selectedCValCont,selectedGenderValue,selectedCommValue,agestartRange,distanceRange,selectedStateValue,selectedCityValue,searchWise,ageStartVal,ageEndVal} = this.state;

     const handleSubmitPress = () => {
   
    this.props.navigation.navigate('SearchResultScreen');
  };

  const setAgestartrange = (val) => {
    this.setState({agestartRange:val.join('-')});
  };

   const setDistancerange = (val) => {
    this.setState({distanceRange:val});
  };

  let distanceSlider;
  if(selectedDValCont != ''){
  
    distanceSlider = <View style={styles.distancesectionContainer}><View style={styles.lowerheadSection}>
                <Text style={styles.SectionInnerHeadStyle}>Distance </Text>
                <Text style={styles.SectionInnerHeadStyle}>{distanceRange}km</Text>
              </View>
 <MultiSlider
             min={0}
              max={500}
               containerStyle={{height:30,paddingLeft:10}}
               trackStyle={{ borderRadius: 7, height: 3.5 }}
               selectedStyle={{backgroundColor: '#FD6F01'}}
               unselectedStyle={{backgroundColor: '#FECAA0'}}
               markerStyle={{ height:34, width: 34, borderRadius: 15, backgroundColor:'linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)', borderWidth: 0.5, borderColor: '#fff',borderWidth:3,borderRadius:17}}
               pressedMarkerStyle={{height:25, width: 25,backgroundColor:'linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'}}
                values={[10]}
                onValuesChange={values => setDistancerange(values)}
                
                step={10}
              />
              </View>


  }
  let citySection;
   if(selectedCValCont != ''){

     citySection = <View style={styles.citysectionContainer}>
     <View style={styles.selectboxContainer}>
            

              <Picker
        selectedValue={selectedStateValue}
        style={styles.selectStyle}
        onValueChange={(itemValue, itemIndex) => this.setSelectedValue(itemValue,'State')}
      >
        <Picker.Item label="Plese select your state" value="" />
        <Picker.Item label="Punjab" value="Punjab" />
        <Picker.Item label="Himachal" value="Himachal" />
        <Picker.Item label="Haryana" value="Haryana" />
      </Picker>
      <Text style={styles.SectionSmallLabel}>State</Text>
              </View>
                 <View style={styles.selectboxContainer}>
            

              <Picker
        selectedValue={selectedCityValue}
        style={styles.selectStyle}
        onValueChange={(itemValue, itemIndex) => this.setSelectedValue(itemValue,'city')}
      >
        <Picker.Item label="Plese select your city" value="" />
        <Picker.Item label="Shimla" value="Shimla" />
        <Picker.Item label="Karnal" value="Karnal" />
        <Picker.Item label="Mohali" value="Mohali" />
      </Picker>
      <Text style={styles.SectionSmallLabel}>City</Text>
              </View>

              </View>
   }

   


    return <View style={{flex:1,height:'100%'}}><ScrollView><View style={styles.mainBody}>
            <View style={styles.topheadSection}>
              <Text style={styles.SectionHeadStyle}>Search Options</Text>
              <View style={styles.skipSection}>
              <TouchableOpacity onPress={() => this.clearRecords()}>
                    <Text  style={styles.clearSection}>Clear</Text>
              </TouchableOpacity>
              </View>
              
            </View>

            <View style={styles.mainStection}>
              <Text style={styles.SectionInnerHeadStyle}>{searchWise}-Wise</Text>
              <View style={styles.selectionContStection}>
                <TouchableOpacity onPress={() => this.checkVal('d')}>
                  <View     style={[styles.selectionContainer ,selectedDValCont != '' ? styles.selectedDValCont : styles.selectionContainer]}>

                    <Text style={[styles.searchText ,selectedDValCont != '' ? {color:'#fff'}: {}]}>Search Distance-Wise</Text>
                                  
                  </View>
                </TouchableOpacity>

                 <TouchableOpacity onPress={() => this.checkVal('c')}>
                  <View style={[styles.selectionRightContainer ,selectedCValCont != '' ? styles.selectedCValCont : styles.selectionRightContainer]}>
                
                 
                   <Text style={[styles.searchText ,selectedCValCont != '' ? {color:'#fff'}: {}]}>Search City-Wise</Text>
                  
                                
                  </View>
                </TouchableOpacity>
              </View>
        
              <View style={styles.selectboxContainer}>
            

               <Picker
               dropdownIconColor= '#FD6F01'
                         style={styles.selectStyle}
                        fontFamily="abel"
                  selectedValue={selectedGenderValue}
                  
                  onValueChange={(itemmValue, itemIndex) => this.setSelectedValue(itemmValue,'gender')}
                >
                  <Picker.Item  fontFamily="abel" label="Plese select your gender" value="" />
                  <Picker.Item label="male" value="maile" />
                  <Picker.Item label="female" value="female" />
                  <Picker.Item label="other" value="other" />
                </Picker>
                <Text style={styles.SectionSmallLabel}>Gender</Text>

              </View>
              <View style={styles.selectboxContainer}>
            

               <Picker
               style={styles.selectStyle}
              fontFamily="abel"
              dropdownIconColor= '#FD6F01'
              
        selectedValue={selectedCommValue}
        
        onValueChange={(itemmValue, itemIndex) => this.setSelectedValue(itemmValue,'comm')}
      >
        <Picker.Item  fontFamily="Abel" label="Plese select your gender" value="" />
        <Picker.Item label="Business and Entrepreneurship" value="Business and Entrepreneurship" />
        <Picker.Item label="Auto Repair, Buying and Selling" value="Auto Repair, Buying and Selling" />
        <Picker.Item label="Banking and Finance" value="Banking and Finance" />
      </Picker>
      <Text style={styles.SectionLabel}>Select Community</Text>

              </View>

              <View style={styles.lowerheadSection}>
                <Text style={styles.SectionInnerHeadStyle}>Age</Text>
                <Text style={styles.SectionInnerHeadStyle}>{agestartRange}</Text>
              </View>
              
              <MultiSlider
             min={ageStartVal}
              max={100}
               containerStyle={{height:30,paddingLeft:10}}
               trackStyle={{ borderRadius: 7, height: 3.5 }}
               selectedStyle={{backgroundColor: '#FD6F01'}}
               unselectedStyle={{backgroundColor: '#FECAA0'}}
               markerStyle={{ height:34, width: 34, borderRadius: 15, backgroundColor:'linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)', borderWidth: 0.5, borderColor: '#fff',borderWidth:3,borderRadius:17}}
               pressedMarkerStyle={{height:25, width: 25,backgroundColor:'linear-gradient(180deg, rgba(253, 139, 48, 0.69) 0%, #FD6F01 100%)'}}
                values={[ageStartVal,ageEndVal]}
                onValuesChange={values => setAgestartrange(values)}
                
                step={1}
              />


               
               {distanceSlider}
               {citySection}
               
            </View>
            <View style={styles.btnCont}>
               <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity={0.5}
              onPress={handleSubmitPress}>
              <Text style={styles.buttonTextStyle}>Search</Text>
            </TouchableOpacity>
              </View>
          </View></ScrollView>
           <CookieNavigationScreen navigation={this.props.navigation}/>
           </View>
        
      
  }
};
export default SearchScreen;

const styles = StyleSheet.create({
  mainBody: {
   flex:1,
    backgroundColor: AppStyle.appColor,
     paddingLeft: 35,
    paddingRight: 35,
     paddingBottom: 35,
     paddingTop: 50,
    
  },
  skipSection:{
    
    textAlign:'right',
    position:'absolute',
    right:0,
    bottom:8
  },
  clearSection:{
    color:'#FD6F01',
    fontSize:16,

  },
  topheadSection:{
 
  
    position:'relative',
    
  },
  lowerheadSection:{
    display:'flex',
    justifyContent:'space-between',
    flexDirection:'row',
     paddingBottom: 15,
  },
  SectionHeadStyle: {
    fontSize:34,
    fontFamily: 'Abel',
   
    
  },
  SectionInnerHeadStyle:{
    fontSize:16,
    fontFamily: 'Abel',
    
  },
  mainStection:{
    paddingTop: 20,
   width:'100%',

  },
  
  SectionLabel:{
    position: 'absolute', top: -10, left: 20, right: 0, bottom: 0,
    backgroundColor:'#fff',
    paddingLeft:10,
    paddingRight:10,
    width:120,
    height:25,
    textAlign:'center',
    fontFamily: 'Abel',
    color:'rgba(0, 0, 0, 0.4)',
  },
  SectionSmallLabel:{
    position: 'absolute', top: -10, left: 20, right: 0, bottom: 0,
    backgroundColor:'#fff',
    alignSelf: 'flex-start',
    paddingLeft:10,
    paddingRight:10,
    width:70,
    height:25,
    textAlign:'center',
    color:'rgba(0, 0, 0, 0.4)',
    fontFamily: 'Abel'
  },
  selectionContStection:{
    flexDirection:'row',

     textAlign:'center',
     paddingTop: 20,
     marginBottom: 25,
     flex:1,
     
     justifyContent:'space-around'
  },
  selectionContainer:{
    borderColor:'#E8E6EA',
    borderTopLeftRadius:25,
    borderBottomLeftRadius:25,
    marginBottom:15,
     textAlign:'center',
    paddingLeft:10,
    paddingRight:10,
    paddingTop:30,
    paddingBottom:30,
    borderLeftWidth:1,
    borderRightWidth:0,
    borderTopWidth:1,
    borderBottomWidth:1,

  },
  selectionRightContainer:{
   textAlign:'center',
    borderColor:'#E8E6EA',
    borderTopRightRadius:25,
    borderBottomRightRadius:25,
    marginBottom:15,
    paddingLeft:10,
    paddingRight:10,
    paddingTop:30,
    paddingBottom:30,
    borderLeftWidth:0,
    borderRightWidth:1,
    borderTopWidth:1,
    borderBottomWidth:1,
    flex:1,
        flexDirection:'column',
  
  },
  searchText:{
    color:'#000'
  },
  selectedDValCont:{
    backgroundColor:'linear-gradient(180deg, #FD6F01 0%, rgba(253, 139, 48, 0.69) 100%)'
  },
  selectedCValCont:{
    backgroundColor:'linear-gradient(180deg, #FD6F01 0%, rgba(253, 139, 48, 0.69) 100%)'
  },
  selectboxContainer:{
    color: AppStyle.inputBlackcolorText,
    paddingLeft: 15,
    fontFamily: 'Abel',
    borderWidth:1,
    borderColor:'#E8E6EA',
    borderRadius:16,
    height:58,
    marginBottom:35
  },
  btnCont:{
    paddingTop:35,
   
    bottom:10,
    left:0,
    right:0,
    flex:1,
    width:'100%',

  },
  buttonStyle: AppStyle.AppbuttonStyle,
    buttonTextStyle: {
    color: '#FFFFFF',
    fontSize: AppStyle.buttonFontsize,
    fontFamily: 'Abel',

  },

  errorTextStyle: {
    color: 'red',
    textAlign: 'center',
    fontSize: 14,
  },
  citysectionContainer:{
    paddingTop:25
  },
  distancesectionContainer:{
    paddingTop:25
  }
});