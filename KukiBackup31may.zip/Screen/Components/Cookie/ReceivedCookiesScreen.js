// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component,useCallback} from 'react';
import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';
class ReceivedCookiesScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      
    };
  }

 createAlert = (FirstName) =>
  Alert.alert(
    "Required",
    FirstName,
    [
     
      { text: "OK", onPress: () => console.log("OK Pressed") }
    ]
  );
  getuserDetail = (i) => {

    this.props.navigation.navigate('CookeiUserDetailScreen',{
      isReturnscreen: 'ReceivedCookiesScreen',
    });
  }

  render (){

    const { checked} = this.state;

  
    

    let receiverContentData = [];
  for(let i =0; i<=6;i++){
    receiverContentData.push(
              <View style={styles.mainInnersection} key={i}>
                <TouchableOpacity
              style={styles.buttonStyle}
              activeOpacity={0.5}
              onPress={this.getuserDetail.bind(this,i)} ><Image
                  source={require('../../../assets/images/uphoto.png')}
                  style={{
                    width: 48,
                    resizeMode: 'contain',
                    marginRight:10,
                  }}
                /></TouchableOpacity>
                <View style={styles.searchMainContentsection} >
                  <View style={styles.searchContentsection}>
                    <Text style={styles.searchContentText}>Sunita Chandra</Text>
                    <Text style={styles.searchContentText}>F, 18-25, Beuaty and Wellness, Ambala</Text>
                    <View style={styles.ratingMainSection}><Text style={styles.searchContentText}>Trust Rating....</Text>
                    <View style={styles.ratingSection}>
                       <Image
                          source={require('../../../assets/images/icons/star.png')}
                          style={{
                            width: 18,
                            resizeMode: 'contain',

                          }}
                        />
                        <Image
                          source={require('../../../assets/images/icons/star.png')}
                          style={{
                            width: 18,
                            resizeMode: 'contain',

                          }}
                        />
                        <Image
                          source={require('../../../assets/images/icons/star.png')}
                          style={{
                            width: 18,
                            resizeMode: 'contain',

                          }}
                        />
                         <Image
                          source={require('../../../assets/images/icons/starn.png')}
                          style={{
                            width: 18,
                            resizeMode: 'contain',

                          }}
                        />
                        <Image
                          source={require('../../../assets/images/icons/starn.png')}
                          style={{
                            width: 18,
                            resizeMode: 'contain',

                          }}
                        />
                    </View>
                    </View>
                  </View>
                  <View style={styles.cookeSecright}>
                    <Image
                  source={require('../../../assets/images/cookie.png')}
                  style={{
                    width: 18,
                    resizeMode: 'contain',

                  }}
                />
                <Text style={styles.cookieCount}>2</Text>
                  </View>
                  
                </View> 
                </View>);

  }
    return <View style={{flex:1,height:'100%'}}><ScrollView>
            <View style={styles.mainBody}>
              <View style={styles.topheadSection}>
                <Text style={styles.SectionHeadStyle}>Received Cookies Page</Text>
                <Text style={styles.SectionsubHeadStyle}>(Receiver’s View of Received Cookies)</Text>
              </View>
              {receiverContentData}
            </View>
          </ScrollView>
          <CookieNavigationScreen navigation={this.props.navigation}/>
          </View>
  }
};
export default ReceivedCookiesScreen;

const styles = StyleSheet.create({
  mainBody: {
   flex:1,
    backgroundColor: AppStyle.appColor,
    paddingLeft: 35,
    paddingRight: 35,
    paddingBottom: 35,
    paddingTop: 50
  },
  topheadSection:{
    marginTop:10,
    marginBottom:35
  },
  SectionHeadStyle: {
    fontSize:24,
    fontFamily: 'Abel',
    fontWeight:'400',
    color:'#FD6F01'
  },
  cookeSecright:{
    flexDirection:'row'
  },
  cookieCount:{
    fontSize:12,
    fontFamily: 'Abel',
    fontWeight:'400',
    color:'#FD6F01',
    marginTop:-7,
    marginRight:5
  },
  SectionsubHeadStyle:{
    fontSize:16,
    fontFamily: 'Abel',
    fontWeight:'400',
    color:'#000'
  },
  mainInnersection: {
    flexDirection:'row',
    flex:1,
    alignItems:'center',
    justifyContent: 'space-between',
    marginBottom:10
  },
  searchMainContentsection:{
    flexDirection:'row',
    flex:1,
    alignItems:'center',
    justifyContent: 'space-between',
    borderColor:'#E8E6EA',
    borderBottomWidth:1,
      paddingBottom:10,
  },
  searchContentsection:{
    paddingLeft:0,
  },
  searchContentText:{
    fontSize:13,
    fontFamily:'Abel'
  },
  ratingMainSection:{
    flexDirection:'row'
  },
  ratingSection:{
    flexDirection:'row',
    alignItems:'center'
  }
});