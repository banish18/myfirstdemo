// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useState,Component} from 'react';


import {
  StyleSheet,
  TextInput,
  View,
  Text,
  ScrollView,
  FlatList,
  SafeAreaView,
  Image,
  Keyboard,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  KeyboardAvoidingView
} from 'react-native';

import AppStyle from '../../Constants/AppStyle.js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CookieNavigationScreen from '../Common/CookieNavigationScreen';

 

class HomeCookiesScreen extends Component {

 constructor(props) {
    super(props);
    this.state = {
      checked:'male',
      selectedMValCont:'',
      selectedFValCont:'',
      selectedOValCont:'',
    };
  AsyncStorage.setItem('activeClass', 'CactiveClass');
  
  }
 
 createAlert = (FirstName) =>
  Alert.alert(
    "Required",
    FirstName,
    [
     
      { text: "OK", onPress: () => console.log("OK Pressed") }
    ]
  );

  checkVal(val,stVal){
    this.props.navigation.navigate(val);
    
  }
  getuserDetail = (i) => {

    this.props.navigation.navigate('SearchResultUserDetailScreen');
  }
  render (){

    const { checked,selectedMValCont,selectedFValCont,selectedOValCont} = this.state;

     const handleSubmitPress = () => {
   if(!this.state.setChecked){
      this.createAlert('Selected');
      
      return;
    }
    this.props.navigation.navigate('UserstatusScreen');
  };
    return <View style={{flex:1,height:'100%'}}>
          <ScrollView style={{backgroundColor:'#fff',height:'100%'}}>
          <View style={styles.mainBody}>
            
             <Text style={styles.ContentHeadStyle}>Today's Wisdom</Text>
             <View style={styles.OuterMainQuote}>
            <View style={styles.ProfilePic}>

              <View style={styles.innerRightpro}>
                  <TouchableOpacity
              
                activeOpacity={0.5}
                onPress={this.getuserDetail.bind(this)} ><Image
                    source={require('../../../assets/images/uphoto.png')}
                    style={{
                      height: 50,
                      width: 50,
                      resizeMode: 'contain',
                      marginRight:10,
                      marginLeft:20,
                    }}
                  /></TouchableOpacity>
              </View>
              <View>
                <Text style={styles.ContentInnrtStyle}>
                Rajat Mathur
                </Text>
              </View>
            </View>
            <View style={styles.MainQuoteSec}>
            <View style={styles.ArrowTop}>

            </View>
<Text style={styles.MqsTextSec}>
 "Never lose sight of the face that the most important yard stick to your success is how you treat other people"
</Text>
       <Image
                source={require('../../../assets/images/icons/sublogo.png')}
                 style={styles.cookieLogo} 
                 />
</View>
</View>

<View style={styles.SocialMediaSec}>

<View style={styles.TextHeading}>
<Text style={styles.ShareText}>
Share the Wisdom via: 
</Text>
</View>

<View style={styles.SmIcons}>
 <View style={styles.SocialIconBg}>
            <View style={styles.IconImgSec}>
              <Image
                source={require('../../../assets/images/icons/whatsapp-svgrepo.png')}
                 style={[{
                 resizeMode: 'contain',
                  
                  width:15,
                  height:20,
                 
                }]}             
              />
              </View>
              <View style={styles.IconTxtSec}>
              <Text style={styles.IcTxt}>
              Whatsapp
              </Text>
              </View>
             </View>

 <View style={styles.SocialIconBg}>
            <View style={styles.IconImgSec}>
              <Image
                source={require('../../../assets/images/icons/facebook-svgrepo.png')}
                 style={[{
                 resizeMode: 'contain',
                  
                  width:15,
                  height:20,
                 
                }]}             
              />
              </View>
              <View style={styles.IconTxtSec}>
              <Text style={styles.IcTxt}>
              Facebook
              </Text>
              </View>
             </View>

              <View style={styles.SocialIconBg}>
            <View style={styles.IconImgSec}>
              <Image
                source={require('../../../assets/images/icons/instagram-svgre.png')}
                 style={[{
                 resizeMode: 'contain',
                  
                  width:15,
                  height:20,
                 
                }]}             
              />
              </View>
              <View style={styles.IconTxtSec}>
              <Text style={styles.IcTxt}>
              Instagram
              </Text>
              </View>
             </View>

              <View style={styles.SocialIconBg}>
            <View style={styles.IconImgSec}>
              <Image
                source={require('../../../assets/images/icons/twitter-svgrepo.png')}
                 style={[{
                 resizeMode: 'contain',
                  
                  width:15,
                  height:20,
                 
                }]}             
              />
              </View>
              <View style={styles.IconTxtSec}>
              <Text style={styles.IcTxt}>
              Twitter
              </Text>
              </View>
             </View>
</View>
</View>

          </View>



           </ScrollView>
            <CookieNavigationScreen navigation={this.props.navigation}/>
           </View>
           
        
      
  }
};
export default HomeCookiesScreen;

const styles = StyleSheet.create({
  mainBody: {
   flex:1,
    
    backgroundColor: AppStyle.appColor,
     paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
     paddingBottom: 20,
     paddingTop: 50,
     height:'100%'
  
  },
  OuterMainQuote:{
    marginTop:-20,
  },
    ProfilePic:{
    flexDirection:'row',
    alignItems:'flex-end',
    zIndex:2,
  },
  ContentHeadStyle:{
    fontSize:24,
    fontFamily:'Aclonica',
    fontWeight:'300',
    lineHeight:45,
    color:'#FD6F01',
    textAlign:'right',
  },
  ContentInnrtStyle:{
    color:'#ffffff',
  },
  ArrowTop:{
    width:40,
    height:20,
    borderColor:'#ffffff',
    borderTopWidth:1,
    borderLeftWidth:1,
    marginLeft:20,
    transform: [{ skewY: '23deg' }],
    zIndex:2,
    backgroundColor: '#FF9228',
  },
  MainQuoteSec:{
    backgroundColor: '#FF9228',
    borderRadius:6,
    paddingLeft: AppStyle.appLeftPadding,
    paddingRight: AppStyle.appRightPadding,
    paddingBottom: 20,
    paddingTop: 50,
    marginTop:-30,
  },
  MqsTextSec:{
    fontSize:18,
    fontFamily: 'Abel',
    fontWeight:'400',
    lineHeight: 26,
    color:'#ffffff',
    textAlign:'left',
    borderWidth:1,
    borderColor:'#ffffff',
    padding: 15,
    marginTop:-10,
    backgroundColor: '#FF9228',
  },
  SocialMediaSec:{
    textAlign:'center',
    width:'100%',
    marginTop: 40,
    borderWidth:1,
    borderColor:'#E8E6EA',
    borderRadius:6,
  },
  TextHeading:{
    marginTop: -23,
    zIndex:2,
    display: 'flex',
    justifyContent:'center',
    paddingLeft:60,
    paddingRight: 60,
  },
  ShareText:{
    backgroundColor:'#ffffff',
    padding: 5,
    textAlign:'center',
    fontSize:21,
    fontFamily: 'Abel',
    fontWeight:'400',
    lineHeight: 32,
    color: '#000000',
  },
  SmIcons:{
    paddingLeft:50,
    paddingRight: 50,
    marginBottom: 15,
  },
  SocialIconBg:{
    backgroundColor:'#FDF0E6',
    borderRadius:6,
    flexDirection:'row',
    alignItems:'center',
    marginTop: 10,
  },
  IconImgSec:{
    borderRightWidth:1,
    borderColor:'#FFD3A9',
    paddingTop: 10,
    paddingBottom: 10,
    paddingLeft: 15,
    paddingRight: 15,
  },
  IconTxtSec:{
    padding: 10,
  },
  IcTxt:{
    fontSize:16,
    fontFamily: 'Abel',
    fontWeight:'400',
    lineHeight: 26,
    color: '#000000',
  },
  cookieLogo:{
    position:'absolute',
    right: 15,
    bottom: 15,
  },

});