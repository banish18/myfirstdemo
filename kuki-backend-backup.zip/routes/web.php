<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/logout', '\App\Http\Controllers\Auth\LoginController@logout');
Route::group(['middleware' => 'auth'], function () {
    Route::get('/dashboard', [App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('dashboard');
    /* Community */
    Route::get('/communities', [App\Http\Controllers\Admin\CommunityController::class, 'index'])->name('communities');
    Route::post('/save-community', [App\Http\Controllers\Admin\CommunityController::class, 'saveCommunity'])->name('saveCommunity');
    Route::post('/get-community', [App\Http\Controllers\Admin\CommunityController::class, 'getCommunity'])->name('getCommunity');
    Route::post('/delete-community', [App\Http\Controllers\Admin\CommunityController::class, 'deleteCommunity'])->name('deleteCateogry');

    /* Category */
    Route::get('/community-category', [App\Http\Controllers\Admin\CategoryController::class, 'index'])->name('category');
    Route::post('/save-category', [App\Http\Controllers\Admin\CategoryController::class, 'saveCatogry'])->name('saveCatogory');
    Route::post('/get-category', [App\Http\Controllers\Admin\CategoryController::class, 'getCateogry'])->name('getCatogory');
    Route::post('/delete-category', [App\Http\Controllers\Admin\CategoryController::class, 'deleteCateogry'])->name('deleteCateogry');

    /* Posts */
    Route::get('/posts', [App\Http\Controllers\Admin\PostController::class, 'index'])->name('posts');
    Route::post('/save-post', [App\Http\Controllers\Admin\PostController::class, 'savePost'])->name('savePost');
    Route::post('/get-post', [App\Http\Controllers\Admin\PostController::class, 'getPost'])->name('getPost');
    Route::post('/delete-post', [App\Http\Controllers\Admin\PostController::class, 'deletePost'])->name('deletePost');
    Route::post('/update-post-status', [App\Http\Controllers\Admin\PostController::class, 'updatePostStatus'])->name('deletePost');
    
    Route::get('/users', [App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('users');
    //add more Routes here
});