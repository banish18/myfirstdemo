<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Category;
use Session;
class CategoryController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $data = Category::all();
        return view('admin/community/category/index', compact('data'));
    }

    public function saveCatogry(Request $request){
        if($request->parent_id == ''){
            $data  = array('name' => $request->name,'description' => $request->description );
        }else{
            $data  = array('name' => $request->name,'description' => $request->description,'parent_id' => $request->parent_id );
        }
        
        if($request->action == 'add'){
            $category = Category::insert($data);
            Session::flash('alert-success', 'Category added successfully!');
        }else{
            $category = Category::where('id',$request->id)->update($data);
            Session::flash('alert-success', 'Category udpated successfully!');
        }
        
        return json_encode(array('status' => 1)); 
    }

    public function getCateogry(Request $request){
        $category = Category::find($request->id);
        if($category){
            return json_encode(array('category' => $category,'status' => 1)); 
        }else{
            return json_encode(array('category' => [],'status' => 0)); 
        }
        
    }

    public function deleteCateogry(Request $request){
        Category::where('id',$request->id)->delete();
        Session::flash('alert-success', 'Category deleted successfully!');
        return json_encode(array('status' => 1));
    }

    
}
