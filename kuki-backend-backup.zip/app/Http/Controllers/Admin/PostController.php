<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Post;
use Session;
class PostController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $data = Post::all();
        return view('admin/community/posts/index', compact('data'));
    }

    public function savePost(Request $request){
        $data  = array('name' => $request->name,'description' => $request->description );
        
        $category = Post::where('id',$request->id)->update($data);
        Session::flash('alert-success', 'Post udpated successfully!');
    
        return json_encode(array('status' => 1)); 
    }

    public function getPost(Request $request){
        $post = Post::find($request->id);
        if($post){
            return json_encode(array('post' => $post,'status' => 1)); 
        }else{
            return json_encode(array('post' => [],'status' => 0)); 
        }
    }

    public function updatePostStatus(Request $request){
        Post::where('id',$request->id)->update(array('status',$request->status));
        Session::flash('alert-success', 'Post updated successfully!');
        return json_encode(array('status' => 1));
    }

    public function deletePost(Request $request){
        Post::where('id',$request->id)->delete();
        Session::flash('alert-success', 'Post deleted successfully!');
        return json_encode(array('status' => 1));
    }

    
}
