<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Community;
use App\Models\Category;
use Session;

class CommunityController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $categories = Category::all();
        $data = Community::with('category')->get();

        return view('admin/community/index', compact('data','categories'));
    }

    public function saveCommunity(Request $request){
        $data  = array('name' => $request->name,'description' => $request->description,'category_id' => $request->category_id );
        
        if($request->action == 'add'){
            $category = Community::insert($data);
            Session::flash('alert-success', 'Community added successfully!');
        }else{
            $category = Community::where('id',$request->id)->update($data);
            Session::flash('alert-success', 'Community udpated successfully!');
        }
        
        return json_encode(array('status' => 1)); 
    }

    public function getCommunity(Request $request){
        $community = Community::find($request->id);
        if($community){
            return json_encode(array('community' => $community,'status' => 1)); 
        }else{
            return json_encode(array('community' => [],'status' => 0)); 
        }
        
    }

    public function deleteCommunity(Request $request){
        Community::where('id',$request->id)->delete();
        Session::flash('alert-success', 'Community deleted successfully!');
        return json_encode(array('status' => 1));
    }

}
