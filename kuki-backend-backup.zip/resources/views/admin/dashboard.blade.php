@extends('layouts.admin')

@section('content')
  <div class="content-wrapper content-wrapper--with-bg">
	<div class="page-content">
	  <div class="one">
		<div class="row">
			<div class="col-lg-12">
				<div class="alert alert-danger text-center" role="alert">
				  <strong>Heads up!</strong> This alert needs your attention, but it's not super important.
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="card card-stats" data-border-color="sea-green">
					<div class="card-header" data-background-color="sea-green">
						<i class="fas fa-home"></i>
					</div>
					<div class="card-content">
						<h1 class="title">896</h1>
					</div>
					<div class="card-footer">
						<div class="stats">
							<a href="#">
							  <h5 class="title">EMPLOYEES STATUS</h5>
							  <p>Rozar Fadrence</p>
							</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="card card-stats" data-border-color="orange">
					<div class="card-header" data-background-color="orange">
						<i class="fa fa-briefcase"></i>
					</div>
					<div class="card-content">
						<h1 class="title">765</h1>
					</div>
					<div class="card-footer">
						<div class="stats">
							<a href="#">
							  <h5 class="title">EMPLOYEES STATUS</h5>
							  <p>Rozar Fadrence</p>
							</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="card card-stats" data-border-color="red">
					<div class="card-header" data-background-color="red">
						<i class="fa fa-beer"></i>
					</div>
					<div class="card-content">
						<h1 class="title">987</h1>
					</div>
					<div class="card-footer">
						<div class="stats">
							<a href="#">
							  <h5 class="title">EMPLOYEES STATUS</h5>
							  <p>Rozar Fadrence</p>
							</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6 bod-bot">
				<div class="card card-stats" data-border-color="green">
					<div class="card-header" data-background-color="green">
						<i class="fa fa-globe"></i>
					</div>
					<div class="card-content">
						<h1 class="title">567</h1>
					</div>
					<div class="card-footer">
						<div class="stats">
							<a href="#">
							  <h5 class="title">EMPLOYEES STATUS</h5>
							  <p>Rozar Fadrence</p>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6 col-md-12">
				<div class="card" data-border-color="blue">
					<div class="card-header" data-background-color="blue">
						<h5 class="title">Project gantt chart</h5>
					</div>
					<div class="card-content table-responsive">
						<table class="table table-hover">
							<img src="images/table_updated.png" alt="table" class="img-responsive">
						</table>
					</div>
				</div>
			</div>
			<div class="col-lg-6 col-md-12">
				<div class="card" data-border-color="purple">
					<div class="card-header" data-background-color="purple">
						<h5 class="title">Current Phase</h5>
					</div>
					<div class="card-content table-responsive">
						<table class="table table-hover">
							<thead class="">
								<tr>
									<th>NAME</th>
									<th>PHASE</th>
									<th>TYPE</th>
									<th><center>view</center></th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Lily fadrence</td>
									<td>Basement</td>
									<td>Setum Dolar</td>
									<td align="center"><i class="fa fa-eye"></i></td>
								</tr>
								<tr>
									<td>Minerva Hooper</td>
									<td>Wall</td>
									<td>Dolar Setum</td>
									<td align="center"><i class="fa fa-eye"></i></td>
								</tr>
								<tr>
									<td>Sage Rodriguez</td>
									<td>Roof</td>
									<td>$56,142</td>
									<td align="center"><i class="fa fa-eye"></i></td>
								</tr>
								<tr>
									<td>Philip Chaney</td>
									<td>Plumbing</td>
									<td>Setum Dolar</td>
									<td align="center"><i class="fa fa-eye"></i></td>
								</tr>
								<tr>
									<td>Devesco Disuza</td>
									<td>Electric</td>
									<td>Dolar Setum</td>
									<td align="center"><i class="fa fa-eye"></i></td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	  </div>
	</div>
  </div>
@endsection