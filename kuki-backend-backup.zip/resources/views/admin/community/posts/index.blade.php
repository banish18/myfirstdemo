@extends('layouts.admin')

@section('content')
 
<div class="content-wrapper content-wrapper--with-bg">
<div class="page-content">
  <div class="one">
	<div class="row mb-4">
		<div class="col-lg-6">
			<div class="alert shadow text-uppercase hidden-xs-down gap-25" role="alert">
			  <span class="right-15">Communities Posts</span> 
			</div>
		</div>
		<div class="col-lg-6">
			<div class="flash-message">
			  @foreach (['danger', 'warning', 'success', 'info'] as $msg)
			    @if(Session::has('alert-' . $msg))
			    <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}</p>
			    @endif
			  @endforeach
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">

			<div class="card" data-border-color="blue">
				<div class="card-header" data-background-color="blue">
					<div class="row">
						<div class="col-lg-10">
							<h5 class="title">Communities Posts Records</h5>
						</div>
					</div>
				</div>
				<div class="card-content ds-responsive-tables">
					<table class="table table-hover table-striped" id="post_table">
						<thead class="">
							<tr>
								<th>ID</th>
								<th>Title</th>
								<th>Description</th>
								<th>Attachments</th>
								<th>Images</th>
								<th><center>ACTIONS</center></th>
							</tr>
						</thead>
						<tbody>
							@forelse($data as $post)
								<tr>
									<td>{{$post->id}}</td>
									<td>{{$post->title}}</td>
									<td>{{$post->description}}</td>
									<td>{{$post->attachements}}</td>
									<td>{{$post->images}}</td>
									<td align="center" data-title="Actions">
										<a href="javascript:void(0)"><i class="fa fa-edit green-txt" onclick="getPost({{$post->id}})"></i></a>
										<a onclick="deactivatePost({{$post->id}})" href="javascript:void(0)"><i class="fa fa-trash red-txt"></i></a>
										<a onclick="deletePost({{$post->id}})" href="javascript:void(0)"><i class="fa fa-trash red-txt"></i></a>
									</td>
								</tr>
							@empty
							@endforelse
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
  </div>
</div>
</div>

<script type="text/javascript">
	function getPost(id){
		alert(id);
		$.ajax({
			url: "{{ url('/get-post') }}",
			method: 'post',
			data: {
			   id: id,
			   "_token": "{{ csrf_token() }}",
		},
		success: function(result){
		  var obj = jQuery.parseJSON(result);
		  if(obj.status == 1){
		    $('#id').val(obj.id);
		    $('#title').val(obj.name);
		    $('#description').val(obj.description);
		   
		    $('#action').val('update');
		    $('#updatePost').modal('show');
		  }else{
		    alert('something went wrong!');
		  }
		}
		});
  }
</script>

@endsection

<!--Add Category Modal -->
<div class="modal fade" id="updatePost" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Update Post</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="cat-form">
		  <div class="form-group">
		    <label for="name">Title</label>
		    <input type="text" class="form-control" id="title" placeholder="" autocomplete="off" required>
		  </div>
		  <div class="form-group">
		    <label for="description">Description</label>
		    <input type="text" class="form-control" id="description" placeholder="" autocomplete="off" required>
		  </div>
		  <input type="hidden" id="action" value="update" autocomplete="off"/>
		  <input type="hidden" id="id" value=""/>
		  <input type="hidden" id="parent_id" value=""/>
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" id="save-post" class="btn btn-primary">Save</button>
      </div>
    </div>
  </div>
</div>

