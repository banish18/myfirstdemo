@extends('layouts.admin')

@section('content')
 
<div class="content-wrapper content-wrapper--with-bg">
<div class="page-content">
  <div class="one">
	<div class="row mb-4">
		<div class="col-lg-6">
			<div class="alert shadow text-uppercase hidden-xs-down gap-25" role="alert">
			  <span class="right-15">Communities</span> 
			</div>
		</div>
		<div class="col-lg-6">
			<div class="flash-message">
			  @foreach (['danger', 'warning', 'success', 'info'] as $msg)
			    @if(Session::has('alert-' . $msg))
			    <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}</p>
			    @endif
			  @endforeach
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12">

			<div class="card" data-border-color="blue">
				<div class="card-header" data-background-color="blue">
					<div class="row">
						<div class="col-lg-10">
							<h5 class="title">Communities Records</h5>
						</div>
						<div class="col-lg-2">
							<a class="btn btn-danger btn-lg btn-block" onclick="opencommunityModal()">Add New</a>
						</div>
					</div>
				</div>
				<div class="card-content ds-responsive-tables">
					<table class="table table-hover table-striped" id="community_table">
						<thead class="">
							<tr>
								<th>ID</th>
								<th>Name</th>
								<th>Category</th>
								<th>Description</th>
								<th><center>ACTIONS</center></th>
							</tr>
						</thead>
						<tbody>
							@forelse($data as $community)
								<tr>
									<td>{{$community->id}}</td>
									<td>{{$community->name}}
	
									</td>
									<td>{{$community->category->name}}</td>
									<td>{{$community->description}}</td>
									
									<td align="center" data-title="Actions">
										
										<a href="javascript:void(0)"><i class="fa fa-edit green-txt" onclick="getCommunity({{$community->id}})"></i></a>
										<a onclick="deleteCommunity({{$community->id}})" href="javascript:void(0)"><i class="fa fa-trash red-txt"></i></a>
									</td>
								</tr>
							@empty
							@endforelse
							
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
  </div>
</div>
</div>

@endsection

<!--Add Category Modal -->
<div class="modal fade" id="addCommunity" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Add Community</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="cat-form">
		  <div class="form-group">
		    <label for="name">Name</label>
		    <input type="text" class="form-control" id="name" placeholder="" autocomplete="off" required>
		  </div>
		  <div class="form-group">
		    <label for="name">Category</label>
		    <select id="category_id" class="form-control">
		    	<option value="">Select Category</option>
		    	@forelse($categories as $category)
		    	<option value="{{$category->id}}">{{$category->name}}</option>
		    	@empty
		    	@endforelse

		    </select>
		  </div>
		  <div class="form-group">
		    <label for="description">Description</label>
		    <input type="text" class="form-control" id="description" placeholder="" autocomplete="off" required>
		  </div>
		  <input type="hidden" id="action" value="add" autocomplete="off"/>
		  <input type="hidden" id="id" value=""/>
		  <input type="hidden" id="parent_id" value=""/>
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" id="save-community" class="btn btn-primary">Save</button>
      </div>
    </div>
  </div>
</div>

