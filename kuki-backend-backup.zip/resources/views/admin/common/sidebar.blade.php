<!--=======================
       SIDEBAR START
    ========================-->
    <div class="flex-parent">
    <div class="l-sidebar__content">
      <nav class="c-menu js-menu">
        <ul class="u-list shadow">
          <li class="c-menu__item is-active" data-toggle="tooltip" title="Dashboard">
            <div class="c-menu__item__inner"><i class="fas fa-tachometer-alt"></i>
              <div class="c-menu-item__title"><a href="{{route('dashboard')}}"><span>Dashboard</span></a></div>
            </div>
          </li>
          <!--li class="c-menu__item has-submenu" data-toggle="tooltip" title="Profile Management">
            <div class="c-menu__item__inner"><i class="fas fa-user-circle"></i>
              <div class="c-menu-item__title"><span>User Management</span></div>
              <div class="c-menu-item__expand js-expand-submenu"><i class="fa fa-angle-down"></i></div>
            </div>
            <ul class="c-menu__submenu u-list">
              <li>Users</li>
            </ul>
          </li-->
         
          <li class="c-menu__item has-submenu" data-toggle="tooltip" title="Project">
            <div class="c-menu__item__inner"><i class="fas fa-building"></i>
              <div class="c-menu-item__title"><span>Community Management</span></div>
              <div class="c-menu-item__expand js-expand-submenu"><i class="fa fa-angle-down"></i></div>
            </div>
            <ul class="c-menu__submenu u-list">
              <li><a href="{{route('category')}}">Category</a></li>
              <li><a href="{{route('communities')}}">Communities</a></li>
              <li><a href="{{route('posts')}}">Posts</a></li>
            </ul>
          </li>
          
        </ul>
      </nav>
    </div>
    </div>
    <!--=======================
       SIDEBAR CLOSE
    ========================-->  