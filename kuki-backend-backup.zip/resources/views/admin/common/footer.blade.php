<!--=======================
       FOOTER START
    ========================-->
    <footer class="footer text-center shadow">
    <p> &copy; 2018 BuildWhiz - All right Reserved</p>
    </footer>
    <!--=======================
           FOOTER CLOSE
    ========================-->

     <!-- Scripts -->
    
     <!-- jQuery (necessary for Bootstrap's JavaScript plugins)-->
    <script src="{{ asset('admin/js/jquery.min.js') }}"></script> 
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="{{ asset('admin/js/bootstrap.min.js') }} "></script>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script>
    $(".hamburger-toggle").click(function(){
        $("body").toggleClass("sidebar-is-reduced sidebar-is-expanded");
        $(".hamburger-toggle").toggleClass("is-opened");
    });
    
    $(".hamburger-toggle-2").click(function(){
        $("body").toggleClass("sidebar-is-reduced-2 sidebar-is-expanded-2");
        $(".hamburger-toggle-2").toggleClass("is-opened-2");
    });
    
    $(".js-menu li").click(function(){
    //$(this).siblings().removeClass("active");
    $('.fa-angle-up').removeClass('fa-angle-up').addClass('fa-angle-down');
    if($(this).find('.c-menu__submenu:visible').length == 0)
      {
         $(this).find('.fa-angle-down').removeClass('fa-angle-down').addClass('fa-angle-up');
      }
      else
      {
        $(this).find('.fa-angle-up').removeClass('fa-angle-up').addClass('fa-angle-down');
      }
        $(".c-menu__item").removeClass("is-active");
        $(this).addClass("is-active");
        $('.js-menu li').not(this).find('ul').hide();
        $(this).find(".c-menu__submenu").toggle();
    });
    $(".one").scroll(function() { 
        var scroll = $(".one").scrollTop();
        if (scroll >= 50) {
            $(".header").addClass("change");
        }
        else
        {
            $(".header").removeClass("change");
        }
    });

  function openModal(){
    $('#id').val('');
    $('#name').val('');
    $('#description').val('');
    $('#action').val('add');
    $('#addCategory').modal('show');
  }

   function opencommunityModal(){
    $('#id').val('');
    $('#name').val('');
    $('#description').val('');
    $('#category_id').val('');
    $('#action').val('add');
    $('#addCommunity').modal('show');
  }
  $(document).ready(function(){
     $('#community_table').DataTable();
     $('#category_table').DataTable();
  });
  $('#save-category').click(function(e){
    var cat_name = $('#name').val(); 
    var cat_description = $('#description').val(); 

    if(cat_name == ''){
      alert('Please Enter Category Name!');
      return false;
    }
    if(cat_description == ''){
      alert('Please Enter Category Description!');
      return false;
    }
    var get_action = $('#action').val(); 
    var id = $('#id').val(); 
    e.preventDefault();
      $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
        }
      });
      $.ajax({
        url: "{{ url('/save-category') }}",
        method: 'post',
        data: {
           name: cat_name,
           description: cat_description,
           id: id,
           action: get_action,
           "_token": "{{ csrf_token() }}",
        },
        success: function(result){
          console.log(result);
          var obj = jQuery.parseJSON(result);
          if(obj.status == 1){
            $('#addCategory').modal('hide');
            location.reload();
          }
        }
      });
  });

  function getCategory(id){
    $.ajax({
        url: "{{ url('/get-category') }}",
        method: 'post',
        data: {
           id: id,
           "_token": "{{ csrf_token() }}",
        },
        success: function(result){
          var obj = jQuery.parseJSON(result);
          if(obj.status == 1){
            $('#id').val(obj.category.id);
            $('#name').val(obj.category.name);
            $('#description').val(obj.category.description);
           
            $('#action').val('update');
            $('#addCategory').modal('show');
          }else{
            alert('something went wrong!');
          }
        }
      });
  }
  function deleteCategory(id){
    $.ajax({
        url: "{{ url('/delete-category') }}",
        method: 'post',
        data: {
           id: id,
           "_token": "{{ csrf_token() }}",
        },
        success: function(result){
          var obj = jQuery.parseJSON(result);
          if(obj.status == 1){
            location.reload();
          }else{
            alert('something went wrong!');
          }
        }
      });
  }

  $('#save-community').click(function(e){
    var name = $('#name').val(); 
    var description = $('#description').val(); 
    var category_id = $('#category_id').val(); 
    var get_action = $('#action').val(); 

    if(name == ''){
      alert('Please Enter Community Name!');
      return false;
    }
    if(category_id == ''){
      alert('Please Select Community Category!');
      return false;
    }
    if(description == ''){
      alert('Please Enter Community Description!');
      return false;
    }
    
    var id = $('#id').val(); 
    e.preventDefault();
      $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
        }
      });
      $.ajax({
        url: "{{ url('/save-community') }}",
        method: 'post',
        data: {
           name: name,
           description: description,
           category_id: category_id,
           id: id,
           action: get_action,
           "_token": "{{ csrf_token() }}",
        },
        success: function(result){
          console.log(result);
          var obj = jQuery.parseJSON(result);
          if(obj.status == 1){
            $('#addCommunity').modal('hide');
            location.reload();
          }
        }
      });
  });

  function getCommunity(id){
    $.ajax({
        url: "{{ url('/get-community') }}",
        method: 'post',
        data: {
           id: id,
           "_token": "{{ csrf_token() }}",
        },
        success: function(result){
          var obj = jQuery.parseJSON(result);
          if(obj.status == 1){
            $('#id').val(obj.community.id);
            $('#name').val(obj.community.name);
            $('#description').val(obj.community.description);
            $('#category_id').val(obj.community.category_id);
            $('#action').val('update');
            $('#addCommunity').modal('show');
          }else{
            alert('something went wrong!');
          }
        }
      });
  }

  function deleteCommunity(id){
    $.ajax({
        url: "{{ url('/delete-community') }}",
        method: 'post',
        data: {
           id: id,
           "_token": "{{ csrf_token() }}",
        },
        success: function(result){
          var obj = jQuery.parseJSON(result);
          if(obj.status == 1){
            location.reload();
          }else{
            alert('something went wrong!');
          }
        }
      });
  }

    </script>