<header class="l-header shadow">
    <nav class="navbar navbar-expand-lg navbar-light bg-faded">
        <div class="c-header-icon row js-hamburger">
            <div class="hamburger-toggle"><span class="bar-top"></span><span class="bar-mid"></span><span class="bar-bot"></span></div>
        </div>
        <a class="navbar-brand" href="#index.html">Kuki<span class="tagline">Fortune/Wisdom Cookies</span></a>
        <div class="navbar-toggler c-header-icon-2 row" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger-toggle-2"><span class="bar-top"></span><span class="bar-mid"></span><span class="bar-bot"></span></div>
        </div>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">   
            <ul class="navbar-nav">
               
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <div class="c-header-icon"><span class="c-badge c-badge--header-icon animated shake">0</span><i class="far fa-bell"></i></div>
                    </a>
                </li>
               
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <div class="c-header-icon with-name">
                            <div class="float-left ds-admin left-15">
                              <img src="images/admin.png" class="img-fluid" alt=""/>
                            </div>
                            <div class="float-left left-15 right-15">
                              <h5 class="" href="#index.html">{{auth()->user()->name}}</h5>
                              <p class="">Administrator</p>
                            </div>
                        </div>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <a class="dropdown-item" href="#">Edit profile</a>
                        <a class="dropdown-item" href="{{ route('logout') }}">Logout</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
    </header>