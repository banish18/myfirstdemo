@extends('layouts.app')

@section('content')
<div class="ds-center transform navbar-light">
        <a class="navbar-brand" href="#index.html">Kuki<span class="tagline">Connect with people</span></a>
        <hr>
        
        <form class="form-signin" method="POST" action="{{ route('login') }}">
                        @csrf    
            <span id="reauth-email" class="reauth-email"></span>
            <input  id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus placeholder="Enter Email">
             @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password" placeholder="Enter Password" required>
             <!--input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                                    <label class="form-check-label" for="remember">
                                        {{ __('Remember Me') }}
                                    </label-->
            
             <button type="submit" class="btn btn-lg ds-btn text-uppercase" >
                                    {{ __('Login') }}
                                </button>

                                @if (Route::has('password.request'))
                                    <a class="btn btn-link forgetPassword" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif
        </form><!-- /form -->
    </div>
