<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Kuki') }}</title>

   
    <link href="{{ asset('admin/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('admin/css/fontawesome-all.css') }} " rel="stylesheet">
     <link href="{{ asset('admin/css/custom.css') }} " rel="stylesheet">
     <link href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" rel="stylesheet">
   
</head>
<body>
    <!--=======================
       HEADER START
    ========================-->
    @include('admin.common.header')
    
    <!--=======================
       HEADER CLOSE
    ========================-->
     @include('admin.common.sidebar')
    <div id="app">
        <main class="l-main">
            @yield('content')
        </main>
    </div>
    @include('admin.common.footer')
</body>
</html>
