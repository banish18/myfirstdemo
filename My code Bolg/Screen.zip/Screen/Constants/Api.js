export default  {
	apiUrl:'https://apikuki.kukiapp.com/api',
	apiAudioUrl:'https://apikuki.kukiapp.com/storage/app/public/uploads/audio/',
	
	imgaePath: 'https://apikuki.kukiapp.com/storage/app/public/user-gallery/',
	userPostGallery: 'https://apikuki.kukiapp.com/storage/app/public/user-posts-gallery/',
	fcmToken:''
}