# while b=1
# do
# a=`ps -ef|grep -v grep|grep "cron.php"|wc -l`
# if [a -gt 1]
# then
# sleep 1
# else
# sh /home/sa201605/public_html/session-api/cron.php
# fi
# done
# exit

nohup email.php >> /dev/null &