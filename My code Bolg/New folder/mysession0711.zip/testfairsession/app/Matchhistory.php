<?php



namespace App;



use Illuminate\Foundation\Auth\User as Authenticatable;



class Matchhistory extends Authenticatable

{

   protected $table = 'match_history';

}

