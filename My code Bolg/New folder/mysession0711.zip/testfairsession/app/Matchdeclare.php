<?php



namespace App;



use Illuminate\Foundation\Auth\User as Authenticatable;



class Matchdeclare extends Authenticatable

{

   protected $table = 'match_declare';

}

