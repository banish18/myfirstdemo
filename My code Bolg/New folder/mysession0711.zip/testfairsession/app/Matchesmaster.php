<?php



namespace App;



use Illuminate\Foundation\Auth\User as Authenticatable;



class MatchesMaster extends Authenticatable

{

   protected $table = 'matches';

}

