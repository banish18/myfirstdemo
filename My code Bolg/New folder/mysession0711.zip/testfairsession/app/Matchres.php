<?php



namespace App;



use Illuminate\Foundation\Auth\User as Authenticatable;



class Matchres extends Authenticatable

{

   protected $table = 'match_res';

}

