<?php
namespace App\Http\Controllers;
use Auth;
?>
<!-- Navigation -->
				<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<a class="navbar-brand" href="{{ url('/dashboard') }}">
						@if(Auth::User()->user_type == "1")
							Session Super Admin
						@else
							Session Admin
						@endif
						
						</a>
					</div>
					<!-- /.navbar-header -->

					<ul class="nav navbar-top-links navbar-right">	
					@if(Auth::User()->user_type == "1")
							<li><span class="icon-bar sus_btn" onclick="susspendallSession()">Susspend All Session</span></li>
						@endif
					
						<!--li class="dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" href="#">
								<i class="fa fa-envelope fa-fw"></i>  <i class="fa fa-caret-down"></i>
							</a>
							<ul class="dropdown-menu dropdown-messages">
								<li>
									<a href="#">
										No Records
									</a>
								</li>
								<li class="divider"></li>

							</ul>
						
						</li>
						
						<li class="dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" href="#">
								<i class="fa fa-tasks fa-fw"></i>  <i class="fa fa-caret-down"></i>
							</a>
							<ul class="dropdown-menu dropdown-tasks">
								<li>
									<a href="#">
										No Recors
									</a>
								</li>
								<li class="divider"></li>
							</ul>
							
						</li>
						
						<li class="dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" href="#">
								<i class="fa fa-bell fa-fw"></i>  <i class="fa fa-caret-down"></i>
							</a>
							<ul class="dropdown-menu dropdown-alerts">
								<li>
									<a href="#">
										No Records
									</a>
								</li>
								<li class="divider"></li>
							</ul>
							
						</li-->
						<!-- /.dropdown -->
						<li class="dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" href="#">
								<i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
							</a>
							<ul class="dropdown-menu dropdown-user">
								<li><a href="{{ url('changeUPassword') }}"><i class="fa fa-pencil-square-o"></i>Change Password</a>
								</li>
								<li class="divider"></li>
								<li><a href="{{ url('/logout') }}"><i class="fa fa-btn fa-sign-out"></i>Logout</a>
								</li>
							</ul>
							<!-- /.dropdown-user -->
						</li>
						<!-- /.dropdown -->
					</ul>
					<!-- /.navbar-top-links -->

				@include('templates/admin-sidebar')