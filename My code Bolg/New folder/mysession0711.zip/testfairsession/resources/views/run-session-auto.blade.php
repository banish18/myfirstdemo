@extends('layouts.app')
@section('content')
@include('templates/admin-header')
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<!-- /.panel-heading -->
			<div class="panel-body">
			<section class="seccess">
					@if(Session::has('flash_message'))
						<div class="alert alert-success"><em> {!! session('flash_message') !!}</em></div>
					@endif
				</section>
			{!! csrf_field() !!}
				<div class="table-responsive">
				<div class="my-session">
							<h3>Run Session</h3>
						</div>
					<table class="table">
						<thead>
							<th>#</th>
							<th>Description</th>
							<th>Status</th>
							<th>Runs</th>
							<th>Action</th>
						</thead>
						<?php $i = 1; ?>
						<tbody>
							@foreach($Sessions as $session)
								@if($session->action == 1)
									<?php $status = "Created"; ?>
									@elseif($session->action == 2 && $session->isActive == 1)
										<?php $status = "Running,Suspended"; ?>
									@elseif($session->action == 3 && $session->isActive == 1)
										<?php $status = "Running,Suspended"; ?>	
									@elseif($session->action == 3 && $session->isActive == 0)
										<?php $status = "Running,Running Live"; ?>	
									@elseif($session->action == 4 && $session->isActive == 1)	
										<?php $status = "Declared"; ?>
									@else	
										<?php $status = "Suspended"; ?>
								@endif	
								<tr  class="diff-sess active_bg_open"><td>{{ $session->id }}</td>
								<td onclick="showautoPopRs(this,'{{ $session->id }}')">{{ $session->over }}</td>
								<td onclick="showautoPopRs(this,'{{ $session->id }}')">{{ $status }}</td>
								<td onclick="showautoPopRs(this,'{{ $session->id }}')">{{ $session->amount }}</td>
								@if($session->select_val == "0_0" && $session->isActive == "0")
									<td><a class="diff-sess slide_open" href="javascript:void(0)" onclick="updatesessStat('{{$session->sess_rate}}','{{$session->id}}')">Suspend</span></td>
								@else
									<td>No Running Session</td>
								@endif	
								</tr>
								<?php $i++; ?>
								
							@endforeach 
						</tbody>   
					</table>
				</div>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div id="active_bg" class="auto_rates_dv"> 
		<div id="atabs">
			<ul>
				<li><a href="#auto" onclick="getAllMtch()">Auto Rates</a></li>
			</ul>
			<div id="auto">
				<div class="auto-rates-content">
				
				</div>
				<input type="hidden" id="sess_id" />
				<input type="hidden" id="mktId" />
				<input type="hidden" id="auto_rt" />
			</div>
		</div>
		</div>
		<div id="ausess_slide" class="at_Rt" style="display:none;">
			<div class="sess_slide at_Rt">
				<div class="alrt_msg" id="alrt_msg"></div>
				<p><input type="button" id="savert" value="Run Session" onclick="saveSessrt(this)"/></p>
				<br />
			</div>
		</div>
		<div id="slide" style="display:none;">    
			<div class="sess_slide">
				<div class="alrt_msg" id="alrt_msg"></div>
				<p><h2 id="s_rte"></h2></p>
				<p><input type="button" value="Suspend" onclick="suspendSess()"/></p>
				<br /><p><button class="slide_close btn btn-default">Close</button></p>
				<input type="hidden" id="au_sess_id" />
			</div>
		</div> 
		<div id="cover"> </div> 
		
		<div class="loading_img rn_ldimg">
			<img src="{{ asset('assets/clock-loading.gif')}}" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>

{!! Html::script('assets/admin/js/angular.js') !!}
<script>
 
 var app = angular.module('plunker', []);

        app.controller('MainCtrl', ['$scope', '$interval', function($scope, $interval) {
          var interval = $interval(function() {
               var at = jQuery("#auto_rt").val();
			   var slrt = jQuery("#mktId").val();
			   if(slrt != ""){
				    getRtauto(at,slrt);
			   }else{
				   return true;
			   }
				
            }, 2000);
        }]); 
</script>
 
@include('templates/admin-footer')
   
@endsection

