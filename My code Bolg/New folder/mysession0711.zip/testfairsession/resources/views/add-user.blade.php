@extends('layouts.app')
@section('content')
@include('templates/admin-header')
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			     <section class="content-header">
                    <h1>Add User</h1>
                    <ol class="breadcrumb">
                        <li><a href="{{ url('dashboard') }}"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Add User</li>
                    </ol>
                </section>
			</div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				 <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
              

                <!-- Main content -->
				@if (!empty($errors) && count($errors) > 0)
				 <ul>
				  @foreach ($errors->all() as $error)
				   <li>{{ $error }}</li>
				  @endforeach
				 </ul>
				@endif 
                
                <section class="content">
                    <div class='row'>
                    <div class='col-lg-12'>
               {!! Form::open(array('route' => 'add-post-user','method' => 'post','class'=>'form-horizontal','role'=>'form','autocomplete'=>'on','id' => 'lgform','data-toggle'=>"validator")) !!}
					{!! csrf_field() !!}
                    <div class='col-lg-12'>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Name:</label>
							<div class="col-lg-6">
								{!! Form::text('name','',$attributes = array("class"=>"form-control","id"=>"inputEmail3","placeholder"=>"Name",'required' => 'true')) !!}
							</div>
						</div>
						@if($user->user_type == 1 || $user->co_ad == 1)
							<div class="form-group">
								<label for="inputEmail3" class="col-lg-3 control-label ">Email:</label>
								<div class="col-lg-6">
									{!! Form::text('email','',$attributes = array("class"=>"form-control","id"=>"inputUserid3","placeholder"=>"Email",'required' => 'true')) !!}
								</div>
							</div>
						@endif
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Mobile:</label>
							<div class="col-lg-6">
								{!! Form::text('mobile','',$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Mobile",'required' => 'true')) !!}                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Password:</label>
							<div class="col-lg-6">
								{!! Form::text('password','',$attributes = array("class"=>"form-control","id"=>"inputPassword3","placeholder"=>"Password",'required' => 'true')) !!}                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Confirm Password:</label>
							<div class="col-lg-6">
								{!! Form::text('password_confirmation','',$attributes = array("class"=>"form-control","id"=>"inputPassword3","placeholder"=>"Confirm Password",'required' => 'true')) !!}                             
							</div>
						</div>
						@if($user->user_type == 1)
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Limit:</label>
							<div class="col-lg-6">
								{!! Form::text('limit',7,$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Limit",'required' => 'true')) !!}                             
							</div>
						</div>
						@endif
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Credit:</label>
							<div class="col-lg-6">
								{!! Form::text('credit',$balance,$attributes = array("class"=>"form-control","id"=>"ucredit","placeholder"=>"Credit","onkeyup"=>"setRate()" ,'disabled')) !!}                             
							</div>
						</div>	
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Rate:</label>
							<div class="col-lg-6">
								{!! Form::text('rate','',$attributes = array("class"=>"form-control","id"=>"urate","placeholder"=>"Rate","onkeyup"=>"setRate()",'required' => 'true')) !!}                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Amount:</label>
							<div class="col-lg-6">
								{!! Form::text('amt','',$attributes = array("class"=>"form-control","id"=>"uamount","placeholder"=>"Amount",'disabled')) !!}  
                           
								<input type="hidden" name="amount" id="amount" value="{{$user->amount}}" />
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Comm1:</label>
							<div class="col-lg-6">
								{!! Form::text('comm_1','',$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Comm1")) !!}                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Comm1 User:</label>
							<div class="col-lg-6">
								<select name="comm1_user" class="form-control com_user1" onchange="changeCom1(this)">
								<option value="0">Null</option>
								@if($allUsers)
										@foreach($allUsers as $allUser)
											<option value="{{ $allUser->id }}" id="cm_u_{{$allUser->id}}">{{$allUser->name}}</option>
										@endforeach
								@else
										<option value="0">No Records</option>	
								@endif
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Comm2:</label>
							<div class="col-lg-6">
								{!! Form::text('comm_2','',$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Comm2")) !!}                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Com User 2:</label>
							<div class="col-lg-6">
								<select name="comm2_user" class="form-control com_user2" onchange="changeCom2(this)"><option value="0">Null</option>
								@if($allUsers)
										@foreach($allUsers as $allUser)
											<option value="{{ $allUser->id }}" id="cm_u2_{{$allUser->id}}">{{$allUser->name}}</option>
										@endforeach
								@else
										<option value="0">No Records</option>	
								@endif</select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Comm3:</label>
							<div class="col-lg-6">
								{!! Form::text('comm_3','',$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Comm3")) !!}                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Com User 3:</label>
							<div class="col-lg-6">
								<select name="comm3_user" class="form-control com_user3"><option value="0">Null</option>
								@if($allUsers)
										@foreach($allUsers as $allUser)
											<option value="{{ $allUser->id }}" id="cm_u3_{{$allUser->id}}">{{$allUser->name}}</option>
										@endforeach
								@else
										<option value="0">No Records</option>	
								@endif</select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Patti1:</label>
							<div class="col-lg-6">
								{!! Form::text('patti_1','',$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Patti1")) !!}                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Patti1 User:</label>
							<div class="col-lg-6">
								<select name="patti1_user" class="form-control pati_user1" onchange="changePti1(this)"><option value="0">Null</option>
								@if($allUsers)
										@foreach($allUsers as $allUser)
											<option value="{{ $allUser->id }}">{{$allUser->name}}</option>
										@endforeach
								@else
										<option value="0">No Records</option>	
								@endif</select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Patti2:</label>
							<div class="col-lg-6">
								{!! Form::text('patti_2','',$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Patti2")) !!}                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Patti2 User:</label>
							<div class="col-lg-6">
								<select name="patti2_user" class="form-control pati_user2" onchange="changePti2(this)"><option value="0">Null</option>
								@if($allUsers)
										@foreach($allUsers as $allUser)
											<option value="{{ $allUser->id }}">{{$allUser->name}}</option>
										@endforeach
								@else
										<option value="0">No Records</option>	
								@endif</select></select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Patti3:</label>
							<div class="col-lg-6">
								{!! Form::text('patti_3','',$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Patti3")) !!}                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Pati User 3:</label>
							<div class="col-lg-6">
								<select name="patti3_user" class="form-control pati_user3">
									<option value="0">Null</option>
								@if($allUsers)
										@foreach($allUsers as $allUser)
											<option value="{{ $allUser->id }}">{{$allUser->name}}</option>
										@endforeach
								@else
										<option value="0">No Records</option>	
								@endif</select>
								</select>
							</div>
						</div>
						@if($user->user_type == 1 || $user->user_type == 2 && $user->co_ad == 1)
							<div class="form-group">
								<label for="inputEmail3" class="col-lg-3 control-label ">User Type:</label>
								<div class="col-lg-6">
									<select class="form-control" name="user_type" onchange="showCoad(this)">
										<option value="0">Please Select</option>
										<option value="2">admin</option>
										<option value="0">User</option>
									</select>
									<div class="coad-ad">
										<label for="inputEmail3" class="control-label col-lg-8">Can Make Co Admin:</label>
										<input type="checkbox" name="coadmin" id="coad" class="checkbox" />	
									</div>	
								</div> 
																
							</div>
						@endif
						<div class="form-group">
								<label for="inputEmail3" class="col-lg-3 control-label ">Online/Offline:</label>
								<div class="col-lg-6">
									<select class="form-control" name="o_n">
										<option value="1">online</option>
										<option value="0">offline</option>
									</select>
								</div>
						</div>
						<div class="form-group">
								<label for="inputEmail3" class="col-lg-3 control-label ">Commission:</label>
								<div class="col-lg-6">
									{!! Form::text('commition','',$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Commition","onkeyup" => "isNumber(this)")) !!}
								</div>
						</div>
						<div class="form-group">
								<label for="inputEmail3" class="col-lg-3 control-label ">Max Bet:</label>
								<div class="col-lg-6">
									{!! Form::text('max_bet','',$attributes = array("class"=>"form-control","id"=>"max_bet","placeholder"=>"Max Bet")) !!}									<span id="mxmsg" style="color:red"></span>
								</div>
						</div>
						<div class="form-group">
								<label for="inputEmail3" class="col-lg-3 control-label ">Min Bet:</label>
								<div class="col-lg-6">
									{!! Form::text('min_bet','',$attributes = array("class"=>"form-control","id"=>"min_bet","placeholder"=>"Min Bet")) !!}									<span id="mnmsg" style="color:red"></span>
								</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-8 col-sm-0">
							@if($user->user_type == 1) 							
								<button type="submit" class="btn btn-primary btn-sm">Add</button>
							@else
								<button type="button" class="btn btn-primary btn-sm" onclick="chkValidate()">Add</button>
							@endif	
								
							</div> 
						</div>
                    </div>    
                {!! Form::close() !!} 
                       </div> </div>
                    </div>
                </section>

				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		
		<!-- /.panel -->
		<!-- /.panel -->
		<div class="loading_img">
			<img src="{{ asset('assets/clock-loading.gif')}}" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>

@include('templates/admin-footer')
@endsection
