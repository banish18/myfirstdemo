@extends('layouts.app')
 
@section('content')
<div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Chnage Password</h3>
						<section class="seccess">
						@if(Session::has('flash_message'))
							<div class="alert alert-success"><em> {!! session('flash_message') !!}</em></div>
						@endif
					</section>
                    </div>
					@if (!empty($errors) && count($errors) > 0)
					 <ul>
					  @foreach ($errors->all() as $error)
					   <li>{{ $error }}</li>
					  @endforeach
					 </ul>
					@endif 
                    <div class="panel-body">
                       {!! Form::open(array('route' => 'postChangepwd','method' => 'post','class'=>'form-horizontal','role'=>'form','autocomplete'=>'off')) !!}
						{!! csrf_field() !!}
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Old Password" name="old_pwd" type="password" autofocus>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="New Password" name="password" type="password">
                                </div>
								 <div class="form-group">
                                    <input class="form-control" placeholder="Confirm New Password" name="password_confirmation" type="password">
                                </div>
                                <!-- Change this to a button or input when using this as a form -->
								
                                <input type="submit" class="btn btn-lg btn-success btn-block" value="Change" />
                            </fieldset>
                       {!! Form::close() !!} 
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
