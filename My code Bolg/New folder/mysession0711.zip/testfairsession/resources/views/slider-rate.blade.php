
<?php 
	use App\User;
?>
@extends('layouts.app')
@section('content')
@include('templates/admin-header')
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			   <h2 class="page-header">Slide Rate</h2>
			   <div class="alrt_msg" id="alrt_msg"></div>
			   <!--section class="seccess">
					@if(Session::has('flash_message'))
						<div class="alert alert-success"><em> {!! session('flash_message') !!}</em></div>
					@endif
				</section-->
			</div> 
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class='row'>
					<div class='col-lg-8'>
							{!! Form::open(array('route' => 'add-sess-entry','method' => 'post','class'=>'form-horizontal','role'=>'form','autocomplete'=>'off')) !!}
								{!! csrf_field() !!} 
								<div class='col-lg-9'>
									<div class="form-group">
										<div class='col-lg-12'>
										<table class="table">
											<thead>
												<th>#</th>
												<th>Name</th>
												<th>Current Rate</th>
												<th>New Rate</th>
											</thead>
											<?php $i = 1; ?>
											<tbody>
												@foreach($sessions as $session)
													<tr class="diff-sess active_bg_open"><td>{{ $session->id }}</td><td>{{ $session->over }}</td><td><input type="text" id="oldrt" value="{{ $Sliderate->rate }}" /></td><td><input type="text" id="rt_{{$i}}" /></td><td><input type="button" onclick="setslideRate('{{ $session->id }}','{{$i}}')" value="Save"  /></td></tr>
													<?php $i++; ?>
													
												@endforeach
											</tbody>
										</table>
										</div>
											<!--select class="form-control" name="sess" id="sess" onchange="showSessRt(this)">
											@if($sessions)
												<option value="0">Please Select</option>
												@foreach($sessions as $session)
													<option value="{{$session->id}}">{{$session->over}}</option>
												@endforeach	
											@endif	
											</select>
										
										<div class='col-lg-4'>
											<input type="text" id="rt" />
										</div>
										<div class='col-lg-3'>
											<input type="button" onclick="setslideRate()" value="Save" />
										</div-->
									</div>
								</div>
								<input type="hidden" id="sess_id" name="sess_id" value=""/>
							{!! Form::close() !!} 
					</div>
				</div>
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div class="loading_img">
			<img src="{{ asset('assets/clock-loading.gif')}}" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>

@include('templates/admin-footer')


@endsection


