@extends('layouts.app')

@section('content')
<div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h2 class="text-center">Please Sign In</h2>
                    </div>
                    <div class="panel-body">
					@if (!empty($errors) && count($errors) > 0)
				     <ul class="login-errors">
				      @foreach ($errors->all() as $error)
				       <li>{{ $error }}</li>
				      @endforeach
				     </ul>
				    @endif
                        <form class="form-horizontal" role="form" method="POST" action="{{ url('mcl-login') }}">
						{!! csrf_field() !!}
                            <fieldset>
								<div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
									<label class="col-md-4 control-label">Email</label>

									<div class="col-md-6">
										<input type="text" class="form-control" name="username" value="{{ old('email') }}" autofocus>

										@if ($errors->has('email'))
											<span class="help-block">
												<strong>{{ $errors->first('username') }}</strong>
											</span>
										@endif
									</div>
								</div>
								<div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
									<label class="col-md-4 control-label">Password</label>

									<div class="col-md-6">
										<input type="password" class="form-control" name="password">

										@if ($errors->has('password'))
											<span class="help-block">
												<strong>{{ $errors->first('password') }}</strong>
											</span>
										@endif
									</div>
								</div>
                                <div class="form-group">
									<div class="col-md-6 col-md-offset-4">
										<div class="checkbox">
											<label>
												<input type="checkbox" name="remember"> Remember Me
											</label>
										</div>
									</div>
								</div>
                                <!-- Change this to a button or input when using this as a form -->
								<div class="form-group">
									<div class="col-md-6 col-md-offset-4">
										<button type="submit" class="btn btn-lg btn-success btn-block">
											<i class="fa fa-btn fa-sign-in"></i>Login
										</button>
									
										<!--a class="btn btn-link" href="{{ url('/password/reset') }}">Forgot Your Password?</a>
										<a class="btn btn-link" href="{{ url('/register') }}">Register</a-->
									</div>
								</div>								<h4 style="text-align: center;">For Enquiry Please contact admin support</h4>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
