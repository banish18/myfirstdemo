<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<!-- /.panel-heading -->
			<div class="panel-body">
			<section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section>
			<?php echo csrf_field(); ?>

				<div class="table-responsive">
					<div class="col-lg-12">
						<div class="my-session">
							<h3 onclick="shSess(this)" class="ct_ses">Create Session</h3>
							<div class="slide-cont">
								<p><textarea id="over"></textarea><input type="submit" id="Create" value="Create" onclick="ctSess(this)" /><!--input onclick="isCheck()" type="button" id="act" value="Activate" class="acti_sess"/><input type="hidden" id="ac" value="1"--></p>
								<p></p>
							</div>
						</div>
					</div>
					
					<div class="all-sess">
					<div class="col-lg-12">
						<table class="table">
						<thead>
							<th>#</th>
							<th>Description</th>
							<th>Status</th>
							<th>Runs</th>
						</thead>
						<?php $i = 1; ?>
						<tbody>
							<?php foreach($Sessions as $session): ?>
								<?php if($session->action == 1): ?>
									<?php $status = "Created"; $runs = "0";?>
									<?php elseif($session->action == 2): ?>
										<?php $status = "Running,Suspended";$runs = "0"; ?>
									<?php elseif($session->action == 3): ?>
										<?php $status = "Running,Unsuspended";$runs = "0"; ?>	
									<?php elseif($session->action == 4): ?>	
										<?php $status = "Declared"; 
										$runs = $session->runs;
										?>
										
									<?php else: ?>	
										<?php $status = "Suspended"; 
									$runs = "0";
									?>
								<?php endif; ?>	
								
								<tr onclick="showPop(<?php echo e($session->id); ?>,<?php echo e($session->amount); ?>,'<?php echo e($session->isActive); ?>','<?php echo e($session->action); ?>','<?php echo e($session->sess_rate); ?>','<?php echo e($session->runs); ?>','<?php echo e($session->run_diff); ?>','<?php echo e($session->rate); ?>')" class="diff-sess slide_open"><td><?php echo e($session->id); ?></td><td><?php echo e($session->over); ?></td><td><?php echo e($status); ?></td><td><?php echo e($runs); ?></td></tr>
								<?php $i++; ?>
							<?php endforeach; ?>
						</tbody>
					</table>
					<?php echo $Sessions->render(); ?>
					</div>
					</div>
				</div>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div id="slide">
			<div class="sess_slide">
				<div class="alrt_msg" id="alrt_msg"></div>
				<p><!--input type="button" id="active" value="Activate" onclick="setStat(this)"/><input type="button" id="inactive" value="Inactivate" onclick="setStat(this)" /--><input type="button" id="declare" value="Declare" onclick="setStat(this)"/><input type="button" id="undeclare" value="Undeclare" onclick="setStat(this)"/><input type="button" id="runsess" value="Run" onclick="runSess(this)" class="active_bg_open"/></p>
				<div class="dec_bx"><input type="text" id="amount" /><input type="button" id="save" value="Save" onclick="changeDelareRate()"/></div>
				<br /><p><button class="slide_close btn btn-default">Close</button></p>
				<input type="hidden" id="sess_id" class="sess_id" />
				<input type="hidden" id="isAct" />
				<input type="hidden" id="st" />
				<input type="hidden" id="rn" />
				<input type="hidden" id="rd" />
				<input type="hidden" id="rt" />
				<input type="hidden" id="actionsess" />
			</div>
		</div>
		<div id="active_bg">
		
			<div class="sess_slide_rs">
			<div class="my-session">
				<div class="st_ct">
								<div class="alrt_msg" id="alrt_msg"></div>
								<h2 class="sess_stat_h"><img class="news_blink_image" alt="blink_image" src="http://mindxpert.com/portal/assets/images/news-star.gif"><b>Session Waiting.........</b></h2>
								<p>
								    <div class="swiper-container">
										<div class="swiper-wrapper">
											<?php foreach($numbers as $number): ?>
												<div class="swiper-slide" id="<?php echo e($number); ?>" onclick="setNm(<?php echo e($number); ?>,this)"><?php echo e($number); ?></div>
											<?php endforeach; ?>
										</div>
										<!-- Add Pagination -->
										<div class="swiper-pagination"></div> 
										<!-- Add Arrows -->
										<div class="swiper-button-next"></div>
										<div class="swiper-button-prev"></div>
										<input type="hidden" id="rtnumber" />
									</div>
								</p>
								<p><label>Run Diffrence</label><select id="rn_diff" onchange="rndiff(this)"><option value="rn_0" id="null">Null</option><option id="rn_1" value="1">1</option><option id="rn_2" value="2">2</option><option id="rn_3" value="3">3</option><option id="rn_4" value="4">4</option><option id="rn_5" value="5">5</option><option id="rn_6" value="6">6</option></select></p> 
								<p><label>Rate</label><select id="sess_rt" onchange="ssrate(this)"><option id="rt_0:0" value="0:0">Null</option><option id="rt_90:110" value="90:110">90:110</option><option id="rt_85:115" value="85:115">85:115</option><option id="rt_70:125" value="70:125">70:125</option><option id="rt_100:150" value="100:150">100:150</option><option id="rt_200:250" value="200:250">200:250</option><option id="rt_250:400" value="250:400">250:400</option></select></p>
								
								<div class="cr_sess">
									<span>
										<h3>Current Session</h3>
										<b id="rt_1"></b>
										<b id="rt_2"></b>
										<input onclick="saveSessRate()" type="button" name="save" id="save_rt" value="Save"/>
									</span> 
								</div>
								<input type="hidden" class="sess_id" id="sess_id" />
								<input type="hidden" id="act" />
								<p><span><input onclick="isActivesess()" type="button" name="suspend" id="suspend" value="Unsuspend"/></span></p>
								<p><button class="btn btn-default rn_sess_btnC" onclick="cls_popup()">Close</button><button class="active_bg_close btn btn-default rn_sess_btn">Close</button></p>
								
							</div>
							</div>
			</div>
			
		</div>
		<div id="cover"> </div> 
		<div class="loading_img rn_ldimg">
			<img src="<?php echo e(asset('assets/clock-loading.gif')); ?>" />
		</div>
	</div>
	
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
 
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>