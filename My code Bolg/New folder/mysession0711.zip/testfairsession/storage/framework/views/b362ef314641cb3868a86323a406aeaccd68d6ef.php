<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			     <section class="content-header">
                    <h1>Update User</h1>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Update User</li>
                    </ol>
                </section>
			</div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				 <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
              

                <!-- Main content -->
				<?php if(!empty($errors) && count($errors) > 0): ?>
				 <ul>
				  <?php foreach($errors->all() as $error): ?>
				   <li><?php echo e($error); ?></li>
				  <?php endforeach; ?>
				 </ul>
				<?php endif; ?> 
                
                <section class="content">
                    <div class='row'>
                    <div class='col-lg-12'>
               <?php echo Form::open(array('route' => 'edit-user','method' => 'post','class'=>'form-horizontal','role'=>'form','autocomplete' => 'off')); ?>

					<?php echo csrf_field(); ?>

                    <div class='col-lg-12'>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Name:</label>
							<div class="col-lg-6">
								<?php echo Form::text('name',$user->name,$attributes = array("class"=>"form-control","id"=>"inputEmail3","placeholder"=>"Name")); ?>

							</div>
						</div>
						<?php if($loggeduser->user_type == 1 || $loggeduser->co_ad == 1): ?>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Email:</label>
							<div class="col-lg-6">
								<?php echo Form::text('email',$user->email,$attributes = array("class"=>"form-control","id"=>"inputEmail3","placeholder"=>"Email")); ?>                             
							</div>
						</div>
						<?php endif; ?>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Mobile:</label>
							<div class="col-lg-6">
								<?php echo Form::text('mobile',$user->mobile,$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Mobile")); ?>                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Password:</label>
							<div class="col-lg-6">
								<?php echo Form::text('password',$user->show_pass,$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Password")); ?>                             
							</div>
						</div>
						<?php if($loggeduser->user_type == 1): ?>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Limit:</label>
							<div class="col-lg-6">
								<?php echo Form::text('limit',$user->limit,$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Limit")); ?>                             
							</div>
						</div>
						<?php endif; ?>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Credit:</label>
							<div class="col-lg-6">
								<?php echo Form::text('credit',$balance,$attributes = array("class"=>"form-control","id"=>"ucredit","placeholder"=>"Credit","onkeyup"=>"setRate()" ,'disabled')); ?>                             
							</div>
						</div>	
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Rate:</label>
							<div class="col-lg-6">
								<?php echo Form::text('rate',$user->rate,$attributes = array("class"=>"form-control","id"=>"urate","placeholder"=>"Rate","onkeyup"=>"setRate()")); ?>                             
							</div>
						</div>
						<div class="form-group">
						
							<?php 
							$amount = $balance*$user->rate;
							?>
							<label for="inputEmail3" class="col-lg-3 control-label">Amount:</label>
							<div class="col-lg-6">
								<?php echo Form::text('amt',$amount,$attributes = array("class"=>"form-control","id"=>"uamount","placeholder"=>"Amount",'disabled')); ?>

								<input type="hidden" name="amount" id="amount" value="<?php echo e($amount); ?>" />								
							</div>
						</div>	
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Comm1:</label>
							<div class="col-lg-6">
								<?php echo Form::text('comm_1',$user->comm_1,$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Comm1")); ?>                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Comm1 User:</label>
							<div class="col-lg-6">
								<select name="comm1_user" class="form-control com_user1" onchange="changeUCom1(this,'<?php echo e($user->id); ?>')">
								<option value="0">Null</option>
								<?php if($allUsers): ?>
										<?php foreach($allUsers as $allUser): ?>
										<?php if($allUser->id == $user->comm1_user): ?>
											<?php 
												$selected = "selected=selected";
											?>

										<?php else: ?>	
											<?php 
												$selected = "";
												?>
										<?php endif; ?>	
										<?php if($allUser->id != $user->comm2_user && $allUser->id != $user->comm3_user): ?>
											<option value="<?php echo e($allUser->id); ?>" id="cm_u_<?php echo e($allUser->id); ?>" <?php echo e($selected); ?>><?php echo e($allUser->name); ?></option>
										<?php endif; ?>	
											
										<?php endforeach; ?>
								<?php else: ?>
										<option value="0">No Records</option>	
								<?php endif; ?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Comm2:</label>
							<div class="col-lg-6">
								<?php echo Form::text('comm_2',$user->comm_2,$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Comm2")); ?>                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Com User 2:</label>
							<div class="col-lg-6">
								<select name="comm2_user" class="form-control com_user2" onchange="changeUCom2(this,'<?php echo e($user->id); ?>')"><option value="0">Null</option>
								<?php if($allUsers): ?>
										<?php foreach($allUsers as $allUser): ?>
											<?php if($allUser->id == $user->comm2_user): ?>
												<?php 
												$selected = "selected=selected";
											?>

											<?php else: ?>	
											<?php 
												$selected = "";
												?>
											<?php endif; ?>	
											<?php if($allUser->id != $user->comm1_user && $allUser->id != $user->comm3_user): ?>
												<option <?php echo e($selected); ?> value="<?php echo e($allUser->id); ?>" id="cm_u2_<?php echo e($allUser->id); ?>">
												<?php echo e($allUser->name); ?></option>
											<?php endif; ?>	
										<?php endforeach; ?>
								<?php else: ?>
										<option value="0">No Records</option>	
								<?php endif; ?></select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Comm3:</label>
							<div class="col-lg-6">
								<?php echo Form::text('comm_3',$user->comm_3,$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Comm3")); ?>                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Com User 3:</label>
							<div class="col-lg-6">
								<select name="comm3_user" class="form-control com_user3"><option value="0">Null</option>
								<?php if($allUsers): ?>
										<?php foreach($allUsers as $allUser): ?>
										<?php if($allUser->id == $user->comm3_user): ?>
											<?php 
												$selected = "selected=selected";
											?>

										<?php else: ?>	
											<?php 
												$selected = "";
												?>
										<?php endif; ?>
										<?php if($allUser->id != $user->comm1_user && $allUser->id != $user->comm2_user): ?>
											<option value="<?php echo e($allUser->id); ?>" id="cm_u3_<?php echo e($allUser->id); ?>" <?php echo e($selected); ?>><?php echo e($allUser->name); ?></option>
										<?php endif; ?>
										<?php endforeach; ?>
								<?php else: ?>
										<option value="0">No Records</option>	
								<?php endif; ?></select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Patti1:</label>
							<div class="col-lg-6">
								<?php echo Form::text('patti_1',$user->patti_1,$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Patti1")); ?>                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Patti1 User:</label>
							<div class="col-lg-6">
								<select name="patti1_user" class="form-control pati_user1" onchange="changeUPti1(this,'<?php echo e($user->id); ?>')"><option value="0">Null</option>
								<?php if($allUsers): ?>
										<?php foreach($allUsers as $allUser): ?>
										<?php if($allUser->id == $user->patti1_user): ?>
										<?php 
												$selected = "selected=selected";
											?>

										<?php else: ?>	
											<?php 
												$selected = "";
												?>
										<?php endif; ?>
										<?php if($allUser->id != $user->patti2_user && $allUser->id != $user->patti3_user): ?>
											<option value="<?php echo e($allUser->id); ?>" <?php echo e($selected); ?>><?php echo e($allUser->name); ?></option>
										<?php endif; ?>
										<?php endforeach; ?>
								<?php else: ?>
										<option value="0">No Records</option>	
								<?php endif; ?></select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Patti2:</label>
							<div class="col-lg-6">
								<?php echo Form::text('patti_2',$user->patti_2,$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Patti2")); ?>                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Patti2 User:</label>
							<div class="col-lg-6">
								<select name="patti2_user" class="form-control pati_user2" onchange="changeUPti2(this,'<?php echo e($user->id); ?>')"><option value="0">Null</option>
								<?php if($allUsers): ?>
										<?php foreach($allUsers as $allUser): ?>
										<?php if($allUser->id == $user->patti2_user): ?>
										<?php 
												$selected = "selected=selected";
											?>

										<?php else: ?>	
											<?php 
												$selected = "";
												?>
										<?php endif; ?>
										<?php if($allUser->id != $user->patti1_user && $allUser->id != $user->patti3_user): ?>
											<option value="<?php echo e($allUser->id); ?>" <?php echo e($selected); ?>><?php echo e($allUser->name); ?></option>
										<?php endif; ?>
										<?php endforeach; ?>
								<?php else: ?>
										<option value="0">No Records</option>	
								<?php endif; ?></select></select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Patti3:</label>
							<div class="col-lg-6">
								<?php echo Form::text('patti_3',$user->patti_3,$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Patti3")); ?>                             
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Pati User 3:</label>
							<div class="col-lg-6">
								<select name="patti3_user" class="form-control pati_user3">
									<option value="0">Null</option>
								<?php if($allUsers): ?>
										<?php foreach($allUsers as $allUser): ?>
										<?php if($allUser->id == $user->patti3_user): ?>
										<?php 
												$selected = "selected=selected";
											?>

										<?php else: ?>	
											<?php 
												$selected = "";
												?>
										<?php endif; ?>
										<?php if($allUser->id != $user->patti2_user && $allUser->id != $user->patti1_user): ?>
											<option value="<?php echo e($allUser->id); ?>" <?php echo e($selected); ?>><?php echo e($allUser->name); ?></option>
										<?php endif; ?>
										<?php endforeach; ?>
								<?php else: ?>
										<option value="0">No Records</option>	
								<?php endif; ?>
								</select>
							</div>
						</div>
						<?php if($loggeduser->user_type == 1 || $loggeduser->user_type == 2 && $loggeduser->co_ad == 1): ?>
							<?php 
							if($user->user_type == 2){
								$stl = "style=display:block";
								$selected = "selected='selected'";
							}else{
								$stl = "";
								$selected = "";
							}
							if($user->user_type == 0){
								$selected1 = "selected='selected'";
							}else{
								$selected1 = "";
							}
							if($user->co_ad == 1){
								$chk = "checked='checked'";
							}else{
								$chk = "";
							}
							?>
							<div class="form-group">
								<label for="inputEmail3" class="col-lg-3 control-label ">User Type:</label>
								<div class="col-lg-6">
									<select class="form-control" name="user_type" onchange="showCoad(this)">
										<option <?php echo e($selected); ?> value="2">admin</option>
										<option <?php echo e($selected1); ?> value="0">User</option>
									</select>
									<div class="coad-ad" <?php echo e($stl); ?>>
										<label for="inputEmail3" class="control-label col-lg-8">Can Make Co Admin:</label>
										<input type="checkbox" name="coadmin" id="coad" class="checkbox" <?php echo e($chk); ?> />	
									</div>
								</div>
							</div>
						<?php endif; ?>
						<?php 
							if($user->o_n == 1){
								$selected = "selected='selected'";
							}else{
								$selected = "";
							}
							if($user->o_n == 0){
								$selected1 = "selected='selected'";
							}else{
								$selected1 = "";
							}
							?>
						<div class="form-group">
								<label for="inputEmail3" class="col-lg-3 control-label ">Online/Offline:</label>
								<div class="col-lg-6">
									<select class="form-control" name="o_n">
										<option value="1" <?php echo e($selected); ?>>online</option>
										<option value="0" <?php echo e($selected1); ?>>offline</option>
									</select>
								</div>
						</div>
						<div class="form-group">
								<label for="inputEmail3" class="col-lg-3 control-label ">Commission:</label>
								<div class="col-lg-6">
									<?php echo Form::text('commition',$user->commition,$attributes = array("class"=>"form-control","id"=>"inputMobile","placeholder"=>"Commition","onkeyup" => "isNumber(this)")); ?>	
								</div>
						</div>
						<div class="form-group">
								<label for="inputEmail3" class="col-lg-3 control-label ">Max Bet:</label>
								<div class="col-lg-6">
									<?php echo Form::text('max_bet',$user->max_bet,$attributes = array("class"=>"form-control","id"=>"max_bet","placeholder"=>"Max Bet")); ?>								<span id="mxmsg" style="color:red"></span>
								</div>
						</div>
						<div class="form-group">
								<label for="inputEmail3" class="col-lg-3 control-label">Min Bet:</label>
								<div class="col-lg-6">
									<?php echo Form::text('min_bet',$user->min_bet,$attributes = array("class"=>"form-control","id"=>"min_bet","placeholder"=>"Min Bet")); ?>								<span id="mnmsg" style="color:red"></span>
								</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-8 col-sm-0">								<button type="button" class="btn btn-primary btn-sm" onclick="chkeditValidate()">Update</button>
							</div>
						</div>
						  <input type="hidden" name="user_id" value="<?php echo $user->id; ?>" />
                    </div>    
                <?php echo Form::close(); ?> 
                       </div> </div>
                    </div>
                </section>

				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>