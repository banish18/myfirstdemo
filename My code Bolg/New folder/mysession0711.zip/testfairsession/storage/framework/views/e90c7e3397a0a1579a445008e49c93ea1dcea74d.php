<?php 
	use App\User;
?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			   <h2 class="page-header">Match Entry</h2>
			   
			   <h3 class="st_rt" style="color:red"></h3>
			   <div class="alrt_msg" id="alrt_msg"></div>
			   <!--section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section-->
			</div> 
			<!-- /.panel-heading -->
			<div class="panel-body">
					<div class='row'>
					<div class='col-lg-8'>
							<?php echo Form::open(array('route' => 'add-sess-entry','method' => 'post','class'=>'form-horizontal','role'=>'form','autocomplete'=>'off')); ?>

								<?php echo csrf_field(); ?> 
								<div class='col-lg-9'>
									<div class="form-group">
										<select class="form-control" name="sess" id="sess" onchange="showMatchRt(this)">
											<?php if($matches): ?>
												<option value="0">Please Select</option>
												<?php foreach($matches as $match): ?>
													<option value="<?php echo e($match->id); ?>"><?php echo e($match->match_name); ?></option>
												<?php endforeach; ?>	
											<?php endif; ?>	
										</select>
									</div>
									
								</div>
								
								<input type="hidden" id="match_id" name="match_id" value=""/>
											<input type="hidden" id="usr_id" name="usr_id" />
							<?php echo Form::close(); ?> 
						</div>
						<div class='col-lg-8'>
							<div class="matrix_slider">
								 <table class="table">
									<thead><td>#</td><td>Admin</td><td>User</td><td>Team1</td><td>Team2</td><td>B_l</td><td>stak</td><td>	rate</td>									<?php if($loggeduser->user_type == 1): ?>										<td>Action</td>									<?php endif; ?>									</thead>
									<tbody id="ses_records">
										
									</tbody>
								 </table>
							</div>
						</div>	
						<div class="col-lg-4">
							<div class="matrix_slider">
								 <table class="table">
									<thead><th>Runs</th><th>Amount</th></thead>
									<tbody id="ses_mtrx">
										
									</tbody>
								 </table>
							</div>	
						</div>
					</div>
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div class="loading_img">
			<img src="<?php echo e(asset('assets/clock-loading.gif')); ?>" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
<?php echo Html::script('assets/admin/js/angular.js'); ?>

<script>

var app = angular.module('plunker', []);

        app.controller('MainCtrl', ['$scope', '$interval', function($scope, $interval) {
            var interval = $interval(function() {
               var match_id = jQuery("#match_id").val();
			   if(sess_id != ""){
				    var token = jQuery("input[name=_token]").val();
					var request = jQuery.ajax({
						type:"post",
						url:"showMatchRt",
						data:{match_id:match_id,_token:token}
					});
					request.done(function (response){
						jQuery(".loading_img").hide();
						jQuery(".matrix_slider").show();
						jQuery('#ses_mtrx').html(response.html);
						jQuery('#ses_records').html(response.html2);
						jQuery(".st_rt").show();
						jQuery(".st_rt").text('Current Sessin Rate : '+response.sess_rate);
					});
			   }else{
				   return true;
			   }
				
            }, 2000); 
        }]); 
</script>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>