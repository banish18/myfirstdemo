<?php 
	use App\User;
?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			   <h2 class="page-header">Slide Rate</h2>
			   <div class="alrt_msg" id="alrt_msg"></div>
			   <!--section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section-->
			</div> 
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class='row'>
					<div class='col-lg-8'>
							<?php echo Form::open(array('route' => 'add-sess-entry','method' => 'post','class'=>'form-horizontal','role'=>'form','autocomplete'=>'off')); ?>

								<?php echo csrf_field(); ?> 
								<div class='col-lg-9'>
									<div class="form-group">
										<div class='col-lg-12'>
										<table class="table">
											<thead>
												<th>#</th>
												<th>Name</th>
												<th>Current Rate</th>
												<th>New Rate</th>
											</thead>
											<?php $i = 1; ?>
											<tbody>
												<?php foreach($sessions as $session): ?>
													<tr class="diff-sess active_bg_open"><td><?php echo e($session->id); ?></td><td><?php echo e($session->over); ?></td><td><input type="text" id="oldrt" value="<?php echo e($Sliderate->rate); ?>" /></td><td><input type="text" id="rt_<?php echo e($i); ?>" /></td><td><input type="button" onclick="setslideRate('<?php echo e($session->id); ?>','<?php echo e($i); ?>')" value="Save"  /></td></tr>
													<?php $i++; ?>
													
												<?php endforeach; ?>
											</tbody>
										</table>
										</div>
											<!--select class="form-control" name="sess" id="sess" onchange="showSessRt(this)">
											<?php if($sessions): ?>
												<option value="0">Please Select</option>
												<?php foreach($sessions as $session): ?>
													<option value="<?php echo e($session->id); ?>"><?php echo e($session->over); ?></option>
												<?php endforeach; ?>	
											<?php endif; ?>	
											</select>
										
										<div class='col-lg-4'>
											<input type="text" id="rt" />
										</div>
										<div class='col-lg-3'>
											<input type="button" onclick="setslideRate()" value="Save" />
										</div-->
									</div>
								</div>
								<input type="hidden" id="sess_id" name="sess_id" value=""/>
							<?php echo Form::close(); ?> 
					</div>
				</div>
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div class="loading_img">
			<img src="<?php echo e(asset('assets/clock-loading.gif')); ?>" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>

<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>