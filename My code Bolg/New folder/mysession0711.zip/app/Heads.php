<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Heads extends Authenticatable
{
   protected $table = 'heads';
   function getHeadName($name){
		$head = Heads::where('name',$name)->first();
		if($head){
			$head = $head->name;
		}else{
			$head = '';
		}
		return $head;
	}
}
