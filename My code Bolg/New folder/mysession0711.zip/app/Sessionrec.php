<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Sessionrec extends Authenticatable
{
   protected $table = 'sessions_res';
}
