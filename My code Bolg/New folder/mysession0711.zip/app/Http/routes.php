<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/



/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {
    //
	Route::get('/',array('before' => 'auth', function()
	{
		if (Auth::check())
		{
			return Redirect::intended('dashboard');  
		}
		else
		{
			return Redirect::intended('login'); 
		}
	}));
	 
	
}); 

Route::group(['middleware' => 'web'], function () {
    Route::auth();
    Route::get('/dashboard', 'DashboardController@index');
	Route::post('mcl-login', ['as' => 'mcl-login','uses'=>'LoginController@getlogin']);
	Route::get('users', 'UsersController@index');
	Route::get('add-user',	array("as" 	=> "add-user","uses" 	=> 'UsersController@addUser'));
	Route::post('add-post-user',	array("as" 	=> "add-post-user","uses" 	=> 'UsersController@postaddUser'));
	Route::get('update-user/{id}',	array("as" 	=> "update-user","uses" 	=> 'UsersController@updateUser'));
	Route::post('edit-user',	array("as" 	=> "edit-user","uses" 	=> 'UsersController@postUpdateUser'));
	Route::get('delete-user/{id}', array("as" 	=> "delete-user","uses" =>	'UsersController@deleteUser'));
	Route::get('create-session', 'SessionsController@index');
	Route::get('run-session', 'SessionsController@showSessions');
	Route::get('run-session-auto', 'SessionsController@showautoSessions');
	
	Route::get('test-run-session', 'SessionsController@testshowSessions');
	
	Route::post('postSess', 'SessionsController@postSessdata');
	Route::post('updateSessisactive', 'SessionsController@updateSessisactive');
	Route::post('updateSessisstatus', 'SessionsController@updateSessisastatus');
	Route::post('updateDcrate', 'SessionsController@updateDcrate');
	Route::post('setAdmin', 'UsersController@setAdmin');
	Route::post('removeAdmin', 'UsersController@removeAdmin');
	Route::post('setSessRate', 'SessionsController@setSessRate');
	Route::post('suspendUser', 'UsersController@suspendUser');
	Route::post('unsuspendUser', 'UsersController@unsuspendUser');
	Route::post('changeCom1', 'UsersController@changeCom1');
	Route::post('changeUCom1', 'UsersController@changeUCom1');
	Route::post('showUsers', 'UsersController@showUsers');
	Route::post('showaUsers', 'UsersController@showaUsers');
	Route::post('showlUsers', 'UsersController@showlUsers');
	Route::post('showAlsers', 'UsersController@showAlsers');
	Route::get('sessionEntry', 'SessionsController@getSessionentry');
	Route::post('add-sess-entry', array("as" 	=> "add-sess-entry","uses" 	=> 'SessionsController@postSessionentry'));
	Route::post('getAllUsers', 'UsersController@getAllUsersdata');
	Route::post('updatesessStat', 'SessionsController@updatesessStat');
	Route::post('getsesMtx', 'SessionsController@getsesMtxData');
	Route::get('sessledger', 'LedgerController@index'); 
	Route::post('add-post-ledger', array("as" 	=> "add-post-ledger","uses" =>'LedgerController@postLedgerdata'));	
	Route::post('getAlldusers', 'UsersController@getAlldusers');
	Route::post('getAllcusers', 'UsersController@getAllcusers');
	Route::get('reports', 'LedgerController@getLedgerReports');
	Route::get('sess-reports', 'LedgerController@getLedgerSessReports');
	Route::get('ledger', 'LedgerController@getLedgers');
	Route::post('getSessRes', 'LedgerController@getSessRes');
	Route::post('getUSessRes', 'LedgerController@getUSessRes');
	Route::post('getDSessRes', 'LedgerController@getDSessRes'); 
	Route::get('reports-dw', 'LedgerController@getSessDw');
	Route::get('user-wise', 'LedgerController@getSessUw');
	Route::get('userssess-reports/{id}',	array("as" 	=> "userssess-reports","uses" 	=> 'LedgerController@getUserSessReports'));
	Route::post('getUserSessRes',	array("as" 	=> "getUserSessRes","uses" 	=> 'LedgerController@getUserSessRes'));
	Route::get('list-entries', 'LedgerController@getlistEntries');
	Route::post('getUsersSessRes', 'LedgerController@getUsersSessRes');
	Route::post('getUwSessRes', 'LedgerController@getUwSessRes');
	Route::get('sess-wise', 'LedgerController@getSessSw');
	Route::post('getUsersSwsRes', 'LedgerController@getUsersSwsRes');
	Route::post('getAllusersSessRes', 'LedgerController@getAllusersSessRes');
	Route::get('changeUPassword', 'UsersController@changeUPassword');
	Route::post('postChangepwd',	array("as" 	=> "postChangepwd","uses" 	=> 'UsersController@postChangepwd'));
	Route::post('deleteSessresData', 'SessionsController@deleteSessresData');
	Route::get('app-version', 'UsersController@getAppversion');		Route::post('postVersion', 'UsersController@postVersion');
	Route::post('sussallSession', 'SessionsController@sussallSession');
	Route::get('slider-rate', 'SessionsController@sliderRate');
	Route::post('postslideSessrt', 'SessionsController@postslideSessrt');
	Route::post('postchkbetLmt',	array("as" 	=> "postchkbetLmt","uses" 	=> 'UsersController@postchkbetLmt'));
	
	Route::post('getAllSess', 'LedgerController@getAllSess');
	Route::get('getDetailreports', 'SessionsController@getDetailreports');
	Route::post('getAllsessRes', 'SessionsController@getAllsessRes');
	Route::post('getperUsersSwsRes', 'SessionsController@getperUsersSwsRes');
	
});
