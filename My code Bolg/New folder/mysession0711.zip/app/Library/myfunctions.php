<?php namespace App\library {
    class myFunctions {
        public function is_ok() {
            return 'myFunction is OK';
        }
    }
}
?>