<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	

    <title>
    @if(isset($title))
      {{ $title }}
    @else
    Login
    @endif
    </title>

    <!-- Bootstrap Core CSS -->
	{!! Html::style('assets/admin/bower_components/bootstrap/dist/css/bootstrap.css') !!}

    <!-- MetisMenu CSS -->
	{!! Html::style('assets/admin/bower_components/metisMenu/dist/metisMenu.min.css') !!}

    <!-- Timeline CSS -->
	{!! Html::style('assets/admin/dist/css/timeline.css') !!}

    <!-- Custom CSS -->
	{!! Html::style('assets/admin/dist/css/sb-admin-2.css') !!}
	
	{!! Html::style('assets/admin/dist/css/jquery-ui.css') !!}
	
    <!-- Morris Charts CSS -->
	{!! Html::style('assets/admin/bower_components/morrisjs/morris.css') !!}

    <!-- Custom Fonts -->
	{!! Html::style('assets/admin/bower_components/font-awesome/css/font-awesome.min.css') !!}
	
	<!-- Custom Fonts -->
	{!! Html::style('assets/admin/css/swiper.css') !!}
	<!-- Custom Fonts -->
	{!! Html::style('assets/css/bootstrap-multiselect.css') !!}

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

    <style>
        body {
            font-family: 'Lato';
        }

        .fa-btn {
            margin-right: 6px;
        }
    </style>
</head>
<body id="app-layout" ng-app="plunker" ng-controller="MainCtrl">
    @yield('content')
  
    <!-- JavaScripts -->
     <!-- jQuery -->
	{!! Html::script('assets/admin/bower_components/jquery/dist/jquery.min.js') !!}
	
	

    <!-- Bootstrap Core JavaScript -->
	{!! Html::script('assets/admin/bower_components/bootstrap/dist/js/bootstrap.min.js') !!}

    <!-- Metis Menu Plugin JavaScript -->
	{!! Html::script('assets/admin/bower_components/metisMenu/dist/metisMenu.min.js') !!}

    <!-- Morris Charts JavaScript -->
	{!! Html::script('assets/admin/bower_components/raphael/raphael-min.js') !!}
	{!! Html::script('assets/admin/bower_components/morrisjs/morris.min.js') !!}
	
    <!-- Custom Theme JavaScript -->
	{!! Html::script('assets/admin/dist/js/sb-admin-2.js') !!}
	{!! Html::script('assets/admin/js/jquery.popupoverlay.js') !!}
	{!! Html::script('assets/admin/js/custom.js') !!}
	{!! Html::script('assets/admin/js/swiper.js') !!}
	{!! Html::script('assets/admin/js/jquery-ui.js') !!}
	
	{!! Html::script('assets/js/bootstrap-multiselect.js') !!}
	
	<script>
		jQuery('div.alert').delay(5000).slideUp(300);
		jQuery('#alrt_msg').delay(5000).slideUp(300);
		jQuery(function() {
			jQuery( "#from_Date" ).datepicker();
			jQuery( "#to_Date" ).datepicker(); 
			jQuery( "#ldate" ).datepicker();	
			jQuery('.chkveg').multiselect({

			includeSelectAllOption: true

		});			
		});

		
	</script>
	   
</body>
</html>
