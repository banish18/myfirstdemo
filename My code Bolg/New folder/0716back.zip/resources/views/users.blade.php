<?php 
	use App\User;
?>
@extends('layouts.app')
@section('content')
@include('templates/admin-header')
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			   <h2 class="page-header">User Management</h2>
			   <a href="{{url('add-user')}}">Create User</a>
			   <section class="seccess">
					@if(Session::has('flash_message'))
						<div class="alert alert-success"><em> {!! session('flash_message') !!}</em></div>
					@endif
				</section>
			</div> 
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover">
					{!! csrf_field() !!}
						<thead>
							<tr>
								<th>#</th>
								<th>Username</th>
								@if($loggedUser->user_type == 1)
									<th>Email</th>
								@endif	
								@if($loggedUser->user_type != 1)
									<th>Userid</th>
								@endif	
								<th>Mobile</th>
								<th>Password</th>
								@if($loggedUser->user_type == 1)
									<th>Limit</th>
								@endif
								<th>Credit</th>
								<th>Rate</th>
								<th>Amount</th>
								<th>Min Bet</th>
								<th>Max Bet</th>
								<th>Commission</th>
								<th>Comm1 User</th>
								<th>Comm2</th>
								<th>Comm2 User</th>
								<th>Comm3</th>
								<th>Comm3 User</th>
								<th>Pati1</th>
								<th>Pati1 User</th>
								<th>Pati2</th>
								<th>Pati2 User</th>
								<th>Pati3</th>
								<th>Pati3 User</th>
								<th>Action</th>								
							</tr>
						</thead>
						<tbody>
						@if($users)
							<?php $i = 1; 
								
							?>
							@foreach($users as $user)
							<?php 
								$amount = $user->rate*$user->balance;
							?>
							@if($loggedUser->user_type == 1)
								<tr class="diff-sess-u">
							@else
								<tr>
							@endif
							
									
									@if($loggedUser->user_type == 1)
										<td onclick="showUsers('{{$user->id}}')">{{$i}}</td>
									@else
										<td>{{$i}}</td>
									@endif	
									@if($loggedUser->user_type == 1)
										<td onclick="showUsers('{{$user->id}}')">{{ strtoupper($user->name) }}</td>
									@else
										<td>{{ $user->name }}</td>
									@endif	
									@if($loggedUser->user_type == 1)
										<td onclick="showUsers('{{$user->id}}')">{{ $user->email }}</td>
									@endif
									@if($loggedUser->user_type != 1)
										<td>{{ $user->userid }}</td>
									@endif
									@if($loggedUser->user_type == 1)
										<td onclick="showUsers('{{$user->id}}')">{{ $user->mobile }}</td>
										<td onclick="showUsers('{{$user->id}}')">{{ $user->show_pass }}</td>	
									@else
										<td>{{ $user->mobile }}</td>
										<td>{{ $user->show_pass }}</td>
									@endif		
									@if($loggedUser->user_type == 1)
										<td onclick="showUsers('{{$user->id}}')">{{ $user->limit }}</td>
									@endif
									@if($loggedUser->user_type == 1)
									<td onclick="showUsers('{{$user->id}}')">{{ $user->balance }}</td>
									<td onclick="showUsers('{{$user->id}}')">{{ $user->rate }}</td>
									<td onclick="showUsers('{{$user->id}}')">{{ $amount }}</td>
									@else
									<td>{{ $user->balance }}</td>
									<td>{{ $user->rate }}</td>
									<td>{{ $amount }}</td>
									@endif
									
									@if($loggedUser->user_type == 1)
									<td onclick="showUsers('{{$user->id}}')">{{ $user->min_bet}}</td>
									<td onclick="showUsers('{{$user->id}}')">{{ $user->max_bet}}</td>
									<td onclick="showUsers('{{$user->id}}')">{{ $user->commition }}</td>
									@else
									<td>{{ $user->min_bet}}</td>
									<td>{{ $user->max_bet}}</td>
									<td>{{ $user->commition }}</td>
									@endif
									
									<td>{{ $user->comm_1 }}</td>
									<td>{{ $user->getUserName($user->comm1_user) }}</td>
									<td>{{ $user->comm_2 }}</td>
									<td>{{ $user->getUserName($user->comm2_user) }}</td>
									<td>{{ $user->comm_3 }}</td>
									<td>{{ $user->getUserName($user->comm3_user) }}</td>
									<td>{{ $user->patti_1 }}</td>
									<td>{{ $user->getUserName($user->patti1_user) }}</td>
									<td>{{ $user->patti_2 }}</td>
									<td>{{ $user->getUserName($user->patti2_user) }}</td>
									<td>{{ $user->patti_3 }}</td>
									<td>{{ $user->getUserName($user->patti3_user) }}</td>
									
									
									<td><a href="{{ route('update-user',['id' => $user->id]) }}" title="Update"><i class="fa fa-edit fa-1.5x"></i></a>
									@if($loggedUser->user_type == 1)
										<!--i class="fa fa-italic fa-1x"></i>
										<a href="{{ url('delete-user',array('id' => $user->id)) }}" title="Delete"><i class="fa fa-trash fa-1.5x"></i></a-->
										@if($user->user_type != '2' && $user->user_type !='1')
											<!--i class="fa fa-italic fa-1x"></i>
											<a href="javascript:void(0)" title="Make Admin" onclick="setAdmin('{{ $user->id}}')">Make As Admin</a-->
										@else	
											<!--i class="fa fa-italic fa-1x"></i>
											<a href="javascript:void(0)" title="Remove Admin" onclick="removeAdmin('{{ $user->id}}')">Remove As Admin</a-->
										@endif
										@if($user->isActive != '1')
											<i class="fa fa-italic fa-1x"></i>
											<a href="javascript:void(0)" class="unsus" title="Suspend User" onclick="suspendUser('{{ $user->id}}')">Suspend</a>
										@else	
											<i class="fa fa-italic fa-1x"></i>
											<a href="javascript:void(0)" class="sus"  title="Unsuspend User" onclick="unsuspendUser('{{ $user->id}}')">Unsuspend</a></td>
										@endif
										
									@endif
							</tr>
								<?php $i++; ?>
							@endforeach
						@endif
						</tbody>
					</table>
				
				</div>					<div class="ad_us">						<h2></h2>						<table class="table table-striped table-bordered table-hover">						{!! csrf_field() !!}							<thead>								<tr>									<th>#</th>									<th>Username</th>									<th>Userid</th>									<th>Mobile</th>									<th>Password</th>									<th>Credit</th>									<th>Rate</th>									<th>Amount</th>									<th>Action</th>									</tr>							</thead>							<tbody id="ad_users">														</tbody>						</table>					</div>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div class="loading_img">
			<img src="{{ asset('assets/clock-loading.gif')}}" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
@include('templates/admin-footer')

@endsection

