<?php 
	use App\User;
	use App\Heads;
?>
@extends('layouts.app')
@section('content')
@include('templates/admin-header')
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			   <h2 class="page-header">List Entries Report</h2>
			   <section class="seccess">
					@if(Session::has('flash_message'))
						<div class="alert alert-success"><em> {!! session('flash_message') !!}</em></div>
					@endif
				</section>
			</div> 
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
				<?php use App\Session; 
					$session = new Session;
					$user = new User;
					$head = new Heads;

				?>
 
					
					<div class='col-lg-12'>
					<div class="form-group">
						@if(Auth::User()->user_type == "1")	
							<div class="col-lg-3">
								<label for="inputEmail3" class="col-lg-12 control-label ">Admins:</label>
								<div class="col-lg-12">
									<select class="form-control" id="adusers" onchange="getAusers(this)">
									<option value="0">All</option>	
									@if(!$users->isEmpty())
										@foreach($users as $user)
											<option value="{{$user->id}}">{{$user->name}}</option>	
										@endforeach
									@else
										<option>No Records</option>	
									@endif	
									
									</select>
								</div>
							</div>
							<div class="col-lg-3">
								<div class="form-group">
									<label for="inputEmail3" class="col-lg-12 control-label ">Users:</label>
									<div class="col-lg-12">
										<select class="form-control" id="users"><option value="0">All</option>	</select>
									</div>
								</div>
							</div>
						@elseif(Auth::User()->user_type == "2")	
							<div class="col-lg-3">
								<label for="inputEmail3" class="col-lg-12 control-label ">Users:</label>
								<div class="col-lg-12">
									<select class="form-control" id="users">
									<option value="0">All</option>	
									@if(!$users->isEmpty())
										@foreach($users as $user)
											<option value="{{$user->id}}">{{$user->name}}</option>	
										@endforeach
									@else
										<option>No Records</option>	
									@endif	
									
									</select>
								</div>
							</div>
						@endif
						<!--div class="col-lg-3">
							<div class="form-group">
								<label for="inputEmail3" class="col-lg-12 control-label ">From:</label>
								<div class="col-lg-12">
									<input type="text" class="form-control" name="from_Date" id="from_Date" />
								</div>
							</div>
						</div> 
						
						<div class="col-lg-3">
							<div class="form-group">
								<label for="inputEmail3" class="col-lg-12 control-label ">To:</label>
								<div class="col-lg-12">
									<input type="text" class="form-control" name="to_Date" id="to_Date" />
								</div>
							</div>
						</div-->
						
					</div>	
					<div class="form-group">
					<div class="col-lg-12">
							<div class="form-group">
							<div class="col-lg-4"></div>
								<input type="button" class="col-lg-4 control-label btn btn-primary" style="margin-top:20px;" value="Submit" onclick="getUserSessRes()"/>
							<div class="col-lg-4"></div>	
							</div>
						</div>
					</div>	
					</div>
						<div class="ad_us">
						<h2></h2>
						<table class="table table-striped table-bordered table-hover">
						{!! csrf_field() !!}
							<thead>
							<tr>
								<th>User ID</th>
								<th>Session</th>
								<th>Y/N</th>	
								<th>Amount</th>	
								<th>Run</th>
								<th>Rate</th>
							</tr>
						</thead>
							<tbody id="ad_users">
							
							</tbody>
						</table>
					</div>
				</div>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div class="loading_img">
			<img src="{{ asset('assets/clock-loading.gif')}}" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
@include('templates/admin-footer')

@endsection

