@extends('layouts.app')

@section('content')

@include('templates/admin-header')

<div class="container">

        <div class="row">

            <div class="col-md-4 col-md-offset-4">

                <div class="login-panel panel panel-default">

                    <div class="panel-heading">

                        <h3 class="panel-title">App Version</h3>

                    </div>

                    <div class="panel-body">

                        <form class="form-horizontal" role="form" method="POST" action="{{ url('/postVersion') }}">

						{!! csrf_field() !!}

                            <fieldset>

								<div class="form-group">

									<label for="inputEmail3" class="col-lg-3 control-label ">App Version:</label>

									<div class="col-lg-6">

										{!! Form::text('version',$cVersion,$attributes = array("class"=>"form-control","id"=>"inputEmail3","placeholder"=>"Version")) !!}

									</div>

								</div>
								<div class="form-group">

									<div class="col-sm-offset-8 col-sm-0">

										<button type="submit" class="btn btn-primary btn-sm">Update</button>

									</div>

								</div>

                            </fieldset>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    </div>

@include('templates/admin-footer')

@endsection

