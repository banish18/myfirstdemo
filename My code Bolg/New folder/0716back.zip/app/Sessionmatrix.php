<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Sessionmatrix extends Authenticatable
{
   protected $table = 'session_matrix';
}
