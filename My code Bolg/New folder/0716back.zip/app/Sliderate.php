<?php



namespace App;



use Illuminate\Foundation\Auth\User as Authenticatable;



class Sliderate extends Authenticatable

{

   protected $table = 'slide_rate';

}

