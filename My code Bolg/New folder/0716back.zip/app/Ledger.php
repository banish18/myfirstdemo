<?php

namespace App;
use DB;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\User;
class Ledger extends Authenticatable
{
   protected $table = 'ledger';
   function getAlltotal($id,$sess_id){
	    $TotalAmount = "";
		$Ledger = DB::table('dec_ledger')->select(DB::raw('sum(amount) as amount'))
			 ->where('parent',$id)
			 ->where('sess_id',$sess_id)
			 ->first();
		if($Ledger){
			$TotalAmount = 	$TotalAmount+$Ledger->amount;
		}else{
			$TotalAmount = 0;
		}	 
			
		return $TotalAmount;
	}
	function getAllUserTotal($sess_id,$userId){
		if($userId == 1){
			$Ledger = DB::table('dec_ledger')->select(DB::raw('sum(amount) as amount'))
			 ->where('sess_id',$sess_id)
			 ->first();
		}elseif($userId == 2){
			$Ledger = DB::table('dec_ledger')->select(DB::raw('sum(amount) as amount'))
			 ->where('sess_id',$sess_id)
			 ->where('parent',$userId)
			 ->first();
		}else{
			$Ledger = DB::table('dec_ledger')->select(DB::raw('sum(amount) as amount'))
			 ->where('sess_id',$sess_id)
			 ->where('uid',$userId)
			 ->first();
		}
		
		if($Ledger){
			$TotalAmount = 	$Ledger->amount;
		}else{
			$TotalAmount = 0;
		}	 
			
		return $TotalAmount;	 
	}	function getgrantAlltotal($sess_id){	    $TotalAmount = "";		$Ledger = DB::table('dec_ledger')->select(DB::raw('sum(amount) as amount'))			->where('sess_id',$sess_id)		->first();		if($Ledger){			$TotalAmount = 	$TotalAmount+$Ledger->amount;			}else{				$TotalAmount = 0;				}					return $TotalAmount;	}
}
