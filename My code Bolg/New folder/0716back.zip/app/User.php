<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
	
	function getUserName($id){
		$user = User::find($id);
		if($user){
			$user = $user->name;
		}else{
			$user = '';
		}
		return $user;
	}
	function getAdmin($id){
		$user = User::where('id',$id)->first();
		if($user){
			$user = $user->parent_id;
		}else{
			$user = '';
		}
		return $user;
	}
	function CheckMxminbet($id,$min,$max){
		$user 	 = User::where('id',$id)->first();
		$adminbet    = $user->min_bet;
		$admaxbet    = $user->max_bet;
		if($min < $adminbet){
			return false;
		}else if($max > $admaxbet){
			return false;
		}else{
			return true;
		}
	}
	function CheckadMxminbet($id,$min,$max){
		$user 	 = User::where('id',$id)->first();
		$adminbet    = $user->min_bet;
		$admaxbet    = $user->max_bet;
		
		if($max > $admaxbet){
			$msg = array('msg' => '3','max' => $admaxbet);
		}else if($min < $adminbet){
			$msg = array('msg' => '2','min' => $adminbet);
		}else{
			$msg = array('msg' => '1','max' => $adminbet);
		}
		return  $msg; 
	}
}
