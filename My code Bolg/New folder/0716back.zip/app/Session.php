<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Session extends Authenticatable
{
   protected $table = 'sessions';
   function getSessdesc($id){
		$user = Session::find($id);
		if($user){
			$user = $user->over;
		}else{
			$user = '';
		}
		return $user;
	}
}
