<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\User;
use Auth;
use App\Session;
use App\Ledger;
use Illuminate\Support\Facades\Redirect;
use DB;
use App\Ledgerview;
use App\Sessionrec;
use Validator;

class LedgerController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
		
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$user = Auth::User();
		if($user->user_type == 0){
		   Redirect::to('/dashboard')->send();
		}
		$title = "Ledger";
		$date = date('m/d/Y');
        return view('ledger',array("title" => $title,'date' => $date));
		
    }
	
    public function postLedgerdata(Request $request){
		$validator = $this->validator($request->all());
		if($validator->fails()){
			return redirect::to('sessledger')->withErrors($validator);
			}else{
				$loggeduser = Auth::User();
				if($request->uusr_id == ""){
					$ledBalance = Ledgerview::where('uid',$loggeduser->id)->first();
				}else{
					$ledBalance = Ledgerview::where('uid',$request->uusr_id)->first();
				}
				if($request->amount > $ledBalance->balance){
					\Session::flash('flash_message','Please Try within Your Limits.');
					return redirect("sessledger");
				}else{
					if($request->uusr_id == ''){
					$uuid = $request->uusr_name;
					$uid = $loggeduser->id;
					}else{
						$uuid = $request->uusr_name;
						$uid  = $request->uusr_id;
					}
					if($request->cusr_id == ''){
						$cuid = $request->cusr_name;
						$uid1 = $loggeduser->id;
					}else{
						$cuid = $request->cusr_name;
						$uid1 = $request->cusr_id;
					}
					
					$date = date("Y-m-d",strtotime($request->ldate));
					$ledger 				= new Ledger;
					$ledger->desc 			= $request->desc;
					$ledger->uid 			= $uid;
					$ledger->date 			= $date;
					$ledger->acount_head 	= $uuid;
					$ledger->account_head2 	= $cuid;
					$ledger->debit_credit 	= "D";
					$ledger->amount 		= $request->amount;
					$ledger->save();
					$ledger 				= new Ledger;
					$ledger->desc 			= $request->desc;
					$ledger->uid 			= $uid1;
					$ledger->date 			= $date;
					$ledger->acount_head 	= $cuid;
					$ledger->account_head2 	= $uuid;
					$ledger->debit_credit 	= "C";
					$ledger->amount 		= $request->amount;
					$ledger->save();
					\Session::flash('flash_message','Record Saved');
					return redirect("sessledger");
				}
			}
	}
	protected function validator(array $data){
			return Validator::make($data, [
			'ldate' => 'required',
			'debit'    => 'required',
			'credit' => 'required',
			'amount'    => 'required'	,
			'desc'    => 'required'
			]);	
	}
	
	public function getLedgerReports(){
		$loggeduser = Auth::User();
		$ledgersview = Ledgerview::where('uid',$loggeduser->id)->first();
		$ledgers = Ledger::where('uid',$loggeduser->id)->orderBy('id','desc')->paginate(10);
		$title = "Ledger";
		if($ledgersview){ 
			if($ledgersview->balance > 0){
				$ledgersview = $ledgersview->balance.' '.'Credit';
			}else{
				$ledgersview = abs($ledgersview->balance).' '.'Debit';
			}
		}
		return view('ledger-reports',array("title" => $title,'ledgersview' => $ledgersview,'ledgers' => $ledgers));
	}
	
	
	
	public function getLedgerSessReports(){
		$loggeduser = Auth::User();
		$ledgers = DB::table('dec_ledger')->select(DB::raw('distinct sess_id,amount,date'))
                     ->where('uid',$loggeduser->id)
                     ->orderBy('id','desc')
                     ->paginate(10);	
		/* echo "<pre>";print_r($ledgers);
		die; */
		$title = "Sesssion Wise Report";
		return view('sess-reports',array("title" => $title,'ledgers' => $ledgers));
	}
	
	public function getLedgers(){
		$loggeduser = Auth::User();
		$ledgers = Ledger::where('uid',$loggeduser->id)->orderBy('id','desc')->paginate(10);
		$title = "Ledger";
		return view('ledger-sec',array("title" => $title,'ledgers' => $ledgers));
	}
	
	public function getSessRes(Request $request)
    {
		$loggeduser = Auth::User();
		$session = new Session;
		$sess_id = $request->input('sess_id');
		$sessionDesc = $session->getSessdesc($sess_id);
		$dcRuns    = Session::where('id',$sess_id)->first();
		$dcRuns    = $dcRuns->runs;
		$sessions = DB::table($sess_id.'_res')->select(DB::raw('run,amount,y_n,rate'))->where('uid',$loggeduser->id)->orderBy('id','desc')->get();
		$html = '';
		$amountSum = "";
		if($sessions){
			foreach($sessions as $session){
				$points = $session->amount/$session->rate*100;
				if($session->y_n == "1"){
					$yn = "Y";
				}else{
					$yn = "N";
				}
				
				if($session->run < $dcRuns && $session->y_n == "1"){
					$y_n = "Lost";
					$amt = $session->amount;
					$amountSum = $amountSum+$amt;
				}else if($session->run > $dcRuns && $session->y_n == "1"){
					$y_n = "Won";
					$amt = 0-$session->amount;
					if($amt < 0 &&  $session->rate != "100"){
						$amt = 0-$session->amount/$session->rate*100;
					}
					$amountSum = $amountSum+$amt;
				}else if($session->run > $dcRuns && $session->y_n == "0"){
					$y_n = "Lost";
					$amt = $session->amount;
					if($amt < 0 &&  $session->rate != "100"){
						$amt = 0-$session->amount/$session->rate*100;
					}
					$amountSum = $amountSum+$amt;
				}else if($session->run < $dcRuns && $session->y_n == "0"){
					$y_n = "Won";
					$amt = 0-$session->amount;
					$amountSum = $amountSum+$amt;
				}else if($session->run == $dcRuns && $session->y_n == "0"){
					$y_n = "Won";
					$amt = 0-$session->amount;
					$amountSum = $amountSum+$amt;
				}else if($session->run == $dcRuns && $session->y_n == "1"){
					$y_n = "Won";
					$amt = $session->amount;
					$amountSum = $amountSum+$amt;
				}
				
				
				$html .= '<tr>
									
									<td>'.$session->run.'</td>
									<td>'.$points.'</td>
									<td>'.$session->rate.'</td>
									<td>'.$yn.'</td>
									<td>'.$amt.'</td>
									</tr>';
			}
			$html .= '<tr><td></td><td></td><td></td><th>Total</th><th colspan="1">'.$amountSum.'</th></tr>';
			
		}
		$result = array('sessions' =>$html,'sess_desc' => $sessionDesc,'dc_runs' => $dcRuns);
        return $result;
	}
	public function getUSessRes(Request $request)
    {
		$userId = $request->input("uid");
		$session = new Session;
		$sess_id = $request->input('sess_id');
		$sessionDesc = $session->getSessdesc($sess_id);
		$dcRuns    = Session::where('id',$sess_id)->first();
		$dcRuns    = $dcRuns->runs;
		$sessions = DB::table($sess_id.'_res')->select(DB::raw('run,amount,y_n,rate'))->where('uid',$userId)->orderBy('id','desc')->get();
		$html = '';
		$amountSum = "";
		if($sessions){
			foreach($sessions as $session){
				$points = $session->amount/$session->rate*100;
				if($session->y_n == "1"){
					$yn = "Y";
				}else{
					$yn = "N";
				}
				if($session->run < $dcRuns && $session->y_n == "1"){
					$y_n = "Lost";
					$amt = $session->amount;
					$amountSum = $amountSum+$amt;
				}else if($session->run > $dcRuns && $session->y_n == "1"){
					$y_n = "Won";
					$amt = 0-$session->amount;
					if($amt < 0 &&  $session->rate != "100"){
						$amt = 0-$session->amount/$session->rate*100;
					}
					$amountSum = $amountSum+$amt;
				}else if($session->run > $dcRuns && $session->y_n == "0"){
					$y_n = "Lost";
					$amt = $session->amount;
					if($session->rate != "100"){
						$amt = $session->amount/$session->rate*100;
					}
					$amountSum = $amountSum+$amt;
				}else if($session->run < $dcRuns && $session->y_n == "0"){
					$y_n = "Won";
					$amt = 0-$session->amount;
					$amountSum = $amountSum+$amt;
				}else if($session->run == $dcRuns && $session->y_n == "0"){
					$y_n = "Won";
					$amt = 0-$session->amount;
					$amountSum = $amountSum+$amt;
				}else if($session->run == $dcRuns && $session->y_n == "1"){
					$y_n = "Won";
					$amt = $session->amount;
					$amountSum = $amountSum+$amt;
				}
				
				
				$html .= '<tr>
									
									<td>'.$session->run.'</td>
									<td>'.$points.'</td>
									<td>'.$session->rate.'</td>
									<td>'.$yn.'</td>
									<td>'.$amt.'</td>
									</tr>';
			}
			$html .= '<tr><td></td><td></td><td></td><th>Total</th><th colspan="1">'.$amountSum.'</th></tr>';
			
		}
		$result = array('sessions' =>$html,'sess_desc' => $sessionDesc,'dc_runs' => $dcRuns);
        return $result;
	}
	public function getDSessRes(Request $request){
		$session = new Session;
		$loggeduser = Auth::User();
		$fDate      = date('Y-m-d',strtotime($request->input('f_d')));
		$tDate      = date('Y-m-d',strtotime($request->input('t_d')));
		$ledgers = DB::table('dec_ledger')->select(DB::raw('distinct sess_id,amount,date'))
                     ->where('uid',$loggeduser->id)
					 ->whereBetween('date', [$fDate, $tDate])
                     ->orderBy('id','desc')
                     ->get();
		$html = '';
		if($ledgers){
			foreach($ledgers as $ledger){
				if($ledger->amount > 0){
									$gt = abs($ledger->amount)."(Profit)";
								}else{
									$gt = abs($ledger->amount)."(Loss)";
								}
				$html .= '<tr onclick="getSessRes('.$ledger->sess_id.')" class="diff-sess-u">
									
									<td>'.date('d-m-Y',strtotime($ledger->date)) .'</td>
									<td>'.$session->getSessdesc($ledger->sess_id) .'</td>
									<td>'.$gt.'</td>
									</tr>';
			}
		}
		$result = array('sessions' =>$html);
        return $result;
	}
	public function getSessDw(){
		$title = "Ledger";
		return view('ledger-reportsdw',array("title" => $title));
	}
	public function getSessUw(){
		$title = "Ledger Reports User Wise";
		$loggeduser = Auth::User();
		if($loggeduser->user_type == 0){
		   Redirect::to('/dashboard')->send();
		}
		if($loggeduser->user_type == "1"){
			$users = User::where('id','!=',$loggeduser->id)->where('parent','0')->paginate(); 
		}else if($loggeduser->user_type == "2"){
			$users = User::where('parent',$loggeduser->id)->where('user_type','0')->paginate();
		}
		return view('ledger-reportsuw',array("title" => $title,'users' => $users));
	}
	
	public function getUserSessReports($user_id){
		$ledgers = DB::table('dec_ledger')->select(DB::raw('distinct sess_id,amount,date'))
                     ->where('uid',$user_id)
                     ->orderBy('id','desc')
                     ->paginate();	
		$title = "Sesssion Wise Report";
		return view('sess-ureports',array("title" => $title,'ledgers' => $ledgers,'uid' => $user_id));
	}
	public function getlistEntries(){
		$title = "List Entries";
		$loggeduser = Auth::User();
		if($loggeduser->user_type == 0){
		   Redirect::to('/dashboard')->send();
		}
		if($loggeduser->user_type == "1"){
			$users = User::where('id','!=',$loggeduser->id)->where('parent','0')->paginate(10); 
		}else if($loggeduser->user_type == "2"){
			$users = User::where('parent',$loggeduser->id)->where('user_type','0')->paginate(10);
		}
		return view('list-entries',array("title" => $title,'users' => $users));
	}
	/* public function getUserSessRes($user_id){
		$sessionsres = Sessionrec::where('uid',$user_id)->orderBy('id','desc')->get();	
		$title = "Users Sesssion Record";
		return view('user-sessres',array("title" => $title,'sessionsres' => $sessionsres,'uid' => $user_id));
	} */
		public function getUsersSessRes(Request $request){
		$session = new Session;
		$uid    	= $request->input('uid');
		$Aluser     = new User;
		$adusers    = $request->input('adusers');
		$fDate      = date('Y-m-d',strtotime($request->input('f_d')));
		$tDate      = date('Y-m-d',strtotime($request->input('t_d')));
		if($adusers == "0" && $uid == "0" && $request->input('f_d') != "" && $request->input('t_d') != ""){
			$ledgers = DB::table('dec_ledger')->select(DB::raw('distinct sess_id,amount,date,uid'))
				 ->orderBy('id','desc')
				 ->whereBetween('date', [$fDate, $tDate])
				 ->get();
			$granttotalAmout = 	DB::table('dec_ledger')->select(DB::raw('sum(amount) as total'))
				 ->orderBy('id','desc')
				 ->whereBetween('date', [$fDate, $tDate])
				 ->first(); 
			$granttotalAmout = $granttotalAmout->total;	 
				 
		}else if($adusers != "0" && $uid == "0" && $request->input('f_d') != "" && $request->input('t_d') != ""){
			$ledgers = DB::table('dec_ledger')->select(DB::raw('distinct sess_id,amount,date,uid'))
                     ->where('uid',$adusers)
					 ->whereBetween('date', [$fDate, $tDate])
                     ->orderBy('id','desc')
                     ->get();
			$granttotalAmout = 	DB::table('dec_ledger')->select(DB::raw('sum(amount) as total'))
				 ->where('uid',$adusers)
				 ->whereBetween('date', [$fDate, $tDate])
				 ->orderBy('id','desc')
				 ->first();	
			$granttotalAmout = $granttotalAmout->total;		
		}else if($adusers != "0" && $uid != "0" && $request->input('f_d') != "" && $request->input('t_d') != ""){
			$ledgers = DB::table('dec_ledger')->select(DB::raw('distinct sess_id,amount,date,uid'))
					 ->where('uid',$uid)
					 ->whereBetween('date', [$fDate, $tDate])
					 ->orderBy('id','desc')
					 ->get();
			$granttotalAmout = 	DB::table('dec_ledger')->select(DB::raw('sum(amount) as total'))
				 ->where('uid',$uid)
				 ->whereBetween('date', [$fDate, $tDate])
				 ->orderBy('id','desc')
				 ->first();
				 $granttotalAmout = $granttotalAmout->total;
		}else if($adusers == "0" && $uid == "0" && $request->input('f_d') == "" && $request->input('t_d') == ""){
			$ledgers = DB::table('dec_ledger')->select(DB::raw('distinct sess_id,amount,date,uid'))
				 ->orderBy('id','desc')
				 ->get();
			$granttotalAmout = 	DB::table('dec_ledger')->select(DB::raw('sum(amount) as total'))
				 ->orderBy('id','desc')
				 ->first();	 
				 $granttotalAmout = $granttotalAmout->total;
		}else if($adusers != "0" && $uid == "0" && $request->input('f_d') == "" && $request->input('t_d') == ""){
			$users = User::where('parent',$adusers)->get(); 
			if($users){
				$amtto = "";
				foreach($users as $user){
					$ledgers = DB::table('dec_ledger')->select(DB::raw('distinct sess_id,amount,date,uid'))
                     ->where('uid',$user->id)
                     ->orderBy('id','desc')
                     ->get();
					$Allledgers[] = $ledgers;
					$granttotalAmout = 	DB::table('dec_ledger')->select(DB::raw('sum(amount) as total'))
					->where('uid',$uid)
					->orderBy('id','desc')
					->first();
					$granttotalAmout = $amtto+$granttotalAmout->total;
				}
				
				$ar = [];
				foreach($Allledgers as $d){
					if(is_array($d)){
						foreach($d as $b){
							array_push($ar,$b);
						}
					}else{
						array_push($ar,$d);
					}
				}
				$ledgers = $ar;
			}	
		}else if($adusers != "0" && $uid != "0" && $request->input('f_d') == "" && $request->input('t_d') == ""){
			$ledgers = DB::table('dec_ledger')->select(DB::raw('distinct sess_id,amount,date,uid'))
					 ->where('uid',$uid)
					 ->orderBy('id','desc')
					 ->get();
			$granttotalAmout = 	DB::table('dec_ledger')->select(DB::raw('sum(amount) as total'))
					->where('uid',$uid)
					->orderBy('id','desc')
					->first();
			$granttotalAmout = $granttotalAmout->total;
					
		}
		$html = '';
		if($ledgers){
			foreach($ledgers as $ledger){
				if($ledger->amount > 0){
									$gt = abs($ledger->amount)."(Profit)";
								}else{
									$gt = abs($ledger->amount)."(Loss)";
								}
				$html .= '<tr onclick="getUwSessRes('.$ledger->sess_id.','.$ledger->uid.')" class="diff-sess-u">
									
									<td>'.date('d-m-Y',strtotime($ledger->date)) .'</td>
									<td>'.$Aluser->getUserName($ledger->uid).'</td>
									<td>'.$session->getSessdesc($ledger->sess_id) .'</td>
									<td>'.$gt.'</td>
									</tr>';
			}
		}else{
			$html .= '<tr><td>No Records</td></tr>' ;
		}
		$result = array('sessions' =>$html,'total' => $granttotalAmout);
        return $result;
	}
	public function getUwSessRes(Request $request)
    {
		$session = new Session;
		$sess_id = $request->input('sess_id');
		$uid = $request->input('uid');
		$sessionDesc = $session->getSessdesc($sess_id);
		$dcRuns    = Session::where('id',$sess_id)->first();
		$dcRuns    = $dcRuns->runs;
		$sessions = DB::table($sess_id.'_res')->select(DB::raw('run,amount,y_n,rate'))->where('uid',$uid)->orderBy('id','desc')->get();
		$html = '';
		$amountSum = "";
		if($sessions){
			foreach($sessions as $session){
				$points = $session->amount/$session->rate*100;
				if($session->y_n == "1"){
					$yn = "Y";
				}else{
					$yn = "N";
				}
				
				if($session->run < $dcRuns && $session->y_n == "1"){
					$y_n = "Lost";
					$amt = $session->amount;
					$amountSum = $amountSum+$amt;
				}else if($session->run > $dcRuns && $session->y_n == "1"){
					$y_n = "Won";
					$amt = 0-$session->amount;
					if($amt < 0 &&  $session->rate != "100"){
						$amt = 0-$session->amount/$session->rate*100;
					}
					$amountSum = $amountSum+$amt;
				}else if($session->run > $dcRuns && $session->y_n == "0"){
					$y_n = "Lost";
					$amt = $session->amount;
					if($session->rate != "100"){
						$amt = $session->amount/$session->rate*100;
					}
					$amountSum = $amountSum+$amt;
				}else if($session->run < $dcRuns && $session->y_n == "0"){
					$y_n = "Won";
					$amt = 0-$session->amount;
					$amountSum = $amountSum+$amt;
				}else if($session->run == $dcRuns && $session->y_n == "0"){
					$y_n = "Won";
					$amt = 0-$session->amount;
					$amountSum = $amountSum+$amt;
				}else if($session->run == $dcRuns && $session->y_n == "1"){
					$y_n = "Won";
					$amt = $session->amount;
					$amountSum = $amountSum+$amt;
				}
				
				
				
				
				$html .= '<tr>
									
									<td>'.$session->run.'</td>
									<td>'.$points.'</td>
									<td>'.$session->rate.'</td>
									<td>'.$yn.'</td>
									<td>'.$amt.'</td>
									</tr>';
			}
			$html .= '<tr><td></td><td></td><td></td><th>Total</th><th colspan="1">'.$amountSum.'</th></tr>';
			
		}
		$result = array('sessions' =>$html,'sess_desc' => $sessionDesc,'dc_runs' => $dcRuns);
        return $result;
	}
	public function getUserSessRes(Request $request){
		$user_id = $request->input("uid");
		$session = new Session;
		$adusers    = $request->input('adusers');
		if($adusers == "0" && $user_id == "0"){
			$sessionsres = Sessionrec::orderBy('id','desc')->get();
		}else if($adusers != "0" && $user_id != "0"){
			$sessionsres = Sessionrec::where('uid',$user_id)->orderBy('id','desc')->get();
		}else if($adusers != "0" && $user_id == "0"){
			$users = User::where('parent',$adusers)->get(); 
			if($users){
				foreach($users as $user){
					$sessionsres = DB::table('sessions_res')
                     ->where('uid',$user->id)
                     ->orderBy('id','desc')
                     ->get();
					/* $sessionsres = Sessionrec::where('uid',$user->id)->orderBy('id','desc')->get(); */
					$Allledgers[] = $sessionsres;
					
				}
				$ar = [];
				foreach($Allledgers as $d){
					if(is_array($d)){
						foreach($d as $b){
							array_push($ar,$b);
						}
					}else{
						array_push($ar,$d);
					}
				}
				$sessionsres = $ar;
				
			}
			
		}
		$html = '';
		if($sessionsres){
			foreach($sessionsres as $sessionre){
				$html .= '<tr>
							<td>'.$sessionre->uid.'</td>
							<td>'.$session->getSessdesc($sessionre->sess_id).'</td>
							<td>'.$sessionre->y_n.'</td>
							<td>'.$sessionre->amount.'</td>
							<td>'.$sessionre->run.'</td>
							<td>'.$sessionre->rate.'</td>
						  </tr>';
			}
		}else{
			$html .= '<tr><td>No Records</td></tr>';
		}
		$result = array('sessions' =>$html);
        return $result;
	}
	public function getSessSw(){
		$title = "Ledger Reports Session Wise";
		$sessions = DB::table('sessions')
                     ->orderBy('id','desc')
					 ->get();	
		return view('ledger-reportsw',array("title" => $title,'sessions' => $sessions));
	}
	public function getUsersSwsRes(Request $request){
		$loggeduser = Auth::User();
		$session = new Session;
		$Aledger = new Ledger;
		$sess_id = $request->input('sess_id');
		$totalAmout = $Aledger->getAllUserTotal($sess_id,$loggeduser->user_type);
		$Aluser     = new User;
		if($loggeduser->user_type == 1){
			$ledgers = DB::table('dec_ledger')->where('sess_id',$sess_id)
                     ->orderBy('id','desc')
					 ->groupBy('parent')
                     ->get();
		}else if($loggeduser->user_type == 2){
			$ledgers = DB::table('dec_ledger')->where('sess_id',$sess_id)
					 ->where('parent',$loggeduser->id)
                     ->orderBy('id','desc')
					 ->groupBy('parent')
                     ->get();
		}else{
			$ledgers = DB::table('dec_ledger')->where('sess_id',$sess_id)
					 ->where('uid',$loggeduser->id)
                     ->orderBy('id','desc')
					 ->groupBy('parent')
                     ->get();
		}
		
		$html = '';
		if($ledgers){
			foreach($ledgers as $ledger){
				$amt = $Aledger->getAlltotal($Aluser->getAdmin($ledger->uid),$ledger->sess_id);
								$adName = $Aluser->getUserName($Aluser->getAdmin($ledger->uid));
				$html .= '<tr onclick="getAllAdminuserRes('.$ledger->sess_id.','.$Aluser->getAdmin($ledger->uid).')" class="diff-sess-u">
									<td>'.date('d-m-Y',strtotime($ledger->date)) .'</td>
									<td>'.$adName.'</td>
									<td>'.$session->getSessdesc($ledger->sess_id) .'</td>
									<td>'.$amt.'</td>
									</tr>';
			}
		}else{
			$html .= '<tr><td>No Records</td></tr>' ;
		}
		$result = array('sessions' =>$html,'totalAmout' => $totalAmout);
        return $result;
	}
	public function getAllusersSessRes(Request $request){
		$session = new Session;
		$uid = $request->input('uid');
		$sid = $request->input('sid');
		$Aluser     = new User;
		$ledgers = DB::table('dec_ledger')->select(DB::raw('distinct sess_id,amount,date,uid'))
				 ->where('parent',$uid)
				 ->where('sess_id',$sid)
				 ->orderBy('id','desc')
				 ->get();
		$html = '';
		if($ledgers){
			foreach($ledgers as $ledger){
				if($ledger->amount > 0){
									$gt = abs($ledger->amount)."(Profit)";
								}else{
									$gt = abs($ledger->amount)."(Loss)";
								}
								$uName = $Aluser->getUserName($ledger->uid);		
				$html .= '<a href=""><tr onclick="getSingleUSessRes('.$ledger->sess_id.','.$ledger->uid.')" class="diff-sess-u">
									<td>'.date('d-m-Y',strtotime($ledger->date)) .'</td>
									<td>'.$uName.'</td>
									<td>'.$session->getSessdesc($ledger->sess_id) .'</td>
									<td>'.$gt.'</td>
									</tr></a>';
			}
		}else{
			$html .= '<tr><td>No Records</td></tr>' ;
		}
		
		
		$result = array('sessions' =>$html);
        return $result;
	}
}

