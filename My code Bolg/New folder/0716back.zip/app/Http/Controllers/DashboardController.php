<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use App\User;
use App\Session;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$title = "Dashboard";
		$adminCount = User::where('user_type','2')->get();
		$adminCount = count($adminCount);
		$usersCount = User::where('user_type','!=','1')->where('user_type','!=','2')->get();
		$usersCount = count($usersCount);
		$sessCount  = Session::all();
		$arr = ['2','3'];	
		$Sessions = Session::orWhereIn('action',$arr)->orderBy('id', 'desc')->get();
		$runSessCount = count($Sessions);
		$sessCount  = count($sessCount);
        return view('dashboard',array("title" => $title,'admins' => $adminCount,'users' => $usersCount,'sessions' => $sessCount,'runSessCount' => $runSessCount));
    }
}
