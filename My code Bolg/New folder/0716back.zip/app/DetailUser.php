<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class DetailUser extends Authenticatable
{
   protected $table = 'users_rec';
}
