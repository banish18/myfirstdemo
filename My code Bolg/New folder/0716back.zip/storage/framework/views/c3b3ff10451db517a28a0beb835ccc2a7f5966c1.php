<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			     <section class="content-header">
                    <h1>Update User</h1>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Update User</li>
                    </ol>
                </section>
			</div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				 <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
              

                <!-- Main content -->
				<?php if(!empty($errors) && count($errors) > 0): ?>
				 <ul>
				  <?php foreach($errors->all() as $error): ?>
				   <li><?php echo e($error); ?></li>
				  <?php endforeach; ?>
				 </ul>
				<?php endif; ?> 
                
                <section class="content">
                    <div class='row'>
                    <div class='col-lg-12'>
               <?php echo Form::open(array('route' => 'edit-user','method' => 'post','class'=>'form-horizontal','role'=>'form')); ?>

					<?php echo csrf_field(); ?>

                    <div class='col-lg-12'>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Name:</label>
							<div class="col-lg-6">
								<?php echo Form::text('name',$user->name,$attributes = array("class"=>"form-control","id"=>"inputEmail3","placeholder"=>"Name")); ?>

							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label">Email:</label>
							<div class="col-lg-6">
								<?php echo Form::text('email',$user->email,$attributes = array("class"=>"form-control","id"=>"inputEmail3","placeholder"=>"Email")); ?>                             
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-8 col-sm-0">
								<button type="submit" class="btn btn-primary btn-sm">Update</button>
							</div>
						</div>
						  <input type="hidden" name="user_id" value="<?php echo $user->id; ?>" />
                    </div>    
                <?php echo Form::close(); ?> 
                       </div> </div>
                    </div>
                </section>

				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>