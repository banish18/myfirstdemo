<?php
namespace App\Http\Controllers;
use Auth;
?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header">Dashboard</h1>
		</div>
		<!-- /.col-lg-12 -->
	</div>
	<!-- /.row -->
	<div class="row">
	<div class="col-md-12">
	<?php if(Auth::User()->user_type == "1" || Auth::User()->user_type == "2"): ?>
		<div class="col-lg-3 col-md-6">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<div class="row">
						<div class="col-xs-3">
							<i class="fa fa-users fa-5x"></i>
						</div>
						<div class="col-xs-9 text-right dash_user">
						<?php if(Auth::User()->user_type == "1"): ?>
							<div class="col-xs-6"><div class="huge"><?php echo e($admins); ?></div>
							<div>Admins!</div></div>
							<div class="col-xs-6"><div class="huge"><?php echo e($users); ?></div>
							<div>Users!</div></div>
						<?php else: ?>
							<div class="huge"><?php echo e($users); ?></div>
							<div>Users!</div>	
						<?php endif; ?>	
							
							
							
						</div>
					</div>
				</div>
				<a href="<?php echo e(url('users')); ?>">
					<div class="panel-footer">
						<span class="pull-left">Users Managemant</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
				</a>
			</div>
		</div>
		<?php if(Auth::User()->user_type == "1"): ?>
		<div class="col-lg-3 col-md-6">
			<div class="panel panel-green">
				<div class="panel-heading">
					<div class="row">
						<div class="col-xs-3">
							<i class="fa fa-tasks fa-5x"></i>
						</div>
						<div class="col-xs-9 text-right">
							<div class="huge"><?php echo e($sessions); ?></div>
							<div>Sessions!</div>
						</div>
					</div>
				</div>
				<a href="<?php echo e(url('create-session')); ?>">
					<div class="panel-footer">
						<span class="pull-left">Create Session</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
				</a>
			</div>
		</div>
		<div class="col-lg-3 col-md-6">
			<div class="panel panel-yellow">
				<div class="panel-heading">
					<div class="row">
						<div class="col-xs-3">
							<i class="fa fa-shopping-cart fa-5x"></i>
						</div>
						<div class="col-xs-9 text-right">
							<div class="huge"><?php echo e($runSessCount); ?></div>
							<div>Run Session!</div>
						</div>
					</div>
				</div>
				<a href="<?php echo e(url('run-session')); ?>">
					<div class="panel-footer">
						<span class="pull-left">Run Session</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
				</a>
			</div>
		</div>
		<?php endif; ?>	
	<?php endif; ?>	
	
		<div class="col-lg-3 col-md-6">
			<div class="panel panel-red">
				<div class="panel-heading">
					<div class="row">
						<div class="col-xs-3">
							<i class="fa fa-shopping-cart fa-5x"></i>
						</div>
						<div class="col-xs-9 text-right">
							<div class="huge"></div>
							<div>Session Entry</div>
						</div>
					</div>
				</div>
				<a href="<?php echo e(url('sessionEntry')); ?>">
					<div class="panel-footer">
						<span class="pull-left">Session Entry</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
				</a>
			</div>
		</div>
		
	</div>
	<?php if(Auth::User()->user_type == "1" || Auth::User()->user_type == "2"): ?>
	<div class="col-md-12">
		<div class="col-lg-3 col-md-6">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<div class="row">
						<div class="col-xs-3">
							<i class="fa fa-shopping-cart fa-5x"></i>
						</div>
						<div class="col-xs-9 text-right">
							<div class="huge"></div>
							<div>Ledger</div>
						</div>
					</div>
				</div>
				<a href="<?php echo e(url('sessledger')); ?>">
					<div class="panel-footer">
						<span class="pull-left">Ledger</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
				</a>
			</div>
		</div>
		<div class="col-lg-3 col-md-6">
			<div class="panel panel-yellow">
				<div class="panel-heading">
					<div class="row">
						<div class="col-xs-3">
							<i class="fa fa-shopping-cart fa-5x"></i>
						</div>
						<div class="col-xs-9 text-right">
							<div class="huge"></div>
							<div>Reports</div>
						</div>
					</div>
				</div>
				<a href="<?php echo e(url('sessledger')); ?>">
					<div class="panel-footer">
						<span class="pull-left">Reports</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
				</a>
			</div>
		</div>
	</div>	
		<?php endif; ?>
	</div>
	<!-- /.row -->
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>