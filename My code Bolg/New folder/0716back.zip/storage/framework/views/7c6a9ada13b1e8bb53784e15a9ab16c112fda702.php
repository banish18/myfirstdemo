<?php
namespace App\Http\Controllers;
use Auth;
?>
<div class="navbar-default sidebar" role="navigation">
	<div class="sidebar-nav navbar-collapse">
		<ul class="nav" id="side-menu">
			<!--li class="sidebar-search">
				<div class="input-group custom-search-form">
					<input type="text" class="form-control" placeholder="Search...">
					<span class="input-group-btn">
					<button class="btn btn-default" type="button">
						<i class="fa fa-search"></i>
					</button>
				</span>
				</div>
				
			</li-->
			<li>
				<a href="<?php echo e(url('/dashboard')); ?>"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
			</li>
			<?php if(Auth::User()->user_type == "1" || Auth::User()->user_type == "2"): ?>
				<li>
					<a href="<?php echo e(url('/users')); ?>"><i class="fa fa fa-users fa-fw"></i> Users Management</a>
				</li>
				<?php if(Auth::User()->user_type == "1"): ?>
					<li>
						<a href="<?php echo e(url('/create-session')); ?>"><i class="fa fa-asl-interpreting" aria-hidden="true"></i> Create Session</a>
					</li>
					<li>
						<a href="<?php echo e(url('/run-session')); ?>"><i class="fa fa-asl-interpreting" aria-hidden="true"></i> Run Session</a>
					</li> 
					<li>
						<a href="<?php echo e(url('/run-session-auto')); ?>"><i class="fa fa-asl-interpreting" aria-hidden="true"></i> Run Session Automatic</a>
					</li> 
				<?php endif; ?>	
			<?php endif; ?>		
				<li>
					<a href="<?php echo e(url('/sessionEntry')); ?>"><i class="fa fa-beer" aria-hidden="true"></i> User Entry Details</a>
				</li>
			<?php if(Auth::User()->user_type == "1" || Auth::User()->user_type == "2"): ?>	
				<li>
					<a href="<?php echo e(url('/sessledger')); ?>"><i class="fa fa-balance-scale" aria-hidden="true"></i> Ledger Entry</a>
				</li>
			<?php endif; ?>	
				<li>
					<a href=""><i class="fa fa-newspaper-o" aria-hidden="true"></i>  Reports <span class="fa arrow"></span></a>
					<ul class="nav nav-second-level collapse">
						<li>
							<a href="#"><i class="fa fa-circle-o"></i>  Ledger Reports <span class="fa arrow"></span></a>
							<ul class="nav nav-third-level collapse">
								<li>
									<a href="<?php echo e(url('/reports')); ?>"><i class="fa fa-circle-o"></i> Transfer Ledger</a>
								</li>
							</ul>
						</li>
						<li>
							<a href="#"><i class="fa fa-circle-o"></i>  Profit & Loss Reports <span class="fa arrow"></span></a>
							<ul class="nav nav-third-level collapse">
								<!--li>
									<a href="<?php echo e(url('sess-reports')); ?>"><i class="fa fa-circle-o"></i>  Session Wise Reports</a>
								</li>
								<li>
									<a href="<?php echo e(url('reports-dw')); ?>"><i class="fa fa-circle-o"></i>  Date Wise Reports</a>
								</li-->
								<li>
									<a href="<?php echo e(url('sess-wise')); ?>"><i class="fa fa-circle-o"></i> Net Session Wise Reports</a>
								</li>
								<?php if(Auth::User()->user_type == "1" || Auth::User()->user_type == "2"): ?>
								<li>
									<a href="<?php echo e(url('user-wise')); ?>"><i class="fa fa-circle-o"></i> Net User Wise Reports</a>
								</li>
								<li>
									<a href="<?php echo e(url('list-entries')); ?>"><i class="fa fa-circle-o"></i>  List Of Entries Reports</a>
								</li>
								<li>
									<a href="<?php echo e(url('getDetailreports')); ?>"><i class="fa fa-circle-o"></i>  Detail Reports</a>
								</li>
								<?php endif; ?>
							</ul>
						</li>
						<!--li>
							<a href="<?php echo e(url('ledger')); ?>"><i class="fa fa-circle-o"></i>  Ledger Reports</a>
						</li-->
					</ul>
				</li>				<?php if(Auth::User()->user_type == "1"): ?>					<li>						<a href="<?php echo e(url('/app-version')); ?>"><i class="fa fa-asl-interpreting" aria-hidden="true"></i> App Version</a>					</li>	
				<li>
					<a href="<?php echo e(url('/slider-rate')); ?>"><i class="fa fa-balance-scale" aria-hidden="true"></i> Slider</a>
				</li>
							<?php endif; ?>	
				
			
		</ul>
	</div>
	<!-- /.sidebar-collapse -->
</div>
<!-- /.navbar-static-side -->
</nav>