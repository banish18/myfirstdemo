<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			   <h2 class="page-header">Manage Users</h2>
			   <section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section>
			</div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover">
						<thead>
							<tr>
								<th>#</th>
								<th>Username</th>
								<th>Email</th>
								<th>Action</th>								
							</tr>
						</thead>
						<tbody>
						<?php if($users): ?>
							<?php foreach($users as $user): ?>
								<tr>
									<td>#</td>
									<td><?php echo e($user->name); ?></td>
									<td><?php echo e($user->email); ?></td>
									<td><a href="<?php echo e(route('update-user',['id' => $user->id])); ?>" title="Update"><i class="fa fa-edit fa-1.5x"></i></a><i class="fa fa-italic fa-1x"></i><a href="<?php echo e(url('delete-user',array('id' => $user->id))); ?>" title="Delete"><i class="fa fa-trash fa-1.5x"></i></a></td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
						</tbody>
					</table>
				</div>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>