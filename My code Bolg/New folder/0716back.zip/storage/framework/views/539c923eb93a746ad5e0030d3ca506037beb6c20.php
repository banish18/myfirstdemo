<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<!-- /.panel-heading -->
			<div class="panel-body">
			<section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section>
			<?php echo csrf_field(); ?>

				<div class="table-responsive">
					<div class="my-session">
						<h3 onclick="shSess(this)">Create Session</h3>
						<div class="slide-cont">
							<p><textarea id="over"></textarea><select id="ac"><option value="1">Activate</option><option value="Deactivate">Deactivate</option></select></p>
							<p><input type="submit" id="Create" value="Create" onclick="ctSess(this)" /></p>
						</div>
						<div class="st_ct">
							<p id="tm"></p>
							<p><label>Run Diffrence</label><select id="rn_diff" onchange="rndiff(this)"><option value="0">Please Select</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option></select></p>
							<p><label>Rate</label><select id="sess_rt" onchange="ssrate(this)"><option value="0:0">Please Select</option><option value="90:110">90:110</option><option value="100:150">100:150</option><option value="200:250">200:250</option><option value="250:400">250:400</option></select></p>
							<div class="cr_sess">
								<span>
									<h3>Current Session</h3>
									<b id="rt_1"></b>
									<b id="rt_2"></b>
								</span>
							</div>
							<input type="hidden" id="sess_id" />
							<p><span><input onclick="isActivesess()" type="button" name="suspend" id="suspend" value="Suspend"/></span></p>
							
						</div>
					</div>
				</div>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>