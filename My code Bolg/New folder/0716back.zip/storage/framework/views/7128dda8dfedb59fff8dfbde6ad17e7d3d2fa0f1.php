
<?php 
	use App\User;
?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			   <h2 class="page-header">Session Entry</h2>
			   <div class="alrt_msg" id="alrt_msg"></div>
			   <!--section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section-->
			</div> 
			<!-- /.panel-heading -->
			<div class="panel-body">
					<div class='row'>
					<div class='col-lg-8'>
							<?php echo Form::open(array('route' => 'add-sess-entry','method' => 'post','class'=>'form-horizontal','role'=>'form','autocomplete'=>'off')); ?>

								<?php echo csrf_field(); ?> 
								<div class='col-lg-9'>
									<div class="form-group">
										<select class="form-control" name="sess" id="sess" onchange="showSessRt(this)">
											<?php if($sessions): ?>
												<option value="0">Please Select</option>
												<?php foreach($sessions as $session): ?>
													<option value="<?php echo e($session->id); ?>"><?php echo e($session->over); ?></option>
												<?php endforeach; ?>	
											<?php endif; ?>	
										</select>
									</div>
									
								</div>
								<!--div class="col-lg-12">
									<div class="session_entry">
										<div class='col-lg-12'>
											<div class="form-group">
												<div class='col-lg-3 pd_rm'>
													<label for="inputEmail3" class="col-lg-12 control-label aln_cnt">User</label>
													<div class="col-lg-12">
													<?php echo Form::text('sess_user','',$attributes = array("class"=>"form-control","id"=>"sess_user","placeholder"=>"user",'onkeyUp' => 'getSessUsers()','id' => 'esess_user')); ?>

													<ul id="users_list"></ul>
													</div>
												</div>
												<div class='col-lg-2 pd_rm'>
													<label for="inputEmail3" class="col-lg-12 control-label aln_cnt">Runs</label>
													<div class="col-lg-12">
														<?php echo Form::text('runs','',$attributes = array("class"=>"form-control","id"=>"runs","placeholder"=>"Runs")); ?>

													</div>
												</div>
												<div class='col-lg-3 pd_rm'>
													<label for="inputEmail3" class="col-lg-12 control-label aln_cnt">Amount</label>
													<div class="col-lg-12">
														<?php echo Form::text('amount','',$attributes = array("class"=>"form-control","id"=>"amount","placeholder"=>"Amount")); ?>

													</div>
												</div>
												<div class='col-lg-2 pd_rm'>
													<label for="inputEmail3" class="col-lg-12 control-label aln_cnt">Y/N</label>
													<div class="col-lg-12">
														<select class="form-control" name="y_n" id="y_n">
															<option value="1">Y</option>
															<option value="0">N</option>
														</select>
													</div>
												</div>
												<div class='col-lg-2 pd_rm'>
													<label for="inputEmail3" class="col-lg-12 control-label aln_cnt">Rate</label>
													<div class="col-lg-12">
														<?php echo Form::text('rate','100',$attributes = array("class"=>"form-control","id"=>"rate","placeholder"=>"Rate")); ?>

														<ul id="yrates_list"></ul>
													</div>
												</div>
											</div>
											<div class="form-group">
											<div class="col-lg-3"></div>
												<div class="col-lg-3">
													<label for="inputEmail3" class="col-lg-12 control-label aln_cnt"> </label>
													<button type="button" class="btn btn-primary btn-sm col-lg-12 sb_se" onclick="return checkSessEntrySub()">Add</button>
												</div>
												<div class="col-lg-3"></div>
											</div>	
											
										</div>	
									</div>
								</div-->
								<input type="hidden" id="sess_id" name="sess_id" value=""/>
											<input type="hidden" id="usr_id" name="usr_id" />
							<?php echo Form::close(); ?> 
						</div>
						<div class='col-lg-8'>
							<div class="matrix_slider">
								 <table class="table">
									<thead><td>#</td><td>Admin</td><td>User</td><td>Run</td><td>Amount</td><td>Y/N</td><td>Action</td></thead>
									<tbody id="ses_records">
										
									</tbody>
								 </table>
							</div>
						</div>	
						<div class="col-lg-4">
							<div class="matrix_slider">
								 <table class="table">
									<thead><th>Runs</th><th>Amount</th></thead>
									<tbody id="ses_mtrx">
										
									</tbody>
								 </table>
							</div>	
						</div>
					</div>
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div class="loading_img">
			<img src="<?php echo e(asset('assets/clock-loading.gif')); ?>" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
<?php echo Html::script('assets/admin/js/angular.js'); ?>

<script>

var app = angular.module('plunker', []);

        app.controller('MainCtrl', ['$scope', '$interval', function($scope, $interval) {
            var interval = $interval(function() {
               var sess_id = jQuery("#sess_id").val();
			   if(sess_id != ""){
				    var token = jQuery("input[name=_token]").val();
					var request = jQuery.ajax({
						type:"post",
						url:"getsesMtx",
						data:{sess_id:sess_id,_token:token}
					});
					request.done(function (response){
						jQuery(".loading_img").hide();
						jQuery(".matrix_slider").show();
						jQuery('#ses_mtrx').html(response.html);
						jQuery('#ses_records').html(response.html2);
					});
			   }else{
				   return true;
			   }
				
            }, 2000); 
        }]); 
</script>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>