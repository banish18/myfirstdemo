<?php 
	use App\User;
	use App\Heads;
?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			   <h2 class="page-header">User Wise Report</h2>
			   <section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section>
			</div> 
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
				<?php use App\Session; 
					$session = new Session;
					$user = new User;
					$head = new Heads;

				?>
					<div class='col-lg-12'>
					<div class="form-group">
						<?php if(Auth::User()->user_type == "1"): ?>	
							<div class="col-lg-3">
								<label for="inputEmail3" class="col-lg-12 control-label ">Admins:</label>
								<div class="col-lg-12">
									<select class="form-control" id="adusers" onchange="getAusers(this)">
									<option value="0">All</option>	
									<?php if(!$users->isEmpty()): ?>
										<?php foreach($users as $user): ?>
											<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>	
										<?php endforeach; ?>
									<?php else: ?>
										<option>No Records</option>	
									<?php endif; ?>	
									
									</select>
								</div>
							</div>
							<div class="col-lg-3">
								<div class="form-group">
									<label for="inputEmail3" class="col-lg-12 control-label ">Users:</label>
									<div class="col-lg-12">
										<select class="form-control" id="users"><option value="0">All</option>	</select>
									</div>
								</div>
							</div>
						<?php elseif(Auth::User()->user_type == "2"): ?>	
							<div class="col-lg-3">
								<label for="inputEmail3" class="col-lg-12 control-label ">Users:</label>
								<div class="col-lg-12">
									<select class="form-control" id="users">
									<option value="0">All</option>	
									<?php if(!$users->isEmpty()): ?>
										<?php foreach($users as $user): ?>
											<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>	
										<?php endforeach; ?>
									<?php else: ?>
										<option>No Records</option>	
									<?php endif; ?>	
									
									</select>
								</div>
							</div>
						<?php endif; ?>							<?php $date = date('Y-m-d'); ?>
						<div class="col-lg-3">
							<div class="form-group">
								<label for="inputEmail3" class="col-lg-12 control-label ">From:</label>
								<div class="col-lg-12">
									<input type="text" class="form-control" name="from_Date" id="from_Date" value="<?=$date?>" />
								</div>
							</div>
						</div> 	
						
						<div class="col-lg-3">
							<div class="form-group">
								<label for="inputEmail3" class="col-lg-12 control-label ">To:</label>
								<div class="col-lg-12">
									<input type="text" class="form-control" name="to_Date" id="to_Date" value="<?=$date?>" />
								</div>
							</div>
						</div>
						
					</div>	
					<div class="form-group">
					<div class="col-lg-12">
							<div class="form-group">
							<div class="col-lg-4"></div>
								<input type="button" class="col-lg-4 control-label btn btn-primary" style="margin-top:20px;" value="Submit" onclick="getUsersSessRes()"/>
							<div class="col-lg-4"></div>	
							</div>
						</div>
					</div>	
					</div>					<h3 style="float:right">Net Loss/Profit : <b id="nt_lp">0</b></h3>
					<div class="sh_ss">
					<div class="ses_rp">					
						<table class="table table-striped table-bordered table-hover">
						<?php echo csrf_field(); ?>

							<thead>
								<tr>
									<th>Date</th>
									<th>User</th>
									<th>Session Description</th>
									<th>Amount </th>						
								</tr>
							</thead>
							<tbody id="show_sessions">
								
							</tbody>
						</table>
						
					</div>	
					<div class="ad_us">
						<h2></h2>
						<h3></h3>
						<div class="ses_rp2">
						<table class="table table-striped table-bordered table-hover">
						<?php echo csrf_field(); ?>

							<thead>
								<tr>
									<th>Runs</th>
									<th>Points</th>
									<th>Rate</th>
									<th>Y/N</th>
									<th>Amount</th>								
								</tr>
							</thead>
							<tbody id="ad_users">
							
							</tbody>
						</table>
						</div>
					</div>
					</div>
				</div>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div class="loading_img">
			<img src="<?php echo e(asset('assets/clock-loading.gif')); ?>" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>