<?php 
date_default_timezone_set('Asia/kolkata');
include('inc/functions.php');
ini_set('memory_limit','512M');
ini_set("log_errors" , "1");
ini_set("error_log" , "Errors.log.txt");
ini_set("display_errors" , "0");
if(isset($_POST) && (count($_POST)>0) ){	
}else{
	$json_raw = file_get_contents('php://input');
	if($json_raw){
		$obj = new fairsession; 
		$obj -> saveRequest($json_raw);
	}	
	$_POST = json_decode($json_raw, TRUE);	
} 
/* $_POST["action"]     	= "saveSliderate";
$_POST["sess_id"]     = "110";  
$_POST["rt_rate"]     = "6";  
$_POST["rt"]     = "-2";  */ 
/*
$_POST["userid"]     = "100001";
$_POST["password"]    = "manish@123";  */
 

try {
	switch (isset($_POST['action']) ? ($_POST['action']) : 'Wrong') {
		case 'login': 
		$obj 		= new fairsession; 
		$userid 	= isset($_POST["userid"]) ? $_POST["userid"] : "";
		$password 	= isset($_POST["password"]) ? $_POST["password"] : "";
		$response 	= $obj->login($userid,$password);
		break;
		
		case 'getRunSess': 
		$obj 		= new fairsession; 
		$response 	= $obj->getRunSessres();
		break;
		
		case 'getSession': 
		$obj 			= new fairsession; 
		$session_id 	= isset($_POST["session_id"]) ? $_POST["session_id"] : "";
		$response 		= $obj->getSess($session_id);
		break;
		
		case 'saveSliderate': 
		$obj 		= new fairsession; 
		$rt 		= isset($_POST["rt"]) ? $_POST["rt"] : "";
		$rt_rate 	= isset($_POST["rt_rate"]) ? $_POST["rt_rate"] : "";
		$sess_id 	= isset($_POST["sess_id"]) ? $_POST["sess_id"] : "";
		$response   = $obj->saveRt($rt,$rt_rate,$sess_id);
		break;
		
		default:
            throw new Exception('Wrong action !');
	}
	echo str_replace("\/", "/", json_encode($response));
}
// If any exception occurs then send the error in json.
catch (Exception $e) {
    die(json_encode(array('error' => $e->getMessage())));
}	


?>

