<?php  
include('connection.php');
date_default_timezone_set('Asia/Kolkata'); 
include_once('simple_html_dom.php');
set_time_limit(0);
class fairsession{
	function saveRequest($post){
		global $mysqli;
		$results = $mysqli->query("insert into test set request	='".$post."'");
	}
	function login($userid,$password,$app_ver){
		global $mysqli;
	if($app_ver != ""){ 
			$results = $mysqli->query("select * from users where userid= '".$userid."' and show_pass='".$password."'");
			if($results->num_rows > 0){
				$row = $results->fetch_array(MYSQLI_BOTH);			
				$userId = $row["userid"];
				$Verresults = $mysqli->query("select version from app_version");
				$Verrow = $Verresults->fetch_array(MYSQLI_BOTH);		
				$appver = $Verrow["version"];
				$dir    = 'http://fairsession.com/apprelease/fairsession.apk';
				if($appver == ""){
					//$mysqli->query("update app_version set version = '".$app_ver."'");
					$msg = array("responseData" => array("status" => "1", "result" => $userId,'app_link' => $dir
					));
				}else{
						if($appver > $app_ver){
							//$mysqli->query("update app_version set version = '".$app_ver."'");
							$msg = array("responseData" => array("status" => "1", "result" => $userId,'app_link' => $dir ));
						}else{
							$msg = array("responseData" => array("status" => "1", "result" => $userId,'app_link' => 'empty'));
						}
					}
			}else{
				$msg = array("responseData" => array("status" => "0", "error" => "Please Check userid and password"));
			}
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "Please install updated version or contact to admin" ));
		} 
		return $msg;
	}
	function changePassword($userid,$password){
		global $mysqli;
		$options = ['cost' => '12'];
		$passwordE =  password_hash($password,PASSWORD_BCRYPT,$options);
		$results = $mysqli->query("update users set password = '".$passwordE."',show_pass = '".$password."' where userid='".$userid."'");
		if($results){
			$msg = array("responseData" => array("status" => "1", "result" => "Password Successfully Changed."));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "Please Try Again."));
		}
		return $msg;
	}
	function getSess($userid){
		global $mysqli;
		$useridQry 		= $mysqli->query("select id from users where userid=".$userid);
		$useridRow 		= $useridQry->fetch_array(MYSQLI_BOTH);
		$balanceRes     = $mysqli->query("select balance from ledbalance where uid=".$useridRow["id"]);
		$balanceRow     = $balanceRes->fetch_array(MYSQLI_BOTH);
		if($balanceRow["balance"] != " " ){
			$balance        = $balanceRow["balance"];
		}else{
			$balance = "0";
		}
		$results = $mysqli->query("select * from sessions where isActive= '0'");
		if($results->num_rows > 0){
			$row 		= $results->fetch_array(MYSQLI_BOTH);
			$Srate 		= $row["sess_rate"];
			if($Srate == ":"){
				$sess_id 	= $row["id"];
				$runs 		= $row["runs"];
				$rate 		= $row["rate"];
				if($rate != '0:0'){
					$rate2 = explode(":",$rate);
					$rate2 = $runs.':'.$rate2[1].','.$runs.':'.$rate2[0];
					$Srate = "empty";
				}else{
					$rate2 = "empty";
				}
				$over 		= $row["over"];
				$runss       = [];
				
				$result 	= $mysqli->query("select rate,run,y_n,amount from sessions_res where sess_id=". $sess_id." and uid=".$useridRow["id"]);
				while($row 		= $result->fetch_array(MYSQLI_BOTH)){
					$rows[] = $row;
					array_push($runss,$row["run"]);
				}
				$result2 	= $mysqli->query("select runs,sum(amount) as amount from matrix_view where sid=". $sess_id." and uid=".$useridRow["id"]." group by runs");
				while($row2 		= $result2->fetch_array(MYSQLI_BOTH)){
					$rows2[] = $row2; 
				}
				if(empty($rows)){
					$rows = [];
				}
				if(empty($rows2)){
					$rows2 = [];
				}
				if($runss){
					$minval = min($runss);
				}else{
					$minval = "0";
				}
				$msg = array("responseData" => array("status" => "1", "result" => $Srate,'sess_id' => $sess_id,'desc' => $over,'rate2' => $rate2,'balance' => $balance,'rs1' => $rows,'rs2' => $rows2,'minval' => $minval));
			}else{
				$msg = array("responseData" => array("status" => "0", "error" => "No Rates Please Wait for another rate",'balance' => $balance));
			}
			
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Rates Please Wait for another rate",'balance' => $balance));
		}
		return $msg;
	}
	function getSesstest($userid,$session_id){
		global $mysqli;
		$useridQry 		= $mysqli->query("select id from users where userid=".$userid);
		$useridRow 		= $useridQry->fetch_array(MYSQLI_BOTH);
		$balanceRes     = $mysqli->query("select balance from ledbalance where uid=".$useridRow["id"]);
		$balanceRow     = $balanceRes->fetch_array(MYSQLI_BOTH);
		if($balanceRow["balance"] != " " ){
			$balance        = $balanceRow["balance"];
		}else{
			$balance = "0";
		}
		
		$getexposureRes = $mysqli->query("select amount from exposure where uid =".$useridRow["id"]);
		$getexposureRow = $getexposureRes->fetch_array(MYSQLI_BOTH);
		if($getexposureRes->num_rows > 0){
			$exposure        = abs($getexposureRow["amount"]);
		}else{
			$exposure = "0";
		}
					
		$runss       = [];
		$result 	= $mysqli->query("select rate,run,y_n,amount from sessions_res where sess_id=". $session_id." and uid=".$useridRow["id"]);
		while($row 		= $result->fetch_array(MYSQLI_BOTH)){
			$rows[] = $row;
			array_push($runss,$row["run"]);
		}
		$result2 	= $mysqli->query("select runs,sum(amount) as amount from matrix_view where sid=". $session_id." and uid=".$useridRow["id"]." group by runs");
		while($row2 		= $result2->fetch_array(MYSQLI_BOTH)){
			$rows2[] = $row2; 
		}
		if(empty($rows)){
			$rows = [];
		}
		if(empty($rows2)){
			$rows2 = [];
		}
		if($runss){
		  $minval = min($runss);
		}else{
		   $minval = "0";
		}
	
		$checkAdUserLoggInRes = $mysqli->query("select updated_at from admin_login_check");
		$checkAdUserLoggInRow 		= $checkAdUserLoggInRes->fetch_array(MYSQLI_BOTH);
		$time = strtotime(date('Y-m-d h:i:s')); 
		/*echo date('Y-m-d h:i:s').'str'.$time;
		echo 'str'.strtotime($checkAdUserLoggInRow["updated_at"]).'time'.$checkAdUserLoggInRow["updated_at"];
		die;  */
		/* if($time < strtotime($checkAdUserLoggInRow["updated_at"])+4){  */
			$results = $mysqli->query("select * from sessions where isActive= '0' and id=".$session_id);
			if($results->num_rows > 0){
				$row 		= $results->fetch_array(MYSQLI_BOTH);
				$Srate 		= $row["sess_rate"];
				if($Srate == ":"){
					$msg = array("responseData" => array("status" => "0", "error" => "No Rates Please Wait for another rate",'balance' => $balance,'rs1' => $rows,'rs2' => $rows2,'minval' => $minval,'exposure' => $exposure));
				}else{
					$sess_id 	= $row["id"];
					$runs 		= $row["runs"];
					$rate 		= $row["rate"];
					if($rate != '0:0'){
						$rate2 = explode(":",$rate);
						$rate2 = $runs.':'.$rate2[1].','.$runs.':'.$rate2[0];
						$Srate = "empty";
					}else{
						$rate2 = "empty";
					}
					$over 		= $row["over"];
					
					$msg = array("responseData" => array("status" => "1", "result" => $Srate,'sess_id' => $sess_id,'desc' => $over,'rate2' => $rate2,'balance' => $balance,'rs1' => $rows,'rs2' => $rows2,'minval' => $minval,'exposure' => $exposure));
				}
			}else{
				$msg = array("responseData" => array("status" => "0", "error" => "No Rates Please Wait for another rate",'balance' => $balance,'rs1' => $rows,'rs2' => $rows2,'minval' => $minval,'exposure' => $exposure));
			}
		/* }else{
			$mysqli->query("update sessions set isActive = '1'");
			$msg = array("responseData" => array("status" => "0", "error" => "No Rates Please Wait for another rate",'balance' => $balance,'rs1' => $rows,'rs2' => $rows2,'minval' => $minval,'exposure' => $exposure));
		} */
		return $msg;
	}
	function saveSess($userid,$sess_id,$y_n,$amount,$run){
		global $mysqli;
		$rate = explode(":",$run);
		$run  = explode(":",$run);
		$rt = $amount*$rate[1]/100;
		if($rate[1] == "100"){
			$rt2 = $amount*$rate[1]/100;
		}else{
			$rt2 = $amount*100/100;
		}
		$getBetsRes = $mysqli->query("select min_bet,max_bet from users where userid=".$userid);
		$getBetsRow = $getBetsRes->fetch_array(MYSQLI_BOTH);
		$min_bet    = $getBetsRow["min_bet"];
		$max_bet    = $getBetsRow["max_bet"];
		/*
			Set Bet Sleep time
		*/
		$sleepRes   = $mysqli->query("select sleep_value from sleep_val LIMIT 1");
		if($sleepRes->num_rows > 0){
			$sleepRow   = $sleepRes->fetch_array(MYSQLI_BOTH);
			$sleepVal   = $sleepRow["sleep_value"];
		}else{
			$sleepVal = "6";
		}
		if($min_bet == 0 && $max_bet == 0){
			$getuidRes = $mysqli->query("select id from users where userid =".$userid);
			$getuidRow = $getuidRes->fetch_array(MYSQLI_BOTH);
			$userid    = $getuidRow["id"];
			$checkSess 			= $mysqli->query("select isActive from sessions where id=".$sess_id);
			$checkSessrow 		= $checkSess->fetch_array(MYSQLI_BOTH);
			$stat = $checkSessrow["isActive"];
			if($stat == 1){
				$msg = array("responseData" => array("status" => "0", "error" => "Market Suspended Try Again"));
			}else{
				
				sleep($sleepVal);
				$checkSess 			= $mysqli->query("select isActive from sessions where id=".$sess_id);
				$checkSessrow 		= $checkSess->fetch_array(MYSQLI_BOTH);
				$stat = $checkSessrow["isActive"];
				if($stat == 1){
					$msg = array("responseData" => array("status" => "0", "error" => "Market Suspended Try Again"));
				}else{
					if($y_n == 0){
						$sessRecordRes 	= $mysqli->query("select * from sessions where id=".$sess_id);
						$sessRecordRow 	= $sessRecordRes->fetch_array(MYSQLI_BOTH);
						$dbrate 			= explode(":",$sessRecordRow["sess_rate"]);
						$rts 			= $sessRecordRow["rate"];
						if($rts == "0:0"){
							$dbrate 			= explode(":",$sessRecordRow["sess_rate"]);
							$dbrate 			= $dbrate[0];
						}else{
							$dbrate 			= $sessRecordRow["runs"];
						}
						if($dbrate >= $run[0]){
							$sleep = 1;
							$obj = new fairsession; 
							$res = $obj->saveRate($userid,$sess_id,$y_n,$rt,$run[0],$rate[1],$rt2);
							return $res;
						}else{
							$msg = array("responseData" => array("status" => "0", "error" => "Bet Rejected Rate Changed"));
						}
					}else if($y_n == 1){
						$sessRecordRes 	= $mysqli->query("select * from sessions where id=".$sess_id);
						$sessRecordRow 	= $sessRecordRes->fetch_array(MYSQLI_BOTH);
						$rts 			= $sessRecordRow["rate"];
						if($rts == "0:0"){
							$dbrate 			= explode(":",$sessRecordRow["sess_rate"]);
							$dbrate 			= $dbrate[1];
						}else{
							$dbrate 			= $sessRecordRow["runs"];
						}
						if($dbrate <= $run[0]){
							$sleep = 1;
							$obj = new fairsession; 
							$res = $obj->saveRate($userid,$sess_id,$y_n,$rt,$run[0],$rate[1],$rt2);
							return $res;
						}else{
							$msg = array("responseData" => array("status" => "0", "error" => "Bet Rejected Rate Changed"));
						}
					}
				}
			}
		}else{
			if($min_bet != 0 && $max_bet != 0){
				if($rt < $min_bet){
					$msg = array("responseData" => array("status" => "0", "error" => "Less than minimum allowed for You. Please try above minimum."));
					return $msg;
				}
				if($rt > $max_bet){
					$msg = array("responseData" => array("status" => "0", "error" => "More than maximum allowed for You. Please try below maximum."));
					return $msg; 
				}
			}
			if($min_bet != 0 && $max_bet == 0){
				if($rt < $min_bet){
					$msg = array("responseData" => array("status" => "0", "error" => "Less than minimum allowed for You. Please try above minimum."));
					return $msg;   
				}
			}
			if($max_bet != 0 && $min_bet == 0){
				if($rt > $max_bet){
					$msg = array("responseData" => array("status" => "0", "error" => "More than maximum allowed for You. Please try below maximum."));
					return $msg;
				}
			}
			$getuidRes = $mysqli->query("select id from users where userid =".$userid);
			$getuidRow = $getuidRes->fetch_array(MYSQLI_BOTH);
			$userid    = $getuidRow["id"];
			$checkSess 			= $mysqli->query("select isActive from sessions where id=".$sess_id);
			$checkSessrow 		= $checkSess->fetch_array(MYSQLI_BOTH);
			$stat = $checkSessrow["isActive"];
			if($stat == 1){
				$msg = array("responseData" => array("status" => "0", "error" => "Market Suspended Try Again"));
			}else{
				sleep($sleepVal);
				$checkSess 			= $mysqli->query("select isActive from sessions where id=".$sess_id);
				$checkSessrow 		= $checkSess->fetch_array(MYSQLI_BOTH);
				$stat = $checkSessrow["isActive"];
				if($stat == 1){
					$msg = array("responseData" => array("status" => "0", "error" => "Market Suspended Try Again"));
				}else{
					if($y_n == 0){
						$sessRecordRes 	= $mysqli->query("select * from sessions where id=".$sess_id);
						$sessRecordRow 	= $sessRecordRes->fetch_array(MYSQLI_BOTH);
						$rts 			= $sessRecordRow["rate"];
						if($rts == "0:0"){
							$dbrate 			= explode(":",$sessRecordRow["sess_rate"]);
							$dbrate 			= $dbrate[0];
						}else{
							$dbrate 			= $sessRecordRow["runs"];
						}
						if($dbrate >= $run[0]){
							$sleep = 1;
							$obj = new fairsession; 
							$res = $obj->saveRate($userid,$sess_id,$y_n,$rt,$run[0],$rate[1],$rt2);
							return $res;
						}else{
								$msg = array("responseData" => array("status" => "0", "error" => "Bet Rejected Rate Changed"));
						}
					}else if($y_n == 1){
						$sessRecordRes 	= $mysqli->query("select * from sessions where id=".$sess_id);
						$sessRecordRow 	= $sessRecordRes->fetch_array(MYSQLI_BOTH);
						$rts 			= $sessRecordRow["rate"];
						if($rts == "0:0"){
							$dbrate 			= explode(":",$sessRecordRow["sess_rate"]);
							$dbrate 			= $dbrate[1];
						}else{
							$dbrate 			= $sessRecordRow["runs"];
						}
						if($dbrate <= $run[0]){
							$sleep = 1;
							$obj = new fairsession; 
							$res = $obj->saveRate($userid,$sess_id,$y_n,$rt,$run[0],$rate[1],$rt2);
							return $res;
						}else{
							$msg = array("responseData" => array("status" => "0", "error" => "Bet Rejected Rate Changed"));
						}
					}
				} 
			}
		}
		return $msg;
	}
	/** 
		Start 600 entreies insert logic converted to 5 enteries
	*/
	function saveRate($userid,$sess_id,$y_n,$rt,$run,$rate,$rt2){
		global $mysqli;
		$results = $mysqli->query("insert into sessions_res set uid = '".$userid."',sess_id = '".$sess_id."',y_n = '".$y_n."',amount = '".$rt."',run = '".$run."',rate = '".$rate."'");
		if($results){
			$id = $mysqli->insert_id;
			
			/**
				Start code Get Admin Id
			*/
			$getAdminRes = $mysqli->query("select parent_id from users where id =".$userid);
			$getAdminRow = $getAdminRes->fetch_array(MYSQLI_BOTH);
			$adId        = $getAdminRow["parent_id"];
			
			/**
				End code Get Admin Id
			*/
			
			/**
				Start code O entry of bet
			*/
			
			$mysqli->query("insert into session_matrix set sid = '".$sess_id."',uid = '".$userid."',runs = '".$run."',amount = '".$rt."',parent_id = ".$id.",admin_id = ".$adId.",type = 'O'");
			
			/**
				End code O entry of bet
			*/
			
			$sessMatrix = [];
			$sessMatrix2 = [];
			$entryVar = 2;  
			for($i =$run-2;$i<$run;$i++){
				array_push($sessMatrix,$i);
			}
			for($j = $run+1;$j<$run+1+$entryVar;$j++){
				array_push($sessMatrix2,$j);
			}
			$sessMatrix = array_merge($sessMatrix,$sessMatrix2);
			if($y_n == 1){
				$amount1 = [];
				$amount2 = []; 
				$type1 = [];
				$type2 = [];
				for($i =$run-2;$i<$run;$i++){
					array_push($amount1,'-'.$rt2);
					array_push($type1,'N');
				}
				for($j = $run+1;$j<$run+1+$entryVar;$j++){
					array_push($amount2,'+'.$rt);
					array_push($type2,'P');
				}
			}else{
				$amount1 = [];
				$amount2 = [];
				$type1 = [];
				$type2 = [];
				for($i =$run-2;$i<$run;$i++){
					array_push($amount1,'+'.$rt2);
					array_push($type1,'P');
				}
				for($j = $run+1;$j<$run+1+$entryVar;$j++){
					array_push($amount2,'-'.$rt);
					array_push($type2,'N');
				}
			}
			
			$sessAmount = array_merge($amount1,$amount2);
			$type = array_merge($type1,$type2);
			$i = 0;
			foreach($sessMatrix  as $sm){
				$mysqli->query("insert into session_matrix set sid = '".$sess_id."',uid = '".$userid."',runs = '".$sm."',amount = '".$sessAmount[$i]."',parent_id = ".$id.",admin_id = ".$adId.",type = '".$type[$i]."'");
				$i++;
			}
			/**
				Start code to call procedure
			*/ 
			
				$mysqli->query("CALL proc_session_matrix(".$id.")");
			
			/**
				End code to call procedure
			*/
			$getviewBalanceRes = $mysqli->query("select balance from ledbalance where uid =".$userid);
			$getviewBalanceRow = $getviewBalanceRes->fetch_array(MYSQLI_BOTH);
			/* exposure rate*/
			$getexposureRes = $mysqli->query("select amount from exposure where uid =".$userid);
			$getexposureRow = $getexposureRes->fetch_array(MYSQLI_BOTH); 
			if(abs($getexposureRow["amount"]) > $getviewBalanceRow["balance"]){
				$mysqli->query("delete from sessions_res where id =".$id);
				$mysqli->query("delete from session_matrix where parent_id =".$id);
				 
				$msg = array("responseData" => array("status" => "0", "error" => "Bet Rejected Try Within Your Limits"));
			}else{
				$result 	= $mysqli->query("select rate,run,y_n,amount from sessions_res where sess_id=". $sess_id." and uid=".$userid);
				$runs = [];
				while($row 		= $result->fetch_array(MYSQLI_BOTH)){
					array_push($runs,$row["run"]);
					$rows[] = $row;
				}
				/* 
					Implemented new view instead of table to revoke the data upto 14 lines
					old table - session_matrix
					new view - matrix_view (Created by Ashwani sir (23/05/2016))
							
				*/
				$result2 	= $mysqli->query("select runs,sum(amount) as amount from matrix_view where sid=". $sess_id." and uid=".$userid." group by runs");
				while($row2 		= $result2->fetch_array(MYSQLI_BOTH)){
					$rows2[] = $row2; 
				}
				if($runs){
					$minval = min($runs);
				}else{
					$minval = "0";
				}
				$successMez = "Submited Successfully";
				$msg 	 	= array("responseData" => array("status" => "1", "result" => $rows,'result2' => $rows2,'msg' => $successMez,'minval' => $minval));
				}
		}else{
				$msg = array("responseData" => array("status" => "0", "error" => "No Rates Please Wait for another rateee"));
			}
		return $msg;	
	}
	/** 
		End 600 entreies insert logic converted to 5 enteries
	*/
	
	
	
	/*function saveRate($userid,$sess_id,$y_n,$rt,$run,$rate,$rt2){
		global $mysqli;
		$obj = new fairsession; 
		$results = $mysqli->query("insert into sessions_res set uid = '".$userid."',sess_id = '".$sess_id."',y_n = '".$y_n."',amount = '".$rt."',run = '".$run."',rate = '".$rate."'");
		if($results){
			$id = $mysqli->insert_id;
			if($y_n == 1){
				$amount = '+'.$rt2;
			}else{
				$amount = '-'.$rt;
			}
			$getAdminRes = $mysqli->query("select parent_id from users where id =".$userid);
			$getAdminRow = $getAdminRes->fetch_array(MYSQLI_BOTH);
			$adId        = $getAdminRow["parent_id"];	
			/*** 
				Code to insert 
			**/
			/*$mysqli->query("insert into session_matrix set sid = '".$sess_id."',uid = '".$userid."',runs = '".$run."',amount = '".$amount."',parent_id = ".$id.",admin_id = ".$adId.",type = 'O'");
			$lid = $mysqli->insert_id;
			$selectPidRes = $mysqli->query("select parent_id from session_matrix where id=".$lid);
			$selectPidRow = $selectPidRes->fetch_array(MYSQLI_ASSOC);
			$parentId = $selectPidRow["parent_id"];
			$selectRes = $mysqli->query("SELECT min(runs) as min_run, max(runs) as max_run FROM session_matrix where sid=". $sess_id." and uid=".$userid."");
			if($selectRes->num_rows > 0){
				$getminmaxRow = $selectRes->fetch_array(MYSQLI_ASSOC); 
				if($getminmaxRow["min_run"] == $getminmaxRow["max_run"]){
					$sessMatrix = [];
					$sessMatrix2 = [];
					$entryVar = 2;  
					for($i =$getminmaxRow["min_run"]-2;$i<$getminmaxRow["max_run"];$i++){
						array_push($sessMatrix,$i);
					}
					for($j = $getminmaxRow["max_run"]+1;$j<$getminmaxRow["max_run"]+1+$entryVar;$j++){
						array_push($sessMatrix2,$j);
					}
					$sessMatrix = array_merge($sessMatrix,$sessMatrix2);
					if($y_n == 1){
						$type1 = [];
						$type2 = [];
						$amount1 = [];
						$amount2 = [];
						for($i =$getminmaxRow["min_run"]-2;$i<$getminmaxRow["max_run"];$i++){
							array_push($amount1,'-'.$rt2);
							array_push($type1,'N');
						}
						for($j = $getminmaxRow["max_run"];$j<$getminmaxRow["max_run"]+$entryVar;$j++){
							array_push($amount2,'+'.$rt);
							array_push($type2,'P');
						}
						}else{
							$amount1 = [];
							$amount2 = [];
							$type1 = [];
							$type2 = [];
							for($i =$getminmaxRow["min_run"]-2;$i<$getminmaxRow["max_run"];$i++){
								array_push($amount1,'+'.$rt2);
								array_push($type1,'P');
							}
							for($j = $getminmaxRow["min_run"];$j<$getminmaxRow["max_run"]+$entryVar;$j++){
								array_push($amount2,'-'.$rt);
								array_push($type2,'N');
							}
						}
						$sessAmount = array_merge($amount1,$amount2);
						$type = array_merge($type1,$type2);
						
						$i = 0;
						foreach($sessMatrix  as $sm){
							$mysqli->query("insert into session_matrix set sid = '".$sess_id."',uid = '".$userid."',runs = '".$sm."',amount = '".$sessAmount[$i]."',parent_id = ".$id.",admin_id = ".$adId.",type = '".$type[$i]."'");
							$i++;
						}
				}else{
					$sessMatrix = [];
					$sessMatrix2 = [];
					$entryVar = 2;  
					for($i =$run-2;$i<$run;$i++){
						array_push($sessMatrix,$i);
					}
					for($j = $run+1;$j<$run+1+$entryVar;$j++){
						array_push($sessMatrix2,$j);
					}
					$sessMatrix = array_merge($sessMatrix,$sessMatrix2);
					if($y_n == 1){
						$type1 = [];
						$type2 = [];
						$amount1 = [];
						$amount2 = [];
						for($i =$run-2;$i<$run;$i++){
							array_push($amount1,'-'.$rt2);
							array_push($type1,'N');
						}
						for($j = $run;$j<$run+$entryVar;$j++){
							array_push($amount2,'+'.$rt);
							array_push($type2,'P');
						}
					}else{
							$amount1 = [];
							$amount2 = [];
							$type1 = [];
							$type2 = [];
							for($i =$run-2;$i<$run;$i++){
								array_push($amount1,'+'.$rt2);
								array_push($type1,'P');
							}
							for($j = $run;$j<$run+$entryVar;$j++){
								array_push($amount2,'-'.$rt);
								array_push($type2,'N');
							}
						}
						$sessAmount = array_merge($amount1,$amount2);
						$type = array_merge($type1,$type2);
						
						$i = 0;
						foreach($sessMatrix  as $sm){
							$mysqli->query("insert into session_matrix set sid = '".$sess_id."',uid = '".$userid."',runs = '".$sm."',amount = '".$sessAmount[$i]."',parent_id = ".$id.",admin_id = ".$adId.",type = '".$type[$i]."'");
							$i++;
							$ltd = $mysqli->insert_id;
						}
						$selectCurrentORes = $mysqli->query("select amount,max(runs) as max_run,min(runs) as min_run from session_matrix where parent_id=".$parentId);
						$selectCurrentORow = $selectCurrentORes->fetch_array(MYSQLI_ASSOC);
						$Curmax  = $selectCurrentORow["max_run"];
						$Curmin  = $selectCurrentORow["min_run"];
						$Camount = $selectCurrentORow["amount"];
						$selectpRes = $mysqli->query("SELECT parent_id FROM session_matrix where sid=".$sess_id." and uid=".$userid." and type = 'O' and parent_id !=".$parentId." order by id");
						if($selectpRes->num_rows > 0){
							$d = 0;
							while($selectpRow = $selectpRes->fetch_array(MYSQLI_ASSOC)){
								
								$selectMRes = $mysqli->query("SELECT parent_id,amount,max(runs) as max_run,min(runs) as min_run FROM session_matrix where parent_id=".$selectpRow['parent_id']."");
								$selectMRow =  $selectMRes->fetch_array(MYSQLI_ASSOC); 
								if($Curmax == $selectMRow["max_run"]){
									
								}else if($Curmax > $selectMRow["max_run"]){
									
									$d++;
									$rws = $Curmax-$selectMRow["max_run"];
									for($i = 1;$i<=$rws;$i++){
										$sm = $selectMRow["max_run"]+$i;
										$mysqli->query("insert into session_matrix set sid = '".$sess_id."',uid = '".$userid."',runs = '".$sm."',amount = '".$selectMRow["amount"]."',parent_id = ".$selectMRow["parent_id"].",admin_id = ".$adId.",type = 'P'");
										
									}
									$selectcparentMRes = $mysqli->query("SELECT parent_id FROM session_matrix where id=".$ltd);
									$selectcparentMRow =  $selectcparentMRes->fetch_array(MYSQLI_ASSOC);
									$pid = $selectcparentMRow["parent_id"];
								     
									if($d == 1){
										$rws = $Curmin-$selectMRow["min_run"];
										for($i = 1;$i<=$rws;$i++){
											$sm = $Curmin-$i;
											$Camount = $obj->getAmt($selectMRow["min_run"],$sess_id,$userid);
											$mysqli->query("insert into session_matrix set sid = '".$sess_id."',uid = '".$userid."',runs = '".$sm."',amount = '".$Camount."',parent_id = ".$parentId.",admin_id = ".$adId.",type = 'N'");
										} 
									}
									
								}else{
									
									$d++;
									$rws = $selectMRow["max_run"]-$Curmax;
									if($d == 1){
										for($i = 1;$i<=$rws;$i++){
											$sm = $Curmax+$i;
											$mysqli->query("insert into session_matrix set sid = '".$sess_id."',uid = '".$userid."',runs = '".$sm."',amount = '".$Camount."',parent_id = ".$parentId.",admin_id = ".$adId.",type = 'P'");
										}
									}
									$rws = $selectMRow["min_run"]-$Curmin;
									for($i = 1;$i<=$rws;$i++){
										$sm =$selectMRow["min_run"]-$i;
										$mysqli->query("insert into session_matrix set sid = '".$sess_id."',uid = '".$userid."',runs = '".$sm."',amount = '".$selectMRow["amount"]."',parent_id = ".$selectMRow["parent_id"].",admin_id = ".$adId.",type = 'N'");
									} 
								}
							if($Curmax < $selectMRow["max_run"] && $Curmin > $selectMRow["min_run"]){
									$d++;
									if($d == 1){
										$rws = $selectMRow["max_run"]-$Curmax;
										for($i = 1;$i<=$rws;$i++){
											$sm = $Curmax+$i;
											$mysqli->query("insert into session_matrix set sid = '".$sess_id."',uid = '".$userid."',runs = '".$sm."',amount = '".$Camount."',parent_id = ".$parentId.",admin_id = ".$adId.",type = 'P'");
										}
										$rws = $selectMRow["min_run"]-$Curmin;
										for($i = 1;$i<=$rws;$i++){
											$sm =$selectMRow["min_run"]-$i;
											$mysqli->query("insert into session_matrix set sid = '".$sess_id."',uid = '".$userid."',runs = '".$sm."',amount = '".$selectMRow["amount"]."',parent_id = ".$selectMRow["parent_id"].",admin_id = ".$adId.",type = 'N'");
										} 
									}
									
								} 
							}
						}
				}
			}
			
			$getviewBalanceRes = $mysqli->query("select balance from ledbalance where uid =".$userid);
			$getviewBalanceRow = $getviewBalanceRes->fetch_array(MYSQLI_BOTH);
			/* exposure rate*/
			/*$getexposureRes = $mysqli->query("select amount from exposure where uid =".$userid);
			$getexposureRow = $getexposureRes->fetch_array(MYSQLI_BOTH); 
			if(abs($getexposureRow["amount"]) > $getviewBalanceRow["balance"]){
				$mysqli->query("delete from sessions_res where id =".$id);
				$mysqli->query("delete from session_matrix where parent_id =".$id);
				 
				$msg = array("responseData" => array("status" => "0", "error" => "Bet Rejected Try Within Your Limits"));
			}else{
				$result 	= $mysqli->query("select rate,run,y_n,amount from sessions_res where sess_id=". $sess_id." and uid=".$userid);
				$runs = [];
				while($row 		= $result->fetch_array(MYSQLI_BOTH)){
					array_push($runs,$row["run"]);
					$rows[] = $row;
				}
				/* 
					Implemented new view instead of table to revoke the data upto 14 lines
					old table - session_matrix
					new view - matrix_view (Created by Ashwani sir (23/05/2016))
							
				*/
				/*$result2 	= $mysqli->query("select runs,sum(amount) as amount from matrix_view where sid=". $sess_id." and uid=".$userid." group by runs");
				while($row2 		= $result2->fetch_array(MYSQLI_BOTH)){
					$rows2[] = $row2; 
				}
				if($runs){
					$minval = min($runs);
				}else{
					$minval = "0";
				}
				$successMez = "Submitted Successfully";
				$msg 	 	= array("responseData" => array("status" => "1", "result" => $rows,'result2' => $rows2,'msg' => $successMez,'minval' => $minval));
				}
		}else{
				$msg = array("responseData" => array("status" => "0", "error" => "No Rates Please Wait for another rateee"));
			}
		return $msg;	
	}*/
	function getAmt($run,$sess_id,$userid){
		global $mysqli;
		$selectCurrentORes = $mysqli->query("select amount from session_matrix where runs=".$run." and sid = ".$sess_id." and uid = ".$userid."");
		$selectCurrentORow = $selectCurrentORes->fetch_array(MYSQLI_ASSOC);
		$amount  = $selectCurrentORow["amount"];
		return $amount;
	}
	function getallSess(){
		global $mysqli;
		$results = $mysqli->query("select id,sess_rate from sessions where isActive= '0'");
		if($results->num_rows > 0){
			while($row 		= $results->fetch_array(MYSQLI_BOTH)){
				$data[]  	    = $row;
			}
			$msg = array("responseData" => array("status" => "1", "result" => $data));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Rates Please Wait for another rate"));
		}
		return $msg;
	}
	function getallSessmett($userid,$sess_id){
		global $mysqli;
		$getuidRes = $mysqli->query("select id from users where userid =".$userid);
		$getuidRow = $getuidRes->fetch_array(MYSQLI_BOTH);
		$userid    = $getuidRow["id"];
		$result 	= $mysqli->query("select rate,run,y_n,amount from sessions_res where uid=".$userid." and sess_id =".$sess_id);
		if($result){
			$runs = [];
			while($row 		= $result->fetch_array(MYSQLI_BOTH)){
				$rows[] = $row;
				array_push($runs,$row["run"]);
			}
			$result2 	= $mysqli->query("select runs,sum(amount) as amount from session_matrix where uid=".$userid." and  sid = ".$sess_id." group by runs");
		
			while($row2 		= $result2->fetch_array(MYSQLI_BOTH)){
				$rows2[] = $row2; 
			}
			if($runs){
				$minval = min($runs);
			}else{
				$minval = "0";
			}
			$msg 	 	= array("responseData" => array("status" => "1", "result" => $rows,'result2' => $rows2,'minval' => $minval));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Session Live currently please try later"));
		}
		return $msg;
	}
	public function setDeclare($sess_id,$amt){
		global $mysqli;
                $mysqli->query("delete from session_matrix where parent_id in (select parent_id from sessions_res where run=0) and sid =".$sess_id);
                $mysqli->query("delete from sessions_res where run=0 and sess_id =".$sess_id); 		
                $mysqli->query("CREATE TABLE ".$sess_id."_res AS SELECT * FROM sessions_res WHERE sess_id =".$sess_id);
		$mysqli->query("CREATE TABLE ".$sess_id."_matrix AS SELECT * FROM session_matrix WHERE sid =".$sess_id);
		$mysqli->query("delete from sessions_res WHERE sess_id =".$sess_id);
		$mysqli->query("delete from session_matrix WHERE sid =".$sess_id);
		$mysqli->query("update sessions set runs = '".$amt."' WHERE id =".$sess_id);
		
		/*echo "insert into dec_ledger select '',uid,sid,runs,'',sum(amount),'','' from ".$sess_id."_matrix where runs = '".$amt."' group by uid,runs";
		die;	*/
		$insertQry = $mysqli->query("insert into dec_ledger select '',uid,sid,runs,'',sum(amount),'','' from ".$sess_id."_matrix where runs = '".$amt."' group by uid,runs");	
		$mysqli->query("UPDATE dec_ledger a SET parent = ( SELECT parent_id FROM users WHERE id = a.uid )");


$insertQry = $mysqli->query("insert into vol_ledger select '',uid,sess_id,'',sum(amount),'','','' from ".$sess_id."_res group by uid");

$mysqli->query("UPDATE vol_ledger a SET parent = ( SELECT parent_id FROM users WHERE id = a.uid )");
		
		$mysqli->query("insert into dec_ledger_entry select '',sess_id,uid,'Loss','1','D',amount,'' from dec_ledger where sess_id = ".$sess_id." and amount < 0");
		
		/*$mysqli->query("insert into dec_ledger_entry select '',sess_id,parent,'Loss','1','D',amount,'' from dec_ledger where sess_id = ".$sess_id." and amount < 0");

		$mysqli->query("insert into dec_ledger_entry select '',sess_id,'1','Profit',a.uid,'C',amount,'' from dec_ledger a where sess_id = ".$sess_id." and amount < 0");*/
		
		$mysqli->query("insert into dec_ledger_entry select '',sess_id,uid,'Profit','1','C',amount,'' from dec_ledger where sess_id = ".$sess_id." and amount > 0");
		
		/*$mysqli->query("insert into dec_ledger_entry select '',sess_id,parent,'Profit','1','C',amount,'' from dec_ledger where sess_id = ".$sess_id." and amount > 0");

		$mysqli->query("insert into dec_ledger_entry select '',sess_id,'1','Loss',a.uid,'D',amount,'' from dec_ledger a where sess_id = ".$sess_id." and amount > 0");*/
		
		$mysqli->query("INSERT INTO dec_ledger_entry SELECT '', sess_id, uid, uid, 'Commission', 'D', abs(a.amount) * (SELECT commition FROM users WHERE id = a.uid AND commition !=0
		AND EXISTS (SELECT * FROM users WHERE id = a.uid) ) /100,'' FROM dec_ledger a, users b WHERE a.sess_id =".$sess_id." AND a.amount > 0 AND a.uid = b.id
		");

		/*$mysqli->query("INSERT INTO dec_ledger_entry SELECT '', sess_id, '1', 'Commission', uid, 'C',abs(a.amount) * (SELECT commition FROM users WHERE id = a.uid and commition !=0
		AND EXISTS (SELECT * FROM users WHERE id = a.uid) ) /100,'' FROM dec_ledger a, users b WHERE a.sess_id =".$sess_id." AND a.amount > 0 AND a.uid = b.id
		");*/
		
		/*$mysqli->query("INSERT INTO dec_ledger_entry SELECT '', sess_id, '1', a.uid, 'Commission', 'C', a.amount * (SELECT commition FROM users WHERE id = a.parent
		AND EXISTS (SELECT * FROM users WHERE id = a.uid) ) /100,'' FROM dec_ledger a, users b WHERE a.sess_id =".$sess_id." AND a.amount >0 AND a.parent = b.id
		");*/
	
		 
		$result = $mysqli->query("select * from dec_ledger_entry where sess_id =".$sess_id." and amount !='0'");
		if($result){
			while($row    = $result->fetch_array(MYSQLI_BOTH)){
				$amount = abs($row["amount"]);
				$date = date("Y-m-d");
				$a = [];
				$getNameRes = $mysqli->query("select name from users where id =".$row['account_head']);
				if($getNameRes){
					$getNameRow = $getNameRes->fetch_array(MYSQLI_BOTH);
					$ac = $getNameRow['name'];
					array_push($a,$ac);
				}else{
					$getHeadNameRes = $mysqli->query("select name from heads where name ='".$row['account_head']."'");
					if($getHeadNameRes){
						$getHeadNameRow = $getHeadNameRes->fetch_array(MYSQLI_BOTH);
						$ac = $getHeadNameRow['name'];
						array_push($a,$ac);
					}
				}
				$mysqli->query("insert into ledger set uid = '".$row['uid']."',match_id = '',date = '".$date."',`desc` = '".$row['sess_id']."',acount_head = '".$ac."',account_head2 = '".$row['account_head2']."',debit_credit = '".$row['debit_credit']."',amount = '".$amount."'");
			}
			
			$mysqli->query("update sessions set action = '4' WHERE id =".$sess_id);
		} 
		return true;
	}
	public function setUndeclare($sess_id){
		global $mysqli;
		$mysqli->query("delete from ledger WHERE `desc` =".$sess_id);
		$mysqli->query("update sessions set runs = '' WHERE id =".$sess_id);
		$mysqli->query("insert into session_matrix SELECT * FROM ".$sess_id."_matrix");
		$mysqli->query("DROP TABLE ".$sess_id."_matrix");
		$mysqli->query("insert into sessions_res SELECT * FROM ".$sess_id."_res");
		$mysqli->query("DROP TABLE ".$sess_id."_res");
		$mysqli->query("delete from dec_ledger WHERE sess_id =".$sess_id);
		$mysqli->query("delete from dec_ledger_entry WHERE sess_id =".$sess_id);
		$mysqli->query("update sessions set action = '2' WHERE id =".$sess_id);
		return true;
	}
	
	public function getLreports($user_id){
		global $mysqli;
		$useridQry 		= $mysqli->query("select id from users where userid=".$user_id);
		$useridRow 		= $useridQry->fetch_array(MYSQLI_BOTH);
		$user_id        = $useridRow["id"];
		$reportsRes = $mysqli->query('select * from ledger where uid = "'.$user_id.'" order by id desc');
		if($reportsRes->num_rows > 0){
			while($reportsRow = $reportsRes->fetch_array(MYSQLI_BOTH)){
				$sessDescRes = $mysqli->query("select over from sessions where id=".$reportsRow["desc"]);
				if($sessDescRes){
					$sessDescRow = $sessDescRes->fetch_array(MYSQLI_BOTH);
					$reportsRow["desc"] = $sessDescRow["over"];
				}
				$rows[] = 	$reportsRow;
			}
			$ledbalanceRes = $mysqli->query('select * from ledbalance where uid = "'.$user_id.'"');
			if($ledbalanceRes){ 
				$ledbalanceRow     = $ledbalanceRes->fetch_array(MYSQLI_BOTH);
				if($ledbalanceRow["balance"] > 0){
					$ledgersview = $ledbalanceRow["balance"].' '.'Credit';
				}else{
					$ledgersview = abs($ledbalanceRow["balance"]).' '.'Debit';
				}
			}else{
				$ledgersview = "";
			}
			
			$msg = array("responseData" => array("status" => "1", "ledgers" => $rows,'balance' => $ledgersview));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Records"));
		}
		
		return $msg;
	}
	
	public function getLSessreports($user_id){
		global $mysqli;
		$useridQry 		= $mysqli->query("select id from users where userid=".$user_id);
		$useridRow 		= $useridQry->fetch_array(MYSQLI_BOTH);
		$user_id        = $useridRow["id"];
		
		$reportsRes = $mysqli->query('select distinct sess_id,amount,date from dec_ledger where uid = "'.$user_id.'" order by id desc');
		if($reportsRes->num_rows > 0){
			while($reportsRow = $reportsRes->fetch_array(MYSQLI_BOTH)){
				$sessDescRes = $mysqli->query("select over,runs from sessions where id=".$reportsRow["sess_id"]);
				$sessDescRow = $sessDescRes->fetch_array(MYSQLI_BOTH);
				$reportsRow["desc"] = $sessDescRow["over"];
				$rows[] = 	$reportsRow;
			}
			$msg = array("responseData" => array("status" => "1", "ledgersSess" => $rows));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Records"));
		}
		
		return $msg;
	}
	
	public function getLSessres($sess_id,$user_id){
		global $mysqli;
		$useridQry 		= $mysqli->query("select id from users where userid=".$user_id);
		$useridRow 		= $useridQry->fetch_array(MYSQLI_BOTH);
		$user_id        = $useridRow["id"];
		$sessDescRes = $mysqli->query("select over,runs from sessions where id=".$sess_id);
		$sessDescRow = $sessDescRes->fetch_array(MYSQLI_BOTH);
		$sessDesc    = $sessDescRow["over"];
		$dcRuns    	 = $sessDescRow["runs"];
		/* echo "select run,amount,y_n,rate from ".$sess_id."_res where uid = '".$user_id."' order by id desc";
		die; */
		$sessRes     = $mysqli->query("select run,amount,y_n,rate from ".$sess_id."_res where uid = '".$user_id."' order by id desc");
		if($sessRes->num_rows > 0){
			$amountSum = "";
			$rows = [];
			$i = 0;
			while($session = $sessRes->fetch_array(MYSQLI_BOTH)){
				$points = $session["amount"]/$session["rate"]*100;
				if($session["y_n"] == "1"){
					$yn = "Y";
				}else{
					$yn = "N";
				}
				
				if($session["run"] < $dcRuns && $session["y_n"] == "1"){
					$y_n = "Lost";
					$amt = $session["amount"];
					$amountSum = $amountSum+$amt;
				}else if($session["run"] > $dcRuns && $session["y_n"] == "1"){
					$y_n = "Won";
					$amt = 0-$session["amount"];
					if($amt < 0 &&  $session["rate"] != "100"){
						$amt = 0-$session["amount"]/$session["rate"]*100;
					}
					$amountSum = $amountSum+$amt;
				}else if($session["run"] > $dcRuns && $session["y_n"] == "0"){
					$y_n = "Lost";
					$amt = $session["amount"];
					if($session["rate"] != "100"){
						$amt = $session["amount"]/$session["rate"]*100;
					}
					$amountSum = $amountSum+$amt;
				}else if($session["run"] < $dcRuns && $session["y_n"] == "0"){
					$y_n = "Won";
					$amt = 0-$session["amount"];
					$amountSum = $amountSum+$amt;
				}else if($session["run"] == $dcRuns && $session["y_n"] == "0"){
					$y_n = "Won";
					$amt = 0-$session["amount"];
					$amountSum = $amountSum+$amt;
				}else if($session["run"] == $dcRuns && $session["y_n"] == "1"){
					$y_n = "Won";
					$amt = $session["amount"];
					$amountSum = $amountSum+$amt;
				}
				
				
				
				
				/* if($session["run"] < $dcRuns && $session["y_n"] == "1"){
					$y_n = "Lost";
					$amt = $session["amount"];
					
					$amountSum = $amountSum+$amt;
				}else if($session["run"] >= $dcRuns && $session["y_n"] == "1"){
					$y_n = "Won";
					$amt = 0-$session["amount"];
					$amountSum = $amountSum+$amt;
				}else if($session["run"] >= $dcRuns &&  $session["y_n"] == "0"){
					$y_n = "Lost";
					$amt = $session["amount"];
					
					$amountSum = $amountSum+$amt;
				}else if($session["run"] < $dcRuns &&  $session["y_n"] == "0"){
					$y_n = "Won";
					$amt = 0-$session["amount"];
					$amountSum = $amountSum+$amt;
				} */
				$rows[$i]["run"] 	= $session["run"];
				$rows[$i]["points"] = $points;
				$rows[$i]["rate"] 	= $session["rate"];
				$rows[$i]["yn"] 	= $yn;
				$rows[$i]["amount"] = $amt;
				$i++;
			}
			$msg = array("responseData" => array("status" => "1", "sessRess" => $rows,'total' => $amountSum,'sess_desc' => $sessDesc,'dc_runs' => $dcRuns));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Records"));
		}
		return $msg;
	}
	public function getDateres($user_id,$from_date,$to_date){
		global $mysqli;
		$useridQry 		= $mysqli->query("select id from users where userid=".$user_id);
		$useridRow 		= $useridQry->fetch_array(MYSQLI_BOTH);
		$user_id        = $useridRow["id"];
		$fDate      = date('Y-m-d',strtotime($from_date));
		$tDate      = date('Y-m-d',strtotime($to_date));
		$reportsRes = $mysqli->query('select distinct sess_id,amount,date from dec_ledger where uid = "'.$user_id.'" and `date` BETWEEN "'.$fDate.'" AND "'.$tDate.'"  order by id desc');
		if($reportsRes->num_rows > 0){
			while($reportsRow = $reportsRes->fetch_array(MYSQLI_BOTH)){
				$sessDescRes = $mysqli->query("select over,runs from sessions where id=".$reportsRow["sess_id"]);
				if($sessDescRes){
					$sessDescRow = $sessDescRes->fetch_array(MYSQLI_BOTH);
					$reportsRow["desc"] = $sessDescRow["over"];
				}	
				$rows[] = 	$reportsRow;
			}
			if(!$rows){
				$rows = "0";
			}
			$msg = array("responseData" => array("status" => "1", "ledgersSess" => $rows));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Records"));
		}
		
		return $msg;
	}
	
	public function getRunSessres(){
		global $mysqli;
		$sessDescRes = $mysqli->query("select id,over from sessions where action ='2' or action ='3' order by id desc" );
		if($sessDescRes->num_rows > 0){
			while($sessDescRow = $sessDescRes->fetch_array(MYSQLI_BOTH)){
				$row[] = $sessDescRow;
			}
			$msg = array("responseData" => array("status" => "1", "data" => $row));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Records"));
		}
		return $msg;
	}
	
	function getUniqSess($userid,$sess_id){
		global $mysqli;
		$useridQry 		= $mysqli->query("select id from users where userid=".$userid);
		$useridRow 		= $useridQry->fetch_array(MYSQLI_BOTH);
		$balanceRes     = $mysqli->query("select balance from ledbalance where uid=".$useridRow["id"]);
		$balanceRow     = $balanceRes->fetch_array(MYSQLI_BOTH);
		if($balanceRow->balance != " " ){
			$balance        = $balanceRow["balance"];
		}else{
			$balance = "0";
		}
		$results = $mysqli->query("select * from sessions where id =".$sess_id);
		if($results->num_rows > 0){
			$row 		= $results->fetch_array(MYSQLI_BOTH);
			$Srate 		= $row["sess_rate"];
			$sess_id 	= $row["id"];
			$runs 		= $row["runs"];
			$rate 		= $row["rate"];
			if($rate != '0:0'){
				$rate2 = explode(":",$rate);
				$rate2 = $runs.':'.$rate2[1].','.$runs.':'.$rate2[0];
				$Srate = "empty";
			}else{
				$rate2 = "empty";
			}
			$over 		= $row["over"];
			$runss       = [];
			
			$result 	= $mysqli->query("select rate,run,y_n,amount from sessions_res where sess_id=". $sess_id." and uid=".$useridRow["id"]);
			while($row 		= $result->fetch_array(MYSQLI_BOTH)){
				$rows[] = $row;
				array_push($runss,$row["run"]);
			}
			$result2 	= $mysqli->query("select runs,sum(amount) as amount from matrix_view where sid=". $sess_id." and uid=".$useridRow["id"]." group by runs");
			while($row2 		= $result2->fetch_array(MYSQLI_BOTH)){
				$rows2[] = $row2; 
			}
			if(empty($rows)){
				$rows = [];
			}
			if(empty($rows2)){
				$rows2 = [];
			}
			if($runss){
				$minval = min($runss);
			}else{
				$minval = "0";
			}

			$msg = array("responseData" => array("status" => "1", "result" => $Srate,'sess_id' => $sess_id,'desc' => $over,'rate2' => $rate2,'balance' => $balance,'rs1' => $rows,'rs2' => $rows2,'minval' => $minval));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Rates Please Wait for another rate",'balance' => $balance));
		}
		return $msg;
	}
	
	function getAllMt(){
		global $mysqli;
		$url  = "http://www.sportingindex.com/spread-betting/cricket";
		$html = file_get_html($url);
		$res = "";
		$resA = "";
		$i = 0;
		$mysqli->query("TRUNCATE TABLE auto_matches");
		foreach($html->find('#all .meetingTable') as $e){
			$i++;
			$resA .= $e;
			$dom 	= new DOMDocument;
			$dom->loadHTML($html->find('.meetingTable')[$i]);
			foreach ($dom->getElementsByTagName('a') as $node) {
				$href 	  = $node->getAttribute( 'href' );
				$meetings = explode("/",$href);
				if($href != ""){
					if($node->nodeValue != "" && $href != "" && $meetings[4] != ""){
						$mysqli->query("insert into auto_matches set a_val = '".$node->nodeValue."',a_href = '".$href."',s_time = '".$time."',meeting = '".$meetings[4]."'");
					}
				} 
			}
			
		}
		$selectRes =  $mysqli->query("select * from auto_matches where a_val != ''");
		$res .= '<div class="at_rates_div"><table class="sess_auto_mtch sess_slide_rs"><tr><th>#</th><th>Match</th></tr>';
		$i = 0;
		while($row = $selectRes->fetch_array(MYSQLI_BOTH)){
			$tm = explode(":",$row["a_val"]);
			$i++;
			$function = "getRt('".$row["meeting"]."','".$tm[1]."')";
			$link = '<a href="#" onclick="'.$function.'">'.$row["a_val"].'</a>';
			$res .= '<tr><td>'.$i.'</td><td>'.$link.'</td></tr>';
		}
		$res .= '</table></div>
		<p class="mg10">
<button class="btn btn-default btn-close rn_sess_btnC" onclick="cls_popup()">Close</button>
<button class="active_bg_close btn btn-default rn_sess_btn">Close</button>
</p>';
		$result = array("res" => $res);
		return $result;
	}
	
	
	function getAllRt($url,$tm,$elm){
		global $mysqli;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);  
		$data = curl_exec($ch);
		curl_close($ch);
		$data = json_decode($data);
		$obj = new fairsession;
		$data = $data->Markets;
		/* echo "<pre>";print_r($data);
		die; */
		$a = 0;
		$html = '<div class="at_rates_div"><table class="sess_auto_mtch sess_slide_rs"><tr><th>#</th><th>Current</th><th>Sell</th><th>Buy</th></tr>';
		for($i = 0;$i < count($data);$i++){
			$a++;
			$current = $data[$i]->SoFar;
			if($current == ""){
				$current = "-";
			}
			$function = "saveAutorate('".$data[$i]->Buy."','".$data[$i]->Sell."','".$current."','".$data[$i]->Key."','".$elm."')";
			$html .='<tr><td>'.$a.'</td><td>'.$current.'</td><td >'.$data[$i]->Sell.'</td><td style="cursor:pointer;" onclick="'.$function.'">'.$data[$i]->Buy.'</td></tr>'; 
		}
		$html .= '</table></div>';
		return $html;
	}
	
	function getAllautoRt($url,$tm){
		global $mysqli;
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);  
		$data = curl_exec($ch);
		curl_close($ch);
		$data = json_decode($data);
		$obj = new fairsession;
		$data = $data->Markets; 
		$a = 0;
		$html = '<div class="at_rates_div"><table class="sess_auto_mtch sess_slide_rs"><tr><th>#</th><th>Current</th><th>Sell</th><th>Buy</th></tr>';
		for($i = 0;$i < count($data);$i++){
			$a++;
			$current = $data[$i]->SoFar;
			if($current == ""){
				$current = "-";
			}
			if($data[$i]->Key == $tm){ 
				$crt = $data[$i]->SoFar;
				$sell = $data[$i]->Sell;
				$buy  = $data[$i]->Buy;
				$ct 	= explode("/",$data[$i]->SoFar);
				if(count($ct) > 1){
					$ct = $ct[0];
				}else{
					$ct = $data[$i]->SoFar;
				}
				if($ct == "-"){
					$ct = "0";
				}
				$ky = $data[$i]->Key;
			}
			$function = "saveAutorate('".$data[$i]->Buy."','".$data[$i]->Sell."','".$current."','".$data[$i]->Key."')";
			$html .='<tr><td>'.$a.'</td><td>'.$current.'</td><td >'.$data[$i]->Sell.'</td><td style="cursor:pointer;" onclick="'.$function.'">'.$data[$i]->Buy.'</td></tr>'; 
		}
		
		$mysqli->query("update auto_session_values set current = '".$ct."',sell_rate = '".$sell."',buy_rate = '".$buy."',score = '".$crt."',mkt_id = '".$ky."' where mkt_id = '".$tm."'");
		
		$html .= '</table></div>';
		return $html;
	}
	
	function svArates($buy,$sell,$current,$sess_id,$ky,$elm){
		global $mysqli;
		$mysqli->query("delete from auto_session_values where sid = '".$sess_id."'");
		$crnt = $current;
		$current = explode("/",$current);
		if(count($current) > 1){
			$current = intval($current[0]);
		}else{
			$current = intval($current[0]);
		}
		if(is_numeric($current)){
			$mysqli->query("insert into auto_session_values set sid = '".$sess_id."',current = '".$current."',sell_rate = '".$sell."',buy_rate = '".$buy."',score = '".$crnt."',mkt_id = '".$ky."',main_mkt = '".$elm."'");
			$msg = 1;
		}else{
			$msg = 0;
		}
		
		return  $msg;
	}
	
	function getSessDiff(){
		global $mysqli;
		$selectRes =  $mysqli->query("select * from diff_par order by id asc");
		$res .= '<div class="at_rates_div"><table class="sess_auto_mtch sess_slide_rs"><tr><th>#</th><th>Start</th><th>End</th><th>Run</th></tr>';
		$i = 0;
		while($row = $selectRes->fetch_array(MYSQLI_BOTH)){
			$i++;
			$res .= '<tr><td>'.$i.'</td><td><input type="text" id="start_'.$i.'" value="'.$row["start"].'" /></td><td><input type="text" id="end_'.$i.'" value="'.$row["end"].'" /></td><td><input type="text" id="rn_'.$i.'" value="'.$row["run_value"].'" /></td></tr>';
		}
		$res .= '</table><p class="mg10">
<button class="btn btn-default btn-close rn_sess_btnC" onclick="cls_popup()">Cancel</button>
<button class="btn btn-default sv_rt_btn slide_open" onclick="saveSessDiff()">Save</button>
</p></div>
		';
		$result = array("res" => $res);
		return $result;
	}
	function saveSessDt($sid,$end,$start,$run){
		global $mysqli;
		$mysqli->query("delete from session_diff where sid= '".$sid."'");
		for($i = 0;$i < count($start); $i++){
			$mysqli->query("insert into session_diff set sid = '".$sid."',start = '".$start[$i]."',end = '".$end[$i]."',run_value = '".$run[$i]."'");
		}
		$msg = 1;
		return  $msg;
	}
	function setSessrate($sid){
		$sess_id = file_get_contents("sessid.txt", true);
		if($sess_id != ""){
			$sess_id = explode(",",$sess_id);
			if(in_array($sid,$sess_id)){
				
			}else{
				$myfile = fopen("sessid.txt", "w") or die("Unable to open file!");
				fwrite($myfile, "");
				if($sess_id[0] == "0"){
					$sid = $sess_id[1].",".$sid;
				}else{
					$sid = $sess_id[1].",".$sid;
				}
				fwrite($myfile, $sid);
				$sess_id = file_get_contents("sessid.txt", true);
				fclose($myfile);
			}
		}else{ 
				$myfile = fopen("sessid.txt", "w") or die("Unable to open file!");
				$sid = "0".",".$sid;
				fwrite($myfile, $sid);
				fclose($myfile);
			} 
		
		
	} 
	
	function susspendSess($sid){
		global $mysqli;
		$res = $mysqli->query("update sessions set isActive = '1' where id =".$sid);
		$myfile = fopen("sessid.txt", "w") or die("Unable to open file!");
		fwrite($myfile, "");
		fclose($myfile);
	}
	
	public function getallrunMatches(){
		global $mysqli;
		$sessDescRes = $mysqli->query("select id,match_name,team1,team2 from matches where action ='2' or action ='3' order by id desc" );
		if($sessDescRes->num_rows > 0){
			while($sessDescRow = $sessDescRes->fetch_array(MYSQLI_ASSOC)){
				$row[] = $sessDescRow;
			}
			$msg = array("responseData" => array("status" => "1", "data" => $row));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Records"));
		}
		return $msg;
	}
	public function getselectedrunMatches($match_id,$userid){
		global $mysqli;
		$useridQry 		= $mysqli->query("select id from users where userid=".$userid);
		$useridRow 		= $useridQry->fetch_array(MYSQLI_BOTH);
		$balanceRes     = $mysqli->query("select balance from ledbalance where uid=".$useridRow["id"]);
		$balanceRow     = $balanceRes->fetch_array(MYSQLI_BOTH);
		if($balanceRow["balance"] != "" ){
			$balance        = $balanceRow["balance"];
		}else{
			$balance = "0";
		}
		$getexposureRes = $mysqli->query("select amount from jointexposure where uid =".$useridRow["id"]);
		$getexposureRow = $getexposureRes->fetch_array(MYSQLI_BOTH);
		if($getexposureRes->num_rows > 0){
			$exposure        = abs($getexposureRow["amount"]);
		}else{
			$exposure = "0";
		}
		$mathceres = $mysqli->query("select * from matches where id =".$match_id );
		if($mathceres->num_rows > 0){
			$mathcerow = $mathceres->fetch_array(MYSQLI_ASSOC);
			$matcchsuperbookres = $mysqli->query("select * from userbook where uid=".$useridRow["id"]." and match_id = ".$match_id);
			if($matcchsuperbookres->num_rows > 0){
				$matcchsuperbookrow = $matcchsuperbookres->fetch_array(MYSQLI_ASSOC);
			}
			
			$team1 = is_null($matcchsuperbookrow["team1sum"]) ? 1 : 0;
			$team2 = is_null($matcchsuperbookrow["team2sum"]) ? 1 : 0;

			if($team1 == 1){
				$matcchsuperbookrow["team1sum"] = "0";
			}
			if($team2 == 1){
				$matcchsuperbookrow["team2sum"] = "0";
			}
			$msg = array("responseData" => array("status" => "1", "data" => $mathcerow,'bookdata' => $matcchsuperbookrow,'balance' => $balance,'exposure' => $exposure));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Records"));
		}
		return $msg;
	}
	function savematchBet($userid,$match_id,$b_l,$amount,$run,$team,$stm){
			global $mysqli;
			$rt = $amount*100/100;
			$rt2 = $amount*100/100;
			/* if($rate[1] == "100"){
				$rt2 = $amount*$rate[1]/100;
			}else{
				$rt2 = $amount*100/100;
			} */
			$getBetsRes = $mysqli->query("select min_bet,max_bet from users where userid=".$userid);
			$getBetsRow = $getBetsRes->fetch_array(MYSQLI_ASSOC);
			$min_bet    = $getBetsRow["min_bet"];
			$max_bet    = $getBetsRow["max_bet"];
			/*
				Set Bet Sleep time
			*/
			$sleepRes   = $mysqli->query("select sleep_value from sleep_val LIMIT 1");
			if($sleepRes->num_rows > 0){
				$sleepRow   = $sleepRes->fetch_array(MYSQLI_ASSOC);
				$sleepVal   = $sleepRow["sleep_value"];
			}else{
				$sleepVal = "6";
			}

			if($min_bet == 0 && $max_bet == 0){
				$getuidRes = $mysqli->query("select id from users where userid =".$userid);
				$getuidRow = $getuidRes->fetch_array(MYSQLI_ASSOC);
				$userid    = $getuidRow["id"];
				$checkSess 			= $mysqli->query("select isActive from matches where id=".$match_id);
				$checkSessrow 		= $checkSess->fetch_array(MYSQLI_ASSOC);
				$stat = $checkSessrow["isActive"];
				if($stat == 1){
					$msg = array("responseData" => array("status" => "0", "error" => "Market Suspended Try Again"));
				}else{
					
					sleep($sleepVal);
					$checkSess 			= $mysqli->query("select isActive from matches where id=".$match_id);
					$checkSessrow 		= $checkSess->fetch_array(MYSQLI_ASSOC);
					$stat = $checkSessrow["isActive"];
					if($stat == 1){
						$msg = array("responseData" => array("status" => "0", "error" => "Market Suspended Try Again"));
					}else{
						$obj = new fairsession; 
						$res = $obj->savematchBetrt($userid,$match_id,$b_l,$amount,$run,$team,$stm);
						return $res;
						/*if($b_l == 0){
							$sessRecordRes 	= $mysqli->query("select * from matches where id=".$match_id);
							$sessRecordRow 	= $sessRecordRes->fetch_array(MYSQLI_BOTH);
							$dbrate 			= explode(":",$sessRecordRow["sess_rate"]);
							$rts 			= $sessRecordRow["rate"];
							if($rts == "0:0"){
								$dbrate 			= explode(":",$sessRecordRow["sess_rate"]);
								$dbrate 			= $dbrate[0];
							}else{
								$dbrate 			= $sessRecordRow["runs"];
							}
							if($dbrate >= $run[0]){
								$sleep = 1;
								$obj = new fairsession; 
								$res = $obj->saveRate($userid,$match_id,$y_n,$rt,$run[0],$rate[1],$rt2);
								return $res;
							}else{
								$msg = array("responseData" => array("status" => "0", "error" => "Bet Rejected Rate Changed"));
							}
						}else if($b_l == 1){
							/* $sessRecordRes 	= $mysqli->query("select * from matches where id=".$match_id);
							$sessRecordRow 	= $sessRecordRes->fetch_array(MYSQLI_BOTH);
							$rts 			= $sessRecordRow["rate"];
							if($rts == "0:0"){
								$dbrate 			= explode(":",$sessRecordRow["sess_rate"]);
								$dbrate 			= $dbrate[1];
							}else{
								$dbrate 			= $sessRecordRow["runs"];
							}
							if($dbrate <= $run[0]){
								$sleep = 1;
								$obj = new fairsession; 
								$res = $obj->saveRate($userid,$match_id,$y_n,$rt,$run[0],$rate[1],$rt2);
								return $res;
							}else{
								$msg = array("responseData" => array("status" => "0", "error" => "Bet Rejected Rate Changed"));
							} 
						}*/
					}
				}
			}else{
				if($min_bet != 0 && $max_bet != 0){
					if($rt < $min_bet){
						$msg = array("responseData" => array("status" => "0", "error" => "Less than minimum allowed for You. Please try above minimum."));
						return $msg;
					}
					if($rt > $max_bet){
						$msg = array("responseData" => array("status" => "0", "error" => "More than maximum allowed for You. Please try below maximum."));
						return $msg; 
					}
				}
				if($min_bet != 0 && $max_bet == 0){
					if($rt < $min_bet){
						
						$msg = array("responseData" => array("status" => "0", "error" => "Less than minimum allowed for You. Please try above minimum."));
						return $msg;   
					}
				}
				if($max_bet != 0 && $min_bet == 0){
					if($rt > $max_bet){
						$msg = array("responseData" => array("status" => "0", "error" => "More than maximum allowed for You. Please try below maximum."));
						return $msg;
					}
				}
				$getuidRes = $mysqli->query("select id from users where userid =".$userid);
				$getuidRow = $getuidRes->fetch_array(MYSQLI_ASSOC);
				$userid    = $getuidRow["id"];
				$checkSess 			= $mysqli->query("select isActive from matches where id=".$match_id);
				$checkSessrow 		= $checkSess->fetch_array(MYSQLI_ASSOC);
				$stat = $checkSessrow["isActive"];
				if($stat == 1){
					$msg = array("responseData" => array("status" => "0", "error" => "Market Suspended Try Again"));
				}else{
					sleep($sleepVal);
					$checkSess 			= $mysqli->query("select isActive from matches where id=".$match_id);
					$checkSessrow 		= $checkSess->fetch_array(MYSQLI_ASSOC);
					$stat = $checkSessrow["isActive"];
					if($stat == 1){
						$msg = array("responseData" => array("status" => "0", "error" => "Market Suspended Try Again"));
					}else{
						if($b_l == 0){
							$sessRecordRes 	= $mysqli->query("select * from matches where id=".$match_id);
							$sessRecordRow 	= $sessRecordRes->fetch_array(MYSQLI_ASSOC);
							//$rts 			= $sessRecordRow["rate"];
							/* if($rts == "0:0"){
								$dbrate 			= explode(":",$sessRecordRow["sess_rate"]);
								$dbrate 			= $dbrate[0];
							}else{ */
							if($stm == "1"){
								$dbrate 			= explode(":",$sessRecordRow["team1_rate"]);
								$dbrate             = $dbrate[0];
							}else{
								$dbrate 			= explode(":",$sessRecordRow["team2_rate"]);
								$dbrate             = $dbrate[0];
							}
							/* } */
							if($dbrate >= $run){
								$sleep = 1;
								$obj = new fairsession; 
								$res = $obj->savematchBetrt($userid,$match_id,$b_l,$amount,$run,$team,$stm);
								return $res;
							}else{
									$msg = array("responseData" => array("status" => "0", "error" => "Bet Rejected Rate Changed"));
							} 
						}else if($b_l == 1){
							$sessRecordRes 	= $mysqli->query("select * from matches where id=".$match_id);
							$sessRecordRow 	= $sessRecordRes->fetch_array(MYSQLI_ASSOC);
							if($stm == "1"){
								$dbrate 			= explode(":",$sessRecordRow["team1_rate"]);
								$dbrate             = $dbrate[1];
							}else{
								$dbrate 			= explode(":",$sessRecordRow["team2_rate"]);
								$dbrate             = $dbrate[1];
							}
							if($dbrate <= $run){
								$sleep = 1;
								$obj = new fairsession; 
								$res = $obj->savematchBetrt($userid,$match_id,$b_l,$amount,$run,$team,$stm);
								return $res;
							}else{
								$msg = array("responseData" => array("status" => "0", "error" => "Bet Rejected Rate Changed"));
							} 
						}
					} 
				}
			}
			return $msg;
	}
	function savematchBetrt($userid,$match_id,$b_l,$amount,$run,$team,$stm){
			global $mysqli;
			$run  = $run-1;
			if($b_l == "0" && $stm == "1"){
				$team1 = abs($amount*$run);
				$team2 = 0-$amount;
			}else{
				$team1 = 0-abs($amount*$run);
				$team2 = $amount;
			}
			
			$verfied = "U";
			$results = $mysqli->query("insert into match_res set uid = '".$userid."',parent_id = '".$userid."',match_id = '".$match_id."',team = '".$team."',team1 = '".$team1."',team2 = '".$team2."',b_l = '".$b_l."',stak = '".$amount."',rate = '".$run."',status = 'M',verfied = '".$verfied."'");
			if($results){
				$msg = array("responseData" => array("status" => "1", "msg" => "Submitted Successfully"));
			}else{
				$msg = array("responseData" => array("status" => "0", "error" => "No Records"));
			}
			return $msg;
	}
	
	function getmatchRes($match_id,$uid){
		global $mysqli;
		$useridQry 		= $mysqli->query("select id from users where userid=".$uid);
		$useridRow 		= $useridQry->fetch_array(MYSQLI_ASSOC);
		$result 	= $mysqli->query("select team1,team2,b_l,stak,rate from match_res where match_id =".$match_id." and uid=".$useridRow["id"]);
		if($result->num_rows > 0){
			while($row2 		= $result->fetch_array(MYSQLI_ASSOC)){
				$rows2[] = $row2; 
			}
			$msg = array("responseData" => array("status" => "1", "result" => $rows2));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Records"));
		}
		return $msg;
	}
}
?>