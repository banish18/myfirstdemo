<?php 
//date_default_timezone_set('Asia/kolkata');
include('inc/functions.php');
ini_set('memory_limit','512M');
//error_reporting(0);
set_time_limit(0);
header('Content-type: application/json');
if(isset($_POST) && (count($_POST)>0) ){	
}else{
	$json_raw = file_get_contents('php://input');
	if($json_raw){
		//$obj = new fairsession; 
		//$obj -> saveRequest($json_raw);
	}	
	$_POST = json_decode($json_raw, TRUE);	
} 
/* $_POST["action"]     = "getSession_test";
$_POST["userid"]     = "101002";
$_POST["session_id"]     = "139"; */
/*
$_POST["password"]    = "12345678"; */
/* $_POST["action"]     = "getSession_test";
$_POST["userid"]     = "101002";
$_POST["session_id"]    = "97";  */

/* $_POST["action"]     = "saveSessRate";
$_POST["sess_id"]     = "93";
$_POST["userid"]     = "101002";  
$_POST["y_n"]   	= "0";
$_POST["amount"]    = "20"; 
$_POST["run"]    = "6:100";   */

/* $_POST["action"]     = "saveSessRate";
$_POST["sess_id"]     = "152";
$_POST["userid"]     = "100001";  
$_POST["y_n"]   	= "0";
$_POST["amount"]    = "200"; 
$_POST["run"]    = "57:100";
 */
try {
	switch (isset($_POST['action']) ? ($_POST['action']) : 'Wrong') {
		case 'login': 
		$obj = new fairsession; 
		$userid 	= isset($_POST["userid"]) ? $_POST["userid"] : "";
		$app_ver 	= isset($_POST["app_ver"]) ? $_POST["app_ver"] : "";
		$password 	= isset($_POST["password"]) ? $_POST["password"] : "";
		$response 	= $obj->login($userid,$password,$app_ver);
		break;
		case 'getSession': 
		$obj 			= new fairsession; 
		$userid 		= isset($_POST["userid"]) ? $_POST["userid"] : "";
		$session_id 	= isset($_POST["session_id"]) ? $_POST["session_id"] : "";
		$response 		= $obj->getSess($userid);
		break;
		
		case 'getSession_test': 
		$obj 			= new fairsession; 
		$userid 		= isset($_POST["userid"]) ? $_POST["userid"] : "";
		$session_id 	= isset($_POST["session_id"]) ? $_POST["session_id"] : "";
		$response 		= $obj->getSesstest($userid,$session_id);
		break;
		
		case 'changePassword': 
		$obj 		= new fairsession; 
		$userid 	= isset($_POST["userid"]) ? $_POST["userid"] : "";
		$password 	= isset($_POST["password"]) ? $_POST["password"] : "";
		$response 	= $obj->changePassword($userid,$password);
		
		break;
		case 'getallSession': 
		$obj 		= new fairsession; 
		$response 	= $obj->getallSess();
		break;
		case 'saveSessRate': 
		$obj 		= new fairsession; 
		$userid 	= isset($_POST["userid"]) ? $_POST["userid"] : "";
		$sess_id 	= isset($_POST["sess_id"]) ? $_POST["sess_id"] : "";
		$y_n 		= isset($_POST["y_n"]) ? $_POST["y_n"] : "";
		$amount     = isset($_POST["amount"]) ? $_POST["amount"] : "";
		$run        = isset($_POST["run"]) ? $_POST["run"] : "";
		$response 	= $obj->saveSess($userid,$sess_id,$y_n,$amount,$run);
		break;
		
		case 'getallSessmetrxdata': 
		$obj 		= new fairsession; 
		$userid 	= isset($_POST["userid"]) ? $_POST["userid"] : "";
		$sess_id 	= isset($_POST["sess_id"]) ? $_POST["sess_id"] : "";
		$response 	= $obj->getallSessmett($userid,$sess_id);
		break;
		
		case 'setDeclare': 
		$obj 		= new fairsession; 
		$sess_id 	= isset($_POST["sess_id"]) ? $_POST["sess_id"] : "";
		$amt 		= isset($_POST["amt"]) ? $_POST["amt"] : "";
		$response 	= $obj->setDeclare($sess_id,$amt);
		break;
		
		case 'setUndeclare': 
		$obj 		= new fairsession; 
		$sess_id 	= isset($_POST["sess_id"]) ? $_POST["sess_id"] : "";
		$response 	= $obj->setUndeclare($sess_id);
		break;
		
		case 'ledgerReports': 
		$obj 		= new fairsession; 
		$user_id 	= isset($_POST["user_id"]) ? $_POST["user_id"] : "";
		$response 	= $obj->getLreports($user_id);
		break;
		
		case 'ledgerSessReports': 
		$obj 		= new fairsession; 
		$user_id 	= isset($_POST["user_id"]) ? $_POST["user_id"] : "";
		$response 	= $obj->getLSessreports($user_id);
		break;
		
		case 'ledgerSessRes': 
		$obj 		= new fairsession; 
		$sess_id 	= isset($_POST["sess_id"]) ? $_POST["sess_id"] : "";
		$user_id 	= isset($_POST["user_id"]) ? $_POST["user_id"] : "";
		$response 	= $obj->getLSessres($sess_id,$user_id);
		break;
		
		case 'ledgerDateSess': 
		$obj 		= new fairsession; 
		$user_id 	= isset($_POST["user_id"]) ? $_POST["user_id"] : "";
		$from_date 	= isset($_POST["from_date"]) ? $_POST["from_date"] : "";
		$to_date 	= isset($_POST["to_date"]) ? $_POST["to_date"] : "";
		$response 	= $obj->getDateres($user_id,$from_date,$to_date);
		break;
		
		case 'getRunSess': 
		$obj 		= new fairsession; 
		$response 	= $obj->getRunSessres();
		break;
		
		case 'getALlMatches': 
		$obj 		= new fairsession; 
		$response 	= $obj->getAllMt();
		break;
		
		case 'getALlRates': 
		$obj 		= new fairsession; 
		$url 	= isset($_POST["url"]) ? $_POST["url"] : "";
		$tm 	= isset($_POST["tm"]) ? $_POST["tm"] : "";
		$elm 	= isset($_POST["elm"]) ? $_POST["elm"] : "";
		$response 	= $obj->getAllRt($url,$tm,$elm);
		break;
		
		case 'getALlautoRates': 
		$obj 		= new fairsession; 
		$url 	= isset($_POST["url"]) ? $_POST["url"] : "";
		$tm 	= isset($_POST["tm"]) ? $_POST["tm"] : "";
		$response 	= $obj->getAllautoRt($url,$tm);
		break;
		
		case 'saveAuto': 
		$obj 		= new fairsession; 
		$sell 		= isset($_POST["sell"]) ? $_POST["sell"] : "";
		$buy 		= isset($_POST["buy"]) ? $_POST["buy"] : "";
		$current 	= isset($_POST["current"]) ? $_POST["current"] : "";
		$sess_id 	= isset($_POST["sess_id"]) ? $_POST["sess_id"] : "";
		$ky 		= isset($_POST["ky"]) ? $_POST["ky"] : "";
		$elm 		= isset($_POST["elm"]) ? $_POST["elm"] : "";
		$response 	= $obj->svArates($buy,$sell,$current,$sess_id,$ky,$elm);
		break;
		
		
		case 'getSessDiff': 
		$obj 		= new fairsession; 
		$response 	= $obj->getSessDiff();
		break;
		
		case 'saveSessDt':
		$obj 		= new fairsession; 
		$sid 		= isset($_POST["sid"]) ? $_POST["sid"] : "";
		$end 		= isset($_POST["end"]) ? $_POST["end"] : "";
		$start 		= isset($_POST["start"]) ? $_POST["start"] : "";
		$run 		= isset($_POST["run"]) ? $_POST["run"] : "";
		$ky 		= isset($_POST["ky"]) ? $_POST["ky"] : "";
		$response 	= $obj->saveSessDt($sid,$end,$start,$run);
		break;
		
		case 'setSessrate':
		$obj 		= new fairsession; 
		$sid 		= isset($_POST["sid"]) ? $_POST["sid"] : "";
		$response 	= $obj->setSessrate($sid); 
		break;
		
		case 'susspendSess':
		$obj 		= new fairsession; 
		$sid 		= isset($_POST["sid"]) ? $_POST["sid"] : "";
		$response 	= $obj->susspendSess($sid); 
		break;
		
		default:
            throw new Exception('Wrong action !');
	}
	echo str_replace("\/", "/", json_encode($response));
}
// If any exception occurs then send the error in json.
catch (Exception $e) {
    die(json_encode(array('error' => $e->getMessage())));
}	


?>

