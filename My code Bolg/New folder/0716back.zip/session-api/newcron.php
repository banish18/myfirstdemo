<?php 
//shell_exec("/usr/bin/nohup php cron.php > output.txt &");
//exec('/usr/bin/php nohup cron.php >/dev/null 2>&1 &');
//exec("/usr/bin/php newcron.php &"); 
//exec("ulimit -n 4096"); 
date_default_timezone_set('Asia/Kolkata');
set_time_limit(0);
error_reporting(0);
 
include('connection.php'); 
$sess_id = file_get_contents("sessid.txt", true);
if($sess_id != ""){
  $allSess = explode(",",$sess_id);
	if($allSess[0] == 0){
		cron_progress($allSess[1]);
	}else{
		foreach($allSess as $sess_id){
			cron_progress($sess_id);
		}
	}
}else{

	$qry = $mysqli->query("update sessions set isActive = '1',action = '2' where id =".$sess_id[1]);
					$res = "session has been susspened";
} 
function cron_progress($sess_id){
		global $mysqli;
		$allSess = file_get_contents("sessid.txt", true);
		$allSess = explode(",",$allSess);
		if(in_array($sess_id,$allSess)){
			$results = $mysqli->query("select * from auto_session_values where sid =".$sess_id);
			$row = $results->fetch_array(MYSQLI_BOTH);	
			if($row){
				$url = "http://livepricing.sportingindex.com/LivePricing.svc/jsonp/GetLivePricesByMeeting?meetingKey=".$row["main_mkt"];
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
				curl_setopt($ch, CURLOPT_HEADER, 0);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);  
				$data = curl_exec($ch);
				curl_close($ch); 
				$data = json_decode($data);
				$data = $data->Markets;
				//echo "<pre>";print_r($data);	
				for($i = 0;$i < count($data);$i++){
					if($data[$i]->Key == $row["mkt_id"]){ 
						$crt = $data[$i]->SoFar;
						$sell = $data[$i]->Sell;
						$buy  = $data[$i]->Buy;
						$ct 	= explode("/",$data[$i]->SoFar);
						$status = $data[$i]->Status;
						//echo "<pre>";print_r($ct);
						if(count($ct) > 1){
							$ct = $ct[0];
						}else{
							$ct = $data[$i]->SoFar;
						}
						if($ct == "-"){
							$ct = "0";
						}
						$ky = $data[$i]->Key;
					}
				}
				if($status != "SU"){
					
					$mysqli->query("update auto_session_values set current = '".$ct."',sell_rate = '".$sell."',buy_rate = '".$buy."',score = '".$crt."',mkt_id = '".$ky."' where sid = '".$sess_id."'");
					$result = $mysqli->query("select * from session_diff where sid =".$sess_id);
					while($row = $result->fetch_array(MYSQLI_BOTH)){
						if($row["start"] == "0" && $row["end"] == "0" && $row["run_value"] == "0"){
							$a = 1;
							$diffA = $buy-$ct;
							if($diffA >= $row["start"] && $diffA <= $row["end"]){
								$margin = $buy-$row["run_value"];
								$vl = 2;
							}
						}else if($row["start"] == "0" && $row["end"] == "0" && $row["run_value"] != "0"){
							$a = 2;
							$diff = $buy-$sell;
							if($diff > $row["run_value"]){
								$diff = $diff-$row["run_value"];
								$diff = $diff/2;
								$sellR = $sell+$diff;
								$buyR = $buy-$diff;
								$vl = 1; 
							}else{
								$vl = 3;
							}
						}else{
							$a = 3;
							$diff = $buy-$ct; 
							if($diff >= $row["start"] && $diff <= $row["end"]){
								$margin = $buy-$row["run_value"];
								$vl = 2;
							}
						} 
					}
					if($vl == 1){ 
						$sess_rate = round($sellR).':'.round($buyR);
					}else if($vl == 3){
						$sess_rate = round($sell,0,PHP_ROUND_HALF_DOWN).':'.round($buy,0);
					}else{
						$sess_rate = $margin.':'.$buy;
					}
					$getSlideRate =  $mysqli->query("select * from slide_rate LIMIT 1");
					if($getSlideRate->num_rows > 0) {
						$getSlideRow  = $getSlideRate->fetch_array(MYSQLI_BOTH);
						$rt = 	$getSlideRow["rate"];				
						$rate         = explode(":",$sess_rate);
						if($rt < 0){
							$rate1 = intval($rate[0])+intval($rt);
							$rate2 =  intval($rate[1])+intval($rt);
						}else{
							$rate1 = intval($rate[0])+intval($rt);
							$rate2 = intval($rate[1])+intval($rt);
						}
						$sess_rate 				= $rate1.":".$rate2;
					}
					$res = $mysqli->query("update sessions set action = '3',sess_rate = '".$sess_rate."',runs = '0',run_diff = '0',rate = '0:0',select_val = '0_0',isActive = '0' where id =".$sess_id);
					
					$res = "your data has been updated";
					$date = date('Y-m-d h:i:s',strtotime(date('Y-m-d h:i:s')));
					
					/* $mysqli->query("update admin_login_check set updated_at = '".$date."' where id = '1'"); */
					//sleep(1);  
					//cron_progress($sess_id);
				}else{
					$qry = $mysqli->query("update sessions set isActive = '1',action = '2' where id =".$sess_id);
					$res = "session has been susspened";
				}
			}else{
				$qry = $mysqli->query("update sessions set isActive = '1',action = '2' where id =".$sess_id);
					$res = "session has been susspened";
			}
		}else{
			$qry = $mysqli->query("update sessions set isActive = '1',action = '2' where id =".$sess_id);
					$res = "session has been susspened";
		}
		echo $res;
	}
echo $res;
?>