<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Response;
use Illuminate\Http\RedirectResponse;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use Illuminate\Support\Facades\Redirect;
use Validator;
use Mail;
//models
use App\User;

class LoginController extends Controller
{
 
	public function __construct()
	{
		$this->middleware('web');
	}

   protected function validator(array $data)
    {
        return Validator::make($data, [
            'username' => 'required|max:255',
            'password' => 'required|min:5',
        ]);
    }


	protected function paswordValidator(array $data)
    {
        return Validator::make($data, [
            'password' => 'required|confirmed|min:5',
        ]);
    }

   function getlogin(Request $request)
   {
		$validator = $this->validator($request->all());             
		if ($validator->fails())
		{
			return Redirect::to('login')->withErrors($validator);
		}   

		$username = $request->input('username');
		$pass = $request->input('password');
	
		if (Auth::attempt(array('userid' => $username, 'password' => $pass ) , 1))
		{
            return redirect('/dashboard');
		}else if(Auth::attempt(array('email' => $username, 'password' => $pass ) , 1)){
				return redirect('/dashboard');
		}
		else
		{
			 return redirect("login")->withErrors("Invalid User Name and Credentials");;
		}
   } 
}
