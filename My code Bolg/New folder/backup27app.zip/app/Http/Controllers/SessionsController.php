<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\User;
use Auth;
use App\Session;
use App\Sessionrec;
use App\Sessionmatrix;
use App\Sliderate;
use Illuminate\Support\Facades\Redirect;
use DB;
use App\Aloginchk;
use App\Ledgerview;
class SessionsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
		
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$user = Auth::User();
		if($user->user_type == 0){
		   Redirect::to('/dashboard')->send();
		}
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$title = "Sessions";
		$Sessions = Session::orderBy('id', 'desc')->paginate(10);
		$numbers = [];		
		for($i=0;$i<=500;$i++){
			$numbers[$i] = $i;
		}
        return view('sessions',array("title" => $title,'Sessions' => $Sessions,'numbers' => $numbers));
		
    }		
	public function showSessions()
    {		
		$user = Auth::User();
		if($user->user_type == 0){
		   Redirect::to('/dashboard')->send();
		}
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$title = "Sessions";
		$arr = ['2','3'];	
		$Sessions = Session::orWhereIn('action',$arr)->orderBy('id', 'desc')->get();
		$numbers = [];
			for($i=0;$i<=500;$i++){
				$numbers[$i] = $i;
		} 
		return view('all-sessions',array("title" => $title,'Sessions' => $Sessions,'numbers' => $numbers));    
	}
	
	public function testshowSessions()
    {		
		$user = Auth::User();
		if($user->user_type == 0){
		   Redirect::to('/dashboard')->send();
		}
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$title = "Sessions";
		$arr = ['2','3'];	
		$Sessions = Session::orWhereIn('action',$arr)->orderBy('id', 'desc')->get();
		$numbers = [];
			for($i=0;$i<=500;$i++){
				$numbers[$i] = $i;
		} 
		return view('testrunsuss',array("title" => $title,'Sessions' => $Sessions,'numbers' => $numbers));    
	}
	
	public function postSessdata(Request $request){
		$user =  Auth::User();
		$userType = $user->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$session 				= new Session;
		$session->user_id       = $user->id;
        $session->over 			= $request->over;
		$session->action 		= '1';
		$session->save();
		
		$id 	  = $session->id;
		$sess	  = Session::find($id);
		$msg      = 1;
		$tm 	  = $sess->over;
		$ac 	  = $sess->action;
		$numbers  = [];
		for($i=0;$i<=500;$i++){
			$numbers[$i] = $i;
		}
		

		$result   = array("msg" => $msg,'tm' => $tm,'ac' => $ac,'id' => $id,'numbers' => $numbers);		\Session::flash('flash_message','Session Succefully Created');
		return $result;
	}
	
	public function updateSessisactive(Request $request){
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$id = $request->sess_id;
		$is = $request->is;
		$session = Session::find($id);
		$session->isActive = $is;
		$session->action   = $request->act;
		$session->save();
		$result   = array("msg" => $is);
		return $result;
	}		
	public function updateSessisastatus(Request $request){
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$id = $request->sess_id;
		$is = $request->is;
		$session = Session::find($id);
		if($is == 2 || $is == 1){
			$session->amount = 0;
		}
		$session->action = $is;
		$session->save();
		$result   = array("msg" => 1);
		\Session::flash('flash_message','Session Succefully Updated');
		return $result;
	}
	public function updateDcrate(Request $request){
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$id = $request->sess_id;
		$amt = $request->amt;
		$session = Session::find($id);
		$session->amount = $amt;
		$session->action = '3';
		$session->save();
		$result   = array("msg" => 1);
		\Session::flash('flash_message','Declare Rate Succefully Updated');
		return $result;
	}
	public function setSessRate(Request $request){
		$user =  Auth::User();
		$userType = $user->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$id 				= $request->sess_id;
		$rate 				= $request->rate;
		$session 			= Session::find($id);
		$session->user_id   = $user->id;
		$session->sess_rate = $rate;
		$session->runs 		= $request->runs;
		$session->run_diff 	= $request->run_diff;
		$session->rate 		= $request->sess_rate;
		$session->select_val 		= $request->select_val;
		$session->save();
		$result   = array("msg" => 1); 
		return $result;
	}
	
	public function getSessionentry(){
		$title 		= 'Session Entry';
		$user 		=  Auth::User();
		$loggeduser = Auth::User();
		$arr = ['2','3'];	
		$sessions = Session::orWhereIn('action',$arr)->orderBy('id', 'desc')->get();
		if($user->user_type == 2){
			$users = User::where('users.parent',$user->id)->where('user_type','0')->get();	
		}else{
			$users = User::where('user_type','!=','1')->get();
		}
		return view('session-entry',array('title' => $title,'sessions' => $sessions,'users' => $users,'loggeduser' => $loggeduser));
	}
	
	public function postSessionentry(Request $request){
		$user =  Auth::User();
		$userType = $user->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$rn = $request->runs;
		$rt = $request->rate;
		$amount = $rt*$request->amount/100;
		$id                     = $request->input("sess_id");
		$session 				= new Sessionrec;
		$session->uid       	= $request->usr_id;
        $session->sess_id 		= $id;
		$session->run 			= $request->runs; 
		$session->amount 		= $amount;
		$session->y_n 			= $request->y_n;
		$session->rate 			= $request->rate;
		$session->save();
		$var1 = $session->run;
		$sessMatrix = [];
		$sessMatrix2 = [];
		$entryVar = 300-$session->run;
		for($i =1;$i<=$session->run-1;$i++){
			array_push($sessMatrix,$i);
		}
		for($j = $session->run;$j<=$session->run+$entryVar;$j++){
			array_push($sessMatrix2,$j);
		}
		$sessMatrix = array_merge($sessMatrix,$sessMatrix2);
		if($session->y_n == 1){
			$amount1 = [];
			$amount2 = [];
			for($i =1;$i<=$session->run-1;$i++){
				array_push($amount1,'-'.$session->amount);
			}
			for($j = $session->run;$j<=$session->run+$entryVar;$j++){
				array_push($amount2,'+'.$session->amount);
			}
		}else{
			$amount1 = [];
			$amount2 = [];
			for($i =1;$i<=$session->run-1;$i++){
				array_push($amount1,'+'.$session->amount);
			}
			for($j = $session->run;$j<=$session->run+$entryVar;$j++){
				array_push($amount2,'-'.$session->amount);
			}
		}
		$users = User::where('id',$request->usr_id)->first();
		$sessAmount = array_merge($amount1,$amount2);
		$i = 0;
		foreach($sessMatrix as $sm){
			$Sessionmatrix = new Sessionmatrix;
			$Sessionmatrix->sid 	= $request->sess_id;
			$Sessionmatrix->uid 	= $request->usr_id;
			$Sessionmatrix->runs 	= $sm;
			$Sessionmatrix->amount 	= $sessAmount[$i];
			$Sessionmatrix->parent_id 	= $session->id;
			$Sessionmatrix->admin_id 	 = $users->parent_id;
			$Sessionmatrix->save();
			$i++;
		} 
		
		$minValue = DB::table('session_matrix')->select(DB::raw('runs,sum(amount) as amount'))->where('sid',$request->sess_id)->where('uid',$request->usr_id)->groupBy('runs')->first();
		$ledBalance = Ledgerview::where('uid',$request->usr_id)->first();
		/* echo $minValue->amount;
		echo "<br />";          
		echo $ledBalance->balance;  */  
	
		if(abs($minValue->amount) > $ledBalance->balance){ 
			$msg = 0;
			DB::table('sessions_res')->where('id',$session->id)->delete();
			DB::table('session_matrix')->where('parent_id',$session->id)->delete();
		}else{
			$msg = 1;
		}
		return $msg;
	}
	
	public function updatesessStat(Request $request){
		$id = $request->sess_id;
		$session = Session::find($id);
		$session->action = "2";
		$session->save();
		$msg = 1;
		return $msg;
	}
	public function getsesMtxData(Request $request){
		$user =  Auth::User();
		$adCheck = Aloginchk::find('1');
		$date = date('Y-m-d h:i:s',strtotime(date('Y-m-d h:i:s'))+19800);
		$adCheck->updated_at = $date;
		$adCheck->save(); 
		
		
		
		$sess_id = $request->sess_id;
		$getSessAC = Session::find($sess_id);
		if($user->user_type == 1){
			$Sessionmatrix = DB::table('super_admin_exp')->select(DB::raw('runs,sum(exposure) as amount'))
                     ->where('sid',$sess_id)
                     ->groupBy('runs')
                     ->get();
			$SessionRes	 = 	DB::table('sessions_res')
                     ->where('sess_id',$sess_id)
					 ->orderBy('id','desc')
                     ->get();
		}else if($user->user_type == 2){
			
			$Sessionmatrix = DB::table('admin_exp')->select(DB::raw('runs,sum(exposure) as amount'))
                     ->where('sid',$sess_id)
					 ->where('admin_id',$user->id)
                     ->groupBy('runs')
                     ->get();
			$SessionRes = DB::select('select * from sessions_res where uid in (select id from users where parent_id = '.$user->id.') and sess_id = '.$sess_id.' ORDER BY id desc');		 
			/* $SessionRes	 = 	DB::table('sessions_res')->select(DB::raw('select * from users where parent = '.$user->id.''))
                     ->where('sess_id',$sess_id)
					 ->orderBy('id','desc')
                     ->get();	 */	 
		}else{
			$Sessionmatrix = DB::table('matrix_view')->select(DB::raw('runs,sum(amount) as amount'))
                     ->where('sid',$sess_id)
					 ->where('admin_id',$user->id)
                     ->groupBy('runs')
                     ->get();
			$SessionRes	 = 	DB::table('sessions_res')
                     ->where('sess_id',$sess_id)
					 ->where('uid',$user->id)
					 ->orderBy('id','desc')
                     ->get();		 
		}
		$html 	= '';
		$html2  = '';
		if($Sessionmatrix){
			$i=0;
			foreach($Sessionmatrix as $data){
				$i++;
				if((int)$data->amount > 0){ 
					$class = "rd";
				}else{
					$class = "gn";
				}
				$html .= '<tr class="s_'.$i.'"><td>'.$data->runs.'</td><td class="'.$class.'">'. abs($data->amount).'</td></tr>';
			}
		}else{
			$html .= '<tr><td>No Records<td></tr>';
		}
		$aUser = new User;
		if($SessionRes){ 
			$i = count($SessionRes);
			foreach($SessionRes as $Sdata){	
				$i-- ;
				if($Sdata->y_n == 0){ 
					$yn = "N";
				}else{
					$yn = "Y";
				}
				$lgusr = Auth::User(); 
				if($lgusr->user_type == "1"){
					$del = '<td><a style="cursor:pointer;" onclick="deletesessRes('.$Sdata->id.')">Delete</a></td>';
				}else{
					$del = "";
				}
				$html2 .= '<tr><td>'.$i.'</td><td>'.$aUser->getUserName($aUser->getAdmin($Sdata->uid)).'</td><td>'.$aUser->getUserName($Sdata->uid).'</td><td>'.$Sdata->run.'</td><td>'.$Sdata->amount.'</td><td>'.$yn.'</td>'.$del.'</tr>';
			}
		}else{
			$html2 .= '<tr><td>No Records<td></tr>';
		} 
		$result = array('html' => $html,'html2' => $html2,'sess_ac' => $getSessAC->isActive,'sess_rate' => $getSessAC->sess_rate,'sessrn' => $getSessAC->runs);
		return $result;
	}
	function deleteSessresData(Request $request){
		DB::table('sessions_res')->where('id',$request->input('sid'))->delete();
		DB::table('session_matrix')->where('parent_id',$request->input('sid'))->delete();
	}
	public function showautoSessions()
    {		
		$user = Auth::User(); 
		if($user->user_type == 0){
		   Redirect::to('/dashboard')->send(); 
		} 
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$title = "Sessions";
		$arr = ['2','3'];	
		$Sessions = Session::orWhereIn('action',$arr)->orderBy('id', 'desc')->get();
		$numbers = [];
			for($i=0;$i<=500;$i++){
				$numbers[$i] = $i;
		} 
		return view('run-session-auto',array("title" => $title,'Sessions' => $Sessions,'numbers' => $numbers));    
	}
	public function sussallSession(Request $request){
		$SessionRes = DB::table('sessions')->update(['isActive' => '1']);	
		$myfile = fopen("session-api/sessid.txt", "w") or die("Unable to open file!");
		fwrite($myfile, "");
		fclose($myfile);
		$msz = 1;
		return $msz;
	}
	public function sliderRate()
    {
		$title = "Slider";
		$arr = ['2','3'];	
		$Sliderate = Sliderate::find(1);
		$sessions = Session::orWhereIn('action',$arr)->orderBy('id', 'desc')->get();
        return view('slider-rate',array("title" => $title,'sessions' => $sessions,'Sliderate' => $Sliderate));
    }
	public function postslideSessrt(Request $request)
    {
		$title 		= "Post Slider";
		$sess_id 	= $request->input("sess_id");
		$rt 		= $request->input("rt");
		$sessions   = Session::find($sess_id);
		$sess_rate  = $sessions->sess_rate;
		$rate       = explode(":",$sess_rate);
		$Sliderate  = Sliderate::find(1);
		if($Sliderate){
			$Sliderate->rate = $rt;
			$Sliderate->save();
		}else{
			$Sliderate = new Sliderate;
			$Sliderate->rate = $rt;
			$Sliderate->save();
		}	
		/* if($rt < 0){
			$rate1 = $rate[0]-$rt;
			$rate2 = $rate[1]-$rt;
		}else{
			$rate1 = $rate[0]+$rt;
			$rate2 = $rate[1]+$rt;
		}
		$sess_rate 				= $rate1.":".$rate2;
		$session  				= Session::find($sess_id);
		$session->sess_rate 	= $sess_rate;
		$session->save(); */
		$msg = 1;
		return $msg;
    }		
}

