<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Aloginchk extends Authenticatable
{
   protected $table = 'admin_login_check';
}
