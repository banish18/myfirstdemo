<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Ledgerview extends Authenticatable
{
   protected $table = 'ledbalance';
}
