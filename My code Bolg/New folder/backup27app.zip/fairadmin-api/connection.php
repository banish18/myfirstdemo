<?php

function getConnected($host,$user,$pass,$db) {



   $mysqli = new mysqli($host, $user, $pass, $db);



   if($mysqli->connect_error) 

     die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());



   return $mysqli;

}

//$mysqli = getConnected('127.0.0.1','fairsession_ashwani','ash@1234','fairsession_fairsess'); 

$mysqli = getConnected("localhost",
 
        "comfairs_fair",

        "ash@1234",'comfairs_fairsession'); 



?>