<?php 
include('connection.php');
//date_default_timezone_set('America/New_York'); 
include_once('simple_html_dom.php');
class fairsession{
	function saveRequest($post){
		global $mysqli;
		$results = $mysqli->query("insert into test set request	='".$post."'");
	}
	function login($userid,$password){
		global $mysqli;
		$results = $mysqli->query("select * from users where userid= '".$userid."' and show_pass='".$password."' and user_type = '1'");
		if($results->num_rows > 0){
			$row = $results->fetch_array(MYSQLI_BOTH);			
			$msg = array("responseData" => array("status" => "1", "result" => $row["userid"]));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "Please Check userid and password"));
		}
		return $msg;
	}
	function getSess($session_id){
		global $mysqli;
		$runss       = [];
		$obj 		= new fairsession; 
		$result 	= $mysqli->query("select uid,rate,run,y_n,amount from sessions_res where sess_id=". $session_id);
		while($row 		= $result->fetch_array(MYSQLI_BOTH)){
			$row["admin"] 		= $obj->getUserName($obj->getAdmin($row["uid"]));
			$row["user"]	 	= $obj->getUserName($row["uid"]);
			$rows[] 			= $row;
		}
		$result2 	= $mysqli->query("select runs,sum(exposure) as amount from super_admin_exp where sid=". $session_id." group by runs");
		while($row2 		= $result2->fetch_array(MYSQLI_BOTH)){
			$rows2[] = $row2; 
		}
		if(empty($rows)){
			$rows = [];
		}
		if(empty($rows2)){
			$rows2 = [];
		}
		if($runss){
		  $minval = min($runss);
		}else{
		   $minval = "0";
		}
	
		$checkAdUserLoggInRes = $mysqli->query("select updated_at from admin_login_check");
		$checkAdUserLoggInRow 		= $checkAdUserLoggInRes->fetch_array(MYSQLI_BOTH);
		$time = strtotime(date('Y-m-d h:i:s')); 
		/*echo date('Y-m-d h:i:s').'str'.$time;
		echo 'str'.strtotime($checkAdUserLoggInRow["updated_at"]).'time'.$checkAdUserLoggInRow["updated_at"];
		die;  */
		if($time < strtotime($checkAdUserLoggInRow["updated_at"])+4){ 
			$results = $mysqli->query("select * from sessions where isActive= '0' and id=".$session_id);
			if($results->num_rows > 0){
				$row 		= $results->fetch_array(MYSQLI_BOTH);
				$Srate 		= $row["sess_rate"];
				if($Srate == ":"){
					$msg = array("responseData" => array("status" => "0", "error" => "No Rates Please Wait for another rate",'rs1' => $rows,'rs2' => $rows2,'minval' => $minval));
				}else{
					$sess_id 	= $row["id"];
					$runs 		= $row["runs"];
					$rate 		= $row["rate"];
					if($rate != '0:0'){
						$rate2 = explode(":",$rate);
						$rate2 = $runs.':'.$rate2[1].','.$runs.':'.$rate2[0];
						$Srate = "empty";
					}else{
						$rate2 = "empty";
					}
					$over 		= $row["over"];
					
					$msg = array("responseData" => array("status" => "1", "result" => $Srate,'sess_id' => $sess_id,'desc' => $over,'rate2' => $rate2,'rs1' => $rows,'rs2' => $rows2,'minval' => $minval));
				}
			}else{
				$msg = array("responseData" => array("status" => "0", "error" => "No Rates Please Wait for another rate",'rs1' => $rows,'rs2' => $rows2,'minval' => $minval));
			} 
		}else{
			$mysqli->query("update sessions set isActive = '1'");
			$msg = array("responseData" => array("status" => "0", "error" => "No Rates Please Wait for another rate",'rs1' => $rows,'rs2' => $rows2,'minval' => $minval));
		}
		return $msg;
	}
	public function getRunSessres(){
		global $mysqli;
		$sessDescRes = $mysqli->query("select id,over from sessions where action ='2' or action ='3' order by id desc" );
		if($sessDescRes->num_rows > 0){
			while($sessDescRow = $sessDescRes->fetch_array(MYSQLI_BOTH)){
				$row[] = $sessDescRow;
			}
			$msg = array("responseData" => array("status" => "1", "data" => $row));
		}else{
			$msg = array("responseData" => array("status" => "0", "error" => "No Records"));
		}
		return $msg;
	}
	
	public function getAdmin($id){
		global $mysqli;
		$res = $mysqli->query("select parent_id from users where id=".$id);
		if($res->num_rows > 0){
			$row = $res->fetch_array(MYSQLI_BOTH);
			$user = $row["parent_id"];
		}else{
			$user = "N/A"; 
		} 
		return $user;
	}
	public function getUserName($id){
		global $mysqli;
		$res = $mysqli->query("select name from users where id=".$id);
		if($res->num_rows > 0){
			$row = $res->fetch_array(MYSQLI_BOTH);
			$user = $row["name"];
		}else{
			$user = "N/A";
		} 
		return $user;
	}
	public function saveRt($rt,$rt_rate,$sess_id){
		global $mysqli;
		$selectRes = $mysqli->query("update slide_rate set rate = '".$rt_rate."'");
		$obj 		= new fairsession; 
		$rates     = $obj->getSess($sess_id);
		$rates1     = $rates["responseData"]["result"];
		$rates2     = $rates["responseData"]["rate2"];
		$msg = array("responseData" => array("status" => "1", "rt" => $rt, 'rt_rate' => $rt_rate,'rates' => $rates1,'rates1' => $rates2));
		return $msg;
	}
}
?>