function shSess(elm){
		jQuery(".slide-cont").slideToggle();
}
function isCheck(){	
	var val = jQuery("#act").val();	
	if(val == "Activate"){		 
		jQuery("#act").addClass('deacti_sess');		 
		jQuery("#act").removeClass('acti_sess');		 
		jQuery("#act").val('Deactivate');		 
		jQuery("#ac").val('0');	
	}else if(val == "Deactivate"){		
		jQuery("#act").removeClass('deacti_sess');
		jQuery("#act").addClass('acti_sess');
		jQuery("#act").val('Activate');	
		jQuery("#ac").val('1');
	}
}
function ctSess(){
	var over  = jQuery("#over").val();
	if(over == ""){
		alert("Please Enter");
		return false;
	}
	var token = jQuery("input[name=_token]").val();
	var ac  = jQuery("#ac").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"postSess",
		data:{over:over,_token:token}
	});
	request.done(function (response){
	 jQuery(".loading_img").hide();
       if(response.msg == 1){
		    jQuery(".slide-cont textarea").val('');
		  location.reload();
		   return true;
	   }else{
		   return false;
	   }
    }); 
}
function ctMtch(){
	var over  = jQuery("#over").val();
	var team1  = jQuery("#team_1").val();
	var team2  = jQuery("#team_2").val();
	if(over == ""){
		alert("Please Enter Match Description");
		return false;
	}else if(team1 == ""){
		alert("Please Enter Team1 Name");
		return false;
	}else if(team2 == ""){
		alert("Please Enter Team2 Name");
		return false;
	}
	var token = jQuery("input[name=_token]").val();
	var ac  = jQuery("#ac").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"postMtch",
		data:{matchname:over,_token:token,team1:team1,team2:team2}
	});
	request.done(function (response){
	 jQuery(".loading_img").hide();
       if(response.msg == 1){
		    jQuery(".slide-cont textarea").val('');
			jQuery("#team_1").val('');
			jQuery("#team_2").val('');
			location.reload();
		   return true;
	   }else{
		   return false;
	   }
    }); 
}
function rndiff(elm){
	rd = jQuery(elm).val();
	jQuery("#num_sess_rd").val('');
	var numb = jQuery("#rtnumber").val();
	var res = parseInt(rd)+parseInt(numb);
	jQuery("#rt_1").html(numb);
	jQuery("#rt_2").html(res); 
	jQuery("#sess_rt").html('<option id="rt_0:0" value="0:0">Null</option><option id="rt_90:110" value="90:110">90:110</option><option id="rt_85:115" value="85:115">85:115</option><option id="rt_70:125" value="70:125">70:125</option><option id="rt_100:150" value="100:150">100:150</option><option id="rt_200:250" value="200:250">200:250</option><option id="rt_250:400" value="250:400">250:400</option>');
	jQuery("#save_rt").click();
	
	
}

function ssrate(elm){
	var numb = jQuery("#rtnumber").val();
	jQuery("#num_sess_rd").val('');
	var rt = jQuery(elm).val();
	rt = rt.split(":")
	jQuery("#rt_1").html(numb+':'+rt[1]);
	jQuery("#rt_2").html(numb+':'+rt[0]);
	jQuery("#rn_diff").html('<option value="0" id="rn_0">Null</option><option id="rn_1" value="1">1</option><option id="rn_2" value="2">2</option><option id="rn_3" value="3">3</option><option id="rn_4" value="4">4</option><option id="rn_5" value="5">5</option><option id="rn_6" value="6">6</option>');
	jQuery("#save_rt").click();
}

function setNm(numb,elm){
	jQuery(".num_slide").removeClass('setNum');
	var n = jQuery(elm).text();
	n = numb+'_'+n;
	jQuery("#select_val").val(n);
	jQuery("#num_sess_rd").val('');
	jQuery(elm).addClass('setNum');
	jQuery("#rtnumber").val(numb);
	jQuery("#rn_1").attr("selected","selected");
	var rt  = jQuery("#rt_1").text();	
	var rt2 = jQuery("#rt_2").text();	
	if(rt == '' && rt2 == ''){
		return true;
	}else{
		var a = jQuery("#rn_diff").val();
		var b = jQuery("#sess_rt").val();
		if(a != 0){
			rt  = numb;
			rt2 = parseInt(rt)+parseInt(a);
			jQuery("#rt_1").text(rt);
			jQuery("#rt_2").text(rt2);
		}
		if(b != "0:0"){
			b =   b.split(":")
			jQuery("#rt_1").text(numb+':'+b[1]);
			jQuery("#rt_2").text(numb+':'+b[0]);
		}
		/* if(a != 0 && b == "0:0"){
	
		}else{
			jQuery("#rt_1").text('');
			jQuery("#rt_2").text('');
		} */
		jQuery("#save_rt").click();
	}
}

function setNm1(numb,elm){
	jQuery(".num_slide").removeClass('setNum');
	var n = jQuery(elm).text();
	n2 = numb+'_'+n;
	jQuery("#select_val").val(n2);
	jQuery(elm).addClass('setNum');
	jQuery("#rtnumber").val(numb);
	jQuery("#sess_rt").html('<option id="rt_0:0" value="0:0">Null</option><option id="rt_90:110" value="90:110">90:110</option><option id="rt_85:115" value="85:115">85:115</option><option id="rt_70:125" value="70:125">70:125</option><option id="rt_100:150" value="100:150">100:150</option><option id="rt_200:250" value="200:250">200:250</option><option id="rt_250:400" value="250:400">250:400</option>');
	jQuery("#rn_diff").html('<option value="0" id="rn_0">Null</option><option id="rn_1" value="1">1</option><option id="rn_2" value="2">2</option><option id="rn_3" value="3">3</option><option id="rn_4" value="4">4</option><option id="rn_5" value="5">5</option><option id="rn_6" value="6">6</option>');
	jQuery("#rt_1").text(numb+':115');
	jQuery("#rt_2").text(numb+':'+n);
	jQuery("#num_sess_rd").val(n+':115');
	jQuery("#save_rt").click();
}
function setNm2(numb,elm){
	jQuery(".num_slide").removeClass('setNum');
	var n = jQuery(elm).text();
	n2 = numb+'_'+n;
	jQuery("#select_val").val(n2);
	jQuery(elm).addClass('setNum');
	jQuery("#rtnumber").val(numb);
	jQuery("#sess_rt").html('<option id="rt_0:0" value="0:0">Null</option><option id="rt_90:110" value="90:110">90:110</option><option id="rt_85:115" value="85:115">85:115</option><option id="rt_70:125" value="70:125">70:125</option><option id="rt_100:150" value="100:150">100:150</option><option id="rt_200:250" value="200:250">200:250</option><option id="rt_250:400" value="250:400">250:400</option>');
	jQuery("#rn_diff").html('<option value="0" id="rn_0">Null</option><option id="rn_1" value="1">1</option><option id="rn_2" value="2">2</option><option id="rn_3" value="3">3</option><option id="rn_4" value="4">4</option><option id="rn_5" value="5">5</option><option id="rn_6" value="6">6</option>');
	jQuery("#rt_1").text(numb+':110');
	jQuery("#rt_2").text(numb+':'+n);
	jQuery("#num_sess_rd").val(n+':110');
	jQuery("#save_rt").click();
}

function isActivesess(){
	var id = jQuery("#sess_id").val();
	var rd = jQuery("#suspend").val();
	var act;
	if(rd == "Suspend"){
		is = 1;
		act = 2;
	}else{
		is = 0;
		act = 3;
	}
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"updateSessisactive",
		data:{sess_id:id,_token:token,is:is,act:act}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response.msg == 0){
			jQuery("#suspend").val('Suspend');
			jQuery("#act").val('0');
			jQuery(".sess_stat_h b").html('Session Running......');
		}else{
			jQuery("#suspend").val('Unsuspend');
			jQuery("#act").val('1');
			jQuery(".sess_stat_h b").html('Session Waiting......');
		}
	});
} 
function changeStatus(elm,sessid){
	var rd = jQuery(elm).val();
	var token = jQuery("input[name=_token]").val();
	var request = jQuery.ajax({
		type:"post",
		url:"updateSessisstatus",
		data:{sess_id:sessid,_token:token,is:rd}
	});
	request.done(function (response){
		if(response.msg == 1){
			location.reload();
		}else{
			return false;
		}
	});
}
function showPop(elm,dcamt,isAct,act,st,rn,rd,rt){
	jQuery(".sess_id").val(elm);
	jQuery("#amount").val(dcamt);
	jQuery("#isAct").val(isAct);
	jQuery("#actionsess").val(act);
	if(act == 1){
		jQuery("#runsess").show();
		jQuery("#declare").hide();
		jQuery("#undeclare").hide();
	}else if(act == 2){
		jQuery("#declare").show();
		jQuery("#undeclare").hide();
		jQuery("#runsess").hide();
	}else if(act == 4){
		jQuery("#declare").hide();
		jQuery("#undeclare").show();
		jQuery("#runsess").hide();
	}
	jQuery("#st").val(st);
	jQuery("#rn").val(rn);
	jQuery("#rd").val(rd);
	jQuery("#rt").val(rt);
	jQuery('#slide').popup({
	  outline: true, // optional
	  focusdelay: 400, // optional
	  vertical: 'top' //optional
	});
}
function setStat(elm){
	var id = jQuery("#sess_id").val();
	var ac = jQuery(elm).val();
	var actionsess = jQuery("#actionsess").val();
	var stat;
	if(ac == "Declare"){
		stat =4;
		if(actionsess == 4){
			jQuery('#alrt_msg').show();
			jQuery('#alrt_msg').html('Already Declared');
			jQuery('#alrt_msg').delay(5000).slideUp(300);
			return false;
		}
		jQuery('.dec_bx').slideToggle();
	}else if(ac == "Undeclare"){
		if(confirm("Are you sure you want to Undeclare this?")){
			var action = "setUndeclare";
			jQuery(".loading_img").show();
			var request = jQuery.ajax({
				type:"post",
				url:"http://fairsession.com/session-api/app.php",
				data:{sess_id:id,action:action}
			});
			request.done(function (response){
				jQuery(".loading_img").hide();
				if(response == 1){
					location.reload();
				}else{
					return false;
				}
			});
		}else{
			return false;
		}
	}
	/* var token = jQuery("input[name=_token]").val();
	if(stat == 2 || stat == 1){
		jQuery(".loading_img").show();
		var request = jQuery.ajax({
			type:"post",
			url:"updateSessisstatus",
			data:{sess_id:id,_token:token,is:stat}
		});
		request.done(function (response){
			jQuery(".loading_img").hide();
			if(response.msg == 1){
				jQuery(".slide_close").click();
				location.reload();
			}else{
				return false;
			}
		});
	}else{
		jQuery(".loading_img").show();
		var request = jQuery.ajax({
			type:"post",
			url:"updateSessisstatus",
			data:{sess_id:id,_token:token,is:stat}
		});
		request.done(function (response){
			jQuery(".loading_img").hide();
			if(response.msg == 1){
				return true;
			}else{
				return false;
			}
		});
	} */
}

function changeDelareRate(){
	if(confirm("Are you sure you want to Declare this?")){
		var sessid = jQuery("#sess_id").val();
		var amt = jQuery("#amount").val();
		var action = "setDeclare";
		jQuery(".loading_img").show();
		var request = jQuery.ajax({
			type:"post",
			url:"http://fairsession.com/session-api/app.php",
			data:{sess_id:sessid,action:action,amt:amt}
		});
		request.done(function (response){
			jQuery(".loading_img").hide();
			if(response == 1){
				location.reload();
			}else{
				return false;
			}
		});
	}else{
		return false;
	}
}
function showPopRs(ths,elm,dcamt,action,isAct,st,rn,rd,rt,ovr,sv){
	jQuery("#cover").addClass('overlayDisplay');
	jQuery("#sess_id").val(elm);
	jQuery("#act").val(isAct);
	jQuery("#sess_desc").html(ovr);
	jQuery(".loading_img").hide();
	
	if(act == 3){
		jQuery(ths).removeClass('active_bg_open');
			jQuery('#alrt_msg').show();
			jQuery('#alrt_msg').html('!Session Is Declared Cannot be Declared First Undeclare');
			jQuery('#alrt_msg').delay(5000).slideUp(300);
		return false;
	}else{
		jQuery(ths).addClass('active_bg_open');
		if(isAct == "0"){
			jQuery(".sess_stat_h b").html('Session Running......')
		}
		if(isAct == "0"){
			jQuery("#suspend").val('Suspend');
		}
		jQuery("#"+sv).addClass('setNum'); 
		jQuery('#rtnumber').val(rn);
		jQuery("#rn_"+rd+"").attr("selected",'selected');
		jQuery("#rt_"+rt+"").attr("selected",'selected');
		var crate = st.split(':');
		jQuery(".cr_sess").show();
		if(rt == "0:0"){
			jQuery("#rt_1").text(crate[0]);
			jQuery("#rt_2").text(crate[1]); 
		}else{
			jQuery("#rt_1").text(rn+":"+crate[0]);
			jQuery("#rt_2").text(rn+":"+crate[1]); 
		}
		jQuery('#active_bg').popup({
		onopen: function() {
			var swiper = new Swiper('.swiper-container', {
				nextButton: '.swiper-button-next',
				prevButton: '.swiper-button-prev',
				slidesPerView: 6,
				cube: {
				  slideShadows: true,
				  shadow: true,
				  shadowOffset: 20,
				  shadowScale: 0.94 
				},
				
			});
			var sliderate = parseInt(rn) * 3.9 / 10;
			
			 swiper.slideTo(sliderate , 1, false);
			/*  var sess_id = jQuery("#sess_id").val();
			   if(sess_id != ""){
				    var token = jQuery("input[name=_token]").val();
					var request = jQuery.ajax({
						type:"post",
						url:"getsesMtx",
						data:{sess_id:sess_id,_token:token}
					});
					request.done(function (response){
						jQuery(".loading_img").hide();
						jQuery(".matrix_slider").show();
						jQuery('#ses_mtrx').html(response);
					});
			   }else{
				   return true;
			   } */
		  },
		  outline: true, // optional
		  focusdelay: 400, // optional
		  vertical: 'top', //optional
		   backgroundactive:true
		});
	} 
}




/*
Test Run Session
*/
function testshowPopRs(ths,elm,dcamt,action,isAct,st,rn,rd,rt,ovr,sv){
	jQuery("#cover").addClass('overlayDisplay');
	jQuery("#sess_id").val(elm);
	jQuery("#act").val(isAct);
	jQuery("#sess_desc").html(ovr);
	jQuery(".loading_img").hide();
	
	if(act == 3){
		jQuery(ths).removeClass('active_bg_open');
			jQuery('#alrt_msg').show();
			jQuery('#alrt_msg').html('!Session Is Declared Cannot be Declared First Undeclare');
			jQuery('#alrt_msg').delay(5000).slideUp(300);
		return false;
	}else{
		jQuery(ths).addClass('active_bg_open');
		if(isAct == "0"){
			jQuery(".sess_stat_h b").html('Session Running......')
		}
		if(isAct == "0"){
			jQuery("#suspend").val('Suspend');
		}
		jQuery("#"+sv).addClass('setNum'); 
		jQuery('#rtnumber').val(rn);
		jQuery("#rn_"+rd+"").attr("selected",'selected');
		jQuery("#rt_"+rt+"").attr("selected",'selected');
		var crate = st.split(':');
		jQuery(".cr_sess").show();
		if(rt == "0:0"){
			jQuery("#rt_1").text(crate[0]);
			jQuery("#rt_2").text(crate[1]); 
		}else{
			jQuery("#rt_1").text(rn+":"+crate[0]);
			jQuery("#rt_2").text(rn+":"+crate[1]); 
		}
		jQuery('#active_bg').popup({
		onopen: function() {
			var swiper = new Swiper('.swiper-container', {
				nextButton: '.swiper-button-next',
				prevButton: '.swiper-button-prev',
				slidesPerView: 6,
				cube: {
				  slideShadows: true,
				  shadow: true,
				  shadowOffset: 20,
				  shadowScale: 0.94 
				}
			}); 
			  jQuery(function() {
				jQuery( "#runstabs" ).tabs();
			  });
			
			/*  var sess_id = jQuery("#sess_id").val();
			   if(sess_id != ""){
				    var token = jQuery("input[name=_token]").val();
					var request = jQuery.ajax({
						type:"post",
						url:"getsesMtx",
						data:{sess_id:sess_id,_token:token}
					});
					request.done(function (response){
						jQuery(".loading_img").hide();
						jQuery(".matrix_slider").show();
						jQuery('#ses_mtrx').html(response);
					});
			   }else{
				   return true;
			   } */
		  },
		  outline: true, // optional
		  focusdelay: 400, // optional
		  vertical: 'top', //optional
		   backgroundactive:true
		});
	} 
}
/* */
function runSess(ths){
	var sess_id = jQuery(".sess_id").val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"updatesessStat",
		data:{sess_id:sess_id,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		location.reload();
	});
	/* var isAct = jQuery("#isAct").val();
	jQuery("#act").val(isAct);
	if(isAct == "0"){
		jQuery(".sess_stat_h b").html('Session Running......')
	}
	if(isAct == "0"){
		jQuery("#suspend").val('Suspend');
	}
	var act = jQuery("#actionsess").val(); */
	/* if(act == 1){
		jQuery(ths).removeClass('active_bg_open');
		alert("!Session Is Inactive First Active To Run");
		return false;
	}else */ /*if(act == 3){*/
		/* jQuery(ths).removeClass('active_bg_open');
			jQuery('#alrt_msg').show();
			jQuery('#alrt_msg').html('!Session Is Declared Cannot be Declared First Undeclare');
			jQuery('#alrt_msg').delay(5000).slideUp(300);
		return false;
	}else{
		jQuery("#cover").addClass('overlayDisplay');
		var rn = jQuery("#rn").val();
		var rd = jQuery("#rd").val();
		var rt = jQuery("#rt").val();
		var st = jQuery("#st").val();
		var crate = st.split(':');
		jQuery(".cr_sess").show();
		jQuery("#rt_1").text(crate[0]);
		jQuery("#rt_2").text(crate[1]);
		jQuery("#"+rn).addClass('setNum'); 
		jQuery('#rtnumber').val(rn);
		jQuery("#rn_"+rd+"").attr("selected",'selected');
		jQuery("#rt_"+rt+"").attr("selected",'selected');
		jQuery(".slide_close").click();
		jQuery('#active_bg').popup({
		onopen: function() {
			var swiper = new Swiper('.swiper-container', {
				nextButton: '.swiper-button-next',
				prevButton: '.swiper-button-prev',
				slidesPerView: 6,
				cube: {
				  slideShadows: true,
				  shadow: true,
				  shadowOffset: 20,
				  shadowScale: 0.94
				}
			}); 
		  },
		  outline: true, // optional
		  focusdelay: 400, // optional
		  vertical: 'top', //optional
		   backgroundactive:true
		}); 
	}*/
}
function setAdmin(uid){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"setAdmin",
		data:{uid:uid,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response.msg == 1){
			location.reload();
		}else{
			return false;
		} 
	});
}
function removeAdmin(uid){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"removeAdmin",
		data:{uid:uid,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response.msg == 1){
			location.reload();
		}else{
			return false;
		}
	});
}

function suspendUser(uid){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"suspendUser",
		data:{uid:uid,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response.msg == 1){
			location.reload();
		}else{
			return false;
		}
	});
}

function unsuspendUser(uid){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"unsuspendUser",
		data:{uid:uid,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response.msg == 1){
			location.reload();
		}else{
			return false;
		}
	});
}

function saveSessRate(){
	var token = jQuery("input[name=_token]").val();
	var sess_id = jQuery("#sess_id").val()
	var rn_diff = jQuery("#rn_diff").val();
	var sess_rt = jQuery("#sess_rt").val();
	var num_sess_rd = jQuery("#num_sess_rd").val();
	var rt  = jQuery("#rt_1").text();	
	var select_val = jQuery("#select_val").val();
	var rt2 = jQuery("#rt_2").text();	
	var runs = jQuery("#rtnumber").val();
	var rate;
	if(rn_diff != "0" && sess_rt == '0:0' && num_sess_rd == ""){
		rate = rt+':'+rt2;
	}
	if(sess_rt != "0:0" && rn_diff == "0" && num_sess_rd == "") {
		rt = rt.split(':');
		rt2 = rt2.split(':');
		rate = rt2[1]+':'+rt[1];
	} 
	if(num_sess_rd != ""){
		rate = num_sess_rd;
		sess_rt = num_sess_rd;
	}
	if(rt == '' && rt2 == ''){ 
		return true;
	}else{
		var request = jQuery.ajax({
		type:"post",
		url:"setSessRate",
		data:{rate:rate,runs:runs,run_diff:rn_diff,sess_rate:sess_rt,_token:token,sess_id:sess_id,select_val:select_val}
		});
		request.done(function (response){
			jQuery(".loading_img").hide();
			if(response.msg == 1){
				return true;
			}else{
				return false;
			}
		});
	}
}
function changeCom1(elm){
	var uid = jQuery(elm).val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"changeCom1",
		data:{uid:uid,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.com_user2').html(response);
		jQuery('.com_user3').html(response);
	});
}
function changeCom2(elm){
	var uid = jQuery(elm).val();
	var uid2 = jQuery('.com_user1').val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"changeCom1",
		data:{uid:uid,uid2:uid2,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.com_user3').html(response);
	});
}
function changePti1(elm){
	var uid = jQuery(elm).val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"changeCom1",
		data:{uid:uid,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.pati_user2').html(response);
		jQuery('.pati_user3').html(response);
	});
}
function changePti2(elm){
	var uid = jQuery(elm).val();
	var uid2 = jQuery('.pati_user1').val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"changeCom1",
		data:{uid:uid,uid2:uid2,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.pati_user3').html(response);
	});
}

function changeUCom1(elm,luid){
	var uid = jQuery(elm).val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"../changeUCom1",
		data:{uid:uid,_token:token,luid:luid}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.com_user2').html(response);
		jQuery('.com_user3').html(response);
	});
}
function changeUCom2(elm,luid){
	var uid = jQuery(elm).val();
	var uid2 = jQuery('.com_user1').val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"../changeUCom1",
		data:{uid:uid,uid2:uid2,_token:token,luid:luid}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.com_user3').html(response);
	});
}
function changeUPti1(elm,luid){
	var uid = jQuery(elm).val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"../changeUCom1",
		data:{uid:uid,_token:token,luid:luid}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.pati_user2').html(response);
		jQuery('.pati_user3').html(response);
	});
}
function changeUPti2(elm,luid){
	var uid = jQuery(elm).val();
	var uid2 = jQuery('.pati_user1').val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"../changeUCom1",
		data:{uid:uid,uid2:uid2,_token:token,luid:luid}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.pati_user3').html(response);
	});
}
function cls_popup(){
	var isact = jQuery("#act").val();
	if(isact == 0){
		jQuery('.alrt_msg').show();
		jQuery('.alrt_msg').html('First Suspend Only Then Close');
		jQuery('#alrt_msg').delay(5000).slideUp(300);
	}else{
		jQuery('.rn_sess_btn').click();
		location.reload();
	}
	return false;
}
function setRate(){
	var cr 		= jQuery("#ucredit").val();
	var amt 	= jQuery("#urate").val();
	if(cr != '' && amt != ''){
		var total 	= parseInt(cr)*parseInt(amt);
		jQuery("#uamount").replaceWith('<input type="text" name="amount" id="uamount" class="form-control" value="'+total+'" disabled/>');
		jQuery("#amount").val(total);
	}
}

function showUsers(elm){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"showUsers",
		data:{uid:elm,_token:token}
	});
	request.done(function (response){
		
		jQuery(".loading_img").hide();
		jQuery('.ad_us').slideDown();
		jQuery('.ad_us h2').html(response.adminName+' users');
		jQuery('#ad_users').html(response.users);
	});
}
function showaUsers(elm){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"showaUsers", 
		data:{uid:elm,_token:token}
	});
	request.done(function (response){
		
		jQuery(".loading_img").hide();
		jQuery('.ad_us').slideDown();
		jQuery('.ad_us h2').html(response.adminName+' users');
		jQuery('#ad_users').html(response.users);
	});
}
function showlUsers(elm){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"showlUsers", 
		data:{uid:elm,_token:token}
	});
	request.done(function (response){
		
		jQuery(".loading_img").hide();
		jQuery('.ad_us').slideDown();
		jQuery('.ad_us h2').html(response.adminName+' users');
		jQuery('#ad_users').html(response.users);
	});
}
function getSessRes(elm){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"getSessRes",
		data:{sess_id:elm,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.ad_us').slideDown();
		jQuery('.ad_us h2').html(response.sess_desc);
		jQuery('.ad_us h3').html('Runs Declared :'+response.dc_runs);
		jQuery('#ad_users').html(response.sessions);
	});
}
function getUSessRes(elm,uid){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"http://fairsession.com/getUSessRes",
		data:{sess_id:elm,_token:token,uid:uid}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.ad_us').slideDown();
		jQuery('.ad_us h2').html(response.sess_desc);
		jQuery('.ad_us h3').html('Runs Declared :'+response.dc_runs);
		jQuery('#ad_users').html(response.sessions);
	});
}

function getDSessRes(){
	var token = jQuery("input[name=_token]").val();
	var f_d   = jQuery('#from_Date').val();
	var t_d   = jQuery('#to_Date').val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({ 
		type:"post",
		url:"getDSessRes",
		data:{f_d:f_d,t_d:t_d,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.sh_ss').slideDown();
		jQuery('#show_sessions').html(response.sessions);
	});
}

function showSessRt(elm){
	var sess_id = jQuery(elm).val();	if(sess_id == ""){		return false;	}
	var token = jQuery("input[name=_token]").val();
	jQuery("#sess_id").val(sess_id);
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"getsesMtx",
		data:{sess_id:sess_id,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery(".matrix_slider").show();
		jQuery('#ses_mtrx').html(response.html);
		jQuery('#ses_records').html(response.html2);
		jQuery(".st_rt").show();
		jQuery(".st_rt").text('Current Sessin Rate : '+response.sess_rate);
		/* var rowpos = $('#ses_mtrx tr:last').position();
		jQuery('.table').scrollTop(rowpos.top); */
		 
	});
}

function getSessUsers(){
	var keyword = $("#esess_user").val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"getAllUsers",
		data:{keyword:keyword,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		$('#users_list').show();
		$('#users_list').html(response);
	});
}
function set_item(item,id) {
	// change input value
	jQuery('#esess_user').val(item);
	jQuery('#usr_id').val(id);
	// hide proposition list
	jQuery('#users_list').hide();
}
/* function set_rt(item) {
	// change input value
	jQuery('#s_rt').val(item);
	// hide proposition list
	jQuery('#yrates_list').hide();
} */
/* function getYrates(){
	var arr = ['90:115','80:115','70:125','100:150','200:250','250:400'];
	var arrLength = arr.length;
	var res = '';
	for(var i=0;i<arrLength;i++){
		res += '<li onclick="set_rt(\''+arr[i]+'\')">'+arr[i]+'</li>';
	}
	jQuery('#yrates_list').show();
	jQuery('#yrates_list').html(res);
	
} */


function checkSessEntrySub(){
	var sess = jQuery("#sess").val();
	var sess_user = jQuery("#sess_user").val();
	var runs = jQuery("#runs").val();
	var amount = jQuery("#amount").val();
	var rate = jQuery("#rate").val();
	var y_n = jQuery("#y_n").val();
	var sess_id = jQuery("#sess_id").val();
	var usr_id = jQuery("#usr_id").val();
	if(sess == "0"){
		jQuery("#alrt_msg").show();
		jQuery("#alrt_msg").html('Please Select Session');
		jQuery('#alrt_msg').delay(5000).slideUp(300);
		return false;
	}else if(sess_user == ""){
		jQuery("#alrt_msg").show();
		jQuery("#alrt_msg").html('Please Enter User');
		jQuery('#alrt_msg').delay(5000).slideUp(300);
		return false;
	}else if(runs == ""){
		jQuery("#alrt_msg").show();
		jQuery("#alrt_msg").html('Please Enter Run');
		jQuery('#alrt_msg').delay(5000).slideUp(300);
		return false;
	}else if(amount == ""){
		jQuery("#alrt_msg").show();
		jQuery("#alrt_msg").html('Please Enter Amount');
		jQuery('#alrt_msg').delay(5000).slideUp(300);
		return false;
	}else if(rate == ""){
		jQuery("#alrt_msg").show();
		jQuery("#alrt_msg").html('Please Enter Rate');
		jQuery('#alrt_msg').delay(5000).slideUp(300);
		return false;
	}else{
		var token = jQuery("input[name=_token]").val();
		jQuery(".loading_img").show();
		var request = jQuery.ajax({
			type:"post",
			url:"add-sess-entry",
			data:{sess_user:sess_user,runs:runs,amount:amount,rate:rate,y_n:y_n,sess_id:sess_id,usr_id:usr_id,_token:token}
		});
		request.done(function (response){
			if(response == 1){
				jQuery(".loading_img").hide();
				jQuery("#sess_user").val('');
				jQuery("#runs").val('');
				jQuery("#amount").val('');
				jQuery("#esess_user").val('');
			}else{
				jQuery(".loading_img").hide();
				alert('Bet Rejected Try within limits');
			}
		});
	}
}

function showDusers(){
	var keyword = $("#esess_user").val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"getAlldusers",
		data:{_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		$('#dusers_list').show();
		$('#dusers_list').html(response);
	});
}
function set_uitem(item,id) {
	// change input value
	jQuery('#dusers').val(item);
	jQuery('#uusr_id').val(id);
	jQuery('#uusr_name').val(item);
	jQuery('#uhd_id').val('');
	// hide proposition list
	jQuery('#dusers_list').hide();
}
function showCusers(){
	var keyword = $("#esess_user").val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"getAllcusers",
		data:{_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		$('#cusers_list').show();
		$('#cusers_list').html(response);
	});
}
function set_citem(item,id) {
	// change input value
	jQuery('#cusers').val(item);
	jQuery('#cusr_id').val(id);
	jQuery('#cusr_name').val(item);
	jQuery('#chd_id').val('');
	// hide proposition list
	jQuery('#cusers_list').hide();
}

function set_Huitem(item,id) {
	// change input value
	jQuery('#dusers').val(item);
	jQuery('#uhd_id').val(id);
	jQuery('#uusr_name').val(item);
	jQuery('#uusr_id').val('');
	// hide proposition list
	jQuery('#dusers_list').hide();
}
function set_Hcitem(item,id) {
	// change input value
	jQuery('#cusers').val(item);
	jQuery('#chd_id').val(id);
	jQuery('#cusr_name').val(item);
	jQuery('#cusr_id').val('');
	// hide proposition list
	jQuery('#cusers_list').hide();
}

function setLedgerVal(){
	var ldate  = jQuery("#ldate").val();
	var dusers = jQuery("#dusers").val();
	var cusers = jQuery("#cusers").val();
	var amount = jQuery("#amount").val();
	var desc   = jQuery("#desc").val();
	if(ldate == ""){
		alert("Please Enter Date");
		return false;
	}else if(dusers == ""){
		alert("Please Debit User");
		return false;
	}else if(cusers == ""){
		alert("Please Credit User");
		return false;
	}else if(amount == ""){
		alert("Please Enter Amount");
		return false;
	}else if(desc == ""){
		alert("Please Enter Description");
		return false;
	}else{
		return true;
	}
}
function getAusers(elm){
	var id = $(elm).val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"showAlsers",
		data:{_token:token,id:id}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		$('#users').html(response);
	});
}
function getUsersSessRes(){
	var uid 	= jQuery('#users').val();
	var adusers = jQuery('#adusers').val();
	var token = jQuery("input[name=_token]").val();
	var f_d   = jQuery('#from_Date').val();
	var t_d   = jQuery('#to_Date').val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"http://fairsession.com/getUsersSessRes",
		data:{f_d:f_d,t_d:t_d,_token:token,uid:uid,adusers:adusers}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.sh_ss').slideDown();
		jQuery('#show_sessions').html(response.sessions);
	});
}

function getUsersSwsRes(){
	var sess_id 	= jQuery('#sess_id').val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"http://fairsession.com/getUsersSwsRes",
		data:{_token:token,sess_id:sess_id}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery(".ad_us").hide();
		jQuery(".ad_us").hide();
		jQuery('.sh_ss').slideDown();
		jQuery('#nt_lp').text(response.totalAmout);
		jQuery('#show_sessions').html(response.sessions);
	});
}

function getUwSessRes(elm,uid){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"getUwSessRes",
		data:{sess_id:elm,uid:uid,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.ad_us').slideDown();
		jQuery('.ad_us h2').html(response.sess_desc);
		jQuery('.ad_us h3').html('Runs Declared :'+response.dc_runs);
		jQuery('#ad_users').html(response.sessions);
	});
}

function getSingleUSessRes(elm,uid){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"getUwSessRes",
		data:{sess_id:elm,uid:uid,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery( "#single_ad_us" ).dialog();
		jQuery('#single_ad_us h2').html(response.sess_desc);
		jQuery('#single_ad_us h3').html('Runs Declared :'+response.dc_runs);
		jQuery('#single_ad_users').html(response.sessions);
		
	});
}

function getUwSessRes(elm,uid){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"getUwSessRes",
		data:{sess_id:elm,uid:uid,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.ad_us').slideDown();
		jQuery('#ad_users').html(response.sessions);
	});
}

function getUserSessRes(){
	var uid = jQuery('#users').val();
	var token = jQuery("input[name=_token]").val();
	var adusers = jQuery('#adusers').val();
	/* var f_d   = jQuery('#from_Date').val();
	var t_d   = jQuery('#to_Date').val(); */
	/* if(uid == "0" || uid == " "){
		alert("Please Select User");
		return false;
	} *//* else if(f_d == ""){
		alert("Please Select From Date");
		return false;
	}else if(t_d == ""){
		alert("Please Select End Date");
		return false;
	} */
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"http://fairsession.com/getUserSessRes",
		data:{/* f_d:f_d,t_d:t_d, */_token:token,uid:uid,adusers:adusers}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.ad_us').slideDown();
		jQuery('#ad_users').html(response.sessions);
	});
}
     
function showCoad(elm){
	var ut = jQuery(elm).val();
	if(ut == "2"){
		jQuery(".coad-ad").show();
	}else{
		jQuery(".coad-ad").hide();
	}
}

function getAllMtch(){
	var request = jQuery.ajax({
		type:"post",
		url:"http://fairsession.com/session-api/app.php",
		data:{action:'getALlMatches'}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery(".auto-rates-content").html(response.res);
	});
}
function getRt(elm,tm){
	var ur = "http://livepricing.sportingindex.com/LivePricing.svc/jsonp/GetLivePricesByMeeting?meetingKey=" + elm;
	var request = jQuery.ajax({
		type:"post",
		url:"http://fairsession.com/session-api/app.php",
		data:{action:'getALlRates',url:ur,tm:tm,elm:elm}
	});
	request.done(function (response){
		jQuery(".auto-rates-content").html(response); 
		jQuery("#auto_rt").val(elm); 
	});
}

function getAllAdminuserRes(sid,uid){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"getAllusersSessRes",
		data:{uid:uid,_token:token,sid:sid}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery('.ad_us').slideDown();
		jQuery('.ad_us h2').html(response.sess_desc);
		jQuery('.ad_us h3').html('Runs Declared :'+response.dc_runs);
		jQuery('#ad_users').html(response.sessions);
	});
}
function isNumber(n) {
  var nm = jQuery(n).val();
  if(isNaN(parseFloat(nm))){
  	alert("Please Enter Numeric Value!");
  	jQuery(n).val(' ');
  	return false;
  }
}
function deletesessRes(elm){
	if(confirm("Are you sure you want to Undeclare this?")){
		var token = jQuery("input[name=_token]").val();
		jQuery(".loading_img").show();
		var request = jQuery.ajax({
			type:"post",
			url:"deleteSessresData",
			data:{_token:token,sid:elm}
		});
		request.done(function (response){
			alert("Record Successfully Deleted");
		});
	}else{
		return false;
	}
}

/*Auto Rates Popup Starts here*/


function showautoPopRs(ths,elm){
	jQuery("#cover").addClass('overlayDisplay');
	jQuery("#sess_id").val(elm);
	var act = jQuery("#act").val();
	jQuery(ths).addClass('active_bg_open');
	jQuery(".loading_img").show();
	jQuery('#active_bg').popup({
	onopen: function() {
	jQuery("#auto_rt").val("");
		var request = jQuery.ajax({
			type:"post",
			url:"http://fairsession.com/session-api/app.php",
			data:{action:'getALlMatches'}
		});
		request.done(function (response){
			jQuery(".loading_img").hide();
			jQuery(".auto-rates-content").html(response.res);
		});
		},
	  outline: true, // optional
	  focusdelay: 400, // optional
	  vertical: 'top', //optional
	   backgroundactive:true
	});
	jQuery( "#atabs" ).tabs();
}

function saveSessDiff(){
	var sid = jQuery("#sess_id").val();
	var start = [];
	var end = [];
	var run = [];
	for(var i = 1;i <= 14;i++){
		 start.push(jQuery("#start_"+i).val());
		 end.push(jQuery("#end_"+i).val());
		 run.push(jQuery("#rn_"+i).val());
	}
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"http://fairsession.com/session-api/app.php",
		data:{action:"saveSessDt",sid:sid,start:start,end:end,run:run}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery("#ausess_slide").show();
		jQuery('#active_bg').popup('hide');
		jQuery("#ausess_slide").width(150);
		jQuery( "#ausess_slide" ).dialog();
		/* jQuery('#slide').popup({
		  outline: true, // optional
		  focusdelay: 400, // optional
		  vertical: 'top' //optional 
		}); */
	});
}

function saveSessrt(){
	var sid = jQuery("#sess_id").val(); 
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"http://fairsession.com/session-api/app.php",
		data:{action:"setSessrate",sid:sid}
	});
	request.done(function (response){
		var request = jQuery.ajax({
			type:"post",
			url:"http://fairsession.com/session-api/newcron.php",
			});
			request.done(function (response){
				location.reload(true);
			});
		setTimeout(function(){
		jQuery(".loading_img").hide();
		jQuery(".ui-button").click();
		  location.reload(true);
		}, 2000);
		
	});
}

function updatesessStat(elm,sess_id){
	jQuery("#au_sess_id").val(sess_id);
	jQuery("#s_rte").text("Session Rate : "+elm); 
	jQuery('#slide').popup({
	  outline: true, // optional
	  focusdelay: 400, // optional
	  vertical: 'top' //optional
	});
}
function suspendSess(){
	var sid = jQuery("#au_sess_id").val();
	
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"http://fairsession.com/session-api/app.php",
		data:{action:"susspendSess",sid:sid}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery(".ui-button").click();
		location.reload();
	}); 
}

function getRtauto(elm,tm){
	var ur = "http://livepricing.sportingindex.com/LivePricing.svc/jsonp/GetLivePricesByMeeting?meetingKey=" + elm;
	var request = jQuery.ajax({
		type:"post",
		url:"http://fairsession.com/session-api/app.php",
		data:{action:'getALlautoRates',url:ur,tm:tm} 
	});
	request.done(function (response){
		//jQuery(".auto-rates-content").html(response); 
		jQuery("#auto_rt").val(elm); 
	});
}

function saveAutorate(buy,sell,current,ky,elm){
	var sess_id = jQuery("#sess_id").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"http://fairsession.com/session-api/app.php",
		data:{action:'saveAuto',buy:buy,sell:sell,current:current,sess_id:sess_id,ky:ky,elm:elm}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response == 1){
			var request = jQuery.ajax({
				type:"post",
				url:"http://fairsession.com/session-api/app.php",
				data:{action:'getSessDiff'}
			});
			request.done(function (response){
				jQuery(".auto-rates-content").html(response.res);
			});
			jQuery("#mktId").val(ky);
		}else{
			alert("Please Select a valid rate");
		}
	});
}

function susspendallSession(){
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"sussallSession",
		data:{_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		alert("All Sessions successfully susspended");
		location.reload(true);
	});
}

function setslideRate(sess_id,nm){
	/* var sess_id  = jQuery("#sess_id").val();
	if(sess_id == ""){
		alert("Please Select Session");
		return false;
	} */
	var token = jQuery("input[name=_token]").val();
	var rt  = jQuery("#rt_"+nm).val();
	if(rt == ""){
		alert("Please Enter New Rate");
		return false;
	}
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"postslideSessrt",
		data:{sess_id:sess_id,_token:token,rt:rt}
	});
	request.done(function (response){
	 jQuery(".loading_img").hide();
       if(response == 1){
			location.reload();
	   }else{
		   return false;
	   }
    }); 
}

/* Auto popup code ends here */

function chkValidate(elm){
	var mnlm  = jQuery("#min_bet").val(); 
	var mxlm  = jQuery("#max_bet").val();
	var token = jQuery("input[name=_token]").val();
	var rt  = jQuery("#rt").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"postchkbetLmt",
		data:{mnlm:mnlm,_token:token,mxlm:mxlm}
	});
	request.done(function (response){
	 jQuery(".loading_img").hide();
       if(response.msg == 1){
		   jQuery("#min_bet").removeClass("brdrClass");
		    jQuery("#max_bet").removeClass("brdrClass");
			 jQuery("#mxmsg").text("");
			 jQuery("#mnmsg").text("");
			jQuery("#lgform").submit();
	   }else if(response.msg == 2){
		   jQuery("#min_bet").addClass("brdrClass");
		   jQuery("#max_bet").removeClass("brdrClass");
		   jQuery("#mnmsg").text("Please Enter Min Amount Grater then "+ response.min);
		   jQuery("#mxmsg").text("");
	   }else{
		    jQuery("#max_bet").addClass("brdrClass");
			 jQuery("#min_bet").removeClass("brdrClass");
			 jQuery("#mxmsg").text("Please Enter Max Amount Less then "+ response.max);
			  jQuery("#mnmsg").text("");
	   }
    }); 
}
function chkeditValidate(elm){
	var mnlm  = jQuery("#min_bet").val(); 
	var mxlm  = jQuery("#max_bet").val();
	var token = jQuery("input[name=_token]").val();
	var rt  = jQuery("#rt").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"http://fairsession.com/postchkbetLmt",
		data:{mnlm:mnlm,_token:token,mxlm:mxlm}
	});
	request.done(function (response){
	 jQuery(".loading_img").hide();
       if(response.msg == 1){
		   jQuery("#min_bet").removeClass("brdrClass");
		    jQuery("#max_bet").removeClass("brdrClass");
			 jQuery("#mxmsg").text("");
			 jQuery("#mnmsg").text("");
			jQuery("#lgform").submit();
	   }else if(response.msg == 2){
		   jQuery("#min_bet").addClass("brdrClass");
		   jQuery("#max_bet").removeClass("brdrClass");
		   jQuery("#mnmsg").text("Please Enter Min Amount Grater then "+ response.min);
		   jQuery("#mxmsg").text("");
	   }else{
		    jQuery("#max_bet").addClass("brdrClass");
			 jQuery("#min_bet").removeClass("brdrClass");
			 jQuery("#mxmsg").text("Please Enter Max Amount Less then "+ response.max);
			  jQuery("#mnmsg").text("");
	   }
    }); 
}

function showMatchPop(elm,dcamt,isAct,act,st,rn,rd,rt,tm1,tm2){
	jQuery(".match_id").val(elm);
	jQuery("#amount").val(dcamt);
	jQuery("#isAct").val(isAct);
	jQuery("#actionsess").val(act);
	if(act == 1){
		jQuery("#runsess").show();
		jQuery("#declare").hide();
		jQuery("#undeclare").hide();
	}else if(act == 2){
		jQuery("#declare").show();
		jQuery("#undeclare").hide();
		jQuery("#runsess").hide();
	}else if(act == 4){
		jQuery("#declare").hide();
		jQuery("#undeclare").show();
		jQuery("#runsess").hide();
	}
	jQuery("#st").val(st);   
	jQuery("#rn").val(rn);
	jQuery("#rd").val(rd);
	jQuery("#rt").val(rt);
	jQuery("#tm1").val(tm1);
	jQuery("#tm2").val(tm2);
	jQuery('#slide').popup({
	  outline: true, // optional
	  focusdelay: 400, // optional
	  vertical: 'top' //optional
	});
}
/* */
function runMatch(ths){
	var match_id = jQuery(".match_id").val();
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"updatemtchStat",
		data:{match_id:match_id,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		location.reload();
	});
}
function showMatchPopRs(ths,elm,act,isAct,matchname,vl,t1,t2,st,rd,rt,rtype){
	jQuery("#cover").addClass('overlayDisplay');
	jQuery("#match_id").val(elm);
	jQuery("#act").val(isAct);
	jQuery("#sess_desc").html(matchname);
	jQuery(".loading_img").hide();
	jQuery("#m_numb_"+vl).addClass('setNum');
	jQuery("#mn_numb_"+rd).addClass('setNum1');
	jQuery("#run_diff").val(rd);
	if(rtype == 1){
		jQuery(".mn_rates").show();
		jQuery("#manualy").addClass('setMn');
	}else{
		jQuery(".mn_rates").hide();
		jQuery("#automatic").addClass('setMn');
	}
	/* if(act == 3){
		jQuery(ths).removeClass('active_bg_open');
			jQuery('#alrt_msg').show();
			jQuery('#alrt_msg').html('!Session Is Declared Cannot be Declared First Undeclare');
			jQuery('#alrt_msg').delay(5000).slideUp(300);
		return false;
	}else{ */
		jQuery(ths).addClass('active_bg_open');
		if(isAct == "0"){
			jQuery(".sess_stat_h b").html('Session Running......')
		}
		if(isAct == "0"){
			jQuery("#suspend").val('Suspend');
		}
		var token = jQuery("input[name=_token]").val();
		jQuery(".loading_img").show();
		var request = jQuery.ajax({
			type:"post",
			url:"getSuperbook",
			data:{match_id:elm,_token:token}
		});
		request.done(function (response){
			jQuery(".loading_img").hide();
			jQuery("#sbrt1").html(response.team1);
			jQuery("#sbrt2").html(response.team2);
		});
		jQuery("#rtnumber").val(rt);
		jQuery("#team1").text(t1);
		jQuery("#team2").text(t2);
		jQuery("#team1sb").text(t1);
		jQuery("#team2sb").text(t2);
		jQuery("#tm1val").val(t1);
		jQuery("#tm2val").val(t2);
		jQuery("#team1").attr('class',t1+' slide_open');
		jQuery("#team2").attr('class',t2 +' slide_open');
		jQuery("#rt_1").text(rt);
		jQuery("#rt_2").text(parseInt(rt)+parseInt(rd));
		jQuery("."+st).addClass('selecttm');
		
		jQuery("#seltem").val(st);
		
		jQuery('#active_bg').popup({
		onopen: function() {
			
		  },
		  outline: true, // optional
		  focusdelay: 400, // optional
		  vertical: 'top', //optional
		   backgroundactive:true
		});
	/* } */ 
}
function isActivematch(){
	var id = jQuery("#match_id").val();
	var rd = jQuery("#suspend").val();
/* 	alert(rd);
	return false; 
	var act;*/
	if(rd == "Suspend"){
		is = 1;
		var act = 2;
	}else{
		is = 0;
		var act = 3;
	}
	//alert(act);
	//return false;
	var token = jQuery("input[name=_token]").val();
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"updateMatchisactive",
		data:{match_id:id,_token:token,is:is,act:act}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response.msg == 0){
			jQuery("#suspend").val('Suspend');
			jQuery("#act").val('0');
			jQuery(".sess_stat_h b").html('Match Running......');
		}else{
			jQuery("#suspend").val('Unsuspend');
			jQuery("#act").val('1');
			jQuery(".sess_stat_h b").html('Match Waiting......');
		}
	});
} 
function setRunval(numb,elm){
	jQuery(".num_slide").removeClass('setNum');
	var n = jQuery(elm).text();
	var rd = jQuery("#run_diff").val();
	jQuery("#select_val").val(n);
	jQuery(elm).addClass('setNum');
	jQuery("#rtnumber").val(numb);
	jQuery("#save_rt").click();
	jQuery("#rt_1").text(numb);
	jQuery("#rt_2").text(parseInt(numb)+parseInt(rd));
}
function saveMatchRate(){
	var token = jQuery("input[name=_token]").val();
	var match_id = jQuery("#match_id").val();
	var rn_diff = jQuery("#run_diff").val();
	if(rn_diff == ""){
		rn_diff = "0";
	}
	/* var rn_diff = jQuery("#rn_diff").val();
	var sess_rt = jQuery("#sess_rt").val();
	var num_sess_rd = jQuery("#num_sess_rd").val();
	var rt  = jQuery("#rt_1").text();	
	var select_val = jQuery("#select_val").val();
	var rt2 = jQuery("#rt_2").text();	 */
	var select_val = jQuery("#select_val").val();
	var runs = jQuery("#rtnumber").val();
	var rate;
	var request = jQuery.ajax({
	type:"post",
	url:"setMatchRate",
	data:{runs:runs,rn_diff:rn_diff,_token:token,match_id:match_id,select_val:select_val}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response.msg == 1){
			return true;
		}else{
			return false;
		}
	});
}
function oldsetTm(elm,stv){
	var act = jQuery("#act").val();
	var tm1 = jQuery("#team1").text();
	var tm2 = jQuery("#team2").text();
	var selected_team = jQuery(elm).val();
	
	var byseleted = jQuery("#seltem").val();
	/* if(selected_team == tm1){
		var byseleted = tm2;
	}else if(selected_team == tm2){
		var byseleted = tm1;
	}else if(selected_team == "both"){
		var byseleted = tm2;
	} */
	if(act != 0){
		jQuery("#altmsg").text("You are changing favourite from "+byseleted+" to "+selected_team+" are you sure?");
		jQuery('#slide').popup({
		  outline: true, // optional
		  focusdelay: 400, // optional
		  vertical: 'top' //optional
		});
		jQuery("#ok").hide();
		jQuery("#continue").show();
		jQuery("#Cancel").show();
		jQuery("#tmval").val(selected_team);
		jQuery("#stv").val(stv);
		jQuery(elm).attr('checked', true);
		return false;
	}else{
		jQuery("#altmsg").text("Please Suspend And Check the Rates First");
		jQuery('#slide').popup({
		  outline: true, // optional
		  focusdelay: 400, // optional
		  vertical: 'top' //optional
		});
		jQuery("#continue").hide();
		jQuery("#Cancel").hide();
		jQuery("#ok").show();
		return false;
	}
	/* var token = jQuery("input[name=_token]").val();
	var match_id = jQuery("#match_id").val()

	var request = jQuery.ajax({
	type:"post",
	url:"setTeam",
	data:{selected_team:selected_team,stv:stv,_token:token,match_id:match_id}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response.msg == 1){
			return true;
		}else{
			return false;
		}
	}); */
}

/**/
function setbtTm(){
	var token = jQuery("input[name=_token]").val();
	var match_id = jQuery("#match_id").val();
	var selected_team  = jQuery("#tmval").val();
	var stv  = jQuery("#stv").val();
	jQuery(".slide_close").click();
	jQuery("#seltem").val(selected_team);
	var sttm = jQuery("#tmval").val();
	var request = jQuery.ajax({
	type:"post",
	url:"setTeam",
	data:{selected_team:selected_team,stv:stv,_token:token,match_id:match_id}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response.msg == 1){
			jQuery("#team1").removeClass("selecttm");
			jQuery("#team2").removeClass("selecttm");
			jQuery("#both").removeClass("selecttm");
			jQuery("."+sttm).addClass("selecttm");
			return true;  
		}else{
			return false;
		}
	});
}
function setTm(elm,stv){
	var act = jQuery("#act").val();
	var tm1 = jQuery("#team1").text();
	var tm2 = jQuery("#team2").text();
	var selected_team = jQuery(elm).text();
	
	
	
	
	var byseleted = jQuery("#seltem").val();
	/* if(selected_team == tm1){
		var byseleted = tm2;
	}else if(selected_team == tm2){
		var byseleted = tm1;
	}else if(selected_team == "both"){
		var byseleted = tm2;
	} */
	if(act != 0){
		jQuery("#altmsg").text("You are changing favourite from "+byseleted+" to "+selected_team+" are you sure?");
		jQuery('#slide').popup({
		  outline: true, // optional
		  focusdelay: 400, // optional
		  vertical: 'top' //optional
		});
		jQuery("#ok").hide();
		jQuery("#continue").show();
		jQuery("#Cancel").show();
		jQuery("#tmval").val(selected_team);
		jQuery("#stv").val(stv);
		jQuery(elm).attr('checked', true);
		return false;
	}else{
		jQuery("#altmsg").text("Please Suspend And Check the Rates First");
		jQuery('#slide').popup({
		  outline: true, // optional
		  focusdelay: 400, // optional
		  vertical: 'top' //optional
		});
		jQuery("#continue").hide();
		jQuery("#Cancel").hide();
		jQuery("#ok").show();
		return false;
	}
	/* var token = jQuery("input[name=_token]").val();
	var match_id = jQuery("#match_id").val()

	var request = jQuery.ajax({
	type:"post",
	url:"setTeam",
	data:{selected_team:selected_team,stv:stv,_token:token,match_id:match_id}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response.msg == 1){
			return true;
		}else{
			return false;
		}
	}); */
}
function continueRate(){
	var token = jQuery("input[name=_token]").val();
	var match_id = jQuery("#match_id").val();
	var selected_team  = jQuery("#tmval").val();
	var stv  = jQuery("#stv").val();
	jQuery(".slide_close").click();
	jQuery("#seltem").val(selected_team);
	var sttm = jQuery("#tmval").val();
	var request = jQuery.ajax({
	type:"post",
	url:"setTeam",
	data:{selected_team:selected_team,stv:stv,_token:token,match_id:match_id}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response.msg == 1){
			jQuery("#team1").removeClass("selecttm");
			jQuery("#team2").removeClass("selecttm");
			jQuery("#both").removeClass("selecttm");
			jQuery("."+sttm).addClass("selecttm");
			return true;  
		}else{
			return false;
		}
	});
}
function setMnrates(elm){
	jQuery(".mnrt").removeClass('setMn');
	var slval = jQuery(elm).text();
	if(slval == "Manualy"){
		jQuery('.mn_rates').show();
		jQuery(elm).addClass('setMn');
		var token = jQuery("input[name=_token]").val();
		var match_id = jQuery("#match_id").val()
		var rt = 1;
		var request = jQuery.ajax({
		type:"post",
		url:"setRtype",
		data:{rt:rt,_token:token,match_id:match_id}
		});
		request.done(function (response){
			jQuery(".loading_img").hide();
			if(response.msg == 1){
				return true;
			}else{
				return false;
			}
		});
	}else{
		jQuery(elm).addClass('setMn');
		jQuery('.mn_rates').hide();
		var token = jQuery("input[name=_token]").val();
		var match_id = jQuery("#match_id").val()
		var rt = 0;
		var request = jQuery.ajax({
		type:"post",
		url:"setRtype",
		data:{rt:rt,_token:token,match_id:match_id}
		});
		request.done(function (response){
			jQuery(".loading_img").hide();
			if(response.msg == 1){
				return true;
			}else{
				return false;
			}
		});
	}
}
function setmnRunval(numb,elm){
	jQuery(".num_slide").removeClass('setNum1');
	var token = jQuery("input[name=_token]").val();
	jQuery("#run_diff").val(numb);
	jQuery(elm).addClass('setNum1');
	var rt =jQuery("#rtnumber").val();
	jQuery("#rt_1").text(rt);
	jQuery("#rt_2").text(parseInt(rt)+parseInt(numb));
	jQuery("#save_rt").click();
}
function setmatchStat(elm){
	var id = jQuery("#match_id").val();
	var ac = jQuery(elm).val();
	var actionsess = jQuery("#actionsess").val();
	var stat;
	var tm1 = jQuery("#tm1").val();
	var tm2 = jQuery("#tm2").val();
	jQuery("#team1").val(tm1);
	jQuery("#team2").val(tm2);
	jQuery("#team1val").text(tm1);
	jQuery("#team2val").text(tm2);
	if(ac == "Declare"){
		stat =4;
		if(actionsess == 4){
			jQuery('#alrt_msg').show();
			jQuery('#alrt_msg').html('Already Declared');
			jQuery('#alrt_msg').delay(5000).slideUp(300);
			return false;
		}
		jQuery('.dec_bxm').slideToggle();
	}else if(ac == "Undeclare"){
		if(confirm("Are you sure you want to Undeclare this?")){
			var action = "setUndeclare";
			var token = jQuery("input[name=_token]").val();
			jQuery(".loading_img").show();
			var request = jQuery.ajax({
			type:"post",
			url:"setmatchUndeclare",
			data:{match_id:id,_token:token}
			});
			request.done(function (response){
				jQuery(".loading_img").hide();
				if(response.msg == 1){
					location.reload();
				}else{
					return false;
				}
			});
		}else{
			return false;
		}
	}
}
function setTmval(elm,tm){
	jQuery("#tm").val(tm);
	jQuery("#selected_val").val(jQuery(elm).val());
}
function setmatchDec(){
	var match_id = jQuery(".match_id").val();
	var selectedval = jQuery("#selected_val").val();
	var token = jQuery("input[name=_token]").val();
	var tm    = jQuery("#tm").val();
	var request = jQuery.ajax({
	type:"post",
	url:"setDeclarematch",
	data:{selectedval:selectedval,_token:token,match_id:match_id,tm:tm}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		if(response.msg == 1){
			location.reload();
		}else{
			return false;
		}
	});
}

function showMatchRt(elm){
	var match_id = jQuery(elm).val();
	if(match_id == ""){
		return false;
	}
	var token = jQuery("input[name=_token]").val();
	jQuery("#match_id").val(match_id);
	jQuery(".loading_img").show();
	var request = jQuery.ajax({
		type:"post",
		url:"getmatchRes",
		data:{match_id:match_id,_token:token}
	});
	request.done(function (response){
		jQuery(".loading_img").hide();
		jQuery(".matrix_slider").show();
		jQuery('#ses_mtrx').html(response.html);
		jQuery('#ses_records').html(response.html2);
		jQuery("#team1sb").text(response.team1);
		jQuery("#team2sb").text(response.team2);
		jQuery("#team1sb").text(response.team1);
		jQuery("#team1sb").text(response.team1);
		jQuery("#sbrt1 span").text(response.team1sum);
		jQuery("#sbrt2 span").text(response.team2sum);
		jQuery(".st_rt").show();
		jQuery(".st_rt").text('Current Sessin Rate : '+response.sess_rate);
		/* var rowpos = $('#ses_mtrx tr:last').position();
		jQuery('.table').scrollTop(rowpos.top); */
		 
	});
}

function deletematchRes(elm){
	if(confirm("Are you sure you want to Undeclare this?")){
		var token = jQuery("input[name=_token]").val();
		jQuery(".loading_img").show();
		var request = jQuery.ajax({
			type:"post",
			url:"deleteMatchresData",
			data:{_token:token,mid:elm}
		});
		request.done(function (response){
			alert("Record Successfully Deleted");
		});
	}else{
		return false;
	}
}