<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Auth;
use DB;
use Illuminate\Http\Request;
use App\User;use Validator;
use Illuminate\Support\Facades\Redirect;
use App\DetailUser;
use App\Ledgerview;
use App\Heads;
class UsersController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
		$user = Auth::User();
		if($user->user_type == 0){
		   Redirect::to('/dashboard')->send();
		}
		
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$user = Auth::User();
		if($user->user_type == 1){
			$users = User::leftJoin('ledbalance','users.id','=','ledbalance.uid')->where('users.id','!=',$user->id)->where('users.parent','0')->get(); 
		}else if($user->user_type == 2 && $user->co_ad == "1"){
			$users = User::leftJoin('ledbalance','users.id','=','ledbalance.uid')->where('users.parent',$user->id)->get();
		}else{
			$users = User::leftJoin('ledbalance','users.id','=','ledbalance.uid')->where('users.parent',$user->id)->where('users.user_type','0')->get();	
		}
		$title = "Manage Users";
        return view('users',array("users" => $users,"title" => $title,'loggedUser' => $user));
    }		
	public function addUser()
    {
		$title = "Add User";
		$loggeduser = Auth::User();
		$user = Auth::User();
		$balance = Ledgerview::where('uid',$loggeduser->id)->first();
		if($balance){
			$cr = $balance->balance;
		}else{
			$cr = "0";
		}
		
		if($loggeduser->user_type == 1){
			$allUsers = User::where('id','!=',$loggeduser->id)->get();
		}else{
			$allUsers = User::where('parent',$user->id)->get();
		}
        return view('add-user',array("title" => $title,'user' => $user,'allUsers' => $allUsers,'balance' => $cr));
	}
	public function postaddUser(Request $request) 
    {
		$title = "Add User";
		$loggeduser = Auth::User();
		$validator = $this->validator($request->all());
		$options = ['cost' => '12'];
		if($validator->fails()){
			return redirect::to('add-user')->withErrors($validator);
			}else{
				if( $request->input('user_type') == "2"){
						$coad = $request->input('coadmin');
						if($coad = "on"){
							$coad = "1";
						}else{
							$coad = "2";
						}
					}else{
						$coad = "0";
					}
				if($loggeduser->user_type == 1){
					$user = new User;
					$user->name	          		  = $request->input('name');
					$user->email	          	  = $request->input('email');
					$user->password 			  = password_hash($request->input('password'),PASSWORD_BCRYPT,$options);
					$user->show_pass 			  = $request->input('password');
					$user->mobile				  = $request->input('mobile');
					$user->comm_1 				  = $request->input('comm_1');
					$user->comm1_user 			  = $request->input('comm1_user');
					$user->comm_2 				  = $request->input('comm_2');
					$user->comm2_user 			  = $request->input('comm2_user');
					$user->limit 			  	= $request->input('limit');
					$user->comm_3 				  = $request->input('comm_3');
					$user->comm3_user 			  = $request->input('comm3_user');
					$user->patti_1 				  = $request->input('patti_1');
					$user->patti1_user 			  = $request->input('patti1_user');
					$user->patti_2 				  = $request->input('patti_2');
					$user->patti2_user 			  = $request->input('patti2_user');
					$user->patti_3 				  = $request->input('patti_3');
					$user->patti3_user 			  = $request->input('patti3_user');
					$user->user_type 			  = $request->input('user_type');
					$user->o_n 			  		  = $request->input('o_n');
					$user->commition 			  = $request->input('commition');
					$user->max_bet 			 	  = $request->input('max_bet');
					$user->min_bet 			  	  = $request->input('min_bet');
					$user->amount 			  	  	= $request->input('amount');
					$user->co_ad 			  	  	= $coad;
					$user->rate				  	  	= $request->input('rate');
					$user->parent_id			   = $loggeduser->id;
					$user->save();
				}else{
					
					$checkLimit = User::find($loggeduser->id);
					$limit = $checkLimit->limit;
					$allUsers 	=  User::where('parent',$loggeduser->id)->get();
					$allUsers	=  count($allUsers);
					$lastUser 	=  User::where('parent',$loggeduser->id)->orderBy('id', 'desc')->first();
					if($lastUser){
						$uid = $lastUser->userid+1;
					}else{
						$uid = $loggeduser->id.'001';
					}
					$userId = $loggeduser->id+1;
					if($limit > $allUsers){
						$user 						  = new User;
						$checkMxMinBet = $user->CheckMxminbet($loggeduser->id,$request->input('min_bet'),$request->input('max_bet'));
						if($checkMxMinBet){
							$user->name	          		  = $request->input('name');
							$user->userid	              = $uid;
							$user->parent	              = $loggeduser->id;
							$user->password 			  = password_hash($request->input('password'),PASSWORD_BCRYPT,$options);
							$user->show_pass 			  = $request->input('password');
							$user->mobile				  = $request->input('mobile');
							$user->comm_1 				  = $request->input('comm_1');
							$user->comm1_user 			  = $request->input('comm1_user');
							$user->comm_2 				  = $request->input('comm_2');
							$user->comm2_user 			  = $request->input('comm2_user');
							$user->comm_3 				  = $request->input('comm_3');
							$user->comm3_user 			  = $request->input('comm3_user');
							$user->patti_1 				  = $request->input('patti_1');
							$user->patti1_user 			  = $request->input('patti1_user');
							$user->patti_2 				  = $request->input('patti_2');
							$user->patti2_user 			  = $request->input('patti2_user');
							$user->patti_3 				  = $request->input('patti_3');
							$user->patti3_user 			  = $request->input('patti3_user');
							$user->o_n 			  		  = $request->input('o_n');
							$user->commition 			  = $request->input('commition');
							$user->max_bet 			 	  = $request->input('max_bet');
							$user->min_bet 			  = $request->input('min_bet');
							$user->amount 			  	  	= $request->input('amount');
							$user->rate				  	  	= $request->input('rate');
							if($loggeduser->co_ad == 1){
								$user->user_type 			  = $request->input('user_type');
								$user->co_ad 			  	  = $coad;
								$user->parent			   	  = $loggeduser->id;
								$user->email	          	  = $request->input('email');
							}
							$user->parent_id			   = $loggeduser->id;
							
							$user->save();
							
							\Session::flash('flash_message','User Succefully Added.');
						}else{
							\Session::flash('flash_message','Try max or min bet with in your limits.');
						}
						
					}else{
						\Session::flash('flash_message','You Do Not Add More Users.Your Limit Is Over.Please Contact Admin.');
					}
				}
				
				return redirect::to('users');
			}
	}
	public function updateUser($id)
    {
		$user = User::find($id);
		$title = "Update User";
		$loggeduser = Auth::User();
		$balance = Ledgerview::where('uid',$id)->first();
		if($balance){
			$cr = $balance->balance;
		}else{
			$cr = "0";
		}
		$selected   = "";
		if($loggeduser->user_type == 1){
			$allUsers = User::where('id','!=',$loggeduser->id)->get();
		}else{
			$allUsers = User::where('parent',$loggeduser->id)->where('id','!=',$id)->get();
		}
        return view('edit-user',array("user" => $user,"title" => $title,'loggeduser' => $loggeduser,'allUsers' => $allUsers,'selected' => $selected,'balance' => $cr));
    }
	public function postUpdateUser(Request $request)
    {
		$loggeduser = Auth::User();
		$id 			= $request->input('user_id');
		$user 			= User::find($id);
		$options = ['cost' => '12'];
		if($request->input('user_type') == "2"){
						if($request->input('coadmin') == "on"){
							$coad = "1";
						}else{
							$coad = "2";
						}
					}else{
						$coad = "0";
					}
		if($loggeduser->user_type == 1){
			$user->name	    = $request->input('name');
			$user->email 	= $request->input('email');
			$user->mobile 	= $request->input('mobile');
			$user->password 	= password_hash($request->input('password'),PASSWORD_BCRYPT,$options);
			$user->show_pass 			  = $request->input('password');
			$user->limit 	= $request->input('limit');
			$user->comm_1 				  = $request->input('comm_1');
			$user->comm1_user 			  = $request->input('comm1_user');
			$user->comm_2 				  = $request->input('comm_2');
			$user->comm2_user 			  = $request->input('comm2_user');
			$user->comm_3 				  = $request->input('comm_3');
			$user->comm3_user 			  = $request->input('comm3_user');
			$user->limit 			  	= $request->input('limit');
			$user->patti_1 				  = $request->input('patti_1');
			$user->patti1_user 			  = $request->input('patti1_user');
			$user->patti_2 				  = $request->input('patti_2');
			$user->patti2_user 			  = $request->input('patti2_user');
			$user->patti_3 				  = $request->input('patti_3');
			$user->patti3_user 			  = $request->input('patti3_user');
			$user->o_n 			  		  = $request->input('o_n');
			$user->commition 			  = $request->input('commition');
			$user->amount 			  	  	= $request->input('amount');
			$user->max_bet 			 	  = $request->input('max_bet');
			$user->min_bet 			  		= $request->input('min_bet');
			$user->rate				  	  	= $request->input('rate');
			$user->user_type 			  = $request->input('user_type');
			$user->co_ad 			  	  	= $coad;
			$user->save();
		}else{
			$usr = new User;
			$checkMxMinBet = $usr->CheckMxminbet($loggeduser->id,$request->input('min_bet'),$request->input('max_bet'));
				if($checkMxMinBet){
					$user->name	 			      = $request->input('name');
					$user->password 			  = password_hash($request->input('password'),PASSWORD_BCRYPT,$options);
					$user->show_pass 			  = $request->input('password');
					$user->mobile 				  = $request->input('mobile');
					$user->comm_1 				  = $request->input('comm_1');
					$user->comm1_user 			  = $request->input('comm1_user');
					$user->comm_2 				  = $request->input('comm_2');
					$user->comm2_user 			  = $request->input('comm2_user');
					$user->comm_3 				  = $request->input('comm_3');
					$user->comm3_user 			  = $request->input('comm3_user');
					$user->patti_1 				  = $request->input('patti_1');
					$user->patti1_user 			  = $request->input('patti1_user');
					$user->patti_2 				  = $request->input('patti_2');
					$user->patti2_user 			  = $request->input('patti2_user');
					$user->patti_3 				  = $request->input('patti_3');
					$user->patti3_user 			  = $request->input('patti3_user');
					$user->o_n 			  		  = $request->input('o_n');
					$user->commition 			  = $request->input('commition');
					$user->max_bet 			 	  = $request->input('max_bet');
					$user->min_bet 			 	  = $request->input('min_bet');
					$user->amount 			  	  	= $request->input('amount');
					$user->rate				  	  	= $request->input('rate');
					if($loggeduser->co_ad == 1){
									$user->user_type 			  = $request->input('user_type');
									$user->co_ad 			  	  = $coad;
									$user->parent			   	  = $loggeduser->id;
									$user->email	          	  = $request->input('email');
								}
					$user->save();
					\Session::flash('flash_message','User Succefully Updated'); 
				}else{
					\Session::flash('flash_message','Try max or min bet with in your limits.');
				}
			
			
		}
		 
		return redirect('users');
    }
	public function deleteUser($id)
    {
		$loggeduser = Auth::User();
		if($loggeduser->user_type == 1){
			$user = User::find($id);
			$user->delete();
			\Session::flash('flash_message','User Succefully Deleted'); 
		}else{
			\Session::flash('flash_message','You do not have permission'); 
		}
        return Redirect("users");
    }	
	protected function validator(array $data){
		$user = Auth::User();
		if($user->user_type == 1){
			return Validator::make($data, [
			'name' => 'required|max:255',
			'email'    => 'required|email',
			'password' => 'required|confirmed|min:6',
			'mobile'    => 'required|min:9'	,
			'limit'    => 'required'
			]);	
		}else{
			return Validator::make($data, [
			'name' => 'required|max:255',
			'password' => 'required|confirmed|min:6',
			'mobile'    => 'required|min:9'		]);	
		}
	}
	public function setAdmin(Request $request){
		$id = $request->uid;
		$user = User::find($id);
		$user->user_type = '2';
		$user->save();
		$result   = array("msg" => 1);
		\Session::flash('flash_message','User Succefully Set As Admin');
		return $result;
	}
	public function removeAdmin(Request $request){
		$id = $request->uid;
		$user = User::find($id);
		$user->user_type = '0';
		$user->save();
		$result   = array("msg" => 1);
		\Session::flash('flash_message','User Succefully Remove As Admin');
		return $result;
	}
	
	public function suspendUser(Request $request){
		$id = $request->uid;
		$user = User::find($id);
		$user->isActive = '1';
		$user->save();
		$result   = array("msg" => 1);
		\Session::flash('flash_message','User Succefully Suspended');
		return $result;
	}
	public function unsuspendUser(Request $request){
		$id = $request->uid;
		$user = User::find($id);
		$user->isActive = '0';
		$user->save();
		$result   = array("msg" => 1);
		\Session::flash('flash_message','User Succefully Unsuspended');
		return $result;
	}
	public function changeCom1(Request $request){
		$loggedUser = Auth::User();
		$id = $request->uid;
		if(isset($request->uid2)){
			$id2 = $request->uid2;
			if($loggedUser->user_type == 1){
				$users = User::where('id','!=',$loggedUser->id)->where('id','!=',$id)->where('id','!=',$id2)->get(); 
			}else{
				$users = User::where('parent',$loggedUser->id)->where('id','!=',$id)->where('id','!=',$id2)->get(); 
			}
			
			
			$html = '<option value="0">Please Select</option>';
			if(count($users) > 0){
				foreach($users as $user){
					$html .= '<option value='.$user->id.'>'.$user->name.'</option>';
				}
			}else{
				$html .= '<option value="0">No Records</option>';
			}
			
		}else{
			if($loggedUser->user_type == 1){
				$users = User::where('id','!=',$loggedUser->id)->where('id','!=',$id)->get(); 
			}else{
				$users = User::where('parent',$loggedUser->id)->where('id','!=',$id)->get(); 
			}
			
			$html = '<option value="0">Please Select</option>';
			foreach($users as $user){
				$html .= '<option value='.$user->id.'>'.$user->name.'</option>';
			}
		}
		
		
		return $html;
	}
	public function changeUCom1(Request $request){
		$loggedUser = Auth::User();
		$id = $request->uid;
		$luid = $request->luid;
		if(isset($request->uid2)){
			$id2 = $request->uid2;
			if($loggedUser->user_type == 1){
				$users = User::where('id','!=',$loggedUser->id)->where('id','!=',$id)->where('id','!=',$id2)->where('id','!=',$luid)->get();
			}else{
				$users = User::where('parent',$loggedUser->id)->where('id','!=',$id)->where('id','!=',$id2)->where('id','!=',$luid)->get();
			}
			 
			
			$html = '<option value="0">Null</option>';
			if(count($users) > 0){
				foreach($users as $user){
					$html .= '<option value='.$user->id.'>'.$user->name.'</option>';
				}
			}else{
				$html .= '<option value="0">No Records</option>';
			}
			
		}else{
			if($loggedUser->user_type == 1){
				$users = User::where('id','!=',$loggedUser->id)->where('id','!=',$id)->where('id','!=',$luid)->get(); 
			}else{
				$users = User::where('parent',$loggedUser->id)->where('id','!=',$id)->where('id','!=',$luid)->get(); 
			}
			
			$html = '<option value="0">Null</option>';
			foreach($users as $user){
				$html .= '<option value='.$user->id.'>'.$user->name.'</option>';
			}
		}
		
		
		return $html;
	}
	
	public function showUsers(Request $request)
    {
		$uid = $request->input('uid');
		$adminusers = User::where('id',$uid)->first();
		$users = User::where('users.parent',$uid)->where('users.user_type','0')->get();
		$html = '';
		$i = 0;
		if($users){
			foreach($users as $user){
				$i++;
				$balance = Ledgerview::where('uid',$user->id)->first();
				if($balance){
					$cr = $balance->balance;
				}else{
					$cr = "0";
				}
				$amount = $user->rate*$cr;
				$html .= '<tr>
									<td>'.$i.'</td>
									<td>'.$user->name.'</td>
									<td>'.$user->userid.'</td>
									<td>'.$user->mobile.'</td>
									<td>'.$user->show_pass.'</td>			
									<td>'.$cr.'</td>
									<td>'.$user->rate.'</td>
									<td>'.$amount.'</td>
									
									<td><a href="'.route('update-user',['id' => $user->id]) .'" title="Update"><i class="fa fa-edit fa-1.5x"></i></a>
									<i class="fa fa-italic fa-1x"></i>
									<a href="'.url('delete-user',array('id' => $user->id)) .'" title="Delete"><i class="fa fa-trash fa-1.5x"></i></a>';
									if($user->isActive != '1'){
									$html .='<i class="fa fa-italic fa-1x"></i>
										<a href="javascript:void(0)" class="unsus" title="Suspend User" onclick="suspendUser('.$user->id.')">Suspend</a>';
									}else{	
									$html .='<i class="fa fa-italic fa-1x"></i>
										<a href="javascript:void(0)" class="sus"  title="Unsuspend User" onclick="unsuspendUser('.$user->id.')">Unsuspend</a>';
									}
									$html .='</tr>';
			}
		}
		$result = array("adminName" => $adminusers->name,'users' =>$html);
        return $result;
	}
	
	public function showaUsers(Request $request)
    {
		$uid = $request->input('uid');
		$adminusers = User::where('id',$uid)->first();
		$users = User::where('users.parent',$uid)->where('users.user_type','0')->get();
		$html = ''; 
		if($users){
			foreach($users as $user){
				$route = route("userssess-reports",["id" => $user->id]);
				$html .= '<tr>
									<td><a target="_blank" href="'.$route.'">'.$user->name.'</a></td>
									<td><a href="">'.$user->userid.'</a></td>';
									$html .='</tr>';
			}
		}
		$result = array("adminName" => $adminusers->name,'users' =>$html);
        return $result;
	}
	public function showlUsers(Request $request)
    {
		$uid = $request->input('uid');
		$adminusers = User::where('id',$uid)->first();
		$users = User::where('users.parent',$uid)->where('users.user_type','0')->get();
		$html = ''; 
		if($users){
			foreach($users as $user){
				$route = route("users-sessionsres",["id" => $user->id]);
				$html .= '<tr>
									<td><a target="_blank" href="'.$route.'">'.$user->name.'</a></td>
									<td><a href="">'.$user->userid.'</a></td>';
									$html .='</tr>';
			}
		}
		$result = array("adminName" => $adminusers->name,'users' =>$html);
        return $result;
	}
	public function getAllUsersdata(Request $request){
		$keyword = $request->input('keyword');
		$loggeduser = Auth::User();
		if($loggeduser->user_type == 1){
			$users = User::where('name','LIKE','%'.$keyword.'%')->get();
		}else{
			$users = User::where('name','LIKE','%'.$keyword.'%')->where('users.parent',$loggeduser->id)->where('users.user_type','0')->get();
		}
		$html = "";
		if($users){
			foreach($users as $user){
				$html .= '<li onclick="set_item(\''.$user->name.'\',\''.$user->id.'\')"><a href="javascript:void(0)">'.$user->name.'</a></li>';
			}
		}else{
			$html .= "<li>No Records</li>";
		}
		
		return $html;
	}
	public function getAlldusers(Request $request){
		$loggeduser = Auth::User();
		
		if($loggeduser->user_type == 1){
			$heads = Heads::where('id','2')->orderBy('name', 'ASC')->get();
			$users = User::where('id','!=',$loggeduser->id)->where('user_type','2')->orderBy('name', 'ASC')->get();
		}else{
			$heads = Heads::where('id','2')->orderBy('name', 'ASC')->get();
			$users = User::where('id','!=',$loggeduser->id)->where('parent',$loggeduser->id)->where('user_type','0')->orderBy('name', 'ASC')->get();
		}
		
		$html = "";
		if($users){
			foreach($users as $user){
				$html .= '<li onclick="set_uitem(\''.strtoupper($user->name).'\',\''.$user->id.'\')">'.strtoupper($user->name).'</li>';
			}
			foreach($heads as $head){
				$html .= '<li onclick="set_Huitem(\''.strtoupper($head->name).'\',\''.$head->id.'\')">'.strtoupper($head->name).'</li>';
			}
		}else{
			$html .= "<li>No Records</li>";
		}
		
		return $html;
	}
	public function getAllcusers(Request $request){
		$loggeduser = Auth::User();
		if($loggeduser->user_type == 1){
			$heads = Heads::where('id','2')->orderBy('name', 'ASC')->get();
			$users = User::where('id','!=',$loggeduser->id)->where('user_type','2')->orderBy('name', 'ASC')->get();
		}else{
			$heads = Heads::where('id','2')->orderBy('name', 'ASC')->get();
			$users = User::where('id','!=',$loggeduser->id)->where('parent',$loggeduser->id)->where('user_type','0')->orderBy('name', 'ASC')->get();
		}
		
		$html = "";
		if($users){
			foreach($users as $user){
				$html .= '<li onclick="set_citem(\''.strtoupper($user->name).'\',\''.$user->id.'\')">'.strtoupper($user->name).'</li>';
			}
			foreach($heads as $head){
				$html .= '<li onclick="set_Hcitem(\''.strtoupper($head->name).'\',\''.$head->id.'\')">'.strtoupper($head->name).'</li>';
			}
		}else{
			$html .= "<li>No Records</li>";
		}
		
		return $html;
	}
	public function showAlsers(Request $request){
		$id = $request->input('id');
		$users = User::where('id','!=',$id)->where('parent',$id)->where('user_type','0')->get();
		
		$html = "<option value ='0'>All</option>";
		if($users){
			foreach($users as $user){
				$html .= '<option value="'.$user->id.'">'.$user->name.'</option>';
			}
		}else{
			$html .= "<option value='0'>All</option><option>No Records</option>";
		}
		
		return $html;
	}
	
	public function changeUPassword(){
		$title = "Change Password"; 	
		return view('changePassword',array("title" => $title));
	}
	
	public function postChangepwd(Request $request){
		$loggedUser = Auth::user();
		$validator = $this->pwdvalidator($request->all());
		$options = ['cost' => '12'];
		if($validator->fails()){
			return redirect::to('changeUPassword')->withErrors($validator);
		}else{
			$user = User::where('show_pass',$request->old_pwd)->first();
			if($user){
				$user = User::find($loggedUser->id);
				$user->password  = password_hash($request->input('password'),PASSWORD_BCRYPT,$options);
				$user->show_pass = $request->input('password');
				$user->save();
				\Session::flash('flash_message','Password Succefully Changed');
				return Redirect('dashboard');
			}else{
				\Session::flash('flash_message','Old Password Dose not match');
				return Redirect('changeUPassword');
			}	
		}
	}
	protected function pwdvalidator(array $data)
    {
        return Validator::make($data, [
            'password' => 'required|confirmed|min:6',
        ]);
    }		
	public function getAppversion(){
		$title = "Manage App Version";
		$cVersion = DB::table('app_version')->first();
		return view('app-version',array("title" => $title,'cVersion' => $cVersion->version));
		}
	public function postVersion(Request $request){
		DB::table('app_version')
		->update(['version' => $request->input('version')]);
		return Redirect('app-version');	
	}
	
	public function postchkbetLmt(Request $request){
		$min = $request->input('mnlm');
		$max = $request->input('mxlm');
		$loggeduser = Auth::User();
		$user 		= new User;
		$checkMxMinBet = $user->CheckadMxminbet($loggeduser->id,$min,$max);
		return $checkMxMinBet;
	}
}

