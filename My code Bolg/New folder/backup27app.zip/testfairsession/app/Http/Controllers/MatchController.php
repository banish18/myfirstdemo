<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\User;
use Auth;
use App\Session;
use App\Matchesmaster;
use App\Sessionrec;
use App\Sessionmatrix;
use App\Sliderate;
use App\Superbook;
use App\Matchhistory;
use App\Matchdeclare;
use App\Matchres;
use Illuminate\Support\Facades\Redirect;
use DB;
use App\Aloginchk;
use App\Ledgerview;
class MatchController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
		
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$user = Auth::User();
		if($user->user_type == 0){
		   Redirect::to('/dashboard')->send();
		}
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$title = "Matches";
		$matches = Matchesmaster::orderBy('id', 'desc')->paginate(10);
		$numbers = [];		
		for($i=0;$i<=500;$i++){
			$numbers[$i] = $i;
		}
        return view('matches',array("title" => $title,'Matches' => $matches,'numbers' => $numbers));
		
    }	

    public function postMtchdata(Request $request){
		$user =  Auth::User();
		$userType = $user->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$match 					= new Matchesmaster;
		$match->user_id       	= $user->id;
		$match->match_name 		= $request->matchname;
		$match->team1 			= $request->team1;
		$match->team2 			= $request->team2;
		$match->action 			= '1';
		$match->run_diff 		= '1';
		$match->save();
		$msg = 1;

		$result   = array("msg" => $msg); 
		\Session::flash('flash_message','Match Succefully Created');
		return $result;
	}
	
	public function showMatches()
    {		
		$user = Auth::User();
		if($user->user_type == 0){
		   Redirect::to('/dashboard')->send();
		}
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$title = "Sessions";
		$arr = ['2','3'];	
		$Sessions = Matchesmaster::orWhereIn('action',$arr)->orderBy('id', 'desc')->get();
		$numbers = [];
			for($i=0;$i<=99;$i++){
				$numbers[$i] = $i;
		} 
		return view('all-matches',array("title" => $title,'Sessions' => $Sessions,'numbers' => $numbers));    
	}
	
	public function testshowSessions()
    {		
		$user = Auth::User();
		if($user->user_type == 0){
		   Redirect::to('/dashboard')->send();
		}
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$title = "Sessions";
		$arr = ['2','3'];	
		$Sessions = Session::orWhereIn('action',$arr)->orderBy('id', 'desc')->get();
		$numbers = [];
			for($i=0;$i<=500;$i++){
				$numbers[$i] = $i;
		} 
		return view('testrunsuss',array("title" => $title,'Sessions' => $Sessions,'numbers' => $numbers));    
	}
	
	public function postSessdata(Request $request){
		$user =  Auth::User();
		$userType = $user->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$session 				= new Session;
		$session->user_id       = $user->id;
        $session->over 			= $request->over;
		$session->action 		= '1';
		$session->save();
		
		$id 	  = $session->id;
		$sess	  = Session::find($id);
		$msg      = 1;
		$tm 	  = $sess->over;
		$ac 	  = $sess->action;
		$numbers  = [];
		for($i=0;$i<=500;$i++){
			$numbers[$i] = $i;
		}
		

		$result   = array("msg" => $msg,'tm' => $tm,'ac' => $ac,'id' => $id,'numbers' => $numbers);		\Session::flash('flash_message','Session Succefully Created');
		return $result;
	}
	
	public function updateMatchisactive(Request $request){
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$id 				= $request->match_id;
		$is 				= $request->is;
		$match 				= Matchesmaster::find($id);
		$match->isActive 	= $is;
		$match->action   	= $request->act;
		$match->save();
		$result   			= array("msg" => $is);
		return $result;
	}		
	public function updateSessisastatus(Request $request){
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$id = $request->sess_id;
		$is = $request->is;
		$session = Session::find($id);
		if($is == 2 || $is == 1){
			$session->amount = 0;
		}
		$session->action = $is;
		$session->save();
		$result   = array("msg" => 1);
		\Session::flash('flash_message','Session Succefully Updated');
		return $result;
	}
	public function updateDcrate(Request $request){
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$id = $request->sess_id;
		$amt = $request->amt;
		$session = Session::find($id);
		$session->amount = $amt;
		$session->action = '3';
		$session->save();
		$result   = array("msg" => 1);
		\Session::flash('flash_message','Declare Rate Succefully Updated');
		return $result;
	}
	public function setMatchRate(Request $request){
		$user =  Auth::User();
		$userType = $user->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$match    = DB::table('matches')->where('id',$request->match_id)->first();
		if($match->selected_team_val == "3"){
			$tmrt        = (int)($match->rate+100)/100;
			$team1Rate   = $tmrt .":"."0";
			$team2Rate   = $tmrt.":"."0";
		}else{
			$tmva1             =  (int)($request->runs+100)/100;
			$tmva2          = (int)$request->runs + (int)$request->rn_diff;
			$tmva2          = ($tmva2+100)/100;
			if($tmva1 == "0"){
				$team1Rate = $tmva1.":".$tmva2;
				$team2Rate = "0:0";
				}else{
					$team1Rate      = $tmva1.":".$tmva2;
					$var1        =  100/(int)$request->runs;
					$var1        =   round($var1, 1, PHP_ROUND_HALF_EVEN)+1;
					$decvar      = (int)$request->runs+(int)$request->rn_diff;
					$var2        =  100/$decvar;
					$var2        =  round($var2, 1, PHP_ROUND_HALF_EVEN)+1;
					$team2Rate   = $var2.':'.$var1;
				}
		}
		
		$id 				= $request->match_id;
		$match 				= Matchesmaster::find($id);
		$match->user_id   	= $user->id;
		$match->team1_rate 	= $team1Rate;
		$match->team2_rate 	= $team2Rate;
		$match->rate 		= $request->runs;
		$match->run_diff    = $request->rn_diff;
		$match->select_val 	= $request->select_val;
		$match->save();
		
		$result   = array("msg" => 1); 
		return $result;
	}
	
	public function setTeam(Request $request){
		$user =  Auth::User();
		$userType = $user->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$id 						= $request->match_id;
		$match    = DB::table('matches')->where('id',$id)->first();
		if($request->stv == 1){
			$tmva1             =  (int)($match->rate+100)/100;
			$tmva2          = (int)$match->rate + (int)$match->run_diff;
			$tmva2          = ($tmva2+100)/100;
			$teamrate1      = $tmva1.":".$tmva2;
			$var1        =  100/(int)$match->rate;
			$var1        =   round($var1, 1, PHP_ROUND_HALF_EVEN)+1;
			$decvar      = (int)$match->rate+(int)$match->run_diff;
			$var2        =  100/$decvar;
			$var2        =  round($var2, 1, PHP_ROUND_HALF_EVEN)+1;
			$teamrate2   = $var2.':'.$var1;
		}else if($request->stv == 2){
			$tmva1             =  $match->rate;
			$tmva2          = (int)$match->rate + (int)$match->run_diff;
			$teamrate1      = $tmva1.":".$tmva2;
			$var1        =  100/(int)$match->rate;
			$var1        =   round($var1, 1, PHP_ROUND_HALF_EVEN)+1;
			$decvar      = (int)$match->rate+(int)$match->run_diff;
			$var2        =  100/$decvar;
			$var2        =  round($var2, 1, PHP_ROUND_HALF_EVEN)+1;
			$teamrate2   = $var2.':'.$var1;
		}else{
			/* $teamrate1   = $match->rate.":"."0";
			$teamrate2   = $match->rate.":"."0"; */
			$tmrt        = (int)($match->rate+100)/100;
			$teamrate1   = $tmrt .":"."0";
			$teamrate2   = $tmrt.":"."0";
		}
		$match 						= Matchesmaster::find($id);
		$match->team1_rate   		= $teamrate1;
		$match->team2_rate   		= $teamrate2;
		$match->selected_team   	= $request->selected_team;
		$match->selected_team_val   = $request->stv;
		$match->save();
		$result   = array("msg" => 1); 
		return $result;
	} 
	
	public function getSessionentry(){
		$title 		= 'Session Entry';
		$user 		=  Auth::User();
		$loggeduser = Auth::User();
		$arr = ['2','3'];	
		$sessions = Session::orWhereIn('action',$arr)->orderBy('id', 'desc')->get();
		if($user->user_type == 2){
			$users = User::where('users.parent',$user->id)->where('user_type','0')->get();	
		}else{
			$users = User::where('user_type','!=','1')->get();
		}
		return view('session-entry',array('title' => $title,'sessions' => $sessions,'users' => $users,'loggeduser' => $loggeduser));
	}
	
	public function postSessionentry(Request $request){
		$user =  Auth::User();
		$userType = $user->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$rn = $request->runs;
		$rt = $request->rate;
		$amount = $rt*$request->amount/100;
		$id                     = $request->input("sess_id");
		$session 				= new Sessionrec;
		$session->uid       	= $request->usr_id;
        $session->sess_id 		= $id;
		$session->run 			= $request->runs; 
		$session->amount 		= $amount;
		$session->y_n 			= $request->y_n;
		$session->rate 			= $request->rate;
		$session->save();
		$var1 = $session->run;
		$sessMatrix = [];
		$sessMatrix2 = [];
		$entryVar = 300-$session->run;
		for($i =1;$i<=$session->run-1;$i++){
			array_push($sessMatrix,$i);
		}
		for($j = $session->run;$j<=$session->run+$entryVar;$j++){
			array_push($sessMatrix2,$j);
		}
		$sessMatrix = array_merge($sessMatrix,$sessMatrix2);
		if($session->y_n == 1){
			$amount1 = [];
			$amount2 = [];
			for($i =1;$i<=$session->run-1;$i++){
				array_push($amount1,'-'.$session->amount);
			}
			for($j = $session->run;$j<=$session->run+$entryVar;$j++){
				array_push($amount2,'+'.$session->amount);
			}
		}else{
			$amount1 = [];
			$amount2 = [];
			for($i =1;$i<=$session->run-1;$i++){
				array_push($amount1,'+'.$session->amount);
			}
			for($j = $session->run;$j<=$session->run+$entryVar;$j++){
				array_push($amount2,'-'.$session->amount);
			}
		}
		$users = User::where('id',$request->usr_id)->first();
		$sessAmount = array_merge($amount1,$amount2);
		$i = 0;
		foreach($sessMatrix as $sm){
			$Sessionmatrix = new Sessionmatrix;
			$Sessionmatrix->sid 	= $request->sess_id;
			$Sessionmatrix->uid 	= $request->usr_id;
			$Sessionmatrix->runs 	= $sm;
			$Sessionmatrix->amount 	= $sessAmount[$i];
			$Sessionmatrix->parent_id 	= $session->id;
			$Sessionmatrix->admin_id 	 = $users->parent_id;
			$Sessionmatrix->save();
			$i++;
		} 
		
		$minValue = DB::table('session_matrix')->select(DB::raw('runs,sum(amount) as amount'))->where('sid',$request->sess_id)->where('uid',$request->usr_id)->groupBy('runs')->first();
		$ledBalance = Ledgerview::where('uid',$request->usr_id)->first();
		/* echo $minValue->amount;
		echo "<br />";          
		echo $ledBalance->balance;  */  
	
		if(abs($minValue->amount) > $ledBalance->balance){ 
			$msg = 0;
			DB::table('sessions_res')->where('id',$session->id)->delete();
			DB::table('session_matrix')->where('parent_id',$session->id)->delete();
		}else{
			$msg = 1;
		}
		return $msg;
	}
	
	public function updatemtchStat(Request $request){
		$id 			= $request->match_id;
		$query = DB::statement("create or replace view superbook_".$id." as SELECT sum(team1) as team1sum,sum(team2) as team2sum from match_res where match_id=".$id." and status = '1'");
		$query = DB::statement("Create or replace VIEW `userbook_".$id."` AS select `match_res`.`uid` AS `uid`,sum(`match_res`.`team1`) AS `team1sum`,sum(`match_res`.`team2`) AS `team2sum` from `match_res` where ((`match_res`.`match_id` = ".$id.") and (`match_res`.`status` = 'M')) group by `match_res`.`uid`");

		$match 			= Matchesmaster::find($id);
		$match->action 	= "2";
		$match->save();
		$msg = 1;
		return $msg;
	}
	public function getsesMtxData(Request $request){
		$user =  Auth::User();
		$adCheck = Aloginchk::find('1');
		$date = date('Y-m-d h:i:s',strtotime(date('Y-m-d h:i:s'))+19800);
		$adCheck->updated_at = $date;
		$adCheck->save(); 
		
		
		
		$sess_id = $request->sess_id;
		$getSessAC = Session::find($sess_id);
		if($user->user_type == 1){
			$Sessionmatrix = DB::table('super_admin_exp')->select(DB::raw('runs,sum(exposure) as amount'))
                     ->where('sid',$sess_id)
                     ->groupBy('runs')
                     ->get();
			$SessionRes	 = 	DB::table('sessions_res')
                     ->where('sess_id',$sess_id)
					 ->orderBy('id','desc')
                     ->get();
		}else if($user->user_type == 2){
			
			$Sessionmatrix = DB::table('admin_exp')->select(DB::raw('runs,sum(exposure) as amount'))
                     ->where('sid',$sess_id)
					 ->where('admin_id',$user->id)
                     ->groupBy('runs')
                     ->get();
			$SessionRes = DB::select('select * from sessions_res where uid in (select id from users where parent_id = '.$user->id.') and sess_id = '.$sess_id.' ORDER BY id desc');		 
			/* $SessionRes	 = 	DB::table('sessions_res')->select(DB::raw('select * from users where parent = '.$user->id.''))
                     ->where('sess_id',$sess_id)
					 ->orderBy('id','desc')
                     ->get();	 */	 
		}else{
			$Sessionmatrix = DB::table('matrix_view')->select(DB::raw('runs,sum(amount) as amount'))
                     ->where('sid',$sess_id)
					 ->where('admin_id',$user->id)
                     ->groupBy('runs')
                     ->get();
			$SessionRes	 = 	DB::table('sessions_res')
                     ->where('sess_id',$sess_id)
					 ->where('uid',$user->id)
					 ->orderBy('id','desc')
                     ->get();		 
		}
		$html 	= '';
		$html2  = '';
		if($Sessionmatrix){
			$i=0;
			foreach($Sessionmatrix as $data){
				$i++;
				if((int)$data->amount > 0){ 
					$class = "rd";
				}else{
					$class = "gn";
				}
				$html .= '<tr class="s_'.$i.'"><td>'.$data->runs.'</td><td class="'.$class.'">'. abs($data->amount).'</td></tr>';
			}
		}else{
			$html .= '<tr><td>No Records<td></tr>';
		}
		$aUser = new User;
		if($SessionRes){ 
			$i = count($SessionRes);
			foreach($SessionRes as $Sdata){	
				$i-- ;
				if($Sdata->y_n == 0){ 
					$yn = "N";
				}else{
					$yn = "Y";
				}
				$lgusr = Auth::User(); 
				if($lgusr->user_type == "1"){
					$del = '<td><a style="cursor:pointer;" onclick="deletesessRes('.$Sdata->id.')">Delete</a></td>';
				}else{
					$del = "";
				}
				$html2 .= '<tr><td>'.$i.'</td><td>'.$aUser->getUserName($aUser->getAdmin($Sdata->uid)).'</td><td>'.$aUser->getUserName($Sdata->uid).'</td><td>'.$Sdata->run.'</td><td>'.$Sdata->amount.'</td><td>'.$yn.'</td>'.$del.'</tr>';
			}
		}else{
			$html2 .= '<tr><td>No Records<td></tr>';
		} 
		$result = array('html' => $html,'html2' => $html2,'sess_ac' => $getSessAC->isActive,'sess_rate' => $getSessAC->sess_rate,'sessrn' => $getSessAC->runs);
		return $result;
	}
	function deleteSessresData(Request $request){
		DB::table('sessions_res')->where('id',$request->input('sid'))->delete();
		DB::table('session_matrix')->where('parent_id',$request->input('sid'))->delete();
	}
	public function showautoSessions()
    {		
		$user = Auth::User(); 
		if($user->user_type == 0){
		   Redirect::to('/dashboard')->send(); 
		} 
		$userType = Auth::User()->user_type;
		if($userType == "2"){
			return redirect::to('/dashboard');
		}
		$title = "Sessions";
		$arr = ['2','3'];	
		$Sessions = Session::orWhereIn('action',$arr)->orderBy('id', 'desc')->get();
		$numbers = [];
			for($i=0;$i<=500;$i++){
				$numbers[$i] = $i;
		} 
		return view('run-session-auto',array("title" => $title,'Sessions' => $Sessions,'numbers' => $numbers));    
	}
	public function sussallSession(Request $request){
		$SessionRes = DB::table('sessions')->update(['isActive' => '1']);	
		$myfile = fopen("session-api/sessid.txt", "w") or die("Unable to open file!");
		fwrite($myfile, "");
		fclose($myfile);
		$msz = 1;
		return $msz;
	}
	public function sliderRate()
    {
		$title = "Slider";
		$arr = ['2','3'];	
		$Sliderate = Sliderate::find(1);
		$sessions = Session::orWhereIn('action',$arr)->orderBy('id', 'desc')->get();
        return view('slider-rate',array("title" => $title,'sessions' => $sessions,'Sliderate' => $Sliderate));
    }
	public function postslideSessrt(Request $request)
    {
		$title 		= "Post Slider";
		$sess_id 	= $request->input("sess_id");
		$rt 		= $request->input("rt");
		$sessions   = Session::find($sess_id);
		$sess_rate  = $sessions->sess_rate;
		$rate       = explode(":",$sess_rate);
		$Sliderate  = Sliderate::find(1);
		if($Sliderate){
			$Sliderate->rate = $rt;
			$Sliderate->save();
		}else{
			$Sliderate = new Sliderate;
			$Sliderate->rate = $rt;
			$Sliderate->save();
		}	
		/* if($rt < 0){
			$rate1 = $rate[0]-$rt;
			$rate2 = $rate[1]-$rt;
		}else{
			$rate1 = $rate[0]+$rt;
			$rate2 = $rate[1]+$rt;
		}
		$sess_rate 				= $rate1.":".$rate2;
		$session  				= Session::find($sess_id);
		$session->sess_rate 	= $sess_rate;
		$session->save(); */
		$msg = 1;
		return $msg;
    }
	public function setRtype(Request $request)
    {
		$matchId 	= $request->input("match_id");
		$rt 		= $request->input("rt");
		$match   	= Matchesmaster::find($matchId);
		$match->rate_type  = $rt;
		$match->save();
		$msg = 1;
		return $msg;
    }	
    public function getSuperbook(Request $request)
    {
		$matchId 	= $request->input("match_id");
		$resultsdata = DB::select( DB::raw("SELECT sum(team1sum) as team1total,sum(team2sum) as team2total FROM userbook"));
		$team1val    = $resultsdata[0]->team1total;
		$team2val    = $resultsdata[0]->team2total;
		if($team1val < 0){
			$tm1 = "<span class='sbgn'>".abs($team1val)."</span>";
		}else{
			$tm1 = "<span class='sbrd'>".abs($team1val)."</span>";
		}
		if($team2val < 0){
			$tm2 = "<span class='sbgn'>".abs($team2val)."</span>";
		}else{
			$tm2 = "<span class='sbrd'>".$team2val."</span>";
		}
		$result = array('team1' => $tm1,'team2' => $tm2);
		return $result;
    }	
	public function setDeclarematch(Request $request)
    {
		$matchId 					= $request->input("match_id");
		$teamId     				= $request->input("tm");
		if($teamId == 1){
			$team = "team1sum";
			$teamamount = "team1";
		}else{
			$team = "team2sum";
			$teamamount = "team2";
		}
		/* To save match History data */
		$resultsdata 				= DB::select( DB::raw("SELECT * FROM matches where id =".$matchId) );
		$Matchhistory 				= new Matchhistory;
		$Matchhistory->match_id 	= $matchId;
		$Matchhistory->match_name 	= $resultsdata[0]->match_name;
		$Matchhistory->team_id 		= $teamId;
		$Matchhistory->team_name 	= $request->selectedval;
		$Matchhistory->save();
		$date = date("Y-m-d");
		/* To save match Declare data */
		$selectQuery = DB::table('match_res')->select(DB::raw("sum(".$teamamount.") as sum"),"match_id","uid","parent_id")->where("match_id",$matchId)->groupBy('parent_id','uid')->get();
		
		/* echo "<pre>";print_r($selectQuery);
	 
		die;
		  */
		/* $updateQry = DB::table('ledger')
            ->where('match_id', $matchId)
            ->update(['status' => "S"]); */
		
		$Matchdeclare = new Matchdeclare;
		$Matchdeclare->match_id = $selectQuery[0]->match_id;
		$Matchdeclare->uid = $selectQuery[0]->uid;
		$Matchdeclare->parent_id = $selectQuery[0]->parent_id;
		$Matchdeclare->amount = $selectQuery[0]->sum;
		$Matchdeclare->save();
		/*To save match res status*/
		$updateQry = DB::table('match_res')
            ->where('match_id', $matchId)
            ->update(['status' => "S"]);
			
		
		$query = DB::insert("insert into dec_ledger_entry select '',match_id,a.uid,'Loss',a.uid,'D',amount,'' from match_declare a where a.match_id = ".$matchId." and amount < 0");
		
		
		$query = DB::insert("insert into dec_ledger_entry select '',match_id,a.uid,'Win',a.uid,'C',amount,'' from match_declare a where a.match_id = ".$matchId." and amount > 0");	
		
		$query = DB::insert("insert into ledger select '',a.uid,".$matchId.",'".$date."','".$resultsdata[0]->match_name."',account_head,sess_id,debit_credit,amount,'','' from dec_ledger_entry a where a.sess_id = ".$matchId."");    
		
		//$mysqli->query("update sessions set action = '4' WHERE id =".$sess_id);
		$updateQry = DB::table('matches')
            ->where('id', $matchId)
            ->update(['action' => "4"]);
		$result = array('msg' => 1);
		return $result; 
    }
	
	public function setmatchUndeclare(Request $request){
		DB::table('ledger')->where('match_id', $request->match_id)->delete();
		DB::table('dec_ledger_entry')->where('sess_id', $request->match_id)->delete();
		DB::table('match_declare')->where('match_id', $request->match_id)->delete();
		DB::table('match_history')->where('match_id', $request->match_id)->delete();
		/*To save match res status*/
		$updateQry = DB::table('match_res')
            ->where('match_id', $request->match_id)
            ->update(['status' => "M"]);
		$updateQry = DB::table('matches')
            ->where('id', $request->match_id)
            ->update(['action' => "2"]);
		$result = array('msg' => 1);
		return $result;
	}
	
	public function getmatchEntry(){
		$title 		= 'Match Entry';
		$user 		=  Auth::User();
		$loggeduser = Auth::User();
		$arr = ['2','3'];	
		$matches = Matchesmaster::orWhereIn('action',$arr)->orderBy('id', 'desc')->get();
		if($user->user_type == 2){
			$users = User::where('users.parent',$user->id)->where('user_type','0')->get();	
		}else{
			$users = User::where('user_type','!=','1')->get();
		}
		return view('match-entry',array('title' => $title,'matches' => $matches,'users' => $users,'loggeduser' => $loggeduser));
	}
	public function getmatchRes(Request $request){
		$user =  Auth::User();
		$html  = '';
		$html2  = '';
		$match_id = $request->match_id;
		$getMatchAC = Matchesmaster::find($match_id);
		
		if($user->user_type == 1){
			$matchadminres = DB::table('userbook')->select(DB::raw('uid,sum(team1sum) as team1sum,sum(team2sum) as team2sum'))
                     ->where('match_id',$match_id)
                     ->groupBy('uid')
                     ->get();
					 
			$MatchRes	 = 	DB::table('match_res')
                     ->where('match_id',$match_id)
					 ->orderBy('id','desc')
                     ->get();
			$team1sum  =  "";
			$team2sum  =  "";	
					 
		}else if($user->user_type == 2){
			$matchadminres = DB::table('userbook')->select(DB::raw('uid,sum(team1sum) as team1sum,sum(team2sum) as team2sum'))
                     ->where('match_id',$match_id)
					 ->where('uid',$user->id)
                     ->groupBy('uid')
                     ->get();
			$MatchRes = DB::select('select * from match_res where user_id in (select id from users where parent_id = '.$user->id.') and match_id = '.$match_id.' ORDER BY id desc');
			$team1sum  =  "";
			$team2sum  =  "";				
		}else{
			$MatchRes	 = 	DB::table('match_res')
                     ->where('match_id',$match_id)
					 ->where('user_id',$user->id)
					 ->orderBy('id','desc')
                     ->get();
			$matchadminres = DB::table('userbook')->select(DB::raw('uid,sum(team1sum) as team1sum,sum(team2sum) as team2sum'))
                     ->where('match_id',$match_id)
					 ->where('uid',$user->id)
                     ->groupBy('uid')
                     ->get();	
			$team1sum  =  $matchadminres->team1sum;
			$team2sum  =  $matchadminres->team1sum;				
		}
		$aUser = new User;
		if($matchadminres){
			$i=0;
			foreach($matchadminres as $data){
				$i++;
				if((int)$data->team1sum > 0){ 
					$class1 = "rd";
				}else{
					$class1 = "gn";
				}
				if((int)$data->team2sum > 0){ 
					$class2 = "rd";
				}else{
					$class2 = "gn";
				}
				$html .= '<tr class="s_'.$i.'"><td>'.$aUser->getUserName($aUser->getAdmin($data->uid)).'</td><td class="'.$class1.'">'.$data->team1sum.'</td><td class="'.$class2.'">'.$data->team2sum.'</td></tr>';
			}
		}else{
			$html .= '<tr><td>No Records<td></tr>';
			
		}
		
		if($MatchRes){ 
			$i = count($MatchRes);
			foreach($MatchRes as $Sdata){	
				$i-- ;
				if($Sdata->b_l == 0){ 
					$bl = "N";
				}else{
					$bl = "Y";
				}
				$lgusr = Auth::User(); 
				if($lgusr->user_type == "1"){
					$del = '<td><a style="cursor:pointer;" onclick="deletematchRes('.$Sdata->id.')">Delete</a></td>';
				}else{
					$del = "";
				}
				$html2 .= '<tr><td>'.$i.'</td><td>'.$aUser->getUserName($aUser->getAdmin($Sdata->uid)).'</td><td>'.$aUser->getUserName($Sdata->uid).'</td><td>'.$Sdata->team1.'</td><td>'.$Sdata->team2.'</td><td>'.$Sdata->b_l.'</td><td>'.$Sdata->stak.'</td><td>'.$Sdata->rate.'</td>'.$del.'</tr>';
			}
		}else{
			$html2 .= '<tr><td>No Records<td></tr>';
		} 
		$result = array('html' => $html,'html2' => $html2,'sess_ac' => $getMatchAC->isActive,'team1' => $getMatchAC->team1,'team2' => $getMatchAC->team2,'team1sum' => $team1sum,'team2sum' => $team2sum);
		return $result;
	}
	function deleteMatchresData(Request $request){
		DB::table('match_res')->where('id',$request->input('mid'))->delete();
	}
}

