<?php 
include("php-script-background-processer-master/PHPBackgroundProcesser.php");
	$proc=new BackgroundProcess();
	echo "<pre>";print_r($proc->showAllPocess());
die; 
?>