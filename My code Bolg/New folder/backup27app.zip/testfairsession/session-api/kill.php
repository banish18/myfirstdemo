<?php
echo system("ulimit -a");
die;
$cpid = posix_getpid();
error_reporting(1);
$a = exec("ps -aef|grep -v grep|grep cron.php|awk -F");
echo $a;
die;
echo "<pre>";print_r($psOutput);

die;
if (count($psOutput) > 0)
{
    foreach ($psOutput as $ps)
    {
        $ps = preg_split('/ +/', $ps);
        $pid = $ps[1];

        if($pid != $cpid)
        {
          $result = posix_kill($pid, 9); 
        }
    }
}
?>