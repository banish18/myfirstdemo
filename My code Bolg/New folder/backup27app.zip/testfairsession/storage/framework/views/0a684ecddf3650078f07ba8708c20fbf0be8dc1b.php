<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<!-- /.panel-heading -->
			<div class="panel-body">
			<section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section>
			<?php echo csrf_field(); ?>

				<div class="table-responsive">
					<div class="col-lg-12">
						<div class="my-session">
							<h3 onclick="shSess(this)" class="ct_ses">Create Match</h3>
							<div class="slide-cont">
								<div class="form-group">
								<label>Match Description</label>
								<textarea id="over" class="form-control"></textarea>
								</div>
							
								<div class="form-group">
									<label>Team 1</label>
									<input type="text" id="team_1" class="form-control" /> 
								</div>
								<div class="form-group">
									<label>Team 2</label>
									<input type="text" id="team_2" class="form-control" /> 
								</div>
								<p><input type="submit" id="Create" value="Create" onclick="ctMtch(this)" /><!--input onclick="isCheck()" type="button" id="act" value="Activate" class="acti_sess"/><input type="hidden" id="ac" value="1"--></p>
							</div>
						</div>
					</div>
					
					<div class="all-sess">
					<div class="col-lg-12">
						<table class="table">
						<thead>
							<th>#</th>
							<th>Description</th>
						</thead>
						<?php $i = 1; ?>
						<tbody>
							<?php foreach($Matches as $match): ?>
								<tr onclick="showMatchPop(<?php echo e($match->id); ?>,<?php echo e($match->amount); ?>,'<?php echo e($match->isActive); ?>','<?php echo e($match->action); ?>','<?php echo e($match->team1_rate); ?>','<?php echo e($match->team2_rate); ?>','<?php echo e($match->run_diff); ?>','<?php echo e($match->rate); ?>','<?php echo e($match->team1); ?>','<?php echo e($match->team2); ?>')" class="diff-sess slide_open"><td><?php echo e($match->id); ?></td><td><?php echo e($match->match_name); ?></td></tr>
								<?php $i++; ?>
							<?php endforeach; ?>
						</tbody>
					</table>
					<?php echo $Matches->render(); ?>
					</div>
					</div>
				</div>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div id="slide">
			<div class="sess_slide">
				<div class="alrt_msg" id="alrt_msg"></div>
				<p><!--input type="button" id="active" value="Activate" onclick="setStat(this)"/><input type="button" id="inactive" value="Inactivate" onclick="setStat(this)" /--><input type="button" id="declare" value="Declare" onclick="setmatchStat(this)"/><input type="button" id="undeclare" value="Undeclare" onclick="setmatchStat(this)"/><input type="button" id="runsess" value="Run" onclick="runMatch(this)" class="active_bg_open"/><input type="button" id="undeclare" value="Undeclare" onclick="setmatchStat(this)"/></p>
				<div class="dec_bxm">
					<div class="col-lg-6"><label>Winning Team</label></div>
					<div class="col-lg-6"><input type="radio" name="team" id="team1" onclick="setTmval(this,'1')" /><span id="team1val"></span><input type="radio" name="team" id="team2" onclick="setTmval(this,'2')" /><span id="team2val"></span></div>
					<input type="button" id="save" value="Save" onclick="setmatchDec()"/>
			    </div>
				<br /><p><button class="slide_close btn btn-default">Close</button></p>
				<input type="hidden" id="match_id" class="match_id" />
				<input type="hidden" id="isAct" />
				<input type="hidden" id="st" />
				<input type="hidden" id="rn" />
				<input type="hidden" id="rd" />
				<input type="hidden" id="rt" />
				<input type="hidden" id="tm1" />
				<input type="hidden" id="tm2" />
				<input type="hidden" id="actionsess" />
				<input type="hidden" id="selected_val" /> 
				<input type="hidden" id="tm" />
			</div>
		</div>    

		<div id="cover"> </div> 
		<div class="loading_img rn_ldimg">
			<img src="<?php echo e(asset('assets/clock-loading.gif')); ?>" />
		</div>
	</div>
	
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
 
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>