@extends('layouts.app')
@section('content')
@include('templates/admin-header')
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<!-- /.panel-heading -->
			<div class="panel-body">
			<section class="seccess">
					@if(Session::has('flash_message'))
						<div class="alert alert-success"><em> {!! session('flash_message') !!}</em></div>
					@endif
				</section>
				<form method="post">
			{!! csrf_field() !!}
				<div class="table-responsive">
				<div class="my-session">
							<h3>Run Match</h3>
						</div>
					<table class="table">
						<thead>
							<th>#</th>
							<th>Description</th>
							<th>Status</th>
						</thead>
						<?php $i = 1; ?>
						<tbody>
							@foreach($Sessions as $session)
								@if($session->action == 1)
									<?php $status = "Created"; ?>
									@elseif($session->action == 2 && $session->isActive == 1)
										<?php $status = "Running,Suspended"; ?>
									@elseif($session->action == 3 && $session->isActive == 1)
										<?php $status = "Running,Suspended"; ?>	
									@elseif($session->action == 3 && $session->isActive == 0)
										<?php $status = "Running,Running Live"; ?>	
									@elseif($session->action == 4 && $session->isActive == 1)	
										<?php $status = "Declared"; ?>
									@else	
										<?php $status = "Suspended"; ?>
								@endif	
								<?php 
								if($session->selected_team == ""){
									$session->selected_team = "1";
								}/* else if($session->run_diff = ""){
									$session->run_diff = " ";
								}else if($session->rate == ""){
									$session->rate =  " ";
								}else if($session->rate_type){
									$session->rate_type = " ";
								}else if($session->select_val == ""){
									$session->select_val = " ";
								} */
									
								?>
								<tr onclick="showMatchPopRs(this,'{{ $session->id }}','{{ $session->action}}','{{ $session->isActive}}','{{ $session->match_name }}','{{ $session->select_val }}','{{ $session->team1 }}','{{ $session->team2 }}','{{ $session->selected_team }}','{{ $session->run_diff }}','{{ $session->rate }}','{{ $session->rate_type }}')" class="diff-sess active_bg_open"><td>{{ $session->id }}</td><td>{{ $session->match_name }}</td><td>{{ $status }}</td></tr>
								<?php $i++; ?>
								
							@endforeach
						</tbody>
					</table>
				</div>
				</form>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div id="active_bg">
			<div class="sess_slide_rs">
			<div class="my-session">
			<div class="st_ct">
				<div class="col-lg-12 bd_bg">
								<div class="alrt_msg" id="alrt_msg"></div>
								<div class="match_hd">
								<div class="col-lg-5">
									<div class="match_rates">
										<ul>
											<li class="mnrt" id="manualy" onclick="setMnrates(this)">Manual</li>
											<li class="mnrt" id="automatic" onclick="setMnrates(this)">Automatic</li>
										</ul>
									</div>
								</div>
								<div class="col-lg-3">
									<div class="cr_sess">
									<span>
										<!--h3 id="sess_desc">Current Session</h3--> 
										<b id="rt_1"></b>
										<b id="rt_2"></b>
										<input onclick="saveMatchRate()" type="button" name="save" id="save_rt" value="Save"/>
									</span>
								</div>
								</div>
								<div class="col-lg-4">
									<div class="match_sb">
										<div class="col-lg-6"><p><span id="team1sb"></p></span><p id="sbrt1"></p></div>
										<div class="col-lg-6"><p><span id="team2sb"></span></p><p id="sbrt2"></p></div>
									</div>
								</div>
								</div>
								
								<div class="col-lg-8">
								<div class="mn_rates">
									<ul class="match_num" name="">
											 <li class="num_slide" id="mn_numb_1"onclick="setmnRunval('1',this)">1</li>
											 <li class="num_slide" id="mn_numb_2"onclick="setmnRunval('2',this)">2</li>
											 <li class="num_slide" id="mn_numb_3"onclick="setmnRunval('3',this)">3</li>
											 <li class="num_slide" id="mn_numb_4"onclick="setmnRunval('4',this)">4</li>
											 <li class="num_slide" id="mn_numb_5"onclick="setmnRunval('5',this)">5</li>
											 <li class="num_slide" id="mn_numb_10"onclick="setmnRunval('10',this)">10</li>
											 <li class="num_slide" id="mn_numb_15"onclick="setmnRunval('15',this)">15</li>
											 <li class="num_slide" id="mn_numb_20"onclick="setmnRunval('20',this)">20</li>
											 <li class="num_slide" id="mn_numb_25"onclick="setmnRunval('25',this)">25</li>
											 <li class="num_slide" id="mn_numb_30"onclick="setmnRunval('30',this)">30</li>
									</ul>
								</div>
								</div>
								<div class="col-lg-4">
								<h2 class="sess_stat_h"><img class="news_blink_image" alt="blink_image" src="http://mindxpert.com/development/portal/assets/images/news-star.gif"><b>Match Waiting.........</b></h2>
								</div>
								<ul class="match_num" name="">
									@foreach($numbers as $number)
										 <li class="num_slide" id="m_numb_{{$number}}"onclick="setRunval('{{$number}}',this)">{{$number}}</li>
									@endforeach
								</ul>
								 
								
								
								<!--div class="cr_sess_m">
									<span>
										<div class="col-lg-4"><input type="radio" id="tm1val" name="team" onclick="setTm(this,1)" class="slide_open"/><label id="team1"></label></div>
								<div class="col-lg-4"><input type="radio" name="team" id="tm2val" onclick="setTm(this,2)" /><label id="team2"></label></div>
								<div class="col-lg-4"><input type="radio" name="team" id="both" value="both" class="both slide_open" onclick="setTm(this,3)"/><label id="both">both</label></div>
									</span>
								</div-->  
								<div class="cr_sess_m">
									<span>
										<div class="col-lg-4"><label id="team1" onclick="setTm(this,1)"></label></div>
										<div class="col-lg-4"><label id="team2" onclick="setTm(this,2)"></label></div>
										<div class="col-lg-4"><label class="both" id="both" onclick="setbtTm()">both</label></div>
									</span>
								</div>  
								
								<input type="hidden" id="match_id" />
								<input type="hidden" id="run_diff" />
								<input type="hidden" id="rtnumber" />
								<input type="hidden" id="act" />
								<input type="hidden" id="num_sess_rd" />
								<input type="hidden" id="select_val" />
								<input type="hidden" id="select_tm_val" />
								<input type="hidden" id="tmval" />
								<input type="hidden" id="stv" />
								<input type="hidden" id="seltem" />
								<br />
								<br />
								
								<div class="col-lg-10"><p class="mt_btn"><span><input onclick="isActivematch()" type="button" name="suspend" id="suspend" value="Unsuspend"/></span></p>
								</div>
								<div class="col-lg-2"><p><button class="btn btn-default rn_sess_btnC mtcls" onclick="cls_popup()">Close</button><button class="active_bg_close btn btn-default rn_sess_btn">Close</button></p></div>
								
			   </div>
			   
			
				</div>
				
			</div>
			</div>
		</div>
		<div id="slide"> 
			<div class="sess_slide sess_slide2">
				<div class="alrt_msg" id="alrt_msg"></div>
				<p id="altmsg"></p> 
				<p><input type="button" id="continue" value="Continue" onclick="continueRate()"/>&nbsp;&nbsp
				
				<input type="button" id="Cancel" value="Cancel" class="slide_close"/></p>
				<p><input type="button" id="ok" value="Ok" class="slide_close"/></p>
			</div>
		</div> 
		<div id="cover"> </div> 
		<div class="loading_img rn_ldimg">
			<img src="{{ asset('assets/clock-loading.gif')}}" />
		</div>
	</div>
	<!-- /.col-lg-12 -->    
</div>
<!-- /.row -->
</div>

{!! Html::script('assets/admin/js/angular.js') !!}

{!! Html::script('assets/admin/js/angular.js') !!}

<script>

var app = angular.module('plunker', []);

        app.controller('MainCtrl', ['$scope', '$interval', function($scope, $interval) {
            
            /* var interval = $interval(function() {
             
               var sess_id = jQuery("#sess_id").val();
			   if(sess_id != ""){
			   var token = jQuery("input[name=_token]").val();
					var request = jQuery.ajax({
						type:"post",
						url:"getsesMtx",
						data:{sess_id:sess_id,_token:token}
					});
					request.done(function (response){
						jQuery(".loading_img").hide();
						jQuery(".matrix_slider").show();
						jQuery('#ses_mtrx').html(response.html); 
						var newval = response.sessrn-6;
					
						var container = jQuery('.matrix_slider'),
							scrollTo = jQuery('.s_'+newval);
							

						container.scrollTop(
							scrollTo.offset().top - container.offset().top + container.scrollTop()
						);
						jQuery('.s_'+response.sessrn).css('background','#3A9D3A');
						
					});
					
				    
			   }else{
				   return true;
			   }
				
            }, 9000);		 */				 
			/* var interval = $interval(function() {
				var sess_id = jQuery("#sess_id").val();
				if(sess_id != ""){
					$.get("http://fairsession.com/bg.jpg",function(d){
						
						}).error(function(){
							location.reload();
						}); 
				}else{
					return true;
				} 
			}, 2000); */
        }]); 
</script>
 
@include('templates/admin-footer')
   
@endsection

