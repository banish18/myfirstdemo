<?php 
	use App\User;
?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			   <h2 class="page-header">User Management</h2>
			   <a href="<?php echo e(url('add-user')); ?>">Create User</a>
			   <section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section>
			</div> 
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
					<table class="table table-striped table-bordered table-hover">
					<?php echo csrf_field(); ?>

						<thead>
							<tr>
								<th>#</th>
								<th>Username</th>
								<?php if($loggedUser->user_type == 1): ?>
									<th>Email</th>
								<?php endif; ?>	
								<?php if($loggedUser->user_type != 1): ?>
									<th>Userid</th>
								<?php endif; ?>	
								<th>Mobile</th>
								<th>Password</th>
								<?php if($loggedUser->user_type == 1): ?>
									<th>Limit</th>
								<?php endif; ?>
								<th>Credit</th>
								<th>Rate</th>
								<th>Amount</th>
								<th>Min Bet</th>
								<th>Max Bet</th>
								<th>Commission</th>
								<th>Comm1 User</th>
								<th>Comm2</th>
								<th>Comm2 User</th>
								<th>Comm3</th>
								<th>Comm3 User</th>
								<th>Pati1</th>
								<th>Pati1 User</th>
								<th>Pati2</th>
								<th>Pati2 User</th>
								<th>Pati3</th>
								<th>Pati3 User</th>
								<th>Action</th>								
							</tr>
						</thead>
						<tbody>
						<?php if($users): ?>
							<?php $i = 1; 
								
							?>
							<?php foreach($users as $user): ?>
							<?php 
								$amount = $user->rate*$user->balance;
							?>
							<?php if($loggedUser->user_type == 1): ?>
								<tr class="diff-sess-u">
							<?php else: ?>
								<tr>
							<?php endif; ?>
							
									
									<?php if($loggedUser->user_type == 1): ?>
										<td onclick="showUsers('<?php echo e($user->id); ?>')"><?php echo e($i); ?></td>
									<?php else: ?>
										<td><?php echo e($i); ?></td>
									<?php endif; ?>	
									<?php if($loggedUser->user_type == 1): ?>
										<td onclick="showUsers('<?php echo e($user->id); ?>')"><?php echo e(strtoupper($user->name)); ?></td>
									<?php else: ?>
										<td><?php echo e($user->name); ?></td>
									<?php endif; ?>	
									<?php if($loggedUser->user_type == 1): ?>
										<td onclick="showUsers('<?php echo e($user->id); ?>')"><?php echo e($user->email); ?></td>
									<?php endif; ?>
									<?php if($loggedUser->user_type != 1): ?>
										<td><?php echo e($user->userid); ?></td>
									<?php endif; ?>
									<?php if($loggedUser->user_type == 1): ?>
										<td onclick="showUsers('<?php echo e($user->id); ?>')"><?php echo e($user->mobile); ?></td>
										<td onclick="showUsers('<?php echo e($user->id); ?>')"><?php echo e($user->show_pass); ?></td>	
									<?php else: ?>
										<td><?php echo e($user->mobile); ?></td>
										<td><?php echo e($user->show_pass); ?></td>
									<?php endif; ?>		
									<?php if($loggedUser->user_type == 1): ?>
										<td onclick="showUsers('<?php echo e($user->id); ?>')"><?php echo e($user->limit); ?></td>
									<?php endif; ?>
									<?php if($loggedUser->user_type == 1): ?>
									<td onclick="showUsers('<?php echo e($user->id); ?>')"><?php echo e($user->balance); ?></td>
									<td onclick="showUsers('<?php echo e($user->id); ?>')"><?php echo e($user->rate); ?></td>
									<td onclick="showUsers('<?php echo e($user->id); ?>')"><?php echo e($amount); ?></td>
									<?php else: ?>
									<td><?php echo e($user->balance); ?></td>
									<td><?php echo e($user->rate); ?></td>
									<td><?php echo e($amount); ?></td>
									<?php endif; ?>
									
									<?php if($loggedUser->user_type == 1): ?>
									<td onclick="showUsers('<?php echo e($user->id); ?>')"><?php echo e($user->min_bet); ?></td>
									<td onclick="showUsers('<?php echo e($user->id); ?>')"><?php echo e($user->max_bet); ?></td>
									<td onclick="showUsers('<?php echo e($user->id); ?>')"><?php echo e($user->commition); ?></td>
									<?php else: ?>
									<td><?php echo e($user->min_bet); ?></td>
									<td><?php echo e($user->max_bet); ?></td>
									<td><?php echo e($user->commition); ?></td>
									<?php endif; ?>
									
									<td><?php echo e($user->comm_1); ?></td>
									<td><?php echo e($user->getUserName($user->comm1_user)); ?></td>
									<td><?php echo e($user->comm_2); ?></td>
									<td><?php echo e($user->getUserName($user->comm2_user)); ?></td>
									<td><?php echo e($user->comm_3); ?></td>
									<td><?php echo e($user->getUserName($user->comm3_user)); ?></td>
									<td><?php echo e($user->patti_1); ?></td>
									<td><?php echo e($user->getUserName($user->patti1_user)); ?></td>
									<td><?php echo e($user->patti_2); ?></td>
									<td><?php echo e($user->getUserName($user->patti2_user)); ?></td>
									<td><?php echo e($user->patti_3); ?></td>
									<td><?php echo e($user->getUserName($user->patti3_user)); ?></td>
									
									
									<td><a href="<?php echo e(route('update-user',['id' => $user->id])); ?>" title="Update"><i class="fa fa-edit fa-1.5x"></i></a>
									<?php if($loggedUser->user_type == 1): ?>
										<!--i class="fa fa-italic fa-1x"></i>
										<a href="<?php echo e(url('delete-user',array('id' => $user->id))); ?>" title="Delete"><i class="fa fa-trash fa-1.5x"></i></a-->
										<?php if($user->user_type != '2' && $user->user_type !='1'): ?>
											<!--i class="fa fa-italic fa-1x"></i>
											<a href="javascript:void(0)" title="Make Admin" onclick="setAdmin('<?php echo e($user->id); ?>')">Make As Admin</a-->
										<?php else: ?>	
											<!--i class="fa fa-italic fa-1x"></i>
											<a href="javascript:void(0)" title="Remove Admin" onclick="removeAdmin('<?php echo e($user->id); ?>')">Remove As Admin</a-->
										<?php endif; ?>
										<?php if($user->isActive != '1'): ?>
											<i class="fa fa-italic fa-1x"></i>
											<a href="javascript:void(0)" class="unsus" title="Suspend User" onclick="suspendUser('<?php echo e($user->id); ?>')">Suspend</a>
										<?php else: ?>	
											<i class="fa fa-italic fa-1x"></i>
											<a href="javascript:void(0)" class="sus"  title="Unsuspend User" onclick="unsuspendUser('<?php echo e($user->id); ?>')">Unsuspend</a></td>
										<?php endif; ?>
										
									<?php endif; ?>
							</tr>
								<?php $i++; ?>
							<?php endforeach; ?>
						<?php endif; ?>
						</tbody>
					</table>
					<div class="ad_us">
						<h2></h2>
						<table class="table table-striped table-bordered table-hover">
						<?php echo csrf_field(); ?>

							<thead>
								<tr>
									<th>#</th>
									<th>Username</th>
									<th>Userid</th>
									<th>Mobile</th>
									<th>Password</th>
									<th>Credit</th>
									<th>Rate</th>
									<th>Amount</th>
									<th>Action</th>	
								</tr>
							</thead>
							<tbody id="ad_users">
							
							</tbody>
						</table>
					</div>
				</div>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div class="loading_img">
			<img src="<?php echo e(asset('assets/clock-loading.gif')); ?>" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>