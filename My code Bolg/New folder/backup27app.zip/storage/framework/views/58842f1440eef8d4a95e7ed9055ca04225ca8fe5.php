<?php $__env->startSection('content'); ?>

<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">

        <div class="row">

            <div class="col-md-4 col-md-offset-4">

                <div class="login-panel panel panel-default">

                    <div class="panel-heading">

                        <h3 class="panel-title">App Version</h3>

                    </div>

                    <div class="panel-body">

                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/postVersion')); ?>">

						<?php echo csrf_field(); ?>


                            <fieldset>

								<div class="form-group">

									<label for="inputEmail3" class="col-lg-3 control-label ">App Version:</label>

									<div class="col-lg-6">

										<?php echo Form::text('version',$cVersion,$attributes = array("class"=>"form-control","id"=>"inputEmail3","placeholder"=>"Version")); ?>


									</div>

								</div>
								<div class="form-group">

									<div class="col-sm-offset-8 col-sm-0">

										<button type="submit" class="btn btn-primary btn-sm">Update</button>

									</div>

								</div>

                            </fieldset>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    </div>

<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>