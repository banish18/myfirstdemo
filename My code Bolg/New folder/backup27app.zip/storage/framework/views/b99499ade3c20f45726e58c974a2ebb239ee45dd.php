<?php 
	use App\User;
	use App\Heads;
?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			   <h2 class="page-header">Transfer Ledger</h2>
			   <section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section>
			</div> 
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
				<?php use App\Session; 
					$session = new Session;
					$user = new User;
					$head = new Heads;
				?>
					<table class="table table-striped table-bordered table-hover">
					<?php echo csrf_field(); ?>

						<thead>
							<tr>
								<th>Date</th>
								<th>Description</th>
								<th>Debit</th>
								<th>Credit</th>							
							</tr>
						</thead>
						<tbody>
						<?php if($ledgers): ?>
							<?php $i = 1; ?>
							<?php foreach($ledgers as $ledger): ?>
								<?php 
								/* if(is_int($ledger->account_head2)){
									echo "int";
									$ac2 = $user->getUserName($ledger->account_head2);
								}else{
									echo "nonint";
									$ac2 = $head->getHeadName($ledger->account_head2);
								} */
								$des = '('.$session->getSessdesc($ledger->desc).')';
								?>
								<?php if($ledger->debit_credit == "C"): ?>
									<?php 
										$desc = "";
										$credit = $ledger->amount;
										$debit = "";
									?>
								<?php else: ?>
										<?php 
											$desc = "";
											$debit = $ledger->amount;
											$credit = "";
										?>
								<?php endif; ?>	
								<tr>
									<td><?php echo e($ledger->date); ?></td>
									<td class="lft_algn"><?php echo e($ledger->acount_head.'-'.$ledger->account_head2); ?></td>
									<td><?php echo e($debit); ?></td>
									<td><?php echo e($credit); ?></td>
								</tr>
								<?php $i++; ?>
							<?php endforeach; ?>
							<tr><td></td><th>Balance</th><th colspan="2"><?php echo e($ledgersview); ?></th></tr>
						<?php endif; ?>
						</tbody>
					</table>
				</div>
				<!-- /.table-responsive -->
			</div>
			<?php echo $ledgers->render(); ?>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div class="loading_img">
			<img src="<?php echo e(asset('assets/clock-loading.gif')); ?>" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>