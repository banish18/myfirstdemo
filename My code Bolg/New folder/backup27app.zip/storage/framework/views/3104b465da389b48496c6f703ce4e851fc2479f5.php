<?php 
	use App\User;
	use App\Heads;
?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			   <h2 class="page-header">Session Wise Report</h2>
			   <section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section>
			</div> 
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
				<?php use App\Session; 
					$session = new Session;
					$user = new User;
					$head = new Heads;

				?>
					<table class="table table-striped table-bordered table-hover">
					<?php echo csrf_field(); ?>

						<thead>
							<tr>
								<th>Date</th>
								<th>Session Description</th>
								<th>Amount </th>						
							</tr>
						</thead>
						<tbody>
						<?php if(!$ledgers->isEmpty()): ?>
							<?php foreach($ledgers as $ledger): ?>
							<?php 
								if($ledger->amount > 0){
									$gt = "Profit";
								}else{
									$gt = "Loss";
								}
							?>
								<tr onclick="getUSessRes('<?php echo e($ledger->sess_id); ?>','<?php echo e($uid); ?>')" class="diff-sess-u">
									<td><?php echo e(date('d-m-Y',strtotime($ledger->date))); ?></td>
									<td><?php echo e($session->getSessdesc($ledger->sess_id)); ?></td>
									<td><?php echo e(abs($ledger->amount).'('.$gt.')'); ?></td>
								</tr>
							<?php endforeach; ?>
							<?php else: ?>
							<tr><td>No Records</td></tr>
						<?php endif; ?>
						</tbody>
					</table> 
					<div class="ad_us">
						<h2></h2>
						<h3></h3>
						<div class="ses_rp2">
						<table class="table table-striped table-bordered table-hover">
						<?php echo csrf_field(); ?>

							<thead>
								<tr>
									<th>Runs</th>
									<th>Points</th>
									<th>Rate</th>
									<th>Y/N</th>
									<th>Amount</th>								
								</tr>
							</thead>
							<tbody id="ad_users">
							
							</tbody>
						</table>
						</div>
					</div>
				</div>
				<!-- /.table-responsive -->
			</div>
			<?php echo $ledgers->render(); ?>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div class="loading_img">
			<img src="<?php echo e(asset('assets/clock-loading.gif')); ?>" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>