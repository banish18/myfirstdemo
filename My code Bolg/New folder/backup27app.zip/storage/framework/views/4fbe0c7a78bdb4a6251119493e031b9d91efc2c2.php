<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section>	
			     <section class="content-header">
                    <h1>Ladger Entry</h1>
                    <ol class="breadcrumb">
                        <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Ladger Entry</li>
                    </ol>
                </section>
			</div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				 <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
              

                <!-- Main content -->
				<?php if(!empty($errors) && count($errors) > 0): ?>
				 <ul>
				  <?php foreach($errors->all() as $error): ?>
				   <li><?php echo e($error); ?></li>
				  <?php endforeach; ?>
				 </ul>
				<?php endif; ?> 
                
                <section class="content">
                    <div class='row'>
                    <div class='col-lg-12'>
               <?php echo Form::open(array('route' => 'add-post-ledger','method' => 'post','class'=>'form-horizontal','role'=>'form','autocomplete'=>'off')); ?>

					<?php echo csrf_field(); ?>

                    <div class='col-lg-6'>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Date:</label>
							<div class="col-lg-6">
								<?php echo Form::text('ldate',$date,$attributes = array("class"=>"form-control","id"=>"ldate","placeholder"=>"Date")); ?>

							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Debit:</label>
							<div class="col-lg-6">
								<?php echo Form::text('debit','',$attributes = array("class"=>"form-control","id"=>"dusers","placeholder"=>"Debit", "onclick"=>"showDusers()")); ?>

								<ul id="dusers_list"></ul>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Credit:</label>
							<div class="col-lg-6">
								<?php echo Form::text('credit','',$attributes = array("class"=>"form-control","id"=>"cusers","placeholder"=>"Credit","onclick"=>"showCusers()")); ?>

								<ul id="cusers_list"></ul>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Amount:</label>
							<div class="col-lg-6">
								<?php echo Form::text('amount','',$attributes = array("class"=>"form-control","id"=>"amount","placeholder"=>"Amount")); ?>

							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Description:</label>
							<div class="col-lg-9">
								<textarea class="form-control" placeholder="Description" name="desc" id="desc"></textarea>
							</div>
						</div>	
						<div class="form-group">
							<div class="col-lg-10"></div>	
							<div class="col-sm-offset-2 col-sm-0">
								<button type="submit" class="btn btn-primary btn-sm" onclick="return setLedgerVal()">Add</button>
							</div>
						</div> 
					</div>
					
					
						<input type="hidden" name="uusr_id" id="uusr_id" />
						<input type="hidden" name="uusr_name" id="uusr_name" />
						<input type="hidden" name="cusr_id" id="cusr_id" />
						<input type="hidden" name="cusr_name" id="cusr_name" />
						
						<input type="hidden" name="uhd_id" id="uhd_id" />
						<input type="hidden" name="chd_id" id="chd_id" />
                <?php echo Form::close(); ?> 
                       </div> </div>
                    </div>
                </section>

				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		
		<!-- /.panel -->
		<!-- /.panel -->
		<div class="loading_img">
			<img src="<?php echo e(asset('assets/clock-loading.gif')); ?>" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>