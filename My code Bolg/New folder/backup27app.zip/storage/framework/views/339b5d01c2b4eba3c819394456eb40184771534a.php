
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
			   <h2 class="page-header">Session Wise Report</h2>
			   <section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section>
			</div> 
			<!-- /.panel-heading -->
			<div class="panel-body">
				<div class="table-responsive">
				<?php use App\Session; 
					$Asession = new Session;
				?>
					<div class='col-lg-12'>
					<div class="form-group">
							<div class="col-lg-4">
								<label for="inputEmail3" class="col-lg-12 control-label ">Sessions:</label>
								<div class="col-lg-12">
									<select class="form-control" id="sess_id">
										<?php foreach($sessions as $session): ?>
											<option value="<?php echo e($session->id); ?>"><?php echo e($session->over); ?></option>
										<?php endforeach; ?>
										<option>1</option>
									</select>
								</div>
							</div>
							<div class="col-lg-2">
								<div class="form-group">
									<input type="button" class="col-lg-12 control-label btn btn-primary" style="margin-top:20px;" value="Submit" onclick="getUsersSwsRes()"/>	
								</div>
							</div>
					</div>		
					</div>
					<div class="sh_ss">
					<h3>Net Loss/Profit : <b id="nt_lp"></b></h3>
					<div class="ses_rp">
						
						<table class="table table-striped table-bordered table-hover">
						<?php echo csrf_field(); ?>

							<thead>
								<tr>
									<th>Date</th>
									<th>Admin</th>
									<th>Session Description</th>
									<th>Amount </th>						
								</tr>
							</thead>
							
							<tbody id="show_sessions">
								
							</tbody>
						</table>
						
					</div>	
					<div class="ad_us">
						<div class="ses_rp2">
						<table class="table table-striped table-bordered table-hover">
						<?php echo csrf_field(); ?>

							<thead>
								<tr>
									<th>Date</th>
									<th>User</th>
									<th>Session Description</th>
									<th>Amount </th>						
								</tr>
							</thead>
							<tbody id="ad_users">
							
							</tbody>
						</table>
						</div>
					</div>
					
					</div>
					<div id="single_ad_us">
						<h2></h2>
						<h3></h3>
						<div class="ses_rp2">
						<table class="table table-striped table-bordered table-hover">
						<?php echo csrf_field(); ?>

							<thead>
								<tr>
									<th>Runs</th>
									<th>Points</th>
									<th>Rate</th>
									<th>Y/N</th>
									<th>Amount</th>								
								</tr>
							</thead>
							<tbody id="single_ad_users">
							
							</tbody>
						</table>
						</div>
					</div>
				</div>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div class="loading_img">
			<img src="<?php echo e(asset('assets/clock-loading.gif')); ?>" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>