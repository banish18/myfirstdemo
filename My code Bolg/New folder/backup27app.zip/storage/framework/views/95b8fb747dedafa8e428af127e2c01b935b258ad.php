<?php $__env->startSection('content'); ?>
<?php echo $__env->make('templates/admin-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<!-- /.panel-heading -->
			<div class="panel-body">
			<section class="seccess">
					<?php if(Session::has('flash_message')): ?>
						<div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em></div>
					<?php endif; ?>
				</section>
			<?php echo csrf_field(); ?>

				<div class="table-responsive">
				<div class="my-session">
							<h3>Run Session</h3>
						</div>
					<table class="table">
						<thead>
							<th>#</th>
							<th>Description</th>
							<th>Status</th>
							<th>Runs</th>
						</thead>
						<?php $i = 1; ?>
						<tbody>
							<?php foreach($Sessions as $session): ?>
								<?php if($session->action == 1): ?>
									<?php $status = "Created"; ?>
									<?php elseif($session->action == 2 && $session->isActive == 1): ?>
										<?php $status = "Running,Suspended"; ?>
									<?php elseif($session->action == 3 && $session->isActive == 1): ?>
										<?php $status = "Running,Suspended"; ?>	
									<?php elseif($session->action == 3 && $session->isActive == 0): ?>
										<?php $status = "Running,Running Live"; ?>	
									<?php elseif($session->action == 4 && $session->isActive == 1): ?>	
										<?php $status = "Declared"; ?>
									<?php else: ?>	
										<?php $status = "Suspended"; ?>
								<?php endif; ?>	
								<tr onclick="showPopRs(this,'<?php echo e($session->id); ?>','<?php echo e($session->amount); ?>','<?php echo e($session->action); ?>','<?php echo e($session->isActive); ?>','<?php echo e($session->sess_rate); ?>','<?php echo e($session->runs); ?>','<?php echo e($session->run_diff); ?>','<?php echo e($session->rate); ?>','<?php echo e($session->over); ?>','<?php echo e($session->select_val); ?>')" class="diff-sess active_bg_open"><td><?php echo e($session->id); ?></td><td><?php echo e($session->over); ?></td><td><?php echo e($status); ?></td><td><?php echo e($session->amount); ?></td></tr>
								<?php $i++; ?>
								
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div id="active_bg">
			<div class="sess_slide_rs">
			<div class="my-session">
			<div class="st_ct">
				<div class="col-lg-8 bd_bg">
								<div class="alrt_msg" id="alrt_msg"></div>
								<p>
								    <div class="swiper-container">
										<div class="swiper-wrapper">
											<?php foreach($numbers as $number): ?>
												<div class="swiper-slide">
												<p id ="<?php echo e($number.'_'.'85'); ?>" onclick="setNm1(<?php echo e($number); ?>,this)" class="num_slide">85</p>
												<p id ="<?php echo e($number.'_'.'90'); ?>" onclick="setNm2(<?php echo e($number); ?>,this)" class="num_slide">90</p>
												<p id="<?php echo e($number.'_'.$number); ?>" class="num_slide" onclick="setNm(<?php echo e($number); ?>,this)"><?php echo e($number); ?></p></div>
											<?php endforeach; ?>
										</div>
										<!-- Add Pagination -->
										<div class="swiper-pagination"></div> 
										<!-- Add Arrows -->
										<div class="swiper-button-next"></div>
										<div class="swiper-button-prev"></div>
										<input type="hidden" id="rtnumber" />
										<input type="hidden" id="rtnumber_1" />
										<input type="hidden" id="rtnumber_2" />
									</div>
								</p>
								<p><span><input onclick="isActivesess()" type="button" name="suspend" id="suspend" value="Unsuspend"/></span></p>
								<p><label>Run Diffrence</label><select id="rn_diff" onchange="rndiff(this)"><option value="0" id="rn_0">Null</option><option id="rn_1" value="1">1</option><option id="rn_2" value="2">2</option><option id="rn_3" value="3">3</option><option id="rn_4" value="4">4</option><option id="rn_5" value="5">5</option><option id="rn_6" value="6">6</option></select></p> 
								<p><label>Rate</label><select id="sess_rt" onchange="ssrate(this)"><option id="rt_0:0" value="0:0">Null</option><option id="rt_90:110" value="90:110">90:110</option><option id="rt_85:115" value="85:115">85:115</option><option id="rt_70:125" value="70:125">70:125</option><option id="rt_100:150" value="100:150">100:150</option><option id="rt_200:250" value="200:250">200:250</option><option id="rt_250:400" value="250:400">250:400</option></select></p>
								
								<div class="cr_sess">
									<span>
										<h3 id="sess_desc">Current Session</h3> 
										<b id="rt_1"></b>
										<b id="rt_2"></b>
										<input onclick="saveSessRate()" type="button" name="save" id="save_rt" value="Save"/>
									</span>
								</div>
								<input type="hidden" id="sess_id" />
								<input type="hidden" id="act" />
								<input type="hidden" id="num_sess_rd" />
								<input type="hidden" id="select_val" />
								
								<h2 class="sess_stat_h"><img class="news_blink_image" alt="blink_image" src="http://mindxpert.com/portal/assets/images/news-star.gif"><b>Session Waiting.........</b></h2>
								<p><button class="btn btn-default rn_sess_btnC" onclick="cls_popup()">Close</button><button class="active_bg_close btn btn-default rn_sess_btn">Close</button></p>
								
								
								
			   </div>
			   
			   <div class="col-lg-4">
							<div class="matrix_slider">
								 <table class="table">
									<thead><th>Runs</th><th>Amount</th></thead>
									<tbody id="ses_mtrx">
										
									</tbody>
								 </table>
							</div>	
						</div>
				</div>
			</div>
			</div>
		</div>
		<div id="cover"> </div> 
		<div class="loading_img rn_ldimg">
			<img src="<?php echo e(asset('assets/clock-loading.gif')); ?>" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>

<?php echo Html::script('assets/admin/js/angular.js'); ?>


<script>

var app = angular.module('plunker', []);

        app.controller('MainCtrl', ['$scope', '$interval', function($scope, $interval) {
            
            var interval = $interval(function() {
             
               var sess_id = jQuery("#sess_id").val();
			   if(sess_id != ""){
			   var token = jQuery("input[name=_token]").val();
					var request = jQuery.ajax({
						type:"post",
						url:"getsesMtx",
						data:{sess_id:sess_id,_token:token}
					});
					request.done(function (response){
						jQuery(".loading_img").hide();
						jQuery(".matrix_slider").show();
						jQuery('#ses_mtrx').html(response.html); 
					});
					//var r=Math.round(Math.random() * 3000);
					 /* $.get("http://fairsession.com/bg.jpg",function(d){
					  
					 }).error(function(){
					    //alert("Internet Stopped Working");
					    location.reload();
					 }); */
				    
			   }else{
				   return true;
			   }
				
            }, 500);						 var interval = $interval(function() {               var sess_id = jQuery("#sess_id").val();			   if(sess_id != ""){					 $.get("http://fairsession.com/bg.jpg",function(d){					 }).error(function(){					    location.reload();					 }); 			   }else{				   return true;			   }            }, 2000);
        }]); 
</script>
 
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>