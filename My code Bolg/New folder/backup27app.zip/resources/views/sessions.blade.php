@extends('layouts.app')
@section('content')
@include('templates/admin-header')
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<!-- /.panel-heading -->
			<div class="panel-body">
			<section class="seccess">
					@if(Session::has('flash_message'))
						<div class="alert alert-success"><em> {!! session('flash_message') !!}</em></div>
					@endif
				</section>
			{!! csrf_field() !!}
				<div class="table-responsive">
					<div class="col-lg-12">
						<div class="my-session">
							<h3 onclick="shSess(this)" class="ct_ses">Create Session</h3>
							<div class="slide-cont">
								<p><textarea id="over"></textarea><input type="submit" id="Create" value="Create" onclick="ctSess(this)" /><!--input onclick="isCheck()" type="button" id="act" value="Activate" class="acti_sess"/><input type="hidden" id="ac" value="1"--></p>
								<p></p>
							</div>
						</div>
					</div>
					
					<div class="all-sess">
					<div class="col-lg-12">
						<table class="table">
						<thead>
							<th>#</th>
							<th>Description</th>
							<th>Status</th>
							<th>Runs</th>
						</thead>
						<?php $i = 1; ?>
						<tbody>
							@foreach($Sessions as $session)
								@if($session->action == 1)
									<?php $status = "Created"; $runs = "0";?>
									@elseif($session->action == 2 && $session->isActive == 1)
										<?php $status = "Running,Suspended";$runs = "0"; ?>
									@elseif($session->action == 3 && $session->isActive == 1)
										<?php $status = "Running,Suspended";$runs = "0"; ?>										@elseif($session->action == 3 && $session->isActive == 0)										<?php $status = "Running,Running Live"; $runs = "0";?>	
									@elseif($session->action == 4 && $session->isActive == 1)	
										<?php $status = "Declared"; 
										$runs = $session->runs;
										?>
										
									@else	
										<?php $status = "Suspended"; 
									$runs = "0";
									?>
								@endif	
								
								<tr onclick="showPop({{ $session->id }},{{ $session->amount}},'{{ $session->isActive}}','{{ $session->action}}','{{ $session->sess_rate}}','{{ $session->runs}}','{{ $session->run_diff}}','{{ $session->rate}}')" class="diff-sess slide_open"><td>{{ $session->id }}</td><td>{{ $session->over }}</td><td>{{ $status }}</td><td>{{ $runs }}</td></tr>
								<?php $i++; ?>
							@endforeach
						</tbody>
					</table>
					<?php echo $Sessions->render(); ?>
					</div>
					</div>
				</div>
				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		<!-- /.panel -->
		<div id="slide">
			<div class="sess_slide">
				<div class="alrt_msg" id="alrt_msg"></div>
				<p><!--input type="button" id="active" value="Activate" onclick="setStat(this)"/><input type="button" id="inactive" value="Inactivate" onclick="setStat(this)" /--><input type="button" id="declare" value="Declare" onclick="setStat(this)"/><input type="button" id="undeclare" value="Undeclare" onclick="setStat(this)"/><input type="button" id="runsess" value="Run" onclick="runSess(this)" class="active_bg_open"/></p>
				<div class="dec_bx"><input type="text" id="amount" /><input type="button" id="save" value="Save" onclick="changeDelareRate()"/></div>
				<br /><p><button class="slide_close btn btn-default">Close</button></p>
				<input type="hidden" id="sess_id" class="sess_id" />
				<input type="hidden" id="isAct" />
				<input type="hidden" id="st" />
				<input type="hidden" id="rn" />
				<input type="hidden" id="rd" />
				<input type="hidden" id="rt" />
				<input type="hidden" id="actionsess" />
			</div>
		</div>
		<div id="active_bg">
		
			<div class="sess_slide_rs">
			<div class="my-session">
				<div class="st_ct">
								<div class="alrt_msg" id="alrt_msg"></div>
								<h2 class="sess_stat_h"><img class="news_blink_image" alt="blink_image" src="http://mindxpert.com/portal/assets/images/news-star.gif"><b>Session Waiting.........</b></h2>
								<p>
								    <div class="swiper-container">
										<div class="swiper-wrapper">
											@foreach($numbers as $number)
												<div class="swiper-slide" id="{{ $number }}" onclick="setNm({{ $number }},this)">{{ $number }}</div>
											@endforeach
										</div>
										<!-- Add Pagination -->
										<div class="swiper-pagination"></div> 
										<!-- Add Arrows -->
										<div class="swiper-button-next"></div>
										<div class="swiper-button-prev"></div>
										<input type="hidden" id="rtnumber" />
									</div>
								</p>
								<p><label>Run Diffrence</label><select id="rn_diff" onchange="rndiff(this)"><option value="rn_0" id="null">Null</option><option id="rn_1" value="1">1</option><option id="rn_2" value="2">2</option><option id="rn_3" value="3">3</option><option id="rn_4" value="4">4</option><option id="rn_5" value="5">5</option><option id="rn_6" value="6">6</option></select></p> 
								<p><label>Rate</label><select id="sess_rt" onchange="ssrate(this)"><option id="rt_0:0" value="0:0">Null</option><option id="rt_90:110" value="90:110">90:110</option><option id="rt_85:115" value="85:115">85:115</option><option id="rt_70:125" value="70:125">70:125</option><option id="rt_100:150" value="100:150">100:150</option><option id="rt_200:250" value="200:250">200:250</option><option id="rt_250:400" value="250:400">250:400</option></select></p>
								
								<div class="cr_sess">
									<span>
										<h3>Current Session</h3>
										<b id="rt_1"></b>
										<b id="rt_2"></b>
										<input onclick="saveSessRate()" type="button" name="save" id="save_rt" value="Save"/>
									</span> 
								</div>
								<input type="hidden" class="sess_id" id="sess_id" />
								<input type="hidden" id="act" />
								<p><span><input onclick="isActivesess()" type="button" name="suspend" id="suspend" value="Unsuspend"/></span></p>
								<p><button class="btn btn-default rn_sess_btnC" onclick="cls_popup()">Close</button><button class="active_bg_close btn btn-default rn_sess_btn">Close</button></p>
								
							</div>
							</div>
			</div>
			
		</div>
		<div id="cover"> </div> 
		<div class="loading_img rn_ldimg">
			<img src="{{ asset('assets/clock-loading.gif')}}" />
		</div>
	</div>
	
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
 
@include('templates/admin-footer')
   
@endsection

