@extends('layouts.app')
@section('content')
@include('templates/admin-header')
<div id="page-wrapper">
<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<section class="seccess">
					@if(Session::has('flash_message'))
						<div class="alert alert-success"><em> {!! session('flash_message') !!}</em></div>
					@endif
				</section>	
			     <section class="content-header">
                    <h1>Ledger Entry</h1>
                    <ol class="breadcrumb">
                        <li><a href="{{ url('dashboard') }}"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Ladger Entry</li>
                    </ol>
                </section>
			</div>
			<!-- /.panel-heading -->
			<div class="panel-body">
				 <!-- Right side column. Contains the navbar and content of the page -->
            <aside class="right-side">
                <!-- Content Header (Page header) -->
              

                <!-- Main content -->
				@if (!empty($errors) && count($errors) > 0)
				 <ul>
				  @foreach ($errors->all() as $error)
				   <li>{{ $error }}</li>
				  @endforeach
				 </ul>
				@endif 
                
                <section class="content">
                    <div class='row'>
                    <div class='col-lg-12'>
               {!! Form::open(array('route' => 'add-post-ledger','method' => 'post','class'=>'form-horizontal','role'=>'form','autocomplete'=>'off')) !!}
					{!! csrf_field() !!}
                    <div class='col-lg-6'>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Date:</label>
							<div class="col-lg-6">
								{!! Form::text('ldate',$date,$attributes = array("class"=>"form-control","id"=>"ldate","placeholder"=>"Date")) !!}
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Debit:</label>
							<div class="col-lg-6">
								{!! Form::text('debit','',$attributes = array("class"=>"form-control","id"=>"dusers","placeholder"=>"Debit", "onclick"=>"showDusers()")) !!}
								<ul id="dusers_list"></ul>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Credit:</label>
							<div class="col-lg-6">
								{!! Form::text('credit','',$attributes = array("class"=>"form-control","id"=>"cusers","placeholder"=>"Credit","onclick"=>"showCusers()")) !!}
								<ul id="cusers_list"></ul>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Amount:</label>
							<div class="col-lg-6">
								{!! Form::text('amount','',$attributes = array("class"=>"form-control","id"=>"amount","placeholder"=>"Amount")) !!}
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-lg-3 control-label ">Description:</label>
							<div class="col-lg-9">
								<textarea class="form-control" placeholder="Description" name="desc" id="desc"></textarea>
							</div>
						</div>	
						<div class="form-group">
							<div class="col-lg-10"></div>	
							<div class="col-sm-offset-2 col-sm-0">
								<button type="submit" class="btn btn-primary btn-sm" onclick="return setLedgerVal()">Add</button>
							</div>
						</div> 
					</div>
					
					
						<input type="hidden" name="uusr_id" id="uusr_id" />
						<input type="hidden" name="uusr_name" id="uusr_name" />
						<input type="hidden" name="cusr_id" id="cusr_id" />
						<input type="hidden" name="cusr_name" id="cusr_name" />
						
						<input type="hidden" name="uhd_id" id="uhd_id" />
						<input type="hidden" name="chd_id" id="chd_id" />
                {!! Form::close() !!} 
                       </div> </div>
                    </div>
                </section>

				<!-- /.table-responsive -->
			</div>
			<!-- /.panel-body -->
		</div>
		
		<!-- /.panel -->
		<!-- /.panel -->
		<div class="loading_img">
			<img src="{{ asset('assets/clock-loading.gif')}}" />
		</div>
	</div>
	<!-- /.col-lg-12 -->
</div>
<!-- /.row -->
</div>
@include('templates/admin-footer')
@endsection
