<?php
function getConnected($host,$user,$pass,$db) {
   $mysqli = new mysqli($host, $user, $pass, $db);
   if($mysqli->connect_error) 
    die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
   return $mysqli;
}
$mysqli = getConnected("localhost","s9mindxp_schejad","demo@1234",'s9mindxp_schej');   
?>