<?php
require('fpdf.php');
function getConnected($host,$user,$pass,$db){
	$mysqli = new mysqli($host,$user,$pass,$db);
	if($mysqli->connect_error)
		die('Connect Error('.mysqli_connect_errno(). ') '.mysqli_connect_error());
	return $mysqli;
}
$mysqli = getConnected('localhost','s9mindxp_portal','0%7$TF-z;ysH','s9mindxp_portal');

/**
	code to get user name
*/

function getUser($id){
	global $mysqli;
	$selectRes = $mysqli->query("select * from users where id=".$id);
	if($selectRes->num_rows > 0){
		$userrow = $selectRes->fetch_object();
	}else{
		$userrow = [];
	}
	return $userrow;
}

/**
	code to generate payslips pdf format
*/

if(isset($_GET["id"]) && $_GET["id"] != ""){
		$uid = $_GET["id"];
		$pName = '';
		class PDF extends FPDF
		{
			// Page header
			function Header()
			{
				global $mysqli;
				global $uid;
				global $pName;
				$selectRes = $mysqli->query("select * from payroll where id=".$uid);
				if($selectRes->num_rows > 0){
					$payrollrow = $selectRes->fetch_array(MYSQLI_ASSOC);
					$date 	= date('M Y',strtotime($payrollrow['dop']));
					$pName 	= getUser($payrollrow['uid'])->f_name.'_'.$date;
				}else{
					$msg = 'somthing went wrong';
					$date = "ND";
				}
				// Logo
				$this->Image('../logo.png',150,6,50);
				// Arial bold 15
				$this->SetFont('Arial','B',12);
				// Move to the right
			   
				// Title
				$this->Cell(30,10,'Payslip '.$date);
				// Line break
				$this->Ln();
				
				
				// Line break
				$this->Ln(20);
			}

			// Page footer
			function Footer()
			{
				// Position at 1.5 cm from bottom
				$this->SetY(-15);
				// Arial italic 8
				$this->SetFont('Arial','',8);
				// Page number
				$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'R');
			}
			
			// Colored table
			function FancyTable($pdf)
			{
				global $mysqli;
				$selectRes = $mysqli->query("select * from payroll where id=".$_GET["id"]);
				if($selectRes->num_rows > 0){
					$payrollrow = $selectRes->fetch_array(MYSQLI_ASSOC);
					$pdf->SetFont('Arial','B',10);
					$pdf->Cell(55,5,'Mr. '.getUser($payrollrow['uid'])->f_name.' '.getUser($payrollrow['uid'])->l_name.'',1,0,'',0);
					$pdf->SetFont('Arial','B',10);
					$pdf->Cell(140,5,'',1,1,'',0);
					$pdf->SetTextColor(255,255,255);
					$pdf->SetFillColor(30,144,255);
					$pdf->Cell(65,7,'Employee Details',1,0,'',true);
					$pdf->Cell(80,7,'Payment & Leave Details',1,0,'',true);
					$pdf->Cell(50,7,'Location Details',1,0,'',true);
					$pdf->SetTextColor(000);
					$pdf->SetFont('Arial','',8);
					// Line break
					$pdf->Ln();
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(32.5,5,'Emp No.',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(32.5,5,getUser($payrollrow['uid'])->unQid,1,0,'',0);
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(32.5,5,'Bank Name',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(47.5,5,getUser($payrollrow['uid'])->bank_author,1,0,'',0);
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(24.5,5,'Location',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(25.5,5,getUser($payrollrow['uid'])->city,1,0,'',0);
					// Line break
					$pdf->Ln();
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(32.5,5,'Dsgn.',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(32.5,5,getUser($payrollrow['uid'])->e_department,1,0,'',0);
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(32.5,5,'Acc',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(47.5,5,getUser($payrollrow['uid'])->acc_no,1,0,'',0);
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(24.5,5,'Base Br.',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(25.5,5,getUser($payrollrow['uid'])->branch,1,0,'',0);
					
					
					// Line break
					$pdf->Ln();
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(32.5,5,'Grade',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(6.5,5,'C2',1,0,'',0);
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(7.5,5,'DOJ',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(18.5,5,date('D-M-Y',strtotime(getUser($payrollrow['doj'])->branch)),1,0,'',0);
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(32.5,5,'Days Paid',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(47.5,5,getUser($payrollrow['doj'])->for_days,1,0,'',0);
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(24.5,5,'Depute Br.',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(25.5,5,getUser($payrollrow['doj'])->company,1,0,'',0);
					
					
					// Line break
					$pdf->Ln();
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(32.5,5,'PAN',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(32.5,5,'A01555dsf',1,0,'',0);
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(32.5,5,'LEAVE BALANCE',1,0,'',0);
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(6,5,'EL',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(9.5,5,'52.00',1,0,'',0);
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(6,5,'SL',1,0,'',0);
					$pdf->SetFont('Arial','',8);
					$pdf->Cell(9.5,5,'30.59',1,0,'',0);
					$pdf->SetFont('Arial','B',8);
					$pdf->Cell(6,5,'CL',1,0,'B',0);
					$pdf->Cell(10.5,5,'3.50',1,0,'',0);
					$pdf->Cell(50,5,'',1,0,'',0);
					// Line break
					$pdf->SetFont('Arial','B',10);
					$pdf->Ln();
					$pdf->SetTextColor(255,255,255);
					$pdf->SetFillColor(30,144,255);
					$pdf->Cell(52.5,5,'Earnings',1,0,'',true);
					$pdf->Cell(30,5,'Arrears',1,0,'',true);
					$pdf->Cell(30,5,'Current',1,0,'',true);
					$pdf->Cell(52.5,5,'Deductions',1,0,'',true);
					$pdf->Cell(30,5,'Amount',1,0,'',true);
					$pdf->SetFont('Arial','',8);
					
					$selectsalaryRes = $mysqli->query("select * from salary_template where uid=".$payrollrow['uid']);
					if($selectsalaryRes->num_rows > 0){
						$salaryrow = $selectsalaryRes->fetch_array(MYSQLI_ASSOC);
						// Line break
						$pdf->Ln();
						$pdf->SetTextColor(000);
						$pdf->Cell(52.5,5,'Basic Salary',1,0,'',0);
						$pdf->Cell(30,5,'',1,0,'',0);
						$pdf->Cell(30,5,$salaryrow['basicsalary'],1,0,'',0);
						$pdf->Cell(52.5,5,'Provident Fund',1,0,'',0);
						$pdf->Cell(30,5,$salaryrow['employee_CPF'],1,0,'',0);
						$totalAllowence 	= json_decode($salaryrow['total_allowance_detail']);
						$totalAllowencevalue = json_decode($salaryrow['total_allowence_value']);
						$total_deduction_detail = json_decode($salaryrow['total_deduction_detail']);
						$total_deduction_detailvalue 	= json_decode($salaryrow['total_deduction_value']);
						$totalEr = $salaryrow['basicsalary'];
						$totalDed = '';
						if(count($totalAllowence) > count($total_deduction_detail)){
							if(!empty($totalAllowence)){
								$i = -1;
								foreach($totalAllowence as $totalAl){
									$totalEr = $totalEr+$totalAllowencevalue[$i];
									$i++;
									// Line break
									$pdf->Ln();
									$pdf->SetTextColor(000);
									$pdf->Cell(52.5,5,$totalAl,1,0,'',0);
									$pdf->Cell(30,5,'',1,0,'',0);
									$pdf->Cell(30,5,$totalAllowencevalue[$i],1,0,'',0);
									
									if(!empty($total_deduction_detail)){
										$j = -1;
										$totalDearray = [];
										$totalValDearray = [];
										foreach($total_deduction_detail as $totalDe){
											$j++;
											
											if($i == $j){
												$totalDed = $totalDed+$total_deduction_detailvalue[$j];
												$pdf->Cell(52.5,5,$totalDe,1,0,'',0);
												$pdf->Cell(30,5,$total_deduction_detailvalue[$j],1,0,'',0);
											}
										}
									}
								}
							}
						}else{
							if(!empty($total_deduction_detail)){
								$i = -1;
								foreach($total_deduction_detail as $totalDe){
									$i++;
									$totalDe = $totalDe+$total_deduction_detailvalue[$i];
									// Line break
									$pdf->Ln();
									$pdf->SetTextColor(000);
									
									if(!empty($totalAllowence)){
										$j = -1;
										foreach($totalAllowence as $totalAl){
											$totalEr = $totalEr+$totalAllowencevalue[$j];
											$j++;
											if($i == $j){
												$pdf->Cell(52.5,5,$totalAl,1,0,'',0);
												$pdf->Cell(30,5,'',1,0,'',0);
												$pdf->Cell(30,5,$totalAllowencevalue[$j],1,0,'',0);
											}
										}
									}
									$pdf->Cell(52.5,5,$totalDe,1,0,'',0);
									$pdf->Cell(30,5,$total_deduction_detailvalue[$j],1,0,'',0);
								}
							}
						}
					
						
						$netPay = $totalEr-$totalDed;
						// Line break
						$pdf->Ln();
						// Line break
						$pdf->Cell(52.5,25,'',1,0,'',0);
						$pdf->Cell(30,25,'',1,0,'',0);
						$pdf->Cell(30,25,'',1,0,'',0);
						$pdf->Cell(52.5,25,'',1,0,'',0);
						$pdf->Cell(30,25,'',1,0,'',0);
						// Line break
						$pdf->Ln();
						$pdf->SetFont('Arial','B',8);
						// Line break
						$pdf->Cell(52.5,7,'Total Earnings',1,0,'',0);
						$pdf->Cell(30,7,'',1,0,'',0);
						$pdf->Cell(30,7,$totalEr,1,0,'',0);
						$pdf->Cell(52.5,7,'Total Deductions',1,0,'',0);
						$pdf->Cell(30,7,$totalDed,1,0,'',0);
						// Line break
						$pdf->Ln(10);
						// Line break
						$pdf->SetFont('Arial','B',8);
						$pdf->SetTextColor(255,255,255);
						$pdf->SetFillColor(30,144,255);
						$pdf->Cell(40,10,'Retrials as on Month end',1,0,'C',true);
						$pdf->SetTextColor(000);
						$pdf->Cell(30,10,'Provident fund*',1,0,'C',0);
						$pdf->Cell(42.5,10,'1,79,565.00',1,0,'R',0);
						$pdf->SetTextColor(255,255,255);
						$pdf->SetFillColor(30,144,255);
						$pdf->Cell(52.5,10,'Net Pay',1,0,'',true);
						$pdf->SetTextColor(000);
						$pdf->Cell(30,10,$netPay,1,0,'',0);
						// Line break
						$pdf->Ln();
						$pdf->SetTextColor(255,0,0);
						$pdf->Cell(52.5,10,'*Inclusive of provisional interest',0,0,'');
						// Line break
						$pdf->SetTextColor(0,0,0);
						$pdf->Ln();
						$pdf->SetTextColor(255,255,255);
						$pdf->SetFillColor(30,144,255);
						$pdf->Cell(140,5,'Projected Annual Tax Income',1,0,'',true);
						$pdf->Cell(55.5,5,'Chapter Via Relief',1,0,'',true);
						$pdf->SetTextColor(000);
						$pdf->SetFont('Arial','',8);
						// Line break
						$pdf->Ln();
						$pdf->SetTextColor(000);
						$pdf->Cell(42.5,5,'Anual Income*',1,0,'',0);
						$pdf->Cell(30,5,'43,000,00',1,0,'',0);
						$pdf->Cell(30,5,'Net tax Income r/o',1,0,'',0);
						$pdf->Cell(42.5,5,'6,63,880.00',1,0,'',0);
						$pdf->Cell(30,5,'80C',1,0,'',0);
						$pdf->Cell(20.5,5,'24,192.00',1,0,'',0);
						// Line break
						$pdf->Ln();
						$pdf->Cell(42.5,5,'Chapter Via Relief',1,0,'',0);
						$pdf->Cell(30,5,'7,00,000,00',1,0,'',0);
						$pdf->Cell(30,5,'Total Tax Payable',1,0,'',0);
						$pdf->Cell(42.5,5,'6,63,880.00',1,0,'',0);
						$pdf->Cell(30,5,'80D',1,0,'',0);
						$pdf->Cell(20.5,5,'24,192.00',1,0,'',0);
						// Line break
						$pdf->Ln();
						$pdf->Cell(42.5,5,'',1,0,'',0);
						$pdf->Cell(30,5,'',1,0,'',0);
						$pdf->Cell(30,5,'Tax Deducted Till Date',1,0,'',0);
						$pdf->Cell(42.5,5,'6,63,880.00',1,0,'',0);
						$pdf->Cell(30,5,'',1,0,'',0);
						$pdf->Cell(20.5,5,'',1,0,'',0);
						// Line break
						$pdf->Ln();
						$pdf->Cell(42.5,5,'',1,0,'',0);
						$pdf->Cell(30,5,'',1,0,'',0);
						$pdf->Cell(30,5,'Balance Tax',1,0,'',0);
						$pdf->Cell(42.5,5,'6,63,880.00',1,0,'',0);
						$pdf->Cell(30,5,'',1,0,'',0);
						$pdf->Cell(20.5,5,'',1,0,'',0);
						// Line break
						$pdf->Ln();
						$pdf->Ln();
						$pdf->SetTextColor(255,255,255);
						$pdf->SetFillColor(30,144,255);
						$pdf->Cell(140,5,'Investment Description',1,0,'',true);
						$pdf->Cell(55.5,5,'Exemption Considered*',1,0,'',true);
						$pdf->SetTextColor(000);
						$pdf->SetFont('Arial','',8);
						// Line break
						$pdf->Ln();
						$pdf->SetTextColor(000);
						$pdf->Cell(42.5,5,'80D-Medical Premium',1,0,'',0);
						$pdf->Cell(30,5,'3,956.00',1,0,'',0);
						$pdf->Cell(30,5,'',1,0,'',0);
						$pdf->Cell(42.5,5,'',1,0,'',0);
						$pdf->Cell(30,5,'Conveyance',1,0,'',0);
						$pdf->Cell(20.5,5,'19,200',1,0,'',0);
						$pdf->Ln();
						$pdf->Cell(42.5,5,'80D-Medical Premium',1,0,'',0);
						$pdf->Cell(30,5,'3,956.00',1,0,'',0);
						$pdf->Cell(30,5,'',1,0,'',0);
						$pdf->Cell(42.5,5,'',1,0,'',0);
						$pdf->Cell(30,5,'',1,0,'',0);
						$pdf->Cell(20.5,5,'',1,0,'',0);
						$pdf->Ln();
						$pdf->Cell(42.5,5,'PF Contribution',1,0,'',0);
						$pdf->Cell(30,5,' 	24,192.00',1,0,'',0);
						$pdf->Cell(30,5,'',1,0,'',0);
						$pdf->Cell(42.5,5,'',1,0,'',0);
						$pdf->Cell(30,5,'',1,0,'',0);
						$pdf->Cell(20.5,5,'',1,0,'',0);
						// Line break
						$pdf->Ln();
						$pdf->SetTextColor(255,0,0);
						$pdf->Cell(52.5,10,'*Please Note, Annual Income is after considering the above exemption - if any.',0,0,'');
						// Line break
						$pdf->SetTextColor(0,0,0);
						$pdf->SetFont('Arial','B',8);
						$pdf->Ln();
						$pdf->Cell(52.5,10,'Payslip generated on: '.date('d M Y,H:i:s').'',0,0,'');
					}else{
						$pdf->SetTextColor(255,0,0);
						$pdf->Cell(52.5,10,'*Not Created Yet',0,0,'C');
					}
				
				}else{
					$pdf->SetTextColor(255,0,0);
					$pdf->Cell(52.5,10,'*Inclusive of provisional interest',0,0,'C');
				}
				
			}
		}

		// Instanciation of inherited class
		$pdf = new PDF();
		$pdf->AliasNbPages();
		$pdf->AddPage();
		$pdf->SetFont('Times','',14);
		$pdf->FancyTable($pdf);

		$pdf->Output($pName.'.pdf','D');
		//$pdf->Output();
	}



?>