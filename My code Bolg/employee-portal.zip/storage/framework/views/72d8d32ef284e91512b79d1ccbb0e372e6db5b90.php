<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
        <div class="page-title">
          <h1>
            Master
          </h1>
                   </div>



        <div class="row">
        <div class="col-md-2">
  <ul class="list-group">
          <li class="list-group-item active" >
           <a  href="<?php echo e(route('company')); ?>">
           <p>
           <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;Company
           </p></a>
           </li>
		   <li class="list-group-item " >
           <a  href="<?php echo e(route('employement',array('action' => 'letter-type'))); ?>">
           <p>
          <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;Letter Type
           </p></a>
           </li>
		   <li class="list-group-item " >
           <a  href="<?php echo e(route('users',array('action' => 'employee-credential'))); ?>">
           <p>
          <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;Employee Credentails
           </p></a>
           </li>
                    </ul>
        </div>
        <div class="col-md-10">

             <div class="row">
            <div class="col-md-12">
            <div class="widget-container fluid-height clearfix">
            <div class="widget-content padded clearfix">
			<div class="table-responsive">
			<ul class="master_cont">
				<li class="col-md-6"> <a  href="<?php echo e(route('company')); ?>">Company</a></li>
				<li class="col-md-6"> <a  href="<?php echo e(route('employement',array('action' => 'letter-type'))); ?>">Letter Type</a></li>
				<li class="col-md-6"> <a  href="<?php echo e(route('users',array('action' => 'employee-credential'))); ?>">Employee Credentails</a></li>
			</ul>
            </div>

            </div>
          </div></div>
          </div>
          </div></div></div>


<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="row" style="text-align:center;"><span>V3.0</span></div>
  </body></html>
  <script>
$(document).ready(function(){
	$(".pdf").click(function(){
		$("#table1").hide();
		setTimeout(function(){$("#table1").show()},1000);
		});
});
</script>
 

<script>
$(".tooltip-trigger").tooltip();
 </script>
     <script>
     /*   for mobile navigation */
     $('.navbar-toggle').click(function() {
         return $('body, html').toggleClass("nav-open");
       });

     /*
      * =============================================================================
      *   DataTables
      * =============================================================================
      */
     $("#dataTable11").dataTable({
       "sPaginationType": "full_numbers",
       aoColumnDefs: [
         {
           bSortable: false,
           aTargets: [0, -1]
         }
       ]
     });
	 </script>
  

    
<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>