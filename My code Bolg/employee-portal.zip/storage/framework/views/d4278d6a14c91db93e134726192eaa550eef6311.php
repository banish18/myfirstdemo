<?php $__env->startSection('content'); ?>
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Bank Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Bank Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			<?php echo $__env->make("employee_self_services/profile/sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
            <table class="table-bordered"> 
			<thead>
			<tr>
			<th>Account Type</th>
			<th>Account Nature</th>
			<th>Account No.</th>
			<th>Primary Account/Salary Account</th>
			<th>Start Date</th>
			</tr>
			</thead>
			<tbody>
			<?php if(!$data['Empbank']->isEmpty()): ?>
				<?php $__currentLoopData = $data['Empbank']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
					<td><?php echo e($bank->account_type); ?></td>
					<td title="flat no.403,sohi towars,govind vihar"><?php echo e($bank->nature); ?></td>
					<td title="Govind Vihar"><?php echo e($bank->account_no); ?></td>
					<td><?php echo e($bank->account_for); ?></td>
					<td>
					<a title="Edit" href="<?php echo e(route('employee-services',array('action' => 'updatebank','id' => $bank->id ))); ?>">
					<i class="icon-edit"></i>
					</a>
					<a href="<?php echo e(route('employee-services',array('action' => 'deletebank','id' => $bank->id ))); ?>" title="Delete Bank Details">
					<i class="icon-trash"> </i>
					</a>
					</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<tr>
				<td>No Records</td>
				</tr>	
			<?php endif; ?>	
			</tbody>
			</table>
			
			 <div style="margin-top:30px;">			
			<button class="btn btn-info">Verify Details</button>
			<a href="<?php echo e(route('employee-services',array('action' => 'addBankdetail'))); ?>" class="btn btn-info">Create Base</a>
			</div>

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>