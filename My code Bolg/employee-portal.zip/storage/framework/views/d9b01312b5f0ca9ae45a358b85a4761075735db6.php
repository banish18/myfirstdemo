<?php $__env->startSection('content'); ?>
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Contact Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Bank Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			<?php echo $__env->make("employee_self_services/profile/sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
            <table class="table-bordered"> 
			<thead>
			<tr>
			<th>Name</th>
			<th>Relationship</th>
			<th>MST Employee flag</th>
			<th>Dependent flag</th>
			<th>Emergency flag</th>
			<th>Action</th>
			</tr>
			</thead>
			<tbody>
			<?php if(!$data['Empcontact']->isEmpty()): ?>
				<?php $__currentLoopData = $data['Empcontact']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
					<td><?php echo e($contact->name); ?></td>
					<td title="flat no.403,sohi towars,govind vihar"><?php echo e($contact->relationship); ?></td>
					<td title="Govind Vihar"><?php echo e(($contact->mst_emp_flag == '1' ? 'Yes':'No')); ?></td>
					<td><?php echo e(($contact->dependent_flag == 1 ? 'Yes':'No')); ?></td>
					<td><?php echo e(($contact->emergency_flag == 1 ? 'Yes':'No')); ?></td>
					<td>
					<a title="Edit" href="<?php echo e(route('employee-services',array('action' => 'updatecontact','id' => $contact->id ))); ?>">
					<i class="icon-edit"></i>
					</a>
					<a href="<?php echo e(route('employee-services',array('action' => 'deletecontact','id' => $contact->id ))); ?>" title="Delete Contact Details">
					<i class="icon-trash"> </i>
					</a>
					</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<tr>
				<td>No Records</td>
				</tr>	
			<?php endif; ?>	
			</tbody>
			</table>
			
			 <div style="margin-top:30px;">			
			<button class="btn btn-info">Verify Details</button>
			<a href="<?php echo e(route('employee-services',array('action' => 'addContactdetail'))); ?>" class="btn btn-info">Create Base</a>
			</div>

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>