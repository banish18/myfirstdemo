<?php $__env->startSection('content'); ?>


 <style>
p img{
	max-width:60px;
	position:relative !important;

}
.number1{
    font-size: 3.8em;
    font-weight: 100;
    background: #ffffff; /** 37681C  **/
    color: #007aff;
    line-height: 1.4em;
    padding-top: 8px;
    letter-spacing: -0.06em;
}
.number2{
	font-size: 3.8em;
    font-weight: 100;
    background: #ffffff;/** FB6542 **/
    color: #007aff;
    line-height: 1.4em;
    padding-top: 8px;
    letter-spacing: -0.06em;
}
.number3{
	font-size: 3.8em;
    font-weight: 100;
    background: #ffffff;/** FFBB00 **/
    color: #007aff;
    line-height: 1.4em;
    padding-top: 8px;
    letter-spacing: -0.06em;
}
 </style>

<div class="container-fluid main-content">




        <!-- Statistics -->
                <div class="row">
          <div class="col-lg-12">
            <div class="widget-container stats-container">
              <div class="col-md-4" style="background:#dddddd;">
                <div class="number1">

                  <img src="images/users.svg" style="margin-top: -18px;
    width: 46px;">
                 3                </div>
                <div class="text" style="background:#fff;">
                 <a href="https://shiftsystems.net/demo/index.php?user=display_dept">Total Departments</a>
                </div>
              </div>
              <div class="col-md-4" style="background:#dddddd;">
                <div class="number2">
                  <img src="images/employees.svg" style="margin-top: -18px;
    width: 46px;">
                 4                </div>
                <div class="text" style="background:#fff;">
                 <a href="https://shiftsystems.net/demo/index.php?user=view_employees">Total Employees</a>
                </div>
              </div>
              <div class="col-md-4" style="background:#dddddd;">
                <div class="number3">
                   <img src="images/sun-umbrella.svg" style="margin-top: -18px;
    width: 46px;">
                  3                </div>
                <div class="text" style="background:#fff;">
                 <a href="https://shiftsystems.net/demo/index.php?user=view_holiday"> Total Holidays </a>
                </div>
              </div>

            </div>
          </div>
        </div>        <!-- End Statistics -->

        <div class="row">

        <div class="col-md-12">
        <div class="col-md-8">
     <div class="widget-container fluid-height clearfix">
	  <div class="heading">
			<a href="#">Calendar</a>
	</div>
<div class="widget-content padded">
<div id="calendar">

</div>

</div>
</div>
</div>
<div class="col-md-4">

 <div class="widget-container scrollable chat chat-page" style="height:691px;padding:0px;">
              <div class="heading">
                <i class="icon-comments"></i>
                 <a href="#">Noticeboard</a>

              </div>
              <div class="widget-content padded" >
                <ul>
                                   <li class="current-user">
                                         <img src="images/-text.png"  width="30" height="30">
                                  <div class="bubble">
                      <a class="user-name" href="#">Happy New Year</a>
                      <p class="message">
                        
Hello All.

Welcome back. This year is going to be amazing. A lot of new product in the pipeline.                        </p>
                      <p class="time">

                        <strong>

                        Published by Angela (HR)<br>Published on 05/01/2017                         </strong>
                      </p>
                    </div>
                  </li>                  <li class="current-user">
                                         <img src="images/-text.png"  width="30" height="30">
                                  <div class="bubble">
                      <a class="user-name" href="#">New Update</a>
                      <p class="message">
                        Sample one
                      </p>
                      <p class="time">

                        <strong>

                        Published by  ()<br>Published on 21/11/2016                         </strong>
                      </p>
                    </div>
                  </li>                  <li class="current-user">
                                         <img src="images/-text.png"  width="30" height="30">
                                  <div class="bubble">
                      <a class="user-name" href="#">Project Deadline</a>
                      <p class="message">
                        All employees complete there project on deadline and submit to their senior before holidays..                       </p>
                      <p class="time">

                        <strong>

                        Published by  ()<br>Published on 10/11/2016                         </strong>
                      </p>
                    </div>
                  </li>                </ul>
              </div>
            </div>
</div>
</div>




</div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>