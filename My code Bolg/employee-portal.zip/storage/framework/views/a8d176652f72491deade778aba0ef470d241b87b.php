<?php $__env->startSection('content'); ?>

  <div class="main-wrapper">

    <div class="main">

	 

	

	

      <div class="document-title">

        <div class="container">

          <h1 class="center">Employee - Allocation Deallocation </h1>

        </div>

        <!-- /.container --> 

      </div>

      <!-- /.document-title -->

	  

	    <div class="document-breadcrumb">

		 	<div class="container">

				<ul class="breadcrumb">

					<li>

						<a href="/">Home</a>

					</li>
					
					<li>

						<a href="<?php echo e(route('employee-services',array('action' => 'travel'))); ?>">Travel</a>

					</li>

					<li>Employee - Allocation Deallocation </li>

				</ul>

			</div>

		</div>

      <div class="container mb40">

        <div class="row">

		 <div class="col-md-3">

			<div class="row">

			<div class="col-lg-12 project-menu">

			<div class="box-sidebar side-menu-main project-menu">

			<div class="box-head-dark">

			<i class="fa fa-bars"></i>

			Domestic Menu

			</div>

			<div class="box-content">

			<?php echo $__env->make("employee_self_services/travel/international/sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			</div>	

			</div>

			</div>

		</div>

		</div>

          <div class="col-sm-9">
				<img src="<?php echo e(asset('frontassets/travel/accommodation and transport initiation.jpg')); ?>" />
          </div>

          <!-- /.col-* --> 
 
        </div>

				<!-- /.row -->

      </div>

      <!-- /.container -->

    </div>

  </div>

  <!-- /.main --> 



<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<style>

ul, li {

    border: 0 none;

    list-style: outside none none;

    margin: 0;

    padding: 0;

}

.infocard_legend li {

    float: left;

    margin-right: 15px;

}



.infocard_legend .worklist {

    background-color: #d9edf7;

}

.infocard_legend li span {

    border: 1px solid #ccc;

    float: left;

    height: 15px;

    margin: 2px 5px 2px 2px;

    width: 16px;

}



</style>

<script>

	$(document).ready(function($){

	var url = window.location.href;

	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');

	});

</script>

<?php $__env->stopSection(); ?>

	

	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>