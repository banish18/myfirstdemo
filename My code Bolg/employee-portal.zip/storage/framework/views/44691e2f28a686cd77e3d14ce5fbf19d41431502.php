<?php $__env->startSection('content'); ?>
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Address Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Address Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			<?php echo $__env->make("employee_self_services/employeeperks/sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
			<div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
            <h4>Bonafide Letter</h4>
            <table  class="table-bordered" width="100%" align="center">
              <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Bonafide Letter</span> </div>
             
<tbody>
<tr>
<td>
<span class="BodyFont" style="text-align:left;font-weight:bold;">Purpose of Letter *</span>
</td>
<td>
<span style="width:300px;text-align: center;border-bottom: none">
<select class="input-block-level ng-pristine ng-valid" ng-options="purpose.id as purpose.name for purpose in purpose_List" ng-model="purpose_id" ng-change="purpose_form_canvas();">
<option class="" value="">Choose Option</option>
<option value="0">Bank Formalities</option>
<option value="1">RTO registration for vehicle</option>
<option value="2">Application for higher education</option>
<option value="3">Telephone connection</option>
<option value="4">Marriage registration</option>
<option value="5">LPG connection</option>
<option value="6">Driving licence</option>
<option value="7">ECNR processing on passport</option>
<option value="8">PAN card</option>
<option value="9">PPF account</option>
<option value="10">Purchase a vehicle</option>
<option value="11">Internet connection</option>
<option value="12">Mobile connection</option>
<option value="13">Bank loan</option>
<option value="14">Bank account</option>
<option value="15">TATA group Corporate discount</option>
<option value="16">Letter for accommodation on Rent</option>
<option value="17">Insurance of vehicle</option>
<option value="18">Transfer of vehicle</option>
<option value="19">Letter for VISA application</option>
<option value="20">To apply for passport</option>
<option value="21">For modifications in passport details</option>
<option value="22">For Police verification</option>
<option value="23">For domicile certificate</option>
<option value="24">UID(AADHAAR)</option>
<option value="25">For renewal of passport</option>
<option value="26">BGC formalities</option>
</select>
</span>
</td>
</tr>
</tbody>
</table>
            </table>
          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
		   </div><!-- /.col-* -->
		</div><!-- /.row -->
	</div><!-- /.container -->
		 
	  
    </div>
  </div>
  <!-- /.main --> 

<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>