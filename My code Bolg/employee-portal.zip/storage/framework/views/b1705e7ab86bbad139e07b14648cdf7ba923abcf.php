<?php
require('fpdf/fpdf.php');

class PDF extends FPDF
{
	// Page header
	function Header()
	{
		// Logo
		$this->Image('logo.png',150,6,50);
		// Arial bold 15
		$this->SetFont('Arial','B',15);
		// Move to the right
	   
		// Title
		$this->Cell(30,10,'Payslip');
		// Line break
		$this->Ln();
		// Title
		$this->Cell(30,10,'Feb2016');
		
		// Line break
		$this->Ln(20);
	}

	// Page footer
	function Footer()
	{
		// Position at 1.5 cm from bottom
		$this->SetY(-15);
		// Arial italic 8
		$this->SetFont('Arial','B',16);
		// Page number
		$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
	}
	// Colored table
	function FancyTable($pdf)
	{
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(55,5,'Mr. Sumit Singh',1,0,'',0);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(140,5,'',1,1,'',0);
		$pdf->SetTextColor(255,255,255);
		$pdf->SetFillColor(30,144,255);
		$pdf->Cell(65,7,'Employee Details',1,0,'',true);
		$pdf->Cell(65,7,'Payment & Leave Details',1,0,'',true);
		$pdf->Cell(65,7,'Location Details',1,0,'',true);
		$pdf->SetTextColor(000);
		$pdf->SetFont('Arial','',8);
		// Line break
		$pdf->Ln();
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(32.5,5,'Emp No.',1,0,'',0);
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(32.5,5,'475038',1,0,'',0);
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(32.5,5,'Bank Name',1,0,'',0);
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(32.5,5,'ICICI',1,0,'',0);
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(32.5,5,'Location',1,0,'',0);
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(32.5,5,'Chandigarh',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(32.5,5,'Dsgn.',1,0,'',0);
		$pdf->Cell(32.5,5,'I.T. Analyst',1,0,'',0);
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(32.5,5,'Acc',1,0,'',0);
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(32.5,5,'00586236599',1,0,'',0);
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(32.5,5,'Base Br.',1,0,'',0);
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(32.5,5,'TCS - New Delhi',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(32.5,5,'Grade',1,0,'',0);
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(6.5,5,'C2',1,0,'',0);
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(7.5,5,'DOJ',1,0,'',0);
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(18.5,5,'01-Feb-2016',1,0,'',0);
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(32.5,5,'Days Paid',1,0,'',0);
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(32.5,5,'31',1,0,'',0);
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(32.5,5,'Depute Br.',1,0,'',0);
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(32.5,5,'TCS - New Delhi',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(32.5,5,'PAN',1,0,'',0);
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(32.5,5,'A01555dsf',1,0,'',0);
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(32.5,5,'LEAVE BALANCE',1,0,'',0);
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(12,5,'EL',1,0,'',0);
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(20.5,5,'52.00',1,0,'',0);
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(12,5,'SL',1,0,'',0);
		$pdf->SetFont('Arial','',8);
		$pdf->Cell(20.5,5,'30.59',1,0,'',0);
		$pdf->SetFont('Arial','B',8);
		$pdf->Cell(12,5,'CL',1,0,'B',0);
		$pdf->Cell(20.5,5,'3.50',1,0,'',0);
		// Line break
		$pdf->SetFont('Arial','B',10);
		$pdf->Ln();
		$pdf->SetTextColor(255,255,255);
		$pdf->SetFillColor(30,144,255);
		$pdf->Cell(52.5,5,'Earnings',1,0,'',true);
		$pdf->Cell(30,5,'Arrears',1,0,'',true);
		$pdf->Cell(30,5,'Current',1,0,'',true);
		$pdf->Cell(52.5,5,'Deductions',1,0,'',true);
		$pdf->Cell(30,5,'Amount',1,0,'',true);
		$pdf->SetFont('Arial','',8);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(52.5,5,'Basic Salary',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'16,800.00',1,0,'',0);
		$pdf->Cell(52.5,5,'Provident Fund',1,0,'',0);
		$pdf->Cell(30,5,'2,016.00',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(52.5,5,'Bob Kitty Allowance',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'5,682.00',1,0,'',0);
		$pdf->Cell(52.5,5,'Income Tax',1,0,'',0);
		$pdf->Cell(30,5,'5,736.00',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(52.5,5,'Convanyance Taxable',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'200.00',1,0,'',0);
		$pdf->Cell(52.5,5,'Health Insurance Scheme Premium',1,0,'',0);
		$pdf->Cell(30,5,'4,045.00',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(52.5,5,'Convanyance Non Taxable',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'200.00',1,0,'',0);
		$pdf->Cell(52.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(52.5,5,'House Rent Allowance',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'1,600.00',1,0,'',0);
		$pdf->Cell(52.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(52.5,5,'Sundry Medical',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'8,000.00',1,0,'',0);
		$pdf->Cell(52.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(52.5,5,'Leave Travel Allowance',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'1,250.00',1,0,'',0);
		$pdf->Cell(52.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(52.5,5,'Personal Allowance',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'1,169.00',1,0,'',0);
		$pdf->Cell(52.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(52.5,5,'Misscellaneous',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'9,600.00',1,0,'',0);
		$pdf->Cell(52.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(52.5,5,'City Allowance',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'1,800.00',1,0,'',0);
		$pdf->Cell(52.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(52.5,5,'Performance Pay',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'1,800.00',1,0,'',0);
		$pdf->Cell(52.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);

		// Line break
		$pdf->Ln();
		// Line break
		$pdf->Cell(52.5,25,'',1,0,'',0);
		$pdf->Cell(30,25,'',1,0,'',0);
		$pdf->Cell(30,25,'',1,0,'',0);
		$pdf->Cell(52.5,25,'',1,0,'',0);
		$pdf->Cell(30,25,'',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetFont('Arial','B',8);
		// Line break
		$pdf->Cell(52.5,7,'Total Earnings',1,0,'',0);
		$pdf->Cell(30,7,'',1,0,'',0);
		$pdf->Cell(30,7,'64,148.00',1,0,'',0);
		$pdf->Cell(52.5,7,'Total Deductions',1,0,'',0);
		$pdf->Cell(30,7,'11,797.00',1,0,'',0);
		// Line break
		$pdf->Ln(10);
		// Line break
		$pdf->SetFont('Arial','B',8);
		$pdf->SetTextColor(255,255,255);
		$pdf->SetFillColor(30,144,255);
		$pdf->Cell(40,10,'Retrials as on Month end',1,0,'C',true);
		$pdf->SetTextColor(000);
		$pdf->Cell(30,10,'Provident fund*',1,0,'C',0);
		$pdf->Cell(42.5,10,'1,79,565.00',1,0,'R',0);
		$pdf->SetTextColor(255,255,255);
		$pdf->SetFillColor(30,144,255);
		$pdf->Cell(52.5,10,'Net Pay',1,0,'',true);
		$pdf->SetTextColor(000);
		$pdf->Cell(30,10,'52,351.00',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(255,0,0);
		$pdf->Cell(52.5,10,'*Inclusive of provisional interest',0,0,'');
		// Line break
		$pdf->SetTextColor(0,0,0);
		$pdf->Ln();
		$pdf->SetTextColor(255,255,255);
		$pdf->SetFillColor(30,144,255);
		$pdf->Cell(140,5,'Projected Annual Tax Income',1,0,'',true);
		$pdf->Cell(55,5,'Chapter Via Relief',1,0,'',true);
		$pdf->SetTextColor(000);
		$pdf->SetFont('Arial','',8);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(42.5,5,'Anual Income*',1,0,'',0);
		$pdf->Cell(30,5,'43,000,00',1,0,'',0);
		$pdf->Cell(30,5,'Net tax Income r/o',1,0,'',0);
		$pdf->Cell(42.5,5,'6,63,880.00',1,0,'',0);
		$pdf->Cell(30,5,'80C',1,0,'',0);
		$pdf->Cell(20.5,5,'24,192.00',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->Cell(42.5,5,'Chapter Via Relief',1,0,'',0);
		$pdf->Cell(30,5,'7,00,000,00',1,0,'',0);
		$pdf->Cell(30,5,'Total Tax Payable',1,0,'',0);
		$pdf->Cell(42.5,5,'6,63,880.00',1,0,'',0);
		$pdf->Cell(30,5,'80D',1,0,'',0);
		$pdf->Cell(20.5,5,'24,192.00',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->Cell(42.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'Tax Deducted Till Date',1,0,'',0);
		$pdf->Cell(42.5,5,'6,63,880.00',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(20.5,5,'',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->Cell(42.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(30,5,'Balance Tax',1,0,'',0);
		$pdf->Cell(42.5,5,'6,63,880.00',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(20.5,5,'',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->Ln();
		$pdf->SetTextColor(255,255,255);
		$pdf->SetFillColor(30,144,255);
		$pdf->Cell(140,5,'Investment Description',1,0,'',true);
		$pdf->Cell(55,5,'Exemption Considered*',1,0,'',true);
		$pdf->SetTextColor(000);
		$pdf->SetFont('Arial','',8);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(000);
		$pdf->Cell(42.5,5,'80D-Medical Premium',1,0,'',0);
		$pdf->Cell(30,5,'3,956.00',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(42.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'Conveyance',1,0,'',0);
		$pdf->Cell(20.5,5,'19,200',1,0,'',0);
		$pdf->Ln();
		$pdf->Cell(42.5,5,'80D-Medical Premium',1,0,'',0);
		$pdf->Cell(30,5,'3,956.00',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(42.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(20.5,5,'',1,0,'',0);
		$pdf->Ln();
		$pdf->Cell(42.5,5,'PF Contribution',1,0,'',0);
		$pdf->Cell(30,5,' 	24,192.00',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(42.5,5,'',1,0,'',0);
		$pdf->Cell(30,5,'',1,0,'',0);
		$pdf->Cell(20.5,5,'',1,0,'',0);
		// Line break
		$pdf->Ln();
		$pdf->SetTextColor(255,0,0);
		$pdf->Cell(52.5,10,'*Please Note, Annual Income is after considering the above exemption - if any.',0,0,'');
		// Line break
		$pdf->SetTextColor(0,0,0);
		$pdf->SetFont('Arial','B',8);
		$pdf->Ln();
		$pdf->Cell(52.5,10,'Payslip generated on: 29 Aug 2015,21:03:13',0,0,'');
		
	}
}

// Instanciation of inherited class
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',14);
$pdf->FancyTable($pdf);
$pdfContent = $pdf->Output('', "S");
return response($pdfContent, 200,
        [
            'Content-Type'        => 'application/pdf',
            'Content-Length'      =>  strlen($pdfContent),
            'Content-Disposition' => 'attachment; filename="mypdf.pdf"',
            'Cache-Control'       => 'private, max-age=0, must-revalidate',
            'Pragma'              => 'public'
        ]
    );
?>