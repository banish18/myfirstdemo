
   <div class="modal-shiftfix">
      <!-- Navigation -->
      <div class="navbar navbar-fixed-top scroll-hide">
        <div class="container-fluid top-bar">

          <div class="pull-right">
            <ul class="nav navbar-nav pull-right">
<li style="margin-top:10px;">
<div class="hidden-xs" id="txt">

 </div>
</li>
              <li class="dropdown notifications hidden-xs">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">

            <span aria-hidden="true"  style="margin-top:-5px;">
             <img src="<?php echo e(asset('admin-asset/images/info.svg')); ?>"/>
</span>
                </a>
                <ul class="dropdown-menu">
                  <li><a href="#">
<b> Department </b>: Super Admin                     </a>
                  </li>
              <li><a href="#">
                                <b> Office Timings</b> : 10:00 AM - 06:30 PM                                </a>
              </li>

                </ul>
              </li>
<!-- ---------------------------For Mark Attendance----------------------------------------- -->
               <!-- -------------------------------END---------------------------------------- -->
            <li class="dropdown user hidden-xs "><a data-toggle="dropdown" class="dropdown-toggle" href="#">


                             <img src="//www.placehold.it/200x150/EFEFEF/AAAAAA&text=no+image" width="34" /><b class="caret"></b>
                   </a>
                <ul class="dropdown-menu">
                <li>
                <a class="" href="javascript:void(0)">


             <img src="<?php echo e(asset('admin-asset/images/profile.svg')); ?>" width="19"/>
             Profile

             </a>
                  </li>
              <li><a href="javascript:void(0)">

               <img src="<?php echo e(asset('images/locked.svg')); ?>" width="19"/>
               Change Password</a>
              </li>

                             
                
                                       <li>
                      <a href="<?php echo e(route('notes')); ?>" class="">

<img src="<?php echo e(asset('admin-asset/images/warning.svg')); ?>" width="19"/>
                      Notice Board</a>
                      </li>
			      <li>
                      <a href="<?php echo e(route('setting',array('action' => 'rules-regulations' ))); ?>" class="">

<img src="<?php echo e(asset('admin-asset/images/warning.svg')); ?>" width="19"/>
                      Rules amd regulations</a>
                      </li>		  
               
                
              
              <li><a href="<?php echo e(route('logout')); ?>">
               <img src="<?php echo e(asset('admin-asset/images/logout.svg')); ?>" width="19"/>
                    Logout</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>

<!-- ----------------------------END---------------------- -->
          <button class="navbar-toggle">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span></button>
           <a  class="logo" href="<?php echo e(route('dashboard')); ?>">
        Employee Portal

       </a>
        </div>
        <div class="container-fluid main-nav clearfix">
          <div class="nav-collapse">
  <ul class="nav">
              <li>
                <a class="current" href="<?php echo e(route('dashboard')); ?>">
                <span aria-hidden="true"  >
                <img src="<?php echo e(asset('admin-asset/images/speedometer.svg')); ?>" style="margin-top: -17px;">
                </span>
                My Dashboard</a>
              </li>
                                 <li><a class=""
                  href="<?php echo e(route('users')); ?>">
                <span aria-hidden="true" >
                <img src="<?php echo e(asset('admin-asset/images/employees.svg')); ?>" style="margin-top: -17px;">
                </span>Employees</a>
              </li>
              
              <li><a class="" href="<?php echo e(route('departments')); ?>">
                <span aria-hidden="true">
                <img src="<?php echo e(asset('admin-asset/images/users.svg')); ?>" style="margin-top: -17px;">
                </span>Departments</a>
              </li>
                                          <li><a class="" href="<?php echo e(route('payroll')); ?>">
                <span aria-hidden="true"  >
                 <img src="<?php echo e(asset('admin-asset/images/check-mark.svg')); ?>" style="margin-top: -17px;">

                </span>Payroll</a></li>


              
				   <!--li class="dropdown">
					  <a data-toggle="dropdown" class="" href ="">
						   <span aria-hidden="true" >
						   <img src="<?php echo e(asset('admin-asset/images/calendar.svg')); ?>" style="margin-top: -17px;">
							</span>Attendances/Leaves<b class="caret"></b>
					  </a>
					<ul class="dropdown-menu">

					  <li>
						<a class="" href="">Attendances</a>
					  </li>

					   <li>
						<a class="" href="">Leaves</a>
					  </li>
					</ul>
				   </li-->
              
                  <!--li>
                  <a class="" href="">
                   <span aria-hidden="true" >
                   <img src="<?php echo e(asset('admin-asset/images/text-lines.svg')); ?>" style="margin-top: -17px;">
                   </span>
                  Claims</a>
                  </li--> <li class="dropdown">
 <a data-toggle="dropdown" class="" href ="">
                <span aria-hidden="true" >
               <img src="<?php echo e(asset('admin-asset/images/notebook.svg')); ?>" style="margin-top: -17px;">
                </span>Reports<b class="caret"></b></a>

                <ul class="dropdown-menu">
                  <li>
                    <a class="" href="">Employee Based Payslips Report</a>
                  </li>                  <li>
                    <a class="" href="">Yearly Payslips Report</a>
                  </li>
                </ul>
              </li>
			  <li class="dropdown">
					 <a class="" href="<?php echo e(route('notes')); ?>">
                <span aria-hidden="true">
                <img src="<?php echo e(asset('admin-asset/images/text-lines.svg')); ?>" style="margin-top: -17px;">
                </span>Notes</a>
				   </li>
				   
				 <li><a class="" href="<?php echo e(route('master',array('action' => 'master'))); ?>">
                <span aria-hidden="true"  >
                 <img src="<?php echo e(asset('admin-asset/images/check-mark.svg')); ?>" style="margin-top: -17px;">

                </span>Master</a></li> 
				
				<li><a class="" href="<?php echo e(route('employement')); ?>">
                <span aria-hidden="true"  >
                 <img src="<?php echo e(asset('admin-asset/images/check-mark.svg')); ?>" style="margin-top: -17px;">

                </span>Employement</a></li> 
				
				<li><a class="" href="<?php echo e(route('users',array('action' => 'fullandfinal'))); ?>">
                <span aria-hidden="true"  >
                 <img src="<?php echo e(asset('admin-asset/images/check-mark.svg')); ?>" style="margin-top: -17px;">

                </span>Previous Employee Detail</a></li> 
              
                  <!--li>
                  <a class="" href="">
                   <span aria-hidden="true" >
                   <img src="<?php echo e(asset('admin-asset/images/text-lines.svg')); ?>" style="margin-top: -17px;">
                   </span>
                  Claims</a>
                  </li-->
   <li>
                <a href="<?php echo e(route('logout')); ?>">
                <span aria-hidden="true"  >
                <img src="<?php echo e(asset('admin-asset/images/logout.svg')); ?>" style="margin-top: -17px;">
                </span>
                Logout</a>
              </li>

            </ul>
          </div>
        </div>
      </div>
      </div>