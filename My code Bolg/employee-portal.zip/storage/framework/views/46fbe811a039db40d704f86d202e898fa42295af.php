<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
<div class="page-title">
<div class="row">
<div class="col-md-6">
<h1><?php echo e($data['user']->name); ?> Profile</h1>
</div>

</div></div>
<div class="row">
 <div class="col-md-2">
           <ul class="list-group">
			 	<li class="list-group-item active" >
		 <a href="<?php echo e(route('users')); ?>">
           <p>
            <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;List Employees
           </p></a>
           </li>

           <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'add'))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add Employee
           </p>
           </a> 
           </li>
		   
		   <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'address-proof','id' => $data['user']->id))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Address and Id Proofs
           </p>
           </a>
           </li>
		   
		   <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'education','id' => $data['user']->id))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Educational Docs
           </p>
           </a>
           </li>
		   
		    <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'previous-employement','id' => $data['user']->id))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Previous Employement Detail
           </p>
           </a>
           </li>
           
            </ul>
        </div>
	
		<div class="col-md-10">
			<div class="row">
		<h2>Previous Employee Documents</h2>
		<div class="widget-container fluid-height clearfix">
			<div class="widget-content padded">
		
		  <form method="post" action="<?php echo e(route('users',array('action' => 'updatepreviousEmployement'))); ?>" enctype="multipart/form-data">
				 <?php echo e(csrf_field()); ?>

				  <input type="hidden" class="uid" name="uid" value="<?php echo e($data['user']->id); ?>">
			<div class="col-md-6">
				<div class="form-group">
				<label class="control-label col-md-3">Company Name</label>
				<div class="col-md-9">
				<?php if($data["Previousemployement"] && $data["Previousemployement"]->company_name != ""): ?>
					<?php  $companyname = $data["Previousemployement"]->company_name;?>
				<?php else: ?>
					<?php  $companyname = "";?>
				<?php endif; ?>	
				<input class="form-control" name="company_name" value="<?php echo e($companyname); ?>" type="text" required>
				<div class="clear" style="float:left;margin-top:39px;"></div>
				</div>
				</div>
				
				<div class="form-group">
				<label class="control-label col-md-3">Company Website</label>
				<div class="col-md-9">
				<?php if($data["Previousemployement"] && $data["Previousemployement"]->company_website != ""): ?>
					<?php  $company_website = $data["Previousemployement"]->company_name;?>
				<?php else: ?>
					<?php  $company_website = "";?>
				<?php endif; ?>
				<input class="form-control" name="company_website" value="<?php echo e($company_website); ?>" type="text" required>
				<div class="clear" style="float:left;margin-top:39px;"></div>
				</div>
				</div>
				
				
				
				<div class="form-group">
				<label class="control-label col-md-3">Employee ID</label>
				<div class="col-md-9">
				<?php if($data["Previousemployement"] && $data["Previousemployement"]->employee_id != ""): ?>
					<?php  $employee_id = $data["Previousemployement"]->employee_id;?>
				<?php else: ?>
					<?php  $employee_id = "";?>
				<?php endif; ?>
				<input class="form-control" name="employee_id" value="<?php echo e($employee_id); ?>" type="text" required>
				<div class="clear" style="float:left;margin-top:39px;"></div>
				<div class="clear" style="float:left;margin-top:39px;"></div>
				</div>
				
				</div>
				
				
				
				<div class="form-group">
					<label class="control-label col-md-3">Form 16
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Previousemployement"] && $data["Previousemployement"]->formsixteen != ""): ?>
						<input type="hidden" value="<?php echo e($data['Previousemployement']->formsixteen); ?>" name="preformsixteen">
						<img src="<?php echo e(asset('images/users/'.$data['Previousemployement']->formsixteen)); ?>" />
					<?php else: ?>
						<input type="hidden" value=" " name="preformsixteen">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>	
					
					
					
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" name="formsixteen" onchange="checkSize(this)"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-md-3">Form 18
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Previousemployement"] && $data["Previousemployement"]->formeighteen != ""): ?>
						<input type="hidden" value="<?php echo e($data['Previousemployement']->formeighteen); ?>" name="preeighteen">
						<img src="<?php echo e(asset('images/users/'.$data['Previousemployement']->formeighteen)); ?>" />
					<?php else: ?>
						<input type="hidden" value=" " name="preformeighteen">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>	
					
					
					
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" name="eighteen" onchange="checkSize(this)"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				
				
				<div class="col-md-5" ></div>
				<div class="col-md-2"><div class="form-group"><input name="save" class="btn btn-lg btn-block btn-success" type="submit" value="save" /></div></div>
				<div class="col-md-5"></div>
				</div>
				
				<div class="col-md-6">
				
				<div class="form-group">
				<label class="control-label col-md-5">Employement Period From</label>
				<div class="col-md-7">
				<?php if($data["Previousemployement"] && $data["Previousemployement"]->period_from != ""): ?>
					<?php  $period_from = $data["Previousemployement"]->period_from;?>
				<?php else: ?>
					<?php  $period_from = "";?>
				<?php endif; ?>
				<input class="form-control" name="period_from" id="period_from" value="<?php echo e($period_from); ?>" type="text" >
				<div class="clear" style="float:left;margin-top:39px;"></div>
				</div>
				</div>
				<div class="form-group">
				<label class="control-label col-md-5">Employement Period To</label>
				<div class="col-md-7">
				<?php if($data["Previousemployement"] && $data["Previousemployement"]->period_to != ""): ?>
					<?php  $period_to = $data["Previousemployement"]->period_to;?>
				<?php else: ?>
					<?php  $period_to = "";?>
				<?php endif; ?>
				<input class="form-control" name="period_to" value="<?php echo e($period_to); ?>" id="period_to" type="text">
				<div class="clear" style="float:left;margin-top:39px;"></div>
				</div>
				</div>
				<div class="form-group">
					<label class="control-label col-md-3">Experience
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Previousemployement"] && $data["Previousemployement"]->experience != ""): ?>
						<input type="hidden" value="<?php echo e($data['Previousemployement']->experience); ?>" name="preexperience">
						<img src="<?php echo e(asset('images/users/'.$data['Previousemployement']->experience)); ?>" />
					<?php else: ?>
						<input type="hidden" value=" " name="preexperience">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>	
					
					
					
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" name="experience" onchange="checkSize(this)"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				
				<div class="clear"></div>
				
				
				<div class="form-group">
					<label class="control-label col-md-3">Salary Slip
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Previousemployement"] && $data["Previousemployement"]->salaryslip != ""): ?>
						<input type="hidden" value="<?php echo e($data['Previousemployement']->driving_license); ?>" name="presalaryslip">
						<img src="<?php echo e(asset('images/users/'.$data['Previousemployement']->salaryslip)); ?>" />
					<?php else: ?>
						<input type="hidden" value="" name="presalaryslip">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>	
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" onchange="checkSize(this)" name="salaryslip" id="profile_pic"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				</div>
		
				</form>
				</div>
				</div>
        </div>
</div>
</div>

</div>
<?php echo $__env->make("templates/admin-footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
function checkSize(elm) {
	
var a = elm.files[0].size;

var b= 67108864;
if(a>b)
alert("File size must be less than 64M");
}

$(function(){
	$("#period_to").datepicker({ dateFormat: 'yyyy-mm-dd' });
	$("#period_from").datepicker({ dateFormat: 'yyyy-mm-dd' });
});

</script>
<!-- ----------------------END------------------------------------- -->
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>