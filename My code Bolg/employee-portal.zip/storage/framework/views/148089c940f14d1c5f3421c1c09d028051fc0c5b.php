<?php $__env->startSection('content'); ?>
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Lost Demage Card Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="<?php echo e(route('home')); ?>">Home</a>
					</li>
					<li>Lost Demage Card Details</li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			<?php echo $__env->make("employee_self_services/profile/sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
            <div class="col-sm-12">
				  <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;">Associate Details</div>
					<table class="table-bordered">     
					<tbody>
					<tr>
					<th>Employee Number</th>
					<td><?php echo e($data['user']->uuid); ?></td>
					<th>Employee Name</th>
					<td><?php echo e($data['user']->f_name.' '.$data['user']->l_name); ?></td>
					<th>Role</th>
					<td><?php echo e($data['user']->designation); ?></td>
					</tr>
					<tr>
					<th>Home Country</th>
					<td><?php echo e($data['user']->country); ?></td>
					<th>Current Country</th>
					<td><?php echo e($data['user']->country); ?></td>
					<th>Employment Status</th>
					<td>Active Assignment</td>
					</tr>
					</tbody>
					</table>
					
				
				

				  </div>
				  <!-- /.col-* --> 
				  
				
			  
			  
			  
						   

					<div class="container">
					 <div class="row">
					  <div class="col-sm-12">
					   <ul class="nav nav-tabs" role="tablist">
						<li role="presentation" class="active">
							<a href="#personal" aria-controls="personal" role="tab" data-toggle="tab">
								<strong>Report/Lost Damaged Card</strong>
								<span></span>
							</a>
						</li>

						<li role="presentation">
							<a href="#company" aria-controls="company" role="tab" data-toggle="tab">
								<strong>CARD HISTORY</strong>
								<span></span>
							</a>
						</li>
					  </ul>

					<div class="tab-content">
						<div role="tabpanel" class="tab-pane active" id="personal">
							<div class="row">
								<div class="col-sm-12">
								
								<table style="border:1px solid #ccc;">
								<tbody>
								<tr>
								<td>
								<span class="BodyFont" style="font-weight:bold; padding-left:10px; padding-top:10px">What do you want to apply for?</span>
								</td>
								</tr>
								<tr>
								<td>
								<label>
								<input class="selectRadio" name="radio2" value="New Card" onclick="submit();" type="radio">
								 Lost/Damage Card
								</label>
								</td>
								<td>
								<label>
								<input class="selectRadio" name="radio2" value="Reimbursement" onclick="submit();" type="radio">
								 Reimbursement (In Case you have found the Lost card)
								</label>
								</td>
								</tr>
								</tbody>
								</table>
								
										
									</div><!-- /.form-group-->
								</div><!-- /.col-* -->
							</div><!-- /.row -->

						   
						  

						<div role="tabpanel" class="tab-pane" id="company">
								
								
								
							
								 <table class="table-bordered">     
									<tbody>
									<tr>
									<th>Sr No.</th>
									<th>Employee No.</th>
									<th>Card No.</th>
									<th>Activation status</th>
									<th>Activation Date	</th>
									<th>Deactivation Date</th>
									<th>Reimbursement Status</th>
									</tr>
									<tr>
									<th>1</th>
									<td>475038</td>
									<th>379452</th>
									<td>Active</td>
									<th>Mar-18-2011</th>
									<td></td>
									<td>N</td>
									</tr>
									</tbody>
									</table>
									<br/>
								<button class="btn btn-info">Back</button>
						</div><!-- /.tab-pane -->
					</div><!-- /.tab-content -->
				</div><!-- /.col-* -->
			</div><!-- /.row -->
		</div><!-- /.container -->

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>