<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
     <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1>Open Positions</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="document-breadcrumb">
                <div class="container">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Pages</a></li>
                        <li><a href="#">Custom page</a></li>
                    </ul>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="container">    
	<h2 class="page-header"><strong>212</strong> jobs from 9 232 matches your search criteria</h2>

<div class="row">
    <div class="col-sm-3">
        <div class="filter-stacked">
    <form method="post" action="http://preview.byaviators.com/template/profession/positions.html?">
        <div class="form-group">
            <input type="text" class="form-control" placeholder="Keyword">
        </div>

        <h3>Salary <a href="#"><i class="fa fa-close"></i></a></h3>

        <div class="split-forms">
            <div class="form-group">
                <input type="number" class="form-control" placeholder="Min.">
            </div>

            <div class="form-group">
                <input type="number" class="form-control" placeholder="Max.">
            </div>
        </div><!-- /.split-forms -->

        <h3>Contract <a href="#"><i class="fa fa-close"></i></a></h3>

        <div class="checkbox">
            <label><input type="checkbox"> Full-time</label>
        </div><!-- /.checkbox -->

        <div class="checkbox">
            <label><input type="checkbox"> Part-time</label>
        </div><!-- /.checkbox -->

        <div class="checkbox">
            <label><input type="checkbox"> One-time project</label>
        </div><!-- /.checkbox -->

        <a href="#" class="filter-stacked-show-more">Show More ...</a>

        <h3>Location <a href="#"><i class="fa fa-close"></i></a></h3>

        <div class="checkbox">
            <label><input type="radio" name="radio-test" value="1"> San Francisco</label>
        </div><!-- /.checkbox -->

        <div class="checkbox">
            <label><input type="radio" name="radio-test" value="2"> Sacramento</label>
        </div><!-- /.checkbox -->

        <div class="checkbox">
            <label><input type="radio" name="radio-test" value="3"> Los Angeles</label>
        </div><!-- /.checkbox -->

        <a href="#" class="filter-stacked-show-more">Show More ...</a>

        <h3>Status <a href="#"><i class="fa fa-close"></i></a></h3>

        <div class="checkbox">
            <label><input type="checkbox"> Most Recent</label>
        </div><!-- /.checkbox -->

        <div class="checkbox">
            <label><input type="checkbox"> Featured</label>
        </div><!-- /.checkbox -->

        <div class="checkbox">
            <label><input type="checkbox"> Urgent</label>
        </div><!-- /.checkbox -->

        <a href="#" class="filter-stacked-show-more">Show More ...</a>

        <button type="submit" class="btn btn-secondary btn-block"><i class="fa fa-refresh"></i> Reset Filter</button>
    </form>
</div><!-- /.filter-stacked -->

    </div><!-- /.col-* -->

    <div class="col-sm-7">
        <div class="positions-list">
            
                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">Senior Data</a>
                        
                            <span>Featured</span>                            
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/dropbox.png" alt=""></span> San Francisco, Dropbox <br></h3>

                    <div class="position-list-item-date">10/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">Junior Java Developer</a>
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/instagram.png" alt=""></span> New York City, New York <br></h3>

                    <div class="position-list-item-date">09/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">PR Manager</a>
                        
                            <span>Urgent</span>                            
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/facebook.png" alt=""></span> Chicago, Michigan <br></h3>

                    <div class="position-list-item-date">08/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">Data Mining Specialist</a>
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/twitter.png" alt=""></span> Philadelphia, Pennsylvania <br></h3>

                    <div class="position-list-item-date">07/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">Python Developer</a>
                        
                            <span>Featured</span>                            
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/airbnb.png" alt=""></span> Denver, Colorado <br></h3>

                    <div class="position-list-item-date">06/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">Senior Data</a>
                        
                            <span>Featured</span>                            
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/dropbox.png" alt=""></span> San Francisco, Dropbox <br></h3>

                    <div class="position-list-item-date">05/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">Junior Java Developer</a>
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/instagram.png" alt=""></span> New York City, New York <br></h3>

                    <div class="position-list-item-date">04/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">PR Manager</a>
                        
                            <span>Urgent</span>                            
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/facebook.png" alt=""></span> Chicago, Michigan <br></h3>

                    <div class="position-list-item-date">03/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">Data Mining Specialist</a>
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/twitter.png" alt=""></span> Philadelphia, Pennsylvania <br></h3>

                    <div class="position-list-item-date">02/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">Python Developer</a>
                        
                            <span>Featured</span>                            
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/airbnb.png" alt=""></span> Denver, Colorado <br></h3>

                    <div class="position-list-item-date">01/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
        </div><!-- /.positions-list -->        

         <div class="center">
	<ul class="pagination">
		<li>
			<a href="#">
				<i class="fa fa-chevron-left"></i>
			</a>
		</li>

		<li><a href="#">1</a></li>
		<li><a href="#">2</a></li>
		<li class="active"><a href="#">3</a></li>
		<li><a href="#">4</a></li>
		<li><a href="#">5</a></li>
		<li>
			<a href="#">
				<i class="fa fa-chevron-right"></i>
			</a>
		</li>
	</ul>
  </div><!-- /.center -->                
    </div><!-- /.col-* -->

    <div class="col-sm-2">
        <div class="banner-wrapper">
            <a href="#">
                <img src="assets/img/tmp/banner-120x600.png" alt="">
            </a>
        </div><!-- /.banner-wrapper -->
    </div><!-- /.col-* -->
</div><!-- /.row -->
</div><!-- /.container -->
        </div><!-- /.main -->
    </div><!-- /.main-wrapper -->
    </div>
</div>
<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>