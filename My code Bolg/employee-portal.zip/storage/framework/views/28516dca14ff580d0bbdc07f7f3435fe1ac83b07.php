<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Employee Portal')); ?></title>

    <!-- Styles -->
	<?php echo Html::style('https://fonts.googleapis.com/css?family=Lato'); ?>

	
	 <?php echo Html::style('admin-asset/css/bootstrap.min.css'); ?> 
	 
	 <?php echo Html::style('admin-asset/css/icon-font.min.css'); ?> 
	 <?php echo Html::style('admin-asset/css/style.css'); ?> 
	   


    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
</head>

<body class="login2">
  
        <?php echo $__env->yieldContent('content'); ?>
   
	<?php echo $__env->make("templates/admin-footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- ================================================
    Scripts
    ================================================ -->
	
	 <?php echo Html::script('admin-asset/js/jquery-1.10.2.min.js'); ?> 
	 
	  <?php echo Html::script('admin-asset/js/bootstrap.min.js'); ?> 
	

</body>
</html>
	

