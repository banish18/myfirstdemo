 <div class="footer-wrapper">
    <div class="footer">
        <div class="footer-bottom">
            <div class="container">
                <div class="footer-bottom-left">
                    &copy; <a href="<?php echo e(route('home')); ?>">Mind Solutions Technology</a>, 2017 All rights reserved.
                </div><!-- /.footer-bottom-left -->

                <div class="footer-bottom-right">
                   A Unit of  <a href="<?php echo e(route('home')); ?>">Maxtel Infosystems Pvt. Ltd.</a>
                </div><!-- /.footer-bottom-right -->
            </div><!-- /.container -->
        </div><!-- /.footer-bottom -->
    </div><!-- /.footer -->
</div><!-- /.footer-wrapper -->
</div>
 
 <?php echo Html::script('frontassets/js/jquery.js'); ?> 
 <?php echo Html::script('frontassets/js/jquery.ezmark.js'); ?> 
 <?php echo Html::script('frontassets/libraries/bootstrap-sass/javascripts/bootstrap/collapse.js'); ?> 
 <?php echo Html::script('frontassets/libraries/bootstrap-sass/javascripts/bootstrap/dropdown.js'); ?> 
 <?php echo Html::script('frontassets/libraries/bootstrap-sass/javascripts/bootstrap/tab.js'); ?> 
 <?php echo Html::script('frontassets/libraries/bootstrap-sass/javascripts/bootstrap/transition.js'); ?> 
 <?php echo Html::script('frontassets/libraries/bootstrap-fileinput/js/fileinput.min.js'); ?> 
 <?php echo Html::script('frontassets/libraries/bootstrap-select/js/bootstrap-select.min.js'); ?> 
 <?php echo Html::script('frontassets/libraries/bootstrap-wysiwyg/bootstrap-wysiwyg.min.js'); ?> 
 <?php echo Html::script('frontassets/libraries/cycle2/jquery.cycle2.min.js'); ?> 
 <?php echo Html::script('frontassets/libraries/cycle2/jquery.cycle2.carousel.min.js'); ?> 
 <?php echo Html::script('frontassets/libraries/countup/countup.min.js'); ?> 
 <?php echo Html::script('frontassets/js/profession.js'); ?>  
 <?php echo Html::script('frontassets/js/style.js'); ?> 
  <?php echo Html::script('frontassets/js/jquery-ui.js'); ?> 