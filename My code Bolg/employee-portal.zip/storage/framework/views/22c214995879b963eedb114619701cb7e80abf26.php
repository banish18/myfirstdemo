<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
<div class="page-title">
<div class="row">
<div class="col-md-12">
<h1>Full and Final Detail</h1></div></div>
</div>
<div class="row">
<div class="col-md-2">
<ul class="list-group">
			<li class="list-group-item active" >
			<a href="<?php echo e(route('users',array('action' => 'fullandfinal'))); ?>">
           <p>
            <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;List Employees
           </p></a>  	
           </li>

           <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'add-previous'))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add Employee
           </p>
           </a>
           </li>
		   
		    <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'final-detail'))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Full and Final Detail
           </p>
           </a> 
           </li>
           
            </ul>
</div>

<div class="col-md-10">
<div class="widget-container fluid-height clearfix">
<div class="widget-content padded">
<form method="post" class="form-horizontal" action="<?php echo e(route('users',array('action' => 'postUpdateFinal'))); ?>" enctype="multipart/form-data">

 <?php echo e(csrf_field()); ?>


<div class="row">
<div class="col-md-12">
<div class="col-md-9">
<div class="heading"><h2>Employee Reporting Details</h2></div><br>
<div class="form-group">
            <label class="control-label col-md-3">Select Employee</label>
            <div class="col-md-7">
			<?php echo e(csrf_field()); ?>

               <select data-placeholder="Select Employee" style="width:350px;" class="chosen-select form-control col-md-7" tabindex="7" name="user" onchange="getFullandfinal(this)"> 
				<option value="">Please Select User To Add Credential</option>
				 <?php if($data["users"]): ?>
					 <?php $__currentLoopData = $data["users"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($user->id); ?>"><?php echo e($user->name.'('.$user->uuid.')'); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	 
			  </select>
			  <?php if($errors->has('user')): ?>
					<span class="help-block">
						<strong><?php echo e($errors->first('user')); ?></strong>
					</span>
				<?php endif; ?>
            </div>
		
          </div>
<div class="form-group">
<label class="control-label col-md-3">Regignation Apply Date</label>
<div class="col-md-7">
 <input type="text" class="form-control" name="rgappdate" id="rgappdate" />
</div>

</div>
<div class="form-group">
<label class="control-label col-md-3">Actual Regignation Date</label>
<div class="col-md-7">
 <input type="text" class="form-control" name="rgadate" id="rgadate"/>
</div></div>
<div class="form-group">
<label class="control-label col-md-3">Notice Period</label>
<div class="col-md-7">
 <input type="text" class="form-control" name="nperiod" id="nperiod" />
</div> </div>
<div class="form-group">
<label class="control-label col-md-3">Any Pending</label>
 <div class="col-md-7">
 <div id="anypend">
	<label>Yes</label>
	 <input type="radio" name="pendi" id="pendy" onclick="setPendi(this)" value="1" />
	  <label>No</label>
	<input type="radio" name="pendi" id="pendn" onclick="setPendi(this)" value="0" />
</div>	

 <input type="text" class="form-control" name="pending" id="pending" />
</div>
 </div>
 <div class="form-group">
<label class="control-label col-md-3">Hoto</label>

 <div class="col-md-7 hoto"> 
 <label>Yes</label>
 <input type="radio" name="hoto" id="hotoy" value="1" />
  <label>No</label>
 <input type="radio" name="hoto" id="hoton" value="0" />
</div>
 </div>


<div class="form-group">
<div class="col-md-12">
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-success" type="submit" name="submit_employee"> Submit</button>
</div>
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
</div>
</div></div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>

<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
	
	function getFullandfinal(elm){
		var id = $(elm).val();
		var siteurl 	= "http://portal.mindxpert.com/";
			var token = jQuery("input[name=_token]").val();
			$.ajax({
				url: siteurl+'users/get-fullemp',
				type: 'POST',
				data: {_token: token,id:id},
				dataType: 'JSON',
				success: function (data) {
					if(data.result == null){
						$("#rgappdate").val('');
						$("#rgadate").val(''); 
						$("#nperiod").val('');
						$("#pending").val(''); 
						if(data.result.hoto == 1){
							$(".hoto").html( '<label>Yes</label><input type="radio" name="hoto" id="hotoy" value="1" /><label>No</label><input type="radio"  name="hoto" id="hoton" value="0" />' ) ;
						}else{
							$(".hoto").html( '<label>Yes</label><input type="radio" name="hoto" id="hotoy" value="1" /><label>No</label><input type="radio" name="hoto" id="hoton" value="0" />' ) ;
						}
					}
					$("#rgappdate").val(data.result.rgappdate);
					$("#rgadate").val(data.result.rgadate); 
					$("#nperiod").val(data.result.nperiod);
					$("#pending").val(data.result.pending); 
					if(data.result.pending == "0"){
						$("#pending").hide();
						$("#pendn").prop("checked", true)
					}else{
						$("#pendy").prop("checked", true)
					}
					if(data.result.hoto == 1){
						$(".hoto").html( '<label>Yes</label><input type="radio" name="hoto" id="hotoy" value="1" checked="checked" /><label>No</label><input type="radio"  name="hoto" id="hoton" value="0" />' ) ;
					}else{
						$(".hoto").html( '<label>Yes</label><input type="radio" name="hoto" id="hotoy" value="1" /><label>No</label><input type="radio" name="hoto" checked="checked" id="hoton" value="0" />' ) ;
					}
				}
			}); 
	}
	$(function(){
		$("#rgappdate").datepicker();
		$("#rgadate").datepicker();
	});
	function setPendi(elm){
		if($(elm).val() == "1"){
			$("#pending").show("slow");
		}else{
			$("#pending").hide("slow");
		}
	}
	
  </script>
<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>