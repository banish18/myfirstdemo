<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
<div class="page-title">
<div class="row">
<div class="col-md-6">
<h1><?php echo e($data['user']->name); ?> Profile</h1>
</div>

</div></div>
<div class="row">
 <div class="col-md-2">
           <ul class="list-group">
			 	<li class="list-group-item active" >
		 <a href="<?php echo e(route('users')); ?>">
           <p>
            <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;List Employees
           </p></a>
           </li>

           <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'add'))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add Employee
           </p>
           </a> 
           </li>
		   
		   <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'address-proof','id' => $data['user']->id))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Address and Id Proofs
           </p>
           </a>
           </li>
		   
		   <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'education','id' => $data['user']->id))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Educational Docs
           </p>
           </a>
           </li>
		   
		    <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'previous-employement','id' => $data['user']->id))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Previous Employement Detail
           </p>
           </a>
           </li>
           
            </ul>
        </div>
		<div class="col-md-10">
		<h2>Education Docs</h2>
		<div class="widget-container fluid-height clearfix">
			<div class="widget-content padded">
		
		  <form method="post" action="<?php echo e(route('users',array('action' => 'updateEducation'))); ?>" enctype="multipart/form-data">
				 <?php echo e(csrf_field()); ?>

				  <input type="hidden" class="uid" name="uid" value="<?php echo e($data['user']->id); ?>">
			<div class="col-md-6">
				<div class="form-group">
					<label class="control-label col-md-3">10th
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Education"] && $data["Education"]->matric != ""): ?>
						<input type="hidden" value="<?php echo e($data['Education']->matric); ?>" name="pre10th">
						<img src="<?php echo e(asset('images/users/'.$data['Education']->matric)); ?>" />
					<?php else: ?>
						<input type="hidden" value=" " name="pre10th">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>	
					
					
					
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" name="10th" onchange="checkSize(this)"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				
				<div class="clear"></div>
				
				
				<div class="form-group">
					<label class="control-label col-md-3">12th
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Education"] && $data["Education"]->plustwo != ""): ?>
						<input type="hidden" value="<?php echo e($data['Education']->plustwo); ?>" name="preplustwo">
						<img src="<?php echo e(asset('images/users/'.$data['Education']->plustwo)); ?>" />
					<?php else: ?>
						<input type="hidden" value="" name="preplustwo">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>	
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" onchange="checkSize(this)" name="plustwo" id="profile_pic"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				
				<div class="form-group">
					<label class="control-label col-md-3">Diploma
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Education"] && $data["Education"]->diploma != ""): ?>
						<img src="<?php echo e(asset('images/users/'.$data['Education']->diploma)); ?>" />
						<input type="hidden" value="<?php echo e($data['Education']->diploma); ?>" name="prediploma">
					<?php else: ?>
						<input type="hidden" value="" name="prediploma">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>	
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" name="diploma" onchange="checkSize(this)" id="profile_pic"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				</div>
				<div class="col-md-6">
				
				<div class="form-group">
					<label class="control-label col-md-3">Graduation
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Education"] && $data["Education"]->graduation != ""): ?>
						<img src="<?php echo e(asset('images/users/'.$data['Education']->graduation)); ?>" />
						<input type="hidden" value="<?php echo e($data['Education']->graduation); ?>" name="pregraduation">
					<?php else: ?>
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
						<input type="hidden" value="" name="pregraduation">
					<?php endif; ?>
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" onchange="checkSize(this)" name="graduation" id="profile_pic"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				
				<div class="form-group">
					<label class="control-label col-md-3">Post Graduation
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Education"] && $data["Education"]->postgraduation != ""): ?>
						<img src="<?php echo e(asset('images/users/'.$data['Education']->postgraduation)); ?>" />
						<input type="hidden" value="<?php echo e($data['Education']->postgraduation); ?>" name="prepostgraduation">
					<?php else: ?>
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
						<input type="hidden" value="" name="prepostgraduation">
					<?php endif; ?>
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" onchange="checkSize(this)" name="postgraduation" id="profile_pic"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				
				
				<div class="form-group">
					<label class="control-label col-md-3">Other
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Education"] && $data["Education"]->other != ""): ?>
						<input type="hidden" value="<?php echo e($data['Education']->other); ?>" name="">
						<img src="<?php echo e(asset('images/users/'.$data['Education']->other)); ?>" />
					<?php else: ?>
						<input type="hidden" value="" name="">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" onchange="checkSize(this)" name="other" id="profile_pic"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				</div>
				
				
				<div class="col-md-5" ></div>
				<div class="col-md-2"><div class="form-group"><input name="save" class="btn btn-lg btn-block btn-success" type="submit" value="save" /></div></div>
				<div class="col-md-5"></div>
				
				
				</form>
				</div></div>
        </div>

</div>

</div>
<?php echo $__env->make("templates/admin-footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
function checkSize(elm) {
	
var a = elm.files[0].size;

var b= 67108864;
if(a>b)
alert("File size must be less than 64M");
}

</script>
<!-- ----------------------END------------------------------------- -->
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>