<?php $__env->startSection('content'); ?>
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Edit Bank Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Edit Bank Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			<?php echo $__env->make("employee_self_services/profile/sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
		  
		  <form method="post" action="<?php echo e(route('employee-services',array('action' => 'postupdateBank'))); ?>">
			  <?php echo e(csrf_field()); ?>

			  <div class="col-sm-12" style="border: 1px solid #ccc;">
					<p class="section_header col-md-4">Account type</p>
						<div class="col-md-8">
						<input class="input-block-level col-md-8" name="account_type" placeholder="Account Type" value="<?php echo e($data['bank']->account_type); ?>" type="text" required>
						</div>
							<div class="clearfix"></div>
						<p class="section_header col-md-4">Account Nature</p>
						<div class="col-md-8">
						<input class="input-block-level col-md-8" name="nature" placeholder="Account Nature" value="<?php echo e($data['bank']->nature); ?>" type="text" required>
						
						</div>
						<div class="clearfix"></div>
						<p class="section_header col-md-4">Account No.</p>
						<div class="col-md-8">
						<div class="clearfix"></div>
						<input class="input-block-level col-md-8" name="account_no" placeholder="Account Number" value="<?php echo e($data['bank']->account_no); ?>" type="text" required>
						
						</div>
						<div class="clearfix"></div>
						<p class="section_header col-md-4">Primary Account/Salary Account</p>
						<div class="col-md-8">
							<?php 
								if($data['bank']->account_for == 1){
									$y = 'selected=selected';
									$n = '';
								}else{
									$n = 'selected=selected';
									$y = '';
								}
							?>
							<select name="account_for" required>
								<option value="">Please Select</option>
								<option value="1" <?php echo e($y); ?>>Yes</option>
								<option value="2" <?php echo e($n); ?>>No</option>
							</select>
						</div>
						
						<div class="clearfix"></div>
						<div class="col-md-3" style="float:right;">
							<input type="hidden" name="id" value="<?php echo e($data['bank']->id); ?>" />
							<input class="btn btn-info col-md-8" name="submit" value="Submit" type="Submit" />
						</div>
						<div class="clearfix"></div>		
			  </div>
		  </form>
            

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>