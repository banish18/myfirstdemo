<?php $__env->startSection('content'); ?>
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Edit Address Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>edit Address Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			<ul>
			<li>
			<a class="side-menu-main-active" href="<?php echo e(route('employee-services',array('action' => 'addressDetail'))); ?>"> Address Detail</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">Bank Details</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">Card Details</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">Change Work Location</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">IOU Detail</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">Language Details</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">Lost Damage Card</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">My Cards</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">My Contacts</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">My Profile</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">My Resume</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">My Role</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">National Identifier</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">Qualification Detail</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">Team Information</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('leaves',array('action' => 'apply-leaves'))); ?>">Work Experience</a>
			</li>
			</ul>
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
		  
		  <form method="post" action="<?php echo e(route('employee-services',array('action' => 'postupdateAddress'))); ?>">
			  <?php echo e(csrf_field()); ?>

		  <div class="col-sm-12" style="border: 1px solid #ccc;">
							
						<div class="page_details_header" style="margin-top:20px;"><em><strong>Family details as present in our record(s)</strong></em>
		               
						</div>
                         
						 <p>Please go to My Profile &gt; My Contacts to edit family details.</p>
						
						
						
						<p class="section_header">Address type</p>
						<div class="col-md-12">
						<input class="input-block-level" name="address_type" placeholder="Address Type" value="<?php echo e($data['Empaddress']->address_type); ?>" type="text">
						</div>
							<div class="clearfix"></div>
						<p class="section_header">Address Line 1</p>
						<div class="col-md-12">
						<input class="input-block-level" placeholder="Address Line 1" name="address_line1" value="<?php echo e($data['Empaddress']->address_line1); ?>" type="text">
						</div>
						<div class="clearfix"></div>
						<p class="section_header">Address Line 2</p>
						<div class="col-md-12">
						<input class="input-block-level" name="address_line2" placeholder="Address Line 2" value="<?php echo e($data['Empaddress']->address_line2); ?>" type="text">
						</div>
						<div class="clearfix"></div>
						<p class="section_header">Primary Address</p>
						<div class="col-md-4">
							<input type="hidden" name="id" value="<?php echo e($data['Empaddress']->id); ?>" />
							<input class="input-block-level" placeholder="Primary Address" name="primary_address" value="<?php echo e($data['Empaddress']->primary_address); ?>" type="text">
						</div>
						<div class="clearfix"></div>
						<p class="section_header">Country</p>
						<div class="col-md-12">
							<input class="input-block-level" placeholder="Country" name="country" value="" type="text">
						</div>
						<div class="clearfix"></div>
						<div class="col-md-3">
							<input class="input-block-level" name="submit" value="Submit" type="Submit" />
						</div>
				 </div>
		  </form>
            

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>