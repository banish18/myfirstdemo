<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
<div class="page-title">
        <h1>Edit Department</h1>
   </div>
 <div class="row">
 <div class="col-md-2">
  <ul class="list-group">
      <li class="list-group-item">
           <a  href="<?php echo e(route('company')); ?>">
           <p>
           <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;List
           </p></a>
           </li>   <li class="list-group-item active" >
           <a  href="<?php echo e(route('company',array('action' => 'add'))); ?>">
           <p>
           <img src="<?php echo e(asset('admin-asset/images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add
           </p></a>
           </li>
                       </ul>
        </div>
 <div class="col-md-10">
 <div class="widget-container fluid-height clearfix">
 <div class="widget-content padded">
 <form method="post" class="form-horizontal" action="<?php echo e(route('company',array('action' => 'postUpdate'))); ?>" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

 <div class="row">
 <div class="col-md-12">
 <div class="col-md-8">

 <div class="form-group">
            <label class="control-label col-md-4">Company Name</label>
            <div class="col-md-8">
              <input class="form-control"  type="text" name="name" value="<?php echo e($data['company']->name); ?>">
            </div>
          </div>
		  <div class="form-group">
            <label class="control-label col-md-4">Company Logo</label>
            <div class="col-md-8">
				<?php if($data['company']->logo != ""): ?>
					<img src="<?php echo e(asset('images/users/company/'.$data['company']->logo)); ?>" alt="company logo" />
				<?php endif; ?>	
				
              <input class="form-control"  type="file" name="logo" value="">
            </div>
          </div>
		  <div class="form-group">
            <label class="control-label col-md-4">Company Email</label>
			 <div class="col-md-6">
			 <input class="form-control"  type="text" name="email[]" value="<?php echo e(json_decode($data['company']->email)[0]); ?>">
            </div>
			<div class="col-md-2"><input type="button" onclick="moreField(this)" value="+" class="btn btn-success" /></div>
			<div class="more">
               <?php if(is_array(json_decode($data['company']->email))): ?>
				   <?php 
				$array = json_decode($data['company']->email);
			
						unset($array[0]);
					
					?>
				   <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			   
			   <label class="control-label col-md-4"></label><div class="col-md-8"><input class="form-control"  type="text" name="email[]" value="<?php echo e($email); ?>" style="float: left;width: 74%;"><input type="button" onclick="removeField(this)" style="margin-left:21px;float:left;width:32px;" value="-" class="btn btn-success" /></div>
			       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			   <?php endif; ?>
            </div>
			 
          </div>
</div></div>
<input type="hidden" name="plogo" value="<?php echo e($data['company']->logo); ?>" />

    <div class="row">
     <div class="col-md-12">
   <div class="col-md-6">
   <input type="hidden" name="id" value="<?php echo e($data['company']->id); ?>" />
    <button class="btn btn-lg btn-block btn-success" type="submit" name="submit_department"> Submit</button>
   </div>
  <div class="col-md-6">
  <button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
  </div></div></div>
 </form>
 </div>
 </div>
 </div>
 </div></div>


		
<?php echo $__env->make("templates/admin-footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
function moreField(elm){
	$(".more").append('<label class="control-label col-md-4"></label><div class="col-md-8"><input class="form-control"  type="text" name="email[]" value="" style="float: left;width: 74%;"><input type="button" onclick="removeField(this)" style="margin-left:21px;float:left;width:32px;" value="-" class="btn btn-success" /></div>');
}
function removeField(elm){
	$(elm).parent().remove();
}
</script>
<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>