<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
  <div class="page-title">
  <div class="row">
  <div class="col-md-12">

          <h1>
           Employees
          </h1>

          </div></div>
                </div>

        <div class="row">
        <div class="col-md-2">

        <div class="widget-container fluid-height" >
              <div class="widget-content">

                <div class="panel-group" id="accordion">
                  <div class="panel">
                    <div class="panel-heading">
                    </div>
                  </div>
                  <div class="panel">
                    <div class="panel-heading">
                      <div class="panel-title">
                      </div>
                    </div>
                    <div class="panel-collapse collapse in" id="collapseTwo">
                    </div>
                  </div>
                  <div class="panel filter-categories">
                    <div class="panel-heading">
                      <div class="panel-title">
               <a class="accordion-toggle collapsed" data-parent="#accordion" data-toggle=collapse href="#collapseThree">
                        <div class="caret pull-right"></div>
                        Departments</a>
                      </div>
                    </div>
                    <div class="panel-collapse collapse in" id="collapseThree">
                      <div class="panel-body">
                      <form method="GET" action="">
                      <input type="hidden" value="view_employees" name="user">
                      <select class="form-control" name="department">
                      <option value="">Show All</option>
                                            <option                         value="1">Super Admin</option>

                                            <option                         value="2">HR</option>

                                            <option                         value="7">Sales</option>

                      
                      </select><br />
                      <button  class="btn btn-block btn-success"  name="submitfilter" >
                       Submit</button>
                      </form></div></div>   </div>
                </div>
              </div>
            </div>
<br>
		<ul class="list-group">
			 		  <li class="list-group-item active" >
           <a href="https://shiftsystems.net/demo/index.php?user=view_employees">
           <p>
            <img src="images/dots-beginning-text-lines-interface-button-symbol.svg" width="15">
           &nbsp;List Employees
           </p></a>
           </li>

                          <li class="list-group-item">
           <a  href="https://shiftsystems.net/demo/index.php?user=newemployee">
           <p>
           <img src="images/plus-sign-in-circle.svg" width="15">
           &nbsp;Add Employee
           </p>
           </a>
           </li>
           
            </ul>
  <ul class="list-group">
<li class="list-group-item" >
           <a  href="https://shiftsystems.net/demo/index.php?user=leave_approval_list">
           <p>

           <img src="images/dots-beginning-text-lines-interface-button-symbol.svg" width="15">
           &nbsp;Leaves
           </p></a>
           </li>
</ul><ul class="list-group">
            <li class="list-group-item">
           <a href="https://shiftsystems.net/demo/index.php?user=view_claims_report">
           <p>
           <img src="images/dots-beginning-text-lines-interface-button-symbol.svg" width="15">
           &nbsp;List Claims
           </p></a>
           </li>
                     <li class="list-group-item ">
           <a  href="https://shiftsystems.net/demo/index.php?user=expense_claims">
           <p>

           <img src="images/plus-sign-in-circle.svg" width="15">
           &nbsp;Add Claims
           </p></a>
           </li></ul>

<ul class="list-group">
		  <li class="list-group-item" >
           <a  href="https://shiftsystems.net/demo/index.php?user=view_awards">
           <p>
            <img src="images/dots-beginning-text-lines-interface-button-symbol.svg" width="15">

           &nbsp;List Awards
           </p></a>
           </li>                 <li class="list-group-item">
           <a  href="https://shiftsystems.net/demo/index.php?user=add_awards">
           <p>
            <img src="images/plus-sign-in-circle.svg" width="15">

           &nbsp;Add Award
           </p></a>
           </li>


           </ul>
         </div>


         <!-- Search and show per page on top of table -->
         <div class="col-md-10">

             <form method="post" action="">
            <div class="row">
            <div class="col-md-12">
  <div class="col-md-6">
<button type="submit" class="btn btn-danger show_delete_button" name="delete_all_entries" style="display:none;"><span>Delete Selected</span></button>
         </div>
          <div class="col-md-6">
            <button type="submit" class="btn  btn-primary pull-right" name="gen_pdf"><span>All Employee's IR8A Forms</span></button>
          </div>

          </div></div>

            <div class="col-md-12">

            <div class="widget-container fluid-height clearfix">
            <div class="widget-content padded clearfix ">
            <div class="table-responsive">
                  <table class="table table-striped" id="dataTable3">
                    <thead>
                    <tr role="row">
                    <th class="check-header">

                    </th>
                     <th> S.NO</th>
                       <th> Employee Code</th>
                       <th> First Name </th>
                       <th> Last Name</th>
                       <th> Department</th>
                        <th>Actions</th>
                     </tr>
                    </thead>

                    <tbody>
                                            <tr>
                        <td class="check">
                         <input type="hidden" value="9" name="checkid[]" >
                         <input type="checkbox" value="9" name="checkempid[]" class="check_particular" data-id="9">
<input type="hidden" class="prev_select_item_id" value="">
                        </td>
                        <td >1</td>
                        <td></td>
                          <td >  </td>
                        <td >  </td>
                        <td> Super Admin </td>
<td class="action"></td>

                                               </tr>                        <tr>
                        <td class="check">
                         <input type="hidden" value="16" name="checkid[]" >
                         <input type="checkbox" value="16" name="checkempid[]" class="check_particular" data-id="16">
<input type="hidden" class="prev_select_item_id" value="">
                        </td>
                        <td >2</td>
                        <td>003</td>
                          <td > Emmett </td>
                        <td > Booth </td>
                        <td> Sales </td>
                 <td class="action" >

             <div class="btn-group">
                      <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i>Options<span class="caret"></span>
                      </button>
                      <ul class="dropdown-menu">

                                            <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=display_employee_details&id=16">View</a>
                         </li>                      <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=edit_employee&editid=16">Edit</a></li>
                                                                        <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=add_emp_salary&id=16"><span >Salary Template</span></a></li>
                                    <li>  <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=newpdfgenerate&id=16&empdata=gen"><span >KET Pdf</span></a></li>
             <li>  <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=ketprint&id=16"><span >KET Print</span></a></li>
                                 <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=form_IR8A&id=16"><span >IR8A forms</span>
                    </a></li>            <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=forms_pdf&appendix_id=16"><span >Appendix8A</span>
                    </a></li>
                 <li>   <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=forms_pdf&appendix8b_id=16"><span >Appendix8B</span>
                    </a></li>
               <li>     <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=forms_pdf&ir8s_id=16"><span >IR8S</span>
                    </a></li>
                    <li>  <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=employee_leaves&editid=16"><span >Employee Leaves</span>
                    </a></li>


                          		                         <li><a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=myclaims&emp_id=16"><span>Claims</span></a></li>
                          		                           <li><a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=view_awards&emp_id=16"><span>Awards</span></a></li>
  <li><a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=leaveshistory&emp_id=16"><span>Leaves History</span></a></li>

	                          		     <li>                    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=view_employees&deleteid=16&department=7"><span style="color:red;">Delete</span></a></li>
                          		                                          </ul>
</div>
                          </td>
                                               </tr>                        <tr>
                        <td class="check">
                         <input type="hidden" value="17" name="checkid[]" >
                         <input type="checkbox" value="17" name="checkempid[]" class="check_particular" data-id="17">
<input type="hidden" class="prev_select_item_id" value="">
                        </td>
                        <td >3</td>
                        <td>m12122</td>
                          <td > tests </td>
                        <td >  </td>
                        <td> Sales </td>
                 <td class="action" >

             <div class="btn-group">
                      <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i>Options<span class="caret"></span>
                      </button>
                      <ul class="dropdown-menu">

                                            <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=display_employee_details&id=17">View</a>
                         </li>                      <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=edit_employee&editid=17">Edit</a></li>
                                                                        <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=add_emp_salary&id=17"><span >Salary Template</span></a></li>
                                    <li>  <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=newpdfgenerate&id=17&empdata=gen"><span >KET Pdf</span></a></li>
             <li>  <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=ketprint&id=17"><span >KET Print</span></a></li>
                             <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=forms_pdf&appendix_id=17"><span >Appendix8A</span>
                    </a></li>
                 <li>   <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=forms_pdf&appendix8b_id=17"><span >Appendix8B</span>
                    </a></li>
               <li>     <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=forms_pdf&ir8s_id=17"><span >IR8S</span>
                    </a></li>
                    <li>  <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=employee_leaves&editid=17"><span >Employee Leaves</span>
                    </a></li>


                          		                         <li><a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=myclaims&emp_id=17"><span>Claims</span></a></li>
                          		                           <li><a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=view_awards&emp_id=17"><span>Awards</span></a></li>
  <li><a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=leaveshistory&emp_id=17"><span>Leaves History</span></a></li>

	                          		     <li>                    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=view_employees&deleteid=17&department=7"><span style="color:red;">Delete</span></a></li>
                          		                                          </ul>
</div>
                          </td>
                                               </tr>                        <tr>
                        <td class="check">
                         <input type="hidden" value="18" name="checkid[]" >
                         <input type="checkbox" value="18" name="checkempid[]" class="check_particular" data-id="18">
<input type="hidden" class="prev_select_item_id" value="">
                        </td>
                        <td >4</td>
                        <td>123</td>
                          <td > Alice </td>
                        <td > McCarty </td>
                        <td> HR </td>
                 <td class="action" >

             <div class="btn-group">
                      <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i>Options<span class="caret"></span>
                      </button>
                      <ul class="dropdown-menu">

                                            <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=display_employee_details&id=18">View</a>
                         </li>                      <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=edit_employee&editid=18">Edit</a></li>
                                                                        <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=add_emp_salary&id=18"><span >Salary Template</span></a></li>
                                    <li>  <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=newpdfgenerate&id=18&empdata=gen"><span >KET Pdf</span></a></li>
             <li>  <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=ketprint&id=18"><span >KET Print</span></a></li>
                             <li>    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=forms_pdf&appendix_id=18"><span >Appendix8A</span>
                    </a></li>
                 <li>   <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=forms_pdf&appendix8b_id=18"><span >Appendix8B</span>
                    </a></li>
               <li>     <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=forms_pdf&ir8s_id=18"><span >IR8S</span>
                    </a></li>
                    <li>  <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=employee_leaves&editid=18"><span >Employee Leaves</span>
                    </a></li>


                          		                         <li><a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=myclaims&emp_id=18"><span>Claims</span></a></li>
                          		                           <li><a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=view_awards&emp_id=18"><span>Awards</span></a></li>
  <li><a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=leaveshistory&emp_id=18"><span>Leaves History</span></a></li>

	                          		     <li>                    <a class="table-actions" href="https://shiftsystems.net/demo/index.php?user=view_employees&deleteid=18&department=2"><span style="color:red;">Delete</span></a></li>
                          		                                          </ul>
</div>
                          </td>
                                               </tr>                    </tbody>
                  </table></div></div></div>
                  </div>
                  </form>


                
              </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>