
   <div class="modal-shiftfix">
      <!-- Navigation -->
      <div class="navbar navbar-fixed-top scroll-hide">
        <div class="container-fluid top-bar">

          <div class="pull-right">
            <ul class="nav navbar-nav pull-right">
<li style="margin-top:10px;">
<div class="hidden-xs" id="txt">

 </div>
</li>
              <li class="dropdown notifications hidden-xs">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">

            <span aria-hidden="true"  style="margin-top:-5px;">
             <img src="images/info.svg"/>
</span>
                </a>
                <ul class="dropdown-menu">
                  <li><a href="#">
<b> Department </b>: Super Admin                     </a>
                  </li>
              <li><a href="#">
                                <b> Office Timings</b> : 12:00 AM - 08:00 PM                                </a>
              </li>

                </ul>
              </li>
<!-- ---------------------------For Mark Attendance----------------------------------------- -->
               <!-- -------------------------------END---------------------------------------- -->
            <li class="dropdown user hidden-xs "><a data-toggle="dropdown" class="dropdown-toggle" href="#">


                             <img src="//www.placehold.it/200x150/EFEFEF/AAAAAA&text=no+image" width="34" /><b class="caret"></b>
                   </a>
                <ul class="dropdown-menu">
                <li>
                <a class="" href="https://shiftsystems.net/demo/index.php?user=profile&id=9">


             <img src="images/profile.svg" width="19"/>
             Profile

             </a>
                  </li>
              <li><a href="https://shiftsystems.net/demo/index.php?user=changepassword">

               <img src="images/locked.svg" width="19"/>
               Change Password</a>
              </li>

                              <li><a class="" href="https://shiftsystems.net/demo/index.php?user=view_holiday">


                <img src="images/sun-umbrella.svg" width="19"/>
                Holidays</a>
              </li>
                
                                       <li>
                      <a href="https://shiftsystems.net/demo/index.php?user=view_noticeboard" class="">

<img src="images/warning.svg" width="19"/>
                      Notice Board</a>
                      </li>
               
                <li> <a class="" href="https://shiftsystems.net/demo/index.php?user=office_management">


<img src="images/briefcase.svg" width="19"/>
                Office Management</a>
              </li>
                                                <li><a class="" href="https://shiftsystems.net/demo/index.php?user=site_setting">
<img src="images/settings.svg" width="19"/>
                Settings</a>
              </li>
              
              <li><a href="https://shiftsystems.net/demo/index.php?user=logout">
               <img src="images/logout.svg" width="19"/>
                    Logout</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>

<!-- ----------------------------END---------------------- -->
          <button class="navbar-toggle">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span></button>
           <a  class="logo" href="<?php echo e(route('dashboard')); ?>">
        Employee Portal

       </a>
        </div>
        <div class="container-fluid main-nav clearfix">
          <div class="nav-collapse">
  <ul class="nav">
              <li>
                <a class="current" href="<?php echo e(route('dashboard')); ?>">
                <span aria-hidden="true"  >
                <img src="images/speedometer.svg" style="margin-top: -17px;">
                </span>
                My Dashboard</a>
              </li>
                                 <li><a class=""
                  href="<?php echo e(route('users')); ?>">
                <span aria-hidden="true" >
                <img src="images/employees.svg" style="margin-top: -17px;">
                </span>Employees</a>
              </li>
              
              <li><a class="" href="">
                <span aria-hidden="true">
                <img src="images/users.svg" style="margin-top: -17px;">
                </span>Departments</a>
              </li>
                                          <li><a class="" href="">
                <span aria-hidden="true"  >
                 <img src="images/check-mark.svg" style="margin-top: -17px;">

                </span>Payroll</a></li>


              
                       <li class="dropdown">
          <a data-toggle="dropdown" class="" href ="">
                <span aria-hidden="true" >
               <img src="images/calendar.svg" style="margin-top: -17px;">
                </span>Attendances/Leaves<b class="caret"></b></a>
                <ul class="dropdown-menu">

                  <li>
                    <a class="" href="">Attendances</a>
                  </li>

                   <li>
                    <a class="" href="">Leaves</a>
                  </li>
                </ul>
              </li>
              
                  <li>
                  <a class="" href="">
                   <span aria-hidden="true" >
                   <img src="images/text-lines.svg" style="margin-top: -17px;">
                   </span>
                  Claims</a>
                  </li> <li class="dropdown">
 <a data-toggle="dropdown" class="" href ="">
                <span aria-hidden="true" >
               <img src="images/notebook.svg" style="margin-top: -17px;">
                </span>Reports<b class="caret"></b></a>

                <ul class="dropdown-menu">
                  <li>
                    <a class="" href="">Employee Based Payslips Report</a>
                  </li>                  <li>
                    <a class="" href="">Yearly Payslips Report</a>
                  </li>
                </ul>
              </li>
   <li>
                <a href="<?php echo e(route('logout')); ?>">
                <span aria-hidden="true"  >
                <img src="images/logout.svg" style="margin-top: -17px;">
                </span>
                Logout</a>
              </li>

            </ul>
          </div>
        </div>
      </div>
      </div>