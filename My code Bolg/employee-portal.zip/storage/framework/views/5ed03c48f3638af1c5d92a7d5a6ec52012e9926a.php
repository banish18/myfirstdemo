<!-- ================================================
    Scripts
    ================================================ -->
	 <!-- jQuery Library -->
	<?php echo Html::script('admin-asset/js/jquery-1.10.2.min.js'); ?>

	<?php echo Html::script('admin-asset/js/jquery-ui.min.js'); ?> 
	<?php echo Html::script('admin-asset/js/bootstrap.min.js'); ?> 
	<?php echo Html::script('admin-asset/js/jquery.bootstrap.wizard.js'); ?> 
	<?php echo Html::script('admin-asset/js/jquery.dataTables.min.js'); ?> 
	<?php echo Html::script('admin-asset/js/datatable-editable.js'); ?> 
	<?php echo Html::script('admin-asset/js/jquery.easy-pie-chart.js'); ?> 
	<?php echo Html::script('admin-asset/js/bootstrap-fileupload.js'); ?> 
	<?php echo Html::script('admin-asset/js/fullcalendar.min.js'); ?>

	<?php echo Html::script('admin-asset/js/bootstrap-datepicker.js'); ?> 
    <?php echo Html::script('admin-asset/js/bootstrap-timepicker.js'); ?>  
	<?php echo Html::script('admin-asset/js/jquery.fancybox.pack.js'); ?> 
	<?php echo Html::script('admin-asset/jquery.fancybox.js'); ?> 
	<?php echo Html::script('js/chosen.jquery.js'); ?>  