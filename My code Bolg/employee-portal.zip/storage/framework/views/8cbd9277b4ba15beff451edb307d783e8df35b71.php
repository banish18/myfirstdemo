<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
           <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1>Latest Updates</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="document-breadcrumb">
                <div class="container">
                    <ul class="breadcrumb">
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li>Latest Updates</li>
                    </ul>
                </div><!-- /.container -->
            </div><!-- /.document-title -->
  <div class="container">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="page-header">Latest Updates</h3>
			<p>
			<?php echo e($data['Updates']->latest_updates); ?>

			</p>

			<h3 class="page-header">Others</h3>

			<ul>
				<?php echo e($data['Updates']->others); ?>

			</ul>

			<h3 class="page-header">Vivamus molestie</h3>

			<ul>
				<?php echo e($data['Updates']->vivamus_molestie); ?>

			</ul>
		</div><!-- /.col-* -->
	</div><!-- /.row -->
</div><!-- /.container -->

        </div><!-- /.main -->
    </div><!-- /.main-wrapper -->
    </div>
</div>
<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>