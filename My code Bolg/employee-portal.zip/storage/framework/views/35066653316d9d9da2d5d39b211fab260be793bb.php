<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
<div class="page-title">
<div class="row">
<div class="col-md-6">
<h1><?php echo e($data['user']->name); ?> Profile</h1>
</div>

</div></div>
<div class="row">
 <div class="col-md-2">
           <ul class="list-group">
			 	<li class="list-group-item active" >
		 <a href="<?php echo e(route('users')); ?>">
           <p>
            <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;List Employees
           </p></a>
           </li>

           <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'add'))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add Employee
           </p>
           </a> 
           </li>
		   
		   <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'address-proof','id' => $data['user']->id))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Address and Id Proofs
           </p>
           </a>
           </li>
		   
		   <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'education','id' => $data['user']->id))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Educational Docs
           </p>
           </a>
           </li>
		   
		    <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'previous-employement','id' => $data['user']->id))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Previous Employement Detail
           </p>
           </a>
           </li>
           
            </ul>
        </div>
		<div class="col-md-10">
		<h2>Address Proof</h2>
		<div class="widget-container fluid-height clearfix">
			<div class="widget-content padded">
		
		  <form method="post" action="<?php echo e(route('users',array('action' => 'updateDocs'))); ?>" enctype="multipart/form-data">
				 <?php echo e(csrf_field()); ?>

				  <input type="hidden" class="uid" name="uid" value="<?php echo e($data['user']->id); ?>">
				  <div class="row">
<div class="col-md-12">
			<div class="col-md-6">
				<div class="form-group">
					<label class="control-label col-md-3">Adhar Card
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Addressproof"] && $data["Addressproof"]->adharcard != ""): ?>
						<input type="hidden" value="<?php echo e($data['Addressproof']->adharcard); ?>" name="preadhar">
						<img src="<?php echo e(asset('images/users/'.$data['Addressproof']->adharcard)); ?>" />
					<?php else: ?>
						<input type="hidden" value=" " name="preadhar">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>	
					
					
					
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" name="adhar" onchange="checkSize(this)"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					
						<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
					
					
				</div>
				
				
				
				
				<div class="form-group">
					<label class="control-label col-md-3">Driving License
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Addressproof"] && $data["Addressproof"]->driving_license != ""): ?>
						<input type="hidden" value="<?php echo e($data['Addressproof']->driving_license); ?>" name="predriving_license">
						<img src="<?php echo e(asset('images/users/'.$data['Addressproof']->driving_license)); ?>" />
					<?php else: ?>
						<input type="hidden" value="" name="predriving_license">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>	
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" onchange="checkSize(this)" name="driving_license" id="profile_pic"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				
				<div class="form-group">
					<label class="control-label col-md-3">Pan Card
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Addressproof"] && $data["Addressproof"]->pancard != ""): ?>
						<img src="<?php echo e(asset('images/users/'.$data['Addressproof']->pancard)); ?>" />
						<input type="hidden" value="<?php echo e($data['Addressproof']->pancard); ?>" name="prepancard">
					<?php else: ?>
						<input type="hidden" value="" name="prepancard">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>	
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" name="pancard" onchange="checkSize(this)" id="profile_pic"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				</div>
				<div class="col-md-6">
				
				<div class="form-group">
					<label class="control-label col-md-3">Voter Card
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Addressproof"] && $data["Addressproof"]->votercard != ""): ?>
						<img src="<?php echo e(asset('images/users/'.$data['Addressproof']->votercard)); ?>" />
						<input type="hidden" value="<?php echo e($data['Addressproof']->votercard); ?>" name="prevotercard">
					<?php else: ?>
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
						<input type="hidden" value="" name="prevotercard">
					<?php endif; ?>
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" onchange="checkSize(this)" name="votercard" id="profile_pic"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				
				<div class="form-group">
					<label class="control-label col-md-3">Passport
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Addressproof"] && $data["Addressproof"]->passport != ""): ?>
						<img src="<?php echo e(asset('images/users/'.$data['Addressproof']->passport)); ?>" />
						<input type="hidden" value="<?php echo e($data['Addressproof']->passport); ?>" name="prevotercard">
					<?php else: ?>
						<input type="hidden" value="" name="prevotercard">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" onchange="checkSize(this)" name="passport" id="profile_pic"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-md-3">Other
					</label>
					<div class="col-md-9">
					<div class="fileupload fileupload-new" data-provides="fileupload">
					
					<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
					<?php if($data["Addressproof"] && $data["Addressproof"]->other != ""): ?>
						<input type="hidden" value="<?php echo e($data['Addressproof']->other); ?>" name="">
						<img src="<?php echo e(asset('images/users/'.$data['Addressproof']->other)); ?>" />
					<?php else: ?>
						<input type="hidden" value="" name="">
						<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
					<?php endif; ?>
					</div>
					<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
					<div>
					<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

					<span class="fileupload-exists">Change</span>
					<input type="file" onchange="checkSize(this)" name="other" id="profile_pic"></span>
					<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
					<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
					</div>
					</div>
					<div class="clear" style="float:left;margin-top:39px;"></div>
					</div>
				</div>
				</div>
				
				
				<div class="col-md-5" ></div>
				<div class="col-md-2"><div class="form-group"><input name="save" class="btn btn-lg btn-block btn-success" type="submit" value="save" /></div></div>
				<div class="col-md-5"></div>
				</div>
				</div>
				</form>
				</div></div>
        </div>

</div>

</div>
<?php echo $__env->make("templates/admin-footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
function checkSize(elm) {
	
var a = elm.files[0].size;

var b= 67108864;
if(a>b)
alert("File size must be less than 64M");
}

</script>
<!-- ----------------------END------------------------------------- -->
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>