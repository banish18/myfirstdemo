<?php $__env->startSection('content'); ?>
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Address Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Address Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			<?php echo $__env->make("employee_self_services/claim/sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
				<div class="container">
				<div class="row">
				 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-left" style="border:1px solid #CCC; padding:4px;">
				 <h4>Voice/Data Request Form</h4>
				 <h5 style="color:red; font-size:11px;">Please select a criteria for report generation.After selecting the criteria click on submit. If no criteria selected default values will be used</h5>
				  <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
				 <div class="form-group">
				   <label for="">From Date</label>
					<input id="" class="form-control" required name="start_date" type="date">
				 </div>
				 <div class="form-group">
				  <label for="">To Date</label>
					<input id="" class="form-control" required name="end_date" type="date">
				 </div>
		<div class="form-group">
		<label for="">Country</label>
		<select class="form-control" name="EmpReq:_idJsp114" size="1" style="width: 142;text-align:left;align:center" onchange="submit()">
		<option value="-2">ALL</option>
		<option value="IN">India</option>
		</select>
		</div>
		<div class="form-group">
		<label for="">Expense Status</label>
		<select class="form-control" name="EmpReq:_idJsp119" size="1" style="width: 142;text-align:left;align:center" onchange="submit()">
		<option value="-1">Select</option>
		<option value="7">Auto Cancelled</option>
		<option value="2">Pending Approval</option>
		<option value="6">Completed</option>
		</select>
		</div>
		<div class="form-group">
		<label>Request No</label>
		<input id="" class="form-control" name="EmpReq:reqno" value="" maxlength="10" size="20" type="text">
		</div>
		<br/>
		<div class="form-group">
		 <span class="BodyFont" style="font-weight:bold;">
		<label>
		  <input class="BodyFont" name="radio" value="1" onclick="submit()" style="font-weight:bold" disabled="disabled" type="radio">
		   Claim Type
		  </label>
		</span>
		<div>
		<br/>
		<div class="form-group">
		<label for="">Expense Status</label>
		<select class="form-control" name="EmpReq:_idJsp131" size="1" style="width: 280;text-align:left;align:center" onchange="submit()" disabled="disabled">
		<option value="-1">ALL </option>
		</select>
		</div>

		<div class="form-group">
		<label for="">Expense Status</label>
		<select class="form-control" name="EmpReq:_idJsp136" size="1" style="width: 280;text-align:left;align:center" onchange="submit()" disabled="disabled">
		<option value="-1">ALL</option>
		</select>
		</div>
		<div class="form-group">
		 <span class="BodyFont" style="font-weight:bold;">
		<label>
		  <input class="BodyFont" name="radio" value="1" onclick="submit()" style="font-weight:bold" disabled="disabled" type="radio">
		   Claim Type
		  </label>
		</span>
		<div>

		</form>
		</div>
		</div>
		</div>
		</div>
		</div>

		<div class="col-lg-12" style="padding:8px; background-color:#E8F2FE; border-top:1px solid #006;">
		<div class="col-lg-2" style=" margin-left:20px;">
		<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Cancel" type="submit">
		</div>
		<div class="col-lg-2">
		<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Proceed" type="submit">
		</div>
		<div class="col-lg-2">
		<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Save as Draft" type="submit">
		</div>
		</div>
				</div><!-- /.col-* -->
			</div><!-- /.row -->
		</div><!-- /.container -->

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>