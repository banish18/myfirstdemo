<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Employee Portal</title>

	 <!-- CORE CSS-->    
	<?php echo Html::style('https://fonts.googleapis.com/css?family=Lato'); ?>			 
    <?php echo Html::style('admin-asset/css/bootstrap.min.css'); ?> 
	<?php echo Html::style('admin-asset/css/jquery.fancybox.css'); ?>

	<?php echo Html::style('admin-asset/css/icon-font.min.css'); ?>

	<?php echo Html::style('admin-asset/css/fullcalendar.css'); ?>

	<?php echo Html::style('admin-asset/css/datatables.css'); ?>

	<?php echo Html::style('admin-asset/css/datepicker.css'); ?>

	<?php echo Html::style('admin-asset/css/timepicker.css'); ?>

	<?php echo Html::style('admin-asset/css/style.css'); ?>

	<?php echo Html::style('admin-asset/css/jquery-ui.min.css'); ?> 
	<?php echo Html::script('admin-asset/ckeditor.js'); ?> 
	<?php echo Html::script('admin-asset/editor.js'); ?> 
	<?php echo Html::style('admin-asset/jquery.fancybox.css'); ?> 
	<?php echo Html::style('css/chosen.min.css'); ?> 



</head>

<body class="default" onload="">
    <div id="app">
      
  
	<?php echo $__env->make("templates/admin-nav", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- End Page Loading -->

        <?php echo $__env->yieldContent('content'); ?>
    </div>
	
 

  
   <script>
	$(".tooltip-trigger").tooltip();
	 </script>
		 <script>
		 /*   for mobile navigation */
		 $('.navbar-toggle').click(function() {
			 return $('body, html').toggleClass("nav-open");
		   });

	


		 /*
		  * =============================================================================
		  *   Bootstrap Popover
		  * =============================================================================
		  */

		 $(".popover-trigger").popover();
		 /*
		  * =============================================================================
		  *   Datepicker
		  * =============================================================================
		  */
 </script>
		
		
	
	<!-- ----------------------END------------------------------------- -->
    

</body>
</html>
	

