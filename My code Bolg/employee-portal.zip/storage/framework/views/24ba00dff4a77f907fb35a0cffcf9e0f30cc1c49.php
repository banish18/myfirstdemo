<?php $__env->startSection('content'); ?>

 <div class="container-fluid main-content">
        <div class="page-title">
          <h1>
         Employees Templates
          </h1>
                 </div>

        <div class="row">
  <div class="col-lg-2">
      <ul class="list-group">
      <!--li class="list-group-item  active">
              <a  href="https://shiftsystems.net/demo/index.php?user=view_template">
                <p>
                <img src="../images/dots-beginning-text-lines-interface-button-symbol.svg" width="15">

                &nbsp;All Payslip Templates
                </p>
              </a></li-->
			  <li class="list-group-item">
              <a  href="<?php echo e(route('payroll')); ?>">
                <p>
                <img src="../images/dots-beginning-text-lines-interface-button-symbol.svg" width="15">
                &nbsp;All Generated Payslips
                </p>
              </a></li>                              <li class="list-group-item">
              <a  href="<?php echo e(route('payroll',array('action' => 'add'))); ?>">
                <p>
               <img src="../images/plus-sign-in-circle.svg" width="15">

                &nbsp;Generate A New Payslip
                </p>
              </a></li>
            </ul>
  </div>
        <div class="col-lg-10">
		<?php if(Session::has('success')): ?>
			<section class="seccess">
					
						<div class="alert alert-success"><em> <?php echo session::get('success'); ?></em></div>
					
				</section>
<?php endif; ?>

             <div class="row">
            <div class="col-lg-12">

            <div class="widget-container fluid-height clearfix">
            <div class="widget-content padded clearfix">
<div class="table-responsive">
                  <table  class="table table-striped" id="dataTable3">
                    <thead>
                    <tr role="row">
                     <th>S.NO</th>
                     <th>Employee</th>
                     <th>Month</th>
					 <th>Year</th>
					 <th> Basic Salary($) </th>
                     <th> Net Salary($) </th>
					 <th> Action </th>
                     </tr>
                    </thead>
                                        <tbody>
						<?php if($data["payslips"]): ?>
							<?php $i = 0; ?>
							<?php $__currentLoopData = $data["payslips"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payslip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $i++; ?>
								<tr>
								<td><?php echo e($i); ?></td>
								<td><?php echo e($data["controller"]::getUser($payslip->uid)); ?></td>
								<td><?php echo e(date('M',strtotime($payslip->dop))); ?></td>
								<td><?php echo e(date('Y',strtotime($payslip->dop))); ?> </td>
								<td><?php echo e($data["controller"]::getUsersalary($payslip->uid)); ?> </td>
								<td><?php echo e($data["controller"]::getUsersalary($payslip->uid)); ?> </td>
								<td class="action" >
									 <div class="btn-group">
											  <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i>Options<span class="caret"></span>
											  </button>
											  <ul class="dropdown-menu">

												<li>    <a target="_blank" class="table-actions" href="<?php echo e(route('payroll',array('action' => 'view','id' => $payslip->id ))); ?>">View</a>
												 </li> 

												 <li>    
													<a class="table-actions" href="fpdf/index.php?id=<?php echo e($payslip->id); ?>">Download</a>
												 </li>  
												 
												  <li>    <a class="table-actions" href="<?php echo e(route('payroll',array('action' => 'salary_template','id' => $payslip->id ))); ?>">Delete </a></li>
												
																  
																								  </ul>
						</div>
												  </td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>		
                                    
                    </tbody>
                  </table></div>



              </div>
            </div></div>
                  </div>

   </div></div></div>

   <!-- ------------modal for fancybox -->
 <div class="row">
              <div class="col-lg-12">
                <div id="fancybox-example" style="display: none;" class="hide_fancybox">
                  <h2>
                    Template
                  </h2>
                  <p>
                  <form method="POST" action="https://shiftsystems.net/demo/index.php?user=view_template">
                    Are You Sure ! You want to delete this payslip template.
			<input type="hidden" name="employeeid" class="confirmdelete">
			<br>
			<button type="submit" class="btn btn-success btn-xs" aria-hidden="true" name="delete_ok">
			Yes</button>
			<button type="button" class="btn btn-danger btn-xs fancy-close" onclick="$.fancybox.close()">
			No</button>
                </form>
                </p>
                </div>
              </div>
            </div>
<?php echo $__env->make("templates/admin-footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- --------------------------end---------- -->

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/t/bs/jszip-2.5.0,pdfmake-0.1.18,dt-1.10.11,af-2.1.1,b-1.1.2,b-colvis-1.1.2,b-flash-1.1.2,b-html5-1.1.2,cr-1.3.1,fc-3.2.1,fh-3.1.1,r-2.0.2,rr-1.1.1/datatables.min.css"/>
 <script type="text/javascript" src="https://cdn.datatables.net/t/bs/jszip-2.5.0,pdfmake-0.1.18,dt-1.10.11,af-2.1.1,b-1.1.2,b-colvis-1.1.2,b-flash-1.1.2,b-html5-1.1.2,cr-1.3.1,fc-3.2.1,fh-3.1.1,r-2.0.2,rr-1.1.1/datatables.min.js"></script>
<style>
.dataTables_filter{
	margin-top: -47px;
}
.btn-group{
float:left;
}
</style>

     <script>
$(document).ready(function() {
    $('#dataTable3').DataTable( {
        dom: 'Blfrtip',

        buttons: [
                  {
                      extend: 'copyHtml5',
                      exportOptions: {
                    	  columns: [ 0,1,2, 3, 4]
                      }
                  },
                  {
                      extend: 'excelHtml5',
                      exportOptions: {
                    	  columns: [ 0,1,2, 3, 4]
                      }
                  },
                  {
                      extend: 'csvHtml5',
                      exportOptions: {
                    	  columns: [ 0,1,2, 3, 4]
                      }
                  },
                  {
                      extend: 'pdfHtml5',
                      exportOptions: {
                          columns: [ 0,1,2, 3, 4]
                      }
                  },
                  'colvis'
              ]
          } );
      } );
</script>  <div class="row" style="text-align:center;"><span>V3.0</span></div>
  </body></html>
  <script>
$(document).ready(function(){
	$(".pdf").click(function(){
		$("#table1").hide();
		setTimeout(function(){$("#table1").show()},1000);
		});
});
</script>
 

<script>
$(".tooltip-trigger").tooltip();
 </script>
     <script>
     /*   for mobile navigation */
     $('.navbar-toggle').click(function() {
         return $('body, html').toggleClass("nav-open");
       });

     /*
      * =============================================================================
      *   DataTables
      * =============================================================================
      */
     $("#dataTable1").dataTable({
       "sPaginationType": "full_numbers",
       aoColumnDefs: [
         {
           bSortable: false,
           aTargets: [0, -1]
         }
       ]
     });
     $('.table').each(function() {
       return $(".table #checkAll").click(function() {
         if ($(".table #checkAll").is(":checked")) {
           return $(".table input[type=checkbox]").each(function() {
             return $(this).prop("checked", true);
           });
         } else {
           return $(".table input[type=checkbox]").each(function() {
             return $(this).prop("checked", false);
           });
         }
       });
     });


     /*
      * =============================================================================
      *   Bootstrap Popover
      * =============================================================================
      */

     $(".popover-trigger").popover();
     /*
      * =============================================================================
      *   Datepicker
      * =============================================================================
      */

    var date = new Date();
    $("#from").datepicker();

    $("#to").datepicker();
    $("#dob").datepicker();
    $("#ps").datepicker();
    $("#pe").datepicker();
    $("#term").datepicker();
    $("#periodfrom").datepicker();
    $("#periodto").datepicker();


     if($("#watermark_yes").is(":checked")){
     	  $("#watermark").show();
       }
     else{
     $("#watermark").hide();
     }
     $("#watermark_yes").click(function(){
 	    $("#watermark").show();
 	});
     $("#watermark_no").click(function(){
   	    $("#watermark").hide();
   	});
     </script>

  <script>
  $(document).ready(function (){
	  $(".fancybox").fancybox({
	      maxWidth: 700,
	      height: 'auto',
	      fitToView: false,
	      autoSize: true,
	      padding: 15,
	      nextEffect: 'fade',
	      prevEffect: 'fade',
	      helpers: {
	        title: {
	          type: "outside"
	        }
	      }
	    });
     var a = $("#db_country").val();
     $("#country").val(a);
	  });
  </script>
 <script>
  $(document).ready(function (){
     var a = $("#db_timezone").val();
     $("#timezone").val(a);
	  });
  $('#timepicker1').timepicker();
  $('#timepicker2').timepicker();
  $('#timepicker3').timepicker();
  $('#timepicker4').timepicker();
  $('#timepicker5').timepicker();
  $('#timepicker6').timepicker();
  $('#timepicker7').timepicker();
  $('#timepicker8').timepicker();
  $('#timepicker9').timepicker();
  $('#timepicker10').timepicker();
  $('#timepicker11').timepicker();
  $('#timepicker12').timepicker();
  $('#timepicker13').timepicker();
  $('#timepicker14').timepicker();

  </script>

   <script>
  $(document).ready(function (){
     var a = $("#date_format").val();
     $("#dateformat").val(a);
	  });
  </script>
  
   
    <!-- ************************for change of salary from edit employee***************************** -->
   <script>


	  var a2 = Number($("#a2").val());
      var a3 = Number($("#a3").val());
      var a4 = Number($("#a4").val());
      var a5 = Number($("#a5").val());
      var ta_sum=a2+a3+a4+a5;
      $(".ta_total").val(ta_sum);




        var d2 = Number($("#d2").val());
       var d3 = Number($("#d3").val());

       var td_sum=d2+d3;
      $(".td_total").val(td_sum);



        var ad2 = Number($("#ad2").val());
       var ad3 = Number($("#ad3").val());
         var ad4 = Number($("#ad4").val());

       var add_sum=ad2+ad3+ad4;
      $(".add_total").val(add_sum);



			var basic = Number($("#basic").val());
			var ta = Number($(".ta_total").val());
			var td = Number($(".td_total").val());
			var add =  Number($(".add_total").val());
			var overtime=Number($(".overtime").val());

			var employee_cpf=Number($("#employee_cpf").val());
			var net_pay_plus= (basic+ta+add+overtime);
			var net_pay_minus =  (td+employee_cpf);
			var net_pay = (net_pay_plus-net_pay_minus);

			$("#net").val(net_pay);



</script>
  <!-- **************************************************************************** -->

   <script>
   $("#enable_check").click(function(){
	   if($("#enable_check").is(":checked")){
           $("#time1").hide();
           $("#time2").hide();
		   }
		   else {
			   $("#time1").show();
			   $("#time2").show();
			   }
	   });
   </script>
   <script>
   $("#emp_view_check").click(function(){

   if($("#emp_view_check").is(":checked")){

	  	  $("#emp_edit_check").show();
		  	$("#emp_del_check").show();
			$("#emp_add_check").show();
	    }
	  else{
	  $("#emp_edit_check").hide();
	  $("#emp_del_check").hide();
		$("#emp_add_check").hide();
		$(".employee_uncheck").removeAttr("checked","checked");
	  }
	  });

   $("#dep_view_check").click(function(){

	   if($("#dep_view_check").is(":checked")){

		  	  $("#dep_edit_check").show();
			  	$("#dep_del_check").show();
			  	 $("#dep_add_check").show();
		    }
		  else{
		  $("#dep_edit_check").hide();
		  $("#dep_del_check").hide();
		  $("#dep_add_check").hide();
		  $(".employee_uncheck").removeAttr("checked","checked");
		  }
		  });
   $("#holiday_view_check").click(function(){

	   if($("#holiday_view_check").is(":checked")){

		  	  $("#holiday_edit_check").show();
			  	$("#holiday_del_check").show();
				$("#holiday_add_check").show();
		    }
		  else{
		  $("#holiday_edit_check").hide();
		  $("#holiday_del_check").hide();
			$("#holiday_add_check").hide();
			$(".employee_uncheck").removeAttr("checked","checked");
		  }
		  });
   $("#task_view_check").click(function(){

	   if($("#task_view_check").is(":checked")){
		  	  $("#task_edit_check").show();
			  	$("#task_del_check").show();
				$("#task_add_check").show();
		    }
		  else{
		  $("#task_edit_check").hide();
		  $("#task_del_check").hide();
			$("#task_add_check").hide();
			$(".employee_uncheck").removeAttr("checked","checked");
		  }
		  });
   $("#payslip_view_check").click(function(){

	   if($("#payslip_view_check").is(":checked")){
			  	$("#payslip_del_check").show();
			  	$("#payslip_add_check").show();
		    }
		  else{

		  $("#payslip_del_check").hide();
		  $("#payslip_add_check").hide();
		  $(".employee_uncheck").removeAttr("checked","checked");
		  }
		  });
   $("#template_view_check").click(function(){

	   if($("#template_view_check").is(":checked")){

		   $("#template_edit_check").show();
			  	$("#template_del_check").show();
			  	$("#template_add_check").show();
		    }
		  else{
		  $("#template_edit_check").hide();
		  $("#template_del_check").hide();
		  $("#template_add_check").hide();
		  $(".employee_uncheck").removeAttr("checked","checked");
		  }
		  });
	  $("#awards_view_check").click(function(){
       if($("#awards_view_check").is(":checked")){
          $("#awards_add_check").show();
           }else{
            $("#awards_add_check").hide();
            $(".employee_uncheck").removeAttr("checked","checked");
               }
		  });


	  $("#noticeboard_view_check").click(function(){

		   if($("#noticeboard_view_check").is(":checked")){

			  	  $("#noticeboard_edit_check").show();
				  	$("#noticeboard_del_check").show();
					$("#noticeboard_add_check").show();
			    }
			  else{
			  $("#noticeboard_edit_check").hide();
			  $("#noticeboard_del_check").hide();
				$("#noticeboard_add_check").hide();
				$(".employee_uncheck").removeAttr("checked","checked");
			  }
			  });

   </script>

  <script>


  if($("#fixed_based").is(":checked")){

	  	  $("#annual_fixed_leaves").show();
	    }
	  else{
		  $("#annual_fixed_leaves").hide();
	  }
  $("#fixed_based").click(function(){
	  $("#service_based").removeAttr("checked");
	    $("#annual_fixed_leaves").show();
	    $("#service_based_leaves").hide();
	    $("#service_based_heading").hide();
	    $("#annual").show();
	});
  $("#service_based").click(function(){
	  $("#fixed_based").removeAttr("checked");
	    $("#service_based_leaves").show();
	    $("#annual_fixed_leaves").show();
	    $("#service_based_heading").show();
	    $("#annual").hide();

	});
  if($("#service_based").is(":checked")){

  	  $("#service_based_leaves").show();
  	  $("#annual_fixed_leaves").show();
    	$("#service_based_heading").show();
    	$("#annual").hide();
    }
  else{
	  $("#service_based_leaves").hide();
  }

   </script>

    <script>
   $("#sun_check").click(function(){
	   if($("#sun_check").is(":checked")){
		   $("#timepicker13").attr("disabled",true);
		   $("#timepicker14").attr("disabled",true);
         }
		   else {
			   $("#timepicker13").attr("disabled",false);
			   $("#timepicker14").attr("disabled",false);
			   }
	   });
   $("#mon_check").click(function(){
	   if($("#mon_check").is(":checked")){
		   $("#timepicker1").attr("disabled",true);
		   $("#timepicker2").attr("disabled",true);
         }
		   else {
			   $("#timepicker1").attr("disabled",false);
			   $("#timepicker2").attr("disabled",false);
			   }
	   });
   $("#tues_check").click(function(){
	   if($("#tues_check").is(":checked")){
		   $("#timepicker3").attr("disabled",true);
		   $("#timepicker4").attr("disabled",true);
         }
		   else {
			   $("#timepicker3").attr("disabled",false);
			   $("#timepicker4").attr("disabled",false);
			   }
	   });
   $("#wed_check").click(function(){
	   if($("#wed_check").is(":checked")){
		   $("#timepicker5").attr("disabled",true);
		   $("#timepicker6").attr("disabled",true);
         }
		   else {
			   $("#timepicker5").attr("disabled",false);
			   $("#timepicker6").attr("disabled",false);
			   }
	   });
   $("#thurs_check").click(function(){
	   if($("#thurs_check").is(":checked")){
		   $("#timepicker7").attr("disabled",true);
		   $("#timepicker8").attr("disabled",true);
         }
		   else {
			   $("#timepicker7").attr("disabled",false);
			   $("#timepicker8").attr("disabled",false);
			   }
	   });
   $("#fri_check").click(function(){
	   if($("#fri_check").is(":checked")){
		   $("#timepicker9").attr("disabled",true);
		   $("#timepicker10").attr("disabled",true);
         }
		   else {
			   $("#timepicker9").attr("disabled",false);
			   $("#timepicker10").attr("disabled",false);
			   }
	   });
   $("#sat_check").click(function(){
	   if($("#sat_check").is(":checked")){
		   $("#timepicker11").attr("disabled",true);
		   $("#timepicker12").attr("disabled",true);
         }
		   else {
			   $("#timepicker11").attr("disabled",false);
			   $("#timepicker12").attr("disabled",false);
			   }
	   });

//for age
   $(".birth").change(function(){
	   var dob = $("#dob").val();
	  dob = new Date(dob);
    var today = new Date();
   var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
   $('#age').val(age);
   });
   //for address
   $("#full_add").keyup(function(){
	   var block = $("#block").val();
	   var street1=$("#street_1").val();
	   var street2=$("#street_2").val();
	   var street3=$("#street_3").val();
	   var houseno=$("#houseno").val();
	   var country=$("#coun").val();
	   var postal=$("#postal").val();

	   var res=houseno.concat(","," ",block," ",",",street1,",",street2,street3," ",",",country," ",postal);

	   $("#fullad").val(res);


	   });

 

   $(document).ready(function(){
   $("#empid").change(function(){

         var eid=$("#empid").val();
         var sal=$(".emp"+eid).attr('data');

         var arr = sal.split('/');

         $("#sal").val(arr[0]);
         $("#netsal").val(arr[1]);


	   });
   });


   jQuery('#con_no').keyup(function () {
	    this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');
	     this.value = this.value.replace(/[^0-9]/g, '');
	});


   jQuery('#mob_no').keyup(function () {
	    this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');
	     this.value = this.value.replace(/[^0-9]/g, '');
	});

   $('.nextofkin_conno').keyup(function () {
        this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');
        this.value = this.value.replace(/[^0-9]/g, '');
   });

   </script>

   <script>

   $('.save').click(function(){

    var awd_data=$("#awd_name").val();
    var last_award_id = $(".last_award_id").val();
  $.ajax({
		  type: "POST",
		  url: "https://shiftsystems.net/demo/index.php?user=ajax",
		  data: 'awd_data=' +awd_data,

		  success: function(data)
		  {

        	  $(".fade").fadeOut();
			  $("#myModal").hide();
			  var new_last_id = parseInt(last_award_id)+parseInt(1);
			  $('body').removeClass('modal-open');
			  var newOption = "<option value='"+new_last_id+"'>"+awd_data+"</option>";
			  $("#sel_awd").append(newOption);
			  $(".last_award_id").val(new_last_id);
		  }


		});
   });
   $('.Click_New_Award').click(function(){
	   $(".fade").fadeIn();
	   $("#myModal").show();
   });
   </script>


   <script>
   $('.check_particular').click(function(){
	   var data_ID=$(this).attr("data-id");
if($(this).prop("checked")==true)
{
	 var Prev_Ids = $(".prev_select_item_id").val();
	 $(".prev_select_item_id").val(data_ID+'__'+Prev_Ids);
 $('.show_delete_button').show();
}
if($(this).prop("checked")==false){
	 var Prev_Ids = $(".prev_select_item_id").val();
	 var Remove_Id = data_ID+'__';
	 var After_Unselect = Prev_Ids.replace(Remove_Id,"");
	 $(".prev_select_item_id").val(After_Unselect);
		if(After_Unselect==""){
	$('.show_delete_button').hide();
		}
}

});
   </script>

   <script>
$(".clickonedit").click(function(){
$(".show_field").show();
$(".hide_field").hide();
});

$('.e_check').click(function(){
if($(this).is(":checked")){
$('.hide_e_check').hide();
}else{
$('.hide_e_check').show();
}
});
   </script>

<script>
$('.delid').click(function(){
	var delid=$(this).attr('data-id');
    $('.confirmdelete').val(delid)

});

$('.fancy-close').click(function(){
$('.hide_fancybox').close();
});
</script>
<script>
function goback(){
	window.history.back();
}
    </script>
  <!-- ----------------------------for attendance marked---------------- -->
<script>
    $(".Post_Mark_Attendance").click(function(){
var employee_id=$(".Post_id").attr('data-emp-id');
var employee_code=$(".Post_code").attr('data-emp-code');
var employee_deptid=$(".Post_deptid").attr('data-dept-id');
var empdate=$(".Post_date").attr('data-date');
var fulldetails ='&employee_id='+employee_id+'&employee_code='+employee_code+'&employee_deptid='+employee_deptid+'&empdate='+empdate;
$.ajax({
	  type: "POST",
	  url: "https://shiftsystems.net/demo/index.php?user=ajax",
	  data: 'fulldetails='+fulldetails,

	  success: function(data)
	  {

		  $(".datashown").text(data);
		  $(".datashown").removeClass('btn btn-xs btn-success');
		  $(".datashown").addClass('btn btn-xs btn-danger');
		  $(".datashown").attr('disabled','disabled');

	  }
	});

        })
</script>

<script>
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
</script>
<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>