<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
<div class="page-title">
<div class="row">
<div class="col-md-12">
<h1>Update Credential</h1></div></div>
</div>
<div class="row">
<div class="col-md-2">
<ul class="list-group">
<li class="list-group-item active" >
<a href="<?php echo e(route('users',array('action' => 'employee-credential'))); ?>">
<p>
<img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
&nbsp;Credentials
</p></a>
</li>
<li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'add-credential'))); ?>">
           <p>
           <img src="<?php echo e(asset('admin-asset/images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add
           </p></a>
           </li>        
</ul>
</div>

<div class="col-md-10">
<div class="widget-container fluid-height clearfix">
<div class="widget-content padded">
<form method="post" class="form-horizontal" action="<?php echo e(route('users',array('action' => 'postupdateCredential'))); ?>" enctype="multipart/form-data">

 <?php echo e(csrf_field()); ?>


<div class="row">
<div class="col-md-12">
<div class="col-md-9">
<div class="heading"><h2>Employee Credential Details</h2></div><br>
<div class="form-group">
            <label class="control-label col-md-3">Select Employee</label>
            <div class="col-md-7">
			<?php echo e(csrf_field()); ?>

               <select data-placeholder="Select Employee" style="width:350px;" class="chosen-select form-control" tabindex="7" name="user" required> 
				<option value="">Please Select User To Add Credential</option>
				 <?php if($data["users"]): ?>
					 <?php $__currentLoopData = $data["users"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php 
							if($data['credential']->uid == $user->id){
								$selected = "selected";
							}else{
								$selected = "";
							}
						?>
						<option <?php echo e($selected); ?> value="<?php echo e($user->id); ?>"><?php echo e($user->name.'('.$user->uuid.')'); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	 
			  </select>
            </div>
			<span style="color:#d43f3a">
mandatory
</span>
          </div>
<div class="form-group">
<label class="control-label col-md-3">Credential Type</label>
<div class="col-md-7">
<input class="form-control" name="credential_type" type="text" value="<?php echo e($data['credential']->credential_type); ?>" required>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="form-group">
<label class="control-label col-md-3">Username/Email</label>
<div class="col-md-7">
<input class="form-control" name="username" type="text" value="<?php echo e($data['credential']->username); ?>" required>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="form-group">
<label class="control-label col-md-3">Password</label>
<div class="col-md-7">
<input class="form-control" name="password" type="text" value="<?php echo e($data['credential']->password); ?>" required>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>

<div class="form-group">
<div class="col-md-12">
<div class="col-md-6">
<input type="hidden" name="id" value="<?php echo e($data['credential']->id); ?>" />
<button class="btn btn-lg btn-block btn-success" type="submit" name="submit_employee"> Submit</button>
</div>
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
</div>
</div></div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>

<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>
<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>