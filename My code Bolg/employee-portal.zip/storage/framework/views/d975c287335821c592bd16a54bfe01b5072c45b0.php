<?php $__env->startSection('content'); ?>

<div class="main-wrapper">
	<div class="main">
		<div class="document-title">
			<div class="container">
				<h1>Notification</h1>
			</div><!-- /.container -->
		</div><!-- /.document-title -->
		<div class="document-breadcrumb">
			<div class="container">
				<ul class="breadcrumb">
					<li><a href="<?php echo e(route('home')); ?>">Home</a></li>
					<li>Notification</li>
				</ul>
			</div><!-- /.container -->
		</div><!-- /.document-title -->
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<ul style="list-style:none;">
				<?php if($data["notifications"]): ?>
					<?php $__currentLoopData = $data["notifications"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><h3 class="page-header"><?php echo e($notification->subject); ?></h3>
						<p>
							<?php echo e($notification->message); ?>

						</p></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<li>You don't have notifications yet !</li>
				<?php endif; ?>	
				</ul>
			</div><!-- /.col-* -->
		</div><!-- /.row -->
	</div><!-- /.container -->
	</div><!-- /.main -->
</div><!-- /.main-wrapper -->

<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>