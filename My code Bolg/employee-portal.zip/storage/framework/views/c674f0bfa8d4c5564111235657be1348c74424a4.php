<?php $__env->startSection('content'); ?>
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Address Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Address Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			<?php echo $__env->make("employee_self_services/profile/sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
             <div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
		  <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;">Associate Details</div>
            <table class="table-bordered">     
			<tbody>
			<tr>
			<th>Employee Status </th>
			<td>Active Assignment</td>
			<th>Home Country</th>
			<td>India</td>
			<th>Depute Country </th>
			<td>India</td>
			</tr>
			<tr>
			<th>Employee Type</th>
			<td>Employee</td>
			<th>Home Branch</th>
			<td>TCS - New Delhi</td>
			<th>Depute Branch</th>
			<td>TCS - New Delhi</td>
			</tr>
			</tbody>
			</table>
			
		
		

          </div>
          <!-- /.col-* --> 
		  
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
	  
	               

            <div class="container">
	         <div class="row">
		      <div class="col-sm-12">
			   <ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active">
					<a href="#personal" aria-controls="personal" role="tab" data-toggle="tab">
						<strong>Report/Lost Damaged Card</strong>
						<span></span>
					</a>
				</li>
			  </ul>

			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="personal">
					<div class="row">
						<div class="col-lg-12">
							<div class="col-lg-6" style="margin-bottom: 10px; margin-top: 12px;">
							<div style="cursor: pointer;">
							<div class="pull-left">
							<img src="../../assets/img/addicon_hover.png" width="30px">
							</div>
							<div class="pull-left" style="margin-left: 5px;">
							<div style="margin-top: 10px;">
							<span style="margin-left: 5px; font-weight: bold;">Add a Forex Card</span>
							</div>
							</div>
							</div>
							</div>
							<div class="col-lg-6" style="margin-bottom: 10px; margin-top: 12px;">
							<select class="col-lg-4 safari-select pull-right">
							<option value="0" selected="selected">Active</option>
							<option value="1">Inactive</option>
							</select>
							<span class="pull-right" style="margin-bottom: 0px; margin-top: 5px;">Filter by</span>
							</div>
							<table class="table-bordered" style="margin-bottom: 15px;">
							<thead class="myGradientClass">
							<tr style="height: 28px;">
							<th style="text-align: left;padding-left: 10px;width: 114px">
							<a style="color: #454647;" href="">
							<span style="font-weight: bold; text-decoration: underline;">Issuing Company</span>
							<img class="sortIcon">
							<img class="sortIcon" src="appResources/img/sortingDown.png" style="display: none;">
							</a>
							</th>
							<th style="text-align: left;padding-left: 10px;width: 114px">
							<a style="color: #454647;" href="">
							<span style="font-weight: bold; text-decoration: underline;" data-key="vendorNameText">Vendor Name</span>
							
							</a>
							</th>
							<th style="text-align: left;padding-left: 10px;width: 114px">
							<a style="color: #454647;" href="">
							<span style="font-weight: bold; text-decoration: underline;">Issuing Authority</span>
							
							</a>
							</th>
							<th style="text-align: left;padding-left: 10px;width: 114px">
							<a style="color: #454647;" href="">
							<span style="font-weight: bold; text-decoration: underline;">Forex Card No.</span>
							
							</a>
							</th>
							<th style="text-align: left;padding-left: 10px;width: 114px">
							<a style="color: #454647;" href="">
							<span style="font-weight: bold; text-decoration: underline;">Valid From Date</span>
							
							</a>
							</th>
							<th style="text-align: left;padding-left: 10px;width: 114px">
							<a style="color: #454647;" href="">
							<span style="font-weight: bold; text-decoration: underline;">Valid Through Date</span>
							</a>
							</th>
							</tr>
							</thead>
							<tbody class="listBorder">
							<tr  style="height: 65px;">
							<td colspan="9" style="text-align: center;">
							<span>
							Currently You do not have forex card details.Please click on
							<b>Add Forex Cards Details</b>
							</span>
							</td>
							<td colspan="9" style="text-align: center; display: none;">
							<span class="ng-binding">Currently You do not have inactive forex card details</span>
							</td>
							</tr>
							</tbody>
							</table>
						</div><!-- /.col-* -->
					</div><!-- /.row -->
				</div><!-- /.tab-pane -->
			</div><!-- /.tab-content -->
		</div><!-- /.col-* -->
	</div><!-- /.row -->
</div><!-- /.container -->
		 

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>