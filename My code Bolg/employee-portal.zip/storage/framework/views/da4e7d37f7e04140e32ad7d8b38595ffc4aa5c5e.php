<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
  <div class="page-title">
    <div class="row">
      <div class="col-md-12">
        <h1>Edit Previous Employee</h1>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-2">
      <ul class="list-group">
			<li class="list-group-item active" >
			<a href="<?php echo e(route('users',array('action' => 'fullandfinal'))); ?>">
           <p>
            <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;List Employees
           </p></a>  	
           </li>

           <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'add-previous'))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add Employee
           </p>
           </a>
           </li>
		   
		    <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'final-detail'))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Full and Final Detail
           </p>
           </a> 
           </li>
           
            </ul>

    </div>
    <div class="col-md-10">
      <div class="widget-container fluid-height clearfix">
        <div class="widget-content padded">
          <form method="post" class="form-horizontal" action="<?php echo e(route('users',array('action' => 'postpreUpdate'))); ?>" enctype="multipart/form-data">
            
 <?php echo e(csrf_field()); ?>

<input type="hidden" name="profile" id="profilesize" >
<input type="hidden" name="addressproof_size" id="add_proof_size" >
<input type="hidden" name="idproof_size" id="id_proof_size" >
<input type="hidden" name="pempid" value="<?php echo e($data['user']->id); ?>" >
<input type="hidden" name="emp_stat" value="2" />
<div class="row">
<div class="col-md-12">
<div class="col-md-6">
<div class="heading"><h2>Employee Details</h2></div><br>
<div class="form-group">
<label class="control-label col-md-3">First Name</label>
<div class="col-md-6">
<input class="form-control" name="e_name" type="text" value="<?php echo e($data['user']->f_name); ?>" required>
 <?php if($errors->has('e_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('e_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>

<div class="form-group">
<label class="control-label col-md-3">Last Name</label>
<div class="col-md-6">
<input class="form-control" name="e_surname" type="text" value="<?php echo e($data['user']->l_name); ?>" required>
 <?php if($errors->has('e_surname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('e_surname')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span>
</div>
<div class="form-group">
<label class="control-label col-md-3">Father Name</label>
<div class="col-md-6">
<input class="form-control" name="father_name" type="text" value="<?php echo e($data['user']->father_name); ?>" required>
 <?php if($errors->has('e_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('father_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="form-group">
<label class="control-label col-md-3">Date Of Birth</label>
<div class="col-md-6">
<div class="input-group date datepicker">
<input class="form-control birth" id="dob" type="text" name="e_dob" value="<?php echo e($data['user']->dob); ?>" required><span class="input-group-addon">

<img src="<?php echo e(asset('admin-asset/images/date.svg')); ?>" width="15">
</span>
</div>
<?php if($errors->has('e_dob')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('e_dob')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span> 

</div>

<div id="full_add">


<div class="form-group">
<label class="control-label col-md-3">House Number</label>
<div class="col-md-6">
<input class="form-control allownumericwithoutdecimal" id="houseno" name="house_no" type="text" value="<?php echo e($data['user']->houseno); ?>">

</div>
</div>

<div class="form-group">
<label class="control-label col-md-3">Street Number 1</label>
<div class="col-md-6">
<input class="form-control" id="street_1" name="address_street_no1" type="text" value="<?php echo e($data['user']->address_street_no1); ?>">
</div>
</div>




<div class="form-group">
<label class="control-label col-md-3">Countries</label>
<div class="col-md-6">
<select class="form-control co" id="coun" name="country" >
                          <option value="0" label="Select a country ... " selected="selected">Select a country ... </option>
						  <?php $__currentLoopData = $data["country"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							 <?php if($data["user"]->country  == $country): ?>
								<?php $selected = "selected=selected"?>
							<?php else: ?>
								<?php $selected = ""?>
							 <?php endif; ?>
							 <option <?php echo e($selected); ?> value="<?php echo e($country); ?>"><?php echo e($country); ?></option>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Postal Code</label>
<div class="col-md-6">
<input class="form-control" id="postal" name="postal_code" type="text" maxlength="6" value="<?php echo e($data['user']->postal_code); ?>">
</div>
</div>

<div class="form-group">
<label class="control-label col-md-3">Full Address</label>
<div class="col-md-6">
<textarea class="form-control" id="fullad" name="e_address" readonly="true"><?php echo e($data['user']->address); ?></textarea>
</div>
</div></div>

<div class="form-group">
<label class="control-label col-md-3">Contact No.</label>
<div class="col-md-6">
<input class="form-control" id="con_no" name="e_contact1" maxlength="12" type="text" value="<?php echo e($data['user']->e_contact1); ?>">
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Mobile No.</label>
<div class="col-md-6">
<input class="form-control" id="mob_no" name="e_contact2" type="text" maxlength="12" value="<?php echo e($data['user']->phone_number); ?>">
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Photograph
</label>
<div class="col-md-5">
<div class="fileupload fileupload-new" data-provides="fileupload">
<input type="hidden" value="" name="">
 <div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;"><img src="<?php echo e(asset('images/users/'.$data['user']->image)); ?>"></div>
<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
<div>
<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

<span class="fileupload-exists">Change</span>
<input type="file" name="emp_photo" id="profile_pic"></span>
<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
<input name="preimage" type="hidden" value="<?php echo e($data['user']->image); ?>">
<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
</div>
</div>
</div>
</div>



</div>
<div class="col-md-6">
<div class="heading"><h2></h2></div><br>
<div class="form-group">
<label class="control-label col-md-3">Company</label>
<div class="col-md-6">
<select class="form-control" name="company">
                        <option value="0">Company</option>
                        <?php if($data["companies"]): ?>
							<?php $__currentLoopData = $data["companies"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php 
								if($company->id == $data['user']->company){
									$sel = "selected=selected";
								}else{
									$sel = "";
								}
							?>
								<option <?php echo e($sel); ?> value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>	
                      </select>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Department</label>
<div class="col-md-6">
<?php
	if($data['user']->e_department  == "1"){
		$dchecked = "selected=selected";	
		$hchecked = "";
		$schecked = "";	
	}else if($data['user']->e_department  == "2"){
		$dchecked = "";	
		$hchecked = "selected=selected";
		$schecked = "";	
	}else if($data['user']->e_department  == "3"){
		$dchecked = "";	
		$hchecked = "";
		$schecked = "selected=selected";	
	}else{
		$dchecked = "";	
		$hchecked = "";
		$schecked = "";	
	}
?>
<select class="form-control" name="e_department">
                        <option value="0">Department</option>
                        <option <?php echo e($dchecked); ?> value="1">Developing </option>
                        <option <?php echo e($hchecked); ?> value="2" >HR </option>
                        <option <?php echo e($schecked); ?> value="7" >Sales </option>
                      </select>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Basic Salary</label>
<div class="col-md-6">
<div class="input-group">
<span class="input-group-addon">$</span>
<input class="form-control" name="e_salary" type="text" value="<?php echo e($data['user']->salary); ?>" required>
<?php if($errors->has('e_salary')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('e_salary')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>

<div class="form-group">
<label class="control-label col-md-3">Sex</label>
<?php 	if($data['user']->sex == "male"){
	$mchecked = "checked=checked";	
	$fchecked = "";	
	}else if($data['user']->sex == "female"){
		$mchecked = "";	
		$fchecked = "checked=checked";	}?>
<div class="col-md-6">
<label class="radio-inline">
<input name="sex" type="radio" value="male" <?php echo e($mchecked); ?>>
<span>Male</span>
</label>
<label class="radio-inline">
<input name="sex" type="radio" value="female" <?php echo e($fchecked); ?>>
<span>Female</span></label>
<?php if($errors->has('sex')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('sex')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>

<span style="color:#d43f3a">
mandatory
</span> </div>

<div class="form-group">
<label class="control-label col-md-3">Religion</label>
<div class="col-md-6">
<?php
	if($data['user']->religion == "hindu"){
		$hchecked = "checked=checked";	
		$mchecked = "";
		$schecked = "";	
		$ochecked = "";	
	}else if($data['user']->religion == "muslim"){
		$hchecked = "";	
		$mchecked = "checked=checked";
		$schecked = "";	
		$ochecked = "";
	}else if($data['user']->religion == "sikh"){
		$hchecked = "";	
		$mchecked = "";
		$schecked = "checked=checked";	
		$ochecked = "";
	}else{
		$hchecked = "";	
		$mchecked = "";
		$schecked = "";	
		$ochecked = "checked=checked";
	}
?>

<label class="radio-inline">
<input name="religion" type="radio" value="hindu" <?php echo e($hchecked); ?>>
<span>Hindu</span>
</label>
<label class="radio-inline">
<input name="religion" type="radio" value="muslim" <?php echo e($mchecked); ?>>
<span>Mulsim</span></label>
<label class="radio-inline">
<input name="religion" type="radio" value="sikh" <?php echo e($schecked); ?>>
<span>Sikh</span></label>
<label class="radio-inline">
<input name="religion" type="radio" value="others" <?php echo e($ochecked); ?>>
<span>Others</span></label>
<?php if($errors->has('religion')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('religion')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
 
</div>
<div class="form-group">
<label class="control-label col-md-3">Job Title</label>

<div class="col-md-6">
<input class="form-control" name="jobtitle" type="text" value="<?php echo e($data['user']->jobtitle); ?>" required>
<?php if($errors->has('jobtitle')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('jobtitle')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span>
</div>




<div class="form-group">
<label class="control-label col-md-3">Qualification</label>

<div class="col-md-6">
<input class="form-control" name="qualification" type="text" value="<?php echo e($data['user']->qualification); ?>" required>
<?php if($errors->has('qualification')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('qualification')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<small>Use commas to separate names</small>
<span style="color:#d43f3a">
mandatory
</span>
</div>
<div class="form-group">
<label class="control-label col-md-3">Email</label>
<div class="col-md-6">
<input class="form-control" name="e_email" type="text" value="<?php echo e($data['user']->email); ?>" required>
<?php if($errors->has('e_email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('e_email')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>

<div class="form-group">
<label class="control-label col-md-3">Age(from date of birth)</label>
<div class="col-md-6">
<input class="form-control" id="empage" name="age" type="text" value="<?php echo e($data['user']->age); ?>" readonly="true" required>
<?php if($errors->has('age')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('age')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span>
 </div>

<div class="form-group">
<label class="control-label col-md-3">Notice Period Served</label>
<div class="col-md-8">
<div class="col-md-3">
<input class="form-control" type="text" name="notice_period" value="<?php echo e($data['user']->notice_period); ?>">
</div><div class="col-md-8">
<select class="form-control" name="for_days">
 <?php 	if($data['user']->for_days == "for month"){		$selected = "selected=selected";	}elseif($data['user']->for_days == "for days"){		$selected = "selected=selected";	}else{		$selected = '';	}?>
<option value="0">---select by month/day--</option>
<option <?php echo e($selected); ?> value="for month" >month/s</option>
<option <?php echo e($selected); ?> value="for days" >day/s</option>
</select></div>
</div> </div>

<div class="form-group">
<label class="control-label col-md-3">Upload Documents</label>
<div class="col-md-6">
<div class="fileupload fileupload-new" data-provides="fileupload"><input type="hidden" value="" name="">
<span class="btn btn-default btn-file"><span class="fileupload-new">Select file</span><span class="fileupload-exists">Change</span><input type="file" name="emp_docs[]" multiple id="add_proof"></span><span class="fileupload-preview"></span><button class="close fileupload-exists" data-dismiss="fileupload" style="float:none" type="button">?</button>
</div> <small>Zip, txt, jpeg, png, pdf, doc (Max : 64M)</small>
<input type="hidden" name="preemp_docs" id="preemp_docs" value="<?php echo e($data['user']->emp_docs); ?>" />

<div class="selectedImages" id="selectedImages" style="margin-top:25px;"></div>
<div class="col-md-12 fileupload-new img-thumbnail">

<?php 
	if($data['user']->emp_docs != "" || $data['user']->emp_docs != " "){
		$images = explode(",",$data['user']->emp_docs);
		foreach($images as $img){
		
			$nimg = explode(".",$img);
			$nimg = $nimg[0];
	?>	
	<p class="col-md-3">
			<img style="width: 50px; height: 50px;border: 2px solid #000;padding: 8px;" src="http://portal.mindxpert.com/images/users/<?php echo e($img); ?>" />
			
			<img onclick="removeDoc(this,'<?php echo e($data['user']->id); ?>','<?php echo e($img); ?>')" style="cursor:pointer;width: 19px; height: 25px;margin-top: -111px;margin-left: 39px;" src="http://portal.mindxpert.com/images/imageedit_1_9009417451.png" />
	</p>		
<?php		
		}
	?>
	
		
		
<?php
	}
?>
</div>
</div>
</div>




</div>
</div></div>

<div class="form-group">
<div class="col-md-12">
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-success" type="submit" name="submit_employee"> Submit</button>
</div>
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
</div>
</div></div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
window.onload = function(){
        
    //Check File API support
    if(window.File && window.FileList && window.FileReader)
    {
        var filesInput = document.getElementById("add_proof");
        
        filesInput.addEventListener("change", function(event){
            
            var files = event.target.files; //FileList object
            var output = document.getElementById("selectedImages");
            
            for(var i = 0; i< files.length; i++)
            {
                var file = files[i];
                
                //Only pics
                if(!file.type.match('image'))
                  continue;
                
                var picReader = new FileReader();
                
                picReader.addEventListener("load",function(event){
                    
                    var picFile = event.target;
                    
                    var div = document.createElement("p");
					
					div.className = "col-md-3";
					
					var ht = '<img onclick="removeliveDoc(this)" style="cursor:pointer;width: 19px; height: 25px;margin-top: -111px;margin-left: 39px;" src="http://portal.mindxpert.com/images/imageedit_1_9009417451.png" />';
                    
                    div.innerHTML = "<img class='thumbnail' style='width: 50px; height: 50px;border: 2px solid #000;padding: 8px;' src='" + picFile.result + "'" +
                            "title='" + picFile.name + "'/>"+ht;
                    
                    output.insertBefore(div,null);            
                
                });
                
                 //Read the image
                picReader.readAsDataURL(file);
            }                               
           
        });
    }
    else
    {
        console.log("Your browser does not support File API");
    }
}
function removeliveDoc(elm){
	$(elm).parent().remove();
}
    
function removeDoc(elm,id,img){
	if(confirm("Do you want to delete this doc?") == true){
		var token = jQuery("input[name=_token]").val();
		$.ajax({
			url: 'http://portal.mindxpert.com/users/deletDocimg',
			type: 'POST',
			data: {_token: token,id:id,img},
			dataType: 'JSON',
			success: function (data) {
				$("#preemp_docs").val(data.data);
				$(elm).parent().remove();
				alert("Successfully Deleted!");
			}
		});
	}
}
	
//For profile pic size
$('#profile_pic').bind('change', function() {
$('#profilesize').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");
});
// For qualification files
$('#qual_1').bind('change', function() {

$('#qualification_1').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});
$('#qual_2').bind('change', function() {

$('#qualification_2').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});
$('#qual_3').bind('change', function() {

$('#qualification_3').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});
$('#qual_4').bind('change', function() {

$('#qualification_4').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});
$('#qual_5').bind('change', function() {

$('#qualification_5').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});

//for addressproof and idproof
$('#add_proof').bind('change', function() {

$('#add_proof_size').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});
$('#id_proof').bind('change', function() {

$('#id_proof_size').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});


$(".allownumericwithoutdecimal").on("keypress keyup blur",function (event) {
$(this).val($(this).val().replace(/[^\d-].+/, ""));
if ((event.which > 57)) {
event.preventDefault();
}
});
</script>
<div class="row" style="text-align:center;"><span>V3.0</span></div>
</body></html>
<script>
$(document).ready(function(){
$(".pdf").click(function(){
$("#table1").hide();
setTimeout(function(){$("#table1").show()},1000);
});
});
</script>

<script>
$(".tooltip-trigger").tooltip();
</script>
<script>
/* for mobile navigation */
$('.navbar-toggle').click(function() {
return $('body, html').toggleClass("nav-open");
});

/*
* =============================================================================
* DataTables
* =============================================================================
*/
$("#dataTable1").dataTable({
"sPaginationType": "full_numbers",
aoColumnDefs: [
{
bSortable: false,
aTargets: [0, -1]
}
]
});
$('.table').each(function() {
return $(".table #checkAll").click(function() {
if ($(".table #checkAll").is(":checked")) {
return $(".table input[type=checkbox]").each(function() {
return $(this).prop("checked", true);
});
} else {
return $(".table input[type=checkbox]").each(function() {
return $(this).prop("checked", false);
});
}
});
});


/*
* =============================================================================
* Bootstrap Popover
* =============================================================================
*/

$(".popover-trigger").popover();
/*
* =============================================================================
* Datepicker
* =============================================================================
*/

var date = new Date();
$("#from").datepicker();

$("#to").datepicker();
$("#dob").datepicker();
$("#ps").datepicker();
$("#pe").datepicker();
$("#term").datepicker();
$("#periodfrom").datepicker();
$("#periodto").datepicker();


if($("#watermark_yes").is(":checked")){
$("#watermark").show();
}
else{
$("#watermark").hide();
}
$("#watermark_yes").click(function(){
$("#watermark").show();
});
$("#watermark_no").click(function(){
$("#watermark").hide();
});
</script>

<script>
$(document).ready(function (){
$(".fancybox").fancybox({
maxWidth: 700,
height: 'auto',
fitToView: false,
autoSize: true,
padding: 15,
nextEffect: 'fade',
prevEffect: 'fade',
helpers: {
title: {
type: "outside"
}
}
});
var a = $("#db_country").val();
$("#country").val(a);
});
</script>
<script>
$(document).ready(function (){
var a = $("#db_timezone").val();
$("#timezone").val(a);
});
$('#timepicker1').timepicker();
$('#timepicker2').timepicker();
$('#timepicker3').timepicker();
$('#timepicker4').timepicker();
$('#timepicker5').timepicker();
$('#timepicker6').timepicker();
$('#timepicker7').timepicker();
$('#timepicker8').timepicker();
$('#timepicker9').timepicker();
$('#timepicker10').timepicker();
$('#timepicker11').timepicker();
$('#timepicker12').timepicker();
$('#timepicker13').timepicker();
$('#timepicker14').timepicker();

</script>

<script>
$(document).ready(function (){
var a = $("#date_format").val();
$("#dateformat").val(a);
});
</script>


<!-- ************************for change of salary from edit employee***************************** -->
<script>


var a2 = Number($("#a2").val());
var a3 = Number($("#a3").val());
var a4 = Number($("#a4").val());
var a5 = Number($("#a5").val());
var ta_sum=a2+a3+a4+a5;
$(".ta_total").val(ta_sum);




var d2 = Number($("#d2").val());
var d3 = Number($("#d3").val());

var td_sum=d2+d3;
$(".td_total").val(td_sum);



var ad2 = Number($("#ad2").val());
var ad3 = Number($("#ad3").val());
var ad4 = Number($("#ad4").val());

var add_sum=ad2+ad3+ad4;
$(".add_total").val(add_sum);



var basic = Number($("#basic").val());
var ta = Number($(".ta_total").val());
var td = Number($(".td_total").val());
var add = Number($(".add_total").val());
var overtime=Number($(".overtime").val());

var employee_cpf=Number($("#employee_cpf").val());
var net_pay_plus= (basic+ta+add+overtime);
var net_pay_minus = (td+employee_cpf);
var net_pay = (net_pay_plus-net_pay_minus);

$("#net").val(net_pay);



</script>
<!-- **************************************************************************** -->

<script>
$("#enable_check").click(function(){
if($("#enable_check").is(":checked")){
$("#time1").hide();
$("#time2").hide();
}
else {
$("#time1").show();
$("#time2").show();
}
});
</script>
<script>
$("#emp_view_check").click(function(){

if($("#emp_view_check").is(":checked")){

$("#emp_edit_check").show();
$("#emp_del_check").show();
$("#emp_add_check").show();
}
else{
$("#emp_edit_check").hide();
$("#emp_del_check").hide();
$("#emp_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});

$("#dep_view_check").click(function(){

if($("#dep_view_check").is(":checked")){

$("#dep_edit_check").show();
$("#dep_del_check").show();
$("#dep_add_check").show();
}
else{
$("#dep_edit_check").hide();
$("#dep_del_check").hide();
$("#dep_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});
$("#holiday_view_check").click(function(){

if($("#holiday_view_check").is(":checked")){

$("#holiday_edit_check").show();
$("#holiday_del_check").show();
$("#holiday_add_check").show();
}
else{
$("#holiday_edit_check").hide();
$("#holiday_del_check").hide();
$("#holiday_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});
$("#task_view_check").click(function(){

if($("#task_view_check").is(":checked")){
$("#task_edit_check").show();
$("#task_del_check").show();
$("#task_add_check").show();
}
else{
$("#task_edit_check").hide();
$("#task_del_check").hide();
$("#task_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});
$("#payslip_view_check").click(function(){

if($("#payslip_view_check").is(":checked")){
$("#payslip_del_check").show();
$("#payslip_add_check").show();
}
else{

$("#payslip_del_check").hide();
$("#payslip_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});
$("#template_view_check").click(function(){

if($("#template_view_check").is(":checked")){

$("#template_edit_check").show();
$("#template_del_check").show();
$("#template_add_check").show();
}
else{
$("#template_edit_check").hide();
$("#template_del_check").hide();
$("#template_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});
$("#awards_view_check").click(function(){
if($("#awards_view_check").is(":checked")){
$("#awards_add_check").show();
}else{
$("#awards_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});


$("#noticeboard_view_check").click(function(){

if($("#noticeboard_view_check").is(":checked")){

$("#noticeboard_edit_check").show();
$("#noticeboard_del_check").show();
$("#noticeboard_add_check").show();
}
else{
$("#noticeboard_edit_check").hide();
$("#noticeboard_del_check").hide();
$("#noticeboard_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});

</script>

<script>


if($("#fixed_based").is(":checked")){

$("#annual_fixed_leaves").show();
}
else{
$("#annual_fixed_leaves").hide();
}
$("#fixed_based").click(function(){
$("#service_based").removeAttr("checked");
$("#annual_fixed_leaves").show();
$("#service_based_leaves").hide();
$("#service_based_heading").hide();
$("#annual").show();
});
$("#service_based").click(function(){
$("#fixed_based").removeAttr("checked");
$("#service_based_leaves").show();
$("#annual_fixed_leaves").show();
$("#service_based_heading").show();
$("#annual").hide();

});
if($("#service_based").is(":checked")){

$("#service_based_leaves").show();
$("#annual_fixed_leaves").show();
$("#service_based_heading").show();
$("#annual").hide();
}
else{
$("#service_based_leaves").hide();
}

</script>

<script>
$("#sun_check").click(function(){
if($("#sun_check").is(":checked")){
$("#timepicker13").attr("disabled",true);
$("#timepicker14").attr("disabled",true);
}
else {
$("#timepicker13").attr("disabled",false);
$("#timepicker14").attr("disabled",false);
}
});
$("#mon_check").click(function(){
if($("#mon_check").is(":checked")){
$("#timepicker1").attr("disabled",true);
$("#timepicker2").attr("disabled",true);
}
else {
$("#timepicker1").attr("disabled",false);
$("#timepicker2").attr("disabled",false);
}
});
$("#tues_check").click(function(){
if($("#tues_check").is(":checked")){
$("#timepicker3").attr("disabled",true);
$("#timepicker4").attr("disabled",true);
}
else {
$("#timepicker3").attr("disabled",false);
$("#timepicker4").attr("disabled",false);
}
});
$("#wed_check").click(function(){
if($("#wed_check").is(":checked")){
$("#timepicker5").attr("disabled",true);
$("#timepicker6").attr("disabled",true);
}
else {
$("#timepicker5").attr("disabled",false);
$("#timepicker6").attr("disabled",false);
}
});
$("#thurs_check").click(function(){
if($("#thurs_check").is(":checked")){
$("#timepicker7").attr("disabled",true);
$("#timepicker8").attr("disabled",true);
}
else {
$("#timepicker7").attr("disabled",false);
$("#timepicker8").attr("disabled",false);
}
});
$("#fri_check").click(function(){
if($("#fri_check").is(":checked")){
$("#timepicker9").attr("disabled",true);
$("#timepicker10").attr("disabled",true);
}
else {
$("#timepicker9").attr("disabled",false);
$("#timepicker10").attr("disabled",false);
}
});
$("#sat_check").click(function(){
if($("#sat_check").is(":checked")){
$("#timepicker11").attr("disabled",true);
$("#timepicker12").attr("disabled",true);
}
else {
$("#timepicker11").attr("disabled",false);
$("#timepicker12").attr("disabled",false);
}
});

$(function(){
	$("#retype").change(function(){
		var retype = $("#retype").val();
		var pass   = $("#pass").val();
		if(retype == pass){
			return true;
		}else{
			alert("Password Does Not Same Please Enter Again!");
			$("#retype").val('');
		}
	});
	
});

//for age
$(".birth").change(function(){
var dob = $("#dob").val();

dob = new Date(dob);
var today = new Date();
var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
$('#empage').val(age);
});
//for address
$("#full_add").keyup(function(){
var street1=$("#street_1").val();
var houseno=$("#houseno").val();
var country=$("#coun").val();
var postal=$("#postal").val();

var res=houseno.concat(","+street1+","+country+","+postal);

$("#fullad").val(res);


});

$(".co").change(function(){
var block = $("#block").val();
var street1=$("#street_1").val();
var street2=$("#street_2").val();
var street3=$("#street_3").val();
var houseno=$("#houseno").val();
var country=$("#coun").val();
var postal=$("#postal").val();

var res=houseno.concat(","+street1+","+country+","+postal);

$("#fullad").val(res);
});


$(document).ready(function(){
$("#empid").change(function(){

var eid=$("#empid").val();
var sal=$(".emp"+eid).attr('data');

var arr = sal.split('/');

$("#sal").val(arr[0]);
$("#netsal").val(arr[1]);


});
});


jQuery('#con_no').keyup(function () {
this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');
this.value = this.value.replace(/[^0-9]/g, '');
});


jQuery('#mob_no').keyup(function () {
this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');
this.value = this.value.replace(/[^0-9]/g, '');
});

$('.nextofkin_conno').keyup(function () {
this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');
this.value = this.value.replace(/[^0-9]/g, '');
});

</script>

<script>

$('.save').click(function(){

var awd_data=$("#awd_name").val();
var last_award_id = $(".last_award_id").val();
$.ajax({
type: "POST",
url: "https://shiftsystems.net/demo/index.php?user=ajax",
data: 'awd_data=' +awd_data,

success: function(data)
{

$(".fade").fadeOut();
$("#myModal").hide();
var new_last_id = parseInt(last_award_id)+parseInt(1);
$('body').removeClass('modal-open');
var newOption = "<option value='"+new_last_id+"'>"+awd_data+"</option>";
$("#sel_awd").append(newOption);
$(".last_award_id").val(new_last_id);
}


});
});
$('.Click_New_Award').click(function(){
$(".fade").fadeIn();
$("#myModal").show();
});
</script>


<script>
$('.check_particular').click(function(){
var data_ID=$(this).attr("data-id");
if($(this).prop("checked")==true)
{
var Prev_Ids = $(".prev_select_item_id").val();
$(".prev_select_item_id").val(data_ID+'__'+Prev_Ids);
$('.show_delete_button').show();
}
if($(this).prop("checked")==false){
var Prev_Ids = $(".prev_select_item_id").val();
var Remove_Id = data_ID+'__';
var After_Unselect = Prev_Ids.replace(Remove_Id,"");
$(".prev_select_item_id").val(After_Unselect);
if(After_Unselect==""){
$('.show_delete_button').hide();
}
}

});
</script>

<script>
$(".clickonedit").click(function(){
$(".show_field").show();
$(".hide_field").hide();
});

$('.e_check').click(function(){
if($(this).is(":checked")){
$('.hide_e_check').hide();
}else{
$('.hide_e_check').show();
}
});
</script>

<script>
$('.delid').click(function(){
var delid=$(this).attr('data-id');
$('.confirmdelete').val(delid)

});

$('.fancy-close').click(function(){
$('.hide_fancybox').close();
});
</script>
<script>
function goback(){
window.history.back();
}
</script>
<!-- ----------------------------for attendance marked---------------- -->
<script>
$(".Post_Mark_Attendance").click(function(){
var employee_id=$(".Post_id").attr('data-emp-id');
var employee_code=$(".Post_code").attr('data-emp-code');
var employee_deptid=$(".Post_deptid").attr('data-dept-id');
var empdate=$(".Post_date").attr('data-date');
var fulldetails ='&employee_id='+employee_id+'&employee_code='+employee_code+'&employee_deptid='+employee_deptid+'&empdate='+empdate;
$.ajax({
type: "POST",
url: "https://shiftsystems.net/demo/index.php?user=ajax",
data: 'fulldetails='+fulldetails,

success: function(data)
{

$(".datashown").text(data);
$(".datashown").removeClass('btn btn-xs btn-success');
$(".datashown").addClass('btn btn-xs btn-danger');
$(".datashown").attr('disabled','disabled');

}
});

})
</script>

<script>
function startTime() {
var today = new Date();
var h = today.getHours();
var m = today.getMinutes();
var s = today.getSeconds();
m = checkTime(m);
s = checkTime(s);
document.getElementById('txt').innerHTML =
h + ":" + m + ":" + s;
var t = setTimeout(startTime, 500);
}
function checkTime(i) {
if (i < 10) {i = "0" + i}; // add zero in front of numbers < 10
return i;
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>