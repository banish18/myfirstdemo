<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Employee Portal')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
	 <!-- CORE CSS-->    
    <link href="<?php echo e(asset('css/materialize.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="<?php echo e(asset('css/style.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
    <!-- CSS style Horizontal Nav-->    
    <link href="<?php echo e(asset('css/layouts/style-horizontal.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
    <!-- Custome CSS-->    
    <link href="<?php echo e(asset('css/custom/custom.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
    


    <!-- INCLUDED PLUGIN CSS ON THIS PAGE -->
    <link href="<?php echo e(asset('js/plugins/perfect-scrollbar/perfect-scrollbar.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="<?php echo e(asset('js/plugins/jvectormap/jquery-jvectormap.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="<?php echo e(asset('js/plugins/chartist-js/chartist.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
	
	   <link href="<?php echo e(asset('css/custom/custom.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
</head>

<body>
    <div id="app">
      
    <!-- Start Page Loading -->
    <div id="loader-wrapper">
        <div id="loader"></div>        
        <div class="loader-section section-left"></div>
        <div class="loader-section section-right"></div>
    </div>
	<?php echo $__env->make("templates/admin-nav", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- End Page Loading -->

        <?php echo $__env->yieldContent('content'); ?>
    </div>
	<?php echo $__env->make("templates/admin-footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <!-- ================================================
    Scripts
    ================================================ -->
    
    <!-- jQuery Library -->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/jquery-1.11.2.min.js')); ?>"></script>
    <!--materialize js-->
    <script type="text/javascript" src="<?php echo e(asset('js/materialize.min.js')); ?>"></script>
    <!--scrollbar-->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    

    <!-- chartist -->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/chartist-js/chartist.min.js')); ?>"></script>   

    <!-- chartjs -->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/chartjs/chart.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/chartjs/chart-script.js')); ?>"></script>

    <!-- sparkline -->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/sparkline/jquery.sparkline.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/sparkline/sparkline-script.js')); ?>"></script>
    
    <!-- google map api -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAAZnaZBXLqNBRXjd-82km_NO7GUItyKek"></script>

    <!--jvectormap-->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/jvectormap/vectormap-script.js')); ?>"></script>    
    
    <!--google map-->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/google-map/google-map-script.js')); ?>"></script>
    
    <!--plugins.js - Some Specific JS codes for Plugin Settings-->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins.min.js')); ?>"></script>
    <!--custom-script.js - Add your own theme custom JS-->
    <script type="text/javascript" src="<?php echo e(asset('js/custom-script.js')); ?>"></script>
    <!-- Toast Notification -->
    <script type="text/javascript">
    // Toast Notification
    $(window).load(function() {
        setTimeout(function() {
            Materialize.toast('<span>Hiya! I am a toast.</span>', 1500);
        }, 1500);
        setTimeout(function() {
            Materialize.toast('<span>You can swipe me too!</span>', 3000);
        }, 5000);
        setTimeout(function() {
            Materialize.toast('<span>You have new order.</span><a class="btn-flat yellow-text" href="#">Read<a>', 3000);
        }, 15000);
    });
    </script>

</body>
</html>
	

