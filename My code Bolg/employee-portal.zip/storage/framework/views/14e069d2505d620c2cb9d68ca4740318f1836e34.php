<?php 
namespace App\Http\Controllers;
use Auth;
?>
    <div class="header-wrapper">
    <div class="header">
        <div class="header-top">
            <div class="container">
                <div class="header-brand">
                    <div class="header-logo">
                        <a href="<?php echo e(route('home')); ?>">
                           <img src="<?php echo e(asset('frontassets/img/company.png')); ?>" alt="logo">
                            <span class="header-logo-text"><span class="header-logo-highlight"></span></span>
                        </a>
                    </div><!-- /.header-logo-->

                </div><!-- /.header-brand -->

                <ul class="header-actions nav nav-pills">
                    <li class="dropdown">
                     <div class="btn-group user-drp">
                    <a href="http://mindxpert.com/portal/profile">
                    <img src="<?php echo e(asset('frontassets/img/tmp/resume-3.jpg')); ?>" style="margin-top:2px;width:50px;height:50px;border-radius:50%;"></a>
                    Welcome <?php echo Auth::User()->name; ?>
                   <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                    
                    <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu">
                    <li>
                    <a href="<?php echo e(route('home',array('action' => 'profile'))); ?>">profile</a>
                   </li>
                    <li>
                    <a href="<?php echo e(route('home',array('action' => 'change-password'))); ?>">Change Password</a>
                   </li>
                   <li>
                   <a href="<?php echo e(route('home',array('action' => 'setting'))); ?>">Settings</a>
                   </li>
                   <li class="divider"></li>
                   <li>
                   <a href="<?php echo e(route('logout')); ?>">Logout</a>
                    </li>  
                  </ul>
</div>
               
                </li>
                </ul><!-- /.header-actions -->

                <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div><!-- /.container -->
        </div><!-- /.header-top -->

        <div class="header-bottom">
            <div class="container">
               <ul class="header-nav nav nav-pills collapse">
                
                    <li class="active">
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('home',array('action' => 'rules-regulation'))); ?>">Rules & Regulations </a>
                    </li>
				    <li class="dropdown">
						  <a href="<?php echo e(route('home',array('action' => 'notification'))); ?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Employee Self Services</a>
						  <ul class="dropdown-menu">
							<li><a href="<?php echo e(route('employee-services')); ?>">Employee Concern</a></li>
							<li><a href="<?php echo e(route('employee-services',array('create-resume'))); ?>">Create Resume</a></li>
							<li><a href="<?php echo e(route('employee-services',array('employee-address'))); ?>">Employee Address</a></li>
							<li><a href="<?php echo e(route('employee-services',array('my-documents'))); ?>">My Documents</a></li>
							<li><a href="<?php echo e(route('employee-services',array('positions'))); ?>">Positions</a></li>
							<li><a href="<?php echo e(route('employee-services',array('position-detail'))); ?>">Positions Detail</a></li>
							<li><a href="<?php echo e(route('users',array('generate-resignation-request'))); ?>">Resignation Request</a></li>

						  </ul>
					</li>

                    <li>
                        <a href="<?php echo e(route('hr-management')); ?>">HR Management</a>
                    </li>
                    
                      <li>
          <a href="<?php echo e(route('home',array('action' => 'notification'))); ?>">Notifications <span class="badge">4</span></a>
          <!--ul class="dropdown-menu">
            <li><a href="#">Regarding Leave</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">Separated link</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">One more separated link</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="#">One more separated link</a></li>
          </ul-->
        </li>
                         
                    
                    <li>
                        <a href="<?php echo e(route('home',array('action' => 'latest-updates'))); ?>">Latest Updates</a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('home',array('action' => 'contact'))); ?>"> <i class="fa fa-phone"></i> Contact Us</a>
                    </li>

                </ul>
                      
</nav>
            </div><!-- /.container -->
        </div><!-- /.header-bottom -->
    </div><!-- /.header -->
</div><!-- /.header-wrapper-->