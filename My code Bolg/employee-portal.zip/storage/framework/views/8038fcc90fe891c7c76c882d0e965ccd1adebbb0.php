<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
<div class="page-title">
<div class="row">
<div class="col-md-12">
<h1>New Employee</h1></div></div>
</div>
<div class="row">
<div class="col-md-2">
<ul class="list-group">
<li class="list-group-item active" >
<a href="<?php echo e(route('users')); ?>">
<p>
<img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
&nbsp;List Employees
</p></a>
</li>

<li class="list-group-item">
<a href="<?php echo e(route('users',array('action' => 'add'))); ?>">
<p>
<img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
&nbsp;Add Employee
</p>
</a>
</li>
</ul>
</div>

<div class="col-md-10">
<div class="widget-container fluid-height clearfix">
<div class="widget-content padded">
<form method="post" class="form-horizontal" action="<?php echo e(route('users',array('action' => 'postAdd'))); ?>" enctype="multipart/form-data">

 <?php echo e(csrf_field()); ?>

<input type="hidden" name="profile" id="profilesize" >
<input type="hidden" name="emp_stat" value="1" />
<div class="row">
<div class="col-md-12">
<div class="col-md-6">
<div class="heading"><h2>Employee Details</h2></div><br>
<div class="form-group">
<label class="control-label col-md-3">Employee ID</label>
<div class="col-md-6">
<input class="form-control" name="uuid" type="text" value="<?php echo e($data['uuid']->uid+1); ?>">
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">First Name</label>
<div class="col-md-6">
<input class="form-control" name="e_name" type="text" value="">  
 <?php if($errors->has('e_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('e_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="form-group">
<label class="control-label col-md-3">Last Name</label>
<div class="col-md-6">
<input class="form-control" name="e_surname" type="text" value="">
 <?php if($errors->has('e_surname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('e_surname')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Date Of Birth</label>
<div class="col-md-6">
<div class="input-group date datepicker">
<input class="form-control birth" id="dob" type="text" name="e_dob" value="" ><span class="input-group-addon">

<img src="<?php echo e(asset('admin-asset/images/date.svg')); ?>" width="15">
</span>
</div>
<?php if($errors->has('e_dob')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('e_dob')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>

<div id="full_add">


<div class="form-group">
<label class="control-label col-md-3">House Number</label>
<div class="col-md-6">
<input class="form-control allownumericwithoutdecimal" id="houseno" name="house_no" type="text" value="">

</div>
</div>

<div class="form-group">
<label class="control-label col-md-3">Street Number 1</label>
<div class="col-md-6">
<input class="form-control" id="street_1" name="address_street_no1" type="text" value="">
</div>
</div>




<div class="form-group">
<label class="control-label col-md-3">Countries</label>
<div class="col-md-6">
<select class="form-control co" id="coun" name="country" >
<option value="0" label="Select a country ... " selected="selected">Select a country ... </option>
<option value="Afghanistan" >Afghanistan</option>
<option value="Albania" >Albania</option>
<option value="Algeria" >Algeria</option>
<option value="American Samoa" >American Samoa</option>
<option value="Andorra" >Andorra</option>
<option value="Angola" >Angola</option>
<option value="Anguilla" >Anguilla</option>
<option value="Antarctica" >Antarctica</option>
<option value="Antigua and Barbuda" >Antigua and Barbuda</option>
<option value="Argentina" >Argentina</option>
<option value="Armenia" >Armenia</option>
<option value="Aruba" >Aruba</option>
<option value="Australia" >Australia</option>
<option value="Austria" >Austria</option>
<option value="Azerbaijan" >Azerbaijan</option>
<option value="Bahamas" >Bahamas</option>
<option value="Bahrain" >Bahrain</option>
<option value="Bangladesh" >Bangladesh</option>
<option value="Barbados" >Barbados</option>
<option value="Belarus" >Belarus</option>
<option value="Belgium" >Belgium</option>
<option value="Belize" >Belize</option>
<option value="Benin" >Benin</option>
<option value="Bermuda" >Bermuda</option>
<option value="Bhutan" >Bhutan</option>
<option value="Bolivia" >Bolivia</option>
<option value="Bosnia and Herzegovina" >Bosnia and Herzegovina</option>
<option value="Botswana" >Botswana</option>
<option value="Bouvet Island" >Bouvet Island</option>
<option value="Brazil" >Brazil</option>
<option value="British Antarctic Territory" >British Antarctic Territory</option>
<option value="British Indian Ocean Territory" >British Indian Ocean Territory</option>
<option value="British Virgin Islands" >British Virgin Islands</option>
<option value="Brunei" >Brunei</option>
<option value="Bulgaria" >Bulgaria</option>
<option value="Burkina Faso" >Burkina Faso</option>
<option value="Burundi" >Burundi</option>
<option value="Cambodia" >Cambodia</option>
<option value="Cameroon" >Cameroon</option>
<option value="Canada" >Canada</option>
<option value="Canton and Enderbury Islands" >Canton and Enderbury Islands</option>
<option value="Cape Verde" >Cape Verde</option>
<option value="Cayman Islands" >Cayman Islands</option>
<option value="Central African Republic" >Central African Republic</option>
<option value="Chad" >Chad</option>
<option value="Chile" >Chile</option>
<option value="China" >China</option>
<option value="Christmas Island" >Christmas Island</option>
<option value="Cocos [Keeling] Islands" >Cocos [Keeling] Islands</option>
<option value="Colombia" >Colombia</option>
<option value="Comoros" >Comoros</option>
<option value="Congo - Brazzaville" >Congo - Brazzaville</option>
<option value="Congo - Kinshasa" >Congo - Kinshasa</option>
<option value="Cook Islands" >Cook Islands</option>
<option value="Costa Rica" >Costa Rica</option>
<option value="Croatia" >Croatia</option>
<option value="Cuba" >Cuba</option>
<option value="Cyprus" >Cyprus</option>
<option value="Czech Republic" >Czech Republic</option>
<option value="C?te d?Ivoire" >C?te d?Ivoire</option>
<option value="Denmark" >Denmark</option>
<option value="Djibouti" >Djibouti</option>
<option value="Dominica" >Dominica</option>
<option value="Dominican Republic" >Dominican Republic</option>
<option value="Dronning Maud Land" >Dronning Maud Land</option>
<option value="East Germany" >East Germany</option>
<option value="Ecuador" >Ecuador</option>
<option value="Egypt" >Egypt</option>
<option value="El Salvador" >El Salvador</option>
<option value="Equatorial Guinea" >Equatorial Guinea</option>
<option value="Eritrea" >Eritrea</option>
<option value="Estonia" >Estonia</option>
<option value="Ethiopia" >Ethiopia</option>
<option value="Falkland Islands" >Falkland Islands</option>
<option value="Faroe Islands" >Faroe Islands</option>
<option value="Fiji" >Fiji</option>
<option value="Finland" >Finland</option>
<option value="France" >France</option>
<option value="French Guiana" >French Guiana</option>
<option value="French Polynesia" >French Polynesia</option>
<option value="French Southern Territories" >French Southern Territories</option>
<option value="French Southern and Antarctic Territories" >French Southern and Antarctic Territories</option>
<option value="Gabon" >Gabon</option>
<option value="Gambia" >Gambia</option>
<option value="Georgia" >Georgia</option>
<option value="Germany" >Germany</option>
<option value="Ghana" >Ghana</option>
<option value="Gibraltar" >Gibraltar</option>
<option value="Greece" >Greece</option>
<option value="Greenland" >Greenland</option>
<option value="Grenada" >Grenada</option>
<option value="Guadeloupe" >Guadeloupe</option>
<option value="Guam" >Guam</option>
<option value="Guatemala" >Guatemala</option>
<option value="Guernsey" >Guernsey</option>
<option value="Guinea" >Guinea</option>
<option value="Guinea-Bissau" >Guinea-Bissau</option>
<option value="Guyana" >Guyana</option>
<option value="Haiti" >Haiti</option>
<option value="Heard Island and McDonald Islands" >Heard Island and McDonald Islands</option>
<option value="Honduras" >Honduras</option>
<option value="Hong Kong SAR China" >Hong Kong SAR China</option>
<option value="Hungary" >Hungary</option>
<option value="Iceland" >Iceland</option>
<option value="India" selected>India</option>
<option value="Indonesia" >Indonesia</option>
<option value="Iran" >Iran</option>
<option value="Iraq" >Iraq</option>
<option value="Ireland" >Ireland</option>
<option value="Isle of Man" >Isle of Man</option>
<option value="Israel" >Israel</option>
<option value="Italy" >Italy</option>
<option value="Jamaica" >Jamaica</option>
<option value="Japan" >Japan</option>
<option value="Jersey" >Jersey</option>
<option value="Johnston Island" >Johnston Island</option>
<option value="Jordan" >Jordan</option>
<option value="Kazakhstan" >Kazakhstan</option>
<option value="Kenya" >Kenya</option>
<option value="Kiribati" >Kiribati</option>
<option value="Kuwait" >Kuwait</option>
<option value="Kyrgyzstan" >Kyrgyzstan</option>
<option value="Laos" >Laos</option>
<option value="Latvia" >Latvia</option>
<option value="Lebanon" >Lebanon</option>
<option value="Lesotho" >Lesotho</option>
<option value="Liberia" >Liberia</option>
<option value="Libya" >Libya</option>
<option value="Liechtenstein" >Liechtenstein</option>
<option value="Lithuania" >Lithuania</option>
<option value="Luxembourg" >Luxembourg</option>
<option value="Macau SAR China" >Macau SAR China</option>
<option value="Macedonia" >Macedonia</option>
<option value="Madagascar" >Madagascar</option>
<option value="Malawi" >Malawi</option>
<option value="Malaysia" >Malaysia</option>
<option value="Maldives" >Maldives</option>
<option value="Mali" >Mali</option>
<option value="Malta" >Malta</option>
<option value="Marshall Islands" >Marshall Islands</option>
<option value="Martinique" >Martinique</option>
<option value="Mauritania" >Mauritania</option>
<option value="Mauritius" >Mauritius</option>
<option value="Mayotte" >Mayotte</option>
<option value="Metropolitan France" >Metropolitan France</option>
<option value="Mexico" >Mexico</option>
<option value="Micronesia" >Micronesia</option>
<option value="Midway Islands" >Midway Islands</option>
<option value="Moldova" >Moldova</option>
<option value="Monaco" >Monaco</option>
<option value="Mongolia" >Mongolia</option>
<option value="Montenegro" >Montenegro</option>
<option value="Montserrat" >Montserrat</option>
<option value="Morocco" >Morocco</option>
<option value="Mozambique" >Mozambique</option>
<option value="Myanmar [Burma]" >Myanmar [Burma]</option>
<option value="Namibia" >Namibia</option>
<option value="Nauru" >Nauru</option>
<option value="Nepal" >Nepal</option>
<option value="Netherlands" >Netherlands</option>
<option value="Netherlands Antilles" >Netherlands Antilles</option>
<option value="Neutral Zone" >Neutral Zone</option>
<option value="New Caledonia" >New Caledonia</option>
<option value="New Zealand" >New Zealand</option>
<option value="Nicaragua" >Nicaragua</option>
<option value="Niger" >Niger</option>
<option value="Nigeria" >Nigeria</option>
<option value="Niue" >Niue</option>
<option value="Norfolk Island" >Norfolk Island</option>
<option value="North Korea" >North Korea</option>
<option value="North Vietnam" >North Vietnam</option>
<option value="Northern Mariana Islands" >Northern Mariana Islands</option>
<option value="Norway" >Norway</option>
<option value="Oman" >Oman</option>
<option value="Pacific Islands Trust Territory" >Pacific Islands Trust Territory</option>
<option value="Pakistan" >Pakistan</option>
<option value="Palau" >Palau</option>
<option value="Palestinian Territories" >Palestinian Territories</option>
<option value="Panama" >Panama</option>
<option value="Panama Canal Zone" >Panama Canal Zone</option>
<option value="Papua New Guinea" >Papua New Guinea</option>
<option value="Paraguay" >Paraguay</option>
<option value="People's Democratic Republic of Yemen" >People's Democratic Republic of Yemen</option>
<option value="Peru" >Peru</option>
<option value="Philippines" >Philippines</option>
<option value="Pitcairn Islands" >Pitcairn Islands</option>
<option value="Poland" >Poland</option>
<option value="Portugal" >Portugal</option>
<option value="Puerto Rico" >Puerto Rico</option>
<option value="Qatar" >Qatar</option>
<option value="Romania" >Romania</option>
<option value="Russia" >Russia</option>
<option value="Rwanda" >Rwanda</option>
<option value="R?union" >R?union</option>
<option value="Saint Barth?lemy" >Saint Barth?lemy</option>
<option value="Saint Helena" >Saint Helena</option>
<option value="Saint Kitts and Nevis" >Saint Kitts and Nevis</option>
<option value="Saint Lucia" >Saint Lucia</option>
<option value="Saint Martin" >Saint Martin</option>
<option value="Saint Pierre and Miquelon" >Saint Pierre and Miquelon</option>
<option value="Saint Vincent and the Grenadines" >Saint Vincent and the Grenadines</option>
<option value="Samoa" >Samoa</option>
<option value="San Marino" >San Marino</option>
<option value="Saudi Arabia" >Saudi Arabia</option>
<option value="Senegal" >Senegal</option>
<option value="Serbia" >Serbia</option>
<option value="Serbia and Montenegro" >Serbia and Montenegro</option>
<option value="Seychelles" >Seychelles</option>
<option value="Sierra Leone" >Sierra Leone</option>
<option value="Singapore" >Singapore</option>
<option value="Slovakia" >Slovakia</option>
<option value="Slovenia" >Slovenia</option>
<option value="Solomon Islands" >Solomon Islands</option>
<option value="Somalia" >Somalia</option>
<option value="South Africa" >South Africa</option>
<option value="South Georgia and the South Sandwich Islands" >South Georgia and the South Sandwich Islands</option>
<option value="South Korea" >South Korea</option>
<option value="Spain" >Spain</option>
<option value="Sri Lanka" >Sri Lanka</option>
<option value="Sudan" >Sudan</option>
<option value="Suriname" >Suriname</option>
<option value="Svalbard and Jan Mayen" >Svalbard and Jan Mayen</option>
<option value="Swaziland" >Swaziland</option>
<option value="Sweden" >Sweden</option>
<option value="Switzerland" >Switzerland</option>
<option value="Syria" >Syria</option>
<option value="S?o Tom? and Pr?ncipe" >S?o Tom? and Pr?ncipe</option>
<option value="Taiwan" >Taiwan</option>
<option value="Tajikistan" >Tajikistan</option>
<option value="Tanzania" >Tanzania</option>
<option value="Thailand" >Thailand</option>
<option value="Timor-Leste" >Timor-Leste</option>
<option value="Togo" >Togo</option>
<option value="Tokelau" >Tokelau</option>
<option value="Tonga" >Tonga</option>
<option value="Trinidad and Tobago" >Trinidad and Tobago</option>
<option value="Tunisia" >Tunisia</option>
<option value="Turkey" >Turkey</option>
<option value="Turkmenistan" >Turkmenistan</option>
<option value="Turks and Caicos Islands" >Turks and Caicos Islands</option>
<option value="Tuvalu" >Tuvalu</option>
<option value="U.S. Minor Outlying Islands" >U.S. Minor Outlying Islands</option>
<option value="U.S. Miscellaneous Pacific Islands" >U.S. Miscellaneous Pacific Islands</option>
<option value="U.S. Virgin Islands" >U.S. Virgin Islands</option>
<option value="Uganda" >Uganda</option>
<option value="Ukraine" >Ukraine</option>
<option value="Union of Soviet Socialist Republics" >Union of Soviet Socialist Republics</option>
<option value="United Arab Emirates" >United Arab Emirates</option>
<option value="United Kingdom" >United Kingdom</option>
<option value="United States" >United States</option>
<option value="Unknown or Invalid Region" >Unknown or Invalid Region</option>
<option value="Uruguay" >Uruguay</option>
<option value="Uzbekistan" >Uzbekistan</option>
<option value="Vanuatu" >Vanuatu</option>
<option value="Vatican City" >Vatican City</option>
<option value="Venezuela" >Venezuela</option>
<option value="Vietnam" >Vietnam</option>
<option value="Wake Island" >Wake Island</option>
<option value="Wallis and Futuna" >Wallis and Futuna</option>
<option value="Western Sahara" >Western Sahara</option>
<option value="Yemen" >Yemen</option>
<option value="Zambia" >Zambia</option>
<option value="Zimbabwe" >Zimbabwe</option>
<option value="?land Islands" >?land Islands</option>
</select>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Postal Code</label>
<div class="col-md-6">
<input class="form-control" id="postal" name="postal_code" type="text" maxlength="6" value="">
</div>
</div>

<div class="form-group">
<label class="control-label col-md-3">Full Address</label>
<div class="col-md-6">
<textarea class="form-control" id="fullad" name="e_address" readonly="true"></textarea>
</div>
</div></div>

<div class="form-group">
<label class="control-label col-md-3">Contact No.</label>
<div class="col-md-6">
<input class="form-control" id="con_no" name="e_contact1" maxlength="12" type="text" value="">
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Mobile No.</label>
<div class="col-md-6">
<input class="form-control" id="mob_no" name="e_contact2" type="text" maxlength="12" value="">
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Photograph
</label>
<div class="col-md-5">
<div class="fileupload fileupload-new" data-provides="fileupload">
<input type="hidden" value="" name="">
<div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;">
<img src="<?php echo e(asset('admin-asset/images/-text.png')); ?>">
</div>
<div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
<div>
<span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span>

<span class="fileupload-exists">Change</span>
<input type="file" name="emp_photo" id="profile_pic"></span>
<a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
<br> <small>Only jpg ,png & jpeg (Max : 64M)</small>
</div>
</div>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Employment type</label>
<div class="col-md-6">
<label class="radio-inline">
<input name="emp_type" type="radio" value="part time" >
<span>Part Time</span>
</label>
<label class="radio-inline">
<input name="emp_type" type="radio" value="full time" >
<span>Full Time</span></label>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>

<div class="form-group">
<label class="control-label col-md-3">Working hours</label>
<div class="col-md-6">
<label class="radio-inline">
<input name="working_hours" type="radio" value="office business hours">
<span>Office business hours</span>
</label>
<label class="radio-inline">
<input name="working_hours" type="radio" value="shift hours">
<span>Shift hours</span></label>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>










</div>
<div class="col-md-6">
<div class="heading"><h2></h2></div><br>
<div class="form-group">
<label class="control-label col-md-3">Offer Date</label>
<div class="col-md-6">
<div class="input-group date datepicker">
<input class="form-control" id="from" type="text" name="offer_date" value="" >
<span class="input-group-addon">
<img src="<?php echo e(asset('admin-asset/images/date.svg')); ?>" width="15">
</span>

</div>
<?php if($errors->has('offer_date')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('offer_date')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>

<!--div class="form-group">
<label class="control-label col-md-3">Employee Code</label>
<div class="col-md-3">
<input class="form-control" type="text" name="e_code" value="" required>
<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="col-md-6">
<a class="btn btn btn-default tooltip-trigger"
data-placement="right" data-toggle="tooltip" title=""
data-original-title="duplicate employee code cannot exist">Info </a>
</div>
</div-->
<div class="form-group">
<label class="control-label col-md-3">Company</label>
<div class="col-md-6">
<select class="form-control" name="company">
                        <option value="0">Company</option>
                        <?php if($data["companies"]): ?>
						<?php $__currentLoopData = $data["companies"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>	
                      </select>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Department</label>
<div class="col-md-6">
<select class="form-control" name="e_department">
                        <option value="0">Department</option>
                        <option value="1">Developing </option>
                        <option value="2" >HR </option>
                        <option value="7" >Sales </option>
                      </select>
<?php if($errors->has('e_department')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('e_department')); ?></strong>
                                    </span>
                                <?php endif; ?>					  
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Basic Salary</label>
<div class="col-md-6">
<div class="input-group">
<span class="input-group-addon">$</span>
<input class="form-control" name="e_salary" type="text" value="">

</div>
<?php if($errors->has('e_salary')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('e_salary')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>

<div class="form-group">
<label class="control-label col-md-3">Sex</label>
<div class="col-md-6">
<label class="radio-inline">
<input name="sex" type="radio" value="male" >
<span>Male</span>
</label>
<label class="radio-inline">
<input name="sex" type="radio" value="female" >
<span>Female</span></label>
<?php if($errors->has('sex')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('sex')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>

<span style="color:#d43f3a">
mandatory
</span> </div>

<div class="form-group">
<label class="control-label col-md-3">Religion</label>
<div class="col-md-6">

<label class="radio-inline">
<input name="religion" type="radio" value="chinese" >
<span>Hindu</span>
</label>
<label class="radio-inline">
<input name="religion" type="radio" value="indian" >
<span>Mulsim</span></label>
<label class="radio-inline">
<input name="religion" type="radio" value="malaysia" >
<span>Sikh</span></label>
<label class="radio-inline">
<input name="religion" type="radio" value="others" >
<span>Others</span></label>

<?php if($errors->has('religion')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('religion')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
 
</div>
<div class="form-group">
<label class="control-label col-md-3">Job Title</label>

<div class="col-md-6">
<input class="form-control" name="jobtitle" type="text" value="">
<?php if($errors->has('jobtitle')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('jobtitle')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
</div>




<div class="form-group">
<label class="control-label col-md-3">Qualification</label>

<div class="col-md-6">
<input class="form-control" name="qualification" type="text" value="">
<?php if($errors->has('qualification')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('qualification')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<small>Use commas to separate names</small>

</div>

<div class="form-group">
<label class="control-label col-md-3">Email</label>
<div class="col-md-6">
<input class="form-control" name="e_email" type="text" value="">
<?php if($errors->has('e_email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('e_email')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="form-group">
<label class="control-label col-md-3">Password</label>
<div class="col-md-6">
<input class="form-control" id="pass" name="e_pass" type="password" value="" >
<?php if($errors->has('e_pass')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('e_pass')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="form-group">
<label class="control-label col-md-3">Retype-Password</label>
<div class="col-md-6">
<input class="form-control" name="retypepassword" id="retype" type="password" value=""> 
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>



<div class="form-group">
<label class="control-label col-md-3">Age(from date of birth)</label>
<div class="col-md-6">
<input class="form-control" id="empage" name="age" type="text" value="" readonly="true">
<?php if($errors->has('age')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('age')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div> </div>


<div class="form-group">
<label class="control-label col-md-3">Notice Period For Termination</label>
<div class="col-md-8">
<div class="col-md-3">
<input class="form-control" type="text" name="notice_period" value="">
</div><div class="col-md-8">
<select class="form-control" name="for_days">
<option value="0">---select by month/day--</option>
<option value="for month" >month/s</option>
<option value="for days" >day/s</option>
</select></div>
</div> </div>


<div class="form-group">
<label class="control-label col-md-3">Probation period</label>
<div class="col-md-8">
<div class="col-md-6">
<div class="input-group date datepicker">
<input class="form-control" id="ps" type="text" name="prob_start_date" value="" placeholder="start date">
<span class="input-group-addon">
<img src="<?php echo e(asset('admin-asset/images/date.svg')); ?>" width="15">
</span>
</div></div>
<div class="col-md-6">
<div class="input-group date datepicker">
<input class="form-control" id="pe" type="text" name="prob_end_date" value="" placeholder="end date">
<span class="input-group-addon">
<img src="<?php echo e(asset('admin-asset/images/date.svg')); ?>" width="15">
</span>
</div></div></div>

</div>
<div class="form-group">
<label class="control-label col-md-3">Working days per week</label>
<div class="col-md-6">
<div class="col-md-3">
<label class="checkbox">
<input type="checkbox" value="mon" name="working_weeks[mon]" ><span>Mon</span></label></div>
<div class="col-md-3">
<label class="checkbox">
<input type="checkbox" value="tue" name="working_weeks[tue]" ><span>Tues</span></label></div>
<div class="col-md-3">
<label class="checkbox">
<input type="checkbox" value="wed" name="working_weeks[wed]" ><span>Wed</span></label></div>
<div class="col-md-3">
<label class="checkbox">
<input type="checkbox" value="thu" name="working_weeks[thu]" ><span>Thurs</span></label></div>
<div class="col-md-3">
<label class="checkbox">
<input type="checkbox" value="fri" name="working_weeks[fri]" ><span>Fri</span></label></div>

<div class="col-md-3">
<label class="checkbox">
<input type="checkbox" value="sat" name="working_weeks[sat]" ><span>Sat</span></label></div>

<div class="col-md-3">
<label class="checkbox">
<input type="checkbox" value="sun" name="working_weeks[sun]" ><span>Sun</span></label></div>

</div>
<div class="col-md-1">
<a class="btn btn btn-default tooltip-trigger"
data-placement="right" data-toggle="tooltip" title=""
data-original-title="Only checked days will be counted in your leaves">Info </a>
</div></div>






</div>
</div></div>
<div class="row">
<div class="col-md-12">
<div class="form-group">
<div class="col-md-6">
<div class="heading">
<h2>Bank Details</h2>
</div></div></div>
<div class="col-md-6">
<div class="form-group">
<label class="control-label col-md-3">Name</label>
<div class="col-md-6">
<input class="form-control" name="name" type="text" value="">
<?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
</div>

<div class="form-group">
<label class="control-label col-md-3">Branch</label>
<div class="col-md-6">
<input class="form-control" name="branch" type="text" value="">
<?php if($errors->has('branch')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('branch')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">City</label>
<div class="col-md-6">
<input class="form-control" name="city" type="text" value="">
<?php if($errors->has('city')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('city')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Bank Statement</label>
<div class="col-md-6">
<div class="fileupload fileupload-new" data-provides="fileupload"><input value="" name="" type="hidden">
<span class="btn btn-default btn-file"><span class="fileupload-new">Select file</span><span class="fileupload-exists">Change</span><input name="bank_statement" id="add_proof" type="file"></span><span class="fileupload-preview"></span><button class="close fileupload-exists" data-dismiss="fileupload" style="float:none" type="button">?</button>
</div> <small>Zip, txt, jpeg, png, pdf, doc (Max : 64M)</small>
</div> </div>
<div class="form-group">
<label class="control-label col-md-3">Cancel Check</label>
<div class="col-md-6">
<div class="fileupload fileupload-new" data-provides="fileupload"><input value="" name="" type="hidden">
<span class="btn btn-default btn-file"><span class="fileupload-new">Select file</span><span class="fileupload-exists">Change</span><input name="cancel_check" id="add_proof" type="file"></span><span class="fileupload-preview"></span><button class="close fileupload-exists" data-dismiss="fileupload" style="float:none" type="button">?</button>
</div> <small>Zip, txt, jpeg, png, pdf, doc (Max : 64M)</small>
</div> </div>
</div> </div>
<div class="col-md-6">
<div class="form-group">
<label class="control-label col-md-3">Account Number</label>
<div class="col-md-6">
<input class="form-control" name="acc_no" type="text" value="">
<?php if($errors->has('acc_no')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('acc_no')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">IFSC Code</label>
<div class="col-md-6">
<input class="form-control" name="ifsccode" type="text" value="">
<?php if($errors->has('ifsccode')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('ifsccode')); ?></strong>
                                    </span>
                                <?php endif; ?>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Account Statement</label>
<div class="col-md-6">
<div class="fileupload fileupload-new" data-provides="fileupload"><input value="" name="" type="hidden">
<span class="btn btn-default btn-file"><span class="fileupload-new">Select file</span><span class="fileupload-exists">Change</span><input name="account_statement" id="add_proof" type="file"></span><span class="fileupload-preview"></span><button class="close fileupload-exists" data-dismiss="fileupload" style="float:none" type="button">?</button>
</div> <small>Zip, txt, jpeg, png, pdf, doc (Max : 64M)</small>
</div> </div>


<div class="form-group">
<label class="control-label col-md-3">Remarks</label>
<div class="col-md-6">
<textarea class="form-control" name="remark"></textarea>
</div>
</div>
</div>
</div>
<div class="form-group">
<div class="col-md-12">
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-success" type="submit" name="submit_employee"> Submit</button>
</div>
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
</div>
</div></div>
</form>
</div>
</div>
</div>
</div>
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
//For profile pic size
$('#profile_pic').bind('change', function() {
$('#profilesize').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");
});
// For qualification files
$('#qual_1').bind('change', function() {

$('#qualification_1').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});
$('#qual_2').bind('change', function() {

$('#qualification_2').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});
$('#qual_3').bind('change', function() {

$('#qualification_3').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});
$('#qual_4').bind('change', function() {

$('#qualification_4').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});
$('#qual_5').bind('change', function() {

$('#qualification_5').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});

//for addressproof and idproof
$('#add_proof').bind('change', function() {

$('#add_proof_size').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});
$('#id_proof').bind('change', function() {

$('#id_proof_size').val(this.files[0].size);
var a = this.files[0].size;
var b= 67108864;
if(a>b)
alert("File size must be less than 64M");

});


$(".allownumericwithoutdecimal").on("keypress keyup blur",function (event) {
$(this).val($(this).val().replace(/[^\d-].+/, ""));
if ((event.which > 57)) {
event.preventDefault();
}
});
</script>
<div class="row" style="text-align:center;"><span>V3.0</span></div>
</body></html>
<script>
$(document).ready(function(){
$(".pdf").click(function(){
$("#table1").hide();
setTimeout(function(){$("#table1").show()},1000);
});
});
</script>

<script>
$(".tooltip-trigger").tooltip();
</script>
<script>
/* for mobile navigation */
$('.navbar-toggle').click(function() {
return $('body, html').toggleClass("nav-open");
});

/*
* =============================================================================
* DataTables
* =============================================================================
*/
$("#dataTable1").dataTable({
"sPaginationType": "full_numbers",
aoColumnDefs: [
{
bSortable: false,
aTargets: [0, -1]
}
]
});
$('.table').each(function() {
return $(".table #checkAll").click(function() {
if ($(".table #checkAll").is(":checked")) {
return $(".table input[type=checkbox]").each(function() {
return $(this).prop("checked", true);
});
} else {
return $(".table input[type=checkbox]").each(function() {
return $(this).prop("checked", false);
});
}
});
});


/*
* =============================================================================
* Bootstrap Popover
* =============================================================================
*/

$(".popover-trigger").popover();
/*
* =============================================================================
* Datepicker
* =============================================================================
*/

var date = new Date();
$("#from").datepicker();

$("#to").datepicker();
$("#dob").datepicker();
$("#ps").datepicker();
$("#pe").datepicker();
$("#term").datepicker();
$("#periodfrom").datepicker();
$("#periodto").datepicker();


if($("#watermark_yes").is(":checked")){
$("#watermark").show();
}
else{
$("#watermark").hide();
}
$("#watermark_yes").click(function(){
$("#watermark").show();
});
$("#watermark_no").click(function(){
$("#watermark").hide();
});
</script>

<script>
$(document).ready(function (){
$(".fancybox").fancybox({
maxWidth: 700,
height: 'auto',
fitToView: false,
autoSize: true,
padding: 15,
nextEffect: 'fade',
prevEffect: 'fade',
helpers: {
title: {
type: "outside"
}
}
});
var a = $("#db_country").val();
$("#country").val(a);
});
</script>
<script>
$(document).ready(function (){
var a = $("#db_timezone").val();
$("#timezone").val(a);
});
$('#timepicker1').timepicker();
$('#timepicker2').timepicker();
$('#timepicker3').timepicker();
$('#timepicker4').timepicker();
$('#timepicker5').timepicker();
$('#timepicker6').timepicker();
$('#timepicker7').timepicker();
$('#timepicker8').timepicker();
$('#timepicker9').timepicker();
$('#timepicker10').timepicker();
$('#timepicker11').timepicker();
$('#timepicker12').timepicker();
$('#timepicker13').timepicker();
$('#timepicker14').timepicker();

</script>

<script>
$(document).ready(function (){
var a = $("#date_format").val();
$("#dateformat").val(a);
});
</script>


<!-- ************************for change of salary from edit employee***************************** -->
<script>


var a2 = Number($("#a2").val());
var a3 = Number($("#a3").val());
var a4 = Number($("#a4").val());
var a5 = Number($("#a5").val());
var ta_sum=a2+a3+a4+a5;
$(".ta_total").val(ta_sum);




var d2 = Number($("#d2").val());
var d3 = Number($("#d3").val());

var td_sum=d2+d3;
$(".td_total").val(td_sum);



var ad2 = Number($("#ad2").val());
var ad3 = Number($("#ad3").val());
var ad4 = Number($("#ad4").val());

var add_sum=ad2+ad3+ad4;
$(".add_total").val(add_sum);



var basic = Number($("#basic").val());
var ta = Number($(".ta_total").val());
var td = Number($(".td_total").val());
var add = Number($(".add_total").val());
var overtime=Number($(".overtime").val());

var employee_cpf=Number($("#employee_cpf").val());
var net_pay_plus= (basic+ta+add+overtime);
var net_pay_minus = (td+employee_cpf);
var net_pay = (net_pay_plus-net_pay_minus);

$("#net").val(net_pay);



</script>
<!-- **************************************************************************** -->

<script>
$("#enable_check").click(function(){
if($("#enable_check").is(":checked")){
$("#time1").hide();
$("#time2").hide();
}
else {
$("#time1").show();
$("#time2").show();
}
});
</script>
<script>
$("#emp_view_check").click(function(){

if($("#emp_view_check").is(":checked")){

$("#emp_edit_check").show();
$("#emp_del_check").show();
$("#emp_add_check").show();
}
else{
$("#emp_edit_check").hide();
$("#emp_del_check").hide();
$("#emp_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});

$("#dep_view_check").click(function(){

if($("#dep_view_check").is(":checked")){

$("#dep_edit_check").show();
$("#dep_del_check").show();
$("#dep_add_check").show();
}
else{
$("#dep_edit_check").hide();
$("#dep_del_check").hide();
$("#dep_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});
$("#holiday_view_check").click(function(){

if($("#holiday_view_check").is(":checked")){

$("#holiday_edit_check").show();
$("#holiday_del_check").show();
$("#holiday_add_check").show();
}
else{
$("#holiday_edit_check").hide();
$("#holiday_del_check").hide();
$("#holiday_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});
$("#task_view_check").click(function(){

if($("#task_view_check").is(":checked")){
$("#task_edit_check").show();
$("#task_del_check").show();
$("#task_add_check").show();
}
else{
$("#task_edit_check").hide();
$("#task_del_check").hide();
$("#task_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});
$("#payslip_view_check").click(function(){

if($("#payslip_view_check").is(":checked")){
$("#payslip_del_check").show();
$("#payslip_add_check").show();
}
else{

$("#payslip_del_check").hide();
$("#payslip_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});
$("#template_view_check").click(function(){

if($("#template_view_check").is(":checked")){

$("#template_edit_check").show();
$("#template_del_check").show();
$("#template_add_check").show();
}
else{
$("#template_edit_check").hide();
$("#template_del_check").hide();
$("#template_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});
$("#awards_view_check").click(function(){
if($("#awards_view_check").is(":checked")){
$("#awards_add_check").show();
}else{
$("#awards_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});


$("#noticeboard_view_check").click(function(){

if($("#noticeboard_view_check").is(":checked")){

$("#noticeboard_edit_check").show();
$("#noticeboard_del_check").show();
$("#noticeboard_add_check").show();
}
else{
$("#noticeboard_edit_check").hide();
$("#noticeboard_del_check").hide();
$("#noticeboard_add_check").hide();
$(".employee_uncheck").removeAttr("checked","checked");
}
});

</script>

<script>


if($("#fixed_based").is(":checked")){

$("#annual_fixed_leaves").show();
}
else{
$("#annual_fixed_leaves").hide();
}
$("#fixed_based").click(function(){
$("#service_based").removeAttr("checked");
$("#annual_fixed_leaves").show();
$("#service_based_leaves").hide();
$("#service_based_heading").hide();
$("#annual").show();
});
$("#service_based").click(function(){
$("#fixed_based").removeAttr("checked");
$("#service_based_leaves").show();
$("#annual_fixed_leaves").show();
$("#service_based_heading").show();
$("#annual").hide();

});
if($("#service_based").is(":checked")){

$("#service_based_leaves").show();
$("#annual_fixed_leaves").show();
$("#service_based_heading").show();
$("#annual").hide();
}
else{
$("#service_based_leaves").hide();
}

</script>

<script>
$("#sun_check").click(function(){
if($("#sun_check").is(":checked")){
$("#timepicker13").attr("disabled",true);
$("#timepicker14").attr("disabled",true);
}
else {
$("#timepicker13").attr("disabled",false);
$("#timepicker14").attr("disabled",false);
}
});
$("#mon_check").click(function(){
if($("#mon_check").is(":checked")){
$("#timepicker1").attr("disabled",true);
$("#timepicker2").attr("disabled",true);
}
else {
$("#timepicker1").attr("disabled",false);
$("#timepicker2").attr("disabled",false);
}
});
$("#tues_check").click(function(){
if($("#tues_check").is(":checked")){
$("#timepicker3").attr("disabled",true);
$("#timepicker4").attr("disabled",true);
}
else {
$("#timepicker3").attr("disabled",false);
$("#timepicker4").attr("disabled",false);
}
});
$("#wed_check").click(function(){
if($("#wed_check").is(":checked")){
$("#timepicker5").attr("disabled",true);
$("#timepicker6").attr("disabled",true);
}
else {
$("#timepicker5").attr("disabled",false);
$("#timepicker6").attr("disabled",false);
}
});
$("#thurs_check").click(function(){
if($("#thurs_check").is(":checked")){
$("#timepicker7").attr("disabled",true);
$("#timepicker8").attr("disabled",true);
}
else {
$("#timepicker7").attr("disabled",false);
$("#timepicker8").attr("disabled",false);
}
});
$("#fri_check").click(function(){
if($("#fri_check").is(":checked")){
$("#timepicker9").attr("disabled",true);
$("#timepicker10").attr("disabled",true);
}
else {
$("#timepicker9").attr("disabled",false);
$("#timepicker10").attr("disabled",false);
}
});
$("#sat_check").click(function(){
if($("#sat_check").is(":checked")){
$("#timepicker11").attr("disabled",true);
$("#timepicker12").attr("disabled",true);
}
else {
$("#timepicker11").attr("disabled",false);
$("#timepicker12").attr("disabled",false);
}
});

$(function(){
	$("#retype").change(function(){
		var retype = $("#retype").val();
		var pass   = $("#pass").val();
		if(retype == pass){
			return true;
		}else{
			alert("Password Does Not Same Please Enter Again!");
			$("#retype").val('');
		}
	});
	
});

//for age
$(".birth").change(function(){
var dob = $("#dob").val();

dob = new Date(dob);
var today = new Date();
var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
$('#empage').val(age);
});
//for address
$("#full_add").keyup(function(){
var street1=$("#street_1").val();
var houseno=$("#houseno").val();
var country=$("#coun").val();
var postal=$("#postal").val();

var res=houseno.concat(","+street1+","+country+","+postal);

$("#fullad").val(res);


});

$(".co").change(function(){
var block = $("#block").val();
var street1=$("#street_1").val();
var street2=$("#street_2").val();
var street3=$("#street_3").val();
var houseno=$("#houseno").val();
var country=$("#coun").val();
var postal=$("#postal").val();

var res=houseno.concat(","+street1+","+country+","+postal);

$("#fullad").val(res);
});


$(document).ready(function(){
$("#empid").change(function(){

var eid=$("#empid").val();
var sal=$(".emp"+eid).attr('data');

var arr = sal.split('/');

$("#sal").val(arr[0]);
$("#netsal").val(arr[1]);


});
});


jQuery('#con_no').keyup(function () {
this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');
this.value = this.value.replace(/[^0-9]/g, '');
});


jQuery('#mob_no').keyup(function () {
this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');
this.value = this.value.replace(/[^0-9]/g, '');
});

$('.nextofkin_conno').keyup(function () {
this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');
this.value = this.value.replace(/[^0-9]/g, '');
});

</script>

<script>

$('.save').click(function(){

var awd_data=$("#awd_name").val();
var last_award_id = $(".last_award_id").val();
$.ajax({
type: "POST",
url: "https://shiftsystems.net/demo/index.php?user=ajax",
data: 'awd_data=' +awd_data,

success: function(data)
{

$(".fade").fadeOut();
$("#myModal").hide();
var new_last_id = parseInt(last_award_id)+parseInt(1);
$('body').removeClass('modal-open');
var newOption = "<option value='"+new_last_id+"'>"+awd_data+"</option>";
$("#sel_awd").append(newOption);
$(".last_award_id").val(new_last_id);
}


});
});
$('.Click_New_Award').click(function(){
$(".fade").fadeIn();
$("#myModal").show();
});
</script>


<script>
$('.check_particular').click(function(){
var data_ID=$(this).attr("data-id");
if($(this).prop("checked")==true)
{
var Prev_Ids = $(".prev_select_item_id").val();
$(".prev_select_item_id").val(data_ID+'__'+Prev_Ids);
$('.show_delete_button').show();
}
if($(this).prop("checked")==false){
var Prev_Ids = $(".prev_select_item_id").val();
var Remove_Id = data_ID+'__';
var After_Unselect = Prev_Ids.replace(Remove_Id,"");
$(".prev_select_item_id").val(After_Unselect);
if(After_Unselect==""){
$('.show_delete_button').hide();
}
}

});
</script>

<script>
$(".clickonedit").click(function(){
$(".show_field").show();
$(".hide_field").hide();
});

$('.e_check').click(function(){
if($(this).is(":checked")){
$('.hide_e_check').hide();
}else{
$('.hide_e_check').show();
}
});
</script>

<script>
$('.delid').click(function(){
var delid=$(this).attr('data-id');
$('.confirmdelete').val(delid)

});

$('.fancy-close').click(function(){
$('.hide_fancybox').close();
});
</script>
<script>
function goback(){
window.history.back();
}
</script>
<!-- ----------------------------for attendance marked---------------- -->
<script>
$(".Post_Mark_Attendance").click(function(){
var employee_id=$(".Post_id").attr('data-emp-id');
var employee_code=$(".Post_code").attr('data-emp-code');
var employee_deptid=$(".Post_deptid").attr('data-dept-id');
var empdate=$(".Post_date").attr('data-date');
var fulldetails ='&employee_id='+employee_id+'&employee_code='+employee_code+'&employee_deptid='+employee_deptid+'&empdate='+empdate;
$.ajax({
type: "POST",
url: "https://shiftsystems.net/demo/index.php?user=ajax",
data: 'fulldetails='+fulldetails,

success: function(data)
{

$(".datashown").text(data);
$(".datashown").removeClass('btn btn-xs btn-success');
$(".datashown").addClass('btn btn-xs btn-danger');
$(".datashown").attr('disabled','disabled');

}
});

})
</script>

<script>
function startTime() {
var today = new Date();
var h = today.getHours();
var m = today.getMinutes();
var s = today.getSeconds();
m = checkTime(m);
s = checkTime(s);
document.getElementById('txt').innerHTML =
h + ":" + m + ":" + s;
var t = setTimeout(startTime, 500);
}
function checkTime(i) {
if (i < 10) {i = "0" + i}; // add zero in front of numbers < 10
return i;
}
</script>
<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>