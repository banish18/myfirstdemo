<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
<div class="page-title">
<div class="row">
<div class="col-md-12">
<h1>New Note</h1></div></div>
</div>
<div class="row">
<div class="col-md-2">
<ul class="list-group">
<li class="list-group-item active" >
<a href="<?php echo e(route('notes')); ?>">
<p>
<img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
&nbsp;List Notes
</p></a>
</li>

</ul>
</div>

<div class="col-md-10">
<div class="widget-container fluid-height clearfix">
<div class="widget-content padded">
<form method="post" class="form-horizontal" action="<?php echo e(route('notes',array('action' => 'postAdd'))); ?>" enctype="multipart/form-data">

 <?php echo e(csrf_field()); ?>


<div class="row">
<div class="col-md-12">
<div class="col-md-9">
<div class="heading"><h2>Notes Details</h2></div><br>
<div class="form-group">
<label class="control-label col-md-3">Title</label>
<div class="col-md-7">
<input class="form-control" name="title" type="text" value="" required>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="form-group">
<label class="control-label col-md-3">Description</label>
<div class="col-md-7">
<textarea class="form-control" name="desc" required></textarea>
</div>
</div>

<div class="form-group">
<div class="col-md-12">
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-success" type="submit" name="submit_employee"> Submit</button>
</div>
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
</div>
</div></div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>