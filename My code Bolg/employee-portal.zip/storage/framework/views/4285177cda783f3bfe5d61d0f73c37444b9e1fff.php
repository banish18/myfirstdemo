<?php $__env->startSection('content'); ?>

            <div class="main-wrapper">
        <div class="main">
            <div class="hero-content">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-6">
                <h1>Mind Solutions Technology</h1>
                <h2>Well trusted and verified company all around the world.</h2>

                
            </div><!-- /.col-* -->

            <div class="col-sm-6 col-md-5 col-md-offset-1">
                <div class="hero-content-carousel">
                    <h2>Happening Right Now</h2>

                    <ul class="cycle-slideshow vertical"
                        data-cycle-fx="carousel"
                        data-cycle-slides="li"
                        data-cycle-carousel-visible="7"
                        data-cycle-carousel-vertical="true">
                        <li><a href="company-detail.html">Dropbox</a> is looking for UX/UI designer.</li>
                        <li>Python Developer <a href="#">John Doe</a>.</li>
                        <li><a href="position-detail.html">IT consultant</a> is needed by <a href="company-detail.html">Twitter</a>.</li>
                        <li>Project manager wanted for <a href="company-detail.html">e-shop portal</a>.</li>
                        <li><a href="company-detail.html">Mark Peterson</a> needs to fix his website.</li>
                        <li><a href="company-detail.html">Facebook</a> is looking for <a href="position-detail.html">beta testers</a>.</li>
                        <li><a href="company-detail.html">Instagram</a> needs help with new API.</li>
                        <li><a href="company-detail.html">Dropbox</a> is looking for UX/UI designer.</li>
                        <li>Python Developer <a href="resume.html">John Doe</a> is looking for work.</li>
                        <li><a href="position-detail.html">IT consultant</a> is needed by <a href="company-detail.html">Twitter</a>.</li>
                        <li>Project manager wanted for one time <a href="#">e-shop portal</a>.</li>
                        <li><a href="company-detail.html">Mark Peterson</a> needs to fix his website.</li>
                        <li><a href="company-detail.html">Facebook</a> is looking for <a href="position-detail.html">beta testers</a>.</li>
                        <li><a href="company-detail.html">Instagram</a> needs help with new API.</li>
                    </ul>

                    <a href="<?php echo e(route('employee-services',array('action' => 'positions'))); ?> " class="hero-content-show-all">Show All</a>
                </div><!-- /.hero-content-content -->
            </div><!-- /.col-* -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</div><!-- /.hero-content -->


<div class="stats">
    <div class="container">
        <div class="row">
            <div class="stat-item col-sm-4" data-to="123">
                <strong id="stat-item-1">0</strong>
                <span>Jobs Added</span>
            </div><!-- /.col-* -->

            <div class="stat-item col-sm-4" data-to="187">
                <strong id="stat-item-2">0</strong>
                <span>Active Resumes</span>
            </div><!-- /.col-* -->

            <div class="stat-item col-sm-4" data-to="140">
                <strong id="stat-item-3">0</strong>
                <span>Positions Matched</span>
            </div><!-- /.col-* -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</div><!-- /.stats -->


<div class="container">
	<div class="row">
    <div class="col-sm-6">
        <h2 class="page-header">Partners</h2>

        <div class="companies-list">
            
                

                <div class="companies-list-item">
                    <div class="companies-list-item-image">
                        <a href="company-detail.html">
                            
                                <img src="assets/img/tmp/airbnb.png" alt="">
                            
                        </a>
                    </div><!-- /.companies-list-item-image -->

                    <div class="companies-list-item-heading">
                        <h2><a href="company-detail.html">Airbnb</a></h2>
                        <h3>New York City, New York</h3>
                    </div><!-- /.companies-list-item-heading -->

                    <div class="companies-list-item-count">
                        <a href="positions.html">3 open positions</a>
                    </div><!-- /.positions-list-item-count -->

                </div><!-- /.companies-list-item -->
            
                

                <div class="companies-list-item">
                    <div class="companies-list-item-image">
                        <a href="company-detail.html">
                            
                                <img src="assets/img/tmp/instagram.png" alt="">
                            
                        </a>
                    </div><!-- /.companies-list-item-image -->

                    <div class="companies-list-item-heading">
                        <h2><a href="company-detail.html">Instagram</a></h2>
                        <h3>Chicago, Michigan</h3>
                    </div><!-- /.companies-list-item-heading -->

                    <div class="companies-list-item-count">
                        <a href="positions.html">32 open positions</a>
                    </div><!-- /.positions-list-item-count -->

                </div><!-- /.companies-list-item -->
            
                

                <div class="companies-list-item">
                    <div class="companies-list-item-image">
                        <a href="company-detail.html">
                            
                                <img src="assets/img/tmp/facebook.png" alt="">
                            
                        </a>
                    </div><!-- /.companies-list-item-image -->

                    <div class="companies-list-item-heading">
                        <h2><a href="company-detail.html">Facebook</a></h2>
                        <h3>Philadelphia, Pennsylvania</h3>
                    </div><!-- /.companies-list-item-heading -->

                    <div class="companies-list-item-count">
                        <a href="positions.html">34 open positions</a>
                    </div><!-- /.positions-list-item-count -->

                </div><!-- /.companies-list-item -->
            
                

                <div class="companies-list-item">
                    <div class="companies-list-item-image">
                        <a href="company-detail.html">
                            
                                <img src="assets/img/tmp/twitter.png" alt="">
                            
                        </a>
                    </div><!-- /.companies-list-item-image -->

                    <div class="companies-list-item-heading">
                        <h2><a href="company-detail.html">Twitter</a></h2>
                        <h3>Denver, Colorado</h3>
                    </div><!-- /.companies-list-item-heading -->

                    <div class="companies-list-item-count">
                        <a href="positions.html">4 open positions</a>
                    </div><!-- /.positions-list-item-count -->

                </div><!-- /.companies-list-item -->
            
                

                <div class="companies-list-item">
                    <div class="companies-list-item-image">
                        <a href="company-detail.html">
                            
                                <img src="assets/img/tmp/dropbox.png" alt="">
                            
                        </a>
                    </div><!-- /.companies-list-item-image -->

                    <div class="companies-list-item-heading">
                        <h2><a href="company-detail.html">Dropbox</a></h2>
                        <h3>San Francisco, California</h3>
                    </div><!-- /.companies-list-item-heading -->

                    <div class="companies-list-item-count">
                        <a href="positions.html">4 open positions</a>
                    </div><!-- /.positions-list-item-count -->

                </div><!-- /.companies-list-item -->
            
        </div><!-- /.companies-list -->
    </div><!-- /.col-* -->

    <div class="col-sm-6">
        <h2 class="page-header">Recent Job Offers</h2>

        <div class="positions-list">
            
                

                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">Junior Java Developer</a>
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/instagram.png" alt=""></span> New York City, New York <br></h3>

                    <div class="position-list-item-date">09/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                

                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">PR Manager</a>
                        
                            <span>Urgent</span>
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/facebook.png" alt=""></span> Chicago, Michigan <br></h3>

                    <div class="position-list-item-date">08/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                

                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">Data Mining Specialist</a>
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/twitter.png" alt=""></span> Philadelphia, Pennsylvania <br></h3>

                    <div class="position-list-item-date">07/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                

                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">Python Developer</a>
                        
                            <span>Featured</span>
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/airbnb.png" alt=""></span> Denver, Colorado <br></h3>

                    <div class="position-list-item-date">06/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
                

                <div class="positions-list-item">
                    <h2>
                        <a href="position-detail.html">Senior Data</a>
                        
                            <span>Featured</span>
                        
                    </h2>
                    <h3><span><img src="assets/img/tmp/dropbox.png" alt=""></span> San Francisco, Dropbox <br></h3>

                    <div class="position-list-item-date">05/11/2015</div><!-- /.position-list-item-date -->
                    <div class="position-list-item-action"><a href="#">Save Position</a></div><!-- /.position-list-item-action -->
                </div><!-- /.position-list-item -->
            
        </div><!-- /.positions-list -->
    </div><!-- /.col-* -->
</div><!-- /.row -->


	<div class="page-title">
    <h2>Gallery</h2>

    <div class="row">
        <div class="col-sm-8 col-sm-offset-2">
            <p>
                Donec tincidunt felis quam, eu tempus purus finibus in. Curabitur hendrerit, odio in viverra interdum, lorem velit scelerisque ipsum, a sagittis ligula leo in dolor. Etiam vestibulum.
            </p>
        </div><!-- /.col-* -->
    </div><!-- /.row -->
</div><!-- /.page-title -->

<div class="posts">
    <div class="row">
        <div class="col-sm-12 col-md-6">
            <div class="post-box">
                <div class="post-box-image">
                    <a href="#">
                        <img src="assets/img/tmp/blog-1.jpg" alt="">
                    </a>
                </div><!-- /.post-box-image -->

                <div class="post-box-content">
                    <h2><a href="#">Morbi eu metus ut libero laoreet vulputate</a></h2>

                    <p>
                        Proin a libero eleifend, posuere ipsum id, pulvinar ipsum. Praesent sit amet massa suscipit, ornare mi et, ultrices nisl.  Vivamus venenatis
                    </p>

                    <a href="#" class="post-box-read-more">Read More</a>
                </div><!-- /.post-box-content -->
            </div><!-- /.post-box -->
        </div><!-- /.col-sm-6 -->

        <div class="col-sm-12 col-md-6"> 
            <div class="post-box post-box-small">
                <div class="post-box-image">
                    <a href="#">
                        <img src="assets/img/tmp/blog-2.jpg" alt="">
                    </a>
                </div><!-- /.post-box-image -->

                <div class="post-box-content">
                    <h2><a href="#">Suspendisse a sagittis</a></h2>

                    <p>
                        Sed ut sem elit. Pellentesque vitae erat vehicula quam posuere porta.
                    </p>
                </div><!-- /.post-box-content -->
            </div><!-- /.post-box -->

            <div class="post-box post-box-small">
                <div class="post-box-image">
                    <a href="#">
                        <img src="assets/img/tmp/blog-3.jpg" alt="">
                    </a>
                </div><!-- /.post-box-image -->

                <div class="post-box-content">
                    <h2><a href="#">Morbi eu metus ut libero</a></h2>

                    <p>
                        Pellentesque magna dolor, dapibus vitae lorem in, laoreet sagittis lacus.
                    </p>
                </div><!-- /.post-box-content -->
            </div><!-- /.post-box -->

            <div class="post-box post-box-small">
                <div class="post-box-image">
                    <a href="#">
                        <img src="assets/img/tmp/blog-4.jpg" alt="">
                    </a>
                </div><!-- /.post-box-image -->

                <div class="post-box-content">
                    <h2><a href="#">Pellentesque magna dolor</a></h2>

                    <p>
                        Suspendisse a sagittis tortor, ac dapibus turpis.
                    </p>
                </div><!-- /.post-box-content -->
            </div><!-- /.post-box -->


        </div><!-- /.col-sm-6 -->
    </div><!-- /.row -->
</div><!-- /.posts-->


	
	<div class="block background-secondary fullwidth candidate-title">
    <div class="page-title">
        <h2>Employee of the Month</h2>

        <div class="row">
            <div class="col-sm-8 col-sm-offset-2">
                <p>
                    Donec tincidunt felis quam, eu tempus purus finibus in. Curabitur hendrerit, odio in viverra interdum, lorem velit scelerisque ipsum, a sagittis ligula leo in dolor. Etiam vestibulum.
                </p>
            </div><!-- /.col-* -->
        </div><!-- /.row -->
    </div><!-- /.page-title -->
</div><!-- /.fullwidth -->

<div class="row mt-60">
    

    <div class="candidate-boxes">
        
            

            <div class="col-sm-3 col-md-2">
                <div class="candidate-box">
                    <div class="candidate-box-image">
                        <a href="resume.html">
                            <img src="assets/img/tmp/resume-1.jpg" alt="Peter Ruck">
                        </a>
                    </div><!-- /.candidate-box-image -->

                    <div class="candidate-box-content">
                        <h2>Peter Ruck</h2>
                        <h3>Java Developer</h3>
                    </div><!-- /.candidate-box-content -->
                </div><!-- /.candidate-box -->
            </div><!-- /.col-* -->
        
            

            <div class="col-sm-3 col-md-2">
                <div class="candidate-box">
                    <div class="candidate-box-image">
                        <a href="resume.html">
                            <img src="assets/img/tmp/resume-2.jpg" alt="Linda Young">
                        </a>
                    </div><!-- /.candidate-box-image -->

                    <div class="candidate-box-content">
                        <h2>Linda Young</h2>
                        <h3>PR Manager</h3>
                    </div><!-- /.candidate-box-content -->
                </div><!-- /.candidate-box -->
            </div><!-- /.col-* -->
        
            

            <div class="col-sm-3 col-md-2">
                <div class="candidate-box">
                    <div class="candidate-box-image">
                        <a href="resume.html">
                            <img src="assets/img/tmp/resume-3.jpg" alt="Britney Doe">
                        </a>
                    </div><!-- /.candidate-box-image -->

                    <div class="candidate-box-content">
                        <h2>Britney Doe</h2>
                        <h3>Data Mining</h3>
                    </div><!-- /.candidate-box-content -->
                </div><!-- /.candidate-box -->
            </div><!-- /.col-* -->
        
            

            <div class="col-sm-3 col-md-2">
                <div class="candidate-box">
                    <div class="candidate-box-image">
                        <a href="resume.html">
                            <img src="assets/img/tmp/resume-4.jpg" alt="Andrew Man">
                        </a>
                    </div><!-- /.candidate-box-image -->

                    <div class="candidate-box-content">
                        <h2>Andrew Man</h2>
                        <h3>Python Developer</h3>
                    </div><!-- /.candidate-box-content -->
                </div><!-- /.candidate-box -->
            </div><!-- /.col-* -->
        
            

            <div class="col-sm-3 col-md-2">
                <div class="candidate-box">
                    <div class="candidate-box-image">
                        <a href="resume.html">
                            <img src="assets/img/tmp/resume.jpg" alt="Elliot Sarah Scott">
                        </a>
                    </div><!-- /.candidate-box-image -->

                    <div class="candidate-box-content">
                        <h2>Elliot Sarah Scott</h2>
                        <h3>Data Analytist</h3>
                    </div><!-- /.candidate-box-content -->
                </div><!-- /.candidate-box -->
            </div><!-- /.col-* -->
        
            

            <div class="col-sm-3 col-md-2">
                <div class="candidate-box">
                    <div class="candidate-box-image">
                        <a href="resume.html">
                            <img src="assets/img/tmp/resume-1.jpg" alt="Peter Ruck">
                        </a>
                    </div><!-- /.candidate-box-image -->

                    <div class="candidate-box-content">
                        <h2>Peter Ruck</h2>
                        <h3>Java Developer</h3>
                    </div><!-- /.candidate-box-content -->
                </div><!-- /.candidate-box -->
            </div><!-- /.col-* -->
        
    </div><!-- /.candidate-boxes -->
</div><!-- /.row -->

	

</div><!-- /.container -->

      </div><!-- /.main -->
    </div><!-- /.main-wrapper -->

<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>