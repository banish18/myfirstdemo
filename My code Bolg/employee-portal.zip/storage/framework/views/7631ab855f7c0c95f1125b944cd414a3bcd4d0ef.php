<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
 <div class="row">
 <div class="col-md-9">
	<div class="page-title">
	<h1>Add Appointment Letter</h1></div>   
   </div>
   <div class="col-md-3"><a href="<?php echo e(asset('images/users/letters/new_appointment.docx')); ?>">Get Appointment Letter</a></div>
   </div>
 <div class="row">
 <div class="col-md-2">
  	<ul class="list-group">
<li class="list-group-item active" >
<a href="<?php echo e(route('employement')); ?>">
<p>
<img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
&nbsp;Lists
</p></a>
</li>
<li class="list-group-item">
           <a  href="<?php echo e(route('employement',array('action' => 'add-appointment'))); ?>">
           <p>
           <img src="<?php echo e(asset('admin-asset/images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add new Employee Letters
           </p></a>
           </li> 
<li class="list-group-item">
           <a  href="<?php echo e(route('employement',array('action' => 'upload-letters'))); ?>">
           <p>
           <img src="<?php echo e(asset('admin-asset/images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Upload Previous Employee Letters
           </p></a>
           </li> 		   
</ul>
        </div>
 <div class="col-md-10">
 <div class="widget-container fluid-height clearfix">
 <div class="widget-content padded">
 <form method="post" class="form-horizontal" action="<?php echo e(route('employement',array('action' => 'postAppointment'))); ?>" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

 <div class="row">
 <div class="col-md-12">
 <div class="col-md-8">

 <div class="form-group">
            <label class="control-label col-md-4">Employee</label>
            <div class="col-md-8">
              <select name="employee" class="form-control">
				<option value="0">Please Select</option>
				<?php if($data["users"]): ?>
					<?php $__currentLoopData = $data["users"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	
			  </select>
            </div>
          </div>
		 <div class="form-group">
            <label class="control-label col-md-4">Upload Letter</label>
            <div class="col-md-8">
              <input type="file" class="form-control" />
            </div>
          </div> 
</div></div>

    <div class="row">
     <div class="col-md-12">
   <div class="col-md-6">
    <button class="btn btn-lg btn-block btn-success" type="submit" name="submit_department"> Submit</button>
   </div>
  <div class="col-md-6">
  <button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
  </div></div></div>
 </form>
 </div>
 </div>
 </div>
 </div></div>


		
<?php echo $__env->make("templates/admin-footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</script>
<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>