<?php $__env->startSection('content'); ?>
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Address Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Address Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			<?php echo $__env->make("employee_self_services/employeeperks/sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
		 <div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
            <table class="table-bordered">
              <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Associate Details</span></div>
              <tr>
                <th>Role</th>
                <td>Developer</td>
                <th>Home Country</th>
                <td>INDIA</td>
                <th>Current Country</th>
                <td>INDIA</td>
              </tr>
              <tr>
                <th>Employment Status</th>
                <td>Active Assignment</td>
                <th>Base Branch</th>
                <td>TCS - New Delhi</td>
                <th>Current Branch</th>
                <td>TCS - New Delhi</td>
              </tr>
			  <tr>
                <th>Employee Type</th>
                <td>Employee</td>
                <th>Base DC</th>
                <td>New Delhi - Non STP</td>
                <th>Current DC</th>
                <td>Chandigarh - Non STP</td>
              </tr>
            </table>
          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <table class="table-bordered">
              <tr>
                <th>Date of Birth</th>
                <td>Oct-10-1985</td>
                <th>Age</th>
                <td>31Years</td>
              </tr>
              
              <tr>
                <th>DOJ with TCS</th>
                <td>Mar-16-2011</td>
                <th>Service in TCS</th>
                <td>5.87Years</td>
              </tr>
            </table>
          </div>
        </div>
        <!-- /.col-* --> 
        
      <div class="col-sm-12">
	   

    </div>
        <!-- /.col-* --> 
	  
	</div>
      <!-- /.row -->   
	  
	
	<div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
		  <div style="margin-top:35px;"><span style="text-decoration: underline;color:#3333FF;font-size:12px;">Warning</span>
		<span style="color:#41A317;font-size:12px;font-family:Arial;font-weight:bold; margin-left:15px;">To raise a request, please add dependents or edit Dependent Flag to "Yes" in Ultimatix > GESS > My Profile > My Contacts</span></div>
		 <div style="margin-top:15px;"><span class="BodyFont" style="font-weight:900;color:red">* </span>
		   <span class="BodyFont" style="color: #727272">All the fields are mandatory and all amounts are in INR. </span></div>
		   <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Student and Course Details</span></div>
           <table class="table-bordered">
<tbody>
<tr>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold">Relation with Member</span>
</td>
<td>
<select class="textBoxStyle" name="applyHigherEdu:_idJsp213" size="1" style="width:180px" onchange="submit(this);">
<option value="--Select--">--Select Applicant--</option>
</select>
</td>
<td></td>
<td></td>
</tr>
<tr>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold">Name of student</span>
</td>
<td>
<input id="applyHigherEdu:_idJsp220" class="textBoxStyle" name="applyHigherEdu:_idJsp220" value="" style="font-weight: normal;width:180px" disabled="disabled" type="text">
</td>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold">Date of Birth (Age)</span>
</td>
<td>
<input id="applyHigherEdu:_idJsp224" class="textBoxStyle" name="applyHigherEdu:_idJsp224" value="" style="font-weight: normal;width:180px" disabled="disabled" type="text">
</td>
</tr>
<tr>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold">Name of the course </span>
</td>
<td>
<input id="applyHigherEdu:_idJsp230" class="textBoxStyle" name="applyHigherEdu:_idJsp230" value="" maxlength="200" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkAddress(this,event);" style="width:180px" type="text">
</td>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold">Discipline</span>
</td>
<td>
<input id="applyHigherEdu:_idJsp234" class="textBoxStyle" name="applyHigherEdu:_idJsp234" value="" maxlength="200" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkAddress(this,event);" style="width:180px" type="text">
</td>
</tr>
<tr>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold">Name of Educational Institute</span>
</td>
<td>
<input id="applyHigherEdu:instituteName" class="textBoxStyle" name="applyHigherEdu:instituteName" value="" maxlength="200" autocomplete="off"  style="width:180px" type="text">
<br>
<a id="applyHigherEdu:_idJsp241" href="#"  style="font-size:12px;font-weight:bold;"><< InstituteNameList</a>
<input name="autoScroll" type="hidden">
</td>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold">Duration of Course</span>
</td>
<td>
<input id="applyHigherEdu:_idJsp245" class="textBoxStyle" name="applyHigherEdu:_idJsp245" value="" maxlength="200" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkAddress(this,event);" style="width:180px" type="text">
</td>
</tr>
<tr>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold">Institute Address</span>
</td>
<td>
<input id="applyHigherEdu:_idJsp249" class="textBoxStyle" name="applyHigherEdu:_idJsp249" value="" maxlength="200" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkAddress(this,event);" style="width:180px" type="text">

</td>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold">Country</span>
</td>
<td>
<input id="applyHigherEdu:_idJsp253" class="textBoxStyle" name="applyHigherEdu:_idJsp253" value="" maxlength="100" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkAddress(this,event);" style="width:180px" type="text">
</td>
</tr>
<tr>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold">Graduated from - Institute</span>
</td>
<td>
<input id="applyHigherEdu:_idJsp257" class="textBoxStyle" name="applyHigherEdu:_idJsp257" value="" maxlength="200" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkAddress(this,event);" style="width:180px" type="text">
</td>
<tr>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold;">Student's performance details(%)</span>
</td>
<td>
<span style="width:180px">
<table cellspacing="0" cellpadding="0" border="1">
<tbody>
<tr>
<td>
<span style="width:58px;text-align:center">
<span class="BodyFont" style="color: #000000;font-weight:bold;height:12pt;">SSC/ICSE</span>
</span>
</td>
<td>
<span style="width:51px;text-align:center">
<span class="BodyFont" style="color: #000000;font-weight:bold;height:12pt;">HSC</span>
</span>
</td>
<td>
<span style="width:65px;text-align:center">
<span class="BodyFont" style="color: #000000;font-weight:bold;height:12pt;">Graduation</span>
</span>
</td>
</tr>
<tr>
<td>

<input id="applyHigherEdu:_idJsp271" class="textBoxStyle" name="applyHigherEdu:_idJsp271" value="" maxlength="5" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkFloatOnly(this,event);" style="width:58px;height:12pt;text-align:center" onblur="return validateMarks(this);" type="text">

</td>
<td>

<input id="applyHigherEdu:_idJsp273" class="textBoxStyle" name="applyHigherEdu:_idJsp273" value="" maxlength="5" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkFloatOnly(this,event);" style="width:51px;height:12pt;text-align:center" onblur="return validateMarks(this);" type="text">

</td>
<td>
<input id="applyHigherEdu:_idJsp275" class="textBoxStyle" name="applyHigherEdu:_idJsp275" value="" maxlength="5" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkFloatOnly(this,event);" style="width:65px;height:12pt;text-align:center" onblur="return validateMarks(this);" type="text">
</td>
</tr>
</tbody>
</table>
</span>
</td>
<td></td>
<td></td>
</tr>
</tbody>
			</table>
          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
	  
	  
	  <div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
           <table class="table-bordered">
		    <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Expense Details</span></div>
<tbody>
<tr>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold;height:15pt;">Course Expense</span>
</td>
<td>
<input id="applyHigherEdu:courseExpense" class="textBoxStyle" name="applyHigherEdu:courseExpense" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="width:180px" onblur="return checkNum(this);" type="text">
</td>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold;height:15pt;">Tuition Fees Expense</span>
</td>
<td>
<input id="applyHigherEdu:tutionFees" class="textBoxStyle" name="applyHigherEdu:tutionFees" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="width:180px" onblur="return checkNum(this);" type="text">
</td>
</tr>
<tr>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold;height:15pt;">Travel Expense</span>
</td>
<td>
<input id="applyHigherEdu:travelExpense" class="textBoxStyle" name="applyHigherEdu:travelExpense" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="width:180px" onblur="return checkNum(this);" type="text">
</td>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold;height:15pt;">Rent Expense</span>
</td>
<td>
<input id="applyHigherEdu:rentExpense" class="textBoxStyle" name="applyHigherEdu:rentExpense" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="width:180px" onblur="return checkNum(this);" type="text">
</td>
</tr>
<tr>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold;height:15pt;">Books Expense</span>
</td>
<td>
<input id="applyHigherEdu:booksExpense" class="textBoxStyle" name="applyHigherEdu:booksExpense" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="width:180px" onblur="return checkNum(this);" type="text">
</td>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold;height:15pt;">Amount received from other sources</span>
</td>
<td>
<input id="applyHigherEdu:Other_Source_Amount" class="textBoxStyle" name="applyHigherEdu:Other_Source_Amount" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="width:180px" onblur="return checkNum(this);" type="text">
</td>
</tr>
<tr>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold;">Assistance from other sources (Scholarship / Grant / Other)</span>
</td>
<td>
<textarea id="applyHigherEdu:Other_Sources" class="textBoxStyle" name="applyHigherEdu:Other_Sources" onkeypress="if(event.keyCode!=9) return chkAddress(this,event) && commentsLength();" onkeyup="LimtCharacters(this,100,'lblcount');" style="width:180px;height:30pt;margin: 5px 0px -8px 0px;"></textarea>
<br/><br/>
<label id="lblcount" style="font-weight:bold;font-size: 11;color: rgb(104, 103, 103);">100</label>
<label style="font-size: 11;color: rgb(104, 103, 103);">Characters Left</label>
</td>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold;height:15pt;">Loan Availed (if any)</span>
</td>
<td>
<input id="applyHigherEdu:Loan_Availed" class="textBoxStyle" name="applyHigherEdu:Loan_Availed" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="width:180px" onblur="return checkNum(this);" type="text">
</td>
</tr>
<tr>
<td>
<span class="BodyFont" style="color: #000000;font-weight:bold;height:15pt;">Amount requested from Trust</span>
</td>
<td>
<input id="applyHigherEdu:Amount_Requested" class="textBoxStyle" name="applyHigherEdu:Amount_Requested" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="width:180px" onblur="return checkNum(this);" type="text">
</td>
<td></td>
<td></td>
</tr>
</tbody>		
			</table>
          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
	  
	  
	  
	  	  <div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
		   <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Supporting Documents Required</span></div>

		  
			<div class="col-sm-12" style="border:1px solid #CCC; padding:10px;">
			

				<div class="BodyFont">Kindly note, you are required to submit the following documents.</div>

				<div class="BodyFont">1. Copy of SSC,HSE and Graduation marksheet.</div>


				<div class="BodyFont">2. I-20, admission letter etc.</div>


				<div class="BodyFont">3. Travel ticket & boarding pass.</div>


				<div class="BodyFont">4. Payment Receipts from University and Break up of fees.</div>


				<div class="BodyFont">5. Rent agreement and rent receipt.</div>
				
				<div class="BodyFont">6. Books receipts.</div>
				
				<div class="BodyFont">7. Bank statement to verify the debit entry for the amount paid to university.</div>
				
				<div class="BodyFont">8. Copy of Student Icard </div>
				
				</div>

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
		
		<div class="col-lg-12" style="padding:8px; background-color:#E8F2FE; border-top:1px solid #006;">
<div class="col-lg-2" style=" margin-left:20px;">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Continue" type="submit">
</div>
<div class="col-lg-2">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Cancel" type="submit">
</div>
<div class="col-lg-2">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Save as Draft" type="submit">
</div>
</div>
		
      </div>
      <!-- /.container -->
		   </div><!-- /.col-* -->
		</div><!-- /.row -->
	</div><!-- /.container -->
		 
	  
    </div>
  </div>
  <!-- /.main --> 

<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>