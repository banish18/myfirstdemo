<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
<div class="page-title">
<div class="row">
<div class="col-md-12">
<h1>Add Reporting</h1></div></div>
</div>
<div class="row">
<div class="col-md-2">
<ul class="list-group">
			<li class="list-group-item active" >
			<a href="<?php echo e(route('users')); ?>">
           <p>
            <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;List Employees
           </p></a>
           </li>

           <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'add'))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add Employee
           </p>
           </a>
           </li>
		   
		    <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'reporting'))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Employee Reporting
           </p>
           </a>
           </li>
           
            </ul>
</div>

<div class="col-md-10">
<div class="widget-container fluid-height clearfix">
<div class="widget-content padded">
<form method="post" class="form-horizontal" action="<?php echo e(route('users',array('action' => 'postaddReporting'))); ?>" enctype="multipart/form-data">

 <?php echo e(csrf_field()); ?>


<div class="row">
<div class="col-md-12">
<div class="col-md-9">
<div class="heading"><h2>Employee Reporting Details</h2></div><br>
<div class="form-group">
            <label class="control-label col-md-3">Select Employee</label>
            <div class="col-md-7">
			<?php echo e(csrf_field()); ?>

               <select data-placeholder="Select Employee" style="width:350px;" class="chosen-select form-control" tabindex="7" name="user" > 
				<option value="">Please Select User To Add Credential</option>
				 <?php if($data["users"]): ?>
					 <?php $__currentLoopData = $data["users"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($user->id); ?>"><?php echo e($user->name.'('.$user->uuid.')'); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	 
			  </select>
			  <?php if($errors->has('user')): ?>
					<span class="help-block">
						<strong><?php echo e($errors->first('user')); ?></strong>
					</span>
				<?php endif; ?>
            </div>
			<span style="color:#d43f3a">
mandatory
</span>
          </div>
<div class="form-group">
<label class="control-label col-md-3">Reporting Manager</label>
<div class="col-md-7">
  <select data-placeholder="Select Employee" style="width:350px;" class="chosen-select form-control" tabindex="7" name="reporting_manager" > 
				<option value="">Please Select User To Add Credential</option>
				 <?php if($data["users"]): ?>
					 <?php $__currentLoopData = $data["users"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($user->id); ?>"><?php echo e($user->name.'('.$user->uuid.')'); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	 
			  </select>
 <?php if($errors->has('reporting_manager')): ?>
					<span class="help-block">
						<strong><?php echo e($errors->first('reporting_manager')); ?></strong>
					</span>
				<?php endif; ?>
</div>

<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="form-group">
<label class="control-label col-md-3">HR Manager</label>
<div class="col-md-7">
  <select data-placeholder="Select Employee" style="width:350px;" class="chosen-select form-control" tabindex="7" name="hr_manager" > 
				<option value="">Please Select User To Add Credential</option>
				 <?php if($data["users"]): ?>
					 <?php $__currentLoopData = $data["users"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($user->id); ?>"><?php echo e($user->name.'('.$user->uuid.')'); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	 
			  </select>
 <?php if($errors->has('hr_manager ')): ?>
					<span class="help-block">
						<strong><?php echo e($errors->first('hr_manager ')); ?></strong>
					</span>
				<?php endif; ?>
</div>

<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="form-group">
<label class="control-label col-md-3">Finance Manager</label>
<div class="col-md-7">
 <select data-placeholder="Select Employee" style="width:350px;" class="chosen-select form-control" tabindex="7" name="finance_manager" > 
				<option value="">Please Select User To Add Credential</option>
				 <?php if($data["users"]): ?>
					 <?php $__currentLoopData = $data["users"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($user->id); ?>"><?php echo e($user->name.'('.$user->uuid.')'); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	 
			  </select>
 <?php if($errors->has('finance_manager ')): ?>
					<span class="help-block">
						<strong><?php echo e($errors->first('finance_manager ')); ?></strong>
					</span>
				<?php endif; ?>
</div>

<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="form-group">
<label class="control-label col-md-3">Admin Manager</label>
<div class="col-md-7">
<select data-placeholder="Select Employee" style="width:350px;" class="chosen-select form-control" tabindex="7" name="admin_manager"> 
				<option value="">Please Select User To Add Credential</option>
				 <?php if($data["users"]): ?>
					 <?php $__currentLoopData = $data["users"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($user->id); ?>"><?php echo e($user->name.'('.$user->uuid.')'); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	 
			  </select>
 <?php if($errors->has('admin_manager ')): ?>
					<span class="help-block">
						<strong><?php echo e($errors->first('admin_manager ')); ?></strong>
					</span>
				<?php endif; ?>
</div>

<span style="color:#d43f3a">
mandatory
</span> </div>


<div class="form-group">
<div class="col-md-12">
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-success" type="submit" name="submit_employee"> Submit</button>
</div>
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
</div>
</div></div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>

<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>
<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>