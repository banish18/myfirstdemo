<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
        <div class="page-title">
          <h1>
            All Companies
          </h1>
		 
                   </div>



        <div class="row">
        <div class="col-md-2">
		
  <ul class="list-group">
          <li class="list-group-item active" >
           <a  href="<?php echo e(route('company')); ?>">
           <p>
           <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;List
           </p></a>
           </li>                <li class="list-group-item " >
           <a  href="<?php echo e(route('company',array('action' => 'add'))); ?>">
           <p>
          <img src="<?php echo e(asset('admin-asset/images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add
           </p></a>
           </li>
                    </ul>
        </div>
        <div class="col-md-10">
		 
		  
             <div class="row">
            <div class="col-md-12">
			<ol class="breadcrumbs">
                <li><a href="<?php echo e(route('master',array('action' => 'master'))); ?>">Master</a></li><span>></span>
                <li class="active">Comapany</li>
              </ol>
            <div class="widget-container fluid-height clearfix">
            <div class="widget-content padded clearfix">
<div class="table-responsive">
                  <table class="table table-striped" id="dataTable11">
                                      <thead>
                    <tr role="row">
					   <th> S.NO</th>
                       <th>Company Name</th>
                       <th>Company Logo</th>
					    <th>Company Email</th>
                       <th style="width: 150px;"> Actions</th>
                  </tr>
                    </thead>
                                        <tbody>
						<?php if($data['companies']): ?>
							<?php $i = 0; ?>
							<?php $__currentLoopData = $data['companies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
							<?php $i++;
							
							
							
							?>
                                            <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($company->name); ?></td>
						
                       <td><img style="width:150px;height:150px;" src="<?php echo e(asset('images/users/company/'.$company->logo)); ?>" /></td>
					   <td> <?php if(is_array(json_decode($company->email))): ?>
								<?php $__currentLoopData = json_decode($company->email); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php echo e($email); ?> <br />
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
							<?php endif; ?>	
							
							</td>
                       
                         <td>
                        
                          <a class="tooltip-trigger" href="<?php echo e(route('company',array('action' => 'edit','id' => $company->id ))); ?>"
                          data-placement="top" title="Edit">
							<i class="lnr lnr-pencil" style="color:blue;"></i>
                          </a>
                            
                           <a class="fancybox delid tooltip-trigger" href="<?php echo e(route('company',array('action' => 'delete','id' => $company->id ))); ?>"
                           data-placement="top" title="Delete" >
                           <i class="lnr lnr-trash" style="color:grey;"></i>
                     </a>
                                                    <input type="hidden" name="id" value="<?php echo e($company->id); ?>">
                                                
                        </td>
                         </tr>
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						 <?php endif; ?>
                      
                    </tbody>
                  </table></div>

            </div>
          </div></div>
          </div>
          </div></div></div>


<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="row" style="text-align:center;"><span>V3.0</span></div>
  </body></html>
  <script>
$(document).ready(function(){
	$(".pdf").click(function(){
		$("#table1").hide();
		setTimeout(function(){$("#table1").show()},1000);
		});
});
</script>
 

<script>
$(".tooltip-trigger").tooltip();
 </script>
     <script>
     /*   for mobile navigation */
     $('.navbar-toggle').click(function() {
         return $('body, html').toggleClass("nav-open");
       });

     /*
      * =============================================================================
      *   DataTables
      * =============================================================================
      */
     $("#dataTable11").dataTable({
       "sPaginationType": "full_numbers",
       aoColumnDefs: [
         {
           bSortable: false,
           aTargets: [0, -1]
         }
       ]
     });
	 </script>
  

    
<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>