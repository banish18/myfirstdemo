<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
	<div class="page-title">
			<h1>Employee Credentials</h1>
			<ol class="breadcrumbs">
                <li><a href="<?php echo e(route('master',array('action' => 'master'))); ?>">Master</a></li><span>></span>
                <li class="active">Employee Credential</li>
              </ol>
                </div>

	<div class="row">
	 <div class="col-md-2">
<ul class="list-group">
<li class="list-group-item active" >
<a href="<?php echo e(route('users',array('action' => 'employee-credential'))); ?>">
<p>
<img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
&nbsp;Credentials
</p></a>
</li>
<li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'add-credential'))); ?>">
           <p>
           <img src="<?php echo e(asset('admin-asset/images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add
           </p></a>
           </li>        
</ul>
</div>
		<div class="col-md-10">
		
			<div class="widget-container fluid-height clearfix">
				<div class="widget-content padded clearfix">
				<div class="table-responsive">
				<div class="form-group">
            <label class="control-label col-md-4">Select Employee</label>
            <div class="col-md-8">
			<?php echo e(csrf_field()); ?>

               <select data-placeholder="Your Favorite Type of Bear" style="width:350px;" class="chosen-select form-control" tabindex="7" onchange="getCredentials(this)">
				<option value="">Please Select User To view Letters</option>
				 <?php if($data["users"]): ?>
					 <?php $__currentLoopData = $data["users"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($user->id); ?>"><?php echo e($user->name.'('.$user->uuid.')'); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	 
			  </select>
            </div>
          </div>
				<?php if(isset($data["credentials"]) && !$data["credentials"]->isEmpty()): ?>
					<table class="table table-striped" id="dataTable3">
                    <thead>
                    <tr role="row">
                    <th class="check-header">

                    </th>
					   <th> S.NO</th>
                       <th>	Employee Name </th>
                       <th> Credential Type </th>
					   <th> Username/Email </th>
					   <th> Password </th>
                       <th>	Actions</th>
                     </tr>
                    </thead>

                    <tbody>
					
						<?php $i = 0; ?>
						<?php $__currentLoopData = $data["credentials"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credential): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $i++; ?>
							<tr>
                        <td class="check">
                         
                        </td>
						<td> <?php echo e($i); ?> </td>
                        <td ><?php echo e($credential->uid); ?></td>
                        <td > <?php echo e($credential->credential_type); ?> </td>
						<td > <?php echo e($credential->username); ?> </td>
						<td > <?php echo e($credential->password); ?> </td>
                 <td class="action" >

             <div class="btn-group">
                      <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i>Options<span class="caret"></span>
                      </button>
                      <ul class="dropdown-menu">
							<li>    <a class="table-actions" href="<?php echo e(route('users',array('action' => 'edit-credential','id' => $credential->id ))); ?>">Edit</a>
							</li>             
                                                     <li>    <a class="table-actions" href="<?php echo e(route('users',array('action' => 'delete-credential','id' => $credential->id ))); ?>">Delete</a></li>
													 
                                          
                          		                                          </ul>
</div>
                          </td>
                                               </tr> 
						
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                    </tbody>
                  </table>
				<?php else: ?>
						<h3>No Records</h3>
                     <?php endif; ?> 
				</div>
				</div>
			</div>
		</div>

		<!-- end DataTables Example -->

	</div>
</div>
<!-- ------------modal for fancybox -->
 <div class="row">
              <div class="col-lg-12">
                <div class="widget-container fluid-height">


                </div>
                <div id="fancybox-example" style="display: none;" class="hide_fancybox">
                  <h2>
                    Noticeboard
                  </h2>
                  <p>
                  <form method="POST" action="https://shiftsystems.net/demo/index.php?user=view_noticeboard">
                    Are You Sure ! You want to delete.
			<input type="hidden" name="notice_id" class="confirmdelete">
			<button type="submit" class="btn btn-success btn-xs" aria-hidden="true" name="deletenotice">
			Yes</button>
			<button type="button" class="btn btn-danger btn-xs fancy-close" onclick="$.fancybox.close()">
			No</button>
                </form>
                </p>
                </div>

              </div>
            </div>
            <!-- --------------------------end---------- -->

		
<?php echo $__env->make("templates/admin-footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>
    <script>
$(document).ready(function() {
    $('#dataTable3').DataTable( {
        dom: 'Blfrtip',

        buttons: [
                  {
                      extend: 'copyHtml5',
                      exportOptions: {
                    	  columns: [ 0,1,2, 3, 4]
                      }
                  },
                  {
                      extend: 'excelHtml5',
                      exportOptions: {
                    	  columns: [ 0,1,2, 3, 4]
                      }
                  },
                  {
                      extend: 'csvHtml5',
                      exportOptions: {
                    	  columns: [ 0,1,2, 3, 4]
                      }
                  },
                  {
                      extend: 'pdfHtml5',
                      exportOptions: {
                          columns: [0,1,2, 3, 4]
                      }
                  },
                  'colvis'
              ]
          } );
      } );
</script>
    <script>
$('.delid').click(function(){
	var delid=$(this).attr('data-id');
    $('.confirmdelete').val(delid)

});

$('.fancy-close').click(function(){
$('.hide_fancybox').close();
});
    </script>
  <div class="row" style="text-align:center;"><span>V3.0</span></div>
  </body></html>
  <script>
$(document).ready(function(){
	$(".pdf").click(function(){
		$("#table1").hide();
		setTimeout(function(){$("#table1").show()},1000);
		});
});
</script>

<script>
$(".tooltip-trigger").tooltip();
 </script>
     <script>
     /*   for mobile navigation */
     $('.navbar-toggle').click(function() {
         return $('body, html').toggleClass("nav-open");
       });

     /*
      * =============================================================================
      *   DataTables
      * =============================================================================
      */
     $("#dataTable1").dataTable({
       "sPaginationType": "full_numbers",
       aoColumnDefs: [
         {
           bSortable: false,
           aTargets: [0, -1]
         }
       ]
     });
     $('.table').each(function() {
       return $(".table #checkAll").click(function() {
         if ($(".table #checkAll").is(":checked")) {
           return $(".table input[type=checkbox]").each(function() {
             return $(this).prop("checked", true);
           });
         } else {
           return $(".table input[type=checkbox]").each(function() {
             return $(this).prop("checked", false);
           });
         }
       });
     });


     /*
      * =============================================================================
      *   Bootstrap Popover
      * =============================================================================
      */

     $(".popover-trigger").popover();
	
	 function getCredentials(elm){
		var siteurl 	= "http://portal.mindxpert.com/";
		var user 		= $(elm).val();
		window.location.assign(siteurl+'/users/get-credential?user='+user);
	}

</script>
<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>