<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
  <div class="page-title">
    <div class="row">
      <div class="col-md-12">
        <h1>New Employee</h1>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-2">
      <ul class="list-group">
        <li class="list-group-item active" ><a href="<?php echo e(route('users')); ?>">
          <p><img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">&nbsp;List Employees</p>
          </a></li>
        <li class="list-group-item"><a href="<?php echo e(route('users',array('action' => 'add'))); ?>">
          <p><img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">&nbsp;Add Employee</p>
          </a></li>
      </ul>
    </div>
    <div class="col-md-10">
      <div class="widget-container fluid-height clearfix">
        <div class="widget-content padded">
          <form method="post" class="form-horizontal" action="<?php echo e(route('users',array('action' => 'postUpdate'))); ?>" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="profile" id="profilesize" >
            <input type="hidden" name="qu_1" id="qualification_1" >
            <input type="hidden" name="qu_2" id="qualification_2" >
            <input type="hidden" name="qu_3" id="qualification_3" >
            <input type="hidden" name="qu_4" id="qualification_4" >
            <input type="hidden" name="qu_5" id="qualification_5" >
            <input type="hidden" name="addressproof_size" id="add_proof_size" >
            <input type="hidden" name="idproof_size" id="id_proof_size" >
            <input type="hidden" name="id" id="id" value="<?php echo e($data['user']->id); ?>" >
            <div class="row">
              <div class="col-md-12">
                <div class="col-md-6">
                  <div class="heading">
                    <h2>Employee Details</h2>
                  </div>
                  <br>
                  <div class="form-group">
                    <label class="control-label col-md-3">First Name</label>
                    <div class="col-md-6">
                      <input class="form-control" name="e_name" type="text" value="<?php echo e($data['user']->f_name); ?>" required>
                    </div>
                    <span style="color:#d43f3a">mandatory</span> </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Last Name</label>
                    <div class="col-md-6">
                      <input class="form-control" name="e_surname" type="text" value="<?php echo e($data['user']->l_name); ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Date Of Birth</label>
                    <div class="col-md-6">
                      <div class="input-group date datepicker">
                        <input class="form-control birth" id="dob" type="text" name="e_dob" value="<?php echo e($data['user']->dob); ?>" required>
                        <span class="input-group-addon"><img src="<?php echo e(asset('admin-asset/images/date.svg')); ?>" width="15"></span></div>
                    </div>
                    <span style="color:#d43f3a">mandatory</span> </div>
                  <div id="full_add">
                    <div class="form-group">
                      <label class="control-label col-md-3">House Number</label>
                      <div class="col-md-6">
                        <input class="form-control allownumericwithoutdecimal" id="houseno" name="house_no" type="text" value="<?php echo e($data['user']->houseno); ?>">
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-md-3">Street Number 1</label>
                      <div class="col-md-6">
                        <input class="form-control" id="street_1" name="address_street_no1" type="text" value="<?php echo e($data['user']->address_street_no1); ?>">
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-md-3">Countries</label>
                      <div class="col-md-6">
                        <select class="form-control co" id="coun" name="country" >
                          <option value="0" label="Select a country ... " selected="selected">Select a country ... </option>
                          <option value="India" >India</option>
                          <option value="Indonesia" >Indonesia</option>
                          <option value="Iran" >Iran</option>
                          <option value="Iraq" >Iraq</option>
                          <option value="Ireland" >Ireland</option>
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-md-3">Postal Code</label>
                      <div class="col-md-6">
                        <input class="form-control" id="postal" name="postal_code" type="text" maxlength="6" value="<?php echo e($data['user']->postal_code); ?>">
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-md-3">Full Address</label>
                      <div class="col-md-6">
                        <textarea class="form-control" id="fullad" name="e_address" readonly="true"><?php echo e($data['user']->address); ?></textarea>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Contact No.</label>
                    <div class="col-md-6">
                      <input class="form-control" id="con_no" name="e_contact1" maxlength="12" type="text" value="<?php echo e($data['user']->e_contact1); ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Mobile No.</label>
                    <div class="col-md-6">
                      <input class="form-control" id="mob_no" name="e_contact2" type="text" maxlength="12" value="<?php echo e($data['user']->phone_number); ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Photograph</label>
                    <div class="col-md-5">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <input type="hidden" value="" name="">
                        <div class="fileupload-new img-thumbnail" style="width: 150px; height: 100px;"><img src="<?php echo e(asset('images/users/'.$data['user']->image)); ?>"></div>
                        <div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px;"></div>
                        <div><span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span>
                          <input type="file" name="emp_photo" id="profile_pic">
                          </span><a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a><br>
						  <input type="hidden" name="preimage" value="<?php echo e($data['user']->image); ?>" />
                          <small>Only jpg ,png & jpeg (Max : 64M)</small></div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Email</label>
                    <div class="col-md-6">
                      <input class="form-control" name="e_email" type="text" value="<?php echo e($data['user']->email); ?>" required>
                    </div>
                    <span style="color:#d43f3a">mandatory</span> </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Age(from date of birth)</label>
                    <div class="col-md-6">
                      <input class="form-control" id="age" name="age" type="text" value="<?php echo e($data['user']->dob); ?>" readonly="true">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Employment type</label>
                    <?php 	if($data['user']->emp_type == "part time"){		$selected = "checked=checked";	}elseif($data['user']->emp_type == "full time"){		$selected = "checked=checked";	}else{		$selected = '';	}?>
                    <div class="col-md-6">
                      <label class="radio-inline">
                        <input name="emp_type" type="radio" value="part time" <?php echo e($selected); ?> required>
                        <span>Part Time</span></label>
                      <label class="radio-inline">
                        <input name="emp_type" type="radio" value="full time" <?php echo e($selected); ?> required>
                        <span>Full Time</span></label>
                    </div>
                    <span style="color:#d43f3a">mandatory</span> </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Working hours</label>
                    <div class="col-md-6">
                      <?php 	if($data['user']->working_hours == "office business hours"){		$selected = "checked=checked";	}elseif($data['user']->working_hours == "shift hours"){		$selected = "checked=checked";	}else{		$selected = '';	}?>
                      <label class="radio-inline">
                        <input name="working_hours" type="radio" value="office business hours" <?php echo e($selected); ?> required>
                        <span>Office business hours</span></label>
                      <label class="radio-inline">
                        <input name="working_hours" type="radio" value="shift hours" <?php echo e($selected); ?> required>
                        <span>Shift hours</span></label>
                    </div>
                    <span style="color:#d43f3a">mandatory</span> </div>
                  <div class="form-group">
                    <?php	$working_weeks = json_decode($data['user']->working_weeks);
					if(!empty($working_weeks)){
						foreach($working_weeks as $working_week){
							if($working_week == "mon" || $working_week == "tue" || $working_week == "wed" || $working_week == "thu" || $working_week == "fri" || $working_week == "sat" || $working_week == "sun"){
								$selected = "checked=checked";
								}else{
									$selected = "";
								}
							}
					}else{
						$selected = "";
					}
					?>
                    <label class="control-label col-md-3">Working days per week</label>
                    <div class="col-md-6">
                      <div class="col-md-3">
                        <label class="checkbox">
                          <input type="checkbox" value="mon" name="working_weeks[mon]" <?php echo e($selected); ?>>
                          <span>Mon</span></label>
                      </div>
                      <div class="col-md-3">
                        <label class="checkbox">
                          <input type="checkbox" value="tue" name="working_weeks[tue]" <?php echo e($selected); ?>>
                          <span>Tues</span></label>
                      </div>
                      <div class="col-md-3">
                        <label class="checkbox">
                          <input type="checkbox" value="wed" name="working_weeks[wed]" <?php echo e($selected); ?>>
                          <span>Wed</span></label>
                      </div>
                      <div class="col-md-3">
                        <label class="checkbox">
                          <input type="checkbox" value="thu" name="working_weeks[thu]" <?php echo e($selected); ?>>
                          <span>Thurs</span></label>
                      </div>
                      <div class="col-md-3">
                        <label class="checkbox">
                          <input type="checkbox" value="fri" name="working_weeks[fri]" <?php echo e($selected); ?>>
                          <span>Fri</span></label>
                      </div>
                      <div class="col-md-3">
                        <label class="checkbox">
                          <input type="checkbox" value="sat" name="working_weeks[sat]" <?php echo e($selected); ?>>
                          <span>Sat</span></label>
                      </div>
                      <div class="col-md-3">
                        <label class="checkbox">
                          <input type="checkbox" value="sun" name="working_weeks[sun]" <?php echo e($selected); ?>>
                          <span>Sun</span></label>
                      </div>
                    </div>
                    <div class="col-md-1"><a class="btn btn btn-default tooltip-trigger"data-placement="right" data-toggle="tooltip" title=""data-original-title="Only checked days will be counted in your leaves">Info </a></div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Notice Period For Termination</label>
                    <div class="col-md-8">
                      <div class="col-md-3">
                        <input class="form-control" type="text" name="notice_period" value="<?php echo e($data['user']->notice_period); ?>">
                      </div>
                      <div class="col-md-8">
                        <?php 	if($data['user']->for_days == "for month"){		$selected = "selected=selected";	}elseif($data['user']->for_days == "for days"){		$selected = "selected=selected";	}else{		$selected = '';	}?>
                        <select class="form-control" name="for_days">
                          <option value="0">---select by month/day--</option>
                          <option value="for month" <?php echo e($selected); ?> >month/s</option>
                          <option value="for days" <?php echo e($selected); ?> >day/s</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Probation period</label>
                    <div class="col-md-8">
                      <div class="col-md-6">
                        <div class="input-group date datepicker">
                          <input class="form-control" id="ps" type="text" name="prob_start_date" value="<?php echo e($data['user']->prob_start_date); ?>" placeholder="start date">
                          <span class="input-group-addon"><img src="<?php echo e(asset('admin-asset/images/date.svg')); ?>" width="15"></span></div>
                      </div>
                      <div class="col-md-6">
                        <div class="input-group date datepicker">
                          <input class="form-control" id="pe" type="text" name="prob_end_date" value="<?php echo e($data['user']->prob_end_date); ?>" placeholder="end date">
                          <span class="input-group-addon"><img src="<?php echo e(asset('admin-asset/images/date.svg')); ?>" width="15"></span></div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="heading">
                    <h2></h2>
                  </div>
                  <br>
                  <div class="form-group">
                    <label class="control-label col-md-3">Appointment Date</label>
                    <div class="col-md-6">
                      <div class="input-group date datepicker">
                        <input class="form-control" id="from" type="text" name="app_date" value="<?php echo e($data['user']->doa); ?>" required>
                        <span class="input-group-addon"><img src="<?php echo e(asset('admin-asset/images/date.svg')); ?>" width="15"></span></div>
                    </div>
                    <span style="color:#d43f3a">mandatory</span> </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Joining Date</label>
                    <div class="col-md-6">
                      <div class="input-group date datepicker">
                        <input class="form-control" id="to" type="text" name="joining" value="<?php echo e($data['user']->doj); ?>">
                        <span class="input-group-addon" required><img src="<?php echo e(asset('admin-asset/images/date.svg')); ?>" width="15"></span></div>
                    </div>
                    <span style="color:#d43f3a">mandatory</span> </div>
                  <!--div class="form-group">
                    <label class="control-label col-md-3">Employee Code</label>
                    <div class="col-md-3">
                      <input class="form-control" type="text" name="e_code" value="<?php echo e($data['user']->unQid); ?>" required>
                      <span style="color:#d43f3a">mandatory</span> </div>
                    <div class="col-md-6"><a class="btn btn btn-default tooltip-trigger"data-placement="right" data-toggle="tooltip" title=""data-original-title="duplicate employee code cannot exist">Info </a></div>
                  </div-->
				  <div class="form-group">
					<label class="control-label col-md-3">Company</label>
					<div class="col-md-6">
					
					<select class="form-control" name="company">
											<option value="0">Company</option>
											<?php if($data["companies"]): ?>
												<?php $__currentLoopData = $data["companies"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php 
														if($company->id == $data["user"]->company){
															$selected = "selected=selected";
														}else{
															$selected =  "";
														}
													?>
													<option <?php echo e($selected); ?> value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>	
										  </select>
					</div>
					</div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Department</label>
                    <div class="col-md-6">
                      <?php 	if($data['user']->e_department == "1"){		$selected = "selected=selected";	}elseif($data['user']->e_department == "2"){		$selected = "selected=selected";	}elseif($data['user']->e_department == "3"){		$selected = "selected=selected";	}else{		$selected = '';	}?>
                      <select class="form-control" name="e_department">
                        <option value="0" <?php echo e($selected); ?>>Department</option>
                        <option value="1" <?php echo e($selected); ?>>Developing </option>
                        <option value="2" <?php echo e($selected); ?>>HR </option>
                        <option value="7" <?php echo e($selected); ?>>Sales </option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Basic Salary</label>
                    <div class="col-md-6">
                      <div class="input-group"><span class="input-group-addon">$</span>
                        <input class="form-control" name="e_salary" type="text" value="<?php echo e($data['user']->salary); ?>" required>
                      </div>
                    </div>
                    <span style="color:#d43f3a">mandatory</span> </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Sex</label>
                    <div class="col-md-6">
                      <?php 	if($data['user']->sex == "male"){
									$mselected = "checked=checked";
									$selected = "";
								}elseif($data['user']->sex == "female"){
									$selected = "checked='checked'";
									$mselected = '';									
								}else{
									$selected = '';
									$mselected = '';
									}?>
                      <label class="radio-inline">
                        <input name="sex" type="radio" value="male" <?php echo e($mselected); ?> required>
                        <span>Male</span></label>
                      <label class="radio-inline">
                        <input name="sex" type="radio" value="female" <?php echo e($selected); ?> required>
                        <span>Female</span></label>
                    </div>
                    <span style="color:#d43f3a">mandatory</span> </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Religion</label>
                    <div class="col-md-6">
                      <?php 	if($data['user']->religion == "hindu" || $data['user']->religion == "muslim" || $data['user']->religion == "sikh" || $data['user']->religion == "others"){		$selected = "checked='checked'";	}else{		$selected = '';	}?>
                      <label class="radio-inline">
                        <input name="religion" type="radio" value="hindu" <?php echo e($selected); ?>>
                        <span>Hindu</span></label>
                      <label class="radio-inline">
                        <input name="religion" type="radio" value="muslim" <?php echo e($selected); ?>>
                        <span>Mulsim</span></label>
                      <label class="radio-inline">
                        <input name="religion" type="radio" value="malaysia" <?php echo e($selected); ?>>
                        <span>Sikh</span></label>
                      <label class="radio-inline">
                        <input name="religion" type="radio" value="others" <?php echo e($selected); ?>>
                        <span>Others</span></label>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Job Title</label>
                    <div class="col-md-6">
                      <input class="form-control" name="jobtitle" type="text" value="<?php echo e($data['user']->jobtitle); ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Qualification</label>
                    <div class="col-md-6">
                      <input class="form-control" name="qualification" type="text" value="<?php echo e($data['user']->qualification); ?>">
                    </div>
                    <small>Use commas to separate names</small></div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Address Proof</label>
                    <div class="col-md-6">
                      <input class="form-control" name="addressproof" type="text" value="<?php echo e($data['user']->addressproof); ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3"></label>
                    <div class="col-md-6">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <input type="hidden" value="" name="">
                        <span class="btn btn-default btn-file"><span class="fileupload-new">Select file</span><span class="fileupload-exists">Change</span>
                        <input type="file" name="address_proof1" id="add_proof">
                        </span><span class="fileupload-preview"></span>
                        <button class="close fileupload-exists" data-dismiss="fileupload" style="float:none" type="button">�</button>
						<input type="hidden" name="address_proof1preimage" value="<?php echo e($data['user']->address_proof1); ?>" />
                      </div>
                      <small>Zip, txt, jpeg, png, pdf, doc (Max : 64M)</small></div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">ID Proof</label>
                    <div class="col-md-6">
                      <input class="form-control" name="idproof" type="text" value="<?php echo e($data['user']->idproof); ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3"></label>
                    <div class="col-md-6">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <input type="hidden" value="" name="">
                        <span class="btn btn-default btn-file"><span class="fileupload-new">Select file</span><span class="fileupload-exists">Change</span>
                        <input type="file" name="id_proof_files" id="id_proof">
                        </span><span class="fileupload-preview"></span>
                        <button class="close fileupload-exists" data-dismiss="fileupload" style="float:none" type="button">�</button>
						<input type="hidden" name="idproof1filenamepreimage" value="<?php echo e($data['user']->id_proof_files); ?>" />
                      </div>
                      <small>Zip, txt, jpeg, png, pdf, doc (Max : 64M)</small></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="form-group">
                  <div class="col-md-6">
                    <div class="heading">
                      <h2>Bank Details</h2>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="control-label col-md-3">Name</label>
                    <div class="col-md-6">
                      <input class="form-control" name="name" type="text" value="<?php echo e($data['user']->bank_author); ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">Branch</label>
                    <div class="col-md-6">
                      <input class="form-control" name="branch" type="text" value="<?php echo e($data['user']->branch); ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3">City</label>
                    <div class="col-md-6">
                      <input class="form-control" name="city" type="text" value="<?php echo e($data['user']->city); ?>">
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label class="control-label col-md-3">Account Number</label>
                  <div class="col-md-6">
                    <input class="form-control" name="acc_no" type="text" value="<?php echo e($data['user']->acc_no); ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-md-3">IFSC Code</label>
                  <div class="col-md-6">
                    <input class="form-control" name="ifsccode" type="text" value="<?php echo e($data['user']->ifsccode); ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-md-3">Remarks</label>
                  <div class="col-md-6">
                    <textarea class="form-control" name="remark"><?php echo e($data['user']->remark); ?></textarea>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <div class="col-md-12">
                <div class="col-md-6">
                  <button class="btn btn-lg btn-block btn-success" type="submit" name="submit_employee"> Submit</button>
                </div>
                <div class="col-md-6">
                  <button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?><script>//For profile pic size$('#profile_pic').bind('change', function() {$('#profilesize').val(this.files[0].size);var a = this.files[0].size;var b= 67108864;if(a>b)alert("File size must be less than 64M");});// For qualification files$('#qual_1').bind('change', function() {$('#qualification_1').val(this.files[0].size);var a = this.files[0].size;var b= 67108864;if(a>b)alert("File size must be less than 64M");});$('#qual_2').bind('change', function() {$('#qualification_2').val(this.files[0].size);var a = this.files[0].size;var b= 67108864;if(a>b)alert("File size must be less than 64M");});$('#qual_3').bind('change', function() {$('#qualification_3').val(this.files[0].size);var a = this.files[0].size;var b= 67108864;if(a>b)alert("File size must be less than 64M");});$('#qual_4').bind('change', function() {$('#qualification_4').val(this.files[0].size);var a = this.files[0].size;var b= 67108864;if(a>b)alert("File size must be less than 64M");});$('#qual_5').bind('change', function() {$('#qualification_5').val(this.files[0].size);var a = this.files[0].size;var b= 67108864;if(a>b)alert("File size must be less than 64M");});//for addressproof and idproof$('#add_proof').bind('change', function() {$('#add_proof_size').val(this.files[0].size);var a = this.files[0].size;var b= 67108864;if(a>b)alert("File size must be less than 64M");});$('#id_proof').bind('change', function() {$('#id_proof_size').val(this.files[0].size);var a = this.files[0].size;var b= 67108864;if(a>b)alert("File size must be less than 64M");});$(".allownumericwithoutdecimal").on("keypress keyup blur",function (event) {$(this).val($(this).val().replace(/[^\d-].+/, ""));if ((event.which > 57)) {event.preventDefault();}});</script>
<div class="row" style="text-align:center;"><span>V3.0</span></div>
</body>
</html>
<script>$(document).ready(function(){$(".pdf").click(function(){$("#table1").hide();setTimeout(function(){$("#table1").show()},1000);});});</script><script>$(".tooltip-trigger").tooltip();</script><script>/* for mobile navigation */$('.navbar-toggle').click(function() {return $('body, html').toggleClass("nav-open");});/** =============================================================================* DataTables* =============================================================================*/$("#dataTable1").dataTable({"sPaginationType": "full_numbers",aoColumnDefs: [{bSortable: false,aTargets: [0, -1]}]});$('.table').each(function() {return $(".table #checkAll").click(function() {if ($(".table #checkAll").is(":checked")) {return $(".table input[type=checkbox]").each(function() {return $(this).prop("checked", true);});} else {return $(".table input[type=checkbox]").each(function() {return $(this).prop("checked", false);});}});});/** =============================================================================* Bootstrap Popover* =============================================================================*/$(".popover-trigger").popover();/** =============================================================================* Datepicker* =============================================================================*/var date = new Date();$("#from").datepicker();$("#to").datepicker();$("#dob").datepicker();$("#ps").datepicker();$("#pe").datepicker();$("#term").datepicker();$("#periodfrom").datepicker();$("#periodto").datepicker();if($("#watermark_yes").is(":checked")){$("#watermark").show();}else{$("#watermark").hide();}$("#watermark_yes").click(function(){$("#watermark").show();});$("#watermark_no").click(function(){$("#watermark").hide();});</script><script>$(document).ready(function (){$(".fancybox").fancybox({maxWidth: 700,height: 'auto',fitToView: false,autoSize: true,padding: 15,nextEffect: 'fade',prevEffect: 'fade',helpers: {title: {type: "outside"}}});var a = $("#db_country").val();$("#country").val(a);});</script><script>$(document).ready(function (){var a = $("#db_timezone").val();$("#timezone").val(a);});$('#timepicker1').timepicker();$('#timepicker2').timepicker();$('#timepicker3').timepicker();$('#timepicker4').timepicker();$('#timepicker5').timepicker();$('#timepicker6').timepicker();$('#timepicker7').timepicker();$('#timepicker8').timepicker();$('#timepicker9').timepicker();$('#timepicker10').timepicker();$('#timepicker11').timepicker();$('#timepicker12').timepicker();$('#timepicker13').timepicker();$('#timepicker14').timepicker();</script><script>$(document).ready(function (){var a = $("#date_format").val();$("#dateformat").val(a);});</script><!-- ************************for change of salary from edit employee***************************** --><script>var a2 = Number($("#a2").val());var a3 = Number($("#a3").val());var a4 = Number($("#a4").val());var a5 = Number($("#a5").val());var ta_sum=a2+a3+a4+a5;$(".ta_total").val(ta_sum);var d2 = Number($("#d2").val());var d3 = Number($("#d3").val());var td_sum=d2+d3;$(".td_total").val(td_sum);var ad2 = Number($("#ad2").val());var ad3 = Number($("#ad3").val());var ad4 = Number($("#ad4").val());var add_sum=ad2+ad3+ad4;$(".add_total").val(add_sum);var basic = Number($("#basic").val());var ta = Number($(".ta_total").val());var td = Number($(".td_total").val());var add = Number($(".add_total").val());var overtime=Number($(".overtime").val());var employee_cpf=Number($("#employee_cpf").val());var net_pay_plus= (basic+ta+add+overtime);var net_pay_minus = (td+employee_cpf);var net_pay = (net_pay_plus-net_pay_minus);$("#net").val(net_pay);</script><!-- **************************************************************************** --><script>$("#enable_check").click(function(){if($("#enable_check").is(":checked")){$("#time1").hide();$("#time2").hide();}else {$("#time1").show();$("#time2").show();}});</script><script>$("#emp_view_check").click(function(){if($("#emp_view_check").is(":checked")){$("#emp_edit_check").show();$("#emp_del_check").show();$("#emp_add_check").show();}else{$("#emp_edit_check").hide();$("#emp_del_check").hide();$("#emp_add_check").hide();$(".employee_uncheck").removeAttr("checked","checked");}});$("#dep_view_check").click(function(){if($("#dep_view_check").is(":checked")){$("#dep_edit_check").show();$("#dep_del_check").show();$("#dep_add_check").show();}else{$("#dep_edit_check").hide();$("#dep_del_check").hide();$("#dep_add_check").hide();$(".employee_uncheck").removeAttr("checked","checked");}});$("#holiday_view_check").click(function(){if($("#holiday_view_check").is(":checked")){$("#holiday_edit_check").show();$("#holiday_del_check").show();$("#holiday_add_check").show();}else{$("#holiday_edit_check").hide();$("#holiday_del_check").hide();$("#holiday_add_check").hide();$(".employee_uncheck").removeAttr("checked","checked");}});$("#task_view_check").click(function(){if($("#task_view_check").is(":checked")){$("#task_edit_check").show();$("#task_del_check").show();$("#task_add_check").show();}else{$("#task_edit_check").hide();$("#task_del_check").hide();$("#task_add_check").hide();$(".employee_uncheck").removeAttr("checked","checked");}});$("#payslip_view_check").click(function(){if($("#payslip_view_check").is(":checked")){$("#payslip_del_check").show();$("#payslip_add_check").show();}else{$("#payslip_del_check").hide();$("#payslip_add_check").hide();$(".employee_uncheck").removeAttr("checked","checked");}});$("#template_view_check").click(function(){if($("#template_view_check").is(":checked")){$("#template_edit_check").show();$("#template_del_check").show();$("#template_add_check").show();}else{$("#template_edit_check").hide();$("#template_del_check").hide();$("#template_add_check").hide();$(".employee_uncheck").removeAttr("checked","checked");}});$("#awards_view_check").click(function(){if($("#awards_view_check").is(":checked")){$("#awards_add_check").show();}else{$("#awards_add_check").hide();$(".employee_uncheck").removeAttr("checked","checked");}});$("#noticeboard_view_check").click(function(){if($("#noticeboard_view_check").is(":checked")){$("#noticeboard_edit_check").show();$("#noticeboard_del_check").show();$("#noticeboard_add_check").show();}else{$("#noticeboard_edit_check").hide();$("#noticeboard_del_check").hide();$("#noticeboard_add_check").hide();$(".employee_uncheck").removeAttr("checked","checked");}});</script><script>if($("#fixed_based").is(":checked")){$("#annual_fixed_leaves").show();}else{$("#annual_fixed_leaves").hide();}$("#fixed_based").click(function(){$("#service_based").removeAttr("checked");$("#annual_fixed_leaves").show();$("#service_based_leaves").hide();$("#service_based_heading").hide();$("#annual").show();});$("#service_based").click(function(){$("#fixed_based").removeAttr("checked");$("#service_based_leaves").show();$("#annual_fixed_leaves").show();$("#service_based_heading").show();$("#annual").hide();});if($("#service_based").is(":checked")){$("#service_based_leaves").show();$("#annual_fixed_leaves").show();$("#service_based_heading").show();$("#annual").hide();}else{$("#service_based_leaves").hide();}</script><script>$("#sun_check").click(function(){if($("#sun_check").is(":checked")){$("#timepicker13").attr("disabled",true);$("#timepicker14").attr("disabled",true);}else {$("#timepicker13").attr("disabled",false);$("#timepicker14").attr("disabled",false);}});$("#mon_check").click(function(){if($("#mon_check").is(":checked")){$("#timepicker1").attr("disabled",true);$("#timepicker2").attr("disabled",true);}else {$("#timepicker1").attr("disabled",false);$("#timepicker2").attr("disabled",false);}});$("#tues_check").click(function(){if($("#tues_check").is(":checked")){$("#timepicker3").attr("disabled",true);$("#timepicker4").attr("disabled",true);}else {$("#timepicker3").attr("disabled",false);$("#timepicker4").attr("disabled",false);}});$("#wed_check").click(function(){if($("#wed_check").is(":checked")){$("#timepicker5").attr("disabled",true);$("#timepicker6").attr("disabled",true);}else {$("#timepicker5").attr("disabled",false);$("#timepicker6").attr("disabled",false);}});$("#thurs_check").click(function(){if($("#thurs_check").is(":checked")){$("#timepicker7").attr("disabled",true);$("#timepicker8").attr("disabled",true);}else {$("#timepicker7").attr("disabled",false);$("#timepicker8").attr("disabled",false);}});$("#fri_check").click(function(){if($("#fri_check").is(":checked")){$("#timepicker9").attr("disabled",true);$("#timepicker10").attr("disabled",true);}else {$("#timepicker9").attr("disabled",false);$("#timepicker10").attr("disabled",false);}});$("#sat_check").click(function(){if($("#sat_check").is(":checked")){$("#timepicker11").attr("disabled",true);$("#timepicker12").attr("disabled",true);}else {$("#timepicker11").attr("disabled",false);$("#timepicker12").attr("disabled",false);}});//for age$(".birth").change(function(){var dob = $("#dob").val();dob = new Date(dob);var today = new Date();var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));$('#age').val(age);});//for address$("#full_add").keyup(function(){var street1=$("#street_1").val();var houseno=$("#houseno").val();var country=$("#coun").val();var postal=$("#postal").val();var res=houseno.concat(",",street1,",",country,","postal);$("#fullad").val(res);});$(".co").change(function(){var block = $("#block").val();var street1=$("#street_1").val();var street2=$("#street_2").val();var street3=$("#street_3").val();var houseno=$("#houseno").val();var country=$("#coun").val();var postal=$("#postal").val();var res=houseno.concat(",",street1,",",country,","postal);$("#fullad").val(res);});$(document).ready(function(){$("#empid").change(function(){var eid=$("#empid").val();var sal=$(".emp"+eid).attr('data');var arr = sal.split('/');$("#sal").val(arr[0]);$("#netsal").val(arr[1]);});});jQuery('#con_no').keyup(function () {this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');this.value = this.value.replace(/[^0-9]/g, '');});jQuery('#mob_no').keyup(function () {this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');this.value = this.value.replace(/[^0-9]/g, '');});$('.nextofkin_conno').keyup(function () {this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');this.value = this.value.replace(/[^0-9]/g, '');});</script><script>$('.save').click(function(){var awd_data=$("#awd_name").val();var last_award_id = $(".last_award_id").val();$.ajax({type: "POST",url: "https://shiftsystems.net/demo/index.php?user=ajax",data: 'awd_data=' +awd_data,success: function(data){$(".fade").fadeOut();$("#myModal").hide();var new_last_id = parseInt(last_award_id)+parseInt(1);$('body').removeClass('modal-open');var newOption = "<option value='"+new_last_id+"'>"+awd_data+"</option>";$("#sel_awd").append(newOption);$(".last_award_id").val(new_last_id);}});});$('.Click_New_Award').click(function(){$(".fade").fadeIn();$("#myModal").show();});</script><script>$('.check_particular').click(function(){var data_ID=$(this).attr("data-id");if($(this).prop("checked")==true){var Prev_Ids = $(".prev_select_item_id").val();$(".prev_select_item_id").val(data_ID+'__'+Prev_Ids);$('.show_delete_button').show();}if($(this).prop("checked")==false){var Prev_Ids = $(".prev_select_item_id").val();var Remove_Id = data_ID+'__';var After_Unselect = Prev_Ids.replace(Remove_Id,"");$(".prev_select_item_id").val(After_Unselect);if(After_Unselect==""){$('.show_delete_button').hide();}}});</script><script>$(".clickonedit").click(function(){$(".show_field").show();$(".hide_field").hide();});$('.e_check').click(function(){if($(this).is(":checked")){$('.hide_e_check').hide();}else{$('.hide_e_check').show();}});</script><script>$('.delid').click(function(){var delid=$(this).attr('data-id');$('.confirmdelete').val(delid)});$('.fancy-close').click(function(){$('.hide_fancybox').close();});</script><script>function goback(){window.history.back();}</script><!-- ----------------------------for attendance marked---------------- --><script>$(".Post_Mark_Attendance").click(function(){var employee_id=$(".Post_id").attr('data-emp-id');var employee_code=$(".Post_code").attr('data-emp-code');var employee_deptid=$(".Post_deptid").attr('data-dept-id');var empdate=$(".Post_date").attr('data-date');var fulldetails ='&employee_id='+employee_id+'&employee_code='+employee_code+'&employee_deptid='+employee_deptid+'&empdate='+empdate;$.ajax({type: "POST",url: "https://shiftsystems.net/demo/index.php?user=ajax",data: 'fulldetails='+fulldetails,success: function(data){$(".datashown").text(data);$(".datashown").removeClass('btn btn-xs btn-success');$(".datashown").addClass('btn btn-xs btn-danger');$(".datashown").attr('disabled','disabled');}});})</script><script>function startTime() {var today = new Date();var h = today.getHours();var m = today.getMinutes();var s = today.getSeconds();m = checkTime(m);s = checkTime(s);document.getElementById('txt').innerHTML =h + ":" + m + ":" + s;var t = setTimeout(startTime, 500);}function checkTime(i) {if (i < 10) {i = "0" + i}; // add zero in front of numbers < 10return i;}</script><!-- ----------------------END------------------------------------- --><?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>