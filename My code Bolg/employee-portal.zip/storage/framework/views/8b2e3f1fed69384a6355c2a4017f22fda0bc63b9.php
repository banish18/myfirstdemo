<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
<div class="page-title">
<div class="row">
<div class="col-md-12">
<h1>Resignation Formality</h1></div></div>
</div>
<div class="row">
<div class="col-md-2">
<ul class="list-group">
<li class="list-group-item active" >
<a href="<?php echo e(route('users',array('action' => 'resignation-request'))); ?>">
<p>
<img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
&nbsp;Lists
</p></a>
</li>

</ul>
</div>

<div class="col-md-10">
<div class="widget-container fluid-height clearfix">
<div class="widget-content padded">
<form method="post" class="form-horizontal" action="<?php echo e(route('users',array('action' => 'postResignation'))); ?>">

 <?php echo e(csrf_field()); ?>


<div class="row">
<div class="col-md-12">
<div class="col-md-6">
<div class="form-group">
<label class="control-label col-md-3">Resignation Accepted</label>
<div class="col-md-4">
<label class="control-label">Yes</label>
<?php if($data['Resignationformality']->r_accepted == 1): ?>
<input name="resignation_accepted" type="radio" value="1" checked required>
<?php else: ?>
<input name="resignation_accepted" type="radio" value="1" required>
<?php endif; ?>
</div>
<div class="col-md-4">
<label class="control-label">No</label>
<?php if($data['Resignationformality']->r_accepted == 0): ?>
	<input name="resignation_accepted" type="radio" value="0" checked  required>
<?php else: ?>
<input name="resignation_accepted" type="radio" value="0"  required>
<?php endif; ?>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Resignation Date</label>
<div class="col-md-9">
<input type="text" class="form-control" name="r_date" id="r_date" value="<?php echo e($data['Resignationformality']->r_date); ?>"/>
</div>
</div>

<div class="form-group">
<label class="control-label col-md-3">Notice Period Serve</label>
<div class="col-md-9">
<input type="number" class="form-control" name="notice_period_server" id="notice_period_server" value="<?php echo e($data['Resignationformality']->notice_period_server); ?>"/>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Less Period Serve</label>
<div class="col-md-9">
<input type="number" class="form-control" name="less_period" id="less_period " value="1" readonly/>
</div>
</div>

<div class="form-group">
<label class="control-label col-md-3">Last Working Date</label>
<div class="col-md-9">
<input type="text"  class="form-control" name="last_working_date" id="last_working_date" value="<?php echo e($data['Resignationformality']->last_working_date); ?>" />
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Exit Formalities Detail</label>
<div class="col-md-9">
<input type="text" class="form-control" name="exit_formalities_detail" id="exit_formalities_detail" value="<?php echo e($data['Resignationformality']->exit_formalities_detail); ?>"/>
</div>
</div>


<div class="form-group">
<label class="control-label col-md-3">Remark On Behaviour</label>
<div class="col-md-9">
<input type="text" class="form-control" name=" remark_behaviour" id="exit_formalities_detail" value="<?php echo e($data['Resignationformality']->remark_behaviour); ?>"/>
</div>
</div>

</div>
<div class="col-md-6">
<div class="form-group">
<label class="control-label col-md-3">Dues Pending</label>
<div class="col-md-4">
<label class="control-label">Yes</label>
<?php if($data['Resignationformality']->dues_pending == 1): ?>
	<?php $Dstyle = "style='display:block;'"; ?>
<input name="dues_pending" type="radio" value="1" onclick="checkDues(this)" checked required>
<?php else: ?>
	<?php $Dstyle = "style=display:none;"; ?>
<input name="dues_pending" type="radio" value="1" onclick="checkDues(this)" required>
<?php endif; ?>	
</div>
<div class="col-md-4">
<label class="control-label">No</label>
<?php if($data['Resignationformality']->dues_pending == 0): ?>
<input name="dues_pending" type="radio" value="0" onclick="checkDues(this)" checked required>
<?php else: ?>
	<input name="dues_pending" type="radio" value="0" onclick="checkDues(this)" required>
<?php endif; ?>	
</div>
</div>

<div class="form-group dues" <?php echo e($Dstyle); ?>>
<label class="control-label col-md-3">Dues Pending Amount</label>
<div class="col-md-9">
<input type="text" class="form-control" name="dues_amount" id="dues_amount" value="<?php echo e($data['Resignationformality']->dues_amount); ?>"/>
</div>
</div>

<div class="form-group">
<label class="control-label col-md-3">Eligible</label>
<div class="col-md-4">
<label class="control-label">Yes</label>
<?php if($data['Resignationformality']->eligible == 1): ?>
<input name="eligible" type="radio" value="1" checked onclick="checkEligible(this)">
<?php $Estyle = "style=display:block;"; ?>
<?php else: ?>
	<?php $Estyle = "style=display:none;"; ?>
<input name="eligible" type="radio" value="1" onclick="checkEligible(this)">
<?php endif; ?>
</div>
<div class="col-md-4">
<label class="control-label">No</label>
<?php if($data['Resignationformality']->eligible == 0): ?>
<input name="eligible" type="radio" value="0" checked onclick="checkEligible(this)">
<?php else: ?>
<input name="eligible" type="radio" value="0" onclick="checkEligible(this)">
<?php endif; ?>	
</div>
</div>
<div class="form-group eligible" <?php echo e($Estyle); ?>>
<label class="control-label col-md-3">Eligible Detail</label>
<div class="col-md-9">
<input type="text" class="form-control" name="eligible_detail" id="eligible_detail" value="<?php echo e($data['Resignationformality']->eligible_detail); ?>"/>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Any Issue During Tenure</label>
<div class="col-md-9">
<input type="text" class="form-control" name="issue" id="issue" value="<?php echo e($data['Resignationformality']->issue); ?>"/>
</div>
</div>
<div class="form-group">
<label class="control-label col-md-3">Exit Formalities</label>
<div class="col-md-4">
<label class="control-label">Yes</label>
<?php if($data['Resignationformality']->exit_formalities == 1): ?>
<input name="exit_formalities" type="radio" value="1" checked>
<?php else: ?>
<input name="exit_formalities" type="radio" value="1" >
<?php endif; ?>	
</div>
<div class="col-md-4">
<label class="control-label">No</label>
<?php if($data['Resignationformality']->exit_formalities == 0): ?>
<input name="exit_formalities" type="radio" value="0" checked>
<?php else: ?>
	<input name="exit_formalities" type="radio" value="0" >
<?php endif; ?>	
</div>
</div>


<div class="form-group">
<label class="control-label col-md-3">Comments</label>
<div class="col-md-9">
<textarea name="other_comment" class="form-control" id="exit_formalities_detail"><?php echo e($data['Resignationformality']->other_comment); ?></textarea>

</div>
</div>


<input type="hidden" name="uid" value="<?php echo e($data['Resignationformality']->uid); ?>"/>


</div>
<div class="col-md-9"></div>
<div class="col-md-6">
<div class="form-group">
<div class="col-md-12">
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-success" type="submit" name="submit_employee"> Submit</button>
</div>
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
</div>
</div></div>
</div>
<div class="col-md-3"></div>
 </form>
</div>

</div>
</div>
</div>
<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
	$(function(){
		$("#r_date").datepicker();
		$("#last_working_date ").datepicker();
	});
	function checkDues(elm){
		var val = $(elm).val();
		if(val == 1){
			$(".dues").slideDown();
		}else{
			$(".dues").hide("slow");
			$("#dues_amount").val("0");
		}
	}
	function checkEligible(elm){
		var val = $(elm).val();
		if(val == 1){
			$(".eligible").slideDown();
		}else{
			$(".eligible").hide("slow");
			$("#eligible_detail").val("0");
		}
	}
</script>

<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>