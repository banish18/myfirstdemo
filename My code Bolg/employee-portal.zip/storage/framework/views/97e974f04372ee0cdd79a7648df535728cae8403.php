<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
<div class="page-title">
<h1>Edit Employee Template</h1>
   </div>
<div class="row">
<div class="col-md-2">

             <ul class="list-group">
			<li class="list-group-item active" >
			<a href="<?php echo e(route('users')); ?>">
           <p>
            <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;List Employees
           </p></a>
           </li>

           <li class="list-group-item">
           <a  href="<?php echo e(route('users',array('action' => 'add'))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add Employee
           </p>
           </a>
           </li>
           
            </ul>
</div>

 <div class="col-md-10">
 <div class="widget-container fluid-height clearfix">
 <div class="widget-content padded">
 
 <?php if($data['salarytemplate']): ?>
	 
 <form method="post" class="form-horizontal" action="<?php echo e(route('users',array('action' => 'postupdateTemplate'))); ?>">
	 <?php echo e(csrf_field()); ?>

 <input type="hidden" class="employee_dataid" value="18">
 <input type="hidden" class="empid" name="empid" value="<?php echo e($data['user']->id); ?>">
 <input type="hidden" class="employee_total_wages" value="12">
 <input type="hidden" class="empage" value="32">
 <input type="hidden" class="emp_salary" value="12">
 <input type="hidden" class="total_cpf_payable_additions" value="0">
 <input type="hidden" class="agetax" value="">
 <input type="hidden" class="agetax_employer" value="">

 <input type="hidden" class="employer_cpf" value="">

 <div class="row">
 <div class="col-md-12">
 <div class="col-md-6">
 <div class="form-group">
            <label class="control-label col-md-3">Name Of Template</label>
            <div class="col-md-6">
                       <input class="form-control" type="text" name="template_name" value="<?php echo e($data['user']->name); ?>" readonly="true">
            </div>
  </div>
  
  <div class="form-group">
            <label class="control-label col-md-3">Basic Pay</label>
            <div class="col-md-4">
              <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input  class="form-control total decimalvalidate" type="text" name="basicpay" id="basic" value="<?php echo e($data['user']->salary); ?>" readonly="true">
            </div></div>
             <div class="col-md-5">
            <a class="btn btn btn-default tooltip-trigger"
            data-placement="right" data-toggle="tooltip" title=""
             data-original-title="This is the employee salary,it comes when you add new employee,if you want to change the salary for generate payslip,you can change from here and it will not reflect the employee basic salary">Info </a>
  </div>
 </div>
 <div class="form-group">
            <label class="control-label col-md-3">Total Allowance</label>
           <div class="col-md-6">
             <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control tot ta_total total" value="<?php echo e($data['salarytemplate']->total_allowance); ?>" name="total_allowance_value" type="text" readonly="true">
            </div></div>

 </div>
 <?php if($data["salarytemplate"]->total_allowance_detail != ""): ?>
	 
	<?php 
	$total_allowance_value = json_decode($data["salarytemplate"]->total_allowence_value);
	$i = -1;?>
	 <?php $__currentLoopData = json_decode($data["salarytemplate"]->total_allowance_detail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_allowance_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php $i++; 
		
		?>
		
		<div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="allowance_name[]" type="text"  placeholder="Name of Allowance" value="<?php echo e($total_allowance_detail); ?>" style="color:#E91E63;">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control tot total decimalvalidate allwval"  name="allowance_value[]" type="text"  id="a2" value="<?php echo e($total_allowance_value[$i]); ?>" placeholder="Amount" onkeyup="addAllownecevalue()">
            </div></div>
			<?php 

						if($i > 2){
							echo '<input type="button" class="btn btn-success" value="-" onclick="removeAllowence(this)" />';
						}
						?>
	</div>
	 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php else: ?>
	 <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="allowance_name[]" type="text"  placeholder="Name of Allowance" value="" style="color:#E91E63;">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control tot total decimalvalidate allwval"  name="allowance_value[]" type="text"  id="a2" value="0" placeholder="Amount" onkeyup="addAllownecevalue()">
            </div></div>
 </div>
  <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="allowance_name[]" type="text" placeholder="Name of Allowance" value="" style="color:#E91E63;"  >
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control tot total decimalvalidate allwval"  name="allowance_value[]" type="text"  id="a3" value="0" placeholder="Amount" onkeyup="addAllownecevalue()">
            </div>
      </div>
 </div>
 
 
 
 <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="allowance_name[]" type="text" value="" placeholder="Name of Allowance" style="color:#E91E63;">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control tot total decimalvalidate allwval"  name="allowance_value[]" type="text"  id="a4" value="0" placeholder="Amount"  onkeyup="addAllownecevalue()">
            </div></div>
 </div>
 <?php endif; ?> 	 
  
  <div class="more_allowence">
 
 </div>
 <div class="form-group">
	<div class="col-md-12">
            <label class="control-label col-md-6">Add more Allowance</label>
            <div class="col-md-3">
              <input type="button" class="btn btn-success" value="+" onclick="addAllownece()"/>
            </div>
			
      </div>
 </div>
 
 

 <div class="form-group">
            <label class="control-label col-md-3">Total Deduction</label>
           <div class="col-md-6">
             <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control ded total td_total" value="0" readonly="true" name="total_deduction_value" type="text" >
            </div></div>
 </div>
 <?php if($data["salarytemplate"]->total_deduction_detail != ""): ?>
	 
	<?php 
	$total_deduction_value = json_decode($data["salarytemplate"]->total_deduction_value);
	$i = -1;
	
	?>
	 <?php $__currentLoopData = json_decode($data["salarytemplate"]->total_deduction_detail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_deduction_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php $i++;
		
		?>
			 <div class="form-group">
						<label class="control-label col-md-3"></label>
						<div class="col-md-3">
						  <input class="form-control"  name="deduction_name[]" type="text" value="<?php echo e($total_deduction_detail); ?>" placeholder="Name of Deduction" style="color:#E91E63;">
						  </div>
						  <div class="col-md-3">
						   <div class="input-group">
							<span class="input-group-addon">&#8377;</span>

						  <input class="form-control ded total decimalvalidate alldwval" onkeyup="addDeductionvalue()"  name="deduction_value[]" type="text" id="d2" value="<?php echo e($total_deduction_value[$i]); ?>" placeholder="Amount">
						</div></div>
						<?php 
						if($i > 2){
							echo '<input type="button" class="btn btn-success" value="-" onclick="removeDeduction(this)" />';
						}
						?>
			 </div>

 
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php else: ?>
	 <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="deduction_name[]" type="text" value="0" placeholder="Name of Deduction" style="color:#E91E63;">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control ded total decimalvalidate alldwval" onkeyup="addDeductionvalue()"  name="deduction_value[]" type="text" id="d2" value="0" placeholder="Amount">
            </div></div>
 </div>
 <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="deduction_name[]" type="text" value="" placeholder="Name of Deduction" style="color:#E91E63;" >
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control ded total decimalvalidate alldwval" onkeyup="addDeductionvalue()"  name="deduction_value[]" type="text" id="d3" value="0" placeholder="Amount">
            </div></div>
 </div>
 <?php endif; ?>
 
 <div class="more_deduction">
 
 </div>
 <div class="form-group">
	<div class="col-md-12">
            <label class="control-label col-md-6">Add more Deduction</label>
            <div class="col-md-3">
              <input type="button" class="btn btn-success" value="+" onclick="addDeduction()"/>
            </div>
			
      </div>
 </div>


 <div class="form-group">
            <b class="control-label col-md-3">Net Salary</b>
            <div class="col-md-6">
             <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control total"  name="net_pay" type="text"  id="net"  value="<?php echo e($data['salarytemplate']->net_salary); ?>" readonly="true">
            </div> </div>
 </div>

 <div class="form-group">
 <b class="control-label col-md-3">Salary Period</b>
 <div class="col-md-8">
 
 <?php if($data['salarytemplate']->salary_period != ""): ?>
	 
	<?php $salaryPeriod = (array) json_decode($data['salarytemplate']->salary_period); 
	?>
 <?php else: ?>
	 <?php
	 $salaryPeriod = "";
	 ?>
 <?php endif; ?>
	<?php 


	if(in_array("hourly",$salaryPeriod)){
		$checked = "checked=checked";
	}else{
		$checked = "";
	}
	if(in_array("daily",$salaryPeriod)){
		$dchecked = "checked=checked";
	}else{
		$dchecked = "";
	}
	if(in_array("weekly",$salaryPeriod)){
		$wchecked = "checked=checked";
	}else{
		$wchecked = "";
	}
	if(in_array("fortnightly",$salaryPeriod)){
		$fchecked = "checked=checked";
	}else{
		$fchecked = "";
	}
	if(in_array("monthly",$salaryPeriod)){
		$mchecked = "checked=checked";
	}else{
		$mchecked = "";
	}
		
	?>
   <input type="checkbox" name="salary_period[hourly]" value="hourly" <?php echo e($checked); ?>><span>Hourly</span>
                   <input type="checkbox" name="salary_period[daily]" value="daily" <?php echo e($dchecked); ?> ><span>Daily</span>
                   <input type="checkbox" name="salary_period[weekly]" <?php echo e($wchecked); ?> value="weekly" ><span>Weekly</span>
                   <input type="checkbox" name="salary_period[fortnightly]" <?php echo e($fchecked); ?> value="fortnightly" ><span>Fortnightly</span>
                    <input type="checkbox" name="salary_period[monthly]" <?php echo e($mchecked); ?> value="monthly" ><span>Monthly</span>
 </div></div>

 </div>
 <div class="col-md-6">


  <div class="form-group">
           <label class="control-label col-md-3">Employee CPF</label>
            <div class="col-md-5">
             <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control"  id="employee_cpf" name="employee_cpf" type="text"   value="0" readonly="true">
            </div> </div>
              <div class="col-md-4">
            <a class="btn btn btn-default tooltip-trigger"
            data-placement="right" data-toggle="tooltip" title=""
             data-original-title="Employee Cpf will calculate only if the employee belongs to the PR or Singapore citizen category ">Info </a>
            </div>
 </div>
 <div class="form-group">
 <label class="control-label col-md-3">Employee CPF Rate</label>
 <div class="col-md-5">
  <div class="input-group">
                <span class="input-group-addon">%</span>
            <input class="form-control agetax" name="employee_cpf_rate" value="0" readonly="true" >
            </div>
 </div>
  <div class="col-md-4">
<a class="btn btn btn-default tooltip-trigger"
            data-placement="right" data-toggle="tooltip" title=""
             data-original-title="Employee Cpf Rate will calculate only if the employee belongs to the PR or Singapore citizen category ">Info </a>
            </div>
 </div>
 <div class="form-group">
           <label class="control-label col-md-3">Employer's CPF Contribution</label>
            <div class="col-md-5">
             <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control employer_cpf" name="employee_cpf_conti"   value="0" readonly="true">
            </div> </div>
            <div class="col-md-4">
<a class="btn btn btn-default tooltip-trigger"
            data-placement="right" data-toggle="tooltip" title=""
             data-original-title="Employer Cpf will calculate only if the employee belongs to the PR or Singapore citizen category ">Info </a>
            </div>
 </div>

 <div class="form-group">
           <label class="control-label col-md-3">Employer's CPF Rate</label>
            <div class="col-md-5">
             <div class="input-group">
                <span class="input-group-addon">%</span>
              <input class="form-control agetax_employer"  name="employer_cpf_rate"    value="0" readonly="true" >
            </div> </div>
              <div class="col-md-4">
<a class="btn btn btn-default tooltip-trigger"
            data-placement="right" data-toggle="tooltip" title=""
             data-original-title="Employer Cpf Rate will calculate only if the employee belongs to the PR or Singapore citizen category ">Info </a>
            </div>
 </div>
 <!--div class="form-group">
            <label class="control-label col-md-3"></label>

             <div class="col-md-6">
              <h4>Overtime Payment Details</h4>
          </div>
 </div>


  <div class="form-group">
           <label class="control-label col-md-3">Overtime Payment Period</label>
           <div class="col-md-7">
            <div class="col-md-6">


 <div class="input-group date datepicker">
 <input class="form-control" id="ps" type="text" name="overtime_start_date" value="" placeholder="start date">
 <span class="input-group-addon">
 <img src="../images/date.svg" width="15">
 </span>
 </div></div>
   <div class="col-md-6">
 <div class="input-group date datepicker">
 <input class="form-control" id="pe" type="text" name="overtime_end_date" value="" placeholder="end date">
 <span class="input-group-addon">
  <img src="../images/date.svg" width="15">
 </span>
 </div></div></div>

 </div>
 <div class="form-group">
 <label class="control-label col-md-3">Overtime Hours Worked</label>
 <div class="col-md-6">
  <input class="form-control"  name="overtime_hours_worked" type="text" value="" >
 </div>
 </div>
 <div class="form-group">
           <label class="control-label col-md-3">Total Overtime Pay</label>
            <div class="col-md-6">
             <div class="input-group">
                <span class="input-group-addon">$</span>
              <input class="form-control overtime total decimalvalidate"  name="total_overtime_pay" type="text" value="" >
            </div> </div>
 </div-->


   <!--div class="form-group">
  <label class="control-label col-md-3">Overtime Period</label>
  <div class="col-md-6">
   <input type="checkbox" name="salary_period_overtime[hourly]" value="hourly" ><span>Hourly</span>
                   <input type="checkbox" name="salary_period_overtime[daily]" value="daily" ><span>Daily</span>
                   <input type="checkbox" name="salary_period_overtime[weekly]" value="weekly" ><span>Weekly</span>
                   <input type="checkbox" name="salary_period_overtime[fortnightly]" value="fortnightly" ><span>Fortnightly</span>
                    <input type="checkbox" name="salary_period_overtime[monthly]"  value="monthly" ><span>Monthly</span>
</div></div-->

  <div class="form-group">
            <label class="control-label col-md-3"></label>

             <div class="col-md-6">
              <h4>Additional Payments Details</h4>
          </div>
 </div>
 <?php if($data["salarytemplate"]->aditional_payment_detail != ""): ?>
	 
	<?php 
	$aditional_payment_value = json_decode($data["salarytemplate"]->aditional_payment_value);
	$i = -1;
	$l = 1;
	?>
	 <?php $__currentLoopData = json_decode($data["salarytemplate"]->aditional_payment_detail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aditional_payment_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	 <?php $i++;
	 $l++;
	 ?>
   <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="payment_name[]" type="text" value="<?php echo e($aditional_payment_detail); ?>" placeholder="Name of Payment">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control add total decimalvalidate"  name="payment_value[]" type="text"  id="ad<?php echo e($l); ?>" value="<?php echo e($aditional_payment_value[$i]); ?>" placeholder="Amount">
            </div></div>
 </div>
  
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php else: ?>
	  <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="payment_name[]" type="text" value="0" placeholder="Name of Payment">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control add total decimalvalidate"  name="payment_value[]" type="text"  id="ad2" value="0" placeholder="Amount">
            </div></div>
 </div>
  <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="payment_name[]" type="text" value="" placeholder="Name of Payment">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control add total decimalvalidate"  name="payment_value[]" type="text"  id="ad3" value="" placeholder="Amount">
            </div> </div>
 </div>
    <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="payment_name[]" type="text" value="" placeholder="Name of Payment">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control add total decimalvalidate"  name="payment_value[]" type="text"  id="ad4" value="" placeholder="Amount">
            </div></div>
 </div>
 <?php endif; ?>
 

  <div class="form-group">
            <label class="control-label col-md-3">Total Additional Payment</label>

             <div class="col-md-6">
              <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control add total add_total" value="<?php echo e($data['salarytemplate']->aditional_payment); ?>" name="total_payment_value" type="text" readonly="true">
            </div>
          </div>
 </div>
  <div class="form-group">
              <label class="control-label col-md-4"><b>Date Of Last Change</b></label>
            <div class="col-md-6">
			<?php echo e($data['salarytemplate']->updated_at); ?> by              </div>
  </div>

 </div>

  </div></div>
  <div class="form-group">
       <label class="control-label col-md-1">Note</label>
       <div class="col-md-10">
       <textarea class="form-control" name="note" ><?php echo e($data['salarytemplate']->notes); ?> </textarea></div>
        <div class="col-md-1"></div>
 </div>
  <div class="form-group">
  <div class="col-md-1"></div>
  <div class="col-md-10">
  <button class="btn btn-lg btn-block btn-success" type="submit" name="submit_edittemplate"> Update</button>
  </div>
 <div class="col-md-1"></div>
 </div>
 </form>
 
<?php else: ?>
 <form method="post" class="form-horizontal" action="<?php echo e(route('users',array('action' => 'postupdateTemplate'))); ?>">
	 <?php echo e(csrf_field()); ?>

 <input type="hidden" class="employee_dataid" value="18">
 <input type="hidden" class="empid" name="empid" value="<?php echo e($data['user']->id); ?>">
 <input type="hidden" class="employee_total_wages" value="12">
 <input type="hidden" class="empage" value="32">
 <input type="hidden" class="emp_salary" value="12">
 <input type="hidden" class="total_cpf_payable_additions" value="0">
 <input type="hidden" class="agetax" value="">
 <input type="hidden" class="agetax_employer" value="">

 <input type="hidden" class="employer_cpf" value="">

 <div class="row">
 <div class="col-md-12">
 <div class="col-md-6">
 <div class="form-group">
            <label class="control-label col-md-3">Name Of Template</label>
            <div class="col-md-6">
                       <input class="form-control" type="text" name="template_name" value="<?php echo e($data['user']->name); ?>" readonly="true">
            </div>
  </div>
  
  <div class="form-group">
            <label class="control-label col-md-3">Basic Pay</label>
            <div class="col-md-4">
              <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input  class="form-control total decimalvalidate" type="text" name="basicpay" id="basic" value="<?php echo e($data['user']->salary); ?>" readonly="true">
            </div></div>
             <div class="col-md-5">
            <a class="btn btn btn-default tooltip-trigger"
            data-placement="right" data-toggle="tooltip" title=""
             data-original-title="This is the employee salary,it comes when you add new employee,if you want to change the salary for generate payslip,you can change from here and it will not reflect the employee basic salary">Info </a>
  </div>
 </div>
 <div class="form-group">
            <label class="control-label col-md-3">Total Allowance</label>
           <div class="col-md-6">
             <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control tot ta_total total" value="" name="total_allowance_value" type="text" readonly="true">
            </div></div>

 </div>

	 <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="allowance_name[]" type="text"  placeholder="Name of Allowance" value="" style="color:#E91E63;">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control tot total decimalvalidate allwval"  name="allowance_value[]" type="text"  id="a2" value="0" placeholder="Amount" onkeyup="addAllownecevalue()">
            </div></div>
 </div>
  <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="allowance_name[]" type="text" placeholder="Name of Allowance" value="" style="color:#E91E63;"  >
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control tot total decimalvalidate allwval"  name="allowance_value[]" type="text"  id="a3" value="0" placeholder="Amount" onkeyup="addAllownecevalue()">
            </div>
      </div>
 </div>
 
 
 
 <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="allowance_name[]" type="text" value="" placeholder="Name of Allowance" style="color:#E91E63;">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control tot total decimalvalidate allwval"  name="allowance_value[]" type="text"  id="a4" value="0" placeholder="Amount"  onkeyup="addAllownecevalue()">
            </div></div>
 </div>
	 
  
  <div class="more_allowence">
 
 </div>
 <div class="form-group">
	<div class="col-md-12">
            <label class="control-label col-md-6">Add more Allowance</label>
            <div class="col-md-3">
              <input type="button" class="btn btn-success" value="+" onclick="addAllownece()"/>
            </div>
			
      </div>
 </div>
 
 

 <div class="form-group">
            <label class="control-label col-md-3">Total Deduction</label>
           <div class="col-md-6">
             <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control ded total td_total" value="0" readonly="true" name="total_deduction_value" type="text" >
            </div></div>
 </div>

	 <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="deduction_name[]" type="text" value="" placeholder="Name of Deduction" style="color:#E91E63;">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control ded total decimalvalidate alldwval" onkeyup="addDeductionvalue()"  name="deduction_value[]" type="text" id="d2" value="0" placeholder="Amount">
            </div></div>
 </div>
 <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="deduction_name[]" type="text" value="" placeholder="Name of Deduction" style="color:#E91E63;" >
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control ded total decimalvalidate alldwval" onkeyup="addDeductionvalue()"  name="deduction_value[]" type="text" id="d3" value="0" placeholder="Amount">
            </div></div>
 </div>

 
 <div class="more_deduction">
 
 </div>
 <div class="form-group">
	<div class="col-md-12">
            <label class="control-label col-md-6">Add more Deduction</label>
            <div class="col-md-3">
              <input type="button" class="btn btn-success" value="+" onclick="addDeduction()"/>
            </div>
			
      </div>
 </div>


 <div class="form-group">
            <b class="control-label col-md-3">Net Salary</b>
            <div class="col-md-6">
             <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control total"  name="net_pay" type="text"  id="net"  value="" readonly="true">
            </div> </div>
 </div>

 <div class="form-group">
 <b class="control-label col-md-3">Salary Period</b>
 <div class="col-md-8">
 
   <input type="checkbox" name="salary_period[hourly]" value="hourly" ><span>Hourly</span>
                   <input type="checkbox" name="salary_period[daily]" value="daily"  ><span>Daily</span>
                   <input type="checkbox" name="salary_period[weekly]"  value="weekly" ><span>Weekly</span>
                   <input type="checkbox" name="salary_period[fortnightly]"  value="fortnightly" ><span>Fortnightly</span>
                    <input type="checkbox" name="salary_period[monthly]"  value="monthly" ><span>Monthly</span>
 </div></div>

 </div>
 <div class="col-md-6">


  <div class="form-group">
           <label class="control-label col-md-3">Employee CPF</label>
            <div class="col-md-5">
             <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control"  id="employee_cpf" name="employee_cpf" type="text"   value="0" readonly="true">
            </div> </div>
              <div class="col-md-4">
            <a class="btn btn btn-default tooltip-trigger"
            data-placement="right" data-toggle="tooltip" title=""
             data-original-title="Employee Cpf will calculate only if the employee belongs to the PR or Singapore citizen category ">Info </a>
            </div>
 </div>
 <div class="form-group">
 <label class="control-label col-md-3">Employee CPF Rate</label>
 <div class="col-md-5">
  <div class="input-group">
                <span class="input-group-addon">%</span>
            <input class="form-control agetax" name="employee_cpf_rate" value="0" readonly="true" >
            </div>
 </div>
  <div class="col-md-4">
<a class="btn btn btn-default tooltip-trigger"
            data-placement="right" data-toggle="tooltip" title=""
             data-original-title="Employee Cpf Rate will calculate only if the employee belongs to the PR or Singapore citizen category ">Info </a>
            </div>
 </div>
 <div class="form-group">
           <label class="control-label col-md-3">Employer's CPF Contribution</label>
            <div class="col-md-5">
             <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control employer_cpf" name="employee_cpf_conti"   value="0" readonly="true">
            </div> </div>
            <div class="col-md-4">
<a class="btn btn btn-default tooltip-trigger"
            data-placement="right" data-toggle="tooltip" title=""
             data-original-title="Employer Cpf will calculate only if the employee belongs to the PR or Singapore citizen category ">Info </a>
            </div>
 </div>

 <div class="form-group">
           <label class="control-label col-md-3">Employer's CPF Rate</label>
            <div class="col-md-5">
             <div class="input-group">
                <span class="input-group-addon">%</span>
              <input class="form-control agetax_employer"  name="employer_cpf_rate"    value="0" readonly="true" >
            </div> </div>
              <div class="col-md-4">
<a class="btn btn btn-default tooltip-trigger"
            data-placement="right" data-toggle="tooltip" title=""
             data-original-title="Employer Cpf Rate will calculate only if the employee belongs to the PR or Singapore citizen category ">Info </a>
            </div>
 </div>
 <!--div class="form-group">
            <label class="control-label col-md-3"></label>

             <div class="col-md-6">
              <h4>Overtime Payment Details</h4>
          </div>
 </div>


  <div class="form-group">
           <label class="control-label col-md-3">Overtime Payment Period</label>
           <div class="col-md-7">
            <div class="col-md-6">


 <div class="input-group date datepicker">
 <input class="form-control" id="ps" type="text" name="overtime_start_date" value="" placeholder="start date">
 <span class="input-group-addon">
 <img src="../images/date.svg" width="15">
 </span>
 </div></div>
   <div class="col-md-6">
 <div class="input-group date datepicker">
 <input class="form-control" id="pe" type="text" name="overtime_end_date" value="" placeholder="end date">
 <span class="input-group-addon">
  <img src="../images/date.svg" width="15">
 </span>
 </div></div></div>

 </div>
 <div class="form-group">
 <label class="control-label col-md-3">Overtime Hours Worked</label>
 <div class="col-md-6">
  <input class="form-control"  name="overtime_hours_worked" type="text" value="" >
 </div>
 </div>
 <div class="form-group">
           <label class="control-label col-md-3">Total Overtime Pay</label>
            <div class="col-md-6">
             <div class="input-group">
                <span class="input-group-addon">$</span>
              <input class="form-control overtime total decimalvalidate"  name="total_overtime_pay" type="text" value="" >
            </div> </div>
 </div-->


   <!--div class="form-group">
  <label class="control-label col-md-3">Overtime Period</label>
  <div class="col-md-6">
   <input type="checkbox" name="salary_period_overtime[hourly]" value="hourly" ><span>Hourly</span>
                   <input type="checkbox" name="salary_period_overtime[daily]" value="daily" ><span>Daily</span>
                   <input type="checkbox" name="salary_period_overtime[weekly]" value="weekly" ><span>Weekly</span>
                   <input type="checkbox" name="salary_period_overtime[fortnightly]" value="fortnightly" ><span>Fortnightly</span>
                    <input type="checkbox" name="salary_period_overtime[monthly]"  value="monthly" ><span>Monthly</span>
</div></div-->

  <div class="form-group">
            <label class="control-label col-md-3"></label>

             <div class="col-md-6">
              <h4>Additional Payments Details</h4>
          </div>
 </div>

	  <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="payment_name[]" type="text" value="" placeholder="Name of Payment">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control add total decimalvalidate"  name="payment_value[]" type="text"  id="ad2" value="0" placeholder="Amount">
            </div></div>
 </div>
  <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="payment_name[]" type="text" value="" placeholder="Name of Payment">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control add total decimalvalidate"  name="payment_value[]" type="text"  id="ad3" value="" placeholder="Amount">
            </div> </div>
 </div>
    <div class="form-group">
            <label class="control-label col-md-3"></label>
            <div class="col-md-3">
              <input class="form-control"  name="payment_name[]" type="text" value="" placeholder="Name of Payment">
              </div>
              <div class="col-md-3">
               <div class="input-group">
                <span class="input-group-addon">&#8377;</span>
              <input class="form-control add total decimalvalidate"  name="payment_value[]" type="text"  id="ad4" value="" placeholder="Amount">
            </div></div>
 </div>
 
 

  <div class="form-group">
            <label class="control-label col-md-3">Total Additional Payment</label>

             <div class="col-md-6">
              <div class="input-group">
                <span class="input-group-addon">&#8377;</span>

              <input class="form-control add total add_total" value="" name="total_payment_value" type="text" readonly="true">
            </div>
          </div>
 </div>
  <div class="form-group">
              <label class="control-label col-md-4"><b>Date Of Last Change</b></label>
            <div class="col-md-6">
			 by              </div>
  </div>

 </div>

  </div></div>
  <div class="form-group">
       <label class="control-label col-md-1">Note</label>
       <div class="col-md-10">
       <textarea class="form-control" name="note" > </textarea></div>
        <div class="col-md-1"></div>
 </div>
  <div class="form-group">
  <div class="col-md-1"></div>
  <div class="col-md-10">
  <button class="btn btn-lg btn-block btn-success" type="submit" name="submit_edittemplate"> Update</button>
  </div>
 <div class="col-md-1"></div>
 </div>
 </form>
<?php endif; ?>	
 </div></div></div></div>
</div>
<?php echo $__env->make("templates/admin-footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 <script>
function addAllownece(){
	$(".more_allowence").append('<div class="form-group"><label class="control-label col-md-3"></label><div class="col-md-3"><input class="form-control"   name="allowance_name[]" type="text" value="" placeholder="Name of Allowance" style="color:#E91E63;"></div><div class="col-md-3"><div class="input-group"><span class="input-group-addon">&#8377;</span><input class="form-control  total decimalvalidate allwval"  name="allowance_value[]" type="text" value="0" placeholder="Amount"  onkeyup="addAllownecevalue()"></div></div><input type="button" class="btn btn-success" value="-" onclick="removeAllowence(this)" /></div>');
}
function removeAllowence(elm){
	$(elm).parent().remove();
	addAllownecevalue();
}

function addDeduction(){
	$(".more_deduction").append('<div class="form-group"><label class="control-label col-md-3"></label><div class="col-md-3"><input class="form-control"  name="deduction_name[]" type="text" value="" placeholder="Name of Deduction" style="color:#E91E63;"></div><div class="col-md-3"><div class="input-group"><span class="input-group-addon">&#8377;</span><input class="form-control alldwval" onkeyup="addDeductionvalue()"  name="deduction_value[]" type="text"  id="a4" value="0" placeholder="Amount"></div></div><input type="button" class="btn btn-success" value="-" onclick="removeDeduction(this)" /></div>');
	
}

function removeDeduction(elm){
	$(elm).parent().remove();
	addDeductionvalue();
}

function addAllownecevalue(){
	var summ = 0;
	$(".allwval").each(function() {
		summ = parseInt(summ)+parseInt($(this).val());
	});
	 $(".ta_total").val(summ);
};

function addDeductionvalue(){
	var summ = 0;
	$(".alldwval").each(function() {
		summ = parseInt(summ)+parseInt($(this).val());
	});
	 $(".td_total").val(summ);
};

$('input.decimalvalidate').keyup(function() {
 var $th = $(this);
 $th.val( $th.val().replace(/[&!~`@#$%^*=a-z]/g, function(str) { return ''; } )) ;
});
 
$(".ded").keyup(function (){
	var d2 = Number($("#d2").val());
	var d3 = Number($("#d3").val());
	var td_sum=d2+d3;
	$(".td_total").val(td_sum);
});

$(".add").keyup(function (){
	var ad2 = Number($("#ad2").val());
	var ad3 = Number($("#ad3").val());
	var ad4 = Number($("#ad4").val());
	var add_sum=ad2+ad3+ad4;
	$(".add_total").val(add_sum);
});

$(".total").keyup(function(){
	var employeedataid=$(".employee_dataid").val();
	var empid = $(".empid").val();
	var basic = Number($("#basic").val());
	var ta = Number($(".ta_total").val());
	var td = Number($(".td_total").val());
	var add =  Number($(".add_total").val());
	var overtime=Number($(".overtime").val());
	var employee_cpf=Number($("#employee_cpf").val());
	var net_pay_plus= (basic+ta+add);
	var net_pay_minus =  (td+employee_cpf);
	var net_pay = (net_pay_plus-net_pay_minus);
	$("#net").val(net_pay.toFixed(2));
	var agetax = $(".agetax").val();
	var agetax_employer = $(".agetax_employer").val();
	var employer_cpf = $(".employer_cpf").val();

});

var summ = 0;
$(".alldwval").each(function() {
summ = parseInt(summ)+parseInt($(this).val());
});

var td_sum=summ;
$(".td_total").val(td_sum);

var ad2 = Number($("#ad2").val());
var ad3 = Number($("#ad3").val());
var ad4 = Number($("#ad4").val());
var add_sum=ad2+ad3+ad4;
	
$(".add_total").val(add_sum);
var basic = Number($("#basic").val());
var ta = Number($(".ta_total").val());
var td = Number($(".td_total").val());
var add =  Number($(".add_total").val());
var overtime=Number($(".overtime").val());

var employee_cpf=Number($("#employee_cpf").val());
var net_pay_plus= (basic+ta+add);
var net_pay_minus =  (td+employee_cpf);
var net_pay = (net_pay_plus-net_pay_minus);
$("#net").val(net_pay);
$("#net").val(net_pay);

 

</script>
 

<script>
$(".tooltip-trigger").tooltip();
 </script>
     <script>
     /*   for mobile navigation */
     $('.navbar-toggle').click(function() {
         return $('body, html').toggleClass("nav-open");
       });

     /*
      * =============================================================================
      *   DataTables
      * =============================================================================
      */
     $("#dataTable1").dataTable({
       "sPaginationType": "full_numbers",
       aoColumnDefs: [
         {
           bSortable: false,
           aTargets: [0, -1]
         }
       ]
     });
     $('.table').each(function() {
       return $(".table #checkAll").click(function() {
         if ($(".table #checkAll").is(":checked")) {
           return $(".table input[type=checkbox]").each(function() {
             return $(this).prop("checked", true);
           });
         } else {
           return $(".table input[type=checkbox]").each(function() {
             return $(this).prop("checked", false);
           });
         }
       });
     });


     /*
      * =============================================================================
      *   Bootstrap Popover
      * =============================================================================
      */

     $(".popover-trigger").popover();

 
	

</script>


  
    <!-- ************************for change of salary from edit employee***************************** -->
   <script>




</script>
  <!-- **************************************************************************** -->

   <script>
   $("#enable_check").click(function(){
	   if($("#enable_check").is(":checked")){
           $("#time1").hide();
           $("#time2").hide();
		   }
		   else {
			   $("#time1").show();
			   $("#time2").show();
			   }
	   });
   </script>
   <script>
   $("#emp_view_check").click(function(){

   if($("#emp_view_check").is(":checked")){

	  	  $("#emp_edit_check").show();
		  	$("#emp_del_check").show();
			$("#emp_add_check").show();
	    }
	  else{
	  $("#emp_edit_check").hide();
	  $("#emp_del_check").hide();
		$("#emp_add_check").hide();
		$(".employee_uncheck").removeAttr("checked","checked");
	  }
	  });

   $("#dep_view_check").click(function(){

	   if($("#dep_view_check").is(":checked")){

		  	  $("#dep_edit_check").show();
			  	$("#dep_del_check").show();
			  	 $("#dep_add_check").show();
		    }
		  else{
		  $("#dep_edit_check").hide();
		  $("#dep_del_check").hide();
		  $("#dep_add_check").hide();
		  $(".employee_uncheck").removeAttr("checked","checked");
		  }
		  });
   $("#holiday_view_check").click(function(){

	   if($("#holiday_view_check").is(":checked")){

		  	  $("#holiday_edit_check").show();
			  	$("#holiday_del_check").show();
				$("#holiday_add_check").show();
		    }
		  else{
		  $("#holiday_edit_check").hide();
		  $("#holiday_del_check").hide();
			$("#holiday_add_check").hide();
			$(".employee_uncheck").removeAttr("checked","checked");
		  }
		  });
   $("#task_view_check").click(function(){

	   if($("#task_view_check").is(":checked")){
		  	  $("#task_edit_check").show();
			  	$("#task_del_check").show();
				$("#task_add_check").show();
		    }
		  else{
		  $("#task_edit_check").hide();
		  $("#task_del_check").hide();
			$("#task_add_check").hide();
			$(".employee_uncheck").removeAttr("checked","checked");
		  }
		  });
   $("#payslip_view_check").click(function(){

	   if($("#payslip_view_check").is(":checked")){
			  	$("#payslip_del_check").show();
			  	$("#payslip_add_check").show();
		    }
		  else{

		  $("#payslip_del_check").hide();
		  $("#payslip_add_check").hide();
		  $(".employee_uncheck").removeAttr("checked","checked");
		  }
		  });
   $("#template_view_check").click(function(){

	   if($("#template_view_check").is(":checked")){

		   $("#template_edit_check").show();
			  	$("#template_del_check").show();
			  	$("#template_add_check").show();
		    }
		  else{
		  $("#template_edit_check").hide();
		  $("#template_del_check").hide();
		  $("#template_add_check").hide();
		  $(".employee_uncheck").removeAttr("checked","checked");
		  }
		  });
	  $("#awards_view_check").click(function(){
       if($("#awards_view_check").is(":checked")){
          $("#awards_add_check").show();
           }else{
            $("#awards_add_check").hide();
            $(".employee_uncheck").removeAttr("checked","checked");
               }
		  });


	  $("#noticeboard_view_check").click(function(){

		   if($("#noticeboard_view_check").is(":checked")){

			  	  $("#noticeboard_edit_check").show();
				  	$("#noticeboard_del_check").show();
					$("#noticeboard_add_check").show();
			    }
			  else{
			  $("#noticeboard_edit_check").hide();
			  $("#noticeboard_del_check").hide();
				$("#noticeboard_add_check").hide();
				$(".employee_uncheck").removeAttr("checked","checked");
			  }
			  });

   </script>

  <script>


  if($("#fixed_based").is(":checked")){

	  	  $("#annual_fixed_leaves").show();
	    }
	  else{
		  $("#annual_fixed_leaves").hide();
	  }
  $("#fixed_based").click(function(){
	  $("#service_based").removeAttr("checked");
	    $("#annual_fixed_leaves").show();
	    $("#service_based_leaves").hide();
	    $("#service_based_heading").hide();
	    $("#annual").show();
	});
  $("#service_based").click(function(){
	  $("#fixed_based").removeAttr("checked");
	    $("#service_based_leaves").show();
	    $("#annual_fixed_leaves").show();
	    $("#service_based_heading").show();
	    $("#annual").hide();

	});
  if($("#service_based").is(":checked")){

  	  $("#service_based_leaves").show();
  	  $("#annual_fixed_leaves").show();
    	$("#service_based_heading").show();
    	$("#annual").hide();
    }
  else{
	  $("#service_based_leaves").hide();
  }

   </script>

    <script>
   $("#sun_check").click(function(){
	   if($("#sun_check").is(":checked")){
		   $("#timepicker13").attr("disabled",true);
		   $("#timepicker14").attr("disabled",true);
         }
		   else {
			   $("#timepicker13").attr("disabled",false);
			   $("#timepicker14").attr("disabled",false);
			   }
	   });
   $("#mon_check").click(function(){
	   if($("#mon_check").is(":checked")){
		   $("#timepicker1").attr("disabled",true);
		   $("#timepicker2").attr("disabled",true);
         }
		   else {
			   $("#timepicker1").attr("disabled",false);
			   $("#timepicker2").attr("disabled",false);
			   }
	   });
   $("#tues_check").click(function(){
	   if($("#tues_check").is(":checked")){
		   $("#timepicker3").attr("disabled",true);
		   $("#timepicker4").attr("disabled",true);
         }
		   else {
			   $("#timepicker3").attr("disabled",false);
			   $("#timepicker4").attr("disabled",false);
			   }
	   });
   $("#wed_check").click(function(){
	   if($("#wed_check").is(":checked")){
		   $("#timepicker5").attr("disabled",true);
		   $("#timepicker6").attr("disabled",true);
         }
		   else {
			   $("#timepicker5").attr("disabled",false);
			   $("#timepicker6").attr("disabled",false);
			   }
	   });
   $("#thurs_check").click(function(){
	   if($("#thurs_check").is(":checked")){
		   $("#timepicker7").attr("disabled",true);
		   $("#timepicker8").attr("disabled",true);
         }
		   else {
			   $("#timepicker7").attr("disabled",false);
			   $("#timepicker8").attr("disabled",false);
			   }
	   });
   $("#fri_check").click(function(){
	   if($("#fri_check").is(":checked")){
		   $("#timepicker9").attr("disabled",true);
		   $("#timepicker10").attr("disabled",true);
         }
		   else {
			   $("#timepicker9").attr("disabled",false);
			   $("#timepicker10").attr("disabled",false);
			   }
	   });
   $("#sat_check").click(function(){
	   if($("#sat_check").is(":checked")){
		   $("#timepicker11").attr("disabled",true);
		   $("#timepicker12").attr("disabled",true);
         }
		   else {
			   $("#timepicker11").attr("disabled",false);
			   $("#timepicker12").attr("disabled",false);
			   }
	   });

//for age
   $(".birth").change(function(){
	   var dob = $("#dob").val();
	  dob = new Date(dob);
    var today = new Date();
   var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
   $('#age').val(age);
   });
   //for address
   $("#full_add").keyup(function(){
	   var block = $("#block").val();
	   var street1=$("#street_1").val();
	   var street2=$("#street_2").val();
	   var street3=$("#street_3").val();
	   var houseno=$("#houseno").val();
	   var country=$("#coun").val();
	   var postal=$("#postal").val();

	   var res=houseno.concat(","," ",block," ",",",street1,",",street2,street3," ",",",country," ",postal);

	   $("#fullad").val(res);


	   });

 

   $(document).ready(function(){
   $("#empid").change(function(){

         var eid=$("#empid").val();
         var sal=$(".emp"+eid).attr('data');

         var arr = sal.split('/');

         $("#sal").val(arr[0]);
         $("#netsal").val(arr[1]);


	   });
   });


   jQuery('#con_no').keyup(function () {
	    this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');
	     this.value = this.value.replace(/[^0-9]/g, '');
	});


   jQuery('#mob_no').keyup(function () {
	    this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');
	     this.value = this.value.replace(/[^0-9]/g, '');
	});

   $('.nextofkin_conno').keyup(function () {
        this.value = this.value.replace(/[ \ ^ 0 1 2 4 5 7. | ? * + ( )]*/,'');
        this.value = this.value.replace(/[^0-9]/g, '');
   });

   </script>

   <script>

   $('.save').click(function(){

    var awd_data=$("#awd_name").val();
    var last_award_id = $(".last_award_id").val();
  $.ajax({
		  type: "POST",
		  url: "https://shiftsystems.net/demo/index.php?user=ajax",
		  data: 'awd_data=' +awd_data,

		  success: function(data)
		  {

        	  $(".fade").fadeOut();
			  $("#myModal").hide();
			  var new_last_id = parseInt(last_award_id)+parseInt(1);
			  $('body').removeClass('modal-open');
			  var newOption = "<option value='"+new_last_id+"'>"+awd_data+"</option>";
			  $("#sel_awd").append(newOption);
			  $(".last_award_id").val(new_last_id);
		  }


		});
   });
   $('.Click_New_Award').click(function(){
	   $(".fade").fadeIn();
	   $("#myModal").show();
   });
   </script>


   <script>
   $('.check_particular').click(function(){
	   var data_ID=$(this).attr("data-id");
if($(this).prop("checked")==true)
{
	 var Prev_Ids = $(".prev_select_item_id").val();
	 $(".prev_select_item_id").val(data_ID+'__'+Prev_Ids);
 $('.show_delete_button').show();
}
if($(this).prop("checked")==false){
	 var Prev_Ids = $(".prev_select_item_id").val();
	 var Remove_Id = data_ID+'__';
	 var After_Unselect = Prev_Ids.replace(Remove_Id,"");
	 $(".prev_select_item_id").val(After_Unselect);
		if(After_Unselect==""){
	$('.show_delete_button').hide();
		}
}

});
   </script>

   <script>
$(".clickonedit").click(function(){
$(".show_field").show();
$(".hide_field").hide();
});

$('.e_check').click(function(){
if($(this).is(":checked")){
$('.hide_e_check').hide();
}else{
$('.hide_e_check').show();
}
});
   </script>

<script>
$('.delid').click(function(){
	var delid=$(this).attr('data-id');
    $('.confirmdelete').val(delid)

});

$('.fancy-close').click(function(){
$('.hide_fancybox').close();
});
</script>
<script>
function goback(){
	window.history.back();
}
    </script>
  <!-- ----------------------------for attendance marked---------------- -->
<script>
    $(".Post_Mark_Attendance").click(function(){
var employee_id=$(".Post_id").attr('data-emp-id');
var employee_code=$(".Post_code").attr('data-emp-code');
var employee_deptid=$(".Post_deptid").attr('data-dept-id');
var empdate=$(".Post_date").attr('data-date');
var fulldetails ='&employee_id='+employee_id+'&employee_code='+employee_code+'&employee_deptid='+employee_deptid+'&empdate='+empdate;
$.ajax({
	  type: "POST",
	  url: "https://shiftsystems.net/demo/index.php?user=ajax",
	  data: 'fulldetails='+fulldetails,

	  success: function(data)
	  {

		  $(".datashown").text(data);
		  $(".datashown").removeClass('btn btn-xs btn-success');
		  $(".datashown").addClass('btn btn-xs btn-danger');
		  $(".datashown").attr('disabled','disabled');

	  }
	});

        })
</script>

<script>
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
</script>
<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>