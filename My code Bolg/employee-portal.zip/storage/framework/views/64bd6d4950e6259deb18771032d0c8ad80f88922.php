<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Employee Portal')); ?></title>

     <?php echo Html::style('https://fonts.googleapis.com/css?family=Lato'); ?>

	 <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" type="text/css">
	  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	  
	
	 <?php echo Html::style('frontassets/libraries/bootstrap-fileinput/css/fileinput.min.css'); ?> 
	 <?php echo Html::style('frontassets/libraries/bootstrap-select/css/bootstrap-select.min.css'); ?> 
	 <?php echo Html::style('frontassets/libraries/bootstrap-wysiwyg/bootstrap-wysiwyg.min.css'); ?> 
	 <?php echo Html::style('frontassets/css/profession-blue-cyan.css'); ?> 
	  <?php echo Html::style('frontassets/fonts/profession/style.css'); ?> 
	 <?php echo Html::style('frontassets/favicon.ico'); ?>

	 
	 <?php echo Html::style('frontassets/css/sidebar.css'); ?> 
	 <?php echo Html::style('frontassets/css/jquery-ui.css'); ?>

	 <style>
	.nav.header-actions li {
		margin: 0;
		padding:0;
	}
	.nav.header-actions li a {
		border: 1px solid rgba(0, 0, 0, 0);
		
		margin: 14px 0;
		padding: 0 5px;
	}
	.dropdown-menu {
		margin: 2px 28px 0;
		padding: 5px;
	}
	.navbar-toggle { top:40px;}
	.nav.header-actions li {
		display: block;
		float: none;
	}

	.nav.header-actions li a {
		background: rgba(0, 0, 0, 0) none repeat scroll 0 0; 
	}
	.bordr{
		border: 1px solid rgb(224, 224, 224);
		cursor:pointer;
		}
	.bordr p{
		padding:4px;
		}
	.bordr .context {
		padding:40px;
		text-align: center;
		} 	
	.item-title{ font-size:16px;}
	.bordrline
	{
	   border-top: 1px solid rgb(224, 224, 224);
		margin: 0 auto;
		width: 40%;
		}
	.fa-bar-chart,.fa-briefcase,.fa-users,.fa-address-card,.fa-usd,.fa-graduation-cap,.fa-file-text,.fa-user-circle,
	.fa-universal-access,.fa-bed,.fa-pencil-square-o,.fa-wrench{color: rgb(54, 176, 187);}

</style>        


</head>

<body class="hero-content-dark footer-dark">
<div class="page-wrapper">
<?php echo $__env->make("templates/header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>

   
	
</body>
</html>
