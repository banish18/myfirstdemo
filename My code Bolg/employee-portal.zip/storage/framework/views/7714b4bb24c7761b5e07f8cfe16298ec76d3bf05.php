<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">
        <div class="page-title">
          <h1>
            All Employee Employement Details
          </h1>
                   </div>



        <div class="row">
        <div class="col-md-2">

					
					<ul class="list-group">
<li class="list-group-item active" >
<a href="<?php echo e(route('employement')); ?>">
<p>
<img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
&nbsp;Lists
</p></a>
</li>
<li class="list-group-item">
           <a  href="<?php echo e(route('employement',array('action' => 'add-appointment'))); ?>">
           <p>
           <img src="<?php echo e(asset('admin-asset/images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add new Employee Letters
           </p></a>
           </li> 
<li class="list-group-item">
           <a  href="<?php echo e(route('employement',array('action' => 'upload-letters'))); ?>">
           <p>
           <img src="<?php echo e(asset('admin-asset/images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Upload Previous Employee Letters
           </p></a>
           </li> 		   
</ul>
        </div>
        <div class="col-md-10">
		

             <div class="row">
            <div class="col-md-12">
            <div class="widget-container fluid-height clearfix">
            <div class="widget-content padded clearfix">
<div class="table-responsive">
<div class="form-group">
            <label class="control-label col-md-2">Search Employee</label>
            <div class="col-md-4">
			<?php echo e(csrf_field()); ?>

               <select data-placeholder="Your Favorite Type of Bear" style="width:350px;" class="chosen-select form-control" tabindex="7" onchange="getLetters(this)"  id="swname">
				<option value="">Search with Name</option> 
				<?php
					$selected = "";
				?>
				 <?php if($data["users"]): ?>
					 <?php $__currentLoopData = $data["users"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if(isset($data["Employeeletters"]) && !$data["Employeeletters"]->isEmpty()): ?>
							<?php
						if($data["user"]->id == $user->id){
								$selected = "selected";
						}else{
							$selected = " ";
						}
							?>							
						<?php endif; ?>	
						<option <?php echo e($selected); ?> value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	 
			  </select>
			  </div>
			  <div class="col-md-5">
	
			 <?php  /* search with Employee Id */ ?>
			  <select data-placeholder="Your Favorite Type of Bear" style="width:350px;" class="chosen-select form-control col-md-4" tabindex="7" onchange="getLetters(this)" id="swid" >
				<option value="">Search with Employee_ID</option> 
				 <?php if($data["users"]): ?>
					 <?php $__currentLoopData = $data["users"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				 <?php if(isset($data["Employeeletters"]) && !$data["Employeeletters"]->isEmpty()): ?>
				 <?php
				 
						if($data["user"]->id == $user->id){
								$selected = "selected";
						}else{
							$selected = " ";
						}
							?>	
					<?php endif; ?>		
						<option <?php echo e($selected); ?> value="<?php echo e($user->uuid); ?>"><?php echo e($user->uuid); ?></option>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>	 
			  </select>
			  
            </div>
          </div>
		  <br />
		  <br />
		  <?php if(isset($data["Employeeletters"]) && !$data["Employeeletters"]->isEmpty()): ?>
			  <div class="form-group"></div>
			  <div class="page-title">
          <h1>
		  <?php echo e($data["user"]->name.'('.$data["user"]->uuid.')'); ?>

          </h1>
                   </div>
			  <div class="col-md-3">
                  	<ul class="list-group employement-ul">
					<li class="list-group-item active" >
					<a href="javascript:void(0)">
					<p>
					<img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
					&nbsp;Letters
					</p></a>
					</li>
					<?php 
					$i = 0;
					?>
					<?php $__currentLoopData = $data["Employeeletters"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Employeeletters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="list-group-item">
						   <a onclick="getempLetter(<?php echo e($Employeeletters->id); ?>,this)"  href="javascript:void(0)">
						   <p>
						   <img src="<?php echo e(asset('admin-asset/images/check-mark.svg')); ?>" width="15">
						   &nbsp;<?php echo e($data["controller"]::getLetter($Employeeletters->letter_type)->name); ?>

						   </p></a>
						   </li> 
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
</ul>
				  </div>
				  <div class="col-md-9 emp_table">
				  <table class="table table-striped" id="dataTable11 ">
                                      <thead>
                    <tr role="row">
                       <th>Employee Name</th>
					   <th>Effective Date</th>
					</tr>
                    </thead>
                                        <tbody id="emp_identi">
						
							<?php $__currentLoopData = $data["Employeeletters"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php 
							$i++;
								if($i == 1){
							?>
								<tr>
									<td><?php echo e($data["controller"]::getUser($letters->uid)->name); ?></td>
									<!--td><a  href="<?php echo e(asset('images/users/letters/'.$letters->letter.'')); ?>" href="javascript:;"><?php echo e($letters->letter); ?> </a></td>
									<td><a href="<?php echo e(route('employement',array('action' => 'deleteAppointment','id' => $letters->id))); ?>">Delete</a></td-->
									<td>
									<?php if($data["controller"]::getUser($letters->uid)->doj == "0000-00-00"): ?>
										<p><input type="text" id="doj" class="form-control" placeholder="Set Joining Date" /><div class="form-group"></div><input type="button" id="joined_btn" class="btn btn-success" value="Save" onclick="saveJoining(<?php echo e($letters->uid); ?>)" /></p>
									<?php else: ?>	
										D.O.J <?php echo e(date("d-M-Y",strtotime($data["controller"]::getUser($letters->uid)->doj))); ?>

									<?php endif; ?>	
									
									</td>
								</tr>
							<?php 
							}
							?>	
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
				  </div>
				  <?php else: ?>
					  <div class="page-title" style="text-align:center;">
          <h1>
           No Records
          </h1>
                   </div>
				  <?php endif; ?>	
					
				  
				  </div>

            </div>
          </div></div>
          </div>
          </div></div></div>

<?php echo $__env->make('templates/admin-footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 <script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>
<script>
$(function(){
	$("#doj").datepicker();
});
$("#setStat").click(function(){
	$("#setjoined").slideDown();
});
function getLetters(elm){
	var swid 	= $("#swid").val();
	var swname 	= $("#swname").val();
	var siteurl 	= "http://portal.mindxpert.com/";
	var user 		= $(elm).val();
	if(swid == ""){
		window.location.assign(siteurl+'/employement/get-letter?user='+user+'&uuid='+swid);
	}else if(swid == "" && swid == user){
		window.location.assign(siteurl+'/employement/get-letter?user='+'&uuid='+swid);
	}else{
		window.location.assign(siteurl+'/employement/get-letter?user='+swname+'&uuid='+swid);
	}
}
function saveJoining(uid){
	var siteurl 	= "http://portal.mindxpert.com/";
	var token = jQuery("input[name=_token]").val();
	var doj = $("#doj").val();
	$.ajax({
		url: siteurl+'/employement/save-joining',
		type: 'POST',
		data: {_token: token,uid:uid,doj:doj},
		dataType: 'JSON',
		success: function (data) {
			location.reload(); 
		}
	}); 
}
function getempLetter(id,elm){
	var siteurl 	= "http://portal.mindxpert.com/";
	$(".employement-ul li").removeClass('setBor');
	var token = jQuery("input[name=_token]").val();
	$.ajax({
		url: siteurl+'/employement/get-empletter',
		type: 'POST',
		data: {_token: token,id:id},
		dataType: 'JSON',
		success: function (data) {
			$(elm).parent().addClass('setBor');
			$("#emp_identi").html(data.result); 
		}
	}); 
}

</script>
<!-- ----------------------END------------------------------------- -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>