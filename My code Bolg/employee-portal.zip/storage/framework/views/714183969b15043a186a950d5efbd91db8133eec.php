	<!-- Login Screen -->
	<div class="login-wrapper">
		<a href="/">
				<img
			src="<?php echo e(asset('images/company-2.png')); ?>" width="150px" />
			 </a>
            <h2>Login</h2>
					 <form class="form-horizontal login-form" role="form" method="POST" action="<?php echo e(route('login')); ?>">
	    <?php echo e(csrf_field()); ?>

			<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
				<div class="input-group">
					<span class="input-group-addon"><i class="lnr lnr-envelope"></i></span><input
						id="email" type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
				</div>
				<?php if($errors->has('email')): ?>
					<span class="help-block">
						<strong><?php echo e($errors->first('email')); ?></strong>
					</span>
				<?php endif; ?>
			</div>
			<div class="form-group">
				<div class="input-group">
					<span class="input-group-addon"><i class="lnr lnr-lock"></i></span><input
						id="password" type="password" class="form-control" name="password" required>
				</div>
				 <?php if($errors->has('password')): ?>
					<span class="help-block">
						<strong><?php echo e($errors->first('password')); ?></strong>
					</span>
				  <?php endif; ?>
			</div>

			<div class="text-left ">
				<a class="pull-right" href="<?php echo e(route('password.request')); ?>">Forgot password?</a>
			<div class="text-left">
          <label class="checkbox">
          <input type="checkbox" name="cookie_set" <?php echo e(old('remember') ? 'checked' : ''); ?> value="true"><span>Keep me logged in</span></label>
        </div>
			</div>

			<input class="btn btn-lg btn-primary btn-block" type="submit"
				value="Log in" name="submit_login">

		</form>


	</div>

<?php echo $__env->make('layouts.admin-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>