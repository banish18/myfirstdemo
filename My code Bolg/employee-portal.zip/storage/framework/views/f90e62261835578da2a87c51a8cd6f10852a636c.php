<?php $__env->startSection('content'); ?>
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Edit Address Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>edit Address Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			<?php echo $__env->make("employee_self_services/profile/sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
		  
		  <form method="post" action="<?php echo e(route('employee-services',array('action' => 'postAddress'))); ?>">
			  <?php echo e(csrf_field()); ?>

		  <div class="col-sm-12" style="border: 1px solid #ccc;">
							
						<div class="page_details_header" style="margin-top:20px;"><em><strong>Family details as present in our record(s)</strong></em>
		               
						</div>
                         
						 <p>Please go to My Profile &gt; My Contacts to edit family details.</p>
						
						
						
						<p class="section_header col-md-4">Address type</p>
						<div class="col-md-8">
						<input class="input-block-level col-md-8" name="address_type" placeholder="Address Type" value="" type="text" required>
						</div>
							<div class="clearfix"></div>
						<p class="section_header col-md-4">Address Line 1</p>
						<div class="col-md-8">
						<textarea class="input-block-level col-md-8" placeholder="Address Line 1" name="address_line1" required></textarea>
						</div>
						<div class="clearfix"></div>
						<p class="section_header col-md-4">Address Line 2</p>
						<div class="col-md-8">
						<div class="clearfix"></div>
						<textarea class="input-block-level col-md-8" name="address_line2" placeholder="Address Line 2" required></textarea>
						</div>
						<div class="clearfix"></div>
						<p class="section_header col-md-4">Primary Address</p>
						<div class="col-md-8">
							<input class="input-block-level col-md-8" placeholder="Primary Address" name="primary_address" value="" type="text" required>
						</div>
						<div class="clearfix"></div>
						<p class="section_header col-md-4">Country</p>
						<div class="col-md-8">
						
							<input class="input-block-level col-md-8" placeholder="Country" name="country" value="" type="text" required>
						</div>
						<div class="clearfix"></div>
						<div class="col-md-3" style="float:right;">
							<input class="btn btn-info col-md-8" name="submit" value="Submit" type="Submit" />
						</div>
						<div class="clearfix"></div>
				 </div>
		  </form>
           
          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
	
	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>