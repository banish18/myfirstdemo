<ul class="navside">
	<li>
		<a class="" href="<?php echo e(route('employee-services',array('action' => 'accommodation-and-transport-initiation'))); ?>">accommodation And Transport Initiation</a>
	</li>
	<li>
		<a class="" href="<?php echo e(route('employee-services',array('action' => 'accomodation-feedback'))); ?>">Accomodation Feedback</a>
	</li>
	<li>
		<a class="" href="<?php echo e(route('employee-services',array('action' => 'long-term-accommodation'))); ?>">Long Term Accommodation</a>
	</li>
</ul>
