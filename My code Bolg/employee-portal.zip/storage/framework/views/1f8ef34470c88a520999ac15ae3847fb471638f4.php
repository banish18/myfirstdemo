<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1>Contact Us</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="document-breadcrumb">
                <div class="container">
                    <ul class="breadcrumb">
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li>Contact Us</li>
                    </ul>
					<?php if(Session::has('success')): ?>
						<section class="seccess">
							<div class="alert alert-success"><em> <?php echo session::get('success'); ?></em></div>
						</section>
					<?php endif; ?>

                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="container">
	<div class="row">
        <div class="col-lg-6">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d9701.242526477665!2d76.7601467824392!3d30.721009490439613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390fedb1fffccd09%3A0xa0483b8de6c7c61d!2sMind+Solutions+Technology!5e0!3m2!1sen!2sin!4v1463042366362" width="100%" height="353px" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
        
        <div class="col-sm-6">
			<div class="widget">
				<h2>Please fill the form</h2>

				<form method="post" action="<?php echo e(route('home',array('action' => 'postContact'))); ?>">
					<?php echo e(csrf_field()); ?>

					<div class="form-group">
                        <input type="text" class="form-control" placeholder="Subject" name="subject">
                    </div><!-- /.form-group -->

                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Your E-mail" name="email">
                    </div><!-- /.form-group -->

                    <div class="form-group">
                        <textarea class="form-control" name="message" rows="5" placeholder="Your Message"></textarea>
                    </div><!-- /.form-group -->

                    <button class="btn btn-secondary pull-right" type="submit">Submit</button>
				</form>
			</div><!-- /.widget -->
		</div><!-- /.col-* -->
        
	</div><!-- /.row -->
</div><!-- /.container -->

        </div><!-- /.main -->
    </div><!-- /.main-wrapper -->
    </div>
</div>
<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>