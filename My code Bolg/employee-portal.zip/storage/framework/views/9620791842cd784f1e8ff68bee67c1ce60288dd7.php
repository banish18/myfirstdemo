<ul class="navside">
	<li>
		<a class="" href="<?php echo e(route('employee-services',array('action' => 'my-requests'))); ?>">My Request</a>
	</li>
	<li>
		<a class="" href="<?php echo e(route('employee-services',array('action' => 'income-from-previous-employeement'))); ?>">Income From Previous Employeement</a>
	</li>
	<li>
		<a class="" href="<?php echo e(route('employee-services',array('action' => 'employee-declaration'))); ?>">Employee Declaration</a>
	</li>
</ul>
