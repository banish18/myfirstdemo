<?php $__env->startSection('content'); ?>
<!-- START MAIN -->
<div id="main">
	 <!-- START WRAPPER -->
    <div class="wrapper">

      <!-- //////////////////////////////////////////////////////////////////////////// -->

      <!-- START CONTENT -->
      <section id="content">
        
        <!--breadcrumbs start-->
        <div id="breadcrumbs-wrapper">
            <!-- Search for small screen -->
            <div class="header-search-wrapper grey hide-on-large-only">
                <i class="mdi-action-search active"></i>
                <input type="text" name="Search" class="header-search-input z-depth-2" placeholder="Explore Materialize">
            </div>
          <div class="container">
		  <div class="container">
            <div class="row">
              <div class="col s12 m9">
                <h5 class="breadcrumbs-title"><?php echo e($data['title']); ?></h5>
                <ol class="breadcrumbs">
                    <li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <li class="active"><?php echo e($data['title']); ?></li>
                </ol>
              </div>
            </div>
          </div>
		  </div>
        </div>
        <!--breadcrumbs end-->
        <!--start container-->
        <div class="container">
		<div class="container">
          <div class="section">
            <!--DataTables example Row grouping-->
            <div id="row-grouping" class="section">
            
              <div class="row">
                <div class="col s12 m12">
					 <!--Input fields-->
					<div id="input-fields">
					  <div class="row">
						<div class="col s12 m12">
						  <div class="row">
							<form class="col s12" action="<?php echo e(route('users',array('action' => 'postUpdate'))); ?>" method="post">
							 <?php echo e(csrf_field()); ?>

							  <div class="row">
								<div class="input-field col s6">
								  <input placeholder="Placeholder" id="first_name" name="first_name" type="text" class="validate" value="<?php echo e($data['user']->f_name); ?>" required />
								  <label for="first_name">First Name</label>
								   <?php if($errors->has('first_name')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('first_name')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
								<div class="input-field col s6">
								  <input id="last_name" name="last_name" type="text" class="validate" value="<?php echo e($data['user']->l_name); ?>" required />
								  <label for="last_name">Last Name</label>
								   <?php if($errors->has('last_name')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('last_name')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
							  </div>
							   <div class="row">
								<div class="input-field col s6">
								  <input id="email" name="email" type="email" class="validate" value="<?php echo e($data['user']->email); ?>" required>
								  <label for="email">Email</label>
								  <?php if($errors->has('email')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('email')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
								<div class="input-field col s6">
								   <input id="designation" name="designation" type="text" class="validate" value="<?php echo e($data['user']->designation); ?>" required>
								  <label for="email">Designation*</label>
								   <?php if($errors->has('designation')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('designation')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
							  </div>
							  
							   <div class="row">
								<div class="input-field col s6">
								   <input id="company" name="company" type="text" class="validate" value="<?php echo e($data['user']->company); ?>" required>
								  <label for="password">Company</label>
								  <?php if($errors->has('company')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('company')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
								<div class="input-field col s6">
								  <input id="salary" name="salary" type="text" class="validate"value="<?php echo e($data['user']->salary); ?>" required>
								  <label for="email">Salary</label>
								  <?php if($errors->has('salary')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('salary')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
							  </div>
							  <div class="row">
								<div class="input-field col s6">
								   <input id="dob" name="dob" type="text" class="datepicker" value="<?php echo e($data['user']->dob); ?>" required />
								  <label for="password">Date of Birth</label>
								  <?php if($errors->has('dob')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('dob')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
								<div class="input-field col s6">
								  <input id="f_h" name="f_h" type="text" class="validate" value="<?php echo e($data['user']->f_h); ?>" required>
								  <label for="email">Father/Husband*</label>
								   <?php if($errors->has('f_h')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('f_h')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
							  </div>
							  
							  <div class="row">
								<div class="input-field col s6">
								   <input id="phone_number" name="phone_number" type="text" class="validate" value="<?php echo e($data['user']->phone_number); ?>" required>
								  <label for="password">Mobile Number</label>
								  <?php if($errors->has('phone_number')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('phone_number')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
								<div class="input-field col s6">
								   <input id="doj" name="doj" type="text" class="datepicker" value="<?php echo e($data['user']->doj); ?>" required>
								  <label for="password">Date Of Joining</label>
								  <?php if($errors->has('doj')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('doj')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
								</div>
							  </div>
							
							  <div class="row">
								<div class="input-field col s12">
								   <textarea id="address" name="address" class="validate" required><?php echo e($data['user']->address); ?></textarea>
								  <label for="email">Address*</label>
								  <?php if($errors->has('address')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('address')); ?></strong>
										</span>
									<?php endif; ?>
								</div>
							  </div>
							  <div class="row">
								 <div class="col s12 m12">
								  <input name="id" type="hidden" class="validate" value="<?php echo e($data['user']->id); ?>" />
									 <div class="action-button">
										  <a class="btn waves-effect waves-light " href="<?php echo e(route('users')); ?>" name="action">Cancel
											
										  </a>
										  <button class="btn waves-effect waves-light " type="submit" name="action">Submit</button>
									 </div>
									 
								   </div>
							  </div>
							  <br>
							  
							</form>
						  </div>
						</div>
					  </div>
					</div>
                </div>
              </div>
            </div>
          </div>
        </div>
		</div>
        <!--end container-->
      </section>
      <!-- END CONTENT -->

      <!-- //////////////////////////////////////////////////////////////////////////// -->
    </div>
    <!-- END WRAPPER -->
</div>
<!-- END MAIN -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>