<?php $__env->startSection('content'); ?>
<div class="container-fluid main-content">

<div class="row">
  <div class="col-md-2">

        <div class="widget-container fluid-height" >
              <div class="widget-content">

                <div class="panel-group" id="accordion">
                  <div class="panel">
                    <div class="panel-heading">
                    </div>
                  </div>
                  <div class="panel">
                    <div class="panel-heading">
                      <div class="panel-title">
                      </div>
                    </div>
                    <div class="panel-collapse collapse in" id="collapseTwo">
                    </div>
                  </div>
                 
                </div>
              </div>
            </div>
<br>
		<ul class="list-group">
			<li class="list-group-item active" >
			<a href="<?php echo e(route('notes')); ?>">
           <p>
            <img src="<?php echo e(asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg')); ?>" width="15">
           &nbsp;List Notes
           </p></a>
           </li>

           <li class="list-group-item">
           <a  href="<?php echo e(route('notes',array('action' => 'add'))); ?>">
           <p>
           <img src="<?php echo e(asset('images/plus-sign-in-circle.svg')); ?>" width="15">
           &nbsp;Add Note
           </p>
           </a>
           </li>
           
            </ul>


         </div>

  <div class="col-md-10">

          <div class="col-md-12">
            <div class="widget-container fluid-height">
				<div class="heading">
				   <h4>Note Details</h4>
				 </div>
				 <div class="widget-content padded">
				  <strong>Title</strong>
				   <p><?php echo e($data['note']->title); ?></p>
					<strong>Description</strong>
					 <p><?php echo e($data['note']->desc); ?></p>
				 </div>
		  </div>
		   </div>
 
        </div>

</div>

</div>
<?php echo $__env->make("templates/admin-footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('layouts.admin-pagesapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>