<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="utf-8" />
<title>Payslip</title>
<style>
<style>
/* CSS Document */
html, body, div, span, object, iframe,h1, h3, h5, h6, p, blockquote, pre,abbr, address, cite, code,del, dfn, em, img, ins, kbd, q, samp,small, strong, sub, sup, var,b, i,dl, dt, dd, ol, ul, li,fieldset, form, label, legend,table, caption, tbody, tfoot, thead, tr, th, td,article, aside, canvas, details, figcaption, figure, footer, header, hgroup, menu, nav, section, summary,time, mark, audio,video{margin:0;padding:0;outline:0;font-size:100%;vertical-align:baseline;background:transparent;}
body {line-height:1;font-family: 'Lato', sans-serif;}
article,aside,details,figcaption,figure,
footer,header,hgroup,menu,nav,section{display:block;}
header{float:left; width:1170px; background-color:#FFF;}
.wrapper{float:left; width:1170px; background-color:#000;}
.auto{width:1170px; margin:0 auto;}
h2{margin:0; padding:0;}
.logo{float:right;}
.left{ float:left; width:250px;}
table{ background-color:#FFF;}
table, th{ text-align:left; border-color:#666; }
table, th, td {border-collapse: collapse;padding:5px;}
.sub-heading{background-color:#1998d2; color:#FFF; font-weight:bold;}
.mg0pd0{margin:0;padding:0;}
.mg10{margin-top:10px;}
.note{width:400px; float:left; margin-bottom:10px;}
.clear{clear:both;}
.fnt{ font-weight:bold;}
.hyt{ height:200px;}
.retrails{float:left; width:305px;}
.net{float:right;width:200px;}
.net-pay{border:2px solid #333; background-color:#1998d2; color:#FFF;}
.border{border:1px solid #333;}
.date{ color:#555; margin-left:10px;}
.mgbotm{margin-bottom:10px;}
</style>
</style>
</head>

<body>
<div class="auto">
<header>
<div class="left">
<h2 class="mg10">Payslip</h2>
<h2 class="mg10">Feb 2016</h2>
</div>
<div class="logo mg10">
<img src="http://portal.mindxpert.com/images/company-2.png" alt="Logo" />
</div>
</header>
 <table border="1" style="width:100%">
   <thead>
              <tr class="heading">
                <th colspan="0"><div class="name">Mr. Vikas Chaudhary</div></th>
              </tr>
             
              
            </thead>
      <tbody>
<tr class="sub-heading">
<th colspan="6">Employee Details</th>
<th colspan="8">Payment & Leave Details</th>
<th colspan="5">Location Details</th>
</tr>
<tr>
<td class="fnt" colspan="2">Emp No.</td>
<td colspan="4">475038</td>
<td class="fnt" colspan="1">Bank Name</td>
<td colspan="7">ICICI</td>
<td class="fnt" colspan="2">Location</td>
<td colspan="2">Chandigarh</td>
</tr>
<tr>
<td class="fnt" colspan="2">Dsgn.</td>
<td colspan="4">I.T. Analyst</td>
<td class="fnt" colspan="1">Acc</td>
<td colspan="7">00586236599</td>
<td class="fnt" colspan="2">Base Br.</td>
<td colspan="1">TCS - New Delhi</td>
</tr>
<tr>
<td class="fnt" colspan="2">Grade</td>
<td colspan="2">C2</td>
<td class="fnt" colspan="1">UAN</td>
<td colspan="1">1005861854</td>
<td class="fnt" colspan="1">Days Paid</td>
<td colspan="7">31</td>
<td class="fnt" colspan="2">Depute Br.</td>
<td colspan="2">TCS - New Delhi</td>
</tr>
<tr>
<td class="fnt" colspan="2">PAN</td>
<td colspan="4">A01555dsf</td>
<td class="fnt" colspan="1">LEAVE BALANCE</td>
<td class="fnt" colspan="1">EL</td>
<td colspan="1">52.00</td>
<td class="fnt" colspan="1">SL</td>
<td colspan="1">30.59</td>
<td class="fnt" colspan="1">CL</td>
<td colspan="2">3.50</td>
<td class="fnt" colspan="2">WON/SWON</td>
<td colspan="1">2156489</td>
</tr>
</tbody>
</table>


<table class="mg10" border="1" style="width:100%;">
   <thead>
<tr class="sub-heading">
<th colspan="6">Earnings</th>
<th colspan="6">Arrears</th>
<th colspan="3">Current</th>
<th colspan="7">Deductions</th>
<th colspan="5">Amount</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="9">Basic Salary</td>
<td colspan="3">&nbsp;</td>
<td colspan="3">16,800.00</td>
<td colspan="7">Provident Fund</td>
<td colspan="5">2,016.00</td>
</tr>
<tr>
<td colspan="9">Bob Kitty Allowance</td>
<td colspan="3">&nbsp;</td>
<td colspan="3">5,682.00</td>
<td colspan="7">Income Tax</td>
<td colspan="5">5,736.00</td>
</tr>
<tr>
<td colspan="9">Convanyance Taxable</td>
<td colspan="3">&nbsp;</td>
<td colspan="3">200.00</td>
<td colspan="7">Health Insurance Scheme Premium</td>
<td colspan="5">4,045.00</td>
</tr>
<tr>
<td colspan="9">Convanyance Non Taxable</td>
<td colspan="3">&nbsp;</td>
<td colspan="3">200.00</td>
</tr>
<tr>
<td colspan="9">House Rent Allowance</td>
<td colspan="3">&nbsp;</td>
<td colspan="3">1,600.00</td>
</tr>
<tr>
<td colspan="9">Sundry Medical</td>
<td colspan="3">&nbsp;</td>
<td colspan="3">8,000.00</td>
</tr>
<tr>
<td colspan="9">Leave Travel Allowance</td>
<td colspan="3">&nbsp;</td>
<td colspan="3">1,250.00</td>
</tr>
<tr>
<td colspan="9">Personal Allowance</td>
<td colspan="3">&nbsp;</td>
<td colspan="3">1,169.00</td>
</tr>
<tr>
<td colspan="9">Misscellaneous</td>
<td colspan="3">&nbsp;</td>
<td colspan="3">9,600.00</td>
</tr>
<tr>
<td colspan="9">City Allowance</td>
<td colspan="3">&nbsp;</td>
<td colspan="3">1,800.00</td>
</tr>

<td colspan="9">Performance Pay</td>
<td colspan="3">&nbsp;</td>
<td colspan="3">13,800.00</td>
</tr>
<tr>
<td colspan="14" class="hyt"></td>
<td  class="hyt" colspan="13"></td>
</tr>
<tr>
<td colspan="12" style="border-right:none;">Total Earnings</td>
<td colspan="2" style="border-left:none;" >64,148.00</td>
<td colspan="12" style="border-right:none;" >Total Deductions</td>
<td colspan="2" style="border-left:none;">11,797.00</td>
</tr>

</tbody>
</table>


<table class="mg10 retrails">
<tr>
    <th class="net-pay" rowspan="2">Retrials as on Month end</th>
    <td class="border">Provident fund*</td>
  </tr>
  <tr>
    <td class="border">1,79,565.00</td>
  </tr>
</table>
<table class="mg10 net">
<tr>
    <td class="net-pay" rowspan="2">Net Pay</td>
    <td class="border">52,351.00</td>
  </tr>
</table>
<div class="clear">
<h5 class="mg0pd0 note">*Inclusive of provisional interest</h5>
</div>

<table border="1" class="mg10" style="width:100%;">
   <thead>
<tr class="sub-heading">
<th colspan="14">Projected Annual Tax Income</th>
<th colspan="17">Chapter Via Relief</th>
</tr>
</tr>
</thead>
<tbody>
<tr>
<td colspan="8">Anual Income*</td>
<td colspan="3">43,000,00</td>
<td colspan="2">Net tax Income r/o</td>
<td colspan="1">6,63,880.00</td>
<td colspan="15">80C</td>
<td colspan="2">24,192.00</td>
</tr>
<tr>
<td colspan="8">Chapter Via Relief</td>
<td colspan="3">7,00,000,00</td>
<td colspan="2">Total Tax Payable</td>
<td colspan="1">59,000.00</td>
<td colspan="15">80D</td>
<td colspan="5">19,776.00</td>
</tr>
<tr>
<td colspan="8"></td>
<td colspan="3"></td>
<td colspan="2">Tax Deducted Till Date</td>
<td colspan="1">33,197.00</td>
<td colspan="15">&nbsp;</td>
<td colspan="5">&nbsp;</td>
</tr>
<tr>
<td colspan="8"></td>
<td colspan="3"></td>
<td colspan="2">Balance Tax</td>
<td colspan="1">26,310.00</td>
<td colspan="15">&nbsp;</td>
<td colspan="5">&nbsp;</td>
</tr>
<tr style="height:20px;">
<td colspan="8">&nbsp;</td>
<td colspan="3">&nbsp;</td>
<td colspan="2">&nbsp;</td>
<td colspan="1">&nbsp;</td>
<td colspan="15">&nbsp;</td>
<td colspan="5">&nbsp;</td>
</tr>

</tbody>
</table>


<table border="1" style="width:100%; margin-top:10px;">
<thead>
<tr class="sub-heading">
<th colspan="16">Investment Description</th>
<th colspan="16">Exemption Considered*</th>
</tr>
</thead>
<tbody>
<tr>
<td colspan="5">80D-Medical Premium</td>
<td colspan="1">3,956.00</td>
<td colspan="5"> </td>
<td colspan="5"> </td>
<td colspan="9">Conveyance</td>
<td colspan="5">19,200</td>
</tr>
<tr>
<td colspan="5">80D-Medical Premium</td>
<td colspan="1">16,180,00</td>
<td colspan="5">&nbsp;</td>
<td colspan="5">&nbsp;</td>
<td colspan="9">&nbsp;</td>
<td colspan="5">&nbsp;</td>
</tr>
<tr>
<td colspan="5">PF Contribution</td>
<td colspan="1">24,192.00</td>
<td colspan="5">&nbsp;</td>
<td colspan="5">&nbsp;</td>
<td colspan="9">&nbsp;</td>
<td colspan="5">&nbsp;</td>
</tr>



</tbody>
</table>
<h6 class="mg0pd0">*Please Note, Annual Income is after considering the above exemption - if any.</h6>
<div class="mg10 mgbotm">Payslip generated on:  <span class="date">29 Aug 2015,21:03:13</span></div>

</div>
</body>
</html>
