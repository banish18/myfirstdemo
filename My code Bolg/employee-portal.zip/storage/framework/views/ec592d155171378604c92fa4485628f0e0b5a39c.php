<?php $__env->startSection('content'); ?>

  <div class="main-wrapper">

    <div class="main">

	 

	

	

      <div class="document-title">

        <div class="container">

          <h1 class="center">Employee - Accomodation Request </h1>

        </div>

        <!-- /.container --> 

      </div>

      <!-- /.document-title -->

	  

	    <div class="document-breadcrumb">

		 	<div class="container">

				<ul class="breadcrumb">

					<li>

						<a href="/">Home</a>

					</li>
					
					<li>

						<a href="<?php echo e(route('employee-services',array('action' => 'travel'))); ?>">Travel</a>

					</li>

					<li>Employee - Accomodation Request </li>

				</ul>

			</div>

		</div>

      <div class="container mb40">

        <div class="row">
		 <div class="col-md-3">

			<div class="row">

			<div class="col-lg-12 project-menu">

			<div class="box-sidebar side-menu-main project-menu">

			<div class="box-head-dark">

			<i class="fa fa-bars"></i>

			Domestic Menu

			</div>

			<div class="box-content">

			<?php echo $__env->make("employee_self_services/travel/international/sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			</div>

			</div>

			</div>

		</div>

		</div>

          <div class="col-sm-9">
				 <div class="document-title">
                <div class="container">
                    <h1 class="center">Domestic Business Travel Initiation for Self/Guest</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="container">
	<div class="row">
		<div class="col-sm-12">
			<ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active">
					<a href="#personal" aria-controls="personal" role="tab" data-toggle="tab">
						<strong>Input Details</strong>
						<span></span>
					</a>
				</li>

				<li role="presentation">
					<a href="#additional" aria-controls="additional" role="tab" data-toggle="tab">
						<strong>Additional Details</strong>
						<span></span>
					</a>
				</li>
                
                <li role="presentation">
					<a href="#validate" aria-controls="validate" role="tab" data-toggle="tab">
						<strong>Validate Data</strong>
						<span></span>
					</a>
				</li>
			</ul>
           
            
			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="personal">
					<div class="row">
						<div class="col-sm-12">
                         <ul class="nav nav-tabs" role="tablist">
                         <li role="presentation" class="active">
                            <a href="#employee" aria-controls="employee" role="tab" data-toggle="tab">
                                <strong>Employee Profile</strong>
                                <span></span>
                            </a>
                         </li>
        
                         <li role="presentation">
                            <a href="#allocation" aria-controls="allocation" role="tab" data-toggle="tab">
                                <strong>Allocation Details</strong>
                                <span></span>
                            </a>
                        </li>
                        </ul>
						<div class="tab-content">
							 <div role="tabpanel" class="tab-pane active" id="employee">
									<div class="row">
										<div class="col-sm-12">
									 <table class="table-bordered">
<tbody>
<tr>
<td>
<table>
<tbody>
<tr>
<td>
<b>Role</b>
</td>
<td> Developer </td>
</tr>
</tbody>
</table>
</td>
<td>
<table>
<tbody>
<tr>
<td>
<b>Home Country</b>
</td>
<td>101</td>
</tr>
</tbody>
</table>
</td>
<td>
<table>
<tbody>
<tr>
<td>
<b>Current Country</b>
</td>
<td>India</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<table>
<tbody>
<tr>
<td>
<b>Employment Status</b>
</td>
<td>Active Assignment</td>
</tr>
</tbody>
</table>
</td>
<td>
<table>
<tbody>
<tr>
<td>
<b>Base Branch</b>
</td>
<td> Tcs - New Delhi</td>
</tr>
</tbody>
</table>
</td>
<td>
<table>
<tbody>
<tr>
<td>
<b>Depute Branch</b>
</td>
<td> Delhi </td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<table>
<tbody>
<tr>
<td>
<b>Employee Type</b>
</td>
<td>Emp</td>
</tr>
</tbody>
</table>
</td>
<td>
<table>
<tbody>
<tr>
<td>
<b>Base DC</b>
</td>
<td>New Delhi - Non Stp</td>
</tr>
</tbody>
</table>
</td>
<td>
<table>
<tbody>
<tr>
<td>
<b>Current DC</b>
</td>
<td> Chandigarh - Non Stp</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<table>
<tbody>
<tr>
<td>
<b>Depute IOU</b>
</td>
<td>NGM-India1.4-Group4</td>
</tr>
</tbody>
</table>
</td>
<td> </td>
<td>
<table>
<tbody>
<tr>
<td>
<b>Company Name</b>
</td>
<td> Tata Consultancy Services</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<table>
<tbody>
<tr>
<td>
<b>Parent Base IOU</b>
</td>
<td>NGM-India1-Parent</td>
</tr>
</tbody>
</table>
</td>
<td>
<table>
<tbody>
<tr>
<td>
<b>Nationality</b>
</td>
<td>indian</td>
</tr>
</tbody>
</table>
</td>
<td> </td>
</tr>
</tbody>
</table>
<br />
<table class="table-bordered" width="100%" cellpadding="0">
<tbody>
<tr class="TAWLDBSpanFull">
<td colspan="4">
<span class="intermediateHeader">Travel Details</span>
</td>
</tr>
<tr class="TAWLDBSpanFull">
<td>
<span style="font-family:Arial;font-size:8pt;font-weight:bold;">Reason For Travel</span>
</td>
<td>
<select id="tvlInit:travelReason" class="dropDownStyle" name="tvlInit:travelReason" size="1" style="float:left;width:200px;" onchange="submit()">
<option value="Select">Select</option>
<option value="157">Domestic - Deputation</option>
<option value="2076">Transfer-Company initiated</option>
<option value="2077">Transfer-Self initiated</option>
</select>
</td>
<td></td>
<td></td>
</tr>

</tbody>
</table>



				 
									</div><!-- /.col-* -->
									</div><!-- /.row --> 
                                      
							</div><!-- /.tab-pane -->
					
						   <div role="tabpanel" class="tab-pane" id="allocation">
								<div class="row">
									<div class="col-sm-12">
									<table width="100%">
<tbody>
<tr>
<td>
<div>
<table class="table-bordered">
<thead>
<tr>
<th class="reportsHeader">Type Of Allocation</th>
<th class="reportsHeader">Project Number</th>
<th class="reportsHeader">Project Name</th>
<th class="reportsHeader">Allocation Start Date</th>
<th class="reportsHeader">Allocation End Date</th>
<th class="reportsHeader">Supervisor Name</th>
<th class="reportsHeader">GL/BRM's Name</th>
<th class="reportsHeader">City</th>
<th class="reportsHeader">Country</th>
<th class="reportsHeader">Region</th>
<th class="reportsHeader">Client Name</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<span>Current</span>
</td>
<td>
<span>2663814</span>
</td>
<td class="coltextcenteralign">
<span class="BodyFont">BSNL CDR 1 SE AMC Service</span>
</td>
<td class="coltextcenteralign">
<span class="BodyFont">Oct-01-2016</span>
</td>
<td class="coltextcenteralign">
<span class="BodyFont">Dec-31-2016</span>
</td>
<td class="coltextcenteralign">
<span class="BodyFont">Priyanka Garg</span>
</td>
<td class="coltextcenteralign">
<span class="BodyFont">Shailendra Mohan</span>
</td>
<td class="coltextcenteralign">
<span class="BodyFont">Hyderabad</span>
</td>
<td class="coltextcenteralign">
<span class="BodyFont">India</span>
</td>
<td class="coltextcenteralign">
<span class="BodyFont">Telangana Telangana </span>
</td>
<td class="coltextcenteralign">
<span class="BodyFont">HCL INFOTECH LTD.</span>
</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>


									</div><!-- /.col-* -->
								</div><!-- /.row -->   
							</div><!-- /.tab-pane -->
                
						</div><!-- /.col-* -->
                     </div><!-- /.col-* -->
				   </div><!-- /.row -->   
				</div><!-- /.tab-pane -->  
                 
                 
                 <div role="tabpanel" class="tab-pane" id="additional">
					<div class="row">
						<div class="col-sm-12">
                         <ul class="nav nav-tabs" role="tablist">
							 <li role="presentation" class="active">
								<a href="#delifrom" aria-controls="delifrom" role="tab" data-toggle="tab">
									<strong>Delegated From</strong>
									<span></span>
								</a>
							 </li>
							 
							 
							 
							 <li role="presentation">
								<a href="#delito" aria-controls="delito" role="tab" data-toggle="tab">
									<strong>Delegated To</strong>
									<span></span>
								</a>
							</li>
                        </ul>
                        
                        
                        <div class="tab-content">
							 <div role="tabpanel" class="tab-pane active" id="delifrom">
									<div class="row">
										<div class="col-sm-12">
									  <h3>Request Details</h3>
<form style="padding:15px;" method="post" action="http://portal.mindxpert.com/travel/add">
<input name="_token" value="41QYUK0m34mhsKRPFTwNc4DctfylOJFUqqTuIw69" type="hidden">
<table class="table-bordered">
<thead>
<tr>
<th>Travelling S/WON Details</th>
<th>Ticketing Location Details</th>
<th>Preferred Mode Of Travel</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<span class="BodyFont" style="color: red">*</span>
S/WON
</td>
<td>
Ticketing Location
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Change" style="vertical-align:bottom;align:center" type="submit">
<div id="ticket_setting" style="display: none;">
<div class="form-group">
<label style="font-size:9px;">
<span class="BodyFont" style="color: red">*</span>
Ticket Processing Country
</label>
<select name="ticket_processing_country">
<option value="0">Select Country</option>
<option value="1">India</option>
</select>
</div>
<div class="form-group">
<label style="font-size:9px;">
<span class="BodyFont" style="color: red">*</span>
Ticketing Branch
</label>
<select name="ticket_processing_branch">
<option value="0">Select Branch</option>
<option value="1">A</option>
</select>
</div>
<div class="form-group">
<label style="font-size:9px;">
<span class="BodyFont" style="color: red">*</span>
Ticketing Location
</label>
<select name="ticket_processing_location">
<option value="0">Select Location</option>
<option value="1">A</option>
</select>
</div>
</div>
</td>
<td>
Mode of Travel
<select name="travel_mode">
<option value="Air">Air</option>
<option value="Rail">Rail</option>
<option value="Sea">Sea</option>
<option value="=own-arranged">Road � Own Arranged Vehicles</option>
<option value="company-arranged">Road- Company Arranged Vehicles</option>
</select>
</td>
</tr>
</tbody>
</table>
<h3>Travel Itinerary</h3>
<table>
<tbody>
<tr>
<td> </td>
<td>
Travel Request For
<input name="request_for" value="return" type="radio">
Return
<input name="request_for" value="oneway" type="radio">
oneWay
<input name="request_for" value="multiCity" type="radio">
Multi-City
</td>
<td> </td>
</tr>
</tbody>
</table>
<div class="innr">
<div class="form-group">
<label for="from">
<span class="BodyFont" style="color: red">*</span>
From:
</label>
<input id="from" class="form-control" name="from" required type="text">
</div>
<div class="form-group">
<label for="to">
<span class="BodyFont" style="color: red">*</span>
To:
</label>
<input id="to" class="form-control" name="to" required type="text">
</div>
<div class="form-group">
<label for="depart">
<span class="BodyFont" style="color: red">*</span>
Depart On:
</label>
<input id="depart_on" class="form-control" name="depart_date" required type="date">
</div>
<div class="form-group">
<label for="return">
<span class="BodyFont" style="color: red">*</span>
Return On:
</label>
<input id="return_on" class="form-control" name="return_date" required type="date">
</div>
<div class="form-group">
<label for="duration">
<span class="BodyFont" style="color: red">*</span>
Duration of Stay:
</label>
<input id="duration_of_stay" class="form-control" name="duration_of_stay" required type="text">
night(s)
</div>
<div class="form-group">
<label for="email">
<span class="BodyFont" style="color: red">*</span>
Purpose of Visit:
</label>
<select name="purpose" required="required">
<option value="Business Discussion">Business Discussion</option>
<option value="To attend Conference/Seminars">To attend Conference/Seminars</option>
<option value="To conduct Conference/Seminars">To conduct Conference/Seminars</option>
<option value="Accompanying Client">Accompanying Client</option>
<option value="To Impart Training">To Impart Training</option>
<option value="To Receive Training">To Receive Training</option>
<option value="Support TCSL office">Support TCSL office</option>
<option value="Project Work">Project Work</option>
<option value="Audit">Audit</option>
<option value="Business Meetings/Presentations">Business Meetings/Presentations</option>
<option value="Knowledge transfer">Knowledge transfer</option>
<option value="Architects visit for TCS project">Architects visit for TCS project</option>
<option value="External consultant for TCS Projects">External consultant for TCS Projects</option>
<option value="TCS invitees">TCS invitees</option>
<option value="Return Travel">Return Travel</option>
<option value="Others">Others</option>
</select>
</div>
<div class="form-group">
<label for="email">Visting Location:</label>
<input id="email" class="form-control" name="visit_location" type="text">
</div>
</div>
<div class="form-group">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Next" style="vertical-align:bottom;align:center" type="submit">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="SaveasDraft" style="vertical-align:bottom;align:center" type="submit">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Reset" style="vertical-align:bottom;align:center" type="submit">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Cancel" style="vertical-align:bottom;align:center" type="submit">
</div>
</form>
				 
									</div><!-- /.col-* -->
									</div><!-- /.row -->   
							</div><!-- /.tab-pane -->
					
						   <div role="tabpanel" class="tab-pane" id="delito">
								<div class="row">
									<div class="col-sm-12">
									<h3>Request Details</h3>
<form style="padding:15px;" method="post" action="http://portal.mindxpert.com/travel/add">
<input name="_token" value="41QYUK0m34mhsKRPFTwNc4DctfylOJFUqqTuIw69" type="hidden">
<table class="table-bordered">
<thead>
<tr>
<th>Travelling S/WON Details</th>
<th>Ticketing Location Details</th>
<th>Preferred Mode Of Travel</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<span class="BodyFont" style="color: red">*</span>
S/WON
</td>
<td>
Ticketing Location
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Change" style="vertical-align:bottom;align:center" type="submit">
<div id="ticket_setting" style="display: none;">
<div class="form-group">
<label style="font-size:9px;">
<span class="BodyFont" style="color: red">*</span>
Ticket Processing Country
</label>
<select name="ticket_processing_country">
<option value="0">Select Country</option>
<option value="1">India</option>
</select>
</div>
<div class="form-group">
<label style="font-size:9px;">
<span class="BodyFont" style="color: red">*</span>
Ticketing Branch
</label>
<select name="ticket_processing_branch">
<option value="0">Select Branch</option>
<option value="1">A</option>
</select>
</div>
<div class="form-group">
<label style="font-size:9px;">
<span class="BodyFont" style="color: red">*</span>
Ticketing Location
</label>
<select name="ticket_processing_location">
<option value="0">Select Location</option>
<option value="1">A</option>
</select>
</div>
</div>
</td>
<td>
Mode of Travel
<select name="travel_mode">
<option value="Air">Air</option>
<option value="Rail">Rail</option>
<option value="Sea">Sea</option>
<option value="=own-arranged">Road � Own Arranged Vehicles</option>
<option value="company-arranged">Road- Company Arranged Vehicles</option>
</select>
</td>
</tr>
</tbody>
</table>
<h3>Travel Itinerary</h3>
<table>
<tbody>
<tr>
<td> </td>
<td>
Travel Request For
<input name="request_for" value="return" type="radio">
Return
<input name="request_for" value="oneway" type="radio">
oneWay
<input name="request_for" value="multiCity" type="radio">
Multi-City
</td>
<td> </td>
</tr>
</tbody>
</table>
<div class="innr">
<div class="form-group">
<label for="from">
<span class="BodyFont" style="color: red">*</span>
From:
</label>
<input id="from" class="form-control" name="from" required type="text">
</div>
<div class="form-group">
<label for="to">
<span class="BodyFont" style="color: red">*</span>
To:
</label>
<input id="to" class="form-control" name="to" required type="text">
</div>
<div class="form-group">
<label for="depart">
<span class="BodyFont" style="color: red">*</span>
Depart On:
</label>
<input id="depart_on" class="form-control" name="depart_date" required type="date">
</div>
<div class="form-group">
<label for="return">
<span class="BodyFont" style="color: red">*</span>
Return On:
</label>
<input id="return_on" class="form-control" name="return_date" required type="date">
</div>
<div class="form-group">
<label for="duration">
<span class="BodyFont" style="color: red">*</span>
Duration of Stay:
</label>
<input id="duration_of_stay" class="form-control" name="duration_of_stay" required type="text">
night(s)
</div>
<div class="form-group">
<label for="email">
<span class="BodyFont" style="color: red">*</span>
Purpose of Visit:
</label>
<select name="purpose" required="required">
<option value="Business Discussion">Business Discussion</option>
<option value="To attend Conference/Seminars">To attend Conference/Seminars</option>
<option value="To conduct Conference/Seminars">To conduct Conference/Seminars</option>
<option value="Accompanying Client">Accompanying Client</option>
<option value="To Impart Training">To Impart Training</option>
<option value="To Receive Training">To Receive Training</option>
<option value="Support TCSL office">Support TCSL office</option>
<option value="Project Work">Project Work</option>
<option value="Audit">Audit</option>
<option value="Business Meetings/Presentations">Business Meetings/Presentations</option>
<option value="Knowledge transfer">Knowledge transfer</option>
<option value="Architects visit for TCS project">Architects visit for TCS project</option>
<option value="External consultant for TCS Projects">External consultant for TCS Projects</option>
<option value="TCS invitees">TCS invitees</option>
<option value="Return Travel">Return Travel</option>
<option value="Others">Others</option>
</select>
</div>
<div class="form-group">
<label for="email">Visting Location:</label>
<input id="email" class="form-control" name="visit_location" type="text">
</div>
</div>
<div class="form-group">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Next" style="vertical-align:bottom;align:center" type="submit">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="SaveasDraft" style="vertical-align:bottom;align:center" type="submit">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Reset" style="vertical-align:bottom;align:center" type="submit">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Cancel" style="vertical-align:bottom;align:center" type="submit">
</div>
</form>
									</div><!-- /.col-* -->
								</div><!-- /.row -->   
							</div><!-- /.tab-pane -->
                
						</div><!-- /.col-* -->
					</div><!-- /.row -->   
				</div><!-- /.tab-pane -->
				</div>
                
                
                
                <div role="tabpanel" class="tab-pane" id="validate">
					<div class="row">
						<div class="col-sm-12">
                         
                        <h3>Request Details</h3>
<form style="padding:15px;" method="post" action="http://portal.mindxpert.com/travel/add">
<input name="_token" value="41QYUK0m34mhsKRPFTwNc4DctfylOJFUqqTuIw69" type="hidden">
<table class="table-bordered">
<thead>
<tr>
<th>Travelling S/WON Details</th>
<th>Ticketing Location Details</th>
<th>Preferred Mode Of Travel</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<span class="BodyFont" style="color: red">*</span>
S/WON
</td>
<td>
Ticketing Location
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Change" style="vertical-align:bottom;align:center" type="submit">
<div id="ticket_setting" style="display: none;">
<div class="form-group">
<label style="font-size:9px;">
<span class="BodyFont" style="color: red">*</span>
Ticket Processing Country
</label>
<select name="ticket_processing_country">
<option value="0">Select Country</option>
<option value="1">India</option>
</select>
</div>
<div class="form-group">
<label style="font-size:9px;">
<span class="BodyFont" style="color: red">*</span>
Ticketing Branch
</label>
<select name="ticket_processing_branch">
<option value="0">Select Branch</option>
<option value="1">A</option>
</select>
</div>
<div class="form-group">
<label style="font-size:9px;">
<span class="BodyFont" style="color: red">*</span>
Ticketing Location
</label>
<select name="ticket_processing_location">
<option value="0">Select Location</option>
<option value="1">A</option>
</select>
</div>
</div>
</td>
<td>
Mode of Travel
<select name="travel_mode">
<option value="Air">Air</option>
<option value="Rail">Rail</option>
<option value="Sea">Sea</option>
<option value="=own-arranged">Road � Own Arranged Vehicles</option>
<option value="company-arranged">Road- Company Arranged Vehicles</option>
</select>
</td>
</tr>
</tbody>
</table>
<h3>Travel Itinerary</h3>
<table>
<tbody>
<tr>
<td> </td>
<td>
Travel Request For
<input name="request_for" value="return" type="radio">
Return
<input name="request_for" value="oneway" type="radio">
oneWay
<input name="request_for" value="multiCity" type="radio">
Multi-City
</td>
<td> </td>
</tr>
</tbody>
</table>
<div class="innr">
<div class="form-group">
<label for="from">
<span class="BodyFont" style="color: red">*</span>
From:
</label>
<input id="from" class="form-control" name="from" required type="text">
</div>
<div class="form-group">
<label for="to">
<span class="BodyFont" style="color: red">*</span>
To:
</label>
<input id="to" class="form-control" name="to" required type="text">
</div>
<div class="form-group">
<label for="depart">
<span class="BodyFont" style="color: red">*</span>
Depart On:
</label>
<input id="depart_on" class="form-control" name="depart_date" required type="date">
</div>
<div class="form-group">
<label for="return">
<span class="BodyFont" style="color: red">*</span>
Return On:
</label>
<input id="return_on" class="form-control" name="return_date" required type="date">
</div>
<div class="form-group">
<label for="duration">
<span class="BodyFont" style="color: red">*</span>
Duration of Stay:
</label>
<input id="duration_of_stay" class="form-control" name="duration_of_stay" required type="text">
night(s)
</div>
<div class="form-group">
<label for="email">
<span class="BodyFont" style="color: red">*</span>
Purpose of Visit:
</label>
<select name="purpose" required="required">
<option value="Business Discussion">Business Discussion</option>
<option value="To attend Conference/Seminars">To attend Conference/Seminars</option>
<option value="To conduct Conference/Seminars">To conduct Conference/Seminars</option>
<option value="Accompanying Client">Accompanying Client</option>
<option value="To Impart Training">To Impart Training</option>
<option value="To Receive Training">To Receive Training</option>
<option value="Support TCSL office">Support TCSL office</option>
<option value="Project Work">Project Work</option>
<option value="Audit">Audit</option>
<option value="Business Meetings/Presentations">Business Meetings/Presentations</option>
<option value="Knowledge transfer">Knowledge transfer</option>
<option value="Architects visit for TCS project">Architects visit for TCS project</option>
<option value="External consultant for TCS Projects">External consultant for TCS Projects</option>
<option value="TCS invitees">TCS invitees</option>
<option value="Return Travel">Return Travel</option>
<option value="Others">Others</option>
</select>
</div>
<div class="form-group">
<label for="email">Visting Location:</label>
<input id="email" class="form-control" name="visit_location" type="text">
</div>
</div>
<div class="form-group">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Next" style="vertical-align:bottom;align:center" type="submit">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="SaveasDraft" style="vertical-align:bottom;align:center" type="submit">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Reset" style="vertical-align:bottom;align:center" type="submit">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Cancel" style="vertical-align:bottom;align:center" type="submit">
</div>
</form>   
                        
                  	</div><!-- /.col-* -->
					</div><!-- /.row -->   
				</div><!-- /.tab-pane -->
             <table width="100%">
<tbody>
<tr>
<td>
<table id="IntARN" class="entryForm" style="background-color: #DAE9F4;" width="100%" align="center">
<tbody>
<tr>
<td>
<table id="tvlInit:travelInitiation1222231" width="99%" align="center">
<thead>
<tr>
<th class="reportsHeader">Initiation Checklist:</th>
</tr>
</thead>
<tbody id="tvlInit:travelInitiation1222231:tbody_element">
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">Business travel cannot be more than 30 days per sector</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">Business travel to US on B1 Visa cannot be more than 28 days</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">Onsite allocation on WON is not mandatory for Business travel</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">If you are travelling on a business visa, allocation to SWON is mandatory. from the travel date till the business visa stay period.</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">Accomodation would be available for selection if TCS Accommodation is present at the location and Local transport would be available as per grade eligibility</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">Deputation cannot be extended on a business travel request. Please raise a relocation travel for the same purpose</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">Current/Depute location should be as per your current country and location . If the location is different then the workflow might not go to the required local processing officer of your Branch.</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">No Reporting form would be available in Business travel request </span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">In case of Multi sector travel, the 'To' country of the previous and 'From' country of the next leg should belong to the same country though the travelling city in both can be different</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">Ensure that the duration is entered correctly in case of Business Travel Request as it has direct impact on the forex released, insurance coverage provided as well as the deputation letter released.</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">Change link will enable you to change the Ticketing location if it is different from your depute location. Workflow gets triggered to the concerned branch stakeholders for ticketing, foreign exchange, dep doc, insurance etc. based on the ticketing location selected by you.</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">
<br>
1 .
<b>Important : Additionally For Associates travelling from India</b>
</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">Current/Depute location should be India if the associate is travelling from India. If the Location is other than India, then the workflow will not be triggered to all the Processing Owners except for ticketing and visa processing. Please raise the request after getting the location changed with help of RMG support</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">Please ensure Nominee Details are updated for the travelling individuals through GESS-> My Profile -> Travel Nominee and select the individual name who is travelling in 'Select Individual'</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont">Forex will be provided only on closure of itinerary and visa tagging notificatons by respective officers</span>
</span>
</td>
</tr>
<tr id="count">
<td class="coltextcenteralign" style="text-align:left;border: 1px solid #CDCDCD;padding-left: 3px;">
<span style="width:100%;">
<span class="BodyFont"> Please ensure that you complete your Deputation Documentation Formalities and Port of Entry Briefing from your Branch FDFU before you travel.</span>
</span>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td>
<span class="intermediateHeader" style="width: 100%;background-color: #DAE9F4;">
<span class="BodyFont">Your Current country is : </span>
<span style="color:red;">(India)</span>
<span class="BodyFont"> Processing Branch is :( </span>
<span style="color:red;">TCS - New Delhi</span>
<span class="BodyFont"> ) Processing DC is : (</span>
<span style="color:red;">Chandigarh - Non STP</span>
<span class="BodyFont"> ) and your FDFU contact is : (</span>
<span style="color:red;">N. Phani</span>
)(
<span style="color:red;">109017</span>
)
</span>
</td>
</tr>
<tr>
<td>
<span class="BodyFont" style="color:blue;">Please click on 'Change' to select the correct Ticketing Branch/Delivery Centre.</span>
</td>
</tr>  
</tbody>
</table> 
			</div><!-- /.tab-content --> 
                 
                 </div></div>
       
		</div><!-- /.col-* -->
          </div>

          <!-- /.col-* --> 
 
        </div>

				<!-- /.row -->

      </div>

      <!-- /.container -->

    </div>

  </div>

  <!-- /.main --> 



<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<style>

ul, li {

    border: 0 none;

    list-style: outside none none;

    margin: 0;

    padding: 0;

}

.infocard_legend li {

    float: left;

    margin-right: 15px;

}



.infocard_legend .worklist {

    background-color: #d9edf7;

}

.infocard_legend li span {

    border: 1px solid #ccc;

    float: left;

    height: 15px;

    margin: 2px 5px 2px 2px;

    width: 16px;

}



</style>

<script>

	$(document).ready(function($){

	var url = window.location.href;

	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');

	});

</script>

<?php $__env->stopSection(); ?>

	

	
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>