<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
          <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1>Rules and Regulations</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="document-breadcrumb">
                <div class="container">
                    <ul class="breadcrumb">
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li>Rules & Regulations</li>
                    </ul>
                </div><!-- /.container -->
            </div><!-- /.document-title -->
  <div class="container">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="page-header">Description, duties, responsibilities</h3>
			<p>
			<?php echo e($data['rules']->description_responsibilities); ?>

			</p>

			<h3 class="page-header">Other benefits</h3>
			<?php echo e(strip_tags($data['rules']->other_beifits)); ?>

			

			<h3 class="page-header">Personality requirements and skills</h3>
			<?php echo e(strip_tags($data['rules']->skills)); ?>

			
		</div><!-- /.col-* -->
	</div><!-- /.row -->
</div><!-- /.container -->

        </div><!-- /.main -->
    </div><!-- /.main-wrapper -->
    </div>
</div>
<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>