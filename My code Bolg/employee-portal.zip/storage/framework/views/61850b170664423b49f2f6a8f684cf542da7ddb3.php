<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Employee Portal')); ?></title>

 
	 <!-- CORE CSS-->    
    <link href="<?php echo e(asset('css/materialize.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="<?php echo e(asset('css/style.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
    <!-- CSS style Horizontal Nav-->    
    
    <!-- Custome CSS-->    
    <link href="<?php echo e(asset('css/custom/custom.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
    


    <!-- INCLUDED PLUGIN CSS ON THIS PAGE -->
    <link href="<?php echo e(asset('css/layouts/page-center.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="<?php echo e(asset('js/plugins/prism/prism.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="<?php echo e(asset('js/plugins/perfect-scrollbar/perfect-scrollbar.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
</head>
<body class="cyan">
  <!-- Start Page Loading -->
  <div id="loader-wrapper">
      <div id="loader"></div>        
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
  </div>
  <!-- End Page Loading -->



  <div id="login-page" class="row">
    <div class="col s12 z-depth-4 card-panel">
      <form class="form-horizontal login-form" role="form" method="POST" action="<?php echo e(route('login')); ?>">
	    <?php echo e(csrf_field()); ?>

        <div class="row"> 
          <div class="input-field col s12 center">
            <img src="images/company-2.png" alt="" class="circle responsive-img valign profile-image-login">
            <p class="center login-form-text">Login</p>
          </div>
        </div>
        <div class="row margin">
          <div class="input-field col s12<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <i class="mdi-social-person-outline prefix"></i>
            <input id="email" type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
            <label for="username" class="center-align">Username</label>
          </div>
		  <?php if($errors->has('email')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('email')); ?></strong>
				</span>
			<?php endif; ?>
        </div>
        <div class="row margin">
          <div class="input-field col s12">
            <i class="mdi-action-lock-outline prefix"></i>
            <input id="password" type="password" class="form-control" name="password" required>
            <label for="password">Password</label>
          </div>
		  <?php if($errors->has('password')): ?>
			<span class="help-block">
				<strong><?php echo e($errors->first('password')); ?></strong>
			</span>
		  <?php endif; ?>
        </div>
        <div class="row">          
          <div class="input-field col s12 m12 l12  login-text">
              <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> />
              <label for="remember-me">Remember me</label>
          </div>
        </div>
        <div class="row">
          <div class="input-field col s12">
		   <button type="submit" class="btn waves-effect waves-light col s12">
                                    Login
                                </button>
            
          </div>
        </div>
        <div class="row">
          <div class="input-field col s6 m6 l6">
            <p class="margin medium-small"><a href="<?php echo e(route('register')); ?>">Register Now!</a></p>
          </div>
          <div class="input-field col s6 m6 l6">
              <p class="margin right-align medium-small"><a href="<?php echo e(route('password.request')); ?>">Forgot password ?</a></p>
          </div>          
        </div>

      </form>
    </div>
  </div>




    <!-- ================================================
    Scripts
    ================================================ -->
    
    <!-- jQuery Library -->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/jquery-1.11.2.min.js')); ?>"></script>
    <!--materialize js-->
    <script type="text/javascript" src="<?php echo e(asset('js/materialize.min.js')); ?>"></script>
    

    <!-- sparkline -->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/prism/prism.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    
  

    <!--jvectormap-->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/custom-script.js')); ?>"></script>
    
</body>
</html>

