<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
		<h2>Comming Soon....................</h2>
    </div>
</div>
<?php echo $__env->make('templates/footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>