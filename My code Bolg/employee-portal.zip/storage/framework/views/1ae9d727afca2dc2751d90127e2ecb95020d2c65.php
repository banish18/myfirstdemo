<ul class="navside">
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'profile'))); ?>">My Profile</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'addressDetail'))); ?>"> Address Detail</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'bankdetail'))); ?>">Bank Details</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'languagedetail'))); ?>">Language Details</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'contactsdetail'))); ?>">My Contacts</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'role'))); ?>">My Role</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'team-information'))); ?>">Team Information</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'qualification'))); ?>">Qualification Detail</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'change-work-location'))); ?>">Change Work Location</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'cards'))); ?>">Card Details</a>
			</li>
			
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'iou'))); ?>">IOU Detail</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'lost-demage-card'))); ?>">Lost Damage Card</a>
			</li>
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'my-cards'))); ?>">My Cards</a>
			</li>
			
			
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'my-resume'))); ?>">My Resume</a>
			</li>
			
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'national-identifier'))); ?>">National Identifier</a> 
			</li>
			
			
			<li>
			<a class="" href="<?php echo e(route('employee-services',array('action' => 'work-experience'))); ?>">Work Experience</a>
			</li>
			</ul>
