<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Contactdetail extends Authenticatable
{
	  protected $table = 'employee_contact';
}
