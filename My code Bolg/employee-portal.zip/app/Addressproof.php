<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Addressproof extends Authenticatable
{
	  protected $table = 'address_proof';
}
