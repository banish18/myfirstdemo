<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Salarytemplate extends Authenticatable
{
	  protected $table = 'salary_template';
}

?>
