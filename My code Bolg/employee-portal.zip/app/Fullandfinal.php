<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Fullandfinal extends Authenticatable
{
	  protected $table = 'emp_fullandfinal';
}
