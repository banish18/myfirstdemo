<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Empprofile extends Authenticatable
{
	  protected $table = 'emp_profile';
}
