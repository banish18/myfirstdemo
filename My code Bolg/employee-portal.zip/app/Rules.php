<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Rules extends Authenticatable
{
	  protected $table = 'rules_regulations';
}
