<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Resignationformality extends Authenticatable
{
	  protected $table = 'resignation_formalities';
}
