<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;

use Validator;

use Auth;

use App\Department;

use Illuminate\Support\Facades\Redirect;

use Illuminate\Support\Facades\Input;

use App\Notes;

class NotesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
	 
	 public $data = [];
	 
    public function __construct()
    {
        $this->middleware('auth');
		
		$this->title 			= "Notes";

		$this->notes 			= Notes::all();
		
		$this->data['notes'] 	= $this->notes;
		
		$this->data['title'] 	= $this->title;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
	
	public function action(Request $request,$action=null,$id=null)

	{
		$user = Auth::user();
			
		$this->checkPermission 		=  Department::where('id',$user->e_department)->first();
		if($this->checkPermission){
			$this->getPermission 		=  json_decode($this->checkPermission->permission);
	
			$this->data['permissions']	=	$this->getPermission;
		}else{
			$this->data['permissions']	=	[];
		}
		
		switch ($action)

		{
			case 'view':
				
					$this->data['title'] = "Employee";
					$this->data["note"] 			= Notes::find($id);
					return view('admin.notes.view-note',['data'=>$this->data]);	

				
			break;
			
			case 'add':
				if($user->user_type == "0" || in_array('add_noticeboard',$this->data["permissions"])){
					$this->data['title'] = "Add New Notes";

					return view('admin.notes.add-notes',['data'=>$this->data]);

				}else{
					return "Unathorized";
				}

				
				break;								
				
				
			case 'postAdd':
			
			if($user->user_type == "0" || in_array('add_noticeboard',$this->data["permissions"])){
				$note 						= new Notes;
				$note->title 				= $request->title;
				$note->desc 				= $request->desc;
				
				if($note->save())
				{
					 \Session::flash('success','Note Successfully Added.');
				}
				else
				{
					 \Session::flash('error','Error! Please Contact Administrator.'); 
				}
				return redirect::to('notes');
			}else{
				return "Unathorized";
			}
				
				
				break;
			case 'edit':
				if($user->user_type == "0" || in_array('update_noticeboard',$this->data["permissions"])){
					$this->data['title'] 	= "Edit Note";
					
					$this->data["note"] 			= Notes::find($id);			

					return view('admin.notes.edit-notes',['data'=>$this->data]);
				}else{
					return "Unathorized";
				}

				

				break;	
				
			case 'postUpdate':
			
				if($user->user_type == "0" || in_array('update_noticeboard',$this->data["permissions"])){
					$note 						= Notes::find($request->id);
					$note->title 				= $request->title;
					$note->desc 				= $request->desc;
					
					if($note->save())
					{
						 \Session::flash('success','Note Successfully Added.');
					}
					else
					{
						 \Session::flash('error','Error! Please Contact Administrator.'); 
					}
					return redirect::to('notes');
				}else{
					return "unauthorized";
				}
				
				

				break;	
				
				case 'delete':
				
				if($user->user_type == "0" || in_array('view_noticeboard_delete',$this->data["permissions"])){
					
					Notes::where('id',$id)->delete();
			
					return redirect::to('notes');

				}else{
					
					return "unauthorized";
				}
			
				break;
			
				default:

				return view('admin.notes.notes',['data'=>$this->data]);	

				break;		
		}
		
	}
}
