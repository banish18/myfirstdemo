<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;

use Validator;

use App\Department;

use Auth;

use Illuminate\Support\Facades\Redirect;

use Illuminate\Support\Facades\Input;

use App\Leave;

use App\Empleave;

use DB;

use Session;

class LeaveController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
	 
	 public $data = [];
	 
    public function __construct()
    {
        $this->middleware('auth');
		
		$this->title = "All Payslips";

		$this->user = Auth::User();
		
		$this->departments = Department::all();
		
		$this->leave = Leave::all();
		
		$this->data['leaves'] = $this->leave;
		
		$this->data['user'] = $this->user;
		
		$this->data['title'] = $this->title;
		
		$this->data['departments'] = $this->departments;
		
		$this->controller     = $this;
		
		$this->data['controller'] = $this->controller;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
	
	public function action(Request $request,$action=null,$id=null)

	{
		switch ($action)

		{
			case 'leave-requests':
				$this->data['title'] 	= "Leave";
				$leaves = DB::table('leaves')
						->join('emp_leaves', 'users.id', '=', 'emp_leaves.uid')
						->get();	
				return view('employee_self_services.leaves.leave-requests',['data'=>$this->data]);	
			break;	
			
			case 'apply-leaves':
				$user = Auth::user();
				$this->data['title'] = "Leave";
				$Empleave = Empleave::where('uid',$user->id)->get();
				$pleaves = [];
				$rallLeaves = [];
				foreach($this->data['leaves'] as $lv){
					$rallLeaves[$lv->leave_type] = $lv->leave_number;			
				}
				if($Empleave){
					foreach($Empleave as $leave){
					foreach($this->data['leaves'] as $lv){
							if($leave->leave_type == $lv->id){
								$pleaves[$lv->leave_type] = $lv->leave_number-$leave->leave_number;
								unset($rallLeaves[$lv->leave_type]);
							}
						}
					}
				}

				$finalArr = array_merge($pleaves,$rallLeaves);
				unset($finalArr['LWP']);
	
				$this->data["pallLeaves"] = $finalArr;
				$this->data['leaves'] = Leave::where('uid',Auth::user()->id)->orderBy('id','asc')->get();
				
				return view('employee_self_services.leaves.apply-for-leave',['data'=>$this->data]);	
			break;
			
			case 'postApply':
				$user 					= Auth::user();
				$tDays = 	strval($request->days);		
				$getLeave = DB::table('leaves')
				->where('id', $request->leave_type)
				->where('uid', $user->id)
                ->first();	
				if($getLeave && $tDays <= $getLeave->leave_number){
					$Empleave	= DB::table('emp_leaves')->where('uid',$user->id)->where('leave_type',$request->leave_type)->select(DB::raw('SUM(leave_number) as Totalleave'))->first();
					if($Empleave->Totalleave != ""){
						if($tDays < $Empleave->Totalleave){
							if($this->getLtype($request->leave_type) == "PL" && $getLeave->leave_number >= "3" && $tDays <= $getLeave->leave_number && $tDays > 3){
								$Empleave 				= new Empleave;
								$Empleave->uid 			= $user->id;
								$Empleave->leave_type 	= $request->leave_type;
								$Empleave->leave_number = $request->days;
								$Empleave->status 		= 'pending';
								$Empleave->from_date 	= date('Y-m-d',strtotime($request->start_date));
								$Empleave->to_date 		= date('Y-m-d',strtotime($request->end_date));
								$Empleave->reason 		= $request->reason;
								$Empleave->attach 		= 'test.png';
								$Empleave->save();
								\Session::flash('flash_message', 'Your Leave Request Successfully Sent');
								return redirect::to('leaves');
							}else{
								Session::flash('flash_message', 'You Dont have enough Leaves!');
								return redirect::to('leaves/apply-leaves');
							}
						}else{
							Session::flash('flash_message', 'You Dont have enough Leaves!');
							return redirect::to('leaves/apply-leaves');
						}
					}else{
						if($this->getLtype($request->leave_type) == "PL" && $getLeave->leave_number >= "3" && $tDays <= $getLeave->leave_number && $tDays >= 3){
								$Empleave 				= new Empleave;
								$Empleave->uid 			= $user->id;
								$Empleave->leave_type 	= $request->leave_type;
								$Empleave->leave_number = $request->days;
								$Empleave->status 		= 'pending';
								$Empleave->from_date 	= date('Y-m-d',strtotime($request->start_date));
								$Empleave->to_date 		= date('Y-m-d',strtotime($request->end_date));
								$Empleave->reason 		= $request->reason;
								$Empleave->attach 		= 'test.png';
								$Empleave->save();
								\Session::flash('flash_message', 'Your Leave Request Successfully Sent');
								return redirect::to('leaves');
							}else{
								Session::flash('flash_message', 'You Dont have enough Leaves!');
								return redirect::to('leaves/apply-leaves');
							}
					}
					
				}else{
					Session::flash('flash_message', 'You Dont have enough Leaves!');
						return redirect::to('leaves/apply-leaves');
				}
			break;
			
			default:
				$user 					= Auth::user();
				$this->updateBleaves($user->id);
				$this->data['leaves'] = Leave::where('uid',Auth::user()->id)->orderBy('id','asc')->get();
				return view('employee_self_services.leaves.leave-requests',['data'=>$this->data]);	
				break;		
		}
		
	}
	
	public static function getBleaves($id,$lv){
		$user 		= Auth::user();
		$Empleave	= DB::table('emp_leaves')->where('uid',$user->id)->where('leave_type',$id)->select(DB::raw('SUM(leave_number) as Totalleave'))->first();
		$leaves		= $lv-$Empleave->Totalleave;
		return $leaves;
	}
	
	public static function getLtype($id){
		$user 		= Auth::user();
		$leave		= Leave::where('id',$id)->first();
		$leaveT		= $leave->leave_type;
		return $leaveT;
	}
	
	public static function updateBleaves($uid){
		$user 						= Auth::user();
		$preLeave 					= Leave::where('uid',$uid)->get();
		$precLeave 					= Leave::where('uid',$uid) ->orderBy('created_at', 'desc')->first();
		if(!$preLeave->isEmpty()){
			$currentDate            = date('m');
			$Predate 				= date('m', strtotime($precLeave->created_at));
			$loopM                  = $currentDate-$Predate;
			if($currentDate > $Predate){
				for($i=0;$i<$loopM;$i++){
					foreach($preLeave as $lt){
						if($lt->leave_type == 'PL'){
							$preULeave 					 = Leave::find($lt->id);
							$preULeave->leave_number     = $lt->leave_number+1;
							$preULeave->created_at		 = date('Y-m-d');
							$preULeave->save();
						}else if($lt->leave_type == 'CL'){
							$preULeave 					 = Leave::find($lt->id);
							$preULeave->leave_number     = $lt->leave_number+0.5;
							$preULeave->created_at		 = date('Y-m-d');
							$preULeave->save();
						}else if($lt->leave_type == 'SL'){
							$preULeave 					 = Leave::find($lt->id);
							$preULeave->leave_number     = $lt->leave_number+0.33334;
							$preULeave->created_at		 = date('Y-m-d');
							$preULeave->save();
						}else if($lt->leave_type == 'SL ME'){
							$preULeave 					 = Leave::find($lt->id);
							$preULeave->leave_number     = $lt->leave_number+0.5;
							$preULeave->created_at		 = date('Y-m-d');
							$preULeave->save();
						}
					}
				}
			}
			$msg = 1;
		}else{
			$currentDate            	= date('m');
			$typeArr                    = ['PL','CL','SL','SL ME'];
			$jDate                      =  date('m',strtotime($user->doj));
			foreach($typeArr as $ta){
				$preLeave 					= new Leave;
				$preLeave->uid				= $user->id;
				$preLeave->leave_type		= $ta;
				if($ta == "PL"){
					$preLeave->leave_number		= 1;
				}else if($ta == "CL"){
					$preLeave->leave_number		= 0.5;
				}else if($ta == "SL"){
					$preLeave->leave_number		= 0.33334;
				}else if($ta == "SL ME"){
					$preLeave->leave_number		= 0.5;
				}
				$preLeave->created_at			= $user->doj;
				$preLeave->save();
			}
			
			$preLeave 							= Leave::where('uid',$uid)->get();
			if(!$preLeave->isEmpty()){
					$precLeave 					= Leave::where('uid',$uid) ->orderBy('created_at', 'desc')->first();
					$lastCreated 				= date('m',strtotime($precLeave->created_at));
					for($i=(int)$lastCreated;$i<=$currentDate;$i++){
						foreach($preLeave as $lt){
								if($lt->leave_type == 'PL'){
									$preBLeave 					= Leave::find($lt->id);
									$preBLeave->leave_number    = $lt->leave_number+1;
									$preBLeave->updated_at     	= date('Y-m-d');
									$preBLeave->save();
								}else if($lt->leave_type == 'CL'){
									$preBLeave 					= Leave::find($lt->id);
									$preBLeave->leave_number    = $lt->leave_number+0.50;
									$preBLeave->updated_at     	= date('Y-m-d');
									$preBLeave->save();
								}else if($lt->leave_type == 'SL'){
									$preBLeave 					= Leave::find($lt->id);
									$preBLeave->leave_number    = $lt->leave_number+0.33334;
									$preBLeave->updated_at     	= date('Y-m-d');
									$preBLeave->save();
								}else if($lt->leave_type == 'SL ME'){
									$preBLeave 					= Leave::find($lt->id);
									$preBLeave->leave_number    = $lt->leave_number+0.50;
									$preBLeave->updated_at     	= date('Y-m-d');
									$preBLeave->save();
								}
							}
					}
			}
		
			$msg = 0;
		}
		return $msg;
	}
	
}
