<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;

use Auth;

use Validator;

use Illuminate\Support\Facades\Redirect;

use Illuminate\Support\Facades\Input;

use App\Department;

class DepartmentController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
	 
	 public $data = [];
	 
    public function __construct()
    {
        $this->middleware('auth');
		
		$this->title 			= "Notes";

		$this->department 			= Department::all();
		
		$this->data['departments'] 	= $this->department;
		
		$this->data['title'] 	= $this->title;
		
		$this->controller       = $this;
		
		$this->data['controller'] 	= $this->controller;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
	
	public function action(Request $request,$action=null,$id=null)

	{
		$user = Auth::user();
			
		$this->checkPermission 		=  Department::where('id',$user->e_department)->first();
		if($this->checkPermission){
			$this->getPermission 		=  json_decode($this->checkPermission->permission);
	
			$this->data['permissions']	=	$this->getPermission;
		}else{
			$this->data['permissions']	=	[];
		}
	
		switch ($action)

		{

			case 'add':
			
				if($user->user_type == "0" || in_array('add_department',$this->data["permissions"])){
					$this->data['title'] = "Add New Notes";

					return view('admin.departments.add-department',['data'=>$this->data]);

				}else{
					return "unauthorized";
				}

				
				break;								

			case 'postAdd':
			
				if($user->user_type == "0" || in_array('add_department',$this->data["permissions"])){
					$department 						= new Department;
					$department->name 					= $request->name;
					$department->desc 					= $request->description;
					$department->codes 					= $request->codes;
					$department->permission 			= json_encode($request->permissions);
					
					if($department->save())
					{
						 \Session::flash('success','Note Successfully Added.');
					}
					else
					{
						 \Session::flash('error','Error! Please Contact Administrator.'); 
					}
					return redirect::to('departments');
				}else{
					return "unauthorized";
				}
				
				
				
				
				break;
			case 'edit':
			
				if($user->user_type == "0" || in_array('edit_department',$this->data["permissions"])){
					$this->data['title'] 	= "Edit Note";
				
					$this->data["department"] 			= Department::find($id);			

					return view('admin.departments.edit-department',['data'=>$this->data]);
				}else{
					return "unauthorized";
				}

				

				break;	
				
			case 'postUpdate':
				if($user->user_type == "0" || in_array('edit_department',$this->data["permissions"])){
					$department 						= Department::find($request->id);
					$department->name 					= $request->name;
					$department->desc 					= $request->description;
					$department->codes 					= $request->codes;
					$department->permission 			= json_encode($request->permissions);
					
					if($department->save())
					{
						 \Session::flash('success','Department Successfully Updated.');
					}
					else
					{
						 \Session::flash('error','Error! Please Contact Administrator.'); 
					}
					return redirect::to('departments');
				}else{
					return "unauthorized";
				}

				break;	
				
				case 'delete':
				
				if($user->user_type == "0" || in_array('display_dept_delete',$this->data["permissions"])){
					Department::where('id',$id)->delete();
			
					return view('admin.departments.departments',['data'=>$this->data]);	

				}else{
					return "unauthorized";
				}
			
				break;
			
				default:
				if($user->user_type == "0" || in_array('edit_department',$this->data["permissions"])){
					return view('admin.departments.departments',['data'=>$this->data]);	
				}else{
					return "unauthorized";
				}
				break;		
		}
		
	}
	
	public static function getPermissions($permissions){
		$permissions = json_decode($permissions);
		/* $html = '';
		if(!empty($permissions)){
			foreach($permissions as $permission){
				$html .= $permission."<br />";
			}
		} */
		return $permissions;
	}
}
