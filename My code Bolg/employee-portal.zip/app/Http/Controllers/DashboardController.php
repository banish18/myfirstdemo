<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Auth;use App\Notes;

use DB;

use App\Rules;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {		$this->notes = Notes::all();		$this->data['notes'] = $this->notes;		$this->users = DB::table('users')->count();		$this->data['totalusers'] = $this->users;
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {		
        return view('admin/dashboard',['data'=>$this->data]);
    }
	/**
     * Handle actions and their view.
     *
     * @return \Illuminate\Http\Response
     */
	 public function action(Request $request,$action=null,$id=null){
		 switch($action){
			 case 'home':
				return view('home',['data'=>$this->data]);	
			 break;
			 case 'rules-regulations':
				$this->data["rules"] = Rules::where('id','1')->first();
				return view('admin.rules-regulations',['data'=>$this->data]);	
			 break;
			 case 'master':
				return view('admin.master',['data'=>$this->data]);	
			 break;
			 default:
				return view('home',['data'=>$this->data]);
			break;	
		 }
	 }
}
