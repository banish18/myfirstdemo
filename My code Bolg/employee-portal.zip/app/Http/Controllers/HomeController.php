<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;

use Auth;

use App\Empprofile;

use App\Addressdetail;

use App\Rules;

use App\Updates;

use App\Notification;

use Illuminate\Support\Facades\Redirect;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
	public $user;
    public function __construct()
    {
        $this->middleware('auth');
		$this->user 					= Auth::User();
		$this->data['title'] 			= "Home";
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       // return view('home');
    }
	/**
     * Handle actions and their view.
     *
     * @return \Illuminate\Http\Response
     */
	 public function action(Request $request,$action=null,$id=null){
		 switch($action){
			 case 'home':
				return view('home',['data'=>$this->data]);	
			 break;
			 case 'rules-regulation':
				$this->data["rules"] = Rules::where('id','1')->first();
				return view('rules-regulations',['data'=>$this->data]);	
			 break;
			 case 'notification':
			 $this->data['user'] = Auth::User();
			 $this->data["notifications"] = Notification::where('uid',$this->data['user']->id)->get();
				return view('notification',['data'=>$this->data]);	
			 break;
			 case 'latest-updates':
				$this->data["Updates"] = Updates::where('id','1')->first();
				return view('latest-updates',['data'=>$this->data]);	
			 break;
			 case 'contact':
				return view('contact',['data'=>$this->data]);	
			 break; 
			 case 'postContact':
				$from 		= $request->email;
				$to 		= "sahil@mindxpert.com";
				$subject 	= $request->subject;
				$message 	= "Hi Admin! ".$from." are sending mail to Contact Us";
				$headers 	= 'From: '.$from.'' . "\r\n" .
					'Reply-To: '.$from.'' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();
				mail($to, $subject, $message, $headers);
				\Session::flash('success','Your Mail has been Successfully Sent.');
				return redirect::to('home/contact');
			break;	
			 case 'profile':
				$user = Auth::User();
			    $this->data['emp_profile'] 		= Empprofile::where("uid",$user->id)->first();
				$this->data['addressDetail'] 	= Addressdetail::where("uid",$user->id)->get();
				$this->data['user'] 			= $user;
				return view('profile',['data'=>$this->data]);	
			 break;
			 case 'change-password':
				return view('change-password',['data'=>$this->data]);	
			 break;
			 case 'postChangepassword':
				$user			 	= Auth::User();
				$email 				= $request->email;
				$oldPassword 		= $request->old_password;
				$newPassword 		= $request->new_password;
				$options  		    = ['cost' => '12'];
				/* $oldPassword 		= password_hash($request->input('old_password'),PASSWORD_BCRYPT,$options); */
				if($user->show_pass == $oldPassword && $user->email == $email){
					 $user->show_pass 	= $newPassword;
					 $user->password 	= password_hash($request->input('new_password'),PASSWORD_BCRYPT,$options);
					 $user->save();
					 \Session::flash('success','Password Successfully Changed.');
				}else{
					 \Session::flash('success','Please Enter Your correct email and password again.');
				}
				return redirect::to('home/change-password');
			 break;
			 case 'setting':
				return view('setting',['data'=>$this->data]);	
			 break;
			 default:
				return view('home',['data'=>$this->data]);
			break;	
		 }
	 }
	
}
