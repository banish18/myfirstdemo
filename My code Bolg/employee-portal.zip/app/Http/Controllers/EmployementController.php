<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Auth;use App\Notes;

use DB;

use App\User;

use App\Rules;

use App\Employeeletter;

use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\Redirect;

use App\Lettertype;

class EmployementController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {		$this->notes = Notes::all();		$this->data['notes'] = $this->notes;		$this->users = DB::table('users')->count();		$this->data['totalusers'] = 		$this->users;
			$this->middleware('auth');
			$this->controller = $this;
			$this->data["controller"] = $this->controller;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {		
        return view('admin/dashboard',['data'=>$this->data]);
    }
	/**
     * Handle actions and their view.
     *
     * @return \Illuminate\Http\Response
     */
	 public function action(Request $request,$action=null,$id=null){
		 switch($action){
			 case 'letter-type':
				$this->data["Lettertypes"] = Lettertype::all();
				return view('admin/employement/letter-type',['data'=>$this->data]);	
			 break;
			 case 'add-lettertype':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->get();
				return view('admin/employement/add-lettertype',['data'=>$this->data]);	
			 break;
			 case 'postLettertype':
				$Lettertype 						= new Lettertype;
				$Lettertype->name 				= $request->name;
 				$Lettertype->save();
				return redirect::to('employement/letter-type');
			 break;
			  case 'edit-lettertype':
				$this->data["letter"] = Lettertype::find($id);
				return view('admin/employement/edit-lettertype',['data'=>$this->data]);	
			 break;
			 case 'postupdateLettertype':
				$Lettertype 				= Lettertype::find($request->id);
				$Lettertype->name 			= $request->name;
 				$Lettertype->save();
				return redirect::to('employement/letter-type');
			 break;
			 case 'deleteLettertype':
				$Lettertype 				= Lettertype::find($id);
 				$Lettertype->delete();
				return redirect::to('employement/letter-type');
			 break;
			 case 'add-appointment':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->get();
				return view('admin/employement/add-appointment',['data'=>$this->data]);	
			 break;
			 case 'upload-letters':
				$this->data["Lettertypes"] = Lettertype::all();
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->get();
				return view('admin.employement.upload-letters',['data'=>$this->data]);	
			 break;
			 case 'postpreAppointment':
				$file 							= Input::file('letter');
				$getUser 						= DB::table('users')->where('id',$request->employee)->first();
				if($file){
					$destinationPath 				= base_path() .'/images/users/letters';
					$filename 						= $file->getClientOriginalName();
					$filename 						= $getUser->name.$getUser->uuid.'_'.$filename;
					$file->move($destinationPath, $filename);
				}
				$Employeeletter 					= new Employeeletter;
				$Employeeletter->uid 				= $request->employee;
				$Employeeletter->letter_type 		= $request->letter_type;
				$Employeeletter->letter 			= $filename;
 				$Employeeletter->save();
				return redirect::to('employement');
			 break;
			 case 'deleteAppointment':
			 $Employeeletter 					= Employeeletter::find($id);
			 $Employeeletter->delete();
			 return redirect::to('employement');
			 break;
			 case 'get-letter':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->get();
				if($request->uuid == "" && $request->user != ""){
					$this->data["user"] = User::find($request->user);
				}else if($request->uuid != "" && $request->user == ""){
					$this->data["user"] = User::where('uuid',$request->uuid)->first();
				}else{
					$this->data["user"] = User::where('id',$request->user)->where('uuid',$request->uuid)->first();
				}
				if($this->data["user"]){
					$this->data["Employeeletters"] = Employeeletter::where('uid',$this->data["user"]->id)->get();
				}
				
				return view('admin/employement/employement',['data'=>$this->data]);	
			 break;
			 case 'get-empletter':
				$Employeeletters = Employeeletter::find($request->id);
				$html = "";
				if($this->getLetter($Employeeletters->letter_type)->name == "Appointment"){
					$date = date("d-M-Y",strtotime($this->getUser($Employeeletters->uid)->doj));
				}else if($this->getLetter($Employeeletters->letter_type)->name == "Appraisal"){
					$date = date("d-M-Y",strtotime($this->getUser($Employeeletters->uid)->doap));
				}else{
					$date = date("d-M-Y",strtotime($Employeeletters->created_at));
				}
				if($Employeeletters){
					$usrl = asset('images/users/letters/'.$Employeeletters->letter);
					$html .= '<tr><td><a  href="'.$usrl.'" href="javascript:;">'.$Employeeletters->letter.'</a></td><td>'.$date.'</td></tr>';
				}
				$result = json_encode(array('result' => $html));
				return $result;
				break;
			 case 'save-joining':
				$id 	= $request->uid;
				$user 	= User::find($id);
				$user->doj = date('Y-m-d',strtotime($request->doj));
				$user->save();
				$result = json_encode(array("data" => 1));
				return $result;
			 break;
			 default:
				
					$this->data["users"] = DB::table('users')->where('user_type','!=','0')->get();
				return view('admin/employement/employement',['data'=>$this->data]);
			break;	
		 }
	 }
	 public static function getUser($id){
		 $getUser 						= DB::table('users')->where('id',$id)->first();
		 return $getUser;
	 }
	 public static function getLetter($id){
		 $getLetter = Lettertype::find($id);
		 return $getLetter;
	 }
}
