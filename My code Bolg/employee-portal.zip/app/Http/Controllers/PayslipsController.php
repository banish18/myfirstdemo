<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;

use Validator;

use App\Department;

use App\Payroll;

use Illuminate\Support\Facades\Redirect;

use Illuminate\Support\Facades\Input;

use DB;

class PayslipsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
	 
	 public $data = [];
	 
    public function __construct()
    {
        $this->middleware('auth');
		
		$this->title = "All Payslips";

		$this->users = User::where('user_type','!=','0')->get();
		
		$this->departments = Department::all();
		
		$this->payslips = Payroll::all();
		
		$this->data['users'] = $this->users;
		
		$this->data['title'] = $this->title;
		
		$this->data['departments'] = $this->departments;
		
		$this->controller     = $this;
		
		$this->data['payslips'] = $this->payslips;
		
		$this->data['controller'] = $this->controller;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
	
	public function action(Request $request,$action=null,$id=null)

	{
		switch ($action)

		{
			case 'view':
				$this->data['title'] = "Employee";
				$this->data["user"] 			= User::find($id);
				return view('admin.payroll.payslip',['data'=>$this->data]);	
			break;
			
			case 'add':

				$this->data['title'] = "Generate New Payslip";

				return view('admin.payroll.generate-payslips',['data'=>$this->data]);

				break;								
				
				
			case 'postAdd':
			
				$checkQry = $users = DB::table('payroll')->where('uid',$request->emp_id)
									->whereBetween('from_date', [date('Y-m-d',strtotime($request->startperiod)), date('Y-m-d',strtotime($request->endperiod))])->first();
				if($checkQry){
					\Session::flash('success','Payslips Allready Generated.');
				}else{
					$payroll 				    = new Payroll;
					$payroll->uid 				= $request->emp_id;
					$payroll->dop 				= date('Y-m-d',strtotime($request->dateofpayment));
					$payroll->from_date         = date('Y-m-d',strtotime($request->startperiod));
					$payroll->to_date 		    = date('Y-m-d',strtotime($request->endperiod));
					
					if($payroll->save())
					{
						 \Session::flash('success','Payslip Successfully Generated.');
					}
					else
					{
						 \Session::flash('error','Error! Please Contact Administrator.'); 
					}
				}					
				
				
				return redirect::to('payroll');
				break;
		
			case 'getUsers':
			
				if($request->department != ""){
					
					$this->data["users"] = User::where('e_department',$request->department)->get();
					
				}
				
				return view('admin.users.users',['data'=>$this->data]);	
				
			break;	
				
			case 'delete':
			
				$prev_select_item_id = $request->prev_select_item_id;
				
				if($prev_select_item_id != ""){
					$prev_select_item_id = explode("_",$request->prev_select_item_id);
				
					foreach($prev_select_item_id as $id){
						
						User::where('id',$id)->delete();
					}
				}
			
				return view('admin.users.users',['data'=>$this->data]);	

				
				
				break;
				
			 case 'getPdf':
			
				return view('admin.payroll.pdfpayslip',['data'=>$this->data]);	

				
				
				break;	
			
			default:

				return view('admin.payroll.payslips',['data'=>$this->data]);	

				break;		
		}
		
	}
	
	public static function getUser($id){
		$user = User::where('id',$id)->first();
		return $user->name;
	}
	
	public static function getUsersalary($id){
		$user = User::where('id',$id)->first();
		return $user->salary;
	}
}
