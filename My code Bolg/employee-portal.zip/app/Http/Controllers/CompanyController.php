<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;

use Validator;

use App\Department;

use App\Company;

use Illuminate\Support\Facades\Redirect;

use Illuminate\Support\Facades\Input;

use DB;

class CompanyController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
	 
	 public $data = [];
	 
    public function __construct()
    {
        $this->middleware('auth');
		
		$this->title = "All Payslips";

		$this->users = User::where('user_type','!=','0')->get();
		
		$this->company = Company::all();
		
		$this->data['companies'] = $this->company;
		
		$this->data['title'] = $this->title;
		
		$this->controller     = $this;
		
		$this->data['controller'] = $this->controller;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
	
	public function action(Request $request,$action=null,$id=null)

	{
		switch ($action)

		{
			case 'view':
				$this->data['title'] = "Employee";
				$this->data["user"] 			= User::find($id);
				return view('admin.payroll.payslip',['data'=>$this->data]);	
			break;
			
			case 'add':

				$this->data['title'] = "Add New Company";

				return view('admin.company.add-company',['data'=>$this->data]);

				break;								
				
				
			case 'postAdd':
				$filename = "";
				$file 							= Input::file('logo');
				if($file){
					$destinationPath 				= base_path() .'/images/users/company';
					$filename 						= $file->getClientOriginalName();
					$filename 						= uniqid().'_'.$filename;
					$file->move($destinationPath, $filename);
				}
				$company 				    = new Company;
				$company->name 				= $request->name;
				$company->logo 				= $filename;
				$company->email 		    = json_encode($request->email);
		
				if($company->save())
				{
					 \Session::flash('success','Company Successfully Generated.');
				}
				else
				{
					 \Session::flash('error','Error! Please Contact Administrator.'); 
				}
		
				
				return redirect::to('company');
				break;
			case 'edit':

				$this->data['title'] = "Edit New Company";
				
				$this->data["company"] = Company::find($id);
				

				return view('admin.company.edit-company',['data'=>$this->data]);

				break;								
				
				
			case 'postUpdate':
			
			    $filename = "";
				$file 							= Input::file('logo');
				if($file){
					$destinationPath 				= base_path() .'/images/users/company';
					$filename 						= $file->getClientOriginalName();
					$filename 						= uniqid().'_'.$filename;
					$file->move($destinationPath, $filename);
				}else{
					$filename 	= $request->plogo;
				}
				$company 				    = Company::find($request->id);
				$company->name 				= $request->name;
				$company->logo 				= $filename;
				$company->email 		    = json_encode($request->email);
				if($company->save())
				{
					 \Session::flash('success','Company Successfully Updated.');
				}
				else
				{
					 \Session::flash('error','Error! Please Contact Administrator.'); 
				}
	
				return redirect::to('company');
				break;	
		
			case 'getUsers':
			
				if($request->department != ""){
					
					$this->data["users"] = User::where('e_department',$request->department)->get();
					
				}
				
				return view('admin.company.companies',['data'=>$this->data]);	
				
			break;	
				
			case 'delete':
			
				
				Company::where('id',$id)->delete();
				
			
				return redirect::to('company');

				break;
			
			default:

				return view('admin.company.companies',['data'=>$this->data]);	

				break;		
		}
		
	}
	
}
