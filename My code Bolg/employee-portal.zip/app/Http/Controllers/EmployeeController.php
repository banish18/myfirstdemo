<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;

use App\Empprofile;

use App\Languagedetail;

use Validator;

use App\BankDetail;

use App\Department;

use App\Payroll;

use Illuminate\Support\Facades\Redirect;

use Illuminate\Support\Facades\Input;

use DB;

use App\Addressdetail;

use App\Contactdetail;

use App\Employeework;

use App\Qualificationdetail;

use Auth;

use App\Resume;

use App\Empresume;

use App\Employeegrievance;

use App\Employeedocreq;

class EmployeeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
	 
	 public $data = [];
	 
    public function __construct()
    {
        $this->middleware('auth');
		
		$this->title = "All Payslips";

		$this->users = User::where('user_type','!=','0')->get();
		
		$this->departments = Department::all();
		
		$this->payslips = Payroll::all();
		
		$this->data['users'] = $this->users;
		
		$this->data['title'] = $this->title;
		
		$this->data['departments'] = $this->departments;
		
		$this->controller     = $this;
		
		$this->data['payslips'] = $this->payslips;
		
		$this->data['controller'] = $this->controller;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
	
	public function action(Request $request,$action=null,$id=null)

	{
		switch ($action)

		{
			case 'view':
				$this->data['title'] = "Employee";
				$this->data["user"] 			= User::find($id);
				return view('admin.payroll.payslip',['data'=>$this->data]);	
			break;	
			
			case 'profile':
				$this->data['title'] = "Profile";
				$this->data["user"] 			= Auth::User();
				$this->data["emp-profile"] 	    = Empprofile::where('uid',$this->data["user"]->id)->first();
				return view('employee_self_services.profile.profile',['data'=>$this->data]);	
			break;	
			
			case 'saveEmployeeReligion':
				$emp 				= User::find(Auth::User()->id);
				$emp->religion 		= $request->religion;
				$emp->caste     	= $request->caste;
				$emp->save();
				return Redirect::to('employee-services/profile');
			break;

			case 'saveEmployeeEmgdetail':
				$user = Auth::User();
				$emp = DB::table('emp_profile')
				->where('uid', $user->id)
				->update(['emergency_contact' => $request->emergency_contact]);
				return Redirect::to('employee-services/profile');
			break;	
			case 'addressDetail':
				$user = Auth::User();
				$this->data["Empaddress"] 	    = Addressdetail::where('uid',$user->id)->get();
				return view('employee_self_services.profile.address-detail',['data'=>$this->data]);	
			break;
			case 'addAddressdetail':
				return view('employee_self_services.profile.add-address',['data'=>$this->data]);	
			break;	
			case 'addBankdetail':
			   $user = Auth::User();
			   return view('employee_self_services.profile.add-bank');
			   break;
			case 'updateaddress':
				$user = Auth::User();
				$this->data["Empaddress"] 	    = Addressdetail::find($id);
				return view('employee_self_services.profile.edit-address',['data'=>$this->data]);
			break;
			case 'postAddress':
				$user 					    			= Auth::User();
				$Addressdetail 							= new Addressdetail;
				$Addressdetail->uid 					= $user->id;
				$Addressdetail->address_type     		= $request->address_type;
				$Addressdetail->address_line1     		= $request->address_line1;
				$Addressdetail->address_line2     		= $request->address_line2;
				$Addressdetail->primary_address     	= $request->primary_address;
				$Addressdetail->country     			= $request->country;
				$Addressdetail->save();
				return Redirect::to('employee-services/addressDetail');
			break;
			case 'postupdateAddress':
				$user 					    			= Auth::User();
				$Addressdetail 							= Addressdetail::find($request->id);
				$Addressdetail->address_type     		= $request->address_type;
				$Addressdetail->address_line1     		= $request->address_line1;
				$Addressdetail->address_line2     		= $request->address_line2;
				$Addressdetail->primary_address     	= $request->primary_address;
				$Addressdetail->country     			= $request->country;
				$Addressdetail->save();
				return Redirect::to('employee-services/addressDetail');
			break;
			case 'bankdetail':
				$user 					    			= Auth::User();
				$this->data["Empbank"] 	    = BankDetail::where('uid',$user->id)->get();
				return view('employee_self_services.profile.bank-details',['data'=>$this->data]);	
			break;
			case 'addBankdetail':
			   $user = Auth::User();
			   return view('employee_self_services.profile.add-bank');
			   break;
			case 'updatebank':
				$user = Auth::User();
				$this->data["bank"] 	    = Bankdetail::find($id);
				return view('employee_self_services.profile.edit-bank',['data'=>$this->data]);
			break;
			case 'postBank':
				$user 					    			= Auth::User();
				$BankDetail 							= new BankDetail;
				$BankDetail->uid 						= $user->id;
				$BankDetail->account_type     			= $request->account_type;
				$BankDetail->nature     				= $request->nature;
				$BankDetail->account_no     			= $request->account_no;
				$BankDetail->account_for     			= $request->account_for;
				$BankDetail->save();
				return Redirect::to('employee-services/bankdetail');
			break;
			case 'postupdateBank':
				$user 					    			= Auth::User();
				$BankDetail 							= BankDetail::find($request->id);
				$BankDetail->account_type     			= $request->account_type;
				$BankDetail->nature     				= $request->nature;
				$BankDetail->account_no     			= $request->account_no;
				$BankDetail->account_for     			= $request->account_for;
				$BankDetail->save();
				return Redirect::to('employee-services/bankdetail');
			break;
			case 'deletebank':
				$bankDetail = BankDetail::find($id);
				$bankDetail->delete();
				return Redirect::to('employee-services/bankdetail');
			break;
			case 'contactsdetail':
				$user 					    			= Auth::User();
				$this->data["Empcontact"] 	   			= Contactdetail::where('uid',$user->id)->get();
				return view('employee_self_services.profile.contact-detail',['data'=>$this->data]);	
			break;
			case 'addContactdetail':
			   $user = Auth::User();
			   return view('employee_self_services.profile.add-contact');
			   break;
			case 'updatecontact':
				$user = Auth::User();
				$this->data["Empcontact"] 	    = Contactdetail::find($id);
			
				return view('employee_self_services.profile.edit-contact',['data'=>$this->data]);
			break;
			case 'postContact':
				$user 					    			= Auth::User();
				$Contactdetail 							= new Contactdetail;
				$Contactdetail->uid 					= $user->id;
				$Contactdetail->name     				= $request->name;
				$Contactdetail->relationship     		= $request->relationship;
				$Contactdetail->mst_emp_flag     		= $request->mst_emp_flag;	
				$Contactdetail->dependent_flag     		= $request->dependent_flag;
				$Contactdetail->emergency_flag     		= $request->emergency_flag;
				$Contactdetail->save();
				return Redirect::to('employee-services/contactsdetail');
			break;
			case 'postupdateContact':
				$user 					    			= Auth::User();
				$Contactdetail 							= Contactdetail::find($request->id);
				$Contactdetail->name     				= $request->name;
				$Contactdetail->relationship     		= $request->relationship;
				$Contactdetail->mst_emp_flag     		= $request->mst_emp_flag;	
				$Contactdetail->dependent_flag     		= $request->dependent_flag;
				$Contactdetail->emegency_flag     		= $request->emegency_flag;
				$Contactdetail->save();
				return Redirect::to('employee-services/contactsdetail');
			break;
			case 'deletecontact':
				$Contactdetail = Contactdetail::find($id);
				$Contactdetail->delete();
				return Redirect::to('employee-services/contactsdetail');
			break;	
			case 'languagedetail':
				$user 					    			= Auth::User();
				$this->data["Emplanguage"] 	   			= Languagedetail::where('uid',$user->id)->get();
				return view('employee_self_services.profile.language-details',['data'=>$this->data]);	
			break;
			case 'addLanguagedetail':
			   $user = Auth::User();
			   return view('employee_self_services.profile.add-language');
			   break;
			case 'updatelanguage':
				$user = Auth::User();
				$this->data["language"] 	    = Languagedetail::find($id);
				return view('employee_self_services.profile.edit-language',['data'=>$this->data]);
			break;
			case 'postLanguage':
				$user 					    		= Auth::User();
				$Languagedetail 						= new Languagedetail;
				$Languagedetail->uid 					= $user->id;
				$Languagedetail->language     			= $request->language;
				$Languagedetail->mother_tongue     		= $request->mother_tongue;
				$Languagedetail->spoken_fluency     	= $request->spoken_fluency;	
				$Languagedetail->reading_fluency     	= $request->reading_fluency;
				$Languagedetail->written_fluency     	= $request->written_fluency;
				$Languagedetail->save();
				return Redirect::to('employee-services/languagedetail');
			break;
			case 'postupdateLanguage':
				$user 					    			= Auth::User();
				$Languagedetail 							= Languagedetail::find($request->id);
				$Languagedetail->language     				= $request->language;
				$Languagedetail->mother_tongue     			= $request->mother_tongue;
				$Languagedetail->spoken_fluency     		= $request->spoken_fluency;	
				$Languagedetail->reading_fluency     		= $request->reading_fluency;
				$Languagedetail->written_fluency     		= $request->written_fluency;
				$Languagedetail->save();
				return Redirect::to('employee-services/languagedetail');
			break;
			case 'deletelanguage':
				$Languagedetail = Languagedetail::find($id);
				$Languagedetail->delete();
				return Redirect::to('employee-services/languagedetail');
			break;
			case 'change-work-location':
				$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.profile.changework-location',['data'=>$this->data]);	
			break;
			case 'role':
				$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.profile.role',['data'=>$this->data]);	
			break;
			case 'aspairationRequest':
				$this->data['user'] = Auth::User();
				$from = $this->data['user']->email;
				$to = "sahil@mindxpert.com@gmail.com";
				$subject = "Regarding To change Aspiratinal Role";
				$message = "Hi Admin! test are requesting to change his Aspirational Role to ".$request->role;
				$headers = 'From: '.$from.'' . "\r\n" .
					'Reply-To: '.$from.'' . "\r\n" .
					'X-Mailer: PHP/' . phpversion();

				mail($to, $subject, $message, $headers);
				\Session::flash('success','Your Request has been Successfully Sent.');
				return Redirect::to('employee-services/role');

			break;
			case 'team-information':
				$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.profile.teaminformation',['data'=>$this->data]);	
			break;
			case 'qualification':
				$user 					    			= Auth::User();
				$this->data["EmpQualification"] 	   			= Qualificationdetail::where('uid',$user->id)->get();
				return view('employee_self_services.profile.qualification',['data'=>$this->data]);	
			break;	
			case 'add-qualification':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.profile.add-qualification',['data'=>$this->data]);	
			break;
			case 'postQualification':
				$user 					    			= Auth::User();
				$Qualificationdetail 						= new Qualificationdetail;
				$Qualificationdetail->uid     				= $user->id;
				$Qualificationdetail->type     				= $request->type;
				$Qualificationdetail->institute     		= $request->institute;
				$Qualificationdetail->start_date     		= date("Y-m-d",strtotime($request->sdate));	
				$Qualificationdetail->end_date     			= date("Y-m-d",strtotime($request->edate));	
				$Qualificationdetail->save();
				return Redirect::to('employee-services/qualification');
			break;	
			case 'cards';
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.profile.cards',['data'=>$this->data]);	
			break;	
			case 'iou';
			$this->data['user'] 			= Auth::User();
			$this->data["Empaddress"] 	    = Addressdetail::where('uid',$this->data['user']->id)->get();
			$this->data['emp-profile'] 		= Empprofile::where('uid',$this->data['user']->id)->first();
				return view('employee_self_services.profile.iou',['data'=>$this->data]);	
			break;
			case 'lost-demage-card':
			$this->data['user'] 			= Auth::User();
			$this->data["Empaddress"] 	    = Addressdetail::where('uid',$this->data['user']->id)->get();
			$this->data['emp-profile'] 		= Empprofile::where('uid',$this->data['user']->id)->first();
				return view('employee_self_services.profile.lost-demage-card',['data'=>$this->data]);	
			break;
			case 'my-cards':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.profile.mycards',['data'=>$this->data]);	
			break;
			case 'my-resume':
			$this->data['user'] 					    			= Auth::User();
			$this->data['resume'] 					    			= Resume::where('uid',$this->data['user']->id)->first();
				return view('employee_self_services.profile.my-resume',['data'=>$this->data]);	
			break;
			case 'postResume':
				$this->data['user'] 	= Auth::User();
				$filename = "";
				$file 					= Input::file('upload_file');
				if($file){
					$destinationPath 	= base_path() .'/images/users/resume';
					$filename 			= $file->getClientOriginalName();
					$filename 			= uniqid().'_'.$filename;
					$file->move($destinationPath, $filename);
				}
				$preresume 					    	= Resume::where('uid',$this->data['user']->id)->first();
				if($preresume){	
					$Resume 			= Resume::find($preresume->id);
					$Resume->resume     = $filename;
					$Resume->save();
				}else{
					$Resume 			= new Resume;
					$Resume->uid     	= $this->data['user']->id;
					$Resume->resume     = $filename;
					$Resume->save();
				}
			
			return Redirect::to('employee-services/my-resume');	
			break;	
			case 'postCreateresume':
				$this->data['user'] 	= Auth::User();
				$filename = "";
				$file 					= Input::file('empphoto');
				if($file){
					$destinationPath 	= base_path() .'/images/users/resume';
					$filename 			= $file->getClientOriginalName();
					$filename 			= uniqid().'_'.$filename;
					$file->move($destinationPath, $filename);
				}
				$preresume 					    	= Empresume::where('uid',$this->data['user']->id)->first();
				$Empresume 					= new Empresume;
				$Empresume->uid     		= $this->data['user']->id;
				$Empresume->f_name     		= $request->f_name;
				$Empresume->m_name     		= $request->m_name;
				$Empresume->l_name     		= $request->l_name;
				$Empresume->country    		= $request->country;
				$Empresume->city     		= $request->city;
				$Empresume->address     	= $request->address;
				$Empresume->phone     		= $request->phone;
				$Empresume->email     		= $request->email;
				$Empresume->website     	= $request->website;
				$Empresume->biography     	= $request->biography;
				$Empresume->date_from     	= date('Y-m-d',strtotime($request->ex_df));
				$Empresume->date_to     	= date('Y-m-d',strtotime($request->ex_dt));
				$Empresume->job_title     	= $request->job_title;
				$Empresume->short_desc     	= $request->short_desc;
				$Empresume->school_name     = $request->school_name;
				$Empresume->degree     		= $request->degree;
				$Empresume->short_descedu   = $request->short_descedu;
				$Empresume->save();
				return Redirect::to('employee-services/my-resume');	
			break;
			case 'national-identifier':
			$this->data['user'] 			= Auth::User();
			$this->data['emp-profile'] 		= Empprofile::where('uid',$this->data['user']->id)->first();
				return view('employee_self_services.profile.national-identifier',['data'=>$this->data]);	
			break;
			case 'work-experience':
			$this->data['user'] 					    			= Auth::User();
				$this->data["workExperience"]                             = Employeework::where('uid',$this->data['user']->id)->get();
				return view('employee_self_services.profile.work-experience',['data'=>$this->data]);	
			break;
			case 'add-experience':
			$this->data['user'] 					    			= Auth::User();
				$this->data["workExperience"]                             = Employeework::where('uid',$this->data['user']->id)->get();
				return view('employee_self_services.profile.add-experience',['data'=>$this->data]);	
			break;
			case 'edit_workexperince':
			$this->data['user'] 					    			= Auth::User();
				$this->data["workExperience"]                       = Employeework::find($id);
				return view('employee_self_services.profile.edit-workexperience',['data'=>$this->data]);	
			break;
			case 'postExperience':
				$user 					    		= Auth::User();
				$Employeework 						= new Employeework;
				$Employeework->uid     				= $user->id;
				$Employeework->company     			= $request->company;
				$Employeework->work_nature     		= $request->work_nature;
				$Employeework->position     		= $request->position;
				$Employeework->joining_date     	= date("Y-m-d",strtotime($request->joining_date));	
				$Employeework->leaving_date     	= date("Y-m-d",strtotime($request->leaving_date));				
				$Employeework->save();
				return Redirect::to('employee-services/work-experience');
			break;
			case 'postupdateExperience':
				$user 					    		= Auth::User();
				$Employeework 						= Employeework::find($request->id);
				$Employeework->company     			= $request->company;
				$Employeework->work_nature     		= $request->work_nature;
				$Employeework->position     		= $request->position;
				$Employeework->joining_date     	= date("Y-m-d",strtotime($request->joining_date));	
				$Employeework->leaving_date     	= date("Y-m-d",strtotime($request->leaving_date));				
				$Employeework->save();
				return Redirect::to('employee-services/work-experience');
			break;
			case 'deleteWorkexperince':
				$Employeework = Employeework::find($id);
				$Employeework->delete();
				return Redirect::to('employee-services/work-experience');
			break;
			case 'apply-claims':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.claim.apply-claims',['data'=>$this->data]);	
			break;
			case 'claim-history':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.claim.claim-history-report',['data'=>$this->data]);	
			break;
			case 'view-advance-history':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.claim.view-advance-history',['data'=>$this->data]);	
			break;
			case 'view-advance-report':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.claim.view-advance-report',['data'=>$this->data]);	
			break;
			case 'voice-data-request':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.claim.track-myworkflow',['data'=>$this->data]);	
			break;
			case 'track-myworkflow':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.responsibilities.track-my-workflow',['data'=>$this->data]);	
			break;
			case 'responsibility-management':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.responsibilities.responsibility-management',['data'=>$this->data]);	
			break;
			case 'my-workflow':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.responsibilities.my-workflow',['data'=>$this->data]);	
			break;
			case 'my-workflow':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.responsibilities.my-workflow',['data'=>$this->data]);	
			break;
			case 'confirmation-probationers':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.responsibilities.confirmation-probationers',['data'=>$this->data]);	
			break;
			case 'employee-perks':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.employeeperks.medical_assistance',['data'=>$this->data]);	
			break;
			case 'medical-assistance':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.employeeperks.medical_assistance',['data'=>$this->data]);	
			break;
			case 'higher-education-assistance':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.employeeperks.higher_education_assistance',['data'=>$this->data]);	
			break;
			case 'higher-education-assistance':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.employeeperks.higher_education_assistance',['data'=>$this->data]);	
			break;
			case 'company-transport':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.employeeperks.company_transport',['data'=>$this->data]);	
			break;
			case 'bonafide-letter':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.employeeperks.bonafide_letter',['data'=>$this->data]);	
			break;
			case 'apply-loans':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.employeeperks.apply_loans',['data'=>$this->data]);	
			break;
			case 'my-requests':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.benifits-taxes.my_requests',['data'=>$this->data]);	
			break;
			case 'travel':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.travel',['data'=>$this->data]);	
			break;
			case 'income-from-previous-employeement':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.benifits-taxes.income-from-previous-employeement',['data'=>$this->data]);	
			break;
			case 'employee-declaration':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.benifits-taxes.employee_declaration',['data'=>$this->data]);	
			break;
			case 'long-term-accommodation':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.accomodation-transport.long-term-accommodation',['data'=>$this->data]);	
			break;
			case 'accomodation-feedback':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.accomodation-transport.accomodation-feedback',['data'=>$this->data]);	
			break;
			case 'accommodation-and-transport-initiation':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.accomodation-transport.accommodation-and-transport-initiation',['data'=>$this->data]);	
			break;
			case 'allocation-deallocation':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.domestic.allocation_deallocation',['data'=>$this->data]);	
			break;
			case 'business':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.domestic.business',['data'=>$this->data]);	
			break;
			case 'feedback':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.feedback.accomodation-request',['data'=>$this->data]);	
			break;
			case 'international':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.international.business_self',['data'=>$this->data]);	
			break;
			case 'business-guest':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.international.business-guest',['data'=>$this->data]);	
			break;
			case 'deputationrelocation-onlyfamily':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.international.deputationrelocation-onlyfamily',['data'=>$this->data]);	
			break;
			case 'deputationRelocation-selfWith-family':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.international.deputation-relocation-selfwith-family',['data'=>$this->data]);	
			break;
			case 'travel-nominee':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.mytravel-essentials.travel-nominee',['data'=>$this->data]);	
			break;
			case 'residency':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.mytravel-essentials.residency',['data'=>$this->data]);	
			break;
			case 'frequent-flyer-details':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.mytravel-essentials.frequent-flyer-details',['data'=>$this->data]);	
			break;
			case 'apply-visa-details':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.travel.mytravel-essentials.apply-visa-details',['data'=>$this->data]);	
			break;
			case 'create-resume':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.create-resume',['data'=>$this->data]);	
			break;
			case 'employee-address':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.employee-address',['data'=>$this->data]);	
			break;
			case 'postGrievance':
				$this->data['user'] 					    			= Auth::User();
				
				$filename = "";
				$file 					= Input::file('attachment_p');
				if($file){
					$destinationPath 	= base_path() .'/images/users/grievance';
					$filename 			= $file->getClientOriginalName();
					$filename 			= uniqid().'_'.$filename;
					$file->move($destinationPath, $filename);
				}
				/* To save employee Grievance into the database */
				$Employeegrievance 				 = new Employeegrievance;
				$Employeegrievance->uid     	 = $this->data['user']->id;
				$Employeegrievance->category     = $request->grievanceType;
				$Employeegrievance->subject      = $request->subject;
				$Employeegrievance->descrip      = $request->descrip;
				$Employeegrievance->attach       = $filename;
				$Employeegrievance->save();
				return Redirect::to('employee-services/employee-address');
			break;
			case 'my-documents':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.my-documents',['data'=>$this->data]);	
			break;
			case 'getDocument':
				$this->data['user'] 					    			= Auth::User();
				/* $sqlQuery = "SELECT * FROM payroll where MONTH(from_date) = ".$request->from_month." and YEAR(from_date) = ".$request->docfromyear." and MONTH(to_date) = ".$request->tomonth." and YEAR(to_date) = ".$request->doctoyear."";
				$result = DB::select(DB::raw($sqlQuery)); */
				$Employeedocreq 				= new Employeedocreq;
				$Employeedocreq->uid     	 	= $this->data['user']->id;
				$Employeedocreq->doctype      	= $request->doctype;
				$Employeedocreq->doccountry     = $request->doccountry;
				$Employeedocreq->period      	= $request->period;
				$Employeedocreq->company_logo   = $request->company_logo;
				$Employeedocreq->from_month    	= $request->from_month;
				$Employeedocreq->docfromyear    = $request->docfromyear;
				$Employeedocreq->tomonth       	= $request->tomonth;
				$Employeedocreq->doctoyear     	= $request->doctoyear;
				$Employeedocreq->save();
				 \Session::flash('success','Your Request has been Successfully Generated.');
				return Redirect::to('employee-services/my-documents');
				
			break;
			case 'positions':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.positions',['data'=>$this->data]);	
			break;
			case 'position-detail':
			$this->data['user'] 					    			= Auth::User();
				return view('employee_self_services.position-detail',['data'=>$this->data]);	
			break;
			default:

				return view('employee_self_services.employee-concern',['data'=>$this->data]);	 

				break;		
		}
		
	}
	
	public static function getUser($id){
		$user = User::where('id',$id)->first();
		return $user->name;
	}
	
	public static function getUsersalary($id){
		$user = User::where('id',$id)->first();
		return $user->salary;
	}
}
