<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Auth;

use App\User;

use Validator;

use App\Department;

Use App\Salarytemplate;

use Illuminate\Support\Facades\Redirect;

use DB;

use App\Company;

use App\Employeecredential;

use App\Employeereporting;

use Illuminate\Support\Facades\Input;

use App\Fullandfinal;

use App\Addressproof;

use App\Education;

use App\Previousemployement;

use App\Resignationrequest;

use App\Resignationformality;

class UsersController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
	 
	 public $data = [];
	 
    public function __construct()
    {
        $this->middleware('auth');
		
		$this->title = "All Employees";

		$this->users = User::where('user_type','!=','0')->where('emp_stat','1')->get();
		
		$this->departments 			= Department::all();
		
		$this->data['users'] 		= $this->users;
		
		$this->data['title'] 		= $this->title;
		
		$this->controller 			= $this;
		
		$this->data['departments'] 	= $this->departments;
		
		$this->companies 			= Company::all();
		
		$this->country   			= ["India" => "India","Indonesia" => "Indonesia","Iran" => "Iran","Iraq" => "Iraq","Ireland" => "Ireland"];
		$this->data["country"] 		= $this->country;
		
		$this->data['companies'] 	= $this->companies;
		
		$this->data['controller'] 	= $this->controller;
		
		/* $this->checkPermission 		=  Department::where('id',$user->id)->first();
		
		$this->getPermission 		=  json_decode($this->checkPermission->permission);
		
		$this->data['permissions']	=	$this->getPermission; */
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
	
	public function action(Request $request,$action=null,$id=null)

	{
		$user = Auth::user();
			
		$this->checkPermission 		=  Department::where('id',$user->e_department)->first();
		if($this->checkPermission){
			$this->getPermission 		=  json_decode($this->checkPermission->permission);
	
			$this->data['permissions']	=	$this->getPermission;
		}else{
			$this->data['permissions']	=	[];
		}
	
		
		
		switch ($action)

		{
			
			case 'view':
				if($user->user_type == "0" || in_array('view_employees',$this->data["permissions"])){
					$this->data['title'] 			= "Employee";
					$this->data["user"] 			= User::find($id);
					return view('admin.users.view-user',['data'=>$this->data]);	
				}else{
					return "Unathorized";
				}
			break;
			
				case 'view-previous':
				if($user->user_type == "0" || in_array('view_employees',$this->data["permissions"])){
					$this->data['title'] 			= "Employee";
					$this->data["user"] 			= User::find($id);
					$this->data["fullandfianl"] 	= Fullandfinal::where("uid",$id)->first();
					return view('admin.users.view-previous',['data'=>$this->data]);	
				}else{
					return "Unathorized";
				}
			break;
			
			case 'add':
			
				if($user->user_type == "0" || in_array('newemployee',$this->data["permissions"])){
					
					$this->data['title'] = "Add New Employee";
					$this->data['uuid'] 	= DB::table("emp_uid")->first();
				
					return view('admin.users.add-user',['data'=>$this->data]);
					
				}else{
					
					return "Unathorized";
					
				}

				

				break;								
				
				
			case 'postAdd':
				if($user->user_type == "0" || in_array('newemployee',$this->data["permissions"])){
					$validator = $this->postEmpvalidator($request->all());
					$options = ['cost' => '12'];
					if($validator->fails()){
						return redirect::to('users/add')->withErrors($validator);
					}else{
						$filename = "";
						$file 							= Input::file('emp_photo');
						if($file){
							$destinationPath 				= base_path() .'/images/users/';
							$filename 						= $file->getClientOriginalName();
							$filename 						= uniqid().'_'.$filename;
							$file->move($destinationPath, $filename);
						}
						
						
						
						$bankstatement = "";
						$file 							= Input::file('bank_statement');
						if($file){
							$destinationPath 				= base_path() .'/images/users/';
							$bankstatement 						= $file->getClientOriginalName();
							$bankstatement 						= uniqid().'_'.$bankstatement;
							$file->move($destinationPath, $bankstatement);
						}
						
						$accountstatement = "";
						$file 							= Input::file('account_statement');
						if($file){
							$destinationPath 				= base_path() .'/images/users/';
							$accountstatement 						= $file->getClientOriginalName();
							$accountstatement 						= uniqid().'_'.$accountstatement;
							$file->move($destinationPath, $accountstatement);
						}
						
						$cancelcheck = "";
						$file 							= Input::file('account_statement');
						if($file){
							$destinationPath 				= base_path() .'/images/users/';
							$cancelcheck 						= $file->getClientOriginalName();
							$cancelcheck 						= uniqid().'_'.$cancelcheck;
							$file->move($destinationPath, $cancelcheck);
						}
						
						$unQid 						= date("ym",strtotime($request->joining));
						$lastUser 					= User::orderby('created_at', 'desc')->first();
						if($user->emp_stat == "1"){
							$unicId = $lastUser->uuid+1;
						}else{
							$Uid 	= DB::table("emp_uid")->first();
					
							if($request->uuid == $Uid->uid+1){
								$unicId = $Uid->uid+1;
								DB::table('emp_uid')
								->update(['uid' => $unicId]);
							}else{
								$unicId = $request->uuid;
							}
						}
						
						
						$options  					= ['cost' => '12'];
						 
						$user 						= new User;
						$user->name 				= $request->e_name;
						$user->unQid 				= $unQid;
						$user->uuid         		= $unicId;
						$user->f_name 				= $request->e_name;
						$user->l_name 				= $request->e_surname;
						$user->father_name 			= $request->father_name;
						$user->password 		   	= password_hash($request->input('e_pass'),PASSWORD_BCRYPT,$options);
						$user->show_pass 		   	= $request->input('e_pass');
						$user->email 				= $request->e_email;
						$user->image 				= $filename;
						$user->phone_number 		= $request->e_contact1;
						$user->address 				= $request->e_address;
						$user->dob 					= date('Y-m-d',strtotime($request->e_dob));		
						$user->houseno 				= $request->house_no;
						$user->address_street_no1 	= $request->address_street_no1;
						$user->country 				= $request->country;
						$user->postal_code 			= $request->postal_code;
						$user->company 				= $request->company;
						$user->e_contact1 			= $request->e_contact2;
						$user->emp_type 			= $request->emp_type;
						$user->working_hours 		= $request->working_hours;
						$user->working_weeks 		= json_encode($request->working_weeks);
						$user->notice_period 		= $request->notice_period;
						$user->for_days 			= $request->for_days;
						$user->prob_start_date 		= date('Y-m-d',strtotime($request->prob_start_date));
						$user->prob_end_date 		 = date('Y-m-d',strtotime($request->prob_end_date));
						$user->doo 					= date('Y-m-d',strtotime($request->offer_date));		
						$user->doj 					= date('Y-m-d',strtotime($request->offer_date));
						$user->doa 					= date('Y-m-d',strtotime($request->offer_date));	
						$user->e_department 		= $request->e_department;
						$user->salary 				= $request->e_salary;
						$user->sex 					= $request->sex;
						$user->religion 			= $request->religion;
						$user->jobtitle 			= $request->jobtitle;
						$user->qualification 		= $request->qualification;	
						$user->bank_author 			= $request->name;	
						$user->branch 				= $request->branch;
						$user->city 				= $request->city;
						$user->acc_no 				= $request->acc_no;
						$user->ifsccode 			= $request->ifsccode;
						$user->remark 				= $request->remark;
						$user->user_type 			= '3';
						$user->emp_stat				= $request->emp_stat;
						$user->bank_statement		= $bankstatement;
						$user->account_statement	= $accountstatement;
						$user->cancel_check			= $cancelcheck;
						$user->emp_docs 			= " ";
						if($user->save())
						{
							$company = Company::find($request->company);
							$emails = json_decode($company->email);
							$emails = implode(",",$emails);
							//$emails = "banish.mst@gmail.com";
							$subject = 'New Employee Added into '.$company->name;
							  $date =date('Ymd');
							  $date =  date('D M,Y',strtotime($date));
							  $message = '<html >
												  <head>
												  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
													  <title>Password Changed</title>
													  <style>
													  .wrapper{
														float:none;
														width:500px;
														margin:0 auto;
													  }
													   .wrapper h2{
														float:left;
														width:100%;
														text-align:center;
													  }
													   .wrapper h3{
														float:left;
														width:100%;
														text-align:center;
													  }
													  .wrapper h4{
														float:left;
														width:100%;
														text-align:center;
													  }
													   .wrapper span{
														float:left;
														width:100%;
														text-align:center;
														font-size:22px;
													  }
													  .HCL{
														float:left;
														width:100%;
														border:1px solid #DEE3E9;
													  }
													  .HCL h4 b{
														color:red;
													  }
													   .HCL p{
														float:left;
														width:100%;
														text-align:center;
													  }
													  </style>
												</head>
												<body>
												<div class="wrapper"> 
													<h2>Howdy '.Auth::user()->name.'</h2>
													<h3>New Employee Added into the Employee Portal</h3>
													<span>On '.$date.'</span>
													<div class="HCL">
														<h4>Employee Name is :- <b>'.$user->name.'</b></h4>
														<p>You can view This Employee Details on Admin Portal.</p>
													</div>
												</div>
												</body>
												</html>';
							  $headers = 'From: info@mindxpert.com' . "\r\n" .
								'Reply-To: info@mindxpert.com' . "\r\n" .
								'X-Mailer: PHP/' . phpversion();
							  $headers .= "MIME-Version: 1.0\r\n";
							  $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
							  mail($emails, $subject, $message, $headers);
							 \Session::flash('success','Employee Successfully Added.');
						}
						else
						{
							 \Session::flash('error','Error! Please Contact Administrator.'); 
						}
						if($user->emp_stat == "1"){
							return redirect::to('users');
						}else{
							return redirect::to('users/fullandfinal');
						}
					}
				}else{
					return "Unathorized";
				}
				
				break;
			case 'edit':
			
				

				if($user->user_type == "0" || in_array('edit_employee',$this->data["permissions"])){
					$this->data['title'] 	= "Edit Employee Information";
				
					$this->data["user"] 			= User::find($id);			

					return view('admin.users.edit-user',['data'=>$this->data]);
				}else{
					return "Unathorized";
				}
				
				

				break;	
			case 'postUpdate':
				if($user->user_type == "0" ||  in_array('edit_employee',$this->data["permissions"])){
						$filename = "";
					$file 							= Input::file('emp_photo');
					if($file){
						$destinationPath 				= base_path() .'/images/users/';
						$filename 						= $file->getClientOriginalName();
						$filename 						= uniqid().'_'.$filename;
						$file->move($destinationPath, $filename);
					}else{
						$filename = $request->preimage;
					}
					
					$address_proof1filename = "";
					$file 							= Input::file('address_proof1');
					if($file){
						$destinationPath 								= base_path() .'/images/users/';
						$address_proof1filename 						= $file->getClientOriginalName();
						$address_proof1filename 						= uniqid().'_'.$address_proof1filename;
						$file->move($destinationPath, $address_proof1filename);
					}else{
						$address_proof1filename = $request->address_proof1preimage;
					}
					
					$idproof1filename = "";
					$file 							= Input::file('id_proof_files');
					if($file){
						$destinationPath 				= base_path() .'/images/users/';
						$idproof1filename 						= $file->getClientOriginalName();
						$idproof1filename 						= uniqid().'_'.$idproof1filename;
						$file->move($destinationPath, $idproof1filename);
					}else{
						$idproof1filename = $request->idproof1filenamepreimage;
					}
					
					if($request->name == ""){
						$request->name == " ";
					}
					if($request->unQid == ""){
						$request->unQid == " ";
					}
					if($request->f_name == ""){
						$request->f_name == " ";
					}
					if($request->l_name == ""){
						$request->l_name == " ";
					}
					if($request->email == ""){
						$request->email == " ";
					}
					if($request->image == ""){
						$request->image == " ";
					}
					if($request->phone_number == ""){
						$request->phone_number == " ";
					}
					if($request->address == ""){
						$request->address == " ";
					}
					if($request->salary == ""){
						$request->salary == " ";
					}
					
					if($request->dob == ""){
						$request->dob == " ";
					}
					if($request->houseno == ""){
						$request->houseno == " ";
					}
					if($request->address_street_no1 == ""){
						$request->address_street_no1 == " ";
					}
					if($request->country == ""){
						$request->country == " ";
					}
					if($request->postal_code == ""){
						$request->postal_code == " ";
					}
					if($request->e_contact1 == ""){
						$request->e_contact1 == " ";
					}
					if($request->emp_type == ""){
						$request->emp_type == " ";
					}
					if($request->working_hours == ""){
						$request->working_hours == " ";
					}
					if($request->notice_period == ""){
						$request->notice_period == " ";
					}
					if($request->for_days == ""){
						$request->for_days == " ";
					}
					if($request->prob_start_date == ""){
						$request->prob_start_date == " ";
					}
					if($request->prob_end_date == ""){
						$request->prob_end_date == " ";
					}
					if($request->doa == ""){
						$request->doa == " ";
					}
					if($request->doj == ""){
						$request->doj == " ";
					}
					if($request->e_department == ""){
						$request->e_department == " ";
					}
					if($request->salary == ""){
						$request->salary == " ";
					}
					if($request->sex == ""){
						$request->sex == " ";
					}
					if($request->religion == ""){
						$request->religion == " ";
					}
					if($request->qualification == ""){
						$request->qualification == " ";
					}
					if($request->jobtitle == ""){
						$request->jobtitle == " ";
					}
					if($request->qualification == ""){
						$request->qualification == " ";
					}
					if($request->addressproof == ""){
						$request->addressproof == " ";
					}
					if($request->idproof == ""){
						$request->idproof == " ";
					}
					if($request->id_proof_files == ""){
						$request->id_proof_files == " ";
					}
					if($request->bank_author == ""){
						$request->bank_author == " ";
					}
					if($request->branch == ""){
						$request->branch == " ";
					}
					if($request->city == ""){
						$request->city == " ";
					}
					if($request->acc_no == ""){
						$request->acc_no == " ";
					}
					if($request->ifsccode == ""){
						$request->ifsccode == " ";
					}
					if($request->remark == ""){
						$request->remark == " ";
					}
					
					/* if($user->emp_stat == "1"){
						$unicId = $lastUser->uuid+1;
					}else{
						$Uid 	= DB::table("emp_uid")->first();
						if($request->uuid == $Uid->uid+1){
							$unicId = $Uid->uid+1;
							DB::table('emp_uid')
							->update(['uid' => $unicId]);
						}else{
							$unicId = $request->uuid;
						}
					} */
					
					
					$options 					= ['cost' => '12'];
					$user 						= User::find($request->id);
					$lastUser 					= User::orderby('created_at', 'desc')->first(); 	
					$user->name 				= $request->e_name;
					$user->f_name 				= $request->e_name;
					$user->l_name 				= $request->e_surname;
					$user->father_name 			= $request->father_name;
					$user->email 				= $request->e_email;
					$user->image 				= $filename;
					$user->phone_number 		= $request->e_contact1;
					$user->address 				= $request->e_address;
					$user->salary 				= $request->e_salary;
					$user->dob 					= date('Y-m-d',strtotime($request->e_dob));		
					$user->houseno 				= $request->house_no;
					$user->address_street_no1 	= $request->address_street_no1;	
					$user->country 				= $request->country;
					$user->company 				= $request->company;
					$user->postal_code 			= $request->postal_code;
					$user->e_contact1 			= $request->e_contact2;	
					$user->emp_type 			= $request->emp_type;
					$user->working_hours 		= $request->working_hours;
					$user->working_weeks 		= json_encode($request->working_weeks);
					$user->notice_period 		= $request->notice_period;
					$user->for_days 			= $request->for_days;
					$user->prob_start_date 		= date('Y-m-d',strtotime($request->prob_start_date));$user->prob_end_date 		= date('Y-m-d',strtotime($request->prob_end_date));		$user->doa 					= date('Y-m-d',strtotime($request->app_date));		
					$user->doj 					= date('Y-m-d',strtotime($request->joining));		$user->e_department 		= $request->e_department;
					$user->salary 				= $request->e_salary;
					$user->sex 					= $request->sex;
					$user->religion 			= $request->religion;
					$user->jobtitle 			= $request->jobtitle;
					$user->qualification 		= $request->qualification;
					$user->address_proof1 		= "test";
					$user->addressproof 		= $request->addressproof;
					$user->idproof 				= $request->idproof;
					$user->id_proof_files 		= $idproof1filename;
					$user->bank_author 			= $request->name;
					$user->branch 				= $request->branch;
					$user->city 				= $request->city;
					$user->acc_no 				= $request->acc_no;
					$user->ifsccode 			= $request->ifsccode;
					$user->remark 				= $request->remark;
					$user->emp_docs 			= " ";
					
					
					if($user->save())

					{

						 \Session::flash('success','Employee Successfully Added.');


					}

					else

					{

						 \Session::flash('error','Error! Please Contact Administrator.'); 

					}

					return redirect::to('users');

					return view('admin.users.pending-leaves',['data'=>$this->data]);
				}else{
					return "Unathorized";
				}
				
				
			break;
			case 'getUsers':
			
				if($request->department != ""){
					
					$this->data["users"] = User::where('e_department',$request->department)->get();
					
				}
				
				return view('admin.users.users',['data'=>$this->data]);	
				
			break;	
				
			case 'delete':
			
				if($user->user_type == "0" || in_array('view_employees_delete',$this->data["permissions"])){
					$prev_select_item_id = $request->prev_select_item_id;
				
					if($prev_select_item_id != ""){
						$prev_select_item_id = explode("_",$request->prev_select_item_id);
					
						foreach($prev_select_item_id as $id){
							
							User::where('id',$id)->delete();
						}
					}
			
					return redirect::to('users');

				}else{
					return "Unathorized";
				}
				
				break;
				
				case 'deletefullfinal':
			
				if($user->user_type == "0" || in_array('view_employees_delete',$this->data["permissions"])){
					$prev_select_item_id = $request->prev_select_item_id;
				
					if($prev_select_item_id != ""){
						$prev_select_item_id = explode("_",$request->prev_select_item_id);
					
						foreach($prev_select_item_id as $id){
							
							User::where('id',$id)->delete();
						}
					}
			   
					return redirect::to('users/fullandfinal');

				}else{
					return "Unathorized";
				}
				
				break;
				
				case 'deletDocimg':
					if($user->user_type == "0" || in_array('edit_employee',$this->data["permissions"])){
						$img = $request->img;
						$User = User::find($request->id);
						$images = $User->emp_docs;
						$images = explode(",",$images);
						$newImges = [];
						foreach($images as $nimg){
							if($nimg == $img){
								
							}else{
								array_push($newImges,$nimg);
							}
						}
						$newImges = implode(",",$newImges);
						$User->emp_docs = $newImges;
						$User->save();
						$result = json_encode(array("data"  => $newImges));
				   
						return $result;

					}else{
						return "Unathorized";
					}
				
				break;
				
				case 'salary_template':
			
				if($user->user_type == "0" || in_array('edit_employee',$this->data["permissions"])){
					$this->data['title'] 	= "Setup Employee Salary Template";
					$this->data['salarytemplate'] 	= Salarytemplate::where('uid',$id)->first();	
				
					$this->data["user"] 			= User::find($id);			

					return view('admin.users.salary-template',['data'=>$this->data]);
				}else{
					return "Unathorized";
				}
				
				break;
				case 'postupdateTemplate':
				
		
				
					if($user->user_type == "0" || in_array('edit_employee',$this->data["permissions"])){
						
					$checkTemp = Salarytemplate::where('uid',$request->empid)->first();	
					
					
					if($checkTemp){
						$Salarytemplate 				    = Salarytemplate::where("uid",$checkTemp->uid)->first();
			$Salarytemplate->template_name 						= $request->template_name;
			$Salarytemplate->basicsalary 						= $request->basicpay;
			$Salarytemplate->total_allowance    				= $request->total_allowance_value;
			$Salarytemplate->total_allowance_detail 			= json_encode($request->allowance_name);
			$Salarytemplate->total_allowence_value 				= json_encode($request->allowance_value);
			$Salarytemplate->total_deduction 		   			= $request->total_deduction_value;
			$Salarytemplate->total_deduction_detail 			= json_encode($request->deduction_name);
			$Salarytemplate->total_deduction_value 				= json_encode($request->deduction_value);
			$Salarytemplate->net_salary 						= $request->net_pay;
			$Salarytemplate->salary_period 						= json_encode($request->salary_period);
			$Salarytemplate->employee_CPF_rate 					= $request->employee_cpf_rate;
			$Salarytemplate->employer_CPF_contribution_rate 	= $request->employer_cpf_rate;
			$Salarytemplate->aditional_payment 			  		= $request->total_payment_value;
			$Salarytemplate->aditional_payment_detail 			= json_encode($request->payment_name);
			$Salarytemplate->aditional_payment_value 			= json_encode($request->payment_value);
			$Salarytemplate->notes 								= $request->note;
						
						if($Salarytemplate->save())
						{
							 \Session::flash('success','Employee Successfully Added.');
						}
						else
						{
							 \Session::flash('error','Error! Please Contact Administrator.'); 
						}
					}else{
			$Salarytemplate 				    				= new Salarytemplate;
			$Salarytemplate->uid 								= $request->empid;
			$Salarytemplate->template_name 						= $request->template_name;
			$Salarytemplate->basicsalary 						= $request->basicpay;
			$Salarytemplate->total_allowance    				= $request->total_allowance_value;
			$Salarytemplate->total_allowance_detail 			= json_encode($request->allowance_name);
			$Salarytemplate->total_allowence_value 				= json_encode($request->allowance_value);
			$Salarytemplate->total_deduction 		   			= $request->total_deduction_value;
			$Salarytemplate->total_deduction_detail 			= json_encode($request->deduction_name);
			$Salarytemplate->total_deduction_value 				= json_encode($request->deduction_value);
			$Salarytemplate->net_salary 						= $request->net_pay;
			$Salarytemplate->salary_period 						= json_encode($request->salary_period);
			$Salarytemplate->employee_CPF_rate 					= $request->employee_cpf_rate;
			$Salarytemplate->employer_CPF_contribution_rate 	= $request->employer_cpf_rate;
			$Salarytemplate->aditional_payment 			  		= $request->total_payment_value;
			$Salarytemplate->aditional_payment_detail 			= json_encode($request->payment_name);
			$Salarytemplate->aditional_payment_value 			= json_encode($request->payment_value);
			$Salarytemplate->notes 								= $request->note;
						
						if($Salarytemplate->save())
						{
							 \Session::flash('success','Employee Successfully Added.');
						}
						else
						{
							 \Session::flash('error','Error! Please Contact Administrator.'); 
						}
					}
					return redirect::to('users');
				}else{
					return "Unathorized";
				}
				
				break;
			case 'employee-credential':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->where('emp_stat','1')->get();
				return view('admin.employee-credential.credentail',['data'=>$this->data]);
			case 'add-credential':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->where('emp_stat','1')->get();
				return view('admin.employee-credential.add-credential',['data'=>$this->data]);
			case 'postaddCredential':
				$validator = $this->validator($request->all());
				$options = ['cost' => '12'];
				if($validator->fails()){
					return redirect::to('users/add-credential')->withErrors($validator);
				}else{
					$Employeecredential 					= new Employeecredential;
					$Employeecredential->uid 				= $request->user;
					$Employeecredential->credential_type 	= $request->credential_type;
					$Employeecredential->username  			= $request->username ;
					$Employeecredential->password 			= base64_encode($request->password);
					$Employeecredential->save();
					return redirect::to("users/employee-credential");
				}
				
			break;
			case 'edit-credential':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->where('emp_stat','1')->get();
				$this->data["credential"] = Employeecredential::find($id);
				return view('admin.employee-credential.edit-credential',['data'=>$this->data]);	
			case 'postupdateCredential':
				$Employeecredential 					= Employeecredential::find($request->id);
				$Employeecredential->uid 				= $request->user;
				$Employeecredential->credential_type 	= $request->credential_type;
				$Employeecredential->username  			= $request->username ;
				$Employeecredential->password 			= base64_encode($request->password);
				$Employeecredential->save();
				return redirect::to("users/get-credential?user=".$request->user);
			break;	
			case 'get-credential':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->where('emp_stat','1')->get();
				$this->data["credentials"] = Employeecredential::where("uid",$request->user)->get();
				return view('admin.employee-credential.credentail',['data'=>$this->data]);	
			break;	
			case 'delete-credential':
				Employeecredential::where('id',$id)->delete();
				return redirect::to("users/employee-credential");
			break;
			case 'reporting':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->get();
				return view('admin.users.reporting',['data'=>$this->data]);	
			break;
			case 'get-reporting':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->where('emp_stat','1')->get();
				$this->data["reportings"] = Employeereporting::where("uid",$request->user)->get();
				return view('admin.users.reporting',['data'=>$this->data]);	
			break;
			case 'add-reporting':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->where('emp_stat','1')->get();
				return view('admin.users.add-reporting',['data'=>$this->data]);	
			break;
			case 'postaddReporting':
				$validator = $this->reportingvalidator($request->all());
				$options = ['cost' => '12'];
				if($validator->fails()){
					return redirect::to('users/add-reporting')->withErrors($validator);
				}else{
					$Employeereporting 						= new Employeereporting;
					$Employeereporting->uid 				= $request->user;
					$Employeereporting->reporting_manager 	= $request->reporting_manager;
					$Employeereporting->hr_manager  		= $request->hr_manager ;
					$Employeereporting->finance_manager 	= $request->finance_manager;
					$Employeereporting->admin_manager 		= $request->admin_manager;
					$Employeereporting->save();
					return redirect::to('users/reporting');
				}
			break;
			case 'edit-reporting':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->where('emp_stat','1')->get();
				$this->data["reporting"] = Employeereporting::find($id);
				return view('admin.users.edit-reporting',['data'=>$this->data]);	
			break;
			case 'postupdateReporting':
				$validator = $this->reportingvalidator($request->all());
				$options = ['cost' => '12'];
				if($validator->fails()){
					return redirect::to('users/add-reporting')->withErrors($validator);
				}else{
					$Employeereporting 						= Employeereporting::find($request->id);
					$Employeereporting->uid 				= $request->user;
					$Employeereporting->reporting_manager 	= $request->reporting_manager;
					$Employeereporting->hr_manager  		= $request->hr_manager ;
					$Employeereporting->finance_manager 	= $request->finance_manager;
					$Employeereporting->admin_manager 		= $request->admin_manager;
					$Employeereporting->save();
					return redirect::to('users/reporting');
				}
			break;
			case 'delete-reporting':
				Employeereporting::where('id',$id)->delete();
				return redirect::to("users/employee-credential");
			break;
			
			case 'fullandfinal':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->where('emp_stat','2')->get();
				return view("admin.users.fullandfinal",['data'=>$this->data]);
			break;
			case 'add-previous':
			
				if($user->user_type == "0" || in_array('newemployee',$this->data["permissions"])){
					
					$this->data['title'] 	= "Add New Previous Employee";
					$this->data['uuid'] 	= DB::table("emp_uid")->first();
				
					return view('admin.users.add-previous-emp',['data'=>$this->data]);
					
				}else{
					
					return "Unathorized";
					
				}
				break;
				case 'edit-previous':
				
				if($user->user_type == "0" || in_array('edit_employee',$this->data["permissions"])){
					$this->data['title'] 	= "Edit Employee Information";
				
					$this->data["user"] 			= User::find($id);			

					return view('admin.users.edit-previous-emp',['data'=>$this->data]);
				}else{
					return "Unathorized";
				}
	
				break;
				case 'final-detail':
				$this->data["users"] = DB::table('users')->where('user_type','!=','0')->where('emp_stat','2')->get();
				return view('admin.users.final-detail',['data'=>$this->data]);	
				break;
				case 'get-fullemp':
					$uid 			= $request->id;
					$Fullandfinal 	= Fullandfinal::where("uid",$uid)->first();
					if($Fullandfinal){
						$Fullandfinal->rgappdate 		= date('m/d/Y',strtotime($Fullandfinal->rgappdate));
						$Fullandfinal->rgadate  		= date('m/d/Y',strtotime($Fullandfinal->rgadate));
					}
					return json_encode(array("result" => $Fullandfinal));
				break;
				case 'postUpdateFinal':
					$uid 			= $request->user;
					$Fullandfinal 						= Fullandfinal::where("uid",$uid)->first();
				
					if($request->pendi == "1"){
						$pending = $request->pending;
					}else{
						$pending = "0";
					}
				
					if($Fullandfinal){
						$Fullandfinal 					= Fullandfinal::where("uid",$uid)->first();
						$Fullandfinal->uid 				= $request->user;
						$Fullandfinal->rgappdate 		= date('Y-m-d',strtotime($request->rgappdate));
						$Fullandfinal->rgadate  		= date('Y-m-d',strtotime($request->rgadate));
						$Fullandfinal->nperiod 			= $request->nperiod;
						$Fullandfinal->pending 			= $pending;
						$Fullandfinal->hoto 			= $request->hoto;
						$Fullandfinal->save();
					}else{
						$Fullandfinal 					= new Fullandfinal;
						$Fullandfinal->uid 				= $request->user;
						$Fullandfinal->rgappdate 		= date('Y-m-d',strtotime($request->rgappdate));
						$Fullandfinal->rgadate  		= date('Y-m-d',strtotime($request->rgadate));
						$Fullandfinal->nperiod 		 	= $request->nperiod;
						$Fullandfinal->pending 			= $pending;
						$Fullandfinal->hoto 			= $request->hoto;
						$Fullandfinal->save();
					}
					return redirect::to("users/final-detail");
				break;
			case 'delete-reporting':
				$Fullandfinal::where('id',$id)->delete();
				return redirect::to("users/final-detail");
			break;
			case 'address-proof':
			
				if($user->user_type == "0" || in_array('newemployee',$this->data["permissions"])){
					
					$this->data["Addressproof"] = Addressproof::where('uid',$request->id)->first();
					
					$this->data['title'] 	= "Upload Employee Address and Id Proofs";
					$this->data['user'] 	= User::find($request->id);
				
					return view('admin.users.address-proof',['data'=>$this->data]);
					
				}else{
					
					return "Unathorized";
					
				}
				break;
			case 'updateDocs':
				$adhar = "";
				$file 							= Input::file('adhar');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$adhar 						= $file->getClientOriginalName();
					$adhar 						= uniqid().'_'.$adhar;
					$file->move($destinationPath, $adhar);
				}else{
					$adhar = $request->preadhar;
				}
				/**
					Driving License
				*/
				$driving_license = "";
				$file 							= Input::file('driving_license');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$driving_license 						= $file->getClientOriginalName();
					$driving_license 						= uniqid().'_'.$driving_license;
					$file->move($destinationPath, $driving_license);
				}else{
					$driving_license = $request->predriving_license;
				}
				/**
					Pan Card
				*/
				$pancard = "";
				$file 							= Input::file('pancard');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$pancard 						= $file->getClientOriginalName();
					$pancard 						= uniqid().'_'.$pancard;
					$file->move($destinationPath, $pancard);
				}else{
					$pancard = $request->prepancard;
				}
				/**
					Voter Card
				*/
				$votercard = "";
				$file 							= Input::file('votercard');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$votercard 						= $file->getClientOriginalName();
					$votercard 						= uniqid().'_'.$votercard;
					$file->move($destinationPath, $votercard);
				}else{
					$votercard = $request->prevotercard;
				}
				/**
					Passport
				*/
				$passport = "";
				$file 							= Input::file('passport');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$passport 						= $file->getClientOriginalName();
					$passport 						= uniqid().'_'.$passport;
					$file->move($destinationPath, $passport);
				}else{
					$passport = $request->prepassport;
				}
				/**
					Other
				*/
				$other = "";
				$file 							= Input::file('other');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$other 						= $file->getClientOriginalName();
					$other 						= uniqid().'_'.$other;
					$file->move($destinationPath, $other);
				}else{
					$other = $request->preother;
				}
				if($adhar == ""){
					$adhar = " ";
				}
				if($driving_license == ""){
					$driving_license = " ";
				}
				if($pancard == ""){
					$pancard = "";
				}
				if($votercard == ""){
					$votercard = " ";
				}
				if($passport == ""){
					$passport = " ";
				}
				if($other == ""){
					$other = " ";
				}
				$Addressproof = Addressproof::where("uid",$request->uid)->first();
				if($Addressproof){
					$Addressproof 					= Addressproof::where("uid",$request->uid)->first();
					$Addressproof->adharcard 		= $adhar;
					$Addressproof->driving_license  = $driving_license;
					$Addressproof->pan_card 		= $pancard;
					$Addressproof->votercard 		= $votercard;
					$Addressproof->passport 		= $passport;
					$Addressproof->other 			= $other;
					$Addressproof->save();
				}else{
					$Addressproof 					= new Addressproof;
					$Addressproof->uid 				= $request->uid;
					$Addressproof->adharcard 		= $adhar;
					$Addressproof->driving_license  = $driving_license;
					$Addressproof->pan_card 		= $pancard;
					$Addressproof->votercard 		= $votercard;
					$Addressproof->passport 		= $passport;
					$Addressproof->other 			= $other;
					$Addressproof->save();
				}
				 
				if($Addressproof->save())

				{

					 \Session::flash('success','Documents Successfully Uploaded.');


				}

				else

				{

					 \Session::flash('error','Error! Please Contact Administrator.'); 

				}
				return redirect::to('users/address-proof/'.$request->uid);
			break;
			case 'education':
			
				if($user->user_type == "0" || in_array('newemployee',$this->data["permissions"])){
					
					$this->data["Education"] = Education::where('uid',$request->id)->first();
					
					$this->data['title'] 	= "Upload Educational Documents";
					$this->data['user'] 	= User::find($request->id);
				
					return view('admin.users.education',['data'=>$this->data]);
					
				}else{
					
					return "Unathorized";
					
				}
				break;
			case 'updateEducation':
				$matric = "";
				$file 							= Input::file('10th');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$matric 						= $file->getClientOriginalName();
					$matric 						= uniqid().'_'.$matric;
					$file->move($destinationPath, $matric);
				}else{
					$matric = $request->pre10th;
				}
				/**
					Plus Two
				*/
				$plustwo = "";
				$file 							= Input::file('plustwo');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$plustwo 						= $file->getClientOriginalName();
					$plustwo 						= uniqid().'_'.$plustwo;
					$file->move($destinationPath, $plustwo);
				}else{
					$plustwo = $request->preplustwo;
				}
				/**
					Diploma
				*/
				$diploma = "";
				$file 							= Input::file('diploma');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$diploma 						= $file->getClientOriginalName();
					$diploma 						= uniqid().'_'.$diploma;
					$file->move($destinationPath, $diploma);
				}else{
					$diploma = $request->prediploma;
				}
				/**
					Graduation
				*/
				$graduation = "";
				$file 							= Input::file('graduation');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$graduation 						= $file->getClientOriginalName();
					$graduation 						= uniqid().'_'.$graduation;
					$file->move($destinationPath, $graduation);
				}else{
					$graduation = $request->pregraduation;
				}
				/**
					Post Graduation
				*/
				$postgraduation = "";
				$file 							= Input::file('postgraduation');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$postgraduation 						= $file->getClientOriginalName();
					$postgraduation 						= uniqid().'_'.$postgraduation;
					$file->move($destinationPath, $postgraduation);
				}else{
					$postgraduation = $request->prepostgrduation;
				}
				/**
					Other
				*/
				$other = "";
				$file 							= Input::file('other');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$other 						= $file->getClientOriginalName();
					$other 						= uniqid().'_'.$other;
					$file->move($destinationPath, $other);
				}else{
					$other = $request->preother;
				}
				if($matric == ""){
					$matric = " ";
				}
				if($plustwo == ""){
					$plustwo = " ";
				}
				if($diploma == ""){
					$diploma = "";
				}
				if($graduation == ""){
					$graduation = " ";
				}
				if($postgraduation == ""){
					$postgraduation = " ";
				}
				if($other == ""){
					$other = " ";
				}
				$Education = Education::where("uid",$request->uid)->first();
				if($Education){
					$Education 					= Education::where("uid",$request->uid)->first();
					$Education->matric 			= $matric;
					$Education->plustwo  		= $plustwo;
					$Education->diploma 		= $diploma;
					$Education->graduation 		= $graduation;
					$Education->postgraduation 	= $postgraduation;
					$Education->other 			= $other;
					$Education->save();
				}else{
					$Education 					= new Education;
					$Education->uid 			= $request->uid;
					$Education->matric 			= $matric;
					$Education->plustwo  		= $plustwo;
					$Education->diploma 		= $diploma;
					$Education->graduation 		= $graduation;
					$Education->postgraduation 	= $postgraduation;
					$Education->other 			= $other;
					$Education->save();
				}
				 
				if($Education->save())

				{

					 \Session::flash('success','Documents Successfully Uploaded.');


				}

				else

				{

					 \Session::flash('error','Error! Please Contact Administrator.'); 

				}
				return redirect::to('users/education/'.$request->uid);
			break;
			case 'previous-employement':
			
				if($user->user_type == "0" || in_array('newemployee',$this->data["permissions"])){
					
					$this->data["Previousemployement"] = Previousemployement::where('uid',$request->id)->first();
					
					$this->data['title'] 	= "Upload Educational Documents";
					$this->data['user'] 	= User::find($request->id);
				
					return view('admin.users.previous-employement',['data'=>$this->data]);
					
				}else{
					
					return "Unathorized";
					
				}
				break;
			case 'updatepreviousEmployement':
				$experience = "";
				$file 							= Input::file('experience');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$experience 						= $file->getClientOriginalName();
					$experience 						= uniqid().'_'.$experience;
					$file->move($destinationPath, $experience);
				}else{
					$experience = $request->experience;
				}
				/**
					Plus Two
				*/
				$salaryslip = "";
				$file 							= Input::file('salaryslip');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$salaryslip 						= $file->getClientOriginalName();
					$salaryslip 						= uniqid().'_'.$salaryslip;
					$file->move($destinationPath, $salaryslip);
				}else{
					$salaryslip = $request->salaryslip;
				}
				
				/**
					Plus Two
				*/
				$formsixteen = "";
				$file 							= Input::file('formsixteen');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$formsixteen 						= $file->getClientOriginalName();
					$formsixteen 						= uniqid().'_'.$formsixteen;
					$file->move($destinationPath, $formsixteen);
				}else{
					$formsixteen = $request->preformsixteen;
				}
				
				/**
					Form Eighteen
				*/
				$formeighteen = "";
				$file 							= Input::file('formeighteen');
				if($file){
					$destinationPath 				= base_path() .'/images/users/';
					$formeighteen 						= $file->getClientOriginalName();
					$formeighteen 						= uniqid().'_'.$formeighteen;
					$file->move($destinationPath, $formeighteen);
				}else{
					$formeighteen = $request->preformeighteen;
				}
				
				if($salaryslip == ""){
					$salaryslip = " ";
				}
				if($experience == ""){
					$experience = " ";
				}
				if($formsixteen == ""){
					$formsixteen = " ";
				}
				if($formeighteen == ""){
					$formeighteen = " ";
				}
				
				$Previousemployement = Previousemployement::where("uid",$request->uid)->first();
				if($Previousemployement){
					$Previousemployement 					= Previousemployement::where("uid",$request->uid)->first();
					$Previousemployement->company_name    = $request->company_name;
					$Previousemployement->company_website    = $request->company_website;
					$Previousemployement->employee_id    = $request->employee_id;
					$Previousemployement->period_from    = date("Y-m-d",strtotime($request->period_from));
					$Previousemployement->period_to    = date("Y-m-d",strtotime($request->period_to));
					$Previousemployement->formsixteen    = $formsixteen;
					$Previousemployement->formeighteen    = $formeighteen;
					$Previousemployement->experience 	= $experience;
					$Previousemployement->salaryslip    = $salaryslip;
					$Previousemployement->save();
				}else{
					$Previousemployement 				= new Previousemployement;
					$Previousemployement->uid 			= $request->uid;
					$Previousemployement->company_name    = $request->company_name;
					$Previousemployement->company_website    = $request->company_website;
					$Previousemployement->employee_id    = $$request->employee_id;
					$Previousemployement->period_from    = $$request->period_from;
					$Previousemployement->period_to    = $$request->period_to;
					$Previousemployement->formsixteen    = $formsixteen;
					$Previousemployement->formeighteen    = $formeighteen;
					$Previousemployement->experience 	= $experience;
					$Previousemployement->salaryslip    = $salaryslip;
					$Previousemployement->save();
				}
				 
				if($Previousemployement->save())

				{

					 \Session::flash('success','Documents Successfully Uploaded.');


				}

				else

				{

					 \Session::flash('error','Error! Please Contact Administrator.'); 

				}
				return redirect::to('users/previous-employement/'.$request->uid);
			break;	
			case 'resignation-request':
			
				if($user->user_type == "0"){
					
					$this->data["ResignationRequest"] = Resignationrequest::all();
					$this->data['user'] 	= User::find($request->id);
				
					return view('admin.users.resignation-request',['data'=>$this->data]);
					
				}else{
					
					return "Unathorized";
					
				}
			break;
			case 'resignation-formalities':
				if($user->user_type == "0"){
					
					$this->data["Resignationformality"] = Resignationformality::where("uid",$request->id)->first();
					if(empty($this->data["Resignationformality"])){
						$this->data["Resignationformality"]["uid"] = $request->id;
						$this->data["Resignationformality"]["r_accepted"] = "";
						$this->data["Resignationformality"]["r_date"] = "";
						$this->data["Resignationformality"]["notice_period_server"] = "";
						$this->data["Resignationformality"]["less_period"] = "";
						$this->data["Resignationformality"]["last_working_date"] = "";
						$this->data["Resignationformality"]["dues_pending"]  = "";
						$this->data["Resignationformality"]["dues_amount"]  = "";
						$this->data["Resignationformality"]["eligible"] = "";
						$this->data["Resignationformality"]["eligible_detail"]  = "";
						$this->data["Resignationformality"]["issue"] = "";
						$this->data["Resignationformality"]["exit_formalities"] = "";
						$this->data["Resignationformality"]["exit_formalities_detail"] = "";
						$this->data["Resignationformality"]["remark_behaviour"] = "";
						$this->data["Resignationformality"]["other_comment"]  = "";
					}
					$this->data["Resignationformality"] = (object)$this->data["Resignationformality"];
					
				
					return view('admin.users.resignation-formalities',['data'=>$this->data]);
					
				}else{
					
					return "Unathorized";
					
				}
			break;
			case 'postResignation':
			
			if($user->user_type == "0"){
				
				if($request->resignation_accepted == ""){
					$request->resignation_accepted = " ";
				}
				if($request->r_date == ""){
					$request->r_date = " ";
				}
				if($request->notice_period_server == ""){
					$request->notice_period_server = " ";
				}
				if($request->less_period == ""){
					$request->less_period = " ";
				}
				if($request->last_working_date == ""){
					$request->last_working_date = " ";
				}
				if($request->dues_pending == ""){
					$request->dues_pending = " ";
				}
				if($request->dues_amount == ""){
					$request->dues_amount = " ";
				}
				if($request->eligible == ""){
					$request->eligible = " ";
				}
				if($request->eligible_detail == ""){
					$request->eligible_detail = " ";
				}
				if($request->issue == ""){
					$request->issue = " ";
				}
				if($request->exit_formalities == ""){
					$request->exit_formalities = " ";
				}
				if($request->exit_formalities_detail == ""){
					$request->exit_formalities_detail = " ";
				}
				if($request->remark_behaviour == ""){
					$request->remark_behaviour = " ";
				}
				if($request->other_comment == ""){
					$request->other_comment = " ";
				}
				$resignationformality = Resignationformality::where("uid",$request->uid)->first();
				if($resignationformality){
					$resignationformality->r_accepted 				= $request->resignation_accepted;
					$resignationformality->uid 				= $request->uid;
					$resignationformality->r_date 				= date("y-m-d",strtotime($request->r_date));
					$resignationformality->notice_period_server 							= $request->notice_period_server;
					$resignationformality->less_period 							= $request->less_period;
					$resignationformality->last_working_date 				= date("y-m-d",strtotime($request->last_working_date));
					$resignationformality->dues_pending 				= $request->dues_pending;
					$resignationformality->dues_amount 				= $request->dues_amount;
					$resignationformality->eligible 				= $request->eligible;
					$resignationformality->eligible_detail 				= $request->eligible_detail;
					$resignationformality->issue 				= $request->issue;
					$resignationformality->exit_formalities				= $request->exit_formalities;
					$resignationformality->exit_formalities_detail 				= $request->exit_formalities_detail;
					$resignationformality->remark_behaviour 				= $request->remark_behaviour;
					$resignationformality->other_comment 				= $request->other_comment;
				}else{
					$resignationformality 						= new Resignationformality;
					$resignationformality->uid 				= $request->uid;
					$resignationformality->r_accepted 				= $request->resignation_accepted;
					$resignationformality->uid 				= $request->uid;
					$resignationformality->r_date 				= date("y-m-d",strtotime($request->r_date));
					$resignationformality->notice_period_server 							= $request->notice_period_server;
					$resignationformality->less_period 							= $request->less_period;
					$resignationformality->last_working_date 				= date("y-m-d",strtotime($request->last_working_date));
					$resignationformality->dues_pending 				= $request->dues_pending;
					$resignationformality->dues_amount 				= $request->dues_amount;
					$resignationformality->eligible 				= $request->eligible;
					$resignationformality->eligible_detail 				= $request->eligible_detail;
					$resignationformality->issue 				= $request->issue;
					$resignationformality->exit_formalities				= $request->exit_formalities;
					$resignationformality->exit_formalities_detail 				= $request->exit_formalities_detail;
					$resignationformality->remark_behaviour 				= $request->remark_behaviour;
					$resignationformality->other_comment 				= $request->other_comment;
				}
	
				if($resignationformality->save())
				{
					 \Session::flash('success','Note Successfully Added.');
				}
				else
				{
					 \Session::flash('error','Error! Please Contact Administrator.'); 
				}
				return redirect::to('users/resignation-request');
			}else{
				return "Unathorized";
			}
				
				
				break;
			case 'deleteRegis':
			
				if($user->user_type == "0"){
					$prev_select_item_id = $request->prev_select_item_id;
				
					if($prev_select_item_id != ""){
						$prev_select_item_id = explode("_",$request->prev_select_item_id);
					
						foreach($prev_select_item_id as $id){
							
							Resignationrequest::where('uid',$id)->delete();
							resignationformality::where('uid',$id)->delete();
						}
					}
			
					return redirect::to('users/resignation-request');

				}else{
					return "Unathorized";
				}
				
				break;
			case 'generate-resignation-request':
				$this->data['user'] 	= Auth::user();
				return view('employee_self_services.generate-resignation',['data'=>$this->data]);
		
			break;	
			case 'postGeneraterequest':
				$this->data['user'] 		= Auth::user();
				$Resignationrequest 		= new Resignationrequest;
				$Resignationrequest->uid =  $this->data['user']->id;
				$Resignationrequest->r_date =  date("y-m-d",strtotime($request->r_date));
				$Resignationrequest->reason =  $request->reason;
				$Resignationrequest->save();
				\Session::flash("success","Your Request Has been successfully Generated");
				return redirect::to('users/generate-resignation-request');
			break;
			case 'postpreviousAdd':
				/* echo "<pre>";print_r($request->input());
				die; */
				if($user->user_type == "0" || in_array('newemployee',$this->data["permissions"])){
					$validator = $this->postpreEmpvalidator($request->all());
					$options = ['cost' => '12'];
					if($validator->fails()){
						return redirect::to('users/add-previous')->withErrors($validator);
					}else{
						$filename = "";
						$file 							= Input::file('emp_photo');
						if($file){
							$destinationPath 				= base_path() .'/images/users/';
							$filename 						= $file->getClientOriginalName();
							$filename 						= uniqid().'_'.$filename;
							$file->move($destinationPath, $filename);
						}else{
							$filename = " ";
						}
						
						$emp_docs = "";
						$file 							= Input::file('emp_docs');
						
						if($file){
							$destinationPath 								= base_path() .'/images/users/';
							$emp_docs 						= $file->getClientOriginalName();
							$emp_docs 						= uniqid().'_'.$emp_docs;
							$file->move($destinationPath, $emp_docs);
						}else{
							$emp_docs = " ";
						}
						
						$unQid 						= date("ym",strtotime($request->joining));
						$lastUser 					= User::orderby('created_at', 'desc')->first();
						if($user->emp_stat == "1"){
							$unicId = $lastUser->uuid+1;
						}else{
							$Uid 	= DB::table("emp_uid")->first();
					
							if($request->uuid == $Uid->uid+1){
								$unicId = $Uid->uid+1;
								DB::table('emp_uid')
								->update(['uid' => $unicId]);
							}else{
								$unicId = $request->uuid;
							}
						}
						
						if($request->house_no == ""){
							$request->house_no = " ";
						}
						if($request->address_street_no1 == ""){
							$request->address_street_no1 = " ";
						}
						if($request->country == ""){
							$request->country = " ";
						}
						if($request->postal_code == ""){
							$request->postal_code = " ";
						}
						if($request->e_address == ""){
							$request->e_address = " ";
						}
						if($request->e_contact1 == ""){
							$request->e_contact1 = " ";
						}
						if($request->e_contact2 == ""){
							$request->e_contact2 = " ";
						}	
						if($request->notice_period == ""){
							$request->notice_period = " ";
						}
						if($request->notice_period == ""){
							$request->notice_period = " ";
						}
						
						
						
						
						$dt = date('y-m-d');
						$options  					= ['cost' => '12'];
						 
						$user 						= new User;
						$user->name 				= $request->e_name;
						$user->unQid 				= $unQid;
						$user->uuid         		= $unicId;
						$user->f_name 				= $request->e_name;
						$user->l_name 				= $request->e_surname;
						$user->father_name 			= $request->father_name;
						$user->password 		   	= " ";
						$user->show_pass 		   	= " ";
						$user->email 				= $request->e_email;
						$user->image 				= $filename;
						$user->phone_number 		= $request->e_contact1;
						$user->address 				= $request->e_address;
						$user->dob 					= date('Y-m-d',strtotime($request->e_dob));		
						$user->age 					= $request->age;		
						$user->houseno 				= $request->house_no;
						$user->address_street_no1 	= $request->address_street_no1;
						$user->country 				= $request->country;
						$user->postal_code 			= $request->postal_code;
						$user->company 				= $request->company;
						$user->e_contact1 			= $request->e_contact2;
						$user->emp_type 			= " ";
						$user->working_hours 		= " ";
						$user->working_weeks 		= " ";
						$user->notice_period 		= $request->notice_period;
						$user->for_days 			= $request->for_days;
						$user->emp_docs 			= $emp_docs;
						$user->prob_start_date 		= $dt;
						$user->prob_end_date 		 = $dt;
						$user->doo 					= $dt;		
						$user->doj 					= $dt;
						$user->doa 					= $dt;	
						$user->e_department 		= $request->e_department;
						$user->salary 				= $request->e_salary;
						$user->sex 					= $request->sex;
						$user->religion 			= $request->religion;
						$user->jobtitle 			= $request->jobtitle;
						$user->qualification 		= $request->qualification;	
						$user->bank_author 			= " ";	
						$user->branch 				= " ";
						$user->city 				= " ";
						$user->acc_no 				= " ";
						$user->ifsccode 			= " ";
						$user->remark 				= " ";
						$user->user_type 			= '3';
						$user->emp_stat				= $request->emp_stat;
						$user->bank_statement		= " ";
						$user->account_statement	= " ";
						$user->cancel_check			= " ";
						if($user->save())
						{
							$company = Company::find($request->company);
							$emails = json_decode($company->email);
							$emails = implode(",",$emails);
							//$emails = "banish.mst@gmail.com";
							$subject = 'New Employee Added into '.$company->name;
							  $date =date('Ymd');
							  $date =  date('D M,Y',strtotime($date));
							  $message = '<html >
												  <head>
												  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
													  <title>Password Changed</title>
													  <style>
													  .wrapper{
														float:none;
														width:500px;
														margin:0 auto;
													  }
													   .wrapper h2{
														float:left;
														width:100%;
														text-align:center;
													  }
													   .wrapper h3{
														float:left;
														width:100%;
														text-align:center;
													  }
													  .wrapper h4{
														float:left;
														width:100%;
														text-align:center;
													  }
													   .wrapper span{
														float:left;
														width:100%;
														text-align:center;
														font-size:22px;
													  }
													  .HCL{
														float:left;
														width:100%;
														border:1px solid #DEE3E9;
													  }
													  .HCL h4 b{
														color:red;
													  }
													   .HCL p{
														float:left;
														width:100%;
														text-align:center;
													  }
													  </style>
												</head>
												<body>
												<div class="wrapper"> 
													<h2>Howdy '.Auth::user()->name.'</h2>
													<h3>New Employee Added into the Employee Portal</h3>
													<span>On '.$date.'</span>
													<div class="HCL">
														<h4>Employee Name is :- <b>'.$user->name.'</b></h4>
														<p>You can view This Employee Details on Admin Portal.</p>
													</div>
												</div>
												</body>
												</html>';
							  $headers = 'From: info@mindxpert.com' . "\r\n" .
								'Reply-To: info@mindxpert.com' . "\r\n" .
								'X-Mailer: PHP/' . phpversion();
							  $headers .= "MIME-Version: 1.0\r\n";
							  $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
							  mail($emails, $subject, $message, $headers);
							 \Session::flash('success','Employee Successfully Added.');
						}
						else
						{
							 \Session::flash('error','Error! Please Contact Administrator.'); 
						}
					
						return redirect::to('users/fullandfinal');
						
					}
				}else{
					return "Unathorized";
				}
				
				break;
			case 'postpreUpdate':
				if($user->user_type == "0" ||  in_array('edit_employee',$this->data["permissions"])){
					$filename = "";
					$file 							= Input::file('emp_photo');
					if($file){
						$destinationPath 				= base_path() .'/images/users/';
						$filename 						= $file->getClientOriginalName();
						$filename 						= uniqid().'_'.$filename;
						$file->move($destinationPath, $filename);
					}else{
						$filename = $request->preimage;
					}
					
					$files 							= Input::file('emp_docs');
					if($files){
						$emp_docsarray = array();
						foreach($files as $file){
							$destinationPath 								= base_path() .'/images/users/';
							$emp_docs 						= $file->getClientOriginalName();
							$emp_docs 						= uniqid().'_'.$emp_docs;
							$file->move($destinationPath, $emp_docs);
							array_push($emp_docsarray,$emp_docs);
							if($request->preemp_docs != ""){
								$pre_docsarray = explode(",",$request->preemp_docs);
								$emp_docsarray = array_merge($pre_docsarray,$emp_docsarray);
							}
								$Nemp_docsarray = implode(",",$emp_docsarray);
						}
					}else{
						$Nemp_docsarray = $request->preemp_docs;
					}
					
					/* echo $emp_docsarray;
					die; */
					if($request->house_no == ""){
							$request->house_no = " ";
						}
					if($request->address_street_no1 == ""){
						$request->address_street_no1 = " ";
					}
					if($request->country == ""){
						$request->country = " ";
					}
					if($request->postal_code == ""){
						$request->postal_code = " ";
					}
					if($request->e_address == ""){
						$request->e_address = " ";
					}
					if($request->e_contact1 == ""){
						$request->e_contact1 = " ";
					}
					if($request->e_contact2 == ""){
						$request->e_contact2 = " ";
					}	
					if($request->notice_period == ""){
						$request->notice_period = " ";
					}
					if($request->notice_period == ""){
						$request->notice_period = " ";
					}
					if($Nemp_docsarray == ""){
						$Nemp_docsarray = " ";
					}
					if($filename == ""){
						$filename = " ";
					}
					
					$dt = date('y-m-d');
					
					
					$options 					= ['cost' => '12'];
					$user 						= User::find($request->pempid);
					$lastUser 					= User::orderby('created_at', 'desc')->first(); 	
						$user->name 				= $request->e_name;
						$user->f_name 				= $request->e_name;
						$user->l_name 				= $request->e_surname;
						$user->father_name 			= $request->father_name;
						$user->password 		   	= " ";
						$user->show_pass 		   	= " ";
						$user->email 				= $request->e_email;
						$user->image 				= $filename;
						$user->phone_number 		= $request->e_contact1;
						$user->address 				= $request->e_address;
						$user->dob 					= date('Y-m-d',strtotime($request->e_dob));		
						$user->age 					= date('Y-m-d',strtotime($request->age));		
						$user->houseno 				= $request->house_no;
						$user->address_street_no1 	= $request->address_street_no1;
						$user->country 				= $request->country;
						$user->postal_code 			= $request->postal_code;
						$user->company 				= $request->company;
						$user->e_contact1 			= $request->e_contact2;
						$user->emp_type 			= " ";
						$user->working_hours 		= " ";
						$user->working_weeks 		= " ";
						$user->notice_period 		= $request->notice_period;
						$user->for_days 			= $request->for_days;
						$user->emp_docs 			= $Nemp_docsarray;
						$user->prob_start_date 		= $dt;
						$user->prob_end_date 		 = $dt;
						$user->doo 					= $dt;		
						$user->doj 					= $dt;
						$user->doa 					= $dt;	
						$user->e_department 		= $request->e_department;
						$user->salary 				= $request->e_salary;
						$user->sex 					= $request->sex;
						$user->religion 			= $request->religion;
						$user->jobtitle 			= $request->jobtitle;
						$user->qualification 		= $request->qualification;	
						$user->bank_author 			= " ";	
						$user->branch 				= " ";
						$user->city 				= " ";
						$user->acc_no 				= " ";
						$user->ifsccode 			= " ";
						$user->remark 				= " ";
						$user->user_type 			= '3';
						$user->emp_stat				= $request->emp_stat;
						$user->bank_statement		= " ";
						$user->account_statement	= " ";
						$user->cancel_check			= " ";
					
					
					if($user->save())

					{

						 \Session::flash('success','Employee Successfully Updated.');


					}

					else

					{

						 \Session::flash('error','Error! Please Contact Administrator.'); 

					}

					return redirect::to('users/fullandfinal');
				}else{
					return "Unathorized";
				}
			break;		
			default:
			if($user->user_type == "0" || in_array('view_employees',$this->data["permissions"])){
				return view('admin.users.users',['data'=>$this->data]);	
			}else{
				return "Unathorized";
			}
			break;		
		}
	}
	public static function getUser($id){
		$user = User::find($id);
		return $user;
	}
	
	public static function checkTemplate($uid){
		$tempalte = DB::table('salary_template')->where('uid', $uid)->first();
		if($tempalte){
			$msg = 1;
		}else{
			$msg = 0;
		}
		return $msg;
	}
	
	protected function validator(array $data){
		return Validator::make($data, [
		'user' => 'required|max:255',
		'credential_type' => 'required|max:255',
		'username'    => 'required|email',
		'password' => 'required|max:255'
		]);	
	}
	protected function reportingvalidator(array $data){
		return Validator::make($data, [
			'user' 					=> 'required|max:255',
			'reporting_manager' 	=> 'required|max:255',
			'hr_manager'   			=> 'required|max:255',
			'finance_manager' 		=> 'required|max:255',
			'admin_manager' 		=> 'required|max:255'
		]);	
	}
	
	protected function postEmpvalidator(array $data){
		return Validator::make($data, [
		'e_name' => 'required|max:255',
		'offer_date' => 'required|max:255',
		'e_surname'    => 'required|max:255',
		'company'    => 'required|max:255',
		'sex'   	 => 'required|max:255',
		'religion'   	 => 'required|max:255',
		'e_dob' => 'required|max:255',
		'e_department' => 'required|max:255',
		'e_salary' => 'required|max:255',
		'e_email' => 'required|max:255',
		'e_pass' => 'required|max:255',
		'age' => 'required|max:255',
		'emp_type' => 'required|max:255',
		'working_hours' => 'required|max:255',
		'jobtitle' => 'required|max:255',
		'qualification' => 'required|max:255',
		'name' => 'required|max:255',
		'working_hours' => 'required|max:255',
		'acc_no' => 'required|max:255',
		'branch' => 'required|max:255',
		'ifsccode' => 'required|max:255',
		'city' => 'required|max:255'
		
		]);	
	}
	
	protected function postpreEmpvalidator(array $data){
		return Validator::make($data, [
		'e_name' => 'required|max:255',
		'company'    => 'required|max:255',
		'sex'   	 => 'required|max:255',
		'religion'   	 => 'required|max:255',
		'e_dob' => 'required|max:255',
		'e_department' => 'required|max:255',
		'e_salary' => 'required|max:255',
		'e_email' => 'required|max:255',
		'age' => 'required|max:255',
		'jobtitle' => 'required|max:255',
		'qualification' => 'required|max:255',
		]);	
	}
	
}
