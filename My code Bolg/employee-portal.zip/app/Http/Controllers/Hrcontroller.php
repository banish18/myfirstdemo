<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HrController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
		$this->data['title'] = "Home";
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       // return view('home');
    }
	/**
     * Handle actions and their view.
     *
     * @return \Illuminate\Http\Response
     */
	 public function action(Request $request,$action=null,$id=null){
		 switch($action){
			 case 'hr-management':
				return view('hr.hr',['data'=>$this->data]);	
			 break;
			 default:
				return view('hr.hr',['data'=>$this->data]);
			break;	
		 }
	 }
	
}
