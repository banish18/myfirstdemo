<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Previousemployement extends Authenticatable
{
	  protected $table = 'previous-employement';
}
