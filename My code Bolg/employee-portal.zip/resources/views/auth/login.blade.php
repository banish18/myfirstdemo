@extends('layouts.admin-app')
	<!-- Login Screen -->
	<div class="login-wrapper">
		<a href="/">
				<img
			src="{{ asset('images/company-2.png') }}" width="150px" />
			 </a>
            <h2>Login</h2>
					 <form class="form-horizontal login-form" role="form" method="POST" action="{{ route('login') }}">
	    {{ csrf_field() }}
			<div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
				<div class="input-group">
					<span class="input-group-addon"><i class="lnr lnr-envelope"></i></span><input
						id="email" type="text" class="form-control" name="email" value="{{ old('email') }}" required>
				</div>
				@if ($errors->has('email'))
					<span class="help-block">
						<strong>{{ $errors->first('email') }}</strong>
					</span>
				@endif
			</div>
			<div class="form-group">
				<div class="input-group">
					<span class="input-group-addon"><i class="lnr lnr-lock"></i></span><input
						id="password" type="password" class="form-control" name="password" required>
				</div>
				 @if ($errors->has('password'))
					<span class="help-block">
						<strong>{{ $errors->first('password') }}</strong>
					</span>
				  @endif
			</div>

			<div class="text-left ">
				<a class="pull-right" href="{{ route('password.request') }}">Forgot password?</a>
			<div class="text-left">
          <label class="checkbox">
          <input type="checkbox" name="cookie_set" {{ old('remember') ? 'checked' : '' }} value="true"><span>Keep me logged in</span></label>
        </div>
			</div>

			<input class="btn btn-lg btn-primary btn-block" type="submit"
				value="Log in" name="submit_login">

		</form>


	</div>
