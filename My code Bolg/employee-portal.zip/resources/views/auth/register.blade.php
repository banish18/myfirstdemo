<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Employee Portal') }}</title>

 
	 <!-- CORE CSS-->    
    <link href="{{ asset('css/materialize.min.css') }}" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="{{ asset('css/style.min.css') }}" type="text/css" rel="stylesheet" media="screen,projection">
    <!-- CSS style Horizontal Nav-->    
    
    <!-- Custome CSS-->    
    <link href="{{ asset('css/custom/custom.min.css') }}" type="text/css" rel="stylesheet" media="screen,projection">
    


    <!-- INCLUDED PLUGIN CSS ON THIS PAGE -->
    <link href="{{ asset('css/layouts/page-center.css') }}" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="{{ asset('js/plugins/prism/prism.css') }}" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="{{ asset('js/plugins/perfect-scrollbar/perfect-scrollbar.css') }}" type="text/css" rel="stylesheet" media="screen,projection">

    <!-- Scripts -->
    <script>
        window.Laravel = {!! json_encode([
            'csrfToken' => csrf_token(),
        ]) !!};
    </script>
</head>
<body class="cyan">
  <!-- Start Page Loading -->
  <div id="loader-wrapper">
      <div id="loader"></div>        
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
  </div>
  <!-- End Page Loading -->



<div id="login-page" class="row">
    <div class="col s12 z-depth-4 card-panel">
      <form class="form-horizontal" role="form" method="POST" action="{{ route('register') }}">
	   {{ csrf_field() }}
        <div class="row">
          <div class="input-field col s12 center {{ $errors->has('name') ? ' has-error' : '' }}"">
            <h4>Register</h4>
            <p class="center">Join to our community now !</p>
          </div>
        </div>
        <div class="row margin">
          <div class="input-field col s12">
            <i class="mdi-social-person-outline prefix"></i>
            <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}" required>
            <label for="username" class="center-align">Username</label>
			@if ($errors->has('name'))
				<span class="help-block">
					<strong>{{ $errors->first('name') }}</strong>
				</span>
			@endif
          </div>
        </div>
        <div class="row margin">
          <div class="input-field col s12 {{ $errors->has('email') ? ' has-error' : '' }}"">
            <i class="mdi-communication-email prefix"></i>
            <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required>
            <label for="email" class="center-align">Email</label>
          </div>
		  @if ($errors->has('email'))
				<span class="help-block">
					<strong>{{ $errors->first('email') }}</strong>
				</span>
			@endif
        </div>
        <div class="row margin">
          <div class="input-field col s12 {{ $errors->has('password') ? ' has-error' : '' }}"">
            <i class="mdi-action-lock-outline prefix"></i>
            <input id="password" type="password" class="form-control" name="password" required>
            <label for="password">Password</label>
          </div>
		   @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
        </div>
        <div class="row margin">
          <div class="input-field col s12">
            <i class="mdi-action-lock-outline prefix"></i>
            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
            <label for="password-again">Password again</label>
          </div>
		  
        </div>
        <div class="row">
          <div class="input-field col s12">
			 <button type="submit" class="btn waves-effect waves-light col s12">
                                    Register
                                </button>
          </div>
          <div class="input-field col s12">
            <p class="margin center medium-small sign-up">Already have an account? <a href="login">Login</a></p>
          </div>
        </div>
      </form>
    </div>
  </div>




    <!-- ================================================
    Scripts
    ================================================ -->
    
    <!-- jQuery Library -->
    <script type="text/javascript" src="{{ asset('js/plugins/jquery-1.11.2.min.js') }}"></script>
    <!--materialize js-->
    <script type="text/javascript" src="{{ asset('js/materialize.min.js') }}"></script>
    

    <!-- sparkline -->
    <script type="text/javascript" src="{{ asset('js/plugins/prism/prism.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/plugins/perfect-scrollbar/perfect-scrollbar.min.js') }}"></script>
    
  

    <!--jvectormap-->
    <script type="text/javascript" src="{{ asset('js/plugins.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/custom-script.js') }}"></script>
    
</body>
</html>

