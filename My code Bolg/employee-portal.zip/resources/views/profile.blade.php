@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
		 <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1>Employee Details</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="document-breadcrumb">
                <div class="container">
                    <ul class="breadcrumb">
                        <li><a href="{{ route('home') }}">Home</a></li>
                        <li>Employee Details</li>
                       
                    </ul>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="container">
    <div class="resume">
    <div class="resume-main">
        <div class="resume-main-image">
            <img src="assets/img/tmp/resume.jpg" alt="">

            <a href="#" class="resume-main-image-label">
                <img src="assets/img/tmp/instagram.png" alt="">
            </a>
        </div><!-- /.resume-main-image -->

        <div class="resume-main-content">
            <h2>{{ $data["user"]->f_name.' '.$data["user"]->l_name }}
                <span class="resume-main-verified"><i class="fa fa-check"></i></span>

                <span class="resume-main-rating">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <span class="resume-main-rating-count">/ 32</span>
                </span><!-- /.resume-main-rating -->
            </h2>

            <h3>{{ $data["user"]->designation }}</h3>

            <p class="resume-main-contacts">
               {{ $data["user"]->address }}<br>
                Email: <a href="mailto:hello@example.com">{{ $data["user"]->email }}</a>
            </p><!-- /.resume-main-contact -->

            <div class="resume-main-actions">
                <a href="#" class="btn btn-secondary"><i class="fa fa-download"></i> Download</a>
                <a href="#" class="btn btn-default">Contact</a>
                <a href="#" class="btn btn-default">Save</a>
            </div><!-- /.resume-main-actions -->
        </div><!-- /.resume-main-content -->
    </div><!-- /.resume-main -->


<div class="resume-chapter">
        <div class="resume-chapter-inner">
            <div class="resume-chapter-content">
                <h2 class="mb40">Basic Details</h2>

                <dl>
                    <dt>Date of birth:</dt>

                    <dd>
                        <h3>{{ $data["user"]->dob }}</h3>
                    </dd>

                    <dt>Blood Group:</dt>

                    <dd>
                        <h3>{{ $data["user"]->blood_group }}</h3>
                    </dd>

                    <dt>Gender:</dt>

                    <dd>
                        <h3>{{ $data["user"]->sex }}</h3>
                    </dd>

                    <dt>Personal Mobile:</dt>

                    <dd>
                        <h3>{{ $data["user"]->phone_number }}	</h3>
                    </dd>
                </dl>
            </div><!-- /.resume-chapter-content -->
        </div><!-- /.resume-chapter-inner -->
    </div><!-- /.resume-chapter -->
	
	@if(!$data["addressDetail"]->isEmpty())
		@foreach($data["addressDetail"] as $address)
			<div class="resume-chapter">
				<div class="resume-chapter-inner">
					<div class="resume-chapter-content">
						<h2 class="mb40">{{ $address->address_type }}</h2>

						<dl>
							<dt>Address1</dt>

							<dd>
								<h3>{{ $address->address_line1 }}</h3>
							</dd>

							<dt>Address2</dt>

							<dd>
								<h3>{{ $address->address_line2 }}</h3>
							</dd>

							
						</dl>
					</div><!-- /.resume-chapter-content -->
				</div><!-- /.resume-chapter-inner -->
			</div><!-- /.resume-chapter -->
		@endforeach
	@endif	
    
    
    
    


<div class="resume-chapter">
        <div class="resume-chapter-inner">
            <div class="resume-chapter-content">
                <h2 class="mb40">Marriage Details</h2>

                <dl>
                    <dt>Marital Status:</dt>

                    <dd>
                        <h3>{{ $data["emp_profile"]->marital_status }}</h3>
                    </dd>

                    <dt>Date of marriage:</dt>

                    <dd>
                        <h3>{{ $data["emp_profile"]->dom }}</h3>
                    </dd>

                   
                </dl>
            </div><!-- /.resume-chapter-content -->
        </div><!-- /.resume-chapter-inner -->
    </div><!-- /.resume-chapter -->

<div class="resume-chapter">
        <div class="resume-chapter-inner">
            <div class="resume-chapter-content">
                <h2 class="mb40">Nationality Details</h2>

                <dl>
                    <dt>Nationality</dt>

                    <dd>
                        <h3>{{ $data["user"]->nationality }}</h3>
                    </dd>

                </dl>
            </div><!-- /.resume-chapter-content -->
        </div><!-- /.resume-chapter-inner -->
    </div><!-- /.resume-chapter -->




   

    <div class="resume-chapter">
        <div class="resume-chapter-inner">
            <div class="resume-chapter-content">
                <h2 class="mb40">Working History</h2>

                <dl>
                    <dt>Current</dt>

                    <dd>
                        <h3>Project Manager</h3>

                        <p>
                            Fusce eu est lectus. Integer commodo fringilla libero, non sodales ipsum consectetur sit amet. Aenean non ligula ac est dapibus feugiat. Fusce convallis ex nec tellus vulputate.
                        </p>
                    </dd>

                    <dt>2011 - 2014</dt>

                    <dd>
                        <h3>Senior UX/UI designer</h3>

                        <p>
                            Fusce eu est lectus. Integer commodo fringilla libero, non sodales ipsum consectetur sit amet. Aenean non ligula ac est dapibus feugiat. Fusce convallis ex nec tellus vulputate.
                        </p>
                    </dd>

                    <dt>2010 - 2011</dt>

                    <dd>
                        <h3>Junior UX/UI designer</h3>

                        <p>
                            Fusce eu est lectus. Integer commodo fringilla libero, non sodales ipsum consectetur sit amet. Aenean non ligula ac est dapibus feugiat. Fusce convallis ex nec tellus vulputate.
                        </p>
                    </dd>

                    <dt>2009 - 2010</dt>

                    <dd>
                        <h3>UX Tester</h3>

                        <p>
                            Fusce eu est lectus. Integer commodo fringilla libero, non sodales ipsum consectetur sit amet. Aenean non ligula ac est dapibus feugiat. Fusce convallis ex nec tellus vulputate.
                        </p>
                    </dd>
                </dl>
            </div><!-- /.resume-chapter-content -->
        </div><!-- /.resume-chapter-inner -->
    </div><!-- /.resume-chapter -->

    <div class="resume-chapter">
        <div class="resume-chapter-inner">
            <div class="resume-chapter-title">
                <h2>Experience</h2>
            </div><!-- /.resume-chapter-title -->

            <div class="resume-chapter-content">
                <div class="row">
                    <div class="col-sm-4">
                        <h4>Frameworks</h4>

                        <ul>
                            <li>Laravel, <span>4 years</span></li>
                            <li>Zend, <span>3 years</span></li>
                            <li>CakePHP, <span>1 year</span></li>
                            <li>Yii, <span>1 year</span></li>
                        </ul>
                    </div><!-- /.col-* -->

                    <div class="col-sm-4">
                        <h4>Operating Systems</h4>

                        <ul>
                            <li>Debian, <span>7 years</span></li>
                            <li>FreeBSD, <span>5 years</span></li>
                            <li>Ubuntu, <span>1 year</span></li>
                            <li>Gentoo, <span>1 year</span></li>
                        </ul>
                    </div><!-- /.col-* -->

                    <div class="col-sm-4">
                        <h4>Languages</h4>

                        <ul>
                            <li>English, <span>native</span></li>
                            <li>German, <span>intermediate</span></li>
                            <li>French, <span>beginner</span></li>
                            <li>Spanish, <span>beginner</span></li>
                        </ul>
                    </div><!-- /.col-* -->
                </div><!-- /.row -->
            </div><!-- /.resume-chapter-content -->
        </div><!-- /.resume-chapter-inner -->
    </div><!-- /.resume-chapter -->
</div><!-- /.resume -->

</div><!-- /.container -->
        </div><!-- /.main -->
    </div><!-- /.main-wrapper -->
    </div>
</div>
@include('templates/footer')
@endsection
