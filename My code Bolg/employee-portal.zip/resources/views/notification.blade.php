@extends('layouts.app')
@section('content')

<div class="main-wrapper">
	<div class="main">
		<div class="document-title">
			<div class="container">
				<h1>Notification</h1>
			</div><!-- /.container -->
		</div><!-- /.document-title -->
		<div class="document-breadcrumb">
			<div class="container">
				<ul class="breadcrumb">
					<li><a href="{{ route('home') }}">Home</a></li>
					<li>Notification</li>
				</ul>
			</div><!-- /.container -->
		</div><!-- /.document-title -->
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<ul style="list-style:none;">
				@if($data["notifications"])
					@foreach($data["notifications"] as $notification)
						<li><h3 class="page-header">{{ $notification->subject }}</h3>
						<p>
							{{ $notification->message }}
						</p></li>
					@endforeach
				@else
					<li>You don't have notifications yet !</li>
				@endif	
				</ul>
			</div><!-- /.col-* -->
		</div><!-- /.row -->
	</div><!-- /.container -->
	</div><!-- /.main -->
</div><!-- /.main-wrapper -->

@include('templates/footer')
@endsection
	
	