@extends('layouts.admin-pagesapp')
@section('content')
<div class="container-fluid main-content">
<div class="page-title">
<div class="row">
<div class="col-md-12">
<h1>Update Credential</h1></div></div>
</div>
<div class="row">
<div class="col-md-2">
<ul class="list-group">
<li class="list-group-item active" >
<a href="{{ route('users',array('action' => 'employee-credential')) }}">
<p>
<img src="{{ asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg') }}" width="15">
&nbsp;Credentials
</p></a>
</li>
<li class="list-group-item">
           <a  href="{{ route('users',array('action' => 'add-credential')) }}">
           <p>
           <img src="{{ asset('admin-asset/images/plus-sign-in-circle.svg') }}" width="15">
           &nbsp;Add
           </p></a>
           </li>        
</ul>
</div>

<div class="col-md-10">
<div class="widget-container fluid-height clearfix">
<div class="widget-content padded">
<form method="post" class="form-horizontal" action="{{ route('users',array('action' => 'postupdateCredential'))}}" enctype="multipart/form-data">

 {{ csrf_field() }}

<div class="row">
<div class="col-md-12">
<div class="col-md-9">
<div class="heading"><h2>Employee Credential Details</h2></div><br>
<div class="form-group">
            <label class="control-label col-md-3">Select Employee</label>
            <div class="col-md-7">
			{{ csrf_field() }}
               <select data-placeholder="Select Employee" style="width:350px;" class="chosen-select form-control" tabindex="7" name="user" required> 
				<option value="">Please Select User To Add Credential</option>
				 @if($data["users"])
					 @foreach($data["users"] as $user)
						<?php 
							if($data['credential']->uid == $user->id){
								$selected = "selected";
							}else{
								$selected = "";
							}
						?>
						<option {{ $selected}} value="{{ $user->id }}">{{ $user->name.'('.$user->uuid.')' }}</option>
					 @endforeach
				@endif	 
			  </select>
            </div>
			<span style="color:#d43f3a">
mandatory
</span>
          </div>
<div class="form-group">
<label class="control-label col-md-3">Credential Type</label>
<div class="col-md-7">
<input class="form-control" name="credential_type" type="text" value="{{ $data['credential']->credential_type }}" required>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="form-group">
<label class="control-label col-md-3">Username/Email</label>
<div class="col-md-7">
<input class="form-control" name="username" type="text" value="{{ $data['credential']->username }}" required>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>
<div class="form-group">
<label class="control-label col-md-3">Password</label>
<div class="col-md-7">
<input class="form-control" name="password" type="text" value="{{ base64_decode($data['credential']->password) }}" required>
</div>
<span style="color:#d43f3a">
mandatory
</span> </div>

<div class="form-group">
<div class="col-md-12">
<div class="col-md-6">
<input type="hidden" name="id" value="{{ $data['credential']->id }}" />
<button class="btn btn-lg btn-block btn-success" type="submit" name="submit_employee"> Submit</button>
</div>
<div class="col-md-6">
<button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
</div>
</div></div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>

@include('templates/admin-footer')
<script type="text/javascript">
    var config = {
      '.chosen-select'           : {},
      '.chosen-select-deselect'  : {allow_single_deselect:true},
      '.chosen-select-no-single' : {disable_search_threshold:10},
      '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chosen-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
  </script>
<!-- ----------------------END------------------------------------- -->
@endsection

