@extends('layouts.admin-pagesapp')
@section('content')
<div class="container-fluid main-content">
<div class="page-title">
        <h1>Edit Department</h1>
   </div>
 <div class="row">
 <div class="col-md-2"></div>
 <div class="col-md-8">
 <div class="widget-container fluid-height clearfix">
 <div class="widget-content padded">
 <form method="post" class="form-horizontal" action="{{ route('company',array('action' => 'postUpdate')) }}">
  {{ csrf_field() }}
 <div class="row">
 <div class="col-md-12">
 <div class="col-md-8">

 <div class="form-group">
            <label class="control-label col-md-4">Description, duties, responsibilities</label>
            <div class="col-md-8">
              <textarea class="form-control"  type="text" name="name" id="full-editor"></textarea>
			
            </div>
			
			<div id="editor">
					{{ $data['rules']->description_responsibilities }}
				</div>
			
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-md-4">Other benefits</label>
            <div class="col-md-8">
              <textarea class="form-control"  type="text" name="name">{{ $data['rules']->	others }}</textarea>
            </div>
          </div>
		  
		  <div class="form-group">
            <label class="control-label col-md-4">Personality requirements and skills</label>
            <div class="col-md-8">
              <textarea class="form-control"  type="text" name="name">{{ $data['rules']->skills }}</textarea>
            </div>
          </div>
</div></div>

    <div class="row">
     <div class="col-md-12">
   <div class="col-md-6">
   <input type="hidden" name="id" value="{{ $data['rules']->id }}">
    <button class="btn btn-lg btn-block btn-success" type="submit" name="submit_department"> Submit</button>
   </div>
  <div class="col-md-6">
  <button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
  </div></div></div>
 </form>
 </div>
 </div>
 </div>
 </div>
  <div class="col-md-2"></div>
 </div>
		
@include("templates/admin-footer")


<!-- ----------------------END------------------------------------- -->
@endsection