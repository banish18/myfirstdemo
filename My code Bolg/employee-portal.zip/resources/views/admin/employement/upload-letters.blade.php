@extends('layouts.admin-pagesapp')
@section('content')
<div class="container-fluid main-content">
<div class="page-title">
        <h1>Add Appointment Letter</h1>
   </div>
 <div class="row">
 <div class="col-md-2">
  	<ul class="list-group">
<li class="list-group-item active" >
<a href="{{ route('employement') }}">
<p>
<img src="{{ asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg') }}" width="15">
&nbsp;List Notes
</p></a>
</li>
<li class="list-group-item">
           <a  href="{{ route('employement',array('action' => 'add-appointment')) }}">
           <p>
           <img src="{{ asset('admin-asset/images/plus-sign-in-circle.svg') }}" width="15">
           &nbsp;Add new Employee Letters
           </p></a>
           </li> 
<li class="list-group-item">
           <a  href="{{ route('employement',array('action' => 'upload-letters')) }}">
           <p>
           <img src="{{ asset('admin-asset/images/plus-sign-in-circle.svg') }}" width="15">
           &nbsp;Upload Previous Employee Letters
           </p></a>
           </li> 		   
</ul>
        </div>
 <div class="col-md-10">
 <div class="widget-container fluid-height clearfix">
 <div class="widget-content padded">
 <form method="post" class="form-horizontal" action="{{ route('employement',array('action' => 'postpreAppointment')) }}" enctype="multipart/form-data">
  {{ csrf_field() }}
 <div class="row">
 <div class="col-md-12">
 <div class="col-md-8">

 <div class="form-group">
            <label class="control-label col-md-3">Employee</label>
            <div class="col-md-7">
              <select name="employee" class="form-control">
				<option value="0">Please Select</option>
				@if($data["users"])
					@foreach($data["users"] as $user)
						<option value="{{$user->id}}">{{$user->name}}</option>
					@endforeach
				@endif	
			  </select>
			 
            </div>
          </div>
		   <div class="form-group">
				<label class="control-label col-md-3">Letter Type</label>
				<div class="col-md-7" >
				<select name="letter_type" class="form-control">
					<option value="0">Please Select Letter Type</option>
					@if($data["Lettertypes"])
						@foreach($data["Lettertypes"] as $lettertypes)
							<option value="{{ $lettertypes->id }}">{{ $lettertypes->name }}</option>
						@endforeach
					@endif
				</select>
				</div>
		   </div>
		   <div class="form-group">
				<label class="control-label col-md-3">Upload Letter</label>
				<div class="col-md-7">
				<input type="file" name="letter"  class="form-control"/>
				</div>
		   </div>
</div></div>

    <div class="row">
     <div class="col-md-12">
   <div class="col-md-6">
    <button class="btn btn-lg btn-block btn-success" type="submit" name="submit_department"> Submit</button>
   </div>
  <div class="col-md-6">
  <button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
  </div></div></div>
 </form>
 </div>
 </div>
 </div>
 </div></div>


		
@include("templates/admin-footer")

</script>
<!-- ----------------------END------------------------------------- -->
@endsection