@extends('layouts.admin-pagesapp')
@section('content')
<div class="container-fluid main-content">
<div class="page-title">
        <h1>Edit Department</h1>
   </div>
 <div class="row">
 <div class="col-md-2">
  <ul class="list-group">
      <li class="list-group-item">
           <a  href="{{ route('company') }}">
           <p>
           <img src="{{ asset('admin-asset/images/dots-beginning-text-lines-interface-button-symbol.svg') }}" width="15">
           &nbsp;List
           </p></a>
           </li>   <li class="list-group-item active" >
           <a  href="{{ route('company',array('action' => 'add')) }}">
           <p>
           <img src="{{ asset('admin-asset/images/plus-sign-in-circle.svg') }}" width="15">
           &nbsp;Add
           </p></a>
           </li>
                       </ul>
        </div>
 <div class="col-md-10">
 <div class="widget-container fluid-height clearfix">
 <div class="widget-content padded">
 <form method="post" class="form-horizontal" action="{{ route('company',array('action' => 'postUpdate')) }}" enctype="multipart/form-data">
  {{ csrf_field() }}
 <div class="row">
 <div class="col-md-12">
 <div class="col-md-8">

 <div class="form-group">
            <label class="control-label col-md-4">Company Name</label>
            <div class="col-md-8">
              <input class="form-control"  type="text" name="name" value="{{ $data['company']->name }}">
            </div>
          </div>
		  <div class="form-group">
            <label class="control-label col-md-4">Company Logo</label>
            <div class="col-md-8">
				@if($data['company']->logo != "")
					<img src="{{ asset('images/users/company/'.$data['company']->logo) }}" alt="company logo" />
				@endif	
				
              <input class="form-control"  type="file" name="logo" value="">
            </div>
          </div>
		  <div class="form-group">
            <label class="control-label col-md-4">Company Email</label>
			 <div class="col-md-6">
			 <input class="form-control"  type="text" name="email[]" value="{{ json_decode($data['company']->email)[0] }}">
            </div>
			<div class="col-md-2"><input type="button" onclick="moreField(this)" value="+" class="btn btn-success" /></div>
			<div class="more">
               @if(is_array(json_decode($data['company']->email)))
				   <?php 
				$array = json_decode($data['company']->email);
			
						unset($array[0]);
					
					?>
				   @foreach($array as $email)
			   
			   <label class="control-label col-md-4"></label><div class="col-md-8"><input class="form-control"  type="text" name="email[]" value="{{$email }}" style="float: left;width: 74%;"><input type="button" onclick="removeField(this)" style="margin-left:21px;float:left;width:32px;" value="-" class="btn btn-success" /></div>
			       @endforeach
			   @endif
            </div>
			 
          </div>
</div></div>
<input type="hidden" name="plogo" value="{{ $data['company']->logo }}" />

    <div class="row">
     <div class="col-md-12">
   <div class="col-md-6">
   <input type="hidden" name="id" value="{{ $data['company']->id }}" />
    <button class="btn btn-lg btn-block btn-success" type="submit" name="submit_department"> Submit</button>
   </div>
  <div class="col-md-6">
  <button class="btn btn-lg btn-block btn-danger" type="reset"> Reset</button>
  </div></div></div>
 </form>
 </div>
 </div>
 </div>
 </div></div>


		
@include("templates/admin-footer")

<script>
function moreField(elm){
	$(".more").append('<label class="control-label col-md-4"></label><div class="col-md-8"><input class="form-control"  type="text" name="email[]" value="" style="float: left;width: 74%;"><input type="button" onclick="removeField(this)" style="margin-left:21px;float:left;width:32px;" value="-" class="btn btn-success" /></div>');
}
function removeField(elm){
	$(elm).parent().remove();
}
</script>
<!-- ----------------------END------------------------------------- -->
@endsection