@extends('layouts.app')

@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Track My Workflow </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Track My Workflow</li>
				</ul>
			</div>
		</div>
      <div class="container mb40">
        <div class="row">
		<div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/responsibilities/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
			  <div class="container">
	         <div class="row">
		      <div class="col-sm-12">
			    <div class="tab-content">
				  <div role="tabpanel" class="tab-pane active" id="personal">
					<div class="row">
						<div class="col-sm-12">
						 <h2>My Worklist</h2>
							<div id="noRecords" class="alert alert-info col-md-12 ng-scope" data-ng-if="myRequests.length==0">
							<strong>No Worklist present.</strong>
							</div>	
						</div><!-- /.form-group-->
					</div><!-- /.col-* -->
				</div><!-- /.row -->

                   
                  

				<div role="tabpanel" class="tab-pane" id="company">
						<div class="col-sm-12" style="border: 1px solid #ccc;">
							<table>
								<tbody>
									<tr>
									<th class="col-md-4" style="padding: 0px 10px 0px 10px;">Request Number</th>
									<th class="col-md-2" style="padding: 10px 17px 10px 8px;">Declaration Category</th>
									<th class="col-md-2" style="padding: 10px 10px 10px 6px;">Approved Amount</th>
									<th class="col-md-2" style="padding: 10px 30px 10px 2px;">Requested Amount</th>
									<th class="col-md-1" style="padding: 10px 24px 10px 0px;">Status</th>
									</tr>
								</tbody>
							</table>
						</div><!-- /.col-* -->
						
						
						<div class="col-md-12" style="border: 1px solid #ccc; margin-top: 15px;">
						<table class="col-md-12">
						<tbody>
						<tr>
						<td class="col-md-4" style="border-right: 1px solid #999;">
						<div id="requestNoDiv" class="col-md-12" style="margin-top: 10px; margin-bottom: 10px; padding:0;">
						<div class="col-md-12" style="padding-left: 0px; margin-bottom: 14px; padding:0;">
						<output class="col-md-4 requestNo " style="padding-left: 0px; cursor: pointer;">TM_1150930</output>
						<output class="col-md-4" role="Completed"  style="margin-top: 14px;">Completed</output>
						<output class="col-md-4" tooltip="Move to Current" style="padding: 0px; float: right; margin-top: 14px; cursor: pointer;"><i class="fa fa-hand-o-down" aria-hidden="true"></i>
</output>
						</div>
						<table class="col-md-12">
							<tbody>
							<tr style="font-size: 14px;">
							<th>Submission Date</th>
							<th>Approved Amount</th>
							<th>Requested Amount</th>
							</tr>
							<tr style="font-size: 12px;">
							<td>May-16-2013</td>
							<td>96000</td>
							<td>96000</td>
							</tr>
							</tbody>
						</table>
						</div>
						</td>
						<td class="col-md-7">
						<table id="detailsTable" style="width: 100%;">
						<tbody>
							<tr style="border-bottom: 1px #dadada solid; font-size: 12px; font-family: segoe ui; font-weight: 500;">
							<td class="col-md-4" style="padding-top: 16px; padding-bottom: 16px;">TRLP</td>
							<td class="col-md-3" style="padding-top: 16px; padding-bottom: 16px;">96000</td>
							<td class="col-md-3" style="padding-top: 16px; padding-bottom: 16px;">96000</td>
							<td class="col-md-2" style="padding-top: 16px; padding-bottom: 16px;" title="Approved">Approved</td>
							</tr>
							</tbody>
						</table>
						</td>
						</tr>
						</tbody>
						</table>
						</div>
						
						
						<div class="col-md-12" style="border: 1px solid #ccc; margin-top: 15px;">
						<table class="col-md-12">
						<tbody>
						<tr>
						<td class="col-md-4" style="border-right: 1px solid #999;">
						<div id="requestNoDiv" class="col-md-12" style="margin-top: 10px; margin-bottom: 10px; padding:0;">
						<div class="col-md-12" style="padding-left: 0px; margin-bottom: 14px; padding:0;">
						<output class="col-md-4 requestNo " style="padding-left: 0px; cursor: pointer;">TM_1150930</output>
						<output class="col-md-4" role="Completed"  style="margin-top: 14px;">Completed</output>
						<output class="col-md-4" tooltip="Move to Current" style="padding: 0px; float: right; margin-top: 14px; cursor: pointer;"><i class="fa fa-hand-o-down" aria-hidden="true"></i>
</output>
						</div>
						<table class="col-md-12">
						<tbody>
						<tr style="font-size: 14px;">
						<th>Submission Date</th>
						<th>Approved Amount</th>
						<th>Requested Amount</th>
						</tr>
						<tr style="font-size: 12px;">
						<td>May-16-2013</td>
						<td>96000</td>
						<td>96000</td>
						</tr>
						</tbody>
						</table>
						</div>
						</td>
						<td class="col-md-7">
						<table id="detailsTable" style="width: 100%;">
						<tbody>
						<tr style="border-bottom: 1px #dadada solid; font-size: 12px; font-family: segoe ui; font-weight: 500;">
						<td class="col-md-4" style="padding-top: 16px; padding-bottom: 16px;">TRLP</td>
						<td class="col-md-3" style="padding-top: 16px; padding-bottom: 16px;">96000</td>
						<td class="col-md-3" style="padding-top: 16px; padding-bottom: 16px;">96000</td>
						<td class="col-md-2" style="padding-top: 16px; padding-bottom: 16px;" title="Approved">Approved</td>
						</tr>
						</tbody>
						</table>
						</td>
						</tr>
						</tbody>
						</table>
						</div>
					</div><!-- /.tabpanel -->    
					</div><!-- /.tab content --> 
				</div><!-- /.col -->
			</div><!-- /.row -->
		</div><!-- /.container-* -->
         
          </div>
          <!-- /.col-* --> 
        </div>
				<!-- /.row -->
      </div>
      <!-- /.container -->
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<style>
ul, li {
    border: 0 none;
    list-style: outside none none;
    margin: 0;
    padding: 0;
}
.infocard_legend li {
    float: left;
    margin-right: 15px;
}

.infocard_legend .worklist {
    background-color: #d9edf7;
}
.infocard_legend li span {
    border: 1px solid #ccc;
    float: left;
    height: 15px;
    margin: 2px 5px 2px 2px;
    width: 16px;
}

</style>
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	