@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Address Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Address Details </li>
				</ul>
			</div>
		</div>
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
				<div class="col-lg-12 project-menu">
				<div class="box-sidebar side-menu-main project-menu">
				<div class="box-head-dark">
				<i class="fa fa-bars"></i>
				Profile Menu
				</div>
				<div class="box-content">
				@include("employee_self_services/employeeperks/sidebar")
				</div>
				</div>
				</div>
			</div>
		</div>
          <div class="col-sm-9">
		  	
      <div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
            <table class="table-bordered">
              <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Associate Details</span><span class="pull-right"><a href="#">View Details >></a></span></div>
              <tr>
                <th>Role</th>
                <td>NO ROLE TAGGED</td>
                <th>Base Country</th>
                <td>INDIA</td>
                <th>Base Branch</th>
                <td>INDIA</td>
              </tr>
              <tr>
                <th>Employment Status</th>
                <td>Active Assignment</td>
                <th>Current Country</th>
                <td>INDIA</td>
                <th>Current Branch</th>
                <td>TCS - New Delhi</td>
              </tr>
            </table>
          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <table class="table-bordered">
             <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Loan Type</span> </div>
              <tr>
               <td>
<span class="BodyFont" style="text-align:left;font-weight:bold;">TCS Branch: </span>
</td>
<td>
<span style="width:300px;text-align: center;border-bottom: none">
<select id="loansForm:loanTypesNew" class="dropDownStyle" name="loansForm:loanTypesNew" size="1" style="width: 350; " onchange="submit()">
<option value="-1">Select</option>
<option value="5001">Emergency Medical Assistance</option>
</select>
</td>
</span>
              </tr>
            </table>
          </div>
        </div>
        <!-- /.col-* --> 
        
      </div>
		  </div>
		
		  </div><!-- /.row -->
		</div><!-- /.container -->
		 
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	