@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Address Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Address Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/employeeperks/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
				  
      <div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
            <table class="table-bordered">
              <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Associate Details</span></div>
              <tr>
                <th>Role</th>
                <td>Developer</td>
                <th>Home Country</th>
                <td>INDIA</td>
                <th>Current Country</th>
                <td>INDIA</td>
              </tr>
              <tr>
                <th>Employment Status</th>
                <td>Active Assignment</td>
                <th>Base Branch</th>
                <td>TCS - New Delhi</td>
                <th>Current Branch</th>
                <td>TCS - New Delhi</td>
              </tr>
			  <tr>
                <th>Employee Type</th>
                <td>Employee</td>
                <th>Base DC</th>
                <td>New Delhi - Non STP</td>
                <th>Current DC</th>
                <td>Chandigarh - Non STP</td>
              </tr>
            </table>
          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <table class="table-bordered">
              <tr>
                <th>Date of Birth</th>
                <td>Oct-10-1985</td>
                <th>Age</th>
                <td>31Years</td>
              </tr>
              
              <tr>
                <th>DOJ with TCS</th>
                <td>Mar-16-2011</td>
                <th>Service in TCS</th>
                <td>5.87Years</td>
              </tr>
            </table>
          </div>
        </div>
        <!-- /.col-* --> 
        
      </div>
      <!-- /.row --> 

    <!-- /.container --> 

	<div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
		   <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Patient/Illness Details</span></div>
           <table class="table-bordered">
			<tbody>
			<tr>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Patient's Relation with Member</span>
			</td>
			<td>
			<select class="textBoxStyle" name="applyMedicalWfTrust:_idJsp213" size="1" style="width:180px" onchange="submit(this);">
			<option value="--Select--">--Select Patient--</option>
			<option value="Self">Self</option>
			<option value="Spouse">Spouse</option>
			<option value="First Child">First Child</option>
			</select>
			</td>
			<td></td>
			<td></td>
			</tr>
			<tr>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Name of Patient</span>
			</td>
			<td>
			<input id="applyMedicalWfTrust:_idJsp220" class="textBoxStyle" name="applyMedicalWfTrust:_idJsp220" value="" style="font-weight: normal;width:180px" disabled="disabled" type="text">
			</td>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Date of Birth (Age)</span>
			</td>
			<td>
			<input id="applyMedicalWfTrust:_idJsp224" class="textBoxStyle" name="applyMedicalWfTrust:_idJsp224" value="" style="font-weight: normal;width:180px" disabled="disabled" type="text">
			</td>
			</tr>
			<tr>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Ailment/Disease</span>
			</td>
			<td>
			<input id="applyMedicalWfTrust:_idJsp230" class="textBoxStyle" name="applyMedicalWfTrust:_idJsp230" value="" maxlength="100" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkAddress(this,event);" style="width:180px" type="text">
			</td>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Suffering since</span>
			</td>
			<td>
			<input id="applyMedicalWfTrust:sufferingSince" class="textBoxStyle" name="applyMedicalWfTrust:sufferingSince" maxlength="11" onmousedown="return clickIcon(this)" onkeydown="return clickIcon(this)" title="Suffering since" style="width:165px;" onfocus="selectText('null', 'applyMedicalWfTrust:sufferingSince')" onclick="selectText('null', 'applyMedicalWfTrust:sufferingSince')" type="text">
			<span id="applyMedicalWfTrust:sufferingSinceSpan">
			<img src="/gess/images/Icon_calendar.gif" style="vertical-align:bottom;" onclick="applyMedicalWfTrust_3AsufferingSinceCalendarVar._popUpCalendar(this,document.getElementById('applyMedicalWfTrust:sufferingSince'),'MMM-dd-yyyy')">
			</td>
			</tr>
			<tr>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold;margin: 0px 0px 10px 0px;">Name of doctor/hospital providing treatment</span>
			</td>
			<td>
			<textarea id="applyMedicalWfTrust:doctor_hospital_name" class="textBoxStyle" name="applyMedicalWfTrust:doctor_hospital_name" onkeypress="if(event.keyCode!=9) return chkAddress(this,event) && commentsLength1();" onkeyup="LimtCharacters(this,300,'lblcount1');" style="width:180px;height:30pt;"></textarea>
			<label style="font-size: 11;color: rgb(104, 103, 103);"><strong>300</strong> Characters Left</label>
			</td>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold;margin: 0px 0px 10px 0px;">Address of doctor/hospital providing treatment</span>
			</td>
			<td>
			<textarea id="applyMedicalWfTrust:doctor_hospital_address" class="textBoxStyle" name="applyMedicalWfTrust:doctor_hospital_address" onkeypress="if(event.keyCode!=9) return chkAddress(this,event) && commentsLength2();" onkeyup="LimtCharacters(this,400,'lblcount2');" style="width:180px;height:30pt;"></textarea>
			<label style="font-size: 11;color: rgb(104, 103, 103);"><strong>400</strong> Characters Left</label>
			</td>
			</tr>
			<tr>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Duration of Treatment</span>
			</td>
			<td>
			<input id="applyMedicalWfTrust:_idJsp247" class="textBoxStyle" name="applyMedicalWfTrust:_idJsp247" value="" maxlength="200" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkAlfaNumericWithDotOnly(this,event);" style="width:180px" type="text">
			</td>
			<td></td>
			<td></td>
			</tr>
			</tbody>
			</table>
          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
	  
	  
	  <div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
           <table class="table-bordered">
		    <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Expense Details</span></div>
			<tbody>
			<tr>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Approximate cost of treatment</span>
			</td>
			<td>
			<input id="applyMedicalWfTrust:_idJsp254" class="textBoxStyle" name="applyMedicalWfTrust:_idJsp254" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="font-weight: normal;width:180px" onblur="return checkNum(this);" type="text">
			</td>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Whether enrolled for HIS higher hospitalization benefits</span>
			</td>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Yes</span>
			</td>
			</tr>
			<tr>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Amount received from HIS</span>
			</td>
			<td>
			<input id="applyMedicalWfTrust:_idJsp262" class="textBoxStyle" name="applyMedicalWfTrust:_idJsp262" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="font-weight: normal;width:180px" onblur="return checkNum(this);" type="text">
			</td>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold;margin: 0px 0px 10px 0px;">Denial reason for full or part amount in HIS claim</span>
			</td>
			<td>
			<textarea id="applyMedicalWfTrust:HIS_denial_reason" class="textBoxStyle" name="applyMedicalWfTrust:HIS_denial_reason" onkeypress="if(event.keyCode!=9) return chkAddress(this,event) && commentsLength3();" onkeyup="LimtCharacters(this,400,'lblcount3');" style="width:180px;height:30pt;"></textarea>
			<label style="font-size: 11;color: rgb(104, 103, 103);"><strong>400</strong> Characters Left</label>
			</td>
			</tr>
			<tr>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Amount recovered from other sources</span>
			</td>
			<td>
			<input id="applyMedicalWfTrust:_idJsp271" class="textBoxStyle" name="applyMedicalWfTrust:_idJsp271" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="font-weight: normal;width:180px" onblur="return checkNum(this);" type="text">
			</td>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Name of the source</span>
			</td>
			<td>
			<input id="applyMedicalWfTrust:_idJsp275" class="textBoxStyle" name="applyMedicalWfTrust:_idJsp275" value="" maxlength="150" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkAlfaNumericWithDotOnly(this,event);" style="width:180px" type="text">
			</td>
			</tr>
			<tr>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Approximate expenses in future</span>
			</td>
			<td>
			<input id="applyMedicalWfTrust:_idJsp279" class="textBoxStyle" name="applyMedicalWfTrust:_idJsp279" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="font-weight: normal;width:180px" onblur="return checkNum(this);" type="text">
		    </td>
			<td>
			<span class="BodyFont" style="color: #000000;font-weight:bold">Amount requested from Trust</span>
			</td>
			<td>
			<input id="applyMedicalWfTrust:_idJsp283" class="textBoxStyle" name="applyMedicalWfTrust:_idJsp283" value="" maxlength="7" autocomplete="off" onkeypress="if(event.keyCode!=9) return chkNumOnly(this,event);" style="font-weight: normal;width:180px" onblur="return checkNum(this);" type="text">
		    </td>
			</tr>
			</tbody>
			</table>
          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
	  
	  <div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
            <table class="table-bordered">
              <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Upload Excel</span></div>
              
				<tbody>
				<tr>
				<td>
				<span class="BodyFont" style="font-size:14px;">Please</span>
				<a id="applyMedicalWfTrust:_idJsp292" href="#" onclick="return oamSubmitForm('applyMedicalWfTrust','applyMedicalWfTrust:_idJsp292');" style="font-size:14px;">click here</a>
				<input name="autoScroll" type="hidden">
				<span class="BodyFont" style="font-size:14px;">to download excel template to upload medical expense details.</span>
				</td>
				</tr>
				<tr>
				<td>
				<span style="float:left;"><input id="applyMedicalWfTrust:fileupload" class="textBoxStyle" name="applyMedicalWfTrust:fileupload" size="50" title=" Please Select file " style="margin-top:16px;" type="file"></span>
				<span style="float:left;margin-top:10px;"><button class="btn btn-primary btn-sm">
<span>Upload XLS</span>
</button></span>
				</td>
				</tr>
				</tbody>
            </table>
          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
	  
	  	  <div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
		   <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Supporting Documents Required</span></div>

		  
			<div class="col-sm-12" style="border:1px solid #CCC; padding:10px;">
			

				<div class="BodyFont">Kindly note, you are required to submit the following documents.</div>

				<div class="BodyFont">1. Original Bills and receipts.</div>


				<div class="BodyFont">2. Copy of Discharge summary.</div>


				<div class="BodyFont">3. Copies of Investigation reports.</div>


				<div class="BodyFont">4. Original Pharmacy bills with doctors prescription.</div>


				<div class="BodyFont">5. Detailed Excel of the Bills and Prescription.</div>
				</div>

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
		
		<div class="col-lg-12" style="padding:8px; background-color:#E8F2FE; border-top:1px solid #006;">
<div class="col-lg-2" style=" margin-left:20px;">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Cancel" type="submit">
</div>
<div class="col-lg-2">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Proceed" type="submit">
</div>
<div class="col-lg-2">
<input class="btn btn-primary" name="BobDetail:ArchiveButton" value="Save as Draft" type="submit">
</div>
</div>
		
      </div>
      <!-- /.container -->
		   </div><!-- /.col-* -->
		</div><!-- /.row -->
	</div><!-- /.container -->
		 
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	