<ul class="navside">
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'medical-assistance')) }}">Medical Assistance</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'higher-education-assistance')) }}">Higher Education Assistance</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'company-transport')) }}">Company Transport</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'bonafide-letter')) }}">Bonafied Letter</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'apply-loans')) }}">Apply Loans</a>
	</li>
</ul>
