<ul class="navside">
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'travel-nominee')) }}">Accomodation Transport</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'residency')) }}">Residency</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'frequent-flyer-details')) }}">Frequent Flyer Details</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'apply-visa-details')) }}">Apply Visa Details</a>
	</li>
</ul>

