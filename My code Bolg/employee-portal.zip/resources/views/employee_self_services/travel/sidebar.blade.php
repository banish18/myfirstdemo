<ul class="navside">
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'accommodation-and-transport-initiation')) }}">Accomodation Transport</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'allocation-deallocation')) }}">Domestic</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'feedback')) }}">Feedback</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'international')) }}">International</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'frequent-flyer-details')) }}">My Travel-Essentials</a>
	</li>
</ul>

