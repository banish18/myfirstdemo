@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Address Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Address Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/claim/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
             <div class="container mb40">
					<div class="row">
					  <div class="col-sm-12">
						<h4>Voice/Data Request Form</h4>
						<table  class="table-bordered" width="100%" align="center">
						  <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Voice/Data Request Form</span> </div>
						 
			<tbody>
			<tr>
			<td>
			<span class="BodyFont" style="color:red">* </span>
			<span class="BodyFont" style="text-align:left;font-weight:bold;">Select Connection Type</span>
			</td>
			<td>
			<span style="width:300px;text-align: center;border-bottom: none">
			<select id="ApplyMobileRequestForm:expenseTypeListId1" class="dropDownStyle1" name="ApplyMobileRequestForm:expenseTypeListId1" size="1" style="width:200px;text-align:left;float:left" onchange="submit()">
			<option value="Select">Select</option>
			<option value="327">Voice/Data Connection</option>
			<option value="328">Data Card(USB) Connection</option>
			</select>
			</span>
			</td>
			</tr>
			</tbody>
			</table>
						</table>
					  </div>
					  <!-- /.col-* --> 
					</div>
					<!-- /.row --> 
				  </div>
				  <!-- /.container -->

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	