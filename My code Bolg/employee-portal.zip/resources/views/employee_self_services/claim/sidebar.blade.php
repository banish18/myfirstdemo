<ul class="navside">
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'apply-claims')) }}">Apply Claims</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'claim-history')) }}">Client History</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'view-advance-history')) }}">View Advance History</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'view-advance-report')) }}">View Advance Report</a>
	</li>
	<li>
		<a class="" href="{{ route('employee-services',array('action' => 'voice-data-request')) }}">View Data Request</a>
	</li>
</ul>
