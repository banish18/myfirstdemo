@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Address Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Address Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/claim/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
             <div class="container mb40">
					<div class="row">
					<div class="col-sm-12">
					<h4> <span>My Details <span style="font-size:13px; float:right;"><a href="#">(View General Guidelines) </a></span></span></h4>
					<table class="table-bordered">
					<div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Associate Details</span> </div>
					<tr>
					<th>Role</th>
					<td>Developer</td>
					<th>Base Country</th>
					<td>INDIA</td>
					<th>Base Branch</th>
					<td>TCS - New Delhi</td>
					</tr>
					<tr>
					<th>Employment Status</th>
					<td>Active Assignment</td>
					<th>Current Country</th>
					<td>INDIA</td>
					<th>Current Branch</th>
					<td>TCS - New Delhi</td>
					</tr>
					</table>
					</div>
					<!-- /.col-* --> 
					</div>
					<!-- /.row --> 
					</div>
					<!-- /.container -->

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
	  <div class="container mb40">
<div class="row">
<div class="col-sm-12">


<table class="table-bordered" style="text-align: justify" width="100%" cellspacing="0" cellpadding="0">
<div class="col-sm-12" style="border:1px solid #CCC; padding:4px;"> <span>Finance Location and Advance Type</span> </div>
<tbody>
<tr>
<td>
<table width="80%" align="left">
<tbody>
<tr>
<td>
<span style="width: 100%">
<span class="Bodyfont" style="font-weight: bold; padding-left: 40">*Select Country</span>
</span>
</td>
<td></td>
<td>
<table class="BodyFont">
<tbody>
<tr>
<td>
<label>
<input class="BodyFont" name="form:_idJsp177" checked="checked" value="hmcountry" type="radio">
Home Country
</label>
</td>
</tr>
</tbody>
</table>
</td>
<td></td>
</tr>
</tbody>
</table>
</td>
<td>
<table width="80%" align="right">
<tbody>
<tr>
<td>
<span style="width:100%">
<span class="Bodyfont" style="font-weight: bold">*Advance type</span>
</span>
</td>
<td>
<table>
<tbody>
<tr>
<td>
<select id="form:AdvTypes" class="dropDownStyle" name="form:AdvTypes" size="1" style="width: 250" onchange="submit()">
<option value="-1">Select</option>
<option value="168">Salary Advance</option>
<option value="170">Sundry Advance</option>
<option value="101">Travel Advance</option>
</select>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</div>
<!-- /.col-* --> 
</div>
<!-- /.row --> 
</div>
<!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	