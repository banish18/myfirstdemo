@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Address Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Address Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/claim/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
			  <div class="container">
	    <div class="row">
          <div class="col-sm-12 nomargpadding">
		<div class="col-xs-6 nomargpadding">
		<div id="custom" class="custom">
		
		<div class="panel-group">
		 <div class="panel panel-default panel-open">
		  <div class="panel-heading">
		   <h4 class="panel-title">
		    <a class="accordion-toggle" href="" tabindex="0">
		   <span>
		    <i class="fa fa-money fa-3x" aria-hidden="true"></i>
		    <b class="parentDivTitle">
		    <span>OTHER CLAIMS</span>
		    </b>
		   </span>
		    </a>
		   </h4>
		 </div>
		<div class="panel-collapse in collapse">
		<div class="panel-body">
		<div id="MyclaimCustomDiv">
		<div class="row">
		<div class="col-xs-12">
		<div id="dragDrop" class="dragAndDropDiv dragAndDropDivMain">
		<div class="row ng-scope">
		<div class="col-md-3">
		<img src="../../assets/img/dnd_animation.gif">
		</div>
		<div class="col-md-9 dndcontent pull-right">
		<div class="row">
		<div class="col-md-12">
		<span class="h1" style="color: #999; font-weight: 100;">Drag & Drop Bills</span>
		</div>
		</div>
		<div class="row" style="margin-top: 5px;">
		<div class="col-md-12">Multiple bills can be dropped together</div>
		</div>
		<div class="row">
		<div class="col-md-12">
		<label id="link" for="filePickerFav1">
		<div class="btn btn-default hand" style="margin-top: 5px; padding-top: 1px; font-size: 12px; height: 24px; margin-bottom: -7px; font-weight: bold;" translate="">
		<span class="ng-scope">Browse Files</span>
		</div>
		</label>
		</div>
		</div>
		<div class="row">
		<div class="col-md-12 h6">
		<strong>Upload only jpg, jpeg, png or pdf format. Maximum file size 1MB per bill. </strong>
		</div>
		</div>
		</div>
		</div>
		</div>
		<br>
		<br>
		<div class="row">
		<div class="col-md-12">
		<button class="btn btn-primary btn-lg">Claim without Bills</button>
		</div>
		</div>
		  <div class="row marginTop8">
		  <div class="col-md-12">
		  <span class="clm-icon-note-2" style="color: #f99506"></span>
		 <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
 <em>Note: Only certain types of claim can be raised without bill. System will prompt for uploading bill wherever required. </em>
		  </div>
		  </div>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	</div>
	

	
	


		
		<div class="col-xs-6 nomargpadding">
		<div id="customGreen" class="customGreen">

<div class="panel-group">
<div class="panel panel-default panel-open">
<div class="panel-heading">
<h4 class="panel-title">
<a class="accordion-toggle" href="" tabindex="0">
<span class="ng-binding">
<i class="fa fa-plane fa-3x" aria-hidden="true"></i>
<b class="parentDivTitle">
<span>TRAVEL CLAIMS</span>
</b>
</span>
</a>
</h4>
</div>
<div class="panel-collapse in collapse" style="height: auto;">
<div class="panel-body">
<div class="ng-scope"></div>
<div id="TravelClaimCustomDiv">
<div id="introexisitingTravel" class="col-md-5 claimHeading" style="display: inline-block; text-align:center;">
<i class="fa fa-file-text-o fa-4x" aria-hidden="true"></i>

<div class="travel-claim-color claimHeading" >
<span>Travel Expenses</span>
</div>
<div id="introselectTravel" class="buttonPurple hand claimHeading" style="display: inline-block; text-align:center;">
<span>Select Travel Requests</span>
</div>
</div>
<div class="col-md-7 claimHeading" id="exisitingTravel" style="display: inline-block; text-align:center;">
<i class="fa fa-file-text-o fa-4x" aria-hidden="true"></i>
<div class="travel-claim-color claimHeading">
<span>Without Travel Request</span>
</div>
<div class="buttonPurple hand claimHeading" style="display: inline-block; text-align:center;">
<span>Create New Travel</span>
</div>
</div>
<div id="heightBalancer" style="height: 50px; display: none;"></div>
</div>
</div>
</div>
</div>
</div>

</div>
		</div>		
    </div>
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding: 10px 0px 5px; box-shadow: 0px 1px 4px 0px rgba(153, 153, 153, 0.6); border: 1px solid rgb(204, 204, 204); background-color: rgb(247, 247, 247);margin-bottom:15px;">
	<div id="dynamicCliamDiv">
<div class="row nomargin">
<div class="col-xs-1 col-md-4">
<div id="customSmallIta">
<span class="ng-scope">Select claim head from the list below</span>
</div>
<div style="height:535px;display:block">
<div id="scrollableDivHead" style="width: 328px; position: static; top: auto; margin-top: 0px;">
<div id="toggleA">
<div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 565px;">
<div id="custScrollOther" class="claimHeadPan" style="overflow: hidden; width: auto; height: 565px;">
<div class="claimHeadsMain hand">
<div class="row alignClaimHeads">
<div class="col-xs-12 col-md-2">
<i class="fa fa-briefcase fa-2x" aria-hidden="true"></i>
</div>
<div class="col-md-10 hidden-sm">Business Meeting Expenses</div>
</div>
</div>
<div class="claimHeadsMain hand ng-scope">
<div class="row alignClaimHeads">
<div class="col-xs-12 col-md-2">
<i class="fa fa-shopping-bag fa-2x" aria-hidden="true"></i>
</div>
<div class="col-md-10 hidden-sm">Client Entertainment</div>
</div>
</div>
<div class="claimHeadsMain hand">
<div class="row alignClaimHeads">
<div class="col-xs-12 col-md-2">
<i class="fa fa-phone fa-2x" aria-hidden="true"></i>
</div>
<div class="col-md-10 hidden-sm">Communication Expenses</div>
</div>
</div>
<div class="claimHeadsMain hand">
<div class="row alignClaimHeads">
<div class="col-xs-12 col-md-2">
<i class="fa fa-connectdevelop fa-2x" aria-hidden="true"></i>
</div>
<div class="col-md-10 hidden-sm">Conference and Training Courses</div>
</div>
</div>
<div class="claimHeadsMain hand">
<div class="row alignClaimHeads">
<div class="col-xs-12 col-md-2">
<i class="fa fa-phone fa-2x" aria-hidden="true"></i>
</div>
<div class="col-md-10 hidden-sm">Grant Settlement</div>
</div>
</div>
<div class="claimHeadsMain hand">
<div class="row alignClaimHeads">
<div class="col-xs-12 col-md-2">
<i class="fa fa-bus fa-2x" aria-hidden="true"></i>
</div>
<div class="col-md-10 hidden-sm ng-binding">Local Conveyance</div>
</div>
</div>
<div class="claimHeadsMain hand">
<div class="row alignClaimHeads">
<div class="col-xs-12 col-md-2">
<i class="fa fa-building fa-2x" aria-hidden="true"></i>
</div>
<div class="col-md-10 hidden-sm">Office Expense</div>
</div>
</div>
<div class="claimHeadsMain hand" ng-repeat="claimHead in currentSessionVar.claimHeadList">
<div class="row alignClaimHeads">
<div class="col-xs-12 col-md-2">
<i class="fa fa-address-book-o fa-2x" aria-hidden="true"></i>
</div>
<div class="col-md-10 hidden-sm">Professional Membership</div>
</div>
</div>
<div class="claimHeadsMain hand">
<div class="row alignClaimHeads">
<div class="col-xs-12 col-md-2">
<i class="fa fa-shirtsinbulk fa-2x" aria-hidden="true"></i>
</div>
<div class="col-md-10 hidden-sm">Shift Working / Extended Hours</div>
</div>
</div>
<div class="claimHeadsMain hand ">
<div class="row alignClaimHeads">
<div class="col-xs-12 col-md-2">
<i class="fa fa-shield fa-2x" aria-hidden="true"></i>
</div>
<div class="col-md-10 hidden-sm">Staff Welfare</div>
</div>
</div>
<div class="claimHeadsMain hand">
<div class="row alignClaimHeads">
<div class="col-xs-12 col-md-2">
<i class="fa fa-cc-visa fa-2x" aria-hidden="true"></i>
</div>
<div class="col-md-10 hidden-sm">Visa & Passport Expenses</div>
</div>
</div>
</div>
<div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; opacity: 0.2; z-index: 90; right: 5px;"></div>
</div>
</div>
<div id="toggleB">
<div id="custScrollTrv" class="claimHeadPanTravel hand"> </div>
</div>
</div>
</div>
</div>
<div class="col-sm-8">

<ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active">
					<a href="#apply_other" aria-controls="present" role="tab" data-toggle="tab">
						<strong>Apply Other Claims (0)</strong>
						
					</a>
				</li>

				<li class="disabled" role="presentation">
					<a href="#apply_travel" aria-controls="permanent" role="tab" data-toggle="tab">
						<strong>Apply Travel Claims (0)</strong>
						
					</a>
				</li>
                
			</ul>
<div class="claimtypetab  other">
<div class="tab-content">
<div class="tab-pane ng-scope active">
<div id="mainFormDivClm" class="ng-scope" style="width: 100%">
<div id="step9" class="well" style="padding-top: 0;">
<div id="successDiv" style="width: 100%; padding: 14px; display: none;">
<div style="width: 496px; height: 50px; margin-right: auto; margin-left: auto; border: 2px solid #139e57; padding: 14px; background: #FFFFFF">
<img src="img/please_note_icon.png" style="vertical-align: middle; padding-left: 6px;">
<span style="padding-left: 10px; font-size: 14px !important; color: #139e57; font-weight: bold;"> </span>
</div>
</div>
<div class="row nomargin">
<div class="col-md-12 white-bg shadow text-center" style="margin-top: 15px; background-color: white; height: 60px; padding-top: 21px;">

<i class="fa fa-plus" aria-hidden="true"></i>
<span class="ng-scope"><a href="#" id="addNew">ADD NEW CLAIM</a></span>

</div>
</div>
</div>
</div>
</div>
<div class="tab-pane">
<div id="mainFormDivClm" class="ng-scope" style="width: 100%">
<div id="purpleBackgroundDiv" style="width: 100%; background: #7F63CA; height: 30px;">
<div style="display: table; width: 100%"> </div>
</div>
<div id="travDivSum" style="display: block; width: 100%; padding-top: 12px; padding-bottom: 12px; padding-left: 10px; background: #FFFFFF">
<div style="width: 100%">
<div style="display: inline-block; width: 84px; vertical-align: top">
<div class="eligMsgText" translate="">
<span>Travel Request</span>
</div>
<div class="ipText" style="padding-top: 6px"></div>
</div>
<div style="display: inline-block; width: 188px; padding-left: 10px; vertical-align: top">
<div class="eligMsgText" translate="">
<span>Travel Type</span>
</div>
<div class="ipText" style="padding-top: 6px"></div>
</div>
<div style="display: inline-block; width: 258px; padding-left: 10px; vertical-align: top">
<div class="eligMsgText" translate="">
<span>Location Details</span>
</div>
<div class="ipText" style="padding-top: 6px"></div>
</div>
<div style="display: inline-block; width: 188px; padding-left: 10px; vertical-align: top">
<div class="eligMsgText" translate="">
<span>Travel Dates</span>
</div>
<div class="ipText" style="padding-top: 6px">24-Jan-2017 to 24-Jan-2017</div>
</div>
<div style="display: inline-block; width: 94px; padding-left: 10px; vertical-align: top">
<div class="eligMsgText" translate="">
<span>Individuals</span>
</div>
<div class="ipText" style="padding-top: 6px"></div>
</div>
</div>
</div>
<div class="well">
<div> </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="row nomargin">
<div class="col-md-12 other-claim-color-bg" style="height: 4px"></div>
</div>
<div id="submitDiv" style="padding-top: 16px; padding-bottom: 16px; box-shadow: 0 4px 6px -6px #000000;">
<div class="row">
<div class="col-xs-12">
<div style="box-shadow: 0 4px 6px -6px #000000;
    padding-bottom: 16px;
    padding-top: 16px;"></div>
	<br/>
<div class="col-xs-7">

<div class="checkbox">
<label class="tncText">
<input class="ng-pristine ng-untouched ng-valid" type="checkbox">
I confirm that I have read the
<a>terms and conditions</a>
related to claims reimbursement policy and I will abide with them.
</label>
</div>

</div>
<div class="col-xs-5 nohpadding">
<div class="pull-right">
<button class="btn btn-primary btn-lg">
<span class="ng-scope">Submit</span>
</button>
<button class="btn btn-default">
<span>Save as Draft</span>
</button>
<button class="btn btn-default">
<span>Discard All</span>
</button>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
	

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding: 10px 0px 5px; box-shadow: 0px 1px 4px 0px rgba(153, 153, 153, 0.6); border: 1px solid rgb(204, 204, 204); background-color: rgb(247, 247, 247);margin-bottom:15px;">
<ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active">
					<a href="#present" aria-controls="present" role="tab" data-toggle="tab">
						<strong>Payslip</strong>
						<span></span>
					</a>
				</li>

				<li role="presentation">
					<a href="#permanent" aria-controls="permanent" role="tab" data-toggle="tab">
						<strong>Compensation letter</strong>
						<span></span>
					</a>
				</li>
                <li role="presentation">
					<a href="#other" aria-controls="other" role="tab" data-toggle="tab">
						<strong>Compensation letter</strong>
						<span></span>
					</a>
				</li>
			</ul>
            
            <div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="present">
					<div class="row">
						<div class="col-sm-12">
                        <div class="col-sm-4">
							<div class="amount-box">
							<div class="row clearfix">
							<div class="col-md-12 column">
							<div class="row clearfix">
							<div class="col-md-12 column amount-box-title" translate="">
							<span>Total Amount Claimed</span>
							</div>
							</div>
							<div class="row clearfix">
							<div class="col-md-12 column amount-box-amount">
							<span class="amount-box-currency ng-binding">INR </span>
							<span>0.00</span>
							</div>
							</div>
							</div>
							</div>
							</div>
							</div>
							<div class="col-sm-4">
							<div class="amount-box">
							<div class="row clearfix">
							<div class="col-md-12 column">
							<div class="row clearfix">
							<div class="col-md-12 column amount-box-title">
							<span>Total Amount Claimed</span>
							</div>
							</div>
							<div class="row clearfix">
							<div class="col-md-12 column amount-box-amount">
							<span class="amount-box-currency">INR </span>
							<span>0.00</span>
							</div>
							</div>
							</div>
							</div>
							</div>
							</div>
							<div class="col-sm-4">
							<div class="amount-box">
							<div class="row clearfix">
							<div class="col-md-12 column">
							<div class="row clearfix">
							<div class="col-md-12 column amount-box-title" translate="">
							<span>Total Amount Claimed</span>
							</div>
							</div>
							<div class="row clearfix">
							<div class="col-md-12 column amount-box-amount">
							<span class="amount-box-currency">INR </span>
							<span>0.00</span>
							</div>
							</div>
							</div>
							</div>
							</div>
							</div>

                            
                           </div><!-- /.col-* -->
					</div><!-- /.row -->          
              </div><!-- /.tab-pane -->


				<div role="tabpanel" class="tab-pane" id="permanent">
					<div class="row">
						<div class="col-sm-12">
							<div class="col-sm-6">
							<div class="form-group">
								<p>No data present.</p>
							</div><!-- /.form-group -->
                            
                                      
                        </div>    
                      </div><!-- /.col-* -->
					</div><!-- /.row -->
                  </div><!-- /.tab-pane -->
                  
                  
                  <div role="tabpanel" class="tab-pane" id="other">
					<div class="row">
							<div class="col-sm-12">
							<div class="form-group">
							<table class="table table-bordered table-striped table-condensed ctable" style="background-color:#fff;">
<tbody>
<tr>
<th>Advance ID</th>
<th>Advance Paid On</th>
<th>Type Of Advance</th>
<th>Advance Amount</th>
<th>Settled Amount</th>
<th>Due Amount</th>
<th>Blocked Amount Claims</th>
<th>Blocked Amount Recovery</th>
<thBlocked Amount Refund</th>
</tr>
<tr>
<td>8209283</td>
<td></td>
<td>DEBT</td>
<td>INR 12000</td>
<td>INR 0</td>
<td>INR 12000</td>
<td>INR 0</td>
<td>INR 0</td>
<td>INR 0</td>
</tr>
</tbody>
</table>	
							</div><!-- /.form-group -->          
                            
                      </div><!-- /.col-* -->
					</div><!-- /.row -->
                  </div><!-- /.tab-pane -->
                  
                  
            
			</div>
		</div>      
                          
		</div><!-- /.col-* -->
	</div><!-- /.row -->
</div><!-- /.container -->

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
  <style>
.nav.header-actions li {
    margin: 0;
    padding:0;
}
.nav.header-actions li a {
    border: 1px solid rgba(0, 0, 0, 0);
    
    margin: 14px 0;
    padding: 0 5px;
}
.dropdown-menu {
    margin: 2px 28px 0;
    padding: 5px;
}
.navbar-toggle { top:40px;}
.nav.header-actions li {
    display: block;
    float: none;
}

.nav.header-actions li a {
    background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
    
}
.badge {background-color: red; color:#FFF;}
.nav .open > a, .nav .open > a:hover, .nav .open > a:focus {
    background-color: transparent;
    border-color: rgb(51, 122, 183);
}
.dropdown-menu li a{color: rgb(38, 38, 38);}
.dropdown-menu .divider {
    padding:0;
    margin:0;
}
.nav > li > a {
    padding: 10px 7px;
}
.nomargpadding {
    padding: 0;
    margin: 0;
}
#custom .panel-heading {
    background-color: #da532c;
    color: #ffffff;
    height: 40px;
    padding: 0 20px;
}
.panel-title {
    color: inherit;
    font-size: 14px;
    margin-bottom: 0;
    margin-top: 0;
}
.parentDivTitle {
    left: 72px;
    line-height: 40px;
    position: absolute;
}
#MyclaimCustomDiv {
    line-height: 1.2;
}
.dragAndDropDiv.dragAndDropDivMain {
    border: 2px dashed #d6492a;
    font-style: normal;
    height: 160px;
    line-height: 18px;
    text-align: left;
    width: 100%;
}
.dragAndDropDivMain .dndcontent {
    margin-left: -24px;
    margin-top: 19px;
}
.btn {
    border-width: 2px;
    font-size: 14px;
    height: 32px;
    min-width: 90px;
    padding-bottom: 0;
    padding-top: 0;
    text-transform: capitalize;
}
.btn-default {
    background-color: #fff;
    border-color: #2084c9;
    color: #2084c9;
}
#customGreen .panel-heading {
    background-color: #603cba;
    color: #ffffff;
    height: 40px;
    padding: 0 20px;
}
.claimHeading {
    font-size: 20px;
}
.travel-claim-color {
    color: #603cba;
}
.buttonPurple {
    border: 2px solid #603cba;
    color: #603cba;
    font-size: 12px !important;
    font-variant: normal;
    font-weight: bold;
    height: 32px;
    margin-top: 10px;
    padding-top: 6px;
    text-align: center;
    width: 140px;
}
.hand {
    cursor: pointer;
}
#customGreen .panel-group .panel-heading + .panel-collapse > .panel-body {
    background-color: #f7f7f7;
    border-top: medium none;
    height: 286px;
    min-height 186px;
}

#dynamicCliamDiv {
    transition: background-color 0.5s ease 0s;
}
#customSmallIta {
    background-color: #fff;
    color: #808080;
    font-size: 14px !important;
    font-style: italic;
    height: 40px;
    padding-left: 25px;
    padding-top: 11px;
	width: 328px;
}
.claimHeadPan {
    background-color: #da532c;
    box-shadow: -2px -2px 10px rgba(0, 0, 0, 0.36) inset;
    color: #ffffff;
    font-size: 14px !important;
    height: 574px;
}
.claimHeadsMain {
   
    padding: 10px 20px;
}
.claimHeadsMain:hover {
    background-color: #a84022;
}
.amount-box {
    background: #fff none repeat scroll 0 0;
    border: 1px solid #d6d6d6;
    color: #555;
    padding: 8px 15px 12px;
    text-align: right;
}
.amount-box .amount-box-title {
    font-size: 12px;
    font-weight: bold;
    padding-bottom: 3px;
}
.amount-box .amount-box-amount {
    font-size: 24px;
    line-height: 0.8;
}
.fa-exclamation-triangle{color:#F99506;}
.fa-file-text-o{color:#603CBA;}
.fa-plus{color:#309DA7;}
.claimHeading{margin-top:30px;}
	</style>
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	