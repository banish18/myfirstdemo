@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
		
    <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1 class="center">My Documents</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="container">
	<div class="row">
		<div class="col-sm-12">
			@if(Session::has('success'))
			<section class="seccess">
					
						<div class="alert alert-success"><em> {!! session::get('success') !!}</em></div>
					
				</section>
@endif

			<ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active">
					<a href="#personal" aria-controls="personal" role="tab" data-toggle="tab">
						<strong>Payslip</strong>
						<span></span>
					</a>
				</li>

				<li role="presentation">
					<a href="#company" aria-controls="company" role="tab" data-toggle="tab">
						<strong>Compensation letter</strong>
						<span></span>
					</a>
				</li>
			</ul>

			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="personal">
				<form method="post" action="{{ route('employee-services',array('action' => 'getDocument')) }}">
					{{ csrf_field() }}
					<div class="row">
						<div class="col-sm-6">
							<div class="form-group">
								<label for="form-register-username">Document Name</label>
								<select class="form-control" name="doctype" required>
                                 <option value="payslip">Payslip</option>
                                </select>
							</div><!-- /.form-group -->
                             
                            
							<div class="form-group">
								<label for="form-register-email">Form</label><br/>
								<select  name="from_month" required>
                                <option value="">--Month--</option>
                                <option value="01">January</option>
                                <option value="02">February</option>
                                <option value="03">March</option>
                                <option value="04">April</option>
                                <option value="05">May</option>
                                <option value="06">June</option>
                                <option value="07">July</option>
                                <option value="08">August</option>
                                <option value="09">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                                </select>

                                <select class="pull-right"  name="docfromyear" required>
                                <option value="">--Year--</option>
                                <option value="2011">2011</option>
                                <option value="2012">2012</option>
                                <option value="2013">2013</option>
                                <option value="2014">2014</option>
                                <option value="2015">2015</option>
                                <option value="2016">2016</option>
                                <option value="2017">2017</option>
                                <option value="2018">2018</option>
                                <option value="2019">2019</option>
                                <option value="2020">2020</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                                <option value="2026">2026</option>
                                <option value="2027">2027</option>
                                <option value="2028">2028</option>
                                <option value="2029">2029</option>
                                <option value="2030">2030</option>
                                <option value="2031">2031</option>
                                <option value="2032">2032</option>
                                <option value="2033">2033</option>
                                <option value="2034">2034</option>
                                <option value="2035">2035</option>
                                <option value="2036">2036</option>
                                </select>
							</div><!-- /.form-group -->

							<div class="form-group">
								<label for="form-register-password">Country:</label>
								<select class="form-control" name="doccountry">
                                <option value="India">India</option>
                                <option value="Usa">Usa</option>
                                </select>
							</div><!-- /.form-group -->
						</div><!-- /.col-* -->

						<div class="col-sm-6">
							<div class="row">
								<div class="form-group">
									<label for="form-register-username">Period:</label><br/>
									<input id="single_month" name="period" type="radio">
                                    Single Month
                                    <input id="multiple_month" name="period" type="radio">
                                    Multiple Months 
								</div><!-- /.form-group -->

								
							
<br/>
							<div class="form-group">
								<label form="form-register-photo">To:</label><br/>
								<select  name="tomonth" required>
                                <option value="">--Month--</option>
                                <option value="01">January</option>
                                <option value="02">February</option>
                                <option value="03">March</option>
                                <option value="04">April</option>
                                <option value="05">May</option>
                                <option value="06">June</option>
                                <option value="07">July</option>
                                <option value="08">August</option>
                                <option value="09">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                                </select>
                                
                                <select class="pull-right"  name="doctoyear" required>
                                <option value="">--Year--</option>
                                <option value="2011">2011</option>
                                <option value="2012">2012</option>
                                <option value="2013">2013</option>
                                <option value="2014">2014</option>
                                <option value="2015">2015</option>
                                <option value="2016">2016</option>
                                <option value="2017">2017</option>
                                <option value="2018">2018</option>
                                <option value="2019">2019</option>
                                <option value="2020">2020</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                                <option value="2026">2026</option>
                                <option value="2027">2027</option>
                                <option value="2028">2028</option>
                                <option value="2029">2029</option>
                                <option value="2030">2030</option>
                                <option value="2031">2031</option>
                                <option value="2032">2032</option>
                                <option value="2033">2033</option>
                                <option value="2034">2034</option>
                                <option value="2035">2035</option>
                                <option value="2036">2036</option>
                                </select>
							</div><!-- /.form-group -->
                            <div class="form-group">
									<label for="form-register-username">Company:</label><br/>
									<select class="form-control" name="company_logo" required="">
                                    <option value="">--Select Company Logo--</option>
                                    <option value="mindsolution">Mind Solution</option>
                                    <option value="maxtel">Max Tel</option>
                                    </select>
								</div><!-- /.form-group -->
							</div><!-- /.form-group-->
						</div><!-- /.col-* -->
					</div><!-- /.row -->

                   <br/>
					<div class="center">
					
                        <button type="submit" class="btn btn-secondary">Submit</button>
						<button type="submit" class="btn btn-primary">Reset</button>
					</div><!-- /.center -->
                    <br/>
                    Note:

                    <p>1) Payslip from 2014 onwords will only be displayed here.</p>
                    
                    <p>2) Please select"yes" under Additional Details to view Complete payslip with breakup of Arrears Paid, if any.</p>
                    
                    <p>3) Please select"No" to hide breakup of Arrears,Leave Balance,Bank Account number, PAN Details and Investment Details.</p>
					</form>
				</div><!-- /.tab-pane -->
				

				<div role="tabpanel" class="tab-pane" id="company">
				<form method="post" action="{{ route('employee-services',array('action' => 'getCompensation')) }}">
					<div class="row">
						<div class="col-sm-6">
							<div class="form-group">
								<label for="form-register-company-username">Document</label>
								<select class="form-control" name="letter_type" required="">
                                <option value="">--Select Letter--</option>
                                <option>Letter</option>
                                </select>
							</div><!-- /.form-group -->

							<div class="form-group">
								<label for="form-register-company-email">Period</label>
								<select class="form-control" name="letter_year" required="">
                                <option value="">--Select Year--</option>
                                <option value="2011">2011</option>
                                <option value="2012">2012</option>
                                <option value="2013">2013</option>
                                <option value="2014">2014</option>
                                <option value="2015">2015</option>
                                <option value="2016">2016</option>
                                <option value="2017">2017</option>
                                <option value="2018">2018</option>
                                <option value="2019">2019</option>
                                <option value="2020">2020</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                                <option value="2026">2026</option>
                                <option value="2027">2027</option>
                                <option value="2028">2028</option>
                                <option value="2029">2029</option>
                                <option value="2030">2030</option>
                                <option value="2031">2031</option>
                                <option value="2032">2032</option>
                                <option value="2033">2033</option>
                                <option value="2034">2034</option>
                                <option value="2035">2035</option>
                                <option value="2036">2036</option>
                                </select>
							</div><!-- /.form-group -->

							
						</div><!-- /.col-* -->
					</div><!-- /.row -->

					
						
<br/>
						<button type="submit" class="btn btn-secondary">Submit</button>
                        <br/><br/>
                    <p>Note:

						Letter post 2014 financial year will only be displayed here. Kindly refer to HR Management -> My Compensation Letters for letters before FY 2014. </p>
					</form>	
					</div><!-- /.center -->
                    
				</div><!-- /.tab-pane -->
			</div><!-- /.tab-content -->
		</div><!-- /.col-* -->
	</div><!-- /.row -->
</div><!-- /.container -->

        </div><!-- /.main -->
    </div>
</div>
@include('templates/footer')
@endsection
