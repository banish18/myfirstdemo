@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
      
    <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1>Position Detail</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="document-breadcrumb">
                <div class="container">
                    <ul class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Pages</a></li>
                        <li><a href="#">Custom page</a></li>
                    </ul>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="container">
	<div class="row">
		<div class="col-sm-8">
			<div class="position-header">
				<h1>
					Senior Java Developer
					<span>Urgent</span>
				</h1>

				<h2>
					<span class="position-header-company-image">
						<a href="company-detail.html">
							<img src="assets/img/tmp/dropbox.png" alt="">
						</a>
					</span>

					<a href="company-detail.html">
						Dropbox
					</a>
				</h2>
			</div><!-- /.position-header -->

			<div class="position-general-information">
				<dl>
					<dt>Location</dt>
					<dd>San Fracisco, California</dd>

					<dt>Start Date</dt>
					<dd>28/11/2015</dd>

					<dt>Contract</dt>
					<dd>Full time</dd>

					<dt>Salary</dt>
					<dd>By agreement</dd>

					<dt>Job ID</dt>
					<dd>#1234</dd>
				</dl>
			</div><!-- /.position-general-information -->

			<h3 class="page-header">Description, duties, responsibilities</h3>
			<p>
				Vivamus dignissim ex eu diam eleifend pharetra. Aliquam eleifend arcu quis risus scelerisque feugiat. Donec suscipit tincidunt purus et vulputate. Proin ac rutrum urna, nec elementum leo. Praesent commodo neque nunc, efficitur aliquam quam iaculis a. Sed quis eros justo. Pellentesque ut turpis quam.
			</p>

			<h3 class="page-header">Other benefits</h3>

			<ul>
				<li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit.</li>
				<li>Aliquam tincidunt mauris eu risus.</li>
				<li>Vestibulum auctor dapibus neque.</li>
				<li>Nunc dignissim risus id metus.</li>
				<li>Cras ornare tristique elit.</li>
				<li>Vivamus vestibulum nulla nec ante.</li>
				<li>Praesent placerat risus quis eros.</li>
				<li>Fusce pellentesque suscipit nibh.</li>
				<li>Integer vitae libero ac risus egestas placerat.</li>
				<li>Vestibulum commodo felis quis tortor.</li>
				<li>Ut aliquam sollicitudin leo.</li>
				<li>Cras iaculis ultricies nulla.</li>
				<li>Donec quis dui at dolor tempor interdum.</li>
				<li>Vivamus molestie gravida turpis.</li>
				<li>Fusce lobortis lorem at ipsum semper sagittis.</li>
				<li>Nam convallis pellentesque nisl.</li>
				<li>Integer malesuada commodo nulla.</li>
			</ul>

			<h3 class="page-header">Personality requirements and skills</h3>

			<ul>
				<li>Ut aliquam sollicitudin leo.</li>
				<li>Cras iaculis ultricies nulla.</li>
				<li>Donec quis dui at dolor tempor interdum.</li>
				<li>Vivamus molestie gravida turpis.</li>
				<li>Fusce lobortis lorem at ipsum semper sagittis.</li>
			</ul>
		</div><!-- /.col-* -->

		<div class="col-sm-4">
			<div class="company-card">
    <div class="company-card-image">
        <span>Top Employeer</span>
        <a href="company-detail.html">
            <img src="assets/img/tmp/dropbox.png" alt=""></a>
        </a>
    </div><!-- /.company-card-image -->

    <div class="company-card-data">
        <dl>
            <dt>Website</dt>
            <dd><a href="http://example.com/">www.example.com</a></dd>

            <dt>E-mail</dt>
            <dd><a href="#">info@example.com</a></dd>

            <dt>Phone</dt>
            <dd>1-234-456-789</dd>

            <dt>Address</dt>
            <dd>
                Everton Street 231,<br>
                San Francisco, California
            </dd>
        </dl>
    </div><!-- /.company-card-data -->
</div><!-- /.company-card -->


			<div class="widget">
				<h2>Apply For Position</h2>

				<form method="get" action="http://preview.byaviators.com/template/profession/position-detail.html?">
					<div class="form-group">
                        <input type="text" class="form-control" placeholder="Subject">
                    </div><!-- /.form-group -->

                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Your E-mail">
                    </div><!-- /.form-group -->

                    <div class="form-group">
                        <textarea class="form-control" rows="5" placeholder="Your Message"></textarea>
                    </div><!-- /.form-group -->

                    <button class="btn btn-secondary pull-right" type="submit">Apply Now</button>
				</form>
			</div><!-- /.widget -->
		</div><!-- /.col-* -->
	</div><!-- /.row -->
</div><!-- /.container -->

        </div><!-- /.main -->
    </div><!-- /.main-wrapper -->
    </div>
</div>
@include('templates/footer')
@endsection
