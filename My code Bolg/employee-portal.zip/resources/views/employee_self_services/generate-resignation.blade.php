@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
      <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1 class="center">Generate Resignation Request</h1>
                </div><!-- /.container -->
				<section class="seccess">
					@if(Session::has('success'))
						<div class="alert alert-success"><em> {!! session::get('success') !!}</em></div>
					@endif
				</section>
            </div><!-- /.document-title -->

            <div class="container">
			<div class="col-sm-9">
				<form method="post" action="{{ route('users',array('action' => 'postGeneraterequest')) }}" enctype="multipart/form-data">
				
				{{ csrf_field() }}
					
<h3 class="page-header" id="contact">Contact Information</h3>

            <div class="row" >
               <div class="col-sm-8">
                    <div class="form-group">
                        <label>Resignation Date</label>
                        <input class="form-control" name="r_date" id="r_date" type="text" required>
                    </div><!-- /.form-group -->
                    <div class="form-group">
                        <label>Reason</label>
                       <textarea name="reason" class="form-control" id="reason" required></textarea>
                    </div><!-- /.form-group -->
                </div>

                
            </div><!-- /.row -->
					<hr>

					<div class="center">
						<button type="submit" class="btn btn-secondary btn-lg">Submit</button>
					</div><!-- /.center -->
				</form>
			</div><!-- /.col-* -->

   
			</div><!-- /.container -->

        </div><!-- /.main -->
    </div><!-- /.main-wrapper -->
    </div>
</div>
@include('templates/footer')
<script>
	$(document).ready(function($){
		$("#r_date").datepicker();
	});
</script>
@endsection
