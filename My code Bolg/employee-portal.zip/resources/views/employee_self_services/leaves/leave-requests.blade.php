@extends('layouts.app')
@section('content')
    <div class="main-wrapper">
	<div class="main">
	 <!-- Sidebar  -->
	 
	 <div id="wrapper">
	  <div class="overlay"></div>
    
    
        
	
	  <!-- Page Content -->
       
            <button type="button" class="hamburger is-closed" data-toggle="offcanvas">
                <span class="hamb-top"></span>
    			<span class="hamb-middle"></span>
				<span class="hamb-bottom"></span>
            </button>
	</div>
	
	<!-- /#sidebar-wrapper -->
        
            <div class="document-title">
                <div class="container">
                    <h1 class="center">Leaves Request</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->
<div class="document-breadcrumb">
<div class="container">
<ul class="breadcrumb">
<li>
<a href="/">Home</a>
</li>
<li>Leaves Request</li>
</ul>
</div>
</div>

            <div class="container">
	<div class="row">
		<div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Leaves Menu
			</div>
			<div class="box-content">
			<ul>
			<li>
			<a class="side-menu-main-active" href="{{ route('leaves') }}"> Leaves Request</a>
			</li>
			<li>
			<a class="" href="{{ route('leaves',array('action' => 'apply-leaves')) }}"> Apply For Leaves</a>
			</li>
			
			</ul>
			</div>
			</div>
			</div>
		</div>
		</div>
		<div class="col-sm-9">
			<ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active">
					<a href="#personal" aria-controls="personal" role="tab" data-toggle="tab">
						<strong>MY BALANCE REPORT</strong>
						<span></span>
					</a>
				</li>

				<li role="presentation">
					<a href="#company" aria-controls="company" role="tab" data-toggle="tab">
						<strong>LOP DETAILS</strong>
						<span></span>
					</a>
				</li>
               
			</ul>
<style>
.searc {
    border-radius: 0;
    border-width: 0;
    width: 240px;
}
.searc form::after{color: rgb(153, 153, 153);
    content: "?";
    display: block;
    font-family: "FontAwesome";
    position: absolute;
    right: 30px;
    top: 11px;
}
table{width:100%; margin-top:15px;}
table th, tr, td{ margin:15px; padding:15px; border:1px solid #999;}
</style>
			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="personal">
					<div class="row">
						<div class="col-sm-12">
                        
                        <div class="col-sm-4 pull-right searc">
<form method="get" action="http://preview.byaviators.com/template/profession/registration.html?">
<input class="form-control" placeholder="Search ..." type="text">
</form></div>
<div class="col-sm-12">
<span>
<span><h4>My Leave Balance Report <span style="font-size: 16px; color: #454545;">(As On <?php echo date('d-M-Y')?>)</span></h4></span>
</span>
<table class="table" style="text-align: left; border: rgb(190, 190, 190) 1px solid; padding-bottom: 14px;">
<tbody>
<tr style="color: #ffffff; background-color: #4f81b1; font-size: 12px; font-weight: bold;">
<th rowspan="2" style="text-align:left;width:10%;border:1px solid #608db8;">Leave Type</th>
<th colspan="1" style="text-align:center; border:1px solid #608db8;text-align: center">Opening Balance</th>
<th colspan="1" style="text-align:center; border:1px solid #608db8;text-align: center" data-ng-show="('India'==homeCountry)">Surplus Leaves Encashed </th>
<th colspan="1" style="text-align:center; border:1px solid #608db8;">Surplus Leaves Lapsed </th>
<th rowspan="2" style="text-align:center; text-align:center;width:10%;border:1px solid #608db8;">Last Credit Date</th>
<th colspan="1" style="text-align:center; border:1px solid #608db8;">Leaves Credited </th>
<th colspan="1" style="text-align:center; border:1px solid #608db8;">Leaves Approved </th>
<th colspan="1" style="text-align:center;border:1px solid #608db8;">Leaves Awaiting Approval </th>
<th style="text-align:center; border:1px solid #608db8;">Postponement</th>
<th colspan="1" style="text-align:center; border:1px solid #608db8;">Timesheet Leaves </th>
<th colspan="1" style="text-align:center;border:1px solid #608db8;">Leave Balance </th>
</tr>
<tr style="color: #ffffff; background-color: #4f81b1; font-size: 12px; font-weight: bold;">
<th class="col-md-1" style="text-align: center;font-size: 10px;border:1px solid #608db8;">A </th>
<th class="col-md-1" style="text-align: center;font-size: 10px;border:1px solid #608db8;">B </th>
<th class="col-md-1" style="text-align: center;font-size: 10px;border:1px solid #608db8;">C </th>
<th class="col-md-1" style="text-align: center;font-size: 10px;border:1px solid #608db8;">D </th>
<th class="col-md-1" style="text-align: center;font-size: 10px;border:1px solid #608db8;">E </th>
<th class="col-md-1" style="text-align: center;font-size: 10px;border:1px solid #608db8;">F </th>
<th class="col-md-1" style="text-align: center;font-size: 10px;border:1px solid #608db8;">G </th>
<th class="col-md-1" style="text-align: center;font-size: 10px;border:1px solid #608db8;">
F=(A+C)-(B+D)
</th>
</tr>
@if($data["leaves"])
	@foreach($data["leaves"] as $leave)
		<tr style="text-align: center;font-size: 12px; color: #555555;">
			<td style="text-align: left; " > {{ $leave->leave_type }} </td>
			<td>
			<div class="row-fluid">
			<div class="col-lg-10" style="text-align: center;width: 70%;margin-left: 15px;">
			<span> {{ round($data['controller']::getBleaves($leave->id,$leave->leave_number), 2) }} </span>
			</div>
			<div>
			<a><i class="fa fa-hand-o-left" aria-hidden="true"></i></a>
			</div>
			</div>
			</td>
			<td>0 </td>
			<td>0 </td>
			<td>{{ date('d-M-Y',strtotime($leave->updated_at)) }} </td>
			<td>{{ round($leave->leave_number - $data['controller']::getBleaves($leave->id,$leave->leave_number), 2) }} </td>
			<td>0 </td>
			<td>0 </td>
			<td>0 </td>
			<td>0 </td>
			<td>{{ round($data['controller']::getBleaves($leave->id,$leave->leave_number) + $leave->leave_number - $data['controller']::getBleaves($leave->id,$leave->leave_number), 2) }} </td>
		</tr>
	@endforeach
@endif	


</tbody>
</table>

						</div><!-- /.col-* --><br/>
					</div><!-- /.row -->
                    </div>
                   <br/>
				</div><!-- /.tab-pane -->

				<div role="tabpanel" class="tab-pane" id="company">
					<div class="row">
						<div class="col-sm-6">
							<div class="form-group">
								<label for="form-register-company-username">Document</label>
								<select class="form-control" name="letter_type" required="">
                                <option value="">--Select Letter--</option>
                                <option>Letter</option>
                                </select>
							</div><!-- /.form-group -->

							<div class="form-group">
								<label for="form-register-company-email">Period</label>
								<select class="form-control" name="letter_year" required="">
                                <option value="">--Select Year--</option>
                                <option value="2011">2011</option>
                                <option value="2012">2012</option>
                                <option value="2013">2013</option>
                                <option value="2014">2014</option>
                                <option value="2015">2015</option>
                                <option value="2016">2016</option>
                                <option value="2017">2017</option>
                                <option value="2018">2018</option>
                                <option value="2019">2019</option>
                                <option value="2020">2020</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                                <option value="2026">2026</option>
                                <option value="2027">2027</option>
                                <option value="2028">2028</option>
                                <option value="2029">2029</option>
                                <option value="2030">2030</option>
                                <option value="2031">2031</option>
                                <option value="2032">2032</option>
                                <option value="2033">2033</option>
                                <option value="2034">2034</option>
                                <option value="2035">2035</option>
                                <option value="2036">2036</option>
                                </select>
							</div><!-- /.form-group -->

							
						</div><!-- /.col-* -->
					</div><!-- /.row -->

					
						
<br/>
						<button type="submit" class="btn btn-secondary">Submit</button>
                        <br/><br/>
                   
					</div><!-- /.center -->
                    
				
                
                
                				
                
                <span class="col-md-9" style="font-style: italic; font-size: 12px; color: #555555;">
<b>Note:</b>
Opening balance is the balance carried forward from previous credit cycle.
<br>
To view previous credits click on  
<a><i class="fa fa-hand-o-left" aria-hidden="true"></i></a>
</span>
                
                
			</div><!-- /.tab-content -->
            
		</div><!-- /.col-* -->
	</div><!-- /.row -->
</div><!-- /.container -->

        </div><!-- /.main -->
    </div><!-- /.main-wrapper -->
@include('templates/footer')
@endsection
	
	