@extends('layouts.app')
@section('content')
 <div class="main-wrapper">
        <div class="main">
		 <!-- Sidebar  -->
	 
	 <div id="wrapper">
	  <div class="overlay"></div>
    
 
		
        
	
	  <!-- Page Content -->
       
            <button type="button" class="hamburger is-closed" data-toggle="offcanvas">
                <span class="hamb-top"></span>
    			<span class="hamb-middle"></span>
				<span class="hamb-bottom"></span>
            </button>
	</div>
	
	<!-- /#sidebar-wrapper -->
            <div class="document-title">
                <div class="container">
                    <h1 class="center">Apply for Leave</h1>
                </div><!-- /.container -->
				<section class="seccess">
					@if(Session::has('flash_message'))
						<div class="alert alert-success"><em> {!! session::get('flash_message') !!}</em></div>
					@endif
				</section>
            </div><!-- /.document-title -->
			
<div class="document-breadcrumb">
<div class="container">
<ul class="breadcrumb">
<li>
<a href="{{ route('home') }}">Home</a>
</li>
<li>Latest Updates</li>
</ul>
</div>
</div>
            <div class="container">
	<div class="row">
    
		<div class="col-sm-12">
		<div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Leaves Menu
			</div>
			<div class="box-content">
			<ul>
			<li>
			<a class="side-menu-main-active" href="{{ route('leaves') }}"> Leaves Request</a>
			</li>
			<li>
			<a class="" href="{{ route('leaves',array('action' => 'apply-leaves')) }}"> Apply For Leaves</a>
			</li>
			
			</ul>
			</div>
			</div>
			</div>
		</div>
		</div>
				<div class="col-md-4">
                <div id="levBalId" class="row content-main-row ">
<div id="leaveBalanceRow" class="col-xs-* col-md-12 col-lg-12 padding-zero leave-balance-row">
<div class="row balance-childrow">
<div class="col-xs-* col-md-12 col-lg-12" style="padding-top:5px;padding-bottom:5px;padding-left:7px;padding-right:7px;">
<div class="leave-balance-header text-left" translate="">
<span class="ng-scope">Available Leave Balance:</span>
</div>
</div>
</div>
<div class="row balance-childrow text-left">
@if($data["pallLeaves"])
	@foreach($data["pallLeaves"] as $key=>$value)
		<span class="col-xs-3 col-sm-6 col-md-6 col-lg-3 ng-scope" style="padding-right:0px;padding-left:7px;">
		<span  style="cursor:default;" data-toggle="tooltip" title="">{{ $key }}</span>
		<span class="balance-name">:</span>
		<span class="balance-count ng-binding" data-ng-bind="typeBal.posted" translate="">{{ round($value, 2) }}</span>
		</span>
	@endforeach	
@endif	


</div>
</div>
</div>
<div id='calendar'></div>
<table class="holiday-detail">
<tbody>
<tr>
<td>
<span style="border-bottom: 3px solid #46dbc6;"></span>
Holiday
</td>
<td>
<span style="border-bottom: 3px solid #f0c000;"></span>
Planned Leave
</td>
<td>
<span style="border-bottom: 3px solid #9EA9B5;"></span>
Weekend
</td>
<td>
<span style="border-bottom: 3px solid #8cb61d;"></span>
Approved Leave
</td>
<td>
<span style="border-bottom: 3px solid #5435ae;"></span>
Flexi Holiday
</td>
<td>
<span style="border-bottom: 3px solid #f37735;"></span>
Pending Leave
</td>
</tr>
</tbody>
</table>
</div>
<div class="col-md-5">
<form method="post" action="{{ route('leaves',array('action' => 'postApply')) }}">
	{{ csrf_field() }}

<div class="form-group">
<label for="">Start Date</label>
<input id="start_date" class="form-control" required name="start_date" type="date">
</div>
<div class="form-group">
<label for="">End Date</label>
<input id="end_date" class="form-control" required name="end_date" type="date" >
</div>
<div class="form-group">
<label for="">Leave Type</label>
<select id="leave_type_select" class="form-control" name="leave_type">
@if($data["leaves"])
	@foreach($data["leaves"] as $leave)
		<option value="{{ $leave->id }}">{{ $leave->leave_type }}</option>
	@endforeach
@endif	
</select>
</div>
<div class="form-group">
<label for="">No of days</label>
<input id="no_of_days" class="form-control" name="days" type="number" required>
</div>
<div class="form-group">
<label>Detailed Reason</label>
<textarea class="form-control" rows="5" name="reason"></textarea>
</div>
<div class="form-group">
                        <label form="form-register-photo">Photo</label>
                        <input type="file" name="form-register-photo" id="form-register-photo">
                    </div><!-- /.form-group-->
<button class="btn btn-primary" type="submit">Submit</button>
</form>
</div>
</div>
		</div><!-- /.col-* -->
	</div><!-- /.row -->
</div><!-- /.container -->

        </div><!-- /.main -->
@include('templates/footer')
  <style>
	.holiday-detail td {
    float: left;
    width: 50%;
	padding:10px;
}
	.holiday-detail td span {
    float: right;
    height: 10px;
    margin-left: 12px;
    padding: 0;
    width: 20px;
}

.nav.header-actions li {
    margin: 0;
    padding:0;
}
.nav.header-actions li a {
    border: 1px solid rgba(0, 0, 0, 0);
    
    margin: 14px 0;
    padding: 0 5px;
}
.dropdown-menu {
    margin: 2px 28px 0;
    padding: 5px;
}
.navbar-toggle { top:40px;}
.nav.header-actions li {
    display: block;
    float: none;
}

.nav.header-actions li a {
    background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
    
}
.badge {background-color: red; color:#FFF;}
.nav .open > a, .nav .open > a:hover, .nav .open > a:focus {
    background-color: transparent;
    border-color: rgb(51, 122, 183);
}
.dropdown-menu li a{color: rgb(38, 38, 38);}
.dropdown-menu .divider {
    padding:0;
    margin:0;
}
.nav > li > a {
    padding: 10px 7px;
}

  
	</style>
{!!  Html::style('frontassets/fonts/profession/apply_leave.css') !!}
{!!  Html::script('frontassets/js/moment.min.js') !!} 
{!!  Html::script('frontassets/js/fullcalendar.min.js') !!} 
{!!  Html::style('frontassets/fonts/profession/apply_leave.css') !!}
{!!  Html::style('frontassets/css/fullcalendar.min.css') !!}
{!!  Html::style('frontassets/css/profession-blue-cyan.css') !!}

<script>

	$(document).ready(function() {
		
		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,basicWeek,basicDay'
			},
			defaultDate: '2016-09-12',
			navLinks: true, // can click day/week names to navigate views
			editable: true,
			eventLimit: true, // allow "more" link when too many events
			events: [
				{
					title: 'All Day Event',
					start: '2016-09-01'
				},
				{
					title: 'Long Event',
					start: '2016-09-07',
					end: '2016-09-10'
				},
				{
					id: 999,
					title: 'Repeating Event',
					start: '2016-09-09T16:00:00'
				},
				{
					id: 999,
					title: 'Repeating Event',
					start: '2016-09-16T16:00:00'
				},
				{
					title: 'Conference',
					start: '2016-09-11',
					end: '2016-09-13'
				},
				{
					title: 'Meeting',
					start: '2016-09-12T10:30:00',
					end: '2016-09-12T12:30:00'
				},
				{
					title: 'Lunch',
					start: '2016-09-12T12:00:00'
				},
				{
					title: 'Meeting',
					start: '2016-09-12T14:30:00'
				},
				{
					title: 'Happy Hour',
					start: '2016-09-12T17:30:00'
				},
				{
					title: 'Dinner',
					start: '2016-09-12T20:00:00'
				},
				{
					title: 'Birthday Party',
					start: '2016-09-13T07:00:00'
				},
				{
					title: 'Click for Google',
					url: 'http://google.com/',
					start: '2016-09-28'
				}
			]
		});
		
	});
$(function(){
	$("#start_date").datepicker();
	$("#end_date").datepicker();
});
</script>

@endsection
	
	