@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Edit Bank Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Edit Bank Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
		  
		  <form method="post" action="{{ route('employee-services',array('action' => 'postupdateBank')) }}">
			  {{ csrf_field() }}
			  <div class="col-sm-12" style="border: 1px solid #ccc;">
					<p class="section_header col-md-4">Account type</p>
						<div class="col-md-8">
						<input class="input-block-level col-md-8" name="account_type" placeholder="Account Type" value="{{ $data['bank']->account_type }}" type="text" required>
						</div>
							<div class="clearfix"></div>
						<p class="section_header col-md-4">Account Nature</p>
						<div class="col-md-8">
						<input class="input-block-level col-md-8" name="nature" placeholder="Account Nature" value="{{ $data['bank']->nature }}" type="text" required>
						
						</div>
						<div class="clearfix"></div>
						<p class="section_header col-md-4">Account No.</p>
						<div class="col-md-8">
						<div class="clearfix"></div>
						<input class="input-block-level col-md-8" name="account_no" placeholder="Account Number" value="{{ $data['bank']->account_no }}" type="text" required>
						
						</div>
						<div class="clearfix"></div>
						<p class="section_header col-md-4">Primary Account/Salary Account</p>
						<div class="col-md-8">
							<?php 
								if($data['bank']->account_for == 1){
									$y = 'selected=selected';
									$n = '';
								}else{
									$n = 'selected=selected';
									$y = '';
								}
							?>
							<select name="account_for" required>
								<option value="">Please Select</option>
								<option value="1" {{$y}}>Yes</option>
								<option value="2" {{$n}}>No</option>
							</select>
						</div>
						
						<div class="clearfix"></div>
						<div class="col-md-3" style="float:right;">
							<input type="hidden" name="id" value="{{ $data['bank']->id}}" />
							<input class="btn btn-info col-md-8" name="submit" value="Submit" type="Submit" />
						</div>
						<div class="clearfix"></div>		
			  </div>
		  </form>
            

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
@endsection
	
	