@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Role Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Role Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
			 <div class="container">
				 <div class="row">
				  <div class="col-sm-12">
				   <h4><em><strong>Team Information   </strong></em></h4>   
					
					<div class="clearfix">
					</div>
					 <div style="margin-top:30px;">	
					 <h5><em><strong>No record(s) present. </strong></em></h5>   
					</div>

				  </div>
				  <!-- /.col-* --> 
				 </div>
			 </div>
        <!-- /.container -->
		</div>
      
	  </div></div>
      
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	