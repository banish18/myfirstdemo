@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Add Experience </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>
						<a href="{{ route('employee-services',array('ation' => 'work-experience')) }}">Work Experience</a>
					</li>
					<li>Add Experience </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
		  
		  <form method="post" action="{{ route('employee-services',array('action' => 'postupdateExperience')) }}">
			  {{ csrf_field() }}
		  <div class="col-sm-12" style="border: 1px solid #ccc;">
							
			
						
						<p class="section_header col-md-4">Company</p>
						<div class="col-md-8">
						<input class="input-block-level col-md-8" name="company" placeholder="Company" value="{{ $data['workExperience']->company }}" type="text" required>
						</div>
							<div class="clearfix"></div>
						<p class="section_header col-md-4">Work Nature</p>
						<div class="col-md-8">
						<input class="input-block-level col-md-8" name="work_nature" placeholder="Work Nature" value="{{ $data['workExperience']->work_nature }}" type="text" required>
						
						</div>
						<div class="clearfix"></div>
						
						<div class="clearfix"></div>
						<p class="section_header col-md-4">Position</p>
						<div class="col-md-8">
							<input class="input-block-level col-md-8" placeholder="Position" name="position" value="{{ $data['workExperience']->position }}" type="text" required>
						</div>
						<div class="clearfix"></div>
						<p class="section_header col-md-4">Joining Date</p>
						<div class="col-md-8">
						
							<input class="input-block-level col-md-8" placeholder="Joining Date" name="joining_date" id="jd" value="{{ $data['workExperience']->joining_date }}" type="text" required>
						</div>
						<div class="clearfix"></div>
						<p class="section_header col-md-4">Leaving Date</p>
						<div class="col-md-8">
						
							<input class="input-block-level col-md-8" placeholder="Leaving Date" name="leaving_date" id="ld" value="{{ $data['workExperience']->leaving_date }}" type="text" required>
						</div>
						<div class="clearfix"></div>
						<div class="col-md-3" style="float:right;">
							<input class="btn btn-info col-md-8" name="submit" value="Submit" type="Submit" />
						</div>
						<div class="clearfix"></div>
				 </div>
				 <input type="hidden" name="id" value="{{ $data['workExperience']->id }}" />
		  </form>
           
          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<script>
	$(function(){
		$("#jd").datepicker();
		$("#ld").datepicker();
	});
</script>
@endsection
	
	