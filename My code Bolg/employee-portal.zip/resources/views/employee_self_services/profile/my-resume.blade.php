@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Resume Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="{{ route('home') }}">Home</a>
					</li>
					<li>Resume Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
		  @if($data["resume"])
			  <iframe src="{{ asset('images/users/resume/'.$data['resume']->resume) }}" title="your_title" align="top" height="420" width="100%" frameborder="0" scrolling="auto" target="Message"></iframe> 
			 <div style="margin-top:30px;">		
				<a href="{{ asset('images/users/resume/'.$data['resume']->resume) }}" download class="btn btn-info">Download Active CV</a>
				
			  </div>
		  @else
			<h4><em><strong>No resume present. Please upload your resume.</strong></em></h4>  
		  @endif
		  	
		  <div class="clearfix">
		  </div>
		  <div style="margin-top:30px;">		
		  <form method="post" action="{{ route('employee-services',array('action' => 'postResume')) }}" enctype="multipart/form-data">
			  {{ csrf_field() }}
			<label>Upload Resume</label>
			<input type="file" name="upload_file" class="btn btn-info" required/>
			<br />
			<button type="submit"class="btn btn-info">Upload</button>
		  </form>	
		  </div>
		   </div><!-- /.col-* -->
		</div><!-- /.row -->
	</div><!-- /.container -->
		 
	  
    </div>
  </div>
  <!-- /.main --> 
  
 <div class="progess-bar"><img src="{{ asset('images/15-progress_bar.gif') }}"</div> 

@include('templates/footer')

<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	