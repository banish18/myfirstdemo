@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Bank Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Bank Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
            <table class="table-bordered"> 
			<thead>
			<tr>
			<th>Account Type</th>
			<th>Account Nature</th>
			<th>Account No.</th>
			<th>Primary Account/Salary Account</th>
			<th>Start Date</th>
			</tr>
			</thead>
			<tbody>
			@if(!$data['Empbank']->isEmpty())
				@foreach($data['Empbank'] as $bank)
					<tr>
					<td>{{ $bank->account_type }}</td>
					<td title="flat no.403,sohi towars,govind vihar">{{ $bank->nature }}</td>
					<td title="Govind Vihar">{{ $bank->account_no }}</td>
					<td>{{ $bank->account_for }}</td>
					<td>
					<a title="Edit" href="{{ route('employee-services',array('action' => 'updatebank','id' => $bank->id )) }}">
					<i class="icon-edit"></i>
					</a>
					<a href="{{ route('employee-services',array('action' => 'deletebank','id' => $bank->id )) }}" title="Delete Bank Details">
					<i class="icon-trash"> </i>
					</a>
					</td>
					</tr>
				@endforeach
			@else
				<tr>
				<td>No Records</td>
				</tr>	
			@endif	
			</tbody>
			</table>
			
			 <div style="margin-top:30px;">			
			<button class="btn btn-info">Verify Details</button>
			<a href="{{ route('employee-services',array('action' => 'addBankdetail')) }}" class="btn btn-info">Create Base</a>
			</div>

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	