@extends('layouts.app')
@section('content')
 <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1 class="center">My Profile</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="container">
	         <div class="row">
			 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
		      <div class="col-sm-9">
			  
			   <ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active">
					<a href="#personal" aria-controls="personal" role="tab" data-toggle="tab">
						<strong>My Details</strong>
						<span></span>
					</a>
				</li>

				<li role="presentation">
					<a href="#company" aria-controls="company" role="tab" data-toggle="tab">
						<strong>Family Details</strong>
						<span></span>
					</a>
				</li>
				<li role="presentation">
					<a href="#religion" aria-controls="religion" role="tab" data-toggle="tab">
						<strong>Religion and Caste Details</strong>
						<span></span>
					</a>
				</li>
				<li role="presentation">
					<a href="#emergency" aria-controls="religion" role="tab" data-toggle="tab">
						<strong>Emergency Contact Details</strong>
						<span></span>
					</a>
				</li>
			  </ul>
			  
			  

			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="personal">
					<div class="row">
						<div class="col-sm-12">
						<div class="col-sm-12" style="border:1px solid #ccc;">
						<table>
						<tbody>
						<tr><td><div class="page_details_header"><em><strong>Please fill current details (if any)</strong></em></div></td></tr>

						<tr>
						<th colspan="5">
						<div class="col-md-12 section_header">
						Basic Details
						</div>
						<th>
						</tr>
							<tr>
							<th style="padding-left:30px;">Employee Name :</th>
							<td>{{ $data["user"]->name }}</td>
							<th style="padding-left:30px;">Preferred Name :</th>
							<td>{{ $data["user"]->f_name.' '.$data["user"]->l_name }}</td>
							</tr>

							<tr>
							<th style="padding-left:30px;">Date of birth :</th>
							<td>{{ $data["user"]->dob }}</td>
							<th style="padding-left:30px;">Gender :</th>
							<td>{{ $data["user"]->sex }}</td>
							</tr>

							<tr>
							<th style="padding-left:30px;">Blood Group :</th>
							<td>{{ $data["user"]->blood_group }}</td>
							</tr>

							<tr>
							<th colspan="5">
							<div class="col-md-12 section_header">
							Marriage Details
							</div>
							</th>
							</tr>

							<tr>
							<th style="padding-left:30px;">Marital Status :</th>
							<td>{{ $data["emp-profile"]->marital_status }}</td>
							<th style="padding-left:30px;">Date of Marriage</th>
							<td>{{ $data["emp-profile"]->dom }}</td>
							</tr>


							<tr>
							<th style="padding-left:30px;">Nationality :</th>
							<td>{{ $data["user"]->nationality }}</td>
							</tr>

							<tr>
							<th colspan="5">
							<div class="col-md-12 section_header">
							Communication Details
							</div>
							</th>
							</tr>


							<tr>
							<th style="padding-left:30px;">Mobile Number :</th>
							<td>{{ $data["user"]->phone_number }}</td>
							<th style="padding-left:30px;">MST Mail</th>
							<td>{{ $data["user"]->email }}</td>
							</tr>

							<tr>
							<th colspan="5">
							<div class="col-md-12 section_header">
							Disability Details
							</div>
							</th>
							</tr>


							<tr>
							<tr><td style="padding-left:30px;">
							
							@if($data["emp-profile"]->disability_details == "")
								No Record(s) present.
							@else
								$data["emp-profile"]->disability_details
							@endif	
							
							</td> </tr>

							</tbody>
							</table>
                             
							 <div class="row">
								<div class="col-md-12">
								<button class="btn btn-info mb40" style="margin:30px 0 0 20px;">Verify Details</button>
								</div>

											</div>

									</div>				
									
															</div><!-- /.form-group-->
															
														</div><!-- /.col-* -->
														
												
				</div><!-- /.row -->

                   
                  

				<div role="tabpanel" class="tab-pane" id="company">
						<div class="col-sm-12" style="border: 1px solid #ccc;">
							
						<div class="page_details_header" style="margin-top:20px;"><em><strong>Family details as present in our record(s)</strong></em>
		               
						</div>
                         
						 <p>Please go to My Profile > My Contacts to edit family details.</p>
						
						
						
						<p class="section_header">Father's Name</p>
						<div class="col-md-4">
						<input class="input-block-level" placeholder="First Name" readonly="readonly" type="text" value="{{ $data['emp-profile']->father_fname }}">
						</div>
						<div class="col-md-4">
						<input class="input-block-level" placeholder="Middle Name" readonly="readonly" type="text" value="{{ $data['emp-profile']->father_mname }}">
						</div>
						<div class="col-md-4">
						<input class="input-block-level" placeholder="Last Name" readonly="readonly" type="text" value="{{ $data['emp-profile']->father_mname }}">
						</div>
						<div class="clearfix"></div>
						<p class="section_header">Mother's Name</p>
						<div class="col-md-4">
						<input class="input-block-level" placeholder="First Name" readonly="readonly" type="text" value="{{ $data['emp-profile']->mother_fname }}">
						</div>
						<div class="col-md-4">
						<input class="input-block-level" placeholder="Middle Name" readonly="readonly" type="text" value="{{ $data['emp-profile']->father_mname }}">
						</div>
						<div class="col-md-4">
						<input class="input-block-level" placeholder="Last Name" readonly="readonly" type="text" value="{{ $data['emp-profile']->father_lname }}">
						</div>
						<div class="clearfix"></div>
						<p class="section_header">Spouse Name</p>
						<div class="col-md-4">
						<input class="input-block-level" placeholder="First Name" readonly="readonly" type="text" value="{{ $data['emp-profile']->spouse_fname }}">
						</div>
						<div class="col-md-4">
						<input class="input-block-level" placeholder="Middle Name" readonly="readonly" type="text" value="{{ $data['emp-profile']->spouse_mname }}">
						</div>
						<div class="col-md-4">
						<input class="input-block-level" placeholder="Last Name" readonly="readonly" type="text" value="{{ $data['emp-profile']->spouse_lname }}">
						</div>
						<div class="clearfix"></div>
						<p class="section_header">Children</p>
						<div class="col-md-4" style="margin:10px 0;"> 
						@if($data['emp-profile']->children == "")
							No Record(s) present.
						@else
						{{ $data['emp-profile']->children }}
						@endif	
						
					</div>
               
			
				
				
				 </div>
				</div>
				<div role="tabpanel" class="tab-pane" id="religion">
					   <div class="col-sm-12" style="border: 1px solid #ccc;">
							
						<div class="page_details_header" style="margin-top:20px;"><em><strong>Please view and update religion and caste details</strong></em>
		               
						</div>
					<form method="post" action="{{ route('employee-services',array('action' => 'saveEmployeeReligion')) }}">	
						{{ csrf_field() }}
                         	 
					<div class="col-lg-12">
							
						<div class="col-lg-2" style="margin:20px 0;">Religion</div>
							
						<div class="col-lg-4" style="margin:20px 0;">
						
							<input class="input-block-level" placeholder="Religion" type="text" value="{{ $data['user']->religion }}" name="religion">
						</div> 
						
						<div class="col-lg-6">
						
						</div>
						
					</div>
					
					
					<div class="col-lg-12">
					<div class="col-lg-2" style="margin:20px 0;">Caste</div>
					<div class="col-lg-4" style="margin:20px 0;">
					<input  class="input-block-level" type="text" name="caste" value="{{ $data['user']->caste }}">
					</div>
					<div class="col-lg-6">
					</div>
					</div>
					<div class="col-lg-12" style="margin:20px 15px;">
					<button class="btn btn-info">Refresh</button>
					<input type="submit" class="btn btn-info" value="Save" />
					
					</form>
					</div>
					</div>
					</div>
				
					<div role="tabpanel" class="tab-pane" id="emergency">
					   <div class="col-sm-12" style="border: 1px solid #ccc;">
							
					<form method="post" action="{{ route('employee-services',array('action' => 'saveEmployeeEmgdetail')) }}">	
						{{ csrf_field() }}
						<div class="page_details_header" style="margin-top:20px;"><em><strong>View Emergency Contact details</strong></em>
		               
						</div>
                         	
					 
						<div class="col-md-4" style="margin:10px 0;"> <textarea name="emergency_contact">{{ $data["emp-profile"]->emergency_contact }}</textarea>
					</div>
						
						<div class="col-lg-12" style="margin:20px 15px;">
					<button class="btn btn-info">Save Emergency details</button>
					
					
					
					</div> 
						</form>
					
                    
			 </div>
	        </div>
			</div>				
					
           </div><!-- /.row -->
	        </div><!-- /.row -->
	     </div><!-- /.container -->

        </div><!-- /.main -->
    </div><!-- /.main-wrapper -->

@include('templates/footer')
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	