@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Contact Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Bank Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
            <table class="table-bordered"> 
			<thead>
			<tr>
			<th>Name</th>
			<th>Relationship</th>
			<th>MST Employee flag</th>
			<th>Dependent flag</th>
			<th>Emergency flag</th>
			<th>Action</th>
			</tr>
			</thead>
			<tbody>
			@if(!$data['Empcontact']->isEmpty())
				@foreach($data['Empcontact'] as $contact)
					<tr>
					<td>{{ $contact->name }}</td>
					<td title="flat no.403,sohi towars,govind vihar">{{ $contact->relationship }}</td>
					<td title="Govind Vihar">{{ ($contact->mst_emp_flag == '1' ? 'Yes':'No') }}</td>
					<td>{{ ($contact->dependent_flag == 1 ? 'Yes':'No') }}</td>
					<td>{{ ($contact->emergency_flag == 1 ? 'Yes':'No') }}</td>
					<td>
					<a title="Edit" href="{{ route('employee-services',array('action' => 'updatecontact','id' => $contact->id )) }}">
					<i class="icon-edit"></i>
					</a>
					<a href="{{ route('employee-services',array('action' => 'deletecontact','id' => $contact->id )) }}" title="Delete Contact Details">
					<i class="icon-trash"> </i>
					</a>
					</td>
					</tr>
				@endforeach
			@else
				<tr>
				<td>No Records</td>
				</tr>	
			@endif	
			</tbody>
			</table>
			
			 <div style="margin-top:30px;">			
			<button class="btn btn-info">Verify Details</button>
			<a href="{{ route('employee-services',array('action' => 'addContactdetail')) }}" class="btn btn-info">Create Base</a>
			</div>

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	