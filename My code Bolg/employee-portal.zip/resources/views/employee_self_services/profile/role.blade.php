@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Role Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="{{ route('home') }}">Home</a>
					</li>
					<li>Role Details </li>
				</ul>
					@if(Session::has('success'))
			<section class="seccess">
					
						<div class="alert alert-success"><em> {!! session::get('success') !!}</em></div>
					
				</section>
@endif

			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
            
			
			 <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <ul class="nav nav-tabs" role="tablist">
              <li role="presentation" class="active"> <a href="#personal" aria-controls="personal" role="tab" data-toggle="tab"> <strong>My Role Details
               
                </strong> </a> </li>
              <li role="presentation"> <a href="#gratuity" aria-controls="gratuity" role="tab" data-toggle="tab"> <strong>Create/Change Aspirational Role
            
                </strong> </a> </li>
           
          
            </ul>
            <div class="tab-content">
              <div role="tabpanel" class="tab-pane active" id="personal">
                <div class="row">

                  <div class="col-lg-12" style="margin-top:5px;">
                    
                    <ul class="nav nav-tabs" role="tablist">
                      <li role="presentation"> <a href="#provident" aria-controls="provident" role="tab" data-toggle="tab"> <strong>History</strong> </a> </li>
                     
                    </ul>
                  </div>
                  <div class="tab-content">
                    <div role="tabpanel" class="tab-pane" id="provident">
                      <div class="col-sm-12">
                          <table class="table table-bordered" width="100%">
                          <thead>
							<tr>
							<th>WON/SWON</th>
							<th>Role</th>
							<th>Job</th>
							<th>Unit</th>
							<th>Work Area</th>
							<th>Base</th>
							<th>Primary</th>
							<th>Start Date</th>
							<th>End Date</th>
							<th></th>
							</tr>
							</thead>
							<tbody>
							
							
							<tr>
							<td>Unallocated</td>
							<td title="Developer">
							<a>{{ $data["user"]->designation }}</a>

							</td>
							<td class="ng-binding" ng-attr-title="" title="NGM India">{{ $data["user"]->company }}</td>
							<td>Yes</td>
							<td>Yes</td>
							<td>{{ $data["user"]->company }}</td>
							<td>06-Jan-2017</td>
							<td>
							<a title="End Date">
							</td>
							</tr>
							
							</tbody>
                        </table>
                      </div>
                    </div>
                    <div role="tabpanel" class="tab-pane active" id="epf">
                      <div class="col-sm-12">
                          <table class="table table-bordered" width="100%">
                          <thead>
							<tr>
							<th>WON/SWON</th>
							<th>Role</th>
							<th>Job</th>
							<th>Unit</th>
							<th>Work Area</th>
							<th>Base</th>
							<th>Primary</th>
							<th>Start Date</th>
							<th>End Date</th>
							<th></th>
							</tr>
							</thead>
							<tbody>
							
				
							<tr>
							<td>Unallocated</td>
							<td title="Developer">
							<a>{{ $data["user"]->designation }}</a>

							</td>
							<td class="ng-binding" ng-attr-title="" title="NGM India">{{ $data["user"]->company }}</td>
							<td>Yes</td>
							<td>Yes</td>
							<td>{{ $data["user"]->company }}</td>
							<td>06-Jan-2017</td>
							<td>
							<a title="End Date">
							</td>
							</tr>
							
							</tbody>
                        </table>
                      </div>
                    </div>
                    <div role="tabpanel" class="tab-pane" id="eps">
                      <div class="col-sm-12">
                       
                        <table class="table table-bordered">
                          <thead>
                            <tr>
                             
                            </tr>
                          </thead>
                          <tbody class="listBorderNomin">
                            <tr class="form-inline ng-scope" ng-repeat="details in empGFDetails">
                              
                              <td style="text-align: center;">No Record(s) present. </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    
                    <div role="tabpanel" class="tab-pane" id="view">
                      <div class="col-sm-12">
                        <table class="table table-bordered">
                          <thead>
                            <tr>
                             
                            </tr>
                          </thead>
                          <tbody class="listBorderNomin">
                            <tr class="form-inline ng-scope" ng-repeat="details in empGFDetails">
                              
                              <td style="text-align: center;">No Record(s) present. </td>
                            </tr>
                          </tbody>
                        </table>
                          
                      </div>
                    </div>
                    <div role="tabpanel" class="tab-pane" id="details">
                      <div class="col-sm-12">

                        
                        
                          <table class="table table-bordered" width="100%">
                          <thead>
							
							<tr>
							<td>Unallocated</td>
							<td title="Developer">
							<a>{{ $data["user"]->designation }}</a>

							</td>
							<td class="ng-binding" ng-attr-title="" title="NGM India">{{ $data["user"]->company }}</td>
							<td>Yes</td>
							<td>Yes</td>
							<td>{{ $data["user"]->company }}</td>
							<td>06-Jan-2017</td>
							<td>
							<a title="End Date">
							</td>
							</tr>
							
							</tbody>
                        </table>
                        
                      </div>
                    </div>  
                  </div> 
                </div>
              </div>
              <!-- /.tab-pane -->
              
              <div role="tabpanel" class="tab-pane" id="gratuity">
                <div class="row">
                  <div class="col-sm-12">
				  <form method="POST" action="{{ route('employee-services',array('action' => 'aspairationRequest')) }}">
					  {{ csrf_field() }}
                    <h4>Aspiration Role </h4>
				   <div class="col-sm-4">
					<div class="form-group">
					<label>Unit *</label>
					
					</div>
					
								
								<select class="form-control" name="doctype" style="height:35px;" name="unit">
                                 <option value="payslip">Payslip</option>
                                </select>
                               
					</div>
					
					<div class="col-sm-4">
					<div class="form-group">
					<label>Role *</label>
					
					</div>
					 <input type="text" class="form-control" name="role" placeholder="Role" />
					</div>
					
					
					<div class="col-sm-4">
					<div class="form-group">
					<label>Job</label>
					
					</div>
					 <input type="text" class="form-control" value="{{ $data['user']->	designation }}" disabled="disabled">
					</div>
					
					<div class="col-sm-4">
					<div class="form-group">
					<label>Work Area</label>
					
					</div>
					 <input type="text" class="form-control" value="{{ $data['user']->	designation }}" disabled="disabled">
					</div>
										
					
					
					
				<div class="clearfix">
					</div>
					<br/>
					<div class="col-sm-12">
						<button class="btn btn-secondary btn-small" type="submit">Save</button>
						
					</div>
					</form>
					</div>
					
					
                  </div>
                  <!-- /.col-* --> 
                  
                </div></div>
                <!-- /.row --> 
                 

 
               
              <!-- /.tab-pane -->    
            </div>
            <!-- /.tab-content --> 
            <br />
          </div>
          <!-- /.col-* --> 
        </div>

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	