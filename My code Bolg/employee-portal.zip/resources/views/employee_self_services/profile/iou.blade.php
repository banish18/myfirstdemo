@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - IOU Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="{{ route('home') }}">Home</a>
					</li>
					<li>IOU Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
          <div class="container mb40">
	         <div class="row">
		      <div class="col-sm-12">
			  <table class="table-bordered">
			  <tbody>
			  <tr>
			  <th>Employee Name :</th>
			   <td>MR. {{ $data['user']->f_name.' '.$data['user']->l_name }}</td>
			    <th>Employee Number: </th>
			   <td>{{ $data['user']->uuid }}</td>
			  </tr>
			   <tr>
			  <th>Designation :</th>
			   <td>{{ $data['user']->designation }}</td>
			   <th>Email Id :</th>
			   <td>{{ $data['user']->email }}</td>
			  </tr>
			   <tr>
			  <th>Date of Joining :</th>
			   <td>{{ $data['user']->doj }}</td>
			   <th>Date of Birth :</th>
			   <td>{{ $data['user']->dob }}</td>
			  </tr>
			   <tr>
			  <th>Employee Status :</th>
			   <td>Active Assignment</td>
			   <th>Person Type :</th>
			   <td>Employee</td>
			  </tr>
			  <tr>
			  <th>Gender :</th>
			   <td>{{ $data['user']->sex }}</td>
			   <th>Employee Category :</th>
			   <td>Confirmed</td>
			  </tr>
			   <tr>
			  <th>Blood Group :</th>
			   <td>{{ $data['user']->blood_group }}</td>
			  </tr>
			   </tbody>
			  </table>
			  </div>
		     </div>
		   </div>
			
			
			
            <div class="container">
	         <div class="row">
		      <div class="col-sm-12">
			   <ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active">
					<a href="#personal" aria-controls="personal" role="tab" data-toggle="tab">
						<strong>Basic Details</strong>
						<span></span>
					</a>
				</li>

				<li role="presentation">
					<a href="#company" aria-controls="company" role="tab" data-toggle="tab">
						<strong>Organization & IOU Details</strong>
						<span></span>
					</a>
				</li>
				<li role="presentation">
					<a href="#religion" aria-controls="religion" role="tab" data-toggle="tab">
						<strong>Workflow Approvers - Supervisor & HR</strong>
						<span></span>
					</a>
				</li>
				<li role="presentation">
					<a href="#emergency" aria-controls="religion" role="tab" data-toggle="tab">
						<strong>     Workflow Approvers - Others</strong>
						<span></span>
					</a>
				</li>
			  </ul>
			  
			  

			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="personal">
					<div class="row">
						<div class="col-sm-12">
						<div class="col-sm-12" style="border:1px solid #ccc;">
						<table>
						<tbody>
						
							@if($data['Empaddress'])
								@foreach($data['Empaddress'] as $empAdd)
									<tr>
									<th style="padding-left:30px;">{{ $empAdd->address_type }}:</th>
									<td>{{ $empAdd->address_line1.','.$empAdd->address_line2.','.$empAdd->country }}</td>
									</tr>
								@endforeach
							@endif	

							<tr>
							<th style="padding-left:30px;">Contact no.1 :</th>
							<td>{{ $data['user']->phone_number }}</td>
							</tr>
							
							<tr>
							<th style="padding-left:30px;">Contact no.2 :</th>
							<td>{{ $data['user']->e_contact1 }}</td>
							</tr>
							
							<tr>
							<th style="padding-left:30px;">Previous Relevant Experience :</th>
							<td>3.19 year(s)</td>
							</tr>
							
							<tr>
							<th style="padding-left:30px;">TCS Experience :</th>
							<td>5.91 year(s)</td>
							</tr>

					
							</tbody>
							</table>
                             
							 

									</div>				
									
															</div><!-- /.form-group-->
															
														</div><!-- /.col-* -->
														
												
				</div><!-- /.row -->

                   
                  

			<div role="tabpanel" class="tab-pane" id="company">
			<table class="table-bordered">
			<tbody>
				<tr>
					<div class="col-lg-3">
						<th>Base Delivery Center :</th>
					</div>
					<div class="col-lg-3">			
						<td>New Delhi - Non STP</td>
					</div>
					<div class="col-lg-3">
						<th>Base Branch :</th>
					</div>
					<div class="col-lg-3">
						<td>TCS - New Delhi</td>
					</div>
				</tr>
				<tr>
					<div class="col-lg-3">
						<th>Base IOU  :</th>
					</div>
					<div class="col-lg-3">			
						<td>NGM-India1.4-Group4</td>
					</div>
					<div class="col-lg-3">
						<th>Parent Base IOU :</th>
					</div>
					<div class="col-lg-3">
						<td>NGM-India1-Parent</td>
					</div>
				</tr>
				<tr>
					<div class="col-lg-3">
						<th>Customer :</th>
					</div>
					<div class="col-lg-3">			
						<td>Not Available</td>
					</div>
					<div class="col-lg-3">
						<th>Employee Location :</th>
					</div>
					<div class="col-lg-3">
						<td>CHANDIGARH</td>
					</div>
				</tr>
				<tr>
					<div class="col-lg-3">
						<th>Depute Delivery Center :</th>
					</div>
					<div class="col-lg-3">			
						<td>Chandigarh - Non STP</td>
					</div>
					<div class="col-lg-3">
						<th>Depute Branch :</th>
					</div>
					<div class="col-lg-3">
						<td>TCS - New Delhi</td>
					</div>
				</tr>
				<tr>
					<div class="col-lg-3">
						<th>Depute IOU  :</th>
					</div>
					<div class="col-lg-3">			
						<td>NGM-India1.4-Group4</td>
					</div>
					<div class="col-lg-3">
						<th>Parent Depute IOU :</th>
					</div>
					<div class="col-lg-3">
						<td>NGM-India1-Parent</td>
					</div>
				</tr>
				</tbody>
			  </table>
			</div>		
			
				
				<div role="tabpanel" class="tab-pane" id="religion">
					   <div class="col-sm-12" style="border: 1px solid #ccc;">
							
						<table>
						<tbody>

							<tr>
							<th style="padding-left:30px;">Supervisor Level 1 :</th>
							<td>MS. PRIYANKA GARG (1196792) </td>
							</tr>

							<tr>
							<th style="padding-left:30px;">Supervisor Level 2 :</th>
							<td>MR. SHAILENDRA MOHAN (104212) </td>
							
							</tr>

							<tr>
							<th style="padding-left:30px;">Base IOU HR Head :</th>
							<td>MR. RAJAT BHATTACHARYA (170631)</td>
							</tr>
							
							<tr>
							<th style="padding-left:30px;">HR Clearance Officer :</th>
							<td>MR. DILEEP KUMAR (239656), MS. KUMKUM TIWARI (189280), MS. GEETA LINGWAL (108442), MS. DEEPIKA SHARMA (1032651), MR. ANIL SEMWAL (171175)</td>
							</tr>
							
							<tr>
							<th style="padding-left:30px;">Exit interview Process :</th>
							<td>MR. KAPIL KUMAR (864748)</td>
							</tr>
							
							<tr>
							<th style="padding-left:30px;">Grievance Process :</th>
							<td>MR. KAPIL KUMAR (864748)</td>
							</tr>
							
							<tr>
							<th style="padding-left:30px;">Leave :</th>
							<td>MR. KAPIL KUMAR (864748)</td>
							</tr>
							
							<tr>
							<th style="padding-left:30px;">Confirmation :</th>
							<td>MR. KAPIL KUMAR (864748)</td>
							</tr>
							</tbody>
							</table>
                         	
						
						
						
						
					
					</div>
					
					</div>
					
					
					<div role="tabpanel" class="tab-pane" id="emergency">
					   <div class="col-sm-12" style="border: 1px solid #ccc;">
							
						<table>
						<tbody>

							<tr>
							<th style="padding-left:30px;">IDM :</th>
							<td>MS. ANAHITA SINGH (1065307),MR. SUNIL KUMAR JAIN (1100241)</td>
							</tr>

							<tr>
							<th style="padding-left:30px;">Administration :</th>
							<td>MR. GYANENDER SINGH (147779)</td>
							
							</tr>

							<tr>
							<th style="padding-left:30px;">Library :</th>
							<td>MR. MANISH RANJAN (160790),MS. DEEPALI MALIK (686876)</td>
							</tr>
							
							<tr>
							<th style="padding-left:30px;">Finance :</th>
							<td>MS. SUMAN BHAGAT (13536)</td>
							</tr>
							
							<tr>
							<th style="padding-left:30px;">Local Ethics Counsellor :</th>
							<td>MR. TRYAMBAK MANGALAM (65013)</td>
							</tr>
							
							<tr>
							<th style="padding-left:30px;">Ethics Counsellor :</th>
							<td>MR. TRYAMBAK MANGALAM (65013)</td>
							</tr>
							</tbody>
							</table>
						</div>
						</div>	
						
					</div>	
                         	
					 
					
						
						
					
                    
							
					
           </div><!-- /.row -->
	        </div><!-- /.row -->
	     </div><!-- /.container -->

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	