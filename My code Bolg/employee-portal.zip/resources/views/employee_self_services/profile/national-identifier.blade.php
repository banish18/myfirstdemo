@extends('layouts.app')
@section('content')
<div class="main-wrapper">
	<div class="main">
		<div class="document-title">
			<div class="container">
			<h1 class="center">Employee - National Identifier </h1>
			</div>
			<!-- /.container --> 
		</div>
		<!-- /.document-title -->
		<div class="document-breadcrumb">
			<div class="container">
			<ul class="breadcrumb">
			<li>
			<a href="{{ route('home') }}">Home</a>
			</li>
			<li>National Identifier</li>
			</ul>
			</div>
		</div>
		<div class="container mb40">
			<div class="row">
				<div class="col-md-3">
					<div class="row">
						<div class="col-lg-12 project-menu">
							<div class="box-sidebar side-menu-main project-menu">
								<div class="box-head-dark">
									<i class="fa fa-bars"></i>
									Profile Menu
								</div>
								<div class="box-content">
									@include("employee_self_services/profile/sidebar")
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-9">
				<form method="post" action="{{ route('employee-services',array('action' => 'postupdateNational')) }}">
					{{ csrf_field() }}
					<div class="col-lg-12">
						<h4><em><strong>National Identifier </strong></em></h4>   
					</div>

					<div class="col-lg-4"> 
						<div class="well">
						<h4><em><strong>India</em></strong></h4>
						<div>Other Locations</div>
						<input type="text" name="national_identifier" value="{{ $data['user']->nationality }}">
						</div>
					</div>
					<div class="col-lg-8">
						<h3 style="margin:0;padding:0;"><em><strong>India</strong></em></h3>
						<h4>National Identifier</h4>
						<div class="span4 ng-binding">Aadhar Number :   <input type="text" name="adhar_number" value="{{ $data['emp-profile']->adhar_number }}" /></div>
						<div class="span4 ng-binding">Enrollment ID :  <input type="text" name="enrollment_id" value="{{ $data['emp-profile']->enrollment_id }}" /></div>
						<h4>Identification Details </i></h4>
						<div class="span4 ng-binding">PAN Number :  <input type="text" name="pannumber" value="{{ $data['emp-profile']->pan_number }}" /></div>
						<div class="span4 ng-binding">NPR :  <input type="text" name="npr" value="{{ $data['emp-profile']->npr }}" /></div>
						
						
					</div>
					</form>
				</div><!-- /.col-* -->
			</div><!-- /.row -->
		</div><!-- /.container --> 
	</div>
</div>
<!-- /.main --> 

@include('templates/footer')
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	