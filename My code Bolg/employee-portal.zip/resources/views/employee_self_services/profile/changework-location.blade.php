@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Change Work Location </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Change Work Location </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
            
      
      <div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
		  <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;">Employee Profile</div>
            <table class="table-bordered">     
			<tbody>
			<tr>	
			<th>Employee Type</th>
			<td>{{ $data['user']->emp_type }}</td>
			<th>Email ID</th>
			<td>{{ $data['user']->email }}</td>
			<th>Base Country</th>
			<td>{{ $data['user']->country }}</td>
			</tr>
			<tr>
			<th>Employment Status</th>
			<td>{{ $data['user']->emp_type }}</td>
			<th>Visa Type</th>
			<td></td>
			<th>Depute Branch</th>
			<td>MST - Chandigarh</td>
			</tr>
			<tr>
			<th>Service Type</th>
			<td>{{ $data['user']->emp_type }}</td>
			<th>Base Branch</th>
			<td>MST - Chandigarh</td>
			<th>Depute DC</th>
			<td>Chandigarh - Non STP</td>
			</tr>
			<tr>
			<th>Role</th>
			<td>{{ $data['user']->e_department }}</td>
			<th>Base DC</th>
			<td></td>
			<th>Depute Country</th>
			<td>{{ $data['user']->country }}</td>
			</tr>
			</tbody>
			</table>
			
		
		

          </div>
          <!-- /.col-* --> 
		  
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	   <div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
		  <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;">Allocation Details</div>
            <table class="table-bordered">     
		   <thead>
			<tr>
			<th>Project No.</th>
			<th>Project Name</th>
			<th>Allocation Start Date</th>
			<th>Allocation End Date	</th>
			<th>Customer Name</th>
			<th>City</th>
			<th>Country</th>
			</tr>
			
		   </thead>
			<tbody>
			<tr>
			<td>2663814	</td>
			<td>BSNL CDR 1 SE AMC Service</td>
			<td>Jan 1, 2017</td>
			<td>Mar 31, 2017</td>
			<td>HCL INFOTECH LTD.</td>
			<td>HYDERABAD, INDIA</td>
			<td>India</td>
			</tr>
			</tbody>
			</table>
		   </div>
          <!-- /.col-* --> 
		  
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
	  
	  <div class="container mb40">
        <div class="row">
          <div class="col-sm-12">
			  <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;">Current Work Location Details</div>
				<table class="table-bordered">     
			   <thead>
				<tr>
				<th>Country</th>
				<th>Branch</th>
				<th>DC</th>
				<th>Location</th>
				</tr>
				
			   </thead>
				<tbody>
				<tr>
				<td>INDIA</td>
				<td>TCS - NEW DELHI</td>
				<td>CHANDIGARH - NON STP</td>
				<td>CHANDIGARH</td>
				</tr>
				</tbody>
				</table>
				
				 <div style="margin-top:30px;">			
			  <button class="btn btn-info">Update</button>
			 </div>
			 
			   </div>
			  <!-- /.col-* --> 
			  
			</div>
			<!-- /.row --> 
		  </div>
		  <!-- /.container -->

          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	