@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Add Qualification Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Add Qualification Details</li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
		  
		  <form method="post" action="{{ route('employee-services',array('action' => 'postQualification')) }}">
			  {{ csrf_field() }}
		  <div class="col-sm-12" style="border: 1px solid #ccc;">
						<p class="section_header col-md-4">Type</p>
						<div class="col-md-8">
						<input class="input-block-level col-md-8" name="type" placeholder="Type" value="" type="text" required>
						</div>
							<div class="clearfix"></div>
						<p class="section_header col-md-4">Institute</p>
						<div class="col-md-8">
						<input class="input-block-level col-md-8" name="institute" placeholder="Institute" value="" type="text" required>
						</div>
						<div class="clearfix"></div>
						<p class="section_header col-md-4">Start date</p>
						<div class="col-md-8">
						<div class="clearfix"></div>
							<input class="input-block-level col-md-8" name="sdate" placeholder="Institute" id="sdate" value="" type="text" required>
						</div>
						
						<div class="clearfix"></div>
						<p class="section_header col-md-4">End date</p>
						<div class="col-md-8">
						<div class="clearfix"></div>
							<input class="input-block-level col-md-8" name="edate" placeholder="Institute" id="edate" value="" type="text" required>
						</div>
						<div class="clearfix"></div>
						<div class="col-md-3" style="float:right;">
							<input class="btn btn-info col-md-8" name="submit" value="Submit" type="Submit" />
						</div>
						<div class="clearfix"></div>
				 </div>
		  </form>
           
          </div>
          <!-- /.col-* --> 
        </div>
        <!-- /.row --> 
      </div>
      <!-- /.container -->
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<script>
	$(function(){
		$("#sdate").datepicker();
		$("#edate").datepicker();
	});
</script>
@endsection
	
	