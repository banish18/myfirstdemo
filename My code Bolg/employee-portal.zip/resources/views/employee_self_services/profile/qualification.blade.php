@extends('layouts.app')

@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Language Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Language Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
            <table class="table-bordered">
              <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;">Qualification Details </div>         
<thead>
<tr>
<th>Type</th>
<th>Institute</th>
<th>Start date</th>
<th>End date</th>
<th></th>
</tr>
</thead>
<tbody>
@if($data["EmpQualification"])
	@foreach($data["EmpQualification"] as $qualification)
		<tr class="ng-scope" ng-class="{info : preview.record_type_flag == 'WORKLIST', warning : preview.record_type_flag == 'REJECTED'}" ng-repeat="preview in infocard_preview_list">
		<td class="ng-binding" ng-attr-title="" title="BACHELOR OF SCIENCE">{{ $qualification->type }}</td>
		<td class="ng-binding" ng-attr-title="" title="Others">{{ $qualification->institute }}</td>
		<td class="ng-binding">{{ date('M,Y d',strtotime($qualification->start_date)) }}</td>
		<td class="ng-binding">{{ date('M,Y d',strtotime($qualification->end_date)) }}</td>
		<td>
		<a class="no-navigation" title="Edit">
		<i class="icon-edit"></i>
		</a>
		<a class="ng-hide" no-navigation=""  title="Worklist Details">
		<i class="icon-bullhorn"></i>
		</a>
		<a class="ng-hide" no-navigation="" title="Rejected history">
		<i class="icon-time"></i>
		</a>
		</td>
		</tr>
	@endforeach
@endif	

</tbody>
</table>



<div class="row-fluid">
<ul class="infocard_legend">
<li>
<span class="worklist"></span>
Pending in Worklist
</li>
<li>
<span class="rejected"></span>
Rejected
</li>
</ul>
</div>


<div class="clearfix">
<p style="font-weight:bold;font-size:12px;color:#888;clear:both;">Note :- Rejected record(s) will be system deleted after 10 days from the date of rejection. </p>
</div>



			
 <div style="margin-top:30px;">			
<button class="btn btn-info">Verify Details</button>
<a href="{{ route('employee-services',array('action' => 'add-qualification')) }}" class="btn btn-info">Create Base</a>
</div>

          </div>
          <!-- /.col-* --> 
        </div>

				<!-- /.row -->
      </div>
      <!-- /.container -->
      
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<style>
ul, li {
    border: 0 none;
    list-style: outside none none;
    margin: 0;
    padding: 0;
}
.infocard_legend li {
    float: left;
    margin-right: 15px;
}

.infocard_legend .worklist {
    background-color: #d9edf7;
}
.infocard_legend li span {
    border: 1px solid #ccc;
    float: left;
    height: 15px;
    margin: 2px 5px 2px 2px;
    width: 16px;
}

</style>
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	