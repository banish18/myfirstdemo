@extends('layouts.app')
@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - Address Details </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>Address Details </li>
				</ul>
			</div>
		</div>
	  
      
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Profile Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/profile/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
          <div class="container mb40">
        <div class="row">
          <div class="col-sm-11">
            <table class="table-bordered">
              <div class="col-sm-12" style="border:1px solid #CCC; padding:4px;">Work Experience</div>         
				
<thead>
<tr>
<th>Company</th>
<th>Work Nature</th>
<th>Position</th>
<th>Joining Date</th>
<th>Leaving Date</th>
<th></th>
</tr>
</thead>
<tbody>
@if(!$data["workExperience"]->isEmpty())
	@foreach($data["workExperience"] as $workExperience)
		<tr class="ng-scope">
			<td class="ng-binding" ng-attr-title="" title="telecom software corp. ltd.">{{ $workExperience->company }}</td>
			<td class="ng-binding" ng-attr-title="" title="oracle 9i">{{ $workExperience->work_nature }}</td>
			<td class="ng-binding" ng-attr-title="" title="DBA">{{ $workExperience->position }}</td>
			<td class="ng-binding">{{ $workExperience->joining_date }}</td>
			<td class="ng-binding">{{ $workExperience->leaving_date }}</td>
			<td>
			<a class="" href="{{ route('employee-services',array('action' => 'edit_workexperince','id' => $workExperience->id )) }}" title="Edit">
			<i class="icon-edit"></i>
			</a>
			<a class="ng-hide"  title="Worklist Details">
			<i class="icon-bullhorn"></i>
			</a>
			<a class="ng-hide"  href="{{ route('employee-services',array('action' => 'deleteWorkexperince','id' => $workExperience->id )) }}" title="Delete history">
			<i class="icon-trash"></i>
			</a>
			</td>
		</tr>
	@endforeach
@else
	<tr class="ng-scope"><td>No Records</td></tr>
@endif	
</tbody>
</table>
</div>
</div>



			
 <div style="margin-top:30px;">			
<a href="{{ route('employee-services',array('action' => 'add-experience')) }}" class="btn btn-info">Create</a>
</div>

          </div>
          <!-- /.col-* --> 
			 
		   </div><!-- /.col-* -->
		</div><!-- /.row -->
	</div><!-- /.container -->
		 
	  
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<style>
ul, li {
    border: 0 none;
    list-style: outside none none;
    margin: 0;
    padding: 0;
}
.infocard_legend li {
    float: left;
    margin-right: 15px;
}

.infocard_legend .worklist {
    background-color: #d9edf7;
}
.infocard_legend li span {
    border: 1px solid #ccc;
    float: left;
    height: 15px;
    margin: 2px 5px 2px 2px;
    width: 16px;
}

</style>
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	