@extends('layouts.app')

@section('content')
  <div class="main-wrapper">
    <div class="main">
	 
	
	
      <div class="document-title">
        <div class="container">
          <h1 class="center">Employee - My Request </h1>
        </div>
        <!-- /.container --> 
      </div>
      <!-- /.document-title -->
	  
	    <div class="document-breadcrumb">
		 	<div class="container">
				<ul class="breadcrumb">
					<li>
						<a href="/">Home</a>
					</li>
					<li>My Request</li>
				</ul>
			</div>
		</div>
      <div class="container mb40">
        <div class="row">
		 <div class="col-md-3">
			<div class="row">
			<div class="col-lg-12 project-menu">
			<div class="box-sidebar side-menu-main project-menu">
			<div class="box-head-dark">
			<i class="fa fa-bars"></i>
			Benifits-Taxes Menu
			</div>
			<div class="box-content">
			@include("employee_self_services/benifits-taxes/sidebar")
			</div>
			</div>
			</div>
		</div>
		</div>
          <div class="col-sm-9">
			<div class="col-sm-12">
				  <div class="col-lg-7">
					<h4>My Request List </h4>
				</div>
				<div class="col-lg-5 pull-right">
				<a id="requestList:myReqLstBodyForm:_idJsp100" class="LinksFont" href="#">< Previous</a>
		<input name="autoScroll" type="hidden">
		<select id="requestList:myReqLstBodyForm:selectedValue" class="dropDownStyle" name="requestList:myReqLstBodyForm:selectedValue" size="1" style="height:18px">
		<option value="0">No records found</option>
		</select>
		<button class="btn btn-primary" type="submit">Go</button>
		<a id="requestList:myReqLstBodyForm:_idJsp106" class="LinksFont" href="#" onclick="return oamSubmitForm('requestList:myReqLstBodyForm','requestList:myReqLstBodyForm:_idJsp106');">Next ></a>
				</div>
				<div class="clearfix"></div>
					<table  class="table-bordered">
					<button class="btn btn-primary" type="submit">Cancel Request</button>
					<button class="btn btn-primary" style="margin:10px 20px;" type="submit">Copy to New</button>
					<button class="btn btn-primary" style="margin:10px 20px;" type="submit">Delete Draft</button>
					<button class="btn btn-primary pull-right" style="margin:10px 0;" type="submit">Archive</button>
					<button class="btn btn-primary pull-right" style="margin:10px 20px;" type="submit">Filter</button>
					<button class="btn btn-primary pull-right" style="margin:10px 20px;" type="submit">Sort</button>
					<button class="btn btn-primary pull-right" style="margin:10px 20px;" type="submit">View Archived</button>
					
				
					   
						<tbody>
						<tr>
						<th class="reportsHeader">
						<input id="requestList:myReqLstBodyForm:table:AllCheckBox" name="requestList:myReqLstBodyForm:table:AllCheckBox" value="true" onclick="selectAll(this)" type="checkbox">
						</th>
						<th class="reportsHeader">Request Type</th>
						<th class="reportsHeader">Request No</th>
						<th class="reportsHeader">Leave Start Date</th>
						<th class="reportsHeader">Leave End Date</th>
						<th class="reportsHeader">Travel Start Date</th>
						<th class="reportsHeader">Travel End Date</th>
						<th class="reportsHeader">Amount</th>
						<th class="reportsHeader">Status</th>
						<th class="reportsHeader">Request Date</th>
						<th class="reportsHeader">Financial Year</th>
						</tr>
						<tr>
						<td></td>
						<td>Request Type</td>
						<td >Request No</td>
						<td>Leave Start Date</td>
						<td>Leave End Date</td>
						<td>Travel Start Date</td>
						<td>Travel End Date</td>
						<td>Amount</td>
						<td>Status</td>
						<td>Request Date</td>
						<td>Financial Year</td>
						</tr>
						</tbody>
						</table>
					</table>
					
					
					
					<table class="table-bordered">
					<tbody>
					<tr>
					<td>
					<span style="text-align: left">
					<a href="#"><i class="fa fa-plus" aria-hidden="true"></i>
					 Workflow Status </a>
					</span>
					</td>
					</tr>
					</tbody>
					</table>			
					
				  </div>
				  <!-- /.col-* --> 
          </div>
          <!-- /.col-* --> 
        </div>
				<!-- /.row -->
      </div>
      <!-- /.container -->
    </div>
  </div>
  <!-- /.main --> 

@include('templates/footer')
<style>
ul, li {
    border: 0 none;
    list-style: outside none none;
    margin: 0;
    padding: 0;
}
.infocard_legend li {
    float: left;
    margin-right: 15px;
}

.infocard_legend .worklist {
    background-color: #d9edf7;
}
.infocard_legend li span {
    border: 1px solid #ccc;
    float: left;
    height: 15px;
    margin: 2px 5px 2px 2px;
    width: 16px;
}

</style>
<script>
	$(document).ready(function($){
	var url = window.location.href;
	$('.navside li a[href="'+url+'"]').addClass('side-menu-main-active');
	});
</script>
@endsection
	
	