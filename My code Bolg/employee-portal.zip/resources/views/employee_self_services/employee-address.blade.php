@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
      
    <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1 class="center">Employee Address</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="container">
	<div class="row">
		<div class="col-sm-12">
			<ul class="nav nav-tabs" role="tablist">
				<li role="presentation" class="active">
					<a href="#personal" aria-controls="personal" role="tab" data-toggle="tab">
						<strong>Recent Requests</strong>
						<span></span>
					</a>
				</li>
				<li role="presentation">
					<a href="#company" aria-controls="company" role="tab" data-toggle="tab">
						<strong>Archived</strong>
						<span></span>
					</a>
				</li>
                <li role="presentation">
					<a href="#system" aria-controls="system" role="tab" data-toggle="tab">
						<strong>System Archived</strong>
						<span></span>
					</a>
				</li>
			</ul>
<style>
.searc {
    border-radius: 0;
    border-width: 0;
    width: 240px;
}
.searc form::after{color: rgb(153, 153, 153);
    content: "?";
    display: block;
    font-family: "FontAwesome";
    position: absolute;
    right: 30px;
    top: 11px;
}
table{width:100%; margin-top:15px;}
table th, tr, td{ margin:15px; padding:15px; border:1px solid #999;}
</style>
			<div class="tab-content">
				<div role="tabpanel" class="tab-pane active" id="personal">
				<form method="post" enctype="multipart/form-data" action="{{ route('employee-services',array('action' => 'postGrievance')) }}">
					{{ csrf_field() }}
					<div class="row">
						<div class="col-sm-12">
                        <table>
<thead>
<tr>
<td colspan="4">Employee Details</td>
</tr>
</thead>
<tbody>
<tr>
<td>Employee Id</td>
<td>{{ $data["user"]->id }}</td>
<td>Employee Name</td>
<td>{{ $data["user"]->f_name.' '.$data["user"]->l_name }}</td>
</tr>
<tr>
<td>Role</td>
<td>{{ $data["user"]->designation }}</td>
<td>Grievance HR</td>
<td>{{ $data["user"]->name }} </td>
</tr>
</tbody>
</table>

<div class="basic-detail">
<p>Grievance Details</p>
</div>

<table style="margin-top:10px;" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="prelegend"></td>
<td class="legend">
<label class="blueOutputLabel" style="padding-left:5px;">Category</label>
<span style="vertical-align: top;color:red;font-size: 8pt;">*</span>
</td>
<td class="value">
<span class="outputText"> </span>
<span class="outputText"> </span>
<select id="grievanceType" name="grievanceType" required="required" name="grievanceType" size="1">
<option value="0">----------Select-----------</option>
<option value="Administration">Administration</option>
<option value="Appraisal">Appraisal</option>
<option value="Communication">Communication</option>
<option value="Compensation">Compensation</option>
<option value="Employee Rewards">Employee Rewards</option>
<option value="Finance">Finance</option>
<option value="IDM">IDM</option>
<option value="Overseas Deputation">Overseas Deputation</option>
<option value="Policy">Policy</option>
<option value="Project">Project</option>
<option value="Transfer">Transfer</option>
</select>
</td>
<td class="space"> </td>
<td class="legend">
<label class="blueOutputLabel" style="padding-left:2px;">Subject</label>
<span style="vertical-align: top;color:red;font-size: 8pt;">*</span>
</td>
<td class="value">
<input id="subject" class="textField" required name="subject" value="" maxlength="500" autocomplete="off" type="text">
</td>
</tr>
</tbody>
</table>
<br/><br/>
<div class="form-group">
                        <label>Short Description</label>
                        <textarea class="form-control" rows="5" name="descrip"></textarea>
                    </div><!-- /.form-group -->

<div class="form-group">
                        <label form="form-register-photo">Upload file</label>
                        <input type="file" name="attachment_p" id="form-register-photo">
                    </div><!-- /.form-group-->

<p>File Types: MS office,Open Office files and images.</p>
			    <p>Size limit: 2 MB</p>

                        </div>
                    </div>
                   <br/><button type="submit" class="btn btn-secondary">Submit</button>
                        <br/><br/>
						</form>
				</div><!-- /.tab-pane -->

				<div role="tabpanel" class="tab-pane" id="company">
					<div class="row">
						<div class="col-sm-6">
							<div class="form-group">
								<label for="form-register-company-username">Document</label>
								<select class="form-control" name="letter_type" required="">
                                <option value="">--Select Letter--</option>
                                <option>Letter</option>
                                </select>
							</div><!-- /.form-group -->

							<div class="form-group">
								<label for="form-register-company-email">Period</label>
								<select class="form-control" name="letter_year" required="">
                                <option value="">--Select Year--</option>
                                <option value="2011">2011</option>
                                <option value="2012">2012</option>
                                <option value="2013">2013</option>
                                <option value="2014">2014</option>
                                <option value="2015">2015</option>
                                <option value="2016">2016</option>
                                <option value="2017">2017</option>
                                <option value="2018">2018</option>
                                <option value="2019">2019</option>
                                <option value="2020">2020</option>
                                <option value="2021">2021</option>
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                                <option value="2026">2026</option>
                                <option value="2027">2027</option>
                                <option value="2028">2028</option>
                                <option value="2029">2029</option>
                                <option value="2030">2030</option>
                                <option value="2031">2031</option>
                                <option value="2032">2032</option>
                                <option value="2033">2033</option>
                                <option value="2034">2034</option>
                                <option value="2035">2035</option>
                                <option value="2036">2036</option>
                                </select>
							</div><!-- /.form-group -->

							
						</div><!-- /.col-* -->
					</div><!-- /.row -->

					
						
<br/>
						<button type="submit" class="btn btn-secondary">Submit</button>
                        <br/><br/>
                   
					</div><!-- /.center -->
                    
				
                
                
                				<div role="tabpanel" class="tab-pane" id="system">
					<div class="row">
						<div class="col-sm-6">
							<div class="form-group">
								<label for="form-register-company-username">Document</label>
								<select class="form-control" name="letter_type" required="">
                                <option value="">--Select Letter--</option>
                                <option>Letter</option>
                                </select>
							</div><!-- /.form-group -->

							

							
						</div><!-- /.col-* -->
					</div><!-- /.row -->

					
						
<br/>
						<button type="submit" class="btn btn-secondary">Submit</button>
                        <br/><br/>
                   
					</div><!-- /.center -->
                    
				</div><!-- /.tab-pane -->
                
                
                
                
                
			</div><!-- /.tab-content -->
		</div><!-- /.col-* -->
	</div><!-- /.row -->
</div><!-- /.container -->

        </div><!-- /.main -->
    </div>
</div>
@include('templates/footer')
@endsection
