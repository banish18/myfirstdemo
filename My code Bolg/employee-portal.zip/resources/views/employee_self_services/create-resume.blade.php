@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
      <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1 class="center">Create Resume</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="container">
    <div class="col-sm-9">
        <form method="get" action="{{ route('employee-services',array('action' => 'postCreateresume')) }}" enctype="multipart/form-data">
            <div class="row" id="baisc">
                <div class="col-sm-7">
                    <div class="form-group">
                        <label form="form-register-photo">Photo</label>
                        <input type="file" name="empphoto" id="empphoto">
                    </div><!-- /.form-group-->
                </div><!-- /.col-* -->

                <div class="col-sm-5">
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" class="form-control" name="f_name" />
                    </div><!-- /.form-group -->

                    <div class="form-group">
                        <label>Middle Name</label>
                        <input type="text" class="form-control" name="m_name">
                    </div><!-- /.form-group -->

                    <div class="form-group">
                        <label>Surname</label>
                        <input type="text" class="form-control" name="l_name">
                    </div><!-- /.form-group -->
                </div><!-- /.col-* -->
            </div><!-- /.row -->

            <h3 class="page-header" id="contact">Contact Information</h3>

            <div class="row" >
                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Country</label>
                        <input type="text" class="form-control" name="country">
                    </div><!-- /.form-group -->
                </div><!-- /.col-* -->

                <div class="col-sm-4">
                    <div class="form-group">
                        <label>City</label>
                        <input type="text" class="form-control" name="city">
                    </div><!-- /.form-group -->
                </div><!-- /.col-* -->

                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Address</label>
                        <input type="text" class="form-control" name="address">
                    </div><!-- /.form-group -->
                </div><!-- /.col-* -->

                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" class="form-control" name="phone">
                    </div><!-- /.form-group -->
                </div><!-- /.col-* -->

                <div class="col-sm-4">
                    <div class="form-group">
                        <label>E-mail</label>
                        <input type="text" class="form-control" name="email">
                    </div><!-- /.form-group -->
                </div><!-- /.col-* -->

                <div class="col-sm-4">
                    <div class="form-group">
                        <label>Website</label>
                        <input type="text" class="form-control" name="website">
                    </div><!-- /.form-group -->
                </div><!-- /.col-* -->
            </div><!-- /.row -->

            <h3 class="page-header">Biography</h3>

            <div class="form-group" id="biography">
                <textarea id="editor" class="form-control" name="biography"></textarea>
            </div><!-- /.form-group -->

            <h3 class="page-header">Experience <a href="#" class="btn btn-primary">Add Another</a></h3>

            <div class="row" id="experience">
                <div class="col-sm-5">
                    <div class="form-group">
                        <label>Job Title</label>
                        <input type="text" class="form-control" name="job_title">
                    </div><!-- /.form-group -->
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Date From</label>
                                <input type="text" class="form-control" id="ex_df" name="ex_df">
                            </div><!-- /.form-group -->
                        </div><!-- /.col-* -->

                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Date To</label>
                                <input type="text" class="form-control" id="ex_dt" name="ex_dt">
                            </div><!-- /.form-group -->
                        </div><!-- /.col-* -->
                    </div><!-- /.row -->
                </div><!-- /.col-* -->

                <div class="col-sm-7">
                    <div class="form-group">
                        <label>Short Description</label>
                        <textarea class="form-control" rows="5" name="short_desc"></textarea>
                    </div><!-- /.form-group -->
                </div><!-- /.col-* -->
            </div><!-- /.row -->

            <h3 class="page-header">Education <a href="#" class="btn btn-primary">Add Another</a></h3>

            <div class="row" id="education">
                <div class="col-sm-5">
                    <div class="form-group">
                        <label>School Name</label>
                        <input type="text" class="form-control" name="school_name">
                    </div><!-- /.form-group -->

                    <div class="form-group">
                        <label>Degree</label>
                        <input type="text" class="form-control" name="degree">
                    </div><!-- /.form-group -->
                </div><!-- /.col-* -->

                <div class="col-sm-7">
                    <div class="form-group">
                        <label>Short Description</label>
                        <textarea class="form-control" rows="5" name="short_descedu"></textarea>
                    </div><!-- /.form-group -->
                </div><!-- /.col-* -->
            </div><!-- /.row -->

            <hr>

            <div class="center">
                <button type="submit" class="btn btn-secondary btn-lg">Save Resume</button>
            </div><!-- /.center -->
        </form>
    </div><!-- /.col-* -->

    <div class="col-sm-3">
 

        <div class="widget">
            <h2>Navigation</h2>

            <ul class="nav">
                <li><a href="#bsic"><span>1.</span> Basic Information</a></li>
                <li><a href="#contact"><span>2.</span> Contact</a></li>
                <li><a href="#biography"><span>3.</span> Biography</a></li>
                <li><a href="#experience"><span>4.</span> Experience</a></li>
                <li><a href="#education"><span>5.</span> Education </a></li>
            </ul>
        </div><!-- /.widget -->

        <div class="widget">
            <h2>Do you have an account?</h2>

            <p>If you don't have an account and you are looking for new employees. Feel free to <a href="registration.html">create new registration</a> for companies with transparent pricing.</p>
        </div><!-- /.widget -->
    </div><!-- /.col-* -->
</div><!-- /.container -->

        </div><!-- /.main -->
    </div><!-- /.main-wrapper -->
    </div>
</div>
@include('templates/footer')
<script>
	$(document).ready(function($){
		$("#ex_df").datepicker();
		$("#ex_dt").datepicker();
	});
</script>
@endsection
