@extends('layouts.app')
@section('content')
 <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1>Employee Self Services</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="document-breadcrumb">
                <div class="container">
                    <ul class="breadcrumb">
                        <li><a href="/">Home</a></li>
                        <li>Employee Self Services</li>
                    </ul>
                </div><!-- /.container -->
            </div><!-- /.document-title -->
  <div class="container">
	<div class="row">
		<div class="col-sm-12">
<div class="col-sm-4 bordr">
<div class="context">
<a href="{{ route('employee-services',array('action' => 'profile')) }}">
<p><i class="fa fa-user-circle fa-4x"></i></p>
<p class="bordrline"></p>
<p class="item-title">My Profile</p>
</a> 
</div>
</div>
<div class="col-sm-4 bordr">
<div class="context">
<a href="{{ route('employee-services',array('action' => 'travel')) }}">
<p><i class="fa fa-file-text fa-4x"></i></p>
<p class="bordrline"></p>
<p class="item-title">Travel</p>
</a>
</div>
</div>
<div class="col-sm-4 bordr">
<div class="context">
<a href="{{ route('employee-services',array('action' => 'apply-claims')) }}">
<p><i class="fa fa-address-card fa-4x"></i></p>
<p class="bordrline"></p>
<p class="item-title">Claims and Advances</p>
</a>
</div>
</div>
<div class="col-sm-4 bordr">
<div class="context">
<p><i class="fa fa-users fa-4x"></i></p>
<p class="bordrline"></p>
<p class="item-title">Allocation & Utilization</p>
</div>
</div>
<div class="col-sm-4 bordr">
<a href="{{ route('employee-services',array('action' => 'responsibility-management')) }}">
<div class="context">
<p><i class="fa fa-briefcase fa-4x"></i></p>
<p class="bordrline"></p>
<p class="item-title">Responsibilities</p>
</a>
</div>
</div>
<div class="col-sm-4 bordr">
<div class="context">
<a href="{{ route('employee-services',array('action' => 'employee-declaration')) }}">
<p><i class="fa fa-universal-access fa-4x"></i></p>
<p class="bordrline"></p>
<p class="item-title">Benefits and Taxes</p>
</a>
</div>
</div>
<div class="col-sm-4 bordr">
<div class="context">
<a href="{{ route('employee-services',array('action' => 'employee-perks')) }}">
<p><i class="fa fa-wrench fa-4x"></i></p>
<p class="bordrline"></p>
<p class="item-title">Employee Perks</p>
</a>
</div>
</div>
<div class="col-sm-4 bordr">
<div class="context">
<p><i class="fa fa-pencil-square-o fa-4x"></i></p>
<p class="bordrline"></p>
<p class="item-title">My WorkList - FYA</p>
</div>
</div>
<div class="col-sm-4 bordr">
<div class="context">
<p><i class="fa fa-bed fa-4x"></i></p>
<p class="bordrline"></p>
<p class="item-title">List of Holidays</p>
</div>
</div>
</div>
	</div><!-- /.row -->
</div><!-- /.container -->

<div class="container">
	<div class="row">
		<div class="col-sm-12">
<div class="col-sm-4 bordr">
<div class="context">
<a href="{{ route('leaves') }}">
<p><i class="fa fa-user-circle fa-4x"></i></p>
<p class="bordrline"></p>
<p class="item-title">Leaves</p>
</a>
</div>
</div>

</div>
	</div><!-- /.row -->
</div><!-- /.container -->

        </div><!-- /.main -->
    </div><!-- /.main-wrapper -->
@include('templates/footer')
@endsection
	
	