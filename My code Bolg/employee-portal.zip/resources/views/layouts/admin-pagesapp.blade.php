<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Employee Portal</title>

	 <!-- CORE CSS-->    
	{!!  Html::style('https://fonts.googleapis.com/css?family=Lato') !!}			 
    {!!  Html::style('admin-asset/css/bootstrap.min.css') !!} 
	{!!  Html::style('admin-asset/css/jquery.fancybox.css') !!}
	{!!  Html::style('admin-asset/css/icon-font.min.css') !!}
	{!!  Html::style('admin-asset/css/fullcalendar.css') !!}
	{!!  Html::style('admin-asset/css/datatables.css') !!}
	{!!  Html::style('admin-asset/css/datepicker.css') !!}
	{!!  Html::style('admin-asset/css/timepicker.css') !!}
	{!!  Html::style('admin-asset/css/style.css') !!}
	{!!  Html::style('admin-asset/css/jquery-ui.min.css') !!} 
	{!!  Html::script('admin-asset/ckeditor.js') !!} 
	{!!  Html::script('admin-asset/editor.js') !!} 
	{!!  Html::style('admin-asset/jquery.fancybox.css') !!} 
	{!!  Html::style('css/chosen.min.css') !!} 



</head>

<body class="default" onload="">
    <div id="app">
      
  
	@include("templates/admin-nav")
    <!-- End Page Loading -->

        @yield('content')
    </div>
	
 

  
   <script>
	$(".tooltip-trigger").tooltip();
	 </script>
		 <script>
		 /*   for mobile navigation */
		 $('.navbar-toggle').click(function() {
			 return $('body, html').toggleClass("nav-open");
		   });

	


		 /*
		  * =============================================================================
		  *   Bootstrap Popover
		  * =============================================================================
		  */

		 $(".popover-trigger").popover();
		 /*
		  * =============================================================================
		  *   Datepicker
		  * =============================================================================
		  */
 </script>
		
		
	
	<!-- ----------------------END------------------------------------- -->
    

</body>
</html>
	

