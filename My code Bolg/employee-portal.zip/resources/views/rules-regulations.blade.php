@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
          <div class="main-wrapper">
        <div class="main">
            <div class="document-title">
                <div class="container">
                    <h1>Rules and Regulations</h1>
                </div><!-- /.container -->
            </div><!-- /.document-title -->

            <div class="document-breadcrumb">
                <div class="container">
                    <ul class="breadcrumb">
                        <li><a href="{{ route('home') }}">Home</a></li>
                        <li>Rules & Regulations</li>
                    </ul>
                </div><!-- /.container -->
            </div><!-- /.document-title -->
  <div class="container">
	<div class="row">
		<div class="col-sm-12">
			<h3 class="page-header">Description, duties, responsibilities</h3>
			<p>
			{{ $data['rules']->description_responsibilities	 }}
			</p>

			<h3 class="page-header">Other benefits</h3>
			{{ strip_tags($data['rules']->other_beifits)	 }}
			

			<h3 class="page-header">Personality requirements and skills</h3>
			{{ strip_tags($data['rules']->skills)	 }}
			
		</div><!-- /.col-* -->
	</div><!-- /.row -->
</div><!-- /.container -->

        </div><!-- /.main -->
    </div><!-- /.main-wrapper -->
    </div>
</div>
@include('templates/footer')
@endsection
