<?php 
	echo phpinfo();
?>