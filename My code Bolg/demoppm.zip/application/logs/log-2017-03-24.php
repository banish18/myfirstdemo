<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2017-03-24 04:54:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 04:54:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 04:54:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 04:54:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:44:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:44:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:44:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:45:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:46:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:47:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:47:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:47:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:47:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:48:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:49:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:49:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:49:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:49:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:49:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:49:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:49:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:50:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:50:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:50:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:50:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:50:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:50:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:50:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:50:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:53:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:53:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:53:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:53:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:53:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:53:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:53:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:53:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:53:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:53:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:54:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:54:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:54:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:54:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:54:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:54:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:54:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:54:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:56:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:56:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:57:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:57:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:57:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:57:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:57:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:57:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:57:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:57:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:59:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:59:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:59:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 05:59:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:00:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:00:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:01:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:01:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:01:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:01:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:01:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:01:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:02:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:02:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:02:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:02:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:02:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:02:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:02:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:02:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:02:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:02:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:03:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:03:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:03:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:03:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:03:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:03:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:03:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:03:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:03:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:03:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:04:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:04:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:04:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:04:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:05:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:05:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:05:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:05:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:05:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:05:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:06:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:06:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:06:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:06:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:06:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:07:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:08:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:09:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:09:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:09:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:09:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:09:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:09:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:09:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:09:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:10:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:10:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:10:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:10:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:10:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:10:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:10:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:10:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:10:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:10:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:11:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:12:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:12:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:12:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:12:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:12:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:12:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:12:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:12:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:12:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:12:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:12:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:12:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:13:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:13:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:13:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:13:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:13:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:13:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:13:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:13:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:13:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:13:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:13:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:13:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:14:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:15:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:16:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:16:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:16:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:16:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:16:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:16:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:18:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:18:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:18:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:18:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:18:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:18:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:19:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:19:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:27:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:27:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:28:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:28:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:29:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:29:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:31:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:31:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:31:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:31:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:31:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:31:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:31:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:31:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:31:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:33:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:33:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:33:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:33:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:34:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:34:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:34:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:34:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:34:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:34:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:36:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:36:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:36:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:36:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:36:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:37:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:38:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:39:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:40:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:40:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:40:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:40:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:40:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:40:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:40:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:40:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:41:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:41:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:41:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:41:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:41:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:41:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:43:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:43:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:44:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:44:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:46:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:46:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:47:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:47:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:47:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:47:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:47:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:47:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:48:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:48:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:50:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:50:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:50:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:50:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:50:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:50:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:50:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:50:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:50:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:50:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:51:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:51:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:52:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:52:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:52:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:52:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:53:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:53:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:53:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:53:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:53:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 06:53:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:00:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:00:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:00:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:01:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:01:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:01:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:01:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:01:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:24  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:02:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:03:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:03:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:03:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:03:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:04:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:04:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:04:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:04:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:04:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:04:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:05:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:05:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:05:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:05:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:17:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:17:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:17:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:17:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:17:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:17:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:17:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:17:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:18:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:18:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:18:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:18:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:18:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:18:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:18:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:18:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:21:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:21:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:21:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:22:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:22:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:22:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:22:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:22:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:22:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:22:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:22:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:22:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:22:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:22:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:23:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:22  
Severity: 8192  
--> Function eregi() is deprecated /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/helpers/toolbox_helper.php 178
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:24  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:24:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:25:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:25:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:25:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:25:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:25:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:25:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:26:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:27:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:28:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:28:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:28:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:28:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:28:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:28:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:28:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:28:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:28:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:28:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:28:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:29:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:30:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:30:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:30:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:30:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:31:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:31:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:31:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:31:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:31:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:40:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:48:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:48:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:48:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 07:48:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:05:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:05:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:05:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:05:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:05:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:05:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:05:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:05:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:05:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:05:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:06:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:06:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:06:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:06:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:06:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:06:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:06:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:06:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:07:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:08:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:08:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:08:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:08:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:08:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:08:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:08:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:08:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:08:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:08:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:09:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:09:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:09:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:09:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:09:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:10:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:10:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:10:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:10:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:10:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:10:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:10:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:10:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:11:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:11:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:11:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 08:11:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 09:26:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 09:26:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 09:26:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 09:26:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 09:26:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 09:26:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 09:26:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 09:26:24  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 09:26:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 09:26:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:03:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:04:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:04:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:04:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:04:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:04:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:04:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:05:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:05:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:05:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:05:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:05:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:05:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:05:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:05:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:06:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:06:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:08:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:08:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:09:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:09:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:09:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:09:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:10:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:10:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:10:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:10:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:10:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:10:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:10:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:10:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:12:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:12:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:12:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:12:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:12:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:12:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:12:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:12:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:13:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:13:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:13:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:13:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:21:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:21:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:22:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:22:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:22:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:22:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:22:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:22:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:22:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:22:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:22:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:22:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:22:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:22:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:23:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:24:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:24:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:25:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:25:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:25:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:25:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:25:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:25:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:26:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:26:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:26:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:26:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:27:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:27:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:27:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:27:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:28:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:28:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:28:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:28:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:28:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:28:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:28:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:28:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:28:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:28:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:29:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:29:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:29:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:29:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:29:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:29:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:29:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:29:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:29:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:29:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:29:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:29:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:30:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:30:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:30:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:30:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:30:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:30:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:35:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:36:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:37:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:37:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:38:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:38:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:38:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 10:38:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:08:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:08:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:08:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:08:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:08:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:08:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:08:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:08:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:08:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:08:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:09:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:09:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:09:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:09:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:09:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-24 11:09:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

