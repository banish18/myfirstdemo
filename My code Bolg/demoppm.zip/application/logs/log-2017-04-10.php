<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2017-04-10 05:29:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:55:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:55:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:55:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:55:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:55:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:55:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:55:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:55:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:55:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:56:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:56:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:56:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:56:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:57:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:57:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:58:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:58:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:58:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 06:58:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:01:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:01:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:57:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:57:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:57:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:57:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:57:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:57:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:59:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:59:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:59:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:59:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:59:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 07:59:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:01:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:01:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:03:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:03:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:03:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:03:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:08:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:08:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:09:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:09:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:14:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:14:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:15:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:17:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:17:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:17:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:17:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:17:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:17:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:18:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:18:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:20:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:20:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:20:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:20:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:21:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 08:21:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:47:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:47:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:48:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:48:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:48:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:48:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:48:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:48:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:48:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:48:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:48:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:48:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:49:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:49:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:49:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:49:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:49:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:49:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:49:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:49:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:50:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:50:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:50:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:50:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:50:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:50:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:50:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:50:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:50:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:50:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:51:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:51:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:51:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:51:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:51:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:51:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:51:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:51:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:51:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:51:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:52:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:52:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:52:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:52:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:52:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:52:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:52:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:52:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:53:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:53:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:53:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:53:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:53:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:53:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:53:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:53:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:53:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:53:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:53:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:53:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:54:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:54:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:54:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:54:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:56:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-04-10 10:56:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

