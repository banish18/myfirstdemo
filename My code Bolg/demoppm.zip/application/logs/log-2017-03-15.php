<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2017-03-15 05:26:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:26:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:27:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:27:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:30:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:31:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:31:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:31:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:31:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:32:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:32:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:32:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:32:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:32:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:32:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:32:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:32:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:32:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:33:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:33:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:35:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:35:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:35:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:35:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:35:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:35:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:35:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:35:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:35:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:35:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:24  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:36:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:37:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:37:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:37:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:37:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:37:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:37:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:37:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:37:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:37:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:37:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:37:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:37:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:24  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:38:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:39:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:40:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:40:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:40:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:40:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:40:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:40:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:41:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:41:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:41:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:41:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:43:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:43:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:43:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:43:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:44:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:44:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:44:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:44:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:44:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:44:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:44:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:44:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:44:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:44:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:44:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:44:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:45:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:45:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:45:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:46:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:46:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:46:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:46:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:46:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:46:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:46:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:46:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:46:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:46:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:47:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:47:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:47:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:47:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:47:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:47:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:47:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:47:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:47:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:47:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:47:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:47:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:49:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:49:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:49:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:49:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:49:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:49:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:49:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:49:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:49:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:49:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:50:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:51:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:51:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:51:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:51:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:56:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:56:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:56:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:56:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:56:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:56:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:56:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:56:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:56:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:56:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:57:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:57:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:57:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:57:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:57:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:57:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:57:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:57:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:57:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:57:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:57:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 05:57:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:01:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:01:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:01:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:01:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:01:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:01:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:01:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:01:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:02:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:05:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:05:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:08:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:08:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:08:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:08:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:10:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:10:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:10:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:10:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:11:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:11:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:11:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:11:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:11:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:11:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:11:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:11:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:11:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:11:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:12:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:12:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:12:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:12:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:13:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:13:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:13:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:13:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:13:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:13:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:13:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:13:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:14:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:14:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:15:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:15:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:15:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:15:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:15:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:16:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:16:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:16:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:16:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:16:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:16:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:16:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:16:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:17:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:17:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:17:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:17:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:18:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:18:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:18:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:18:24  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:18:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:18:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:18:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:18:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:19:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:19:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:19:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:19:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:20:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:20:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:21:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:21:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:21:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:21:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:21:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:21:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:22:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:22:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:22:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:22:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:23:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:23:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:23:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:23:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:23:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:23:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:24:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:24:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:33:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:33:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:33:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:33:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:33:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:33:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:34:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:34:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:34:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:34:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:35:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:35:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:36:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:36:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:36:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:36:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:36:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:36:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:37:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:37:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:37:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:37:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:37:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:37:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:37:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:37:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:37:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:37:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:38:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:38:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:38:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:38:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:38:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:38:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:39:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:39:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:40:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:40:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:40:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:40:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:41:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:41:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:41:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:41:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:42:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:42:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:42:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:42:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:42:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:42:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:43:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:43:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:50:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 06:50:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:03:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:03:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:03:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:03:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:03:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:03:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:14:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:14:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:19:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:19:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:19:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:19:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:19:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:19:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:19:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:19:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:30:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 07:30:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:05:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:05:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:05:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:06:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:06:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:06:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:06:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:06:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:13:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:13:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:13:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:13:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:13:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:13:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:15:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:15:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:15:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:15:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:16:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:16:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:18:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:18:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:19:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:19:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:19:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:19:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:20:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:20:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:20:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:20:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:20:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:20:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:20:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:20:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:22:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:22:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:23:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:23:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:25:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:25:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:26:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:26:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:27:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:27:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:03  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:28:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:29:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:29:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:30:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:31:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:31:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:31:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:31:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:31:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:31:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:31:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:31:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:31:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:31:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:31:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:31:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:32:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:32:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:32:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:32:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:33:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:33:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:33:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:33:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:33:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:33:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:38:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:38:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:38:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:38:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:38:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:38:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:39:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:39:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:39:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:39:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:40:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:40:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:40:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:40:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:40:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:40:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:40:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:40:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:40:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:40:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:40:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:40:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:41:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:41:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:41:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:41:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:42:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:42:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:42:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:42:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:42:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:42:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:42:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:42:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:42:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:42:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:43:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:43:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:44:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:45:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:45:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:45:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:45:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:45:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:45:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:45:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:45:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:45:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:45:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:46:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:46:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:46:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:46:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:46:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:46:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:46:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:46:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:46:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:46:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:46:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:46:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:47:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:47:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:47:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:47:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:47:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:47:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:47:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:47:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:47:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:47:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:47:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:47:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:48:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:48:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:48:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:48:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:48:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:48:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:48:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:48:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:48:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:48:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:49:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:49:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:49:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:49:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:49:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:49:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:50:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:50:24  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:50:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:50:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:50:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:50:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:51:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:52:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:52:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:52:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:52:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:53:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:53:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:53:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:53:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:53:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:53:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:53:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:53:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:54:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:54:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:54:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:54:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:54:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:54:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:54:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:54:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:55:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:55:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:55:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:55:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:55:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:55:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:55:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:55:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:56:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:56:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:58:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:58:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:58:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:58:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:58:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:58:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:58:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:58:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:58:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:58:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:58:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:58:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:24  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 08:59:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:00:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:00:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:00:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:00:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:00:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:00:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:00:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:00:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:00:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:00:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:00:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:00:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:01:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:01:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:01:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:01:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:01:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:01:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:01:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:01:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:01:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:01:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:02:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:03:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:04:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:05:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:05:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:06:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:07:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:07:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:07:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:07:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:07:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:07:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:07:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:07:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:07:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:07:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:08:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:09:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:09:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:09:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:09:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:10:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:10:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:11:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:12:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:12:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:12:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:12:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:12:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:12:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:12:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:12:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:12:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:12:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:13:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:14:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:15:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:15:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:15:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:15:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:18:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:18:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:18:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:18:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:18:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:18:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:22:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:23:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:24:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:24:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:24:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:24:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:24:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:24:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:24:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:24:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:24:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:24:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:25:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:25:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:25:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:25:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:25:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:25:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:25:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:25:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:25:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:25:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:26:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:26:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:26:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:26:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:27:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:27:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:27:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:27:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:27:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:27:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:27:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:27:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:27:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:27:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:27:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:27:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:28:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:28:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:28:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:28:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:28:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:28:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:29:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:29:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:29:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:29:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:29:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:29:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:30:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:30:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:30:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:30:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:30:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:30:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:30:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:30:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:30:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:30:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:31:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:31:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:31:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:31:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:31:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:31:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:32:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:32:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:32:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:32:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:32:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:32:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:33:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:33:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:33:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:33:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:33:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:33:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:33:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:33:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:35:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:35:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:41:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:41:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:41:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:41:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:41:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:41:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:41:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:41:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:42:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:42:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:42:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:42:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:46:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:46:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:49:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:49:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:51:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:51:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:52:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:52:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:52:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:52:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:52:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:52:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:53:31  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:53:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:53:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:53:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:53:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:53:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:54:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:54:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:54:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:54:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:54:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:54:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:55:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:55:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:55:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:55:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:55:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:55:24  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:55:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:55:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:55:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:55:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:55:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:55:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:56:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 09:56:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:05:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:05:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:06:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:06:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:06:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:06:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:07:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:07:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:08:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:08:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:08:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:08:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:08:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:08:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:08:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:08:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:09:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:09:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:09:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:09:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:17:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 10:17:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:42:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:42:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:45:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:45:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:45:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:45:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:45:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:45:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:47:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:47:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:47:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:47:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:47:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:47:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:48:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:48:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:48:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:48:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:48:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:48:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:48:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:48:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:55:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:55:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:55:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 11:55:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:04:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:04:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:04:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:04:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:05:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:05:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:05:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:05:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:06:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:06:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:17:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:17:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:17:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:17:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:17:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:17:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:19:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:19:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:19:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:19:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:19:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:19:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:20:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:20:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:20:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:20:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:20:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:20:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:20:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:20:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:22:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:22:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:22:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:22:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:22:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:22:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:25:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:25:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:26:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:26:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:26:20  
Severity: 4096  
--> Object of class CI_URI could not be converted to string /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/controllers/admin/myprojects.php 66
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:26:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:26:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:28:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:28:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:29:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:29:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:29:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:29:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:30:03  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:30:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:30:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:30:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:30:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:30:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:30:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:30:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:40:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:40:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:40:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:40:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:41:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:41:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:44:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:44:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:46:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:46:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:46:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-03-15 12:46:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

