<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2017-05-05 03:46:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:48:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:48:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:48:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:48:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:48:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:53:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:53:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:54:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:54:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:54:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:54:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:54:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:54:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:54:30  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 03:54:31  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:02:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:02:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:02:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:02:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:03:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:03:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:03:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:03:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:46  
AJAX-LOG:: [FILE: /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/controllers/admin/ajax.php]  
[FUNCTION: __default]  
[LINE: 308]  
[MESSAGE: Routing errror. Specified method/action (delete-credentialmember) not found]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:09:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:10:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:10:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:10:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:22:59  
AJAX-LOG:: [FILE: /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/controllers/admin/ajax.php]  
[FUNCTION: __default]  
[LINE: 308]  
[MESSAGE: Routing errror. Specified method/action (delete-credentialmember) not found]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:23:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:23:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:32:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:32:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:33:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:33:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:33:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:33:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:33:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:33:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:34:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:34:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:34:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:34:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:35:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:35:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:37:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:37:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:38:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:38:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:38:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:38:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:38:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:38:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:40:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:40:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:46:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:46:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:46:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:46:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:47:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:47:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:47:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:47:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:47:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:47:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:49:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:49:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:50:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:50:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:50:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:50:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:50:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:50:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:50:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:50:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:57:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:57:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:58:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:58:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:58:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:58:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:58:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 04:58:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:00:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:00:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:00:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:00:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:00:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:00:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:00:41  
AJAX-LOG:: [FILE: /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/controllers/admin/ajax.php]  
[FUNCTION: __default]  
[LINE: 308]  
[MESSAGE: Routing errror. Specified method/action (delete-credentialmember) not found]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:00:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:00:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:03:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:03:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:03:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:03:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:03:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:03:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:03:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:03:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:03:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:03:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:03:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:03:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:04:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:04:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:04:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:04:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:04:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:04:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:04:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:04:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:05:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:05:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:05:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:05:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:42:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:42:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:43:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:43:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:43:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:43:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:43:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:43:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:43:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:43:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:44:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:44:24  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:44:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:44:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:44:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:44:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:44:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:44:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:44:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:44:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:46:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:46:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:46:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:46:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:46:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:46:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:46:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:46:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:46:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:46:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:46:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:46:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:47:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:47:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:47:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:47:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:47:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:47:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:47:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:47:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:51:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:51:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:51:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:51:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:51:48  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:51:48  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:51:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:51:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:52:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:52:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:52:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:52:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:52:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:52:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:52:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 05:52:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:30  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:00:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:03:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:03:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:03:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:03:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:03:59  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:03:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:04:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:04:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:16  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:16  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:21  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:21  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:06:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:07:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:07:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:07:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:07:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:07:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:07:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:07:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:07:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:07:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:07:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:09:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:10:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:10:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:10:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:10:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:10:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:10:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:14:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:14:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:14:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:14:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:14:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:14:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:14:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:14:15  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:17:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:17:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:17:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:17:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:17:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:17:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:17:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:17:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:17:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 06:17:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:02:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:02:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:02:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:02:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:03:15  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:04:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:05:36  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:05:36  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:05:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:06:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:06:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:06:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:06:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:08:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:08:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:08:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:08:17  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:08:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:08:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:08:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:08:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:08:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:08:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:08:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:08:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:09:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:09:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:09:23  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:09:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:09:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:09:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:09:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:09:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:09:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:09:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:09:34  
Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ctype,
                                          cname,
                        ' at line 4
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:10:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:10:07  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:10:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:10:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:10:11  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:10:11  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:10:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:10:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:10:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:10:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:10:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:10:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:12:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:12:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:12:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:12:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:14:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:14:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:14:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:14:28  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:14:28  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:15:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:15:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:15:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:15:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:15:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:15:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:06  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:06  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:09  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:40  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:54  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:54  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:16:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:17:04  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:17:04  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:17:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:17:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:17:29  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:17:29  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:17:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:17:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:17:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:17:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:17:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:17:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:24:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:24:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:24:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:24:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:24:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:24:58  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:25:51  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:25:51  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:26:20  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:26:20  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:27:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:27:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:28:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:28:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:28:33  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:28:33  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:29:00  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:29:00  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:29:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:29:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:30:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:30:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:30:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:30:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:30:53  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:30:53  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:31:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:31:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:31:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:31:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:36:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:36:13  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:45:17  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 07:45:18  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:05:27  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:05:27  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:05:34  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:05:34  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:05:35  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:05:35  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:05:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:05:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:05:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:05:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:05:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:05:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:06:25  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 08:06:25  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:31:56  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:31:56  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:32:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:32:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:32:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:32:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:32:18  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:32:19  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:32:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:32:19  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:32:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:32:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:37:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:37:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:37:38  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:37:38  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:37:43  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 10:37:43  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 11:42:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 11:42:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 11:42:33  
[FILE: /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/helpers/view_helper.php]  
[FUNCTION: help_verify_template]  
[LINE: 27]  
[MESSAGE: Template file could not be found (/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/themes/default/admin/emails.html)]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 11:57:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 11:57:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 11:57:52  
[FILE: /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/helpers/view_helper.php]  
[FUNCTION: help_verify_template]  
[LINE: 27]  
[MESSAGE: Template file could not be found (/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/themes/default/admin/emails.html)]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 12:08:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 12:08:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 12:08:02  
[FILE: /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/helpers/view_helper.php]  
[FUNCTION: help_verify_template]  
[LINE: 27]  
[MESSAGE: Template file could not be found (/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/themes/default/admin/emails.html)]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 12:10:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 12:10:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 12:16:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-05 12:16:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

