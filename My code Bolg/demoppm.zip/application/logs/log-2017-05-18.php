<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2017-05-18 04:07:42  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:07:42  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:08:01  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:08:01  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:08:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:08:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:08:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:08:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:08:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:08:22  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:08:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:08:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:09:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:09:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:09:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 04:09:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:20:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:20:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:20:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:20:47  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:20:47  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:20:52  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:20:52  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:20:57  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:20:57  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:41:22  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:41:23  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:42:40  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:42:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:43:10  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:43:10  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:43:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:43:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:44:39  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:44:39  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:50:37  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 09:50:37  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:01:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:01:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:12:12  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:12:12  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:12:44  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:12:44  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:12:49  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:12:49  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:12:55  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:12:55  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:13:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:13:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:13:26  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:13:26  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:13:32  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:13:32  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:16:13  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:16:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:16:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:16:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:16:24  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:20:02  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:20:02  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:20:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:20:45  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:20:50  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:20:50  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:20:58  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:20:59  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:21:07  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:21:08  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:21:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:21:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:22:45  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:22:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:22:46  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:22:46  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:25:41  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:25:41  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:25:41  
Query error: Unknown column 'tasks.task_id' in 'order clause'
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:26:14  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 10:26:14  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 12:44:08  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 12:44:09  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 14:00:05  
Severity: 8192  
--> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead /mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/system/database/drivers/mysql/mysql_driver.php 91
------------------------------------------------------------------------------------------------------------------------------

ERROR - 2017-05-18 14:00:05  
/mounted-storage/home45b/sub002/sc33066-HWBV/dbasupport/PPM/application/core/MY_Controller.php --- __preRun_MysqlUpdates --- 1195 --- [DB UPDATED - FULL DEBUG DATA()]
------------------------------------------------------------------------------------------------------------------------------

