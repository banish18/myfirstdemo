<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * class for perfoming all Mycredentials related functions
 *
 * @author   Mindxpert.com
 * @access   public
 * @see      http://www.mindxpert.com
 */
class Mycredentials extends MY_Controller
{

    /**
     * constructor method
     */
    public function __construct()
    {

        parent::__construct();

        //profiling::
        $this->data['controller_profiling'][] = __function__;


        //template file
     /*    if ($this->data['fields']['settings_general']['project_list_display'] == 'extended') {
            $this->data['template_file'] = PATHS_ADMIN_THEME . 'projects.extended.html';
        } else { */
            $this->data['template_file'] = PATHS_ADMIN_THEME . 'mycredential.html';
        // }

        //display segments
        $this->data['visible']['display_segments'] = 'basic';

        //member specific title bar
        $this->data['visible']['wi_my_projects_title_bar'] = 1;

        //css settings
        $this->data['vars']['css_menu_heading_myprojects'] = 'heading-menu-active'; //menu
        $this->data['vars']['css_menu_myprojects'] = 'open'; //menu

        //default page title
        $this->data['vars']['main_title'] 		= $this->data['lang']['lang_my_credentials'];
        $this->data['vars']['main_title_icon'] 	= '<i class="icon-folder-open"></i>';

    }

    /**
     * This is our re-routing function and is the inital function called
     *
     * 
     */
    function index()
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //login check
        $this->__commonAdmin_LoggedInCheck();
		
        //uri - action segment
        $action = $this->uri->segment(3);
		
		$uid    = $this->uri->segment(4);
		
        //re-route to correct method
        switch ($action) {
			case 'list':
                $this->__listCredentials();
                break;
			
            case 'new-credential':
                $this->__newCredential();
                break;
			case 'add-credential':
                $this->__addCredential();
                break;
			case 'edit-credential':
                $this->__editCredential();
                break;	
			case 'update-credentail':
                $this->__updateCredential();
                break;		
			case 'update-note':
                $this->__updateNote();
                break;		
            default:
                $this->__listCredentials();
        }

        //load view
        $this->__flmView('admin/main');

    }

    /**
     * list a members own projects
     */
    function __listCredentials()
    {

        /* --------------URI SEGMENTS---------------
        * [example]
        * /admin/mycredentials/list/in-progress/0
        * (2)->controller
        * (3)->router
        * (4)->status (open/closed)
        * (5)->offset
        ** -----------------------------------------*/

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //uri segments
        $status = ($this->uri->segment(4) =='')? 'open': $this->uri->segment(4);
        $offset = (is_numeric($this->uri->segment(5))) ? $this->uri->segment(5) : 0;

        //additional data
        $my_id = $this->data['vars']['my_id'];
		

        //get results and save for tbs block merging
        $this->data['reg_blocks'][] = 'blk1';
        $this->data['blocks']['blk1'] = $this->projects_model->getCredentials($offset, 'search', $my_id, $status);
		

        //count results rows - used by pagination class
        $rows_count = count($this->projects_model->getCredentials($offset, 'count', $my_id, $status));
	
		


        //pagination
        $config = pagination_default_config(); //
        $config['base_url'] = site_url("/admin/mycredentials/list/$status");
        $config['total_rows'] = $rows_count;
        $config['per_page'] = $this->data['settings_general']['results_limit'];
        $config['uri_segment'] = 5; //the offset var
        $this->pagination->initialize($config);
        $this->data['vars']['pagination'] = $this->pagination->create_links();

        //visibility
        if ($rows_count > 0) {
            //show side menu
            $this->data['visible']['wi_projects_table'] = 1;
        } else {
            //show mothing found
            $this->notifications('wi_notification', $this->data['lang']['lang_no_results_found']);
        }

 

    }
	
	/**
     * load credential module
     *
    */
	
    function __editCredential()
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;
		
		 //make form visible
        $this->data['visible']['wi_edit_project_form'] = 1;
		


        //flow control
        $next = true;

        //get users id
        $id = $this->uri->segment(4);

        //load users details
        $result		= $this->projects_model->credentailDetail($id);

        //check data
        if ($result) {
            //set vars array
            $credentail_details['id'] 			= $result['id'];
            $credentail_details['type'] 		= $result['type'];
            $credentail_details['username'] 	= $result['username'];
            $credentail_details['password'] 	= $result['password'];
            $credentail_details['other_detail'] = $result['other_detail'];
            $credentail_details['notes'] 		= $result['notes'];
			
			

            //add array to merge data
			$this->data['reg_blocks'][] = 'credential';
			$this->data['blocks']['credential'] = $credentail_details;
          

        } else {

            //show error
            $this->notifications('wi_notification', $this->data['lang']['lang_no_results_found']);
        }

    }
	
	/**
     * add new credential
     *
     */
    function __updateCredential()
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //flow control
        $next = true;

     

        //prefill forms with post data
        $this->data['reg_fields'][] = 'post';
        foreach ($_POST as $key => $value) {
            $this->data['fields']['post'][$key] = $value;
        }

		
        //form validation
        if (!$this->__flmFormValidation('add_credential')) {
            //show error
            $this->notices('error', $this->form_processor->error_message, 'html');
            //halt
            $next = false;
        }

        //save information to database & get the id of this new client
        if ($next) {
            $credential_id = $this->projects_model->addCredential();


            //was the project created ok
            if (is_numeric($credential_id)) {

                //redirect to new project
                redirect("/admin/mycredentials/list");
            } else {
                //show error
                $this->notifications('wi_notification', $this->data['lang']['lang_request_could_not_be_completed']);
            }
        }
    }

	
	 /**
     * display [add new credential] form
     */
    function __newCredential()
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //make form visible
        $this->data['visible']['wi_add_project_form'] = 1;

        //page title
        $this->data['visible']['wi_title_bar'] = 1;
        $this->data['vars']['projects_page_title'] = $this->data['lang']['lang_add_new_credential'];

        //create post field for tbs
        $this->data['reg_fields'][] = 'post';

        //tbs fix
        $this->data['reg_blocks'][] = 'blk1';
        $this->data['blocks']['blk1'] = array();

    }
	/**
     * update credential
     *
     */
	function __updateNote(){
		 //profiling
        $this->data['controller_profiling'][] = __function__;

        //flow control
        $next = true;
		
		 //get credential id
        $id = $this->uri->segment(4);

        //prefill forms with post data
        $this->data['reg_fields'][] = 'post';
        foreach ($_POST as $key => $value) {
            $this->data['fields']['post'][$key] = $value;
        }

        //save information to database & get the id of this new client
        if ($next) {
            $this->projects_model->updateNote($id);

			//redirect to new project
			redirect("admin/credential/edit-notes/".$id);
       
        }
	}
	/**
     * add new credential
     *
     */
    function __addCredential()
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //flow control
        $next = true;

     

        //prefill forms with post data
        $this->data['reg_fields'][] = 'post';
        foreach ($_POST as $key => $value) {
            $this->data['fields']['post'][$key] = $value;
        }

		
        //form validation
        if (!$this->__flmFormValidation('add_credential')) {
            //show error
            $this->notices('error', $this->form_processor->error_message, 'html');
            //halt
            $next = false;
        }

        //save information to database & get the id of this new client
        if ($next) {
            $credential_id = $this->projects_model->addCredential();


            //was the project created ok
            if (is_numeric($credential_id)) {

                //redirect to new project
                redirect("/admin/mycredentials/list");
            } else {
                //show error
                $this->notifications('wi_notification', $this->data['lang']['lang_request_could_not_be_completed']);
            }
        }
    }
	
	/**
     * validates forms for various methods in this class
     * @param	string $form identify the form to validate
     */
    function __flmFormValidation($form = '')
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //form validation
        if ($form == 'add_credential') {

            //check required fields
            $fields = array(
                'type' => "type",
                'username' => "username",
                'password' => "password",
                'other_detail' => "other_detail",
				'notes' => "notes");
            if (!$this->form_processor->validateFields($fields, 'required')) {
                return false;
            }

            //everything ok
            return true;
        }

        //nothing specified - return false & error message
        $this->form_processor->error_message = $this->data['lang']['lang_form_validation_error'];
        return false;

    }
    /**
     * loads the view
     *
     * @param string $view the view to load
     */
    function __flmView($view = '')
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //template::
        $this->data['template_file'] = help_verify_template($this->data['template_file']);
		

        //complete the view
        $this->__commonAll_View($view);
    }
	


}

/* End of file myprojects.php */
/* Location: ./application/controllers/admin/myprojects.php */
