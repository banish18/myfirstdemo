<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * class for perfoming all Mycredentials related functions
 *
 * @author   Mindxpert.com
 * @access   public
 * @see      http://www.mindxpert.com
 */
class Password extends MY_Controller
{

    /**
     * constructor method
     */
    public function __construct()
    {

        parent::__construct();

        //profiling::
        $this->data['controller_profiling'][] = __function__;


        //template file
        $this->data['template_file'] = PATHS_ADMIN_THEME . 'password.modal.html';

    }

    /**
     * This is our re-routing function and is the inital function called
     *
     * 
     */
    function index()
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //login check
        $this->__commonAdmin_LoggedInCheck();
		
        //uri - action segment
        $action = $this->uri->segment(3);
		
		$uid    = $this->uri->segment(4);
		
        //re-route to correct method
        switch ($action) {
           case 'show-password':
                $this->__showPassword();
                break;	
           case 'show-ppassword':
				$this->__showPPassword();
                break;	
            default:
                $this->__showPassword();
        }

        //load view
        $this->__flmView('admin/main');

    }
	
	/*
		Get Password 
	*/
	
	function __showPassword(){
		
        //profiling
        $this->data['controller_profiling'][] = __function__;

        //flow control
        $next = true;

        //get users id
        $id = $this->uri->segment(4);
		

        //load users details
        $result = $this->projects_model->showPassword($id);
		$password = base64_decode($result["password"]);

        //check data
        if ($password) {
          
            $this->data['reg_fields'][] = 'password';
            $this->data['fields']['password'] = $password;

        } else {

            //show error
            $this->notifications('wi_notification', $this->data['lang']['lang_no_results_found']);
        }

	}
	
	/*
		Get Password 
	*/
	
	function __showPPassword(){
		
        //profiling
        $this->data['controller_profiling'][] = __function__;

        //flow control
        $next = true;

        //get users id
        $id = $this->uri->segment(4);
		

        //load users details
        $result = $this->projects_model->showPPassword($id);
		$password = base64_decode($result["cpassword"]);

        //check data
        if ($password) {
          
            $this->data['reg_fields'][] = 'password';
            $this->data['fields']['password'] = $password;

        } else {

            //show error
            $this->notifications('wi_notification', $this->data['lang']['lang_no_results_found']);
        }

	}
	/**
     * loads the view
     *
     * @param string $view the view to load
     */
    function __flmView($view = '')
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //template::
        $this->data['template_file'] = help_verify_template($this->data['template_file']);
		

        //complete the view
        $this->__commonAll_View($view);
    }
	
}

/* End of file credential.php */
/* Location: ./application/controllers/admin/credential.php */
