<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * class for perfoming all Mycredentials related functions
 *
 * @author   Nextloop.net
 * @access   public
 * @see      http://www.nextloop.net
 */
class Pcredential extends MY_Controller
{

    /**
     * constructor method
     */
    public function __construct()
    {

        parent::__construct();

        //profiling::
        $this->data['controller_profiling'][] = __function__;


        //template file
        $this->data['template_file'] = PATHS_ADMIN_THEME . 'pcredential.modal.html';

    }

    /**
     * This is our re-routing function and is the inital function called
     *
     * 
     */
    function index()
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //login check
        $this->__commonAdmin_LoggedInCheck();
		
        //uri - action segment
        $action = $this->uri->segment(4);
		
		$uid    = $this->uri->segment(3);
		
		
		//create pulldown lists
        $this->__pulldownLists();
		
	
		
		
		
        //re-route to correct method
        switch ($action) {
		   case 'add-credential':
                $this->__addCredential();
                break;
           case 'edit-credential':
                $this->__editCredential();
                break;
			case 'add-teammembers':
				$this->_addTeammembers();
			break;	
            default:
                $this->__editCredential();
        }

        //load view
        $this->__flmView('admin/main');

    }
	
		/*
		Edit Credential
	*/
	
	function __addCredential(){

        //profiling
        $this->data['controller_profiling'][] = __function__;
		
		 //make form visible
        $this->data['visible']['wi_add_project_form'] = 1;

        //flow control
        $next = true;

		//get credential id
        $id = $this->uri->segment(3);
		
		$result = array("id" => $id);
		
		$this->data['vars']['proj'] = $id;

	}
	
	/*
		Edit Credential
	*/
	
	function __editCredential(){
		
        //profiling
        $this->data['controller_profiling'][] = __function__;
		
		 //make form visible
        $this->data['visible']['wi_edit_credential_form'] = 1;

        //flow control
        $next = true;

        //get users id
        $id = $this->uri->segment(3);
		

        //load users details
        $result = $this->projects_model->pcredentailDetail($id);;

        //check data
        if ($result) {
          
            $this->data['reg_fields'][] = 'blk1';
            $this->data['fields']['blk1'] = $result;

        } else {

            //show error
            $this->notifications('wi_notification', $this->data['lang']['lang_no_results_found']);
        }

	}
	
	/*
		Get Password 
	*/
	
	function __showPPassword(){
		
        //profiling
        $this->data['controller_profiling'][] = __function__;

        //flow control
        $next = true;

        //get users id
        $id = $this->uri->segment(4);
		

        //load users details
        $result = $this->projects_model->showPPassword($id);
		$password = base64_decode($result["cpassword"]);

        //check data
        if ($password) {
          
            $this->data['reg_fields'][] = 'password';
            $this->data['fields']['password'] = $password;

        } else {

            //show error
            $this->notifications('wi_notification', $this->data['lang']['lang_no_results_found']);
        }

	}
	/**
     * loads the view
     *
     * @param string $view the view to load
     */
    function __flmView($view = '')
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //template::
        $this->data['template_file'] = help_verify_template($this->data['template_file']);
		

        //complete the view
        $this->__commonAll_View($view);
    }
	
	/*
		Edit Credential
	*/
	
	function _addTeammembers(){
		
        //profiling
        $this->data['controller_profiling'][] = __function__;
		
		 //make form visible
        $this->data['visible']['wi_add_team_member'] = 1;

        //flow control
        $next = true;

        //get users id
        $project_id = $this->uri->segment(3);
		
		$this->data['vars']['proj'] = $project_id;
		
        //load users details
        $result = $this->projects_model->getDetail($project_id);

        //check data
        if ($result) {
          
            $this->data['reg_blocks'][] = 'blk1';
            $this->data['blocks']['blk1'] = $result;

        } else {

            //show error
            $this->notifications('wi_notification', $this->data['lang']['lang_no_results_found']);
        }

	}
	
	/**
     * Generates various pulldown (<option>...</option>) lists for ready use in HTML
     * Output is set to e.g. $this->data['lists']['milestones']
     *
     */
    function __pulldownLists()
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //[all_team_members]
        $data = $this->teamprofile_model->allTeamMembers('team_profile_full_name', 'ASC');
        
        $this->data['lists']['all_team_members'] = create_pulldown_list($data, 'team_members', 'id');

    }
	
}

/* End of file credential.php */
/* Location: ./application/controllers/admin/credential.php */
