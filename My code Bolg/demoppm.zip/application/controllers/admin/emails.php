<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * class for perfoming all Mycredentials related functions
 *
 * @author   Mindxpert.com
 * @access   public
 * @see      http://www.mindxpert.com
 */
class Emails extends MY_Controller
{

    /**
     * constructor method
     */
    public function __construct()
    {

        parent::__construct();

        //profiling::
        $this->data['controller_profiling'][] = __function__;


        //template file
        $this->data['template_file'] = PATHS_ADMIN_THEME . 'emails.html';

    }

    /**
     * This is our re-routing function and is the inital function called
     *
     * 
     */
    function index()
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;
		
        //uri - action segment
        $action = $this->uri->segment(3);
		
        //re-route to correct method
        switch ($action) {
		   case 'send-status':
                $this->__sendStatus();
                break;
           case 'due-status-email':
                $this->__duestatusMail();
                break;
			case 'get-updates':
                $this->__getUpdates();
                break;	
            default:
                $this->__sendStatus();
        }

        //load view
        $this->__flmView('admin/main');

    }
	
		/*
		Send Status
	*/
	
	function __sendStatus(){

        //profiling
        $this->data['controller_profiling'][] = __function__;
		
		 //make form visible
        $this->data['visible']['wi_email_form'] = 1;
		
		$result = $this->projects_model->sendStatus();
		
		echo $result;
		
	}
	
	/*
		Send Status
	*/
	
	function __duestatusMail(){

        //profiling
        $this->data['controller_profiling'][] = __function__;
		
		 //make form visible
        $this->data['visible']['wi_email_form'] = 1;
		
		$result = $this->projects_model->sendStatustoemployee();
		
		echo $result;
		
	}
	
	
	/**
     * loads the view
     *
     * @param string $view the view to load
     */
    function __flmView($view = '')
    {

        //profiling
        $this->data['controller_profiling'][] = __function__;

        //template::
        $this->data['template_file'] = help_verify_template($this->data['template_file']);
		

        //complete the view
        $this->__commonAll_View($view);
    }
	
	function __getUpdates(){
		$result = $this->projects_model->getLatestupdates();
		
		$result = 	json_encode($result);
		echo $result;
		die;
	}
	
	
}

/* End of file credential.php */
/* Location: ./application/controllers/admin/credential.php */
