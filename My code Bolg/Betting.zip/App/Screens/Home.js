import React, { Component } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import Matches from './Cricket/Matches';
import Sessions from './Cricket/Sessions';

import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  Image,
  Button,
  TouchableOpacity,
  Touchable,
  Colors,
  DebugInstructions,
  Header,
  LearnMoreLinks,
  ReloadInstructions,
} from 'react-native';


const Stack = createNativeStackNavigator();
const Tab = createMaterialTopTabNavigator();
class HomeScreen extends Component {

   constructor(props: Object) {
    super(props);
    this.state ={ timer: 0}
  }



  /*componentDidMount(){
    this.interval = setInterval(
      () => this.setState((prevState)=> ({ timer: prevState.timer + 1 })),
      1000
    );
  }

  componentDidUpdate(){
    if(this.state.timer === 100){ 
      clearInterval(this.interval);
    }
  }

  componentWillUnmount(){
   clearInterval(this.interval);
  }*/

  render() {
    return (
      <Tab.Navigator
      initialRouteName="Matches"
      screenOptions={{
        tabBarActiveTintColor: '#e91e63',
        tabBarLabelStyle: { fontSize: 12 },
        tabBarStyle: { backgroundColor: 'powderblue' },
      }}
    >
      <Tab.Screen
        name="Matches"
        component={Matches}
        options={{ tabBarLabel: 'Matches' }}
      />
      <Tab.Screen
        name="Sessions"
        component={Sessions}
        options={{ tabBarLabel: 'Sessions' }}
      />
    </Tab.Navigator>
    )
  }
}


const styles = {  
  container: {
    height: '100%',
    display:'flex',
    flexDirection:'row',
    justifyContent:'center',
    backgroundColor:'#f1f2f4'
  },
  leftContainer: {
    padding:2,
    display:'flex',
    flexDirection:'column',
    alignItems:'flex-start',
    width:'70%'
  },
  rightContainer: {
     padding:2,
    
     display:'flex',
     width:'30%'
  },
  leftHeadContainer: {
    
  },
  rightHeadContainer: {
    flexDirection:'row',
  },
  BtSection: {
    width:'50%',
    textAlign:'center',
    
  },
  BtSectionRt: {
     width:'50%',
    textAlign:'center',
    
  },
  BtinnrSection: {
    width:'50%',
    textAlign:'center',
     backgroundColor:'#a5d9fd',
       padding:10,
  },
  BtinnrSectionRt: {
     width:'50%',
    textAlign:'center',
    backgroundColor:'#f9cad4',
      padding:10,
  },
  leftInnerSec: {
    flexDirection:'column',
    backgroundColor:'#fff',
    width:'100%'
  },
  matchDetailsec: {
    padding:10,
    borderWidth:1,
    borderColor:'gray'
  },
  rightInnerSec: {
    flexDirection:'row',
    backgroundColor:'#fff',
    width:'100%',
     borderWidth:1,
    borderColor:'gray'
  }
};
export default HomeScreen;
