import React, { Component } from 'react';

import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  Image,
  Button,
  TouchableOpacity,
  Pressable,
  Touchable,
  Colors,
  DebugInstructions,
  Header,
  LearnMoreLinks,
  ReloadInstructions,
  Modal,
  Alert,
  TextInput
} from 'react-native';

const initialState = ''

class Mathces extends Component {
   // initial state
  state = {
    modalVisible: true
  };

  

  onAmountChange = betamount => {
    this.setState({betamount});
    this.winametstate = betamount*this.betstate.winratio;
    this.winametstate =  this.winametstate.toFixed(2);
  };


   constructor(props: Object) {
    super(props);
    this.betstate = {
            winteam: '',
            winratio: '',
            match:''
          };
    this.winametstate = this.state.betamount;
  }


  // hide show modal
  setModalVisible = (visible,match,winteam = 0,winratio = 0) => {
    this.setState({ modalVisible: visible });
    this.betstate.winteam = winteam;
    this.betstate.winratio = winratio;
    this.betstate.match = match;
    if(!visible){
      this.betstate = {
            winteam: '',
            winratio: '',
            match:''
          };
      this.setState({betamount:''});     
      this.winametstate = 0;
    }
  }

  placeBet(visible){
    this.setState({ modalVisible: visible });
    setTimeout(function(){
      Alert.alert("Your bet has been placed.");
    },500)
     this.betstate = {
            winteam: '',
            winratio: '',
            match:''
          };
      this.setState({betamount:''});     
      this.winametstate = 0;
  }


  /*componentDidMount(){
    this.interval = setInterval(
      () => this.setState((prevState)=> ({ timer: prevState.timer + 1 })),
      1000
    );
  }

  componentDidUpdate(){
    if(this.state.timer === 100){ 
      clearInterval(this.interval);
    }
  }

  componentWillUnmount(){
   clearInterval(this.interval);
  }*/

 

  render() {
    const { modalVisible } = this.state;
  	 var matches = [[{ id: 1, name: 'India','match': 'India vs Pakistan', win: '1.7', back: '3.7' }, { id: 2, name: 'Pak','match': 'England vs india', win: '3.7', back: '1.7' }],[{ id: 3, name: 'Eng','match' : 'England vs india', win: '1.7', back: '1.2' }, { id: 4, name: 'Ban','match': 'England vs india', win: '2.7', back: '1.2' }]
];


  var MathesNames = [];
  var MathesBet = [];

	for(let i = 0; i < matches.length; i++){
    MathesNames.push( <View style={styles.matchHeadtitleContainer}><Text style={styles.textStyle}>India vs Pakistan</Text></View>)
   
       MathesBet.push(  <View style={styles.matchRtHeadtitleContainer}>
          <View style={styles.BtSection}><Text style={styles.textStyle}>&nbsp;</Text></View>
          </View>)
    
   
    for(let j = 0;j< matches[i].length;j++){
      MathesNames.push(
        <View style={styles.leftInnerSec}>
          <View key={matches[i][j].name} style={styles.matchDetailsec}><Text style={styles.blacktextStyle}>{matches[i][j].name}</Text></View>
        </View> 
      )
      MathesBet.push(
       <View style={styles.rightInnerSec}>
              <Pressable  onPress={() => {
                this.setModalVisible(true,matches[i][j].match,matches[i][j].name,matches[i][j].win);
              }}  style={({ pressed }) => [
          {
            backgroundColor: pressed
              ? 'yellow'
              : '#570f2c'
          },
          styles.BtinnrSection
        ]}>
        {({ pressed }) => (
          <Text style={pressed ? styles.blacktextrtStyle : styles.wttextrtStyle}>
            {matches[i][j].win}
          </Text>
        )}
              </Pressable>
              </View>
      )
    }
	}
	//console.log(matches);
    return (
     <View style={styles.container}>
        <View style={styles.leftContainer}>
        <View style={styles.leftHeadContainer}><Text style={styles.textStyle,{textAlign:'center',color:'#fff'}}>Matches </Text></View>
          {MathesNames}
        </View>
        <View style={styles.rightContainer}>
        <View style={styles.rightHeadContainer}><Text style={styles.centertextStyle}> Rates </Text></View>
         {MathesBet}
        </View>
        <View style={styles.modalContainer}>
         <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            Alert.alert("Modal has been closed.");
            this.setModalVisible(!modalVisible);
          }}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={styles.modalTextHead}>Bet Slip ( {this.betstate.match} )</Text>
              <View style={styles.leftBetslipsec}>
                <View style={styles.betdetailView}>
                    <Text style={styles.bettitle}>{this.betstate.winteam}</Text>
                    <Text style={styles.betratio}>{this.betstate.winratio}</Text>
                </View>
                <View style={styles.betdetailAmtView}>
                    <TextInput
                      style={styles.betinput}
                      value={this.state.betamount}
                      maxLength={256}
                       keyboardType='numeric'
                      placeholder="Enter amount..."
                      autoCapitalize="none"
                      autoCorrect={false}
                      returnKeyType="next"
                      onChangeText={this.onAmountChange}
                      underlineColorAndroid="transparent"
                      placeholderTextColor="#999"
                    />
                    <Text style={styles.betwinamount}>You won {this.winametstate}</Text>
                </View>
              </View>
              <View style={styles.ftBetslipsec}>
              <Text style={styles.winbetsec}>{}</Text>

               <Pressable  onPress={() => {
                this.setModalVisible(!modalVisible);
              }}  style={({ pressed }) => [
          {
            backgroundColor: pressed
              ? '#fff'
              : '#FF3974'
          },
          styles.closeButton
        ]}>
        {({ pressed }) => (
          <Text style={pressed ? styles.blacktextrtStyle : styles.wttextrtStyle}>
            Cancel
          </Text>
        )}
              </Pressable>

               <Pressable  onPress={() => {
                this.placeBet(!modalVisible);
              }}  style={({ pressed }) => [
          {
            backgroundColor: pressed
              ? 'yellow'
              : '#570f2c'
          },
          styles.placeButton
        ]}>
        {({ pressed }) => (
          <Text style={pressed ? styles.blacktextrtStyle : styles.wttextrtStyle}>
            Place Bet
          </Text>
        )}
              </Pressable>
              </View>
             
            </View>
          </View>
        </Modal>
        </View>
      </View> 
    )
  }
}


const styles = {  
  container: {
    height: '100%',
    display:'flex',
    flexDirection:'row',
    justifyContent:'center',
    backgroundColor:'#192333'
  },
  leftContainer: {
    padding:2,
    marginTop:5,
    display:'flex',
    flexDirection:'column',
    alignItems:'flex-start',
    width:'70%'
  },
  rightContainer: {
     padding:2,
     marginTop:5,
     display:'flex',
     width:'30%'
  },
  leftHeadContainer: {
    textAlign:'center',
    width:'100%',
    fontWeight:'bold',
    color:'#fff'
  },
  rightHeadContainer: {
    textAlign:'center',
    width:'100%',
    fontWeight:'bold',
    
  },
  textStyle: {
    color:'#fff',
    fontSize:16
  },
  centeredView:{
    marginTop:200
  },
  centertextStyle: {
    color:'#fff',
    fontSize:16,
    textAlign:'center'
  },
  blacktextStyle: {
    color:'#000',
    fontWeight:'bold',
    fontSize:16
  },
   blacktextrtStyle: {
    color:'#000',
    textAlign:'center',
    fontWeight:'bold',
    fontSize:16
  },
  wttextrtStyle:{
    color:'#fff',
    textAlign:'center',
    fontWeight:'bold',
    fontSize:16
  },
  yellowtextStyle: {
    backgroundColor:'#yellow'
  },
  BtSection: {
    width:'50%',
    textAlign:'center',
    
  },
  BtSectionRt: {
     width:'50%',
    textAlign:'center',
    
  },
  BtinnrSection: {
    width:'100%',
    textAlign:'center',
       padding:10,
  },
  BtinnrSectionRt: {
     width:'50%',
    textAlign:'center',
    backgroundColor:'#f9cad4',
      padding:10,
  },
  leftInnerSec: {
    flexDirection:'column',
    backgroundColor:'#fff',
    width:'100%'
  },
  matchDetailsec: {
    padding:10,
    borderWidth:1,
    borderColor:'gray'
  },
  rightInnerSec: {
    flexDirection:'row',
    backgroundColor:'#fff',
    width:'100%',
     borderWidth:1,
    borderColor:'gray'
  },
  matchHeadtitleContainer: {
    margin:9,
    color:'red'
  },
  matchRtHeadtitleContainer: {
     margin:9,
   
    flexDirection:'row'
  },
  closeButton: {
    display: 'flex',
    height: 47,
    width: 93,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
   
    shadowColor: '#2AC062',
    shadowOpacity: 0.5,
    shadowOffset: { 
      height: 10, 
      width: 0 
    },
    shadowRadius: 25
    
  },
  placeButton:{
    display: 'flex',
    height: 47,
    width: 93,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#2AC062',
    shadowOpacity: 0.5,
    shadowOffset: { 
      height: 10, 
      width: 0 
    },
    shadowRadius: 25,
    marginLeft:15
  },
  modalTextHead: {
    color: '#000',
    fontSize: 22,
    textAlign:'center',
    width:'100%'
  },
  modalText: {
    color: '#000',
    fontSize: 12,
    textAlign:'left'
  },

  modalView: {
    marginTop: 2,
    display:'flex',
    backgroundColor: "white",
    borderRadius: 20,
    padding: 30,
    alignItems: "flex-start",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5
  },
  modalContainer: {
    position:'absolute',
    left:0,
    top:50
  },
  leftBetslipsec: {
   marginBottom:15
  },
  bettitle: {
    color:'#000',
    width:'50%',
  },
  betratio: {
    width:'50%',
     textAlign:'right',
      color:'red'
  },
  winbetsec: {

  },
  ftBetslipsec: {
    flexDirection:'row',
    marginTop:5,
    display: 'flex',
    alignItems: 'center',
    width:'100%',
    justifyContent: 'center'
  },
  betinput: {
    height: 40,
    width:'50%',
    padding: 12,
    backgroundColor: '#192333',
    borderRadius: 6,
    color:'#fff',
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    marginBottom: 1
  },
  betdetailView:{
    flexDirection:'row',
    marginTop:15,
  },
  betdetailAmtView:{
     flexDirection: 'row',
     marginTop:10
  },
  betwinamount:{
     width:'50%',
     textAlign: 'right',
     marginTop:12,
     fontSize:16
  }
};
export default Mathces;
