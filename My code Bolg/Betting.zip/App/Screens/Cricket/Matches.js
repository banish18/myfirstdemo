import React, { Component } from 'react';

import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  Image,
  Button,
  TouchableOpacity,
  Pressable,
  Touchable,
  Colors,
  DebugInstructions,
  Header,
  LearnMoreLinks,
  ReloadInstructions,
  Modal,
  Alert,
  TextInput
} from 'react-native';

const initialState = {
  username: '',
  password: '',
  errors: {},
  isAuthorized: false,
  isLoading: false,
};

class Mathces extends Component {
   // initial state
  state = {
    modalVisible: true
  };

  betstate = initialState;

  onAmountChange = betamount => {
    this.setState({betamount});

    this.winametstate = betamount*1.2;
    this.winametstate =  this.winametstate.toFixed(2);
  };


   constructor(props: Object) {
    super(props);
    this.winametstate = 10
  }


  // hide show modal
  setModalVisible = (visible) => {
    this.setState({ modalVisible: visible });
  }

  placeBet(visible){
    this.setState({ modalVisible: visible });
    setTimeout(function(){
      Alert.alert("Your bet has been placed.");
    },500)
    
  }


  /*componentDidMount(){
    this.interval = setInterval(
      () => this.setState((prevState)=> ({ timer: prevState.timer + 1 })),
      1000
    );
  }

  componentDidUpdate(){
    if(this.state.timer === 100){ 
      clearInterval(this.interval);
    }
  }

  componentWillUnmount(){
   clearInterval(this.interval);
  }*/

 

  render() {
    const { modalVisible } = this.state;
  	 var matches = [[{ id: 1, name: 'India', win: '1.7', back: '3.7' }, { id: 1, name: 'Pak', win: '3.7', back: '1.7' }],[{ id: 1, name: 'Eng', win: '1.7', back: '1.2' }, { id: 1, name: 'Ban', win: '2.7', back: '1.2' }]
];


  var MathesNames = [];
  var MathesBet = [];

	for(let i = 0; i < matches.length; i++){
    MathesNames.push( <View style={styles.matchHeadtitleContainer}><Text style={styles.textStyle}>* Match {i+1}</Text></View>)
   
       MathesBet.push(  <View style={styles.matchRtHeadtitleContainer}>
          <View style={styles.BtSection}><Text style={styles.textStyle}>&nbsp;</Text></View>
          </View>)
    
   
    for(let j = 0;j< matches[i].length;j++){
      MathesNames.push(
        <View style={styles.leftInnerSec}>
          <View style={styles.matchDetailsec}><Text style={styles.textStyle}>{matches[i][j].name}</Text></View>
        </View> 
      )
      MathesBet.push(
       <View style={styles.rightInnerSec}>
              <Pressable  onPress={() => {
                this.setModalVisible(true);
              }} style={styles.BtinnrSection}><Text style={styles.textStyle}>{matches[i][j].win}</Text>
              </Pressable>
              </View>
      )
    }
	}
	console.log(matches);
    return (
     <View style={styles.container}>
        <View style={styles.leftContainer}>
        <View style={styles.leftHeadContainer}><Text style={styles.textStyle}>* Matches </Text></View>
          {MathesNames}
        </View>
        <View style={styles.rightContainer}>
        <View style={styles.rightHeadContainer}><Text style={styles.textStyle}>* Bets </Text></View>
         {MathesBet}
        </View>
        <View style={styles.modalContainer}>
         <Modal
          animationType="slide"
          transparent={false}
          visible={modalVisible}
          onRequestClose={() => {
            Alert.alert("Modal has been closed.");
            this.setModalVisible(!modalVisible);
          }}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>

              <Text style={styles.modalTextHead}>Bet Slip ( India vs Pakistan )</Text>
              <View style={styles.leftBetslipsec}>
                <View style={styles.betdetailView}>
                    <Text style={styles.bettitle}>India</Text>
                    <Text style={styles.betratio}>1.2</Text>
                </View>
                <View style={styles.betdetailAmtView}>
                    <TextInput
                      style={styles.betinput}
                      value={this.state.betamount}
                      maxLength={256}
                       keyboardType='numeric'
                      placeholder="Enter amount..."
                      autoCapitalize="none"
                      autoCorrect={false}
                      returnKeyType="next"
                      onChangeText={this.onAmountChange}
                      underlineColorAndroid="transparent"
                      placeholderTextColor="#999"
                    />
                    <Text style={styles.betwinamount}>You won {this.winametstate}</Text>
                </View>
              </View>
              <View style={styles.ftBetslipsec}>
              <Text style={styles.winbetsec}>{}</Text>
              <Pressable
                style={[styles.button, styles.closeButton]}
                onPress={() => this.setModalVisible(!modalVisible)}
              >
                <Text style={styles.textStyle}>Close</Text>
              </Pressable>

               <Pressable
                style={[styles.button, styles.placeButton]}
                onPress={() => this.placeBet(!modalVisible)}
              >
                <Text style={styles.textStyle}>Place Bet</Text>
              </Pressable>

              </View>
             
            </View>
          </View>
        </Modal>
        </View>
      </View> 


    )
  }
}


const styles = {  
  container: {
    height: '100%',
    display:'flex',
    flexDirection:'row',
    justifyContent:'center',
    backgroundColor:'#f1f2f4'
  },
  leftContainer: {
    padding:2,
    display:'flex',
    flexDirection:'column',
    alignItems:'flex-start',
    width:'70%'
  },
  rightContainer: {
     padding:2,
    
     display:'flex',
     width:'30%'
  },
  leftHeadContainer: {
    textAlign:'center',
    width:'100%',
    fontWeight:'bold'
  },
  rightHeadContainer: {
    textAlign:'center',
    width:'100%',
    fontWeight:'bold'
  },
  BtSection: {
    width:'50%',
    textAlign:'center',
    
  },
  BtSectionRt: {
     width:'50%',
    textAlign:'center',
    
  },
  BtinnrSection: {
    width:'100%',
    textAlign:'center',
     backgroundColor:'#a5d9fd',
       padding:10,
  },
  BtinnrSectionRt: {
     width:'50%',
    textAlign:'center',
    backgroundColor:'#f9cad4',
      padding:10,
  },
  leftInnerSec: {
    flexDirection:'column',
    backgroundColor:'#fff',
    width:'100%'
  },
  matchDetailsec: {
    padding:10,
    borderWidth:1,
    borderColor:'gray'
  },
  rightInnerSec: {
    flexDirection:'row',
    backgroundColor:'#fff',
    width:'100%',
     borderWidth:1,
    borderColor:'gray'
  },
  matchHeadtitleContainer: {
    margin:9,
    color:'red'
  },
  matchRtHeadtitleContainer: {
     margin:9,
   
    flexDirection:'row'
  },
  closeButton: {
    display: 'flex',
    height: 47,
    width: 93,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FF3974',
    shadowColor: '#2AC062',
    shadowOpacity: 0.5,
    shadowOffset: { 
      height: 10, 
      width: 0 
    },
    shadowRadius: 25
    
  },
  placeButton:{
    display: 'flex',
    height: 47,
    width: 93,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#81d413',
    shadowColor: '#2AC062',
    shadowOpacity: 0.5,
    shadowOffset: { 
      height: 10, 
      width: 0 
    },
    shadowRadius: 25,
    marginLeft:15
  },
  modalTextHead: {
    color: '#000',
    fontSize: 22,
    textAlign:'center',
    width:'100%'
  },
  modalText: {
    color: '#000',
    fontSize: 12,
    textAlign:'left'
  },

  modalView: {
    margin: 2,
    display:'flex',
    backgroundColor: "white",
    borderRadius: 20,
    padding: 15,
    alignItems: "flex-start",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5
  },
  modalContainer: {
    position:'absolute',
    left:0,
    top:0
  },
  leftBetslipsec: {
   
  },
  bettitle: {
   
    width:'50%',
  },
  betratio: {
    width:'50%',
     textAlign:'right',
      color:'red'
  },
  winbetsec: {

  },
  ftBetslipsec: {
    flexDirection:'row',
    marginTop:5,
    display: 'flex',
    alignItems: 'center',
    width:'100%',
    justifyContent: 'center'
  },
  betinput: {
    height: 40,
    width:'50%',
    padding: 12,
    backgroundColor: 'red',
    borderRadius: 6,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    marginBottom: 1
  },
  betdetailView:{
    flexDirection:'row',
    marginTop:15,
  },
  betdetailAmtView:{
     flexDirection: 'row',
     marginTop:10
  },
  betwinamount:{
     width:'50%',
     textAlign: 'right'
  }
};
export default Mathces;
