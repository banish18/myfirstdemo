import React, { Component } from 'react';

import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  Image,
  Button,
  TouchableOpacity,
  Pressable,
  Touchable,
  Colors,
  DebugInstructions,
  Header,
  LearnMoreLinks,
  ReloadInstructions,
  Modal,
  Alert,
  TextInput
} from 'react-native';

import Accordion from 'react-native-collapsible/Accordion';

const initialState = ''




class Sessions extends Component {
   // initial state
  state = {
    modalVisible: true,
     activeSections: [],
  };
  SECTIONS = [
    
  ];
  _

  _updateSections = (activeSections) => {
    this.setState({ activeSections });
  };

  

  onAmountChange = betamount => {
    this.setState({betamount});
    this.winametstate = betamount*1;
    this.winametstate =  this.winametstate.toFixed(2);
  };


   constructor(props: Object) {
    super(props);
    this.betstate = {
            winteam: '',
            match:''
          };
    this.winametstate = this.state.betamount;

    this.SECTIONS = this.sessionsData();

    console.log('bharat');
    console.log(this.sessionsData());
  }


  // hide show modal
  setModalVisible = (visible = false,match,winteam = 0) => {
    this.setState({ modalVisible: visible });
    this.betstate.winteam = winteam;
    this.betstate.match = match;
    if(!visible){
      this.betstate = {
            winteam: '',
            match:''
          };
      this.setState({betamount:''});     
      this.winametstate = 0;
    }
  }

  placeBet(visible){
    this.setState({ modalVisible: visible });
    setTimeout(function(){
      Alert.alert("Your bet has been placed.");
    },500)
     this.betstate = {
            winteam: '',
            match:''
          };
      this.setState({betamount:''});     
      this.winametstate = 0;
  }



  _renderSectionTitle = (section) => {
    return (
      <View style={styles.matchesinnerSec}>
        <Text style={styles.matchesinnerSec}>{section.content}</Text>
      </View>
    );
  };

  _renderHeader = (section) => {
    return (
      <View style={styles.matchesinnerSec}>
        <Text style={styles.wttextrtStyle}>{section.title}</Text>
      </View>
    );
  };

  _renderContent = (section) => {
    const { modalVisible } = this.state;
    return (
      <View style={styles.matchesSec}>
        <Text style={styles.blacktextrtStyle,{marginBottom:15,fontSize:20,fontWeight:'bold'}}>{section.content}</Text>
        <View key={'laysec'} style={styles.sessionbetsect}>
        <Pressable  onPress={() => {
                this.setModalVisible(!modalVisible,section.title,section.lay);
              }}  style={({ pressed }) => [
          {
            backgroundColor: pressed
              ? '#570f2c'
              : 'yellow'
          },
          styles.sesstionbtbtn
        ]}>
        {({ pressed }) => (
          <Text style={pressed ? styles.wttextrtStyle : styles.blacktextrtStyle}>
            {section.lay}
          </Text>
        )}
              </Pressable>
       
          <Pressable  onPress={() => {
                this.setModalVisible(!modalVisible,section.title,section.back);
              }}  style={({ pressed }) => [
          {
            backgroundColor: pressed
              ? '#570f2c'
              : 'yellow'
          },
          styles.sesstionbtbtn
        ]}>
        {({ pressed }) => (
          <Text style={pressed ? styles.wttextrtStyle : styles.blacktextrtStyle}>
           {section.back}
          </Text>
        )}
              </Pressable>
        </View>
      </View>
    );
  };

  sessionsData(){
      const { modalVisible } = this.state;
     var matches = [{ id: 1,'title': 'India vs Pakistan','content':'Next Five Over Runs','lay':30,'back':40}, { id: 2,'title': 'England vs Bangladesh','content':'Next 10 over Runs','lay':100,'back':140}];


      var MathesNames = [];
      
      for(let i = 0; i < matches.length; i++){
          MathesNames.push(
          
              <View key={matches[i].id} style={styles.matchesSec}>
              <Pressable  onPress={() => {
                    this.setModalVisible(!modalVisible);
                  }}  style={({ pressed }) => [
              {
                backgroundColor: pressed
                  ? 'yellow'
                  : '#570f2c'
              },
              styles.matchesinnerSec
            ]}>
            {({ pressed }) => (
              <Text style={pressed ? styles.blacktextrtStyle : styles.wttextrtStyle}>
                {matches[i].match}
              </Text>
            )}
                  </Pressable>

              </View>
          
          )
      }

      return matches;
  }




  render() {
     const { modalVisible } = this.state;
    return (
     <View key={'container'} style={styles.container}>
        <View key={'headContainer'} style={styles.headContainer}>
            <Text style={styles.wttextrtStyle}>Matches</Text>  
             <View key={'matchContainer'} style={styles.matchContainer}>
      
            <Accordion
        sections={this.SECTIONS}
        activeSections={this.state.activeSections}
        renderHeader={this._renderHeader}
        renderContent={this._renderContent}
        onChange={this._updateSections}
      />
         </View>
        </View>
        <View key={'modalContainer'} style={styles.modalContainer}>
         <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            Alert.alert("Modal has been closed.");
            this.setModalVisible(!modalVisible);
          }}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={styles.modalTextHead}>Bet Slip ( {this.betstate.match} )</Text>
              <View style={styles.leftBetslipsec}>
                <View style={styles.betdetailView}>
                    <Text style={styles.bettitle}>{this.betstate.winteam}</Text>
                    <Text style={styles.betratio}>{this.betstate.winratio}</Text>
                </View>
                <View style={styles.betdetailAmtView}>
                    <TextInput
                      style={styles.betinput}
                      value={this.state.betamount}
                      maxLength={256}
                       keyboardType='numeric'
                      placeholder="Enter amount..."
                      autoCapitalize="none"
                      autoCorrect={false}
                      returnKeyType="next"
                      onChangeText={this.onAmountChange}
                      underlineColorAndroid="transparent"
                      placeholderTextColor="#999"
                    />
                    <Text style={styles.betwinamount}>You won {this.winametstate}</Text>
                </View>
              </View>
              <View style={styles.ftBetslipsec}>
              <Text style={styles.winbetsec}>{}</Text>

               <Pressable  onPress={() => {
                this.setModalVisible(!modalVisible);
              }}  style={({ pressed }) => [
          {
            backgroundColor: pressed
              ? '#fff'
              : '#FF3974'
          },
          styles.closeButton
        ]}>
        {({ pressed }) => (
          <Text style={pressed ? styles.blacktextrtStyle : styles.wttextrtStyle}>
            Cancel
          </Text>
        )}
              </Pressable>

               <Pressable  onPress={() => {
                this.placeBet(!modalVisible);
              }}  style={({ pressed }) => [
          {
            backgroundColor: pressed
              ? 'yellow'
              : '#570f2c'
          },
          styles.placeButton
        ]}>
        {({ pressed }) => (
          <Text style={pressed ? styles.blacktextrtStyle : styles.wttextrtStyle}>
            Place Bet
          </Text>
        )}
              </Pressable>
              </View>
             
            </View>
          </View>
        </Modal>
        </View>
      </View> 
    )
  }
}


const styles = {  
  container: {
    height: '100%',
    display:'flex',
    flexDirection:'row',
    justifyContent:'center',
    backgroundColor:'#192333'
  },
  headContainer: {
    padding:2,
    marginTop:10,
    alignItems:'center',
    width:'100%',
  },
  matchContainer:{
    width:'100%',
    flexDirection:'column',
    marginTop:5
  },
  matchesSec: {
    width:'100%',
    height:'100%', 
    backgroundColor:'#f9cad4',
    color:'#000',
    padding:5
    
  },
  sessionbetsect:{
     flexDirection:'row',
     width:'100%',
     marginBottom:5,
     justifyContent: 'center',
    alignItems: 'center',
  },
  matchesinnerSec: {
    width:'100%',
    padding: 12,
    borderRadius: 6,
     marginTop:5,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    marginBottom: 1,
    backgroundColor:'#570f2c'
  },
  blacktextrtStyle: {
    color:'#000',
    
    fontWeight:'bold',
    fontSize:16
  },
  wttextrtStyle:{
    color:'#fff',
    textAlign:'center',
    fontWeight:'bold',
    fontSize:16
  },
  BtSection: {
    width:'50%',
    textAlign:'center'
  },
  BtSectionRt: {
     width:'50%',
    textAlign:'center',
    
  },
  BtinnrSection: {
    width:'100%',
    textAlign:'center',
       padding:10,
  },
  BtinnrSectionRt: {
     width:'50%',
    textAlign:'center',
    backgroundColor:'#f9cad4',
      padding:10,
  },
  leftInnerSec: {
    flexDirection:'column',
    backgroundColor:'#fff',
    width:'100%'
  },
  matchDetailsec: {
    padding:10,
    borderWidth:1,
    borderColor:'gray'
  },
  rightInnerSec: {
    flexDirection:'row',
    backgroundColor:'#fff',
    width:'100%',
     borderWidth:1,
    borderColor:'gray'
  },
  matchHeadtitleContainer: {
    margin:9,
    color:'red'
  },
  matchRtHeadtitleContainer: {
     margin:9,
   
    flexDirection:'row'
  },
  closeButton: {
    display: 'flex',
    height: 47,
    width: 93,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#2AC062',
    shadowOpacity: 0.5,
    shadowOffset: { 
      height: 10, 
      width: 0 
    },
    shadowRadius: 25
    
  },
  sesstionbtbtn:{
    display: 'flex',
    height: 40,
    width: 70,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#2AC062',
    shadowOpacity: 0.5,
    shadowOffset: { 
      height: 10, 
      width: 0 
    },
    shadowRadius: 25,
    marginLeft:15
  },
  placeButton:{
    display: 'flex',
    height: 47,
    width: 93,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#2AC062',
    shadowOpacity: 0.5,
    shadowOffset: { 
      height: 10, 
      width: 0 
    },
    shadowRadius: 25,
    marginLeft:15
  },
  modalTextHead: {
    color: '#000',
    fontSize: 22,
    textAlign:'center',
    width:'100%'
  },
  modalText: {
    color: '#000',
    fontSize: 12,
    textAlign:'left'
  },

  modalView: {
    marginTop: 2,
    display:'flex',
    backgroundColor: "white",
    borderRadius: 20,
    padding: 30,
    alignItems: "flex-start",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5
  },
  modalContainer: {
    position:'absolute',
    left:0,
    top:50
  },
  leftBetslipsec: {
   marginBottom:15
  },
  bettitle: {
    color:'#000',
    width:'50%',
  },
  betratio: {
    width:'50%',
     textAlign:'right',
      color:'red'
  },
  winbetsec: {

  },
  ftBetslipsec: {
    flexDirection:'row',
    marginTop:5,
    display: 'flex',
    alignItems: 'center',
    width:'100%',
    justifyContent: 'center'
  },
  betinput: {
    height: 40,
    width:'50%',
    padding: 12,
    backgroundColor: '#192333',
    borderRadius: 6,
    color:'#fff',
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    marginBottom: 1
  },
  betdetailView:{
    flexDirection:'row',
    marginTop:15,
  },
  betdetailAmtView:{
     flexDirection: 'row',
     marginTop:10
  },
  betwinamount:{
     width:'50%',
     textAlign: 'right',
     marginTop:12,
     fontSize:16
  }
};
export default Sessions;
