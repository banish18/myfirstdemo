import React, { Component } from 'react';

import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  Image,
  Button,
  TouchableOpacity,
  Touchable,
  Colors,
  DebugInstructions,
  Header,
  LearnMoreLinks,
  ReloadInstructions,
} from 'react-native';


class Mathces extends Component {

   constructor(props: Object) {
    super(props);
    this.state ={ timer: 0}
  }



  /*componentDidMount(){
    this.interval = setInterval(
      () => this.setState((prevState)=> ({ timer: prevState.timer + 1 })),
      1000
    );
  }

  componentDidUpdate(){
    if(this.state.timer === 100){ 
      clearInterval(this.interval);
    }
  }

  componentWillUnmount(){
   clearInterval(this.interval);
  }*/

  render() {
    return (
     <View style={styles.container}>
        <View style={styles.leftContainer}>
          <View style={styles.leftHeadContainer}><Text style={styles.textStyle}>* Sessions</Text></View>
          <View style={styles.leftInnerSec}>
            <View style={styles.matchDetailsec}><Text style={styles.textStyle}>Next 5 Runs</Text></View>
            <View style={styles.matchDetailsec}><Text style={styles.textStyle}>Wickets in next over</Text></View>
          </View>
        </View>
        <View style={styles.rightContainer}>
         <View style={styles.rightHeadContainer}>
          <View style={styles.BtSection}><Text style={styles.textStyle}>Back</Text></View>
          <View style={styles.BtSection}><Text style={styles.textStyle}>Lay</Text></View>
          </View>
         <View style={styles.rightInnerSec}>
            <View style={styles.BtinnrSection}><Text style={styles.textStyle}>30</Text></View>
            <View style={styles.BtinnrSectionRt}><Text style={styles.textStyle}>40</Text></View>
          </View>
          <View style={styles.rightInnerSec}>
            <View style={styles.BtinnrSection}><Text style={styles.textStyle}>1</Text></View>
            <View style={styles.BtinnrSectionRt}><Text style={styles.textStyle}>2</Text></View>
          </View>
        </View>
      </View> 
    )
  }
}


const styles = {  
  container: {
    height: '100%',
    display:'flex',
    flexDirection:'row',
    justifyContent:'center',
    backgroundColor:'#f1f2f4'
  },
  leftContainer: {
    padding:2,
    display:'flex',
    flexDirection:'column',
    alignItems:'flex-start',
    width:'70%'
  },
  rightContainer: {
     padding:2,
    
     display:'flex',
     width:'30%'
  },
  leftHeadContainer: {
    
  },
  rightHeadContainer: {
    flexDirection:'row',
  },
  BtSection: {
    width:'50%',
    textAlign:'center',
    
  },
  BtSectionRt: {
     width:'50%',
    textAlign:'center',
    
  },
  BtinnrSection: {
    width:'50%',
    textAlign:'center',
     backgroundColor:'#a5d9fd',
       padding:10,
  },
  BtinnrSectionRt: {
     width:'50%',
    textAlign:'center',
    backgroundColor:'#f9cad4',
      padding:10,
  },
  leftInnerSec: {
    flexDirection:'column',
    backgroundColor:'#fff',
    width:'100%'
  },
  matchDetailsec: {
    padding:10,
    borderWidth:1,
    borderColor:'gray'
  },
  rightInnerSec: {
    flexDirection:'row',
    backgroundColor:'#fff',
    width:'100%',
     borderWidth:1,
    borderColor:'gray'
  }
};
export default Mathces;
