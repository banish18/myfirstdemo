import * as React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import HomeScreen from './App/Screens/Home';
import ProfileScreen from './App/Screens/Profile';
import SettingsScreen from './App/Screens/Settings';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Feather } from '@expo/vector-icons';
import { FontAwesome5 } from '@expo/vector-icons';
import SavedScreen from './App/Screens/Saved';
import ReferScreen from './App/Screens/Refer';
import Login from './App/Screens/Login/Login';
import Register from './App/Screens/Register/Register';
import DrawerItems from './App/Constants/DrawerItems';
import Header from './App/Components/Header';

const Drawer = createDrawerNavigator();

const AppDrawerScreen = () => (
  <Drawer.Navigator 
        drawerType="front"
        initialRouteName="Home"
        drawerContentOptions={{
          activeTintColor: '#e91e63',
          backgroundColor:'red',
          itemStyle: { marginVertical: 10 },
        }}
       
      >
        {
          DrawerItems.map(drawer=><Drawer.Screen 
            key={drawer.name}
            name={drawer.name} 
            options={{
            drawerIcon:({focused})=>
             drawer.iconType==='Material' ? 
              <MaterialCommunityIcons 
                  name={drawer.iconName}
                  size={24} 
                  color={focused ? "#e91e63" : "black"} 
              />
            :
            drawer.iconType==='Feather' ?
              <Feather 
                name={drawer.iconName}
                size={24} 
                color={focused ? "#e91e63" : "black"} 
              /> 
            :
              <FontAwesome5 
                name={drawer.iconName}
                size={24} 
                color={focused ? "#e91e63" : "black"} 
              />
            ,
                headerShown:true,
                
    
  
               /*header: ({ scene }) => {
                  const { options } = scene.descriptor;
                  const title =
                    options.headerTitle !== undefined
                      ? options.headerTitle
                      : options.title !== undefined
                      ? options.title
                      : scene.route.name;
                
                  return (
                    <Header screen={title}/>
                  );
                }*/
                /*header: ({ scene }) => {
                const title = '';
                 return (
                    <Header screen={title}/>
                  );
             }*/
          
            }} 
            component={
              drawer.name==='Home' ? HomeScreen :
              drawer.name==='Profile' ? ProfileScreen 
                : drawer.name==='Settings' ? SettingsScreen 
                  : drawer.name==='Saved Items' ? SavedScreen
                    : ReferScreen
            } 
          />)
        }
      </Drawer.Navigator>
);

const AuthStack = createStackNavigator();
const AuthStackScreen = () => (
  <AuthStack.Navigator>
    <AuthStack.Screen name="Login" component={Login} />
    <AuthStack.Screen name="Register" component={Register} />
  </AuthStack.Navigator>
);

export default function App() {
  //let isAuthorized = await SecureStore.getItemAsync('isAuthorized');
  let isAuthorized = true;
  return (
    <NavigationContainer>
      {isAuthorized ? (
        <AppDrawerScreen />
      ) : (
        <AuthStackScreen />
      )}
    </NavigationContainer>
  );
}